import {makeObjEventEmitter,makeNotify} from "/@events";
import {sleep} from "/@vfact";
import {tabNT,tabFS} from "/@tabos";
import {AAFarm} from "./aafarm.js";
import {AATaskReq,AATaskWork} from "./AATask.js";
import {AASkills} from "./AASkills.js";

//****************************************************************************
//:AABot
//****************************************************************************
let AABot,aaBot;
{
	//------------------------------------------------------------------------
	AABot=function(botNode,stub){
		if(!botNode){
			return;
		}
		this.botNode=botNode;
		this.id=stub.id;
		this.name=stub.name;
		this.host=false;
		this.type=stub.type;
		this.alias=stub.alias;
		this.active=stub.active;
		this.description=stub.description;
		
		this.messages=[];
		makeNotify(this);
	};
	aaBot=AABot.prototype={};
	
	//------------------------------------------------------------------------
	aaBot.getState=async function(){
		//TODO: Code this:
	};
}

//****************************************************************************
//:AAHostBot:
//****************************************************************************
let AAHostBot,aaHostBot;
{
	//------------------------------------------------------------------------
	AAHostBot=function(bots,stub){
		AABot.call(this,bots,stub);
		this.host=true;
		this.isLooping=false;
		this.sessionId=null;
		this.chatSession=null;
		this.taskReqs=new Map();
		this.taskWorks=new Map();
		this.webSocket=null;
		this.waitMsgCall=null;
		this.nextNewMsg=null;
		this.lastReadMsgId=null;
		this.isConnected=false;
		this.isRetryConnect=false;
		this.def=null;
		
		this.botScope=null;
		this.skillScope=null;
		this.skills=new AASkills();
		
		this.nextAskReqId=1;
		this.askReqs={};
		
		this.waitTaskWork=false;
	};
	aaHostBot=AAHostBot.prototype=new AABot();
	
	//------------------------------------------------------------------------
	aaHostBot.getBotDef=async function(){
		let res;
		if(!this.def){
			res=await tabNT.makeCall("AAEBotNodeGetBotDef",{bot:this.id});
			if(!res || res.code!==200){
				if(res && res.info){
					return null;
				}
				return null;
			}
			this.def=res.def;
		}
		return this.def;
	};
	
	//------------------------------------------------------------------------
	aaHostBot.startBotClient=async function(chatSession){
		let res;
		if(this.sessionId){
			throw Error("Bot session already started.");
		}
		
		res=await tabNT.makeCall("AAEBotNodeStartBotClient",{bot:this.id});
		if(!res || res.code!==200){
			if(res && res.info){
				throw Error(res.info);
			}
			throw Error("Get bot message error.");
		}
		this.chatSession=chatSession;
		this.sessionId=res.sessionId;
	};
	
	//------------------------------------------------------------------------
	aaHostBot.stopBotClient=async function(){
		let ws;
		this.sessionId=null;
		this.chatSession=null;
		if(this.isConnected){
			this.isConnected=false;
		}
		ws=this.webSocket;
		this.webSocket=null;
		if(ws){
			ws.close(1000);
		}
	};

	//------------------------------------------------------------------------
	aaHostBot.startMessageClient=async function(){
		let res,msgs,msg,selector,ws,pms;
		let wsReady,wsError,i,n;
		this.lastMsgTime=-1;
		this.isConnected=false;
		if(this.webSocket){
			console.log("User client already started.");
			return;
		}
		pms=new Promise((resolve,reject)=>{
			wsReady=resolve;
			wsError=reject;
		});
		res=await tabNT.makeCall("AAEBotNodeStartMessageClient",{bot:this.id,sessionId:this.sessionId});
		if(!res || res.code!==200){
			if(res && res.info){
				throw Error(res.info);
			}
			throw Error("Start user message client failed");
		}
		selector=res.selectCode;
		ws=new WebSocket(`ws://${document.location.host}`);
		ws.addEventListener('open',()=>{
			this.webSocket=ws;
			ws.send(JSON.stringify({msg:"CONNECT",selector:selector}));
			console.log("Bot WS connected.");
		});
		ws.addEventListener('message', (msg) => {
			let msgVO;
			msgVO=JSON.parse(msg.data);
			if(msgVO.msg==="CONNECTED"){
				this.isConnected=true;
				//Notify into chat session:
				this.chatSession.addChatText("system","Server connected.");
				wsReady();
				console.log("Bot WS Ready.");
			}else{
				let handler;
				handler="WSMSG_"+msgVO.msg;
				handler=this[handler]||ws[handler];
				if(handler){
					handler.call(this,msgVO);
				}
			}
		});
		ws.addEventListener('close', (msg) => {
			if(this.isConnected){
				this.isConnected=false;
				//Notify not connected...
				this.chatSession.addChatText("system","Connect lost, will retry connect");
				if(!this.isRetryConnect){
					this.isRetryConnect=true;
					this.retryConnect();
				}
			}
			this.webSocket=null;
			this.sessionId=null;
		});
		ws.addEventListener('error', (msg) => {
			wsError(msg);
		});
		res=await tabNT.makeCall("AAEBotGetMessages",{bot:this.id,sessionId:this.sessionId,fromTime:0,toTime:0,num:100});
		if(!res || res.code!==200){
			if(res && res.info){
				throw Error(res.info);
			}
			throw Error("Send bot message failed");
		}
		//Get current messages:
		this.nextNewMsg=null;
		msgs=this.messages;
		msgs.push(...res.messages);
		FindUnhandled:{
			this.nextNewMsg=null;
			n=msgs.length;
			for(i=0;i<n;i++){
				msg=msgs[i];
				if(msg.to===this.id){
					if(msg.handled){
						this.lastReadMsgId=msg.id;
					}else{
						this.nextNewMsg=msg;
					}
				}else{
					this.lastReadMsgId=msg.id;
				}
			}
		}

		//Wait connection ready:
		await pms;
		console.log("User client started.");
	};
	
	//------------------------------------------------------------------------
	aaHostBot.retryConnect=async function(lag){
		lag=lag||3000;
		if(lag>30000){
			lag=30000;
		}
		await sleep(lag);
		if(!this.isRetryConnect){
			return;
		}
		try{
			console.log("Will retry connect...");
			await this.startBotClient(this.chatSession);
			await this.startMessageClient();
		}catch(err){
			if(this.isRetryConnect){
				console.log("Retry connect failed, will retry later.");
				this.retryConnect(lag+500);
			}
		}
	};
	
	//------------------------------------------------------------------------
	aaHostBot.WSMSG_Message=async function(msg){
		let msgVO,callback;
		msgVO=msg.message;
		this.messages.push(msgVO);
		callback=this.waitMsgCall;
		if(callback){
			this.waitMsgCall=null;
			callback();
		}
		if(msgVO.type==="ReplyAsk"){
			callback=this.askReqs[msgVO.askReq];
			if(callback){
				callback(msgVO.result);
			}
		}
		this.emitNotify("GetMessage");
	};

	//------------------------------------------------------------------------
	aaHostBot.getNewMessage=async function(){
		let pms,msgs,msg,i,n,newMsg;
		msgs=this.messages;
		n=msgs.length;
		msg=this.nextNewMsg;
		if(msg){
			this.lastReaddMsgId=msg.id;
			msg.handled=true;
			return msg;
		}
		n=msgs.length;
		for(i=n-1;i>=0;i--){
			msg=msgs[i];
			if(!msg.handled){
				this.lastReaddMsgId=msg.id;
				msg.handled=true;
				return msg;
			}
			if(msg.id===this.lastReaddMsgId){
				msg=msgs[i+1]
				if(msg){
					this.lastReaddMsgId=msg.id;
					if(!msg.handled){
						msg.handled=true;
						return msg;
					}
				}
			}
		}
		pms=new Promise((resolve,reject)=>{
			this.waitMsgCall=resolve;
		});
		await pms;
		this.waitMsgCall=null;
		n=msgs.length;
		for(i=n-1;i>=0;i--){
			msg=msgs[i];
			if(!msg.handled){
				this.lastReaddMsgId=msg.id;
				msg.handled=true;
				return msg;
			}
			if(msg.id===this.lastReaddMsgId){
				msg=msgs[i+1]
				if(msg){
					this.lastReaddMsgId=msg.id;
					if(!msg.handled){
						msg.handled=true;
						return msg;
					}
				}
			}
		}
		return null;
	};

	//------------------------------------------------------------------------
	aaHostBot.sendMessage=async function(toBot,msgVO){
		if(toBot.from===this.id && typeof(toBot.to)==="string"){
			msgVO=toBot;
			toBot=toBot.to;
		}
		msgVO.from=this.id;
		msgVO.to=typeof(toBot)==="string"?toBot:toBot.id;
		if(this.webSocket){
			this.webSocket.send(JSON.stringify({msg:"Message","message":msgVO}));
		}else{
			this.botNode.sendMessage(this,toBot,msgVO);
		}
	};

	//------------------------------------------------------------------------
	aaHostBot.handleMessage=async function(msgId){
		let res;
		res=await tabNT.makeCall("AAEBotHandleMessage",{bot:this.id,sessionId:this.sessionId,message:msgId});
		if(!res || res.code!==200){
			if(res && res.info){
				throw Error(res.info);
			}
			throw Error("Start user message client failed");
		}
		this.nextNewMsg=null;
	};
	
	//------------------------------------------------------------------------
	aaHostBot.sendAsk=async function(to,msgVO,cbk){
		let reqId;
		reqId=""+(this.nextAskReqId++);
		this.askReqs[reqId]=cbk;
		msgVO.askReq=reqId;
		await this.sendMessage(to,msgVO);
	};
	
	//------------------------------------------------------------------------
	aaHostBot.getBotScope=async function(update){
		let nodeScope,scope,def;
		if(this.botScope && update===false){
			return this.botScope;
		}
		nodeScope=await this.botNode.getBotsScope();
		delete nodeScope[this.id];
		def=await this.getBotDef();
		if(def.bots){
			let botId;
			scope={};
			for(botId of def.bots){
				scope[botId]=nodeScope[botId];
			}
		}else{
			scope=nodeScope;
		}
		this.botScope=scope;
		return this.botScope||{};
	};
	
	//------------------------------------------------------------------------
	aaHostBot.getSkillScope=async function(update){
		let nodeScope,scope,def,saveVO;
		if(this.skillScope && update==false){
			return this.skillScope;
		}
		def=await this.getBotDef();
		try{
			if(def && def.skills){
				saveVO={skills:def.skills,chains:[],groups:[]};
			}else{
				saveVO=await (await fetch("/~/doc/SkillIndex.json")).json();
			}
		}catch(err){
			saveVO=await (await fetch("/@aae/ai/SkillIndex.json")).json();
		}
		await this.skills.loadFromVO(saveVO);
		this.skillScope=this.skills.getSkillScope();
		return this.skillScope;
	};

	//************************************************************************
	//:HostBot's task request/work APIs:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		//Request:
		//--------------------------------------------------------------------
		aaHostBot.newTaskReq=async function(toBot,prompt,chatFlow){
			let res,fromId,toId,task;
			fromId=this.id;
			toId=toBot;
			res=await tabNT.makeCall("AAETaskNewTaskReq",{from:fromId,to:toId,prompt:prompt,chatFlow:chatFlow});
			if(!res || res.code!==200){
				if(res && res.info){
					throw Error(res.info);
				}
				throw Error("New task request failed");
			}
			task=new AATaskReq(res.taskId,fromId,toId,prompt,chatFlow);
			//Add to bot:
			this.taskReqs.set(task.id,task);
			return task;
		};

		//--------------------------------------------------------------------
		aaHostBot.rejectTaskReq=async function(taskId,reason){
			let res;
			res=await tabNT.makeCall("AAETaskRejectTaskReq",{taskId:taskId,from:this.id,reason:reason});
			if(!res || res.code!==200){
				if(res && res.info){
					throw Error(res.info);
				}
				throw Error("Reject taskReq failed");
			}
			this.taskReqs.delete(taskId);
		};
		
		//--------------------------------------------------------------------
		aaHostBot.finishTaskReq=async function(taskId,result){
			/*let res;
			res=await tabNT.makeCall("AAETaskFinishTaskReq",{taskId:taskId,from:this.id,result:result});
			if(!res || res.code!==200){
				if(res && res.info){
					throw Error(res.info);
				}
				throw Error("Finish taskReq failed");
			}*/
			this.taskReqs.delete(taskId);
		};

		//--------------------------------------------------------------------
		aaHostBot.failTaskReq=async function(taskId,reason){
			let res;
			/*res=await tabNT.makeCall("AAETaskFailTaskReq",{taskId:taskId,from:this.id,reason:reason});
			if(!res || res.code!==200){
				if(res && res.info){
					throw Error(res.info);
				}
				throw Error("New task failed");
			}*/
			this.taskReqs.delete(taskId);
		};
		
		//--------------------------------------------------------------------
		aaHostBot.giveUpTaskReq=async function(taskId,reason){
			let res;
			res=await tabNT.makeCall("AAETaskGiveUpTaskReq",{taskId:taskId,from:this.id,reason:reason});
			if(!res || res.code!==200){
				if(res && res.info){
					throw Error(res.info);
				}
				throw Error("New task failed");
			}
			this.taskReqs.delete(taskId);
		};
		
		//--------------------------------------------------------------------
		//Work:
		//--------------------------------------------------------------------
		aaHostBot.acceptTaskWork=async function(taskId,fromBot,prompt,chatFlow){
			let res,fromId,toId,task;
			toId=this.id;
			fromId=fromBot;
			res=await tabNT.makeCall("AAETaskAcceptTaskWork",{taskId:taskId,from:fromId,to:toId,prompt:prompt});
			if(!res || res.code!==200){
				if(res && res.info){
					throw Error(res.info);
				}
				throw Error("New task failed");
			}
			task=new AATaskWork(res.taskId,fromId,toId,prompt,chatFlow);
			this.taskWorks.set(task.id,task);
			this.waitTaskWork=false;
			return task;
		};

		//--------------------------------------------------------------------
		aaHostBot.getNextTaskWork=async function(){
			let res,task;
			if(this.waitTaskWork){
				return null;
			}
			res=await tabNT.makeCall("AAETaskGetNextWork",{bot:this.id});
			if(!res || res.code!==200){
				if(res && res.info){
					throw Error(res.info);
				}
				throw Error("Get next workfailed");
			}
			if(res.taskId){
				task=this.taskWorks.get(res.taskId);
			}else{
				this.waitTaskWork=true;
			}
			return task||null;
		};
		
		//--------------------------------------------------------------------
		aaHostBot.rejectTaskWork=async function(taskId,reason){
			let res;
			res=await tabNT.makeCall("AAETaskRejectTaskWork",{taskId:taskId,from:this.id,reason:reason});
			if(!res || res.code!==200){
				if(res && res.info){
					throw Error(res.info);
				}
				throw Error("New task failed");
			}
		};
		
		//--------------------------------------------------------------------
		aaHostBot.startTaskWork=async function(taskId){
			let res,task;
			task=this.taskWorks.get(taskId);
			if(!task){
				throw Error(`Task ${taskId} not found.`);
			}
			await task.start();
		};
		
		//--------------------------------------------------------------------
		aaHostBot.finishTaskWork=async function(taskId,result){
			let res,task;
			task=this.taskWorks.get(taskId);
			if(!task){
				throw Error(`Task ${taskId} not found.`);
			}
			res=await tabNT.makeCall("AAETaskFinishTaskWork",{taskId:taskId,from:this.id,result:result});
			if(!res || res.code!==200){
				if(res && res.info){
					throw Error(res.info);
				}
				throw Error("New task failed");
			}
			this.taskWorks.delete(taskId);
		};

		//--------------------------------------------------------------------
		aaHostBot.failTaskWork=async function(taskId,reason){
			let res,task;
			task=this.taskWorks.get(taskId);
			if(!task){
				throw Error(`Task ${taskId} not found.`);
			}
			res=await tabNT.makeCall("AAETaskFailTaskWork",{taskId:taskId,from:this.id,reason:reason});
			if(!res || res.code!==200){
				if(res && res.info){
					throw Error(res.info);
				}
				throw Error("New task failed");
			}
			this.taskWorks.delete(taskId);
		};

		//--------------------------------------------------------------------
		aaHostBot.giveUpTaskWork=async function(taskId,reason){
			let res,task;
			task=this.taskWorks.get(taskId);
			if(!task){
				throw Error(`Task ${taskId} not found.`);
			}
			res=await tabNT.makeCall("AAETaskGiveUpTaskWork",{taskId:taskId,from:this.id,reason:reason});
			if(!res || res.code!==200){
				if(res && res.info){
					throw Error(res.info);
				}
				throw Error("New task failed");
			}
			this.taskWorks.delete(taskId);
		};
	}
}

export {AABot,AAHostBot};
