import {makeObjEventEmitter,makeNotify} from "/@events";
import {sleep} from "/@vfact";
import {tabNT,tabFS} from "/@tabos";
import {AAFarm} from "./aafarm.js";
import {AABot,AAHostBot} from "./AABot.js";
import {AATaskReq,AATaskWork} from "./AATask.js";

//****************************************************************************
//:AABotNode
//****************************************************************************
let AABotNode,aaBotNode;
{
	//------------------------------------------------------------------------
	AABotNode=function(){
		this.hostAlias=null;
		this.botsMap=new Map();
		this.taskMap=new Map();
		this.botsIndex=null;
	};
	aaBotNode=AABotNode.prototype={};
	
	//------------------------------------------------------------------------
	AABotNode.getAppBotNode=function(create=false){
		let topWin,node;
		topWin=window;
		while(topWin.parent && topWin.parent!==topWin){
			topWin=topWin.parent;
		}
		if(create){
			node=new AABotNode();
			topWin.AABotNodeInstance=node;
		}else{
			node=topWin.AABotNodeInstance;
			if(!node){
				node=new AABotNode();
				topWin.AABotNodeInstance=node;
			}
		}
		return node;
	};
	
	//------------------------------------------------------------------------
	aaBotNode.getNodeInfo=async function(){
		let info,res;
		info={
			nodeId:"",
			description:"",
			alias:""
		};
		res=await tabNT.makeCall("AAEBotNodeGetNodeInfo",{});
		if(!res || res.code!==200){
			if(res && res.info){
				throw Error(res.info);
			}
			throw Error("Get node info failed");
		}
		return res.info;
	};
	
	//------------------------------------------------------------------------
	aaBotNode.syncBots=aaBotNode.getBots=async function(){
		let res,list,bots,stub,bot,botsMap,hostAlias,botsIndex;
		hostAlias=this.hostAlias;
		if(hostAlias===null){
			hostAlias=this.hostAlias=(await AAFarm.getLocalAlias())||"";
		}
		res=await tabNT.makeCall("AAEBotNodeGetBots",{});
		if(!res || res.code!==200){
			if(res && res.info){
				throw Error(res.info);
			}
			throw Error("open");
		}
		botsIndex=this.botsIndex={};
		botsMap=this.botsMap;
		list=res.bots;
		for(stub of list){
			bot=botsMap.get(stub.id);
			if(!bot){
				if(stub.alias===hostAlias || hostAlias===""){
					bot=new AAHostBot(this,stub);
				}else{
					bot=new AABot(this,stub);
				}
				botsMap.set(stub.id,bot);
			}
			botsIndex[stub.id]=stub;
		}
		return Array.from(botsMap.values());
	};
	
	//------------------------------------------------------------------------
	aaBotNode.getBotsScope=aaBotNode.getBotsIndex=async function(){
		let indexVO,name,bots,bot;
		indexVO={};
		if(!this.botsIndex){
			await this.syncBots();
		}else{
			await this.syncBots();
		}
		bots=this.botsIndex;
		for(name in bots){
			bot=bots[name];
			if(bot.active){
				indexVO[name]=bot.description;
			}
		}
		return indexVO;
	};
	
	//------------------------------------------------------------------------
	aaBotNode.getBot=function(id){
		return this.botsMap.get(id);
	};
	
	//------------------------------------------------------------------------
	aaBotNode.getHostBot=async function(id){
		let bot;
		bot=this.getBot(id);
		if(!bot){
			console.error("startHostBot error: Can't find bot: "+id);
			return null;
		}
		if(!bot.startMessageClient){
			console.error(`startHostBot error: Bot ${id} is not a HostBot.`);
			return null;
		}
		return bot;
	};
	
	//************************************************************************
	//:Tasks:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		aaBotNode.getTask=async function(taskId){
			
		};
	}
}

export {AABotNode};
