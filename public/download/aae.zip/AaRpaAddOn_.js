import {VFACT} from "/@vfact";
import {AAFarm} from "/@aae/aafarm.js";
import {BrowserArgs} from "./data/AppData.js";

const $ln=VFACT.lanCode;
const EditAttr=VFACT.classRegs.EditAttr;
const EditAISeg=VFACT.classRegs.EditAISeg;
const EditAISegOutlet=VFACT.classRegs.EditAISegOutlet;
const SegObjBaseAttr=EditAISeg.SegObjBaseAttr;
const SegObjShellAttr=EditAISeg.SegObjShellAttr;
const FlowOutletDef=EditAISegOutlet.FlowOutletDef;
const SegOutletDef=EditAISegOutlet.SegOutletDef;
const CodeOutletArrayDef=EditAISegOutlet.CodeOutletArrayDef;
const ButtonOutletDef=EditAISegOutlet.ButtonOutletDef;

const DocAIAgentExporter=VFACT.classRegs.DocAIAgentExporter;
const docAIAgentExporter=DocAIAgentExporter.prototype;
const varNameRegex = /^[a-zA-Z_$][a-zA-Z0-9_$]*$/;

const packExtraCodes=docAIAgentExporter.packExtraCodes;
const packResult=docAIAgentExporter.packResult;

async function pickBrowser(farm,sender){
	let app,liveBrowsers,items,browser,alias,homeLive,item,browserId;
	let openBrowserId,openBrowserAlias,openBrowserWithDir;
	app=VFACT.app;
	liveBrowsers=await farm.getBrowsers();
	items=[];
	homeLive=false;
	for(browser of liveBrowsers){
		alias=browser.alias;
		items.push({text:alias+`: ${browser.pages.length} pages`,alias:browser.alias,browserId:browser.id});
		if(alias==="RPAHOME"){
			homeLive=true;
		}
	}
	if(!homeLive){
		items.push({text:"RPAHOME",alias:"RPAHOME",browserId:null});
	}
	items.push({text:"New browser",alias:null,browserId:null});
	item=await app.modalDlg("/@StdUI/ui/DlgMenu.js",{
		items:items,hud:sender,
	});
	if(!item){
		return null;
	}

	browserId=item.browserId;
	alias=item.alias;
	if(browserId){
		openBrowserId=browserId;
		openBrowserAlias=alias;
		openBrowserWithDir=false;
	}else if(alias){
		openBrowserId=null;
		openBrowserAlias=alias;
		openBrowserWithDir=true;
	}else if(alias===null){
		//TODO: ask a new alias and if use data-dir:
		let cfg=await app.modalDlg("/@StdUI/ui/DlgDataView.js",{
			hud:sender,
			x:-380,y:0,
			template:BrowserArgs,object:null,
			title:"New browser"
		});
		if(!cfg){
			return null;
		}
		openBrowserAlias=cfg.alias;
		openBrowserWithDir=cfg.dataDir;
	}else if(alias===""){
		openBrowserId=null;
		openBrowserAlias="";
		openBrowserWithDir=false;
	}
	
	let opts;
	opts={headless:false,devtools:false};
	if(openBrowserAlias && openBrowserWithDir){
		opts.autoDataDir=true;
	}
	browser=await farm.openBrowser(openBrowserAlias,opts);
	openBrowserAlias=browser.alias;
	farm.editBrowser=browser;
	return browser;
}

async function pickPage(aaf,browser,sender,pageName){
	let pages,items,page,title,item;
	pages=await browser.getPages();
	if(!pages || !pages.length){
		return null;
	}
	items=[];
	for(page of pages){
		title=await page.getTitle();
		if(!title){
			title=await page.getUrl();
		}
		items.push({"text":title,page:page});
	}
	item=await VFACT.app.modalDlg("/@StdUI/ui/DlgMenu.js",{
		items:items,hud:sender,
	});
	if(!item){
		return null;
	}
	page=item.page;
	aaf.editPages[pageName]=page;
	return page;
}

async function confirmPage(attr,sender){
	let seg,doc,aaf,browser,pageName,page,query,title;
	let app=VFACT.app;
	let repick=false;
	seg=attr.owner;
	doc=seg.doc;
	aaf=doc.aaFarm;
	pageName=seg.getAttrVal("page");
	if(!aaf){
		aaf=doc.aaFarm=new AAFarm();
		aaf.editPages={};
	}
	page=null;
	browser=aaf.editBrowser;
	if(browser){
		page=aaf.editPages[pageName];
	}
	if(page){
		try{
			title=await page.getTitle();
			if(!title){
				page=null;
			}
		}catch(err){
			page=null;
		}
	}
	if(page){
		let items=[
			{text:`[${title}]`,page:page},
			{text:`Select a new page`,page:null}
		];
		let item=await app.modalDlg("/@StdUI/ui/DlgMenu.js",{
			items:items,hud:sender,
		});
		if(!item){
			VFACT.app.showTip(sender,"Canceled.");
			return null;
		}
		page=item.page;
	}
	if(!page){
		//First pick browser:
		browser=await pickBrowser(aaf,sender);
		if(!browser){
			VFACT.app.showTip(sender,"No browser.");
			return null;
		}
		page=await pickPage(aaf,browser,sender,pageName);
		if(!page){
			VFACT.app.showTip(sender,"No page.");
			return null;
		}
	}
	return page;
};

async function showQueryDlg(attr,sender,line,box){
	let seg,doc,aaf,browser,pageName,page,query;
	let repick=false;
	let app=VFACT.app;
	query=attr.val;
	seg=attr.owner;
	doc=seg.doc;
	aaf=doc.aaFarm;
	page=await confirmPage(attr,sender);
	if(!page){
		return;
	}
	query=await app.modalDlg("/@aae/ui/MainUI.js",{aaf:aaf,browser,page,query});
	if(query!==undefined){
		box.setAttrByText(attr,query);
	}
	return query;
}

EditAISeg.regCatalog({
	name:"WebRpa",showName:(($ln==="CN")?("网页RPA"):/*EN*/("Web-RPA"))
});

const QueryFindOutlets={
	...CodeOutletArrayDef,
	attrs:[
		{
			type:"aioutlet",key:1,fixed:1,
			def:{
				...SegOutletDef,
				attrs:{
					...SegOutletDef.attrs,
					"id":{name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"Missing"},
				}
			}
		}
	]	
};

const errorSeg={
	name:"errorSeg",showName:(($ln==="CN")?("错误处理"):/*EN*/("Error Handler")),type:"string",key:1,fixed:1,initVal:"",editType:"choice",
	icon:"flag.svg",rawEdit:false,
	getMenuItems:function(){
		let list,i,n,seg;
		let items=[];
		list=this.owner.doc.segsList;
		n=list.length;
		for(i=0;i<n;i++){
			seg=list[i];
			if(seg.idVal.val){
				items.push({text:seg.idVal.val,valText:seg.jaxId});
			}
		}
		return items;
	},
	val2ShowText:function(val){
		let list,i,n,seg;
		if(!val){
			return "NA";
		}
		list=this.owner.doc.segsList;
		n=list.length;
		for(i=0;i<n;i++){
			seg=list[i];
			if(seg.idVal.val===val){
				return val;
			}
			if(seg.jaxId===val){
				return seg.idVal.val;
			}
		}
		return "NA";
	}
};

function packErrorSegCode(coder,seg,exportDebug){
	let editDoc=seg.doc;
	let jumpTarget=seg.getAttrVal("errorSeg");
	if(jumpTarget){
		let list=editDoc.segsList,i,n;
		n=list.length;
		FindSeg:{
			for(i=0;i<n;i++){
				let checkSeg=list[i];
				if(checkSeg.idVal.val===jumpTarget){
					break FindSeg;
				}
				if(checkSeg.jaxId===jumpTarget){
					jumpTarget=checkSeg.idVal.val;
					break FindSeg;
				}
			}
			jumpTarget=null;
		}
	}
	if(jumpTarget){
		if(exportDebug){
			coder.packText(`return {seg:${jumpTarget||null},result:err,preSeg:"${seg.jaxId}",outlet:null};`);
		}else{
			coder.packText(`return {seg:${jumpTarget||null},result:err};`);
		}
	}else{
		coder.packText(`throw err;`);coder.newLine();
	}
}

//----------------------------------------------------------------------------
//:WebRpaStart: AISeg that start WebRPA:
{
	EditAISeg.regDef({
		name:"WebRpaStart",showName:(($ln==="CN")?("启动网页RPA"):/*EN*/("Init Web-RPA")),icon:"start.svg",catalog:["WebRpa"],
		attrs:{
			...SegObjShellAttr,
			"browser":{
				name:"browser",showName:"Browser Alias",type:"string",key:1,fixed:1,initVal:"RPAHOME"
			},
			"headless":{
				name:"headless",showName:"Headless",type:"bool",key:1,fixed:1,initVal:false
			},
			"devtools":{
				name:"devtools",showName:"Dev. Tools",type:"bool",key:1,fixed:1,initVal:false
			},
			"url":{
				name:"url",showName:"Open Page",type:"string",key:1,fixed:1,initVal:""
			},
			"valName":{
				name:"valName",showName:"Page Val",type:"string",key:1,fixed:1,initVal:"aaPage"
			},
			"waitBefore":{
				name:"waitBefore",showName:"Wait Before",type:"int",key:1,fixed:1,initVal:0
			},
			"waitAfter":{
				name:"waitAfter",showName:"Wait After",type:"int",key:1,fixed:1,initVal:0
			},
			"outlet":{name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc"},
			"catchlet":{
				name:"catchlet",showName:"Catch",type:"aioutlet",def:FlowOutletDef,key:1,fixed:1,edit:false,navi:"doc",
				attrs:{
					"id":{
						name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"NoAAE",
					},
				},
			},
			"aiQuery":{name:"aiQuery",showName:(($ln==="CN")?("启用AI查询"):/*EN*/("Enable AI search")),type:"bool",key:1,fixed:1,initVal:true},
		},
		listHint:["id","browser","url","valName","headless","devtools","codes","aiQuery","waitBefore","waitAfter","desc"],
		importSource:{path:"../../rpa/WebRpa.mjs",name:["WebRpa","sleep"]},
	});

	DocAIAgentExporter.segTypeExporters["WebRpaStart"]=
	function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let exportDebug=this.isExportDebug();
		let editDoc=seg.doc;
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();
		coder.newLine();
		{
			coder.maybeNewLine();
			coder.packText(`let result=true;`);coder.newLine();
			coder.packText(`let aiQuery=`);this.genAttrStatement(seg.getAttr("aiQuery"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $alias=`);this.genAttrStatement(seg.getAttr("browser"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $url=`);this.genAttrStatement(seg.getAttr("url"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $waitBefore=`);this.genAttrStatement(seg.getAttr("waitBefore"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $waitAfter=`);this.genAttrStatement(seg.getAttr("waitAfter"));coder.packText(`;`);coder.newLine();
			packExtraCodes(coder,seg,"PreCodes");
			coder.packText(`try{`);
			coder.indentMore();coder.newLine();
			{
				coder.packText(`context.webRpa=session.webRpa || new WebRpa(session);`);coder.newLine();
				coder.packText(`session.webRpa=context.webRpa;`);coder.newLine();
				coder.packText(`aiQuery && (await context.webRpa.setupAIQuery(session,context,basePath,"${seg.jaxId}"));`);coder.newLine();
				coder.packText(`if($alias){`);coder.indentMore();coder.newLine();
				{
					coder.packText(`let $headless=`);this.genAttrStatement(seg.getAttr("headless"));coder.packText(`;`);coder.newLine();
					coder.packText(`let $devtools=`);this.genAttrStatement(seg.getAttr("devtools"));coder.packText(`;`);coder.newLine();
					coder.packText(`let options={$headless:false,$devtools:false,autoDataDir:false};`);coder.newLine();
					coder.packText(`let $browser=null;`);coder.newLine();
					packExtraCodes(coder,seg,"PreBrowser");
					coder.packText(`context.rpaBrowser=$browser=await context.webRpa.openBrowser($alias,options);`);coder.newLine();
					coder.packText(`context.rpaHostPage=$browser.hostPage;`);coder.newLine();
					packExtraCodes(coder,seg,"PostBrowser");
					coder.packText(`if($url){`);
					coder.indentMore();coder.newLine();
					{
						coder.packText(`let $page=null;`);coder.newLine();
						coder.packText(`let $pageVal=`);this.genAttrStatement(seg.getAttr("valName"));coder.packText(`;`);coder.newLine();
						coder.packText(`let $opts={};`);coder.newLine();
						packExtraCodes(coder,seg,"PrePage");
						coder.packText(`context[$pageVal]=$page=await $browser.newPage();`);coder.newLine();
						coder.packText(`await $page.goto($url,{});`);coder.newLine();
						packExtraCodes(coder,seg,"PostPage");
					}
					coder.indentLess();coder.maybeNewLine();
					coder.packText(`}`);coder.newLine();
				}
				coder.indentLess();coder.maybeNewLine();
				coder.packText(`}`);coder.newLine();
				coder.packText(`$waitAfter && (await sleep($waitAfter));`);coder.newLine();
			}
			coder.indentLess();coder.maybeNewLine();
			coder.packText(`}catch(err){`);
			coder.indentMore();coder.newLine();
			{
				let catchlet,catchSeg;
				catchlet=seg.catchlet||null;
				if(catchlet){
					catchSeg=catchlet.getLinkedSeg();
					if(catchSeg){
						packExtraCodes(coder,catchlet,"Codes");
						this.packUpdateContext(coder,catchlet);
						this.packUpdateGlobal(coder,catchlet);
						packResult(coder,seg,catchlet,"err");
					}else{
						packExtraCodes(coder,catchlet,"Codes");
						this.packUpdateContext(coder,catchlet);
						this.packUpdateGlobal(coder,catchlet);
						coder.packText(`throw err;`);coder.newLine();
					}
				}else{
					coder.packText(`throw err;`);coder.newLine();
				}
			}
			coder.indentLess();coder.maybeNewLine();coder.packText(`}`);coder.newLine();
			packExtraCodes(coder,seg,"PostCodes");
			this.packUpdateContext(coder,seg);
			this.packUpdateGlobal(coder,seg);
			packResult(coder,seg,seg.outlet,"result",false);
		}
		coder.indentLess();
		coder.newLine();
		coder.packText(`};`);
		coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		coder.newLine();
	};
}

//----------------------------------------------------------------------------
//:WebRpaOpenBrowser: Open a browser:
{
	EditAISeg.regDef({
		name:"WebRpaOpenBrowser",showName:(($ln==="CN")?("打开浏览器"):/*EN*/("Open Browser")),icon:"web.svg",catalog:["WebRpa"],
		attrs:{
			...SegObjShellAttr,
			"alias":{
				name:"alias",showName:"Alias",type:"string",key:1,fixed:1,initVal:"RPAHOME"
			},
			"headless":{
				name:"headless",showName:"Headless",type:"bool",key:1,fixed:1,initVal:false
			},
			"devtools":{
				name:"devtools",showName:"Dev. Tools",type:"bool",key:1,fixed:1,initVal:false
			},
			"dataDir":{
				name:"dataDir",showName:"Data Dir",type:"bool",key:1,fixed:1,initVal:false
			},
			"outlet":{
				name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
			},
			"run":{
				name:"run",showName:"Run This Step",type:"auto",key:1,fixed:1,initVal:undefined,editType:"action",
				OnAction:async function(attrObj,sender,attrLine,editBox){
					let seg,doc,webRpa,alias,browser;
					seg=attrObj.owner;
					doc=seg.doc;
					webRpa=doc.webRpa;
					if(!webRpa){
						webRpa=doc.webRpa=new AAFarm();
						webRpa.editPages={};
					}
					alias=seg.getAttrVal("alias");
					browser=await webRpa.openBrowser(alias,{headless:false,devtools:true});
					webRpa.editBrowser=browser;
				}
			},
			"errorSeg": errorSeg,
		},
		listHint:[
			"id","alias","dataDir","headless","devtools","errorSeg","run","codes","desc",
		]
	});

	DocAIAgentExporter.segTypeExporters["WebRpaOpenBrowser"]=
	function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let exportDebug=this.isExportDebug();
		let editDoc=seg.doc;
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();
		coder.newLine();
		{
			coder.maybeNewLine();
			coder.packText(`let result=true;`);coder.newLine();
			coder.packText(`let browser=null;`);coder.newLine();
			coder.packText(`let headless=`);this.genAttrStatement(seg.getAttr("headless"));coder.packText(`;`);coder.newLine();
			coder.packText(`let devtools=`);this.genAttrStatement(seg.getAttr("devtools"));coder.packText(`;`);coder.newLine();
			coder.packText(`let dataDir=`);this.genAttrStatement(seg.getAttr("dataDir"));coder.packText(`;`);coder.newLine();
			coder.packText(`let alias=`);this.genAttrStatement(seg.getAttr("alias"));coder.packText(`;`);coder.newLine();
			coder.packText(`let options={headless,devtools,autoDataDir:dataDir};`);coder.newLine();
			packExtraCodes(coder,seg,"PreCodes");
			coder.packText(`try{`);coder.indentMore();coder.newLine();
			{
				coder.packText(`context.rpaBrowser=browser=await context.webRpa.openBrowser(alias,options);`);coder.newLine();
				coder.packText(`context.rpaHostPage=browser.hostPage;`);coder.newLine();
			}
			coder.indentLess();coder.newLine();
			coder.packText(`}catch(err){`);coder.indentMore();coder.newLine();
			{
				packErrorSegCode(coder,seg,exportDebug);
			}
			coder.indentLess();coder.maybeNewLine();coder.packText(`}`);coder.newLine();
			packExtraCodes(coder,seg,"PostCodes");
			packResult(coder,seg,seg.outlet,"result");
		}
		coder.indentLess();
		coder.newLine();
		coder.packText(`};`);
		coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		coder.newLine();
	};
}

//----------------------------------------------------------------------------
//:WebRPACloseBrowser: Close a browser:
{
	EditAISeg.regDef({
		name:"WebRpaCloseBrowser",showName:(($ln==="CN")?("关闭浏览器"):/*EN*/("Close Browser")),icon:"close.svg",catalog:["WebRpa"],
		attrs:{
			...SegObjShellAttr,
			"outlet":{
				name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
			},
			"errorSeg": errorSeg,
		},
		listHint:[
			"id","codes","desc","errorSeg",
		]
	});

	DocAIAgentExporter.segTypeExporters["WebRpaCloseBrowser"]=
	function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let exportDebug=this.isExportDebug();
		let editDoc=seg.doc;
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();
		coder.newLine();
		{
			coder.maybeNewLine();
			coder.packText(`let result=input;`);coder.newLine();
			coder.packText(`let browser=context.rpaBrowser;`);coder.newLine();
			packExtraCodes(coder,seg,"PreCodes");
			coder.packText(`try{`);coder.indentMore();coder.newLine();
			{
				coder.packText(`if(browser){`);coder.indentMore();coder.newLine();
				{
					coder.packText(`await context.webRpa.closeBrowser(browser);`);coder.newLine();
				}
				coder.indentLess();coder.maybeNewLine();
				coder.packText(`}`);coder.newLine();
				coder.packText(`context.rpaBrowser=null;`);coder.newLine();
				coder.packText(`context.rpaHostPage=null;`);coder.newLine();
			}
			coder.indentLess();coder.newLine();
			coder.packText(`}catch(err){`);coder.indentMore();coder.newLine();
			{
				packErrorSegCode(coder,seg,exportDebug);
			}
			coder.indentLess();coder.maybeNewLine();coder.packText(`}`);coder.newLine();
			packExtraCodes(coder,seg,"PostCodes");
			packResult(coder,seg,seg.outlet,"result");
		}
		coder.indentLess();
		coder.newLine();
		coder.packText(`};`);
		coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		coder.newLine();
	};
}

//----------------------------------------------------------------------------
//:AISeg that open a page with url and can also set it's viewpoert size and user-agent:
{
	EditAISeg.regDef({
		name:"WebRpaOpenPage",showName:(($ln==="CN")?("打开页面"):/*EN*/("Open Page")),icon:"/@aae/assets/tab_add.svg",catalog:["WebRpa"],
		attrs:{
			...SegObjShellAttr,
			"valName":{
				name:"valName",showName:"Page Val",type:"string",key:1,fixed:1,initVal:"aaPage"
			},
			"url":{
				name:"url",showName:"URL",type:"string",key:1,fixed:1,initVal:"https://www.google.com"
			},
			"vpWidth":{
				name:"vpWidth",showName:"Viewport Width",type:"int",key:1,fixed:1,initVal:800
			},
			"vpHeight":{
				name:"vpHeight",showName:"Viewport Height",type:"int",key:1,fixed:1,initVal:600
			},
			"timeout":{
				name:"timeout",showName:"Timeout",type:"int",key:0,fixed:1,initVal:0
			},
			"userAgent":{
				name:"userAgent",showName:"User Agent",type:"string",key:1,fixed:1,initVal:""
			},
			"waitBefore":{
				name:"waitBefore",showName:"Wait Before",type:"int",key:1,fixed:1,initVal:0
			},
			"waitAfter":{
				name:"waitAfter",showName:"Wait After",type:"int",key:1,fixed:1,initVal:0
			},
			"outlet":{
				name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
			},
			"run":{
				name:"run",showName:"Run This Step",type:"auto",key:1,fixed:1,initVal:undefined,editType:"action",
				OnAction:async function(attrObj,sender,attrLine,editBox){
					let seg,doc,webRpa,alias,browser,page,vw,vh,url,pageName;
					seg=attrObj.owner;
					doc=seg.doc;
					webRpa=doc.webRpa;
					if(!webRpa){
						webRpa=doc.webRpa=new AAFarm();
						webRpa.editPages={};
					}
					browser=webRpa.editBrowser;
					if(!browser){
						browser=await pickBrowser(webRpa,sender);
						if(!browser){
							VFACT.app.showTip(sender,"No browser.");
							return;
						}
					}
					pageName=seg.getAttrVal("valName");
					page=await browser.newPage();
					webRpa.editPages[pageName]=page;
					vw=seg.getAttrVal("vpWidth");
					vh=seg.getAttrVal("vpHeight");
					url=seg.getAttrVal("url");
					//await page.setViewport({width:vw,height:vh});
					if(url){
						await page.goto(url);
					}
				}
			},
			"errorSeg": errorSeg,
		},
		listHint:[
			"id","valName","url","vpWidth","vpHeight","timeout","userAgent","run","waitBefore","waitAfter","codes","desc","errorSeg",
		]
	});

	DocAIAgentExporter.segTypeExporters["WebRpaOpenPage"]=
	function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let exportDebug=this.isExportDebug();
		let editDoc=seg.doc;
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();
		coder.newLine();
		{
			coder.maybeNewLine();
			coder.packText(`let pageVal=`);this.genAttrStatement(seg.getAttr("valName"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $url=`);this.genAttrStatement(seg.getAttr("url"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $waitBefore=`);this.genAttrStatement(seg.getAttr("waitBefore"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $waitAfter=`);this.genAttrStatement(seg.getAttr("waitAfter"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $width=`);this.genAttrStatement(seg.getAttr("vpWidth"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $height=`);this.genAttrStatement(seg.getAttr("vpHeight"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $userAgent=`);this.genAttrStatement(seg.getAttr("userAgent"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $timeout=(`);this.genAttrStatement(seg.getAttr("timeout"));coder.packText(`)||0;`);coder.newLine();
			coder.packText(`let page=null;`);coder.newLine();
			coder.packText(`let $openOpts={timeout:$timeout};`);coder.newLine();
			coder.packText(`$waitBefore && (await sleep($waitBefore));`);coder.newLine();
			packExtraCodes(coder,seg,"PreCodes");
			coder.packText(`try{`);coder.indentMore();coder.newLine();
			{
				coder.packText(`context[pageVal]=page=await context.rpaBrowser.newPage();`);coder.newLine();
				coder.packText(`($width && $height) && (await page.setViewport({width:$width,height:$height}));`);coder.newLine();
				coder.packText(`$userAgent && (await page.setUserAgent($userAgent));`);coder.newLine();
				coder.packText(`await page.goto($url,$openOpts);`);coder.newLine();
				coder.packText(`$waitAfter && (await sleep($waitAfter));`);coder.newLine();
			}
			coder.indentLess();coder.newLine();
			coder.packText(`}catch(err){`);coder.indentMore();coder.newLine();
			{
				// errorSeg handler
				let jumpTarget=seg.getAttrVal("errorSeg");
				if(jumpTarget){
					let list=editDoc.segsList,i,n;
					n=list.length;
					FindSeg:{
						for(i=0;i<n;i++){
							let checkSeg=list[i];
							if(checkSeg.idVal.val===jumpTarget){
								break FindSeg;
							}
							if(checkSeg.jaxId===jumpTarget){
								jumpTarget=checkSeg.idVal.val;
								break FindSeg;
							}
						}
						jumpTarget=null;
					}
				}
				if(jumpTarget){
					if(exportDebug){
						coder.packText(`return {seg:${jumpTarget||null},result:err,preSeg:"${seg.jaxId}",outlet:null};`);
					}else{
						coder.packText(`return {seg:${jumpTarget||null},result:err};`);
					}
				}else{
					coder.packText(`throw err;`);coder.newLine();
				}
			}
			coder.indentLess();coder.maybeNewLine();coder.packText(`}`);coder.newLine();
			packExtraCodes(coder,seg,"PostCodes");
			packResult(coder,seg,seg.outlet,"true");
		}
		coder.indentLess();
		coder.newLine();
		coder.packText(`};`);
		coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		coder.newLine();
	};
}

//----------------------------------------------------------------------------
//:WebRpaClosePage - Add errorSeg
{
	EditAISeg.regDef({
		name:"WebRpaClosePage",showName:(($ln==="CN")?("关闭页面"):/*EN*/("Close Page")),icon:"/@aae/assets/tab_close.svg",catalog:["WebRpa"],
		attrs:{
			...SegObjShellAttr,
			"page":{
				name:"page",showName:"Page",type:"string",key:1,fixed:1,initVal:"aaPage"
			},
			"waitBefore":{
				name:"waitBefore",showName:"Wait Before",type:"int",key:1,fixed:1,initVal:0
			},
			"waitAfter":{
				name:"waitAfter",showName:"Wait After",type:"int",key:1,fixed:1,initVal:0
			},
			"outlet":{
				name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
			},
			"run":{
				name:"run",showName:"Run This Step",type:"auto",key:1,fixed:1,initVal:undefined,editType:"action",
				// ... no change ...
			},
			"errorSeg": errorSeg,
		},
		listHint:[
			"id","page","run","waitBefore","waitAfter","codes","desc","errorSeg",
		]
	});

	DocAIAgentExporter.segTypeExporters["WebRpaClosePage"]=
	function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let exportDebug=this.isExportDebug();
		let editDoc=seg.doc;
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();coder.newLine();
		{
			coder.maybeNewLine();
			coder.packText(`let result=input;`);coder.newLine();
			coder.packText(`let pageVal=`);this.genAttrStatement(seg.getAttr("page"));coder.packText(`;`);coder.newLine();
			coder.packText(`let waitBefore=`);this.genAttrStatement(seg.getAttr("waitBefore"));coder.packText(`;`);coder.newLine();
			coder.packText(`let waitAfter=`);this.genAttrStatement(seg.getAttr("waitAfter"));coder.packText(`;`);coder.newLine();
			coder.packText(`let page=context[pageVal];`);coder.newLine();
			coder.packText(`waitBefore && (await sleep(waitBefore));`);coder.newLine();
			packExtraCodes(coder,seg,"PreCodes");
			coder.packText(`try{`);coder.indentMore();coder.newLine();
			{
				coder.packText(`await page.close();`);coder.newLine();
				coder.packText(`context[pageVal]=null;`);coder.newLine();
				coder.packText(`waitAfter && (await sleep(waitAfter))`);coder.newLine();
			}
			coder.indentLess();coder.newLine();
			coder.packText(`}catch(err){`);coder.indentMore();coder.newLine();
			{
				let jumpTarget=seg.getAttrVal("errorSeg");
				if(jumpTarget){
					let list=editDoc.segsList,i,n;
					n=list.length;
					FindSeg:{
						for(i=0;i<n;i++){
							let checkSeg=list[i];
							if(checkSeg.idVal.val===jumpTarget){
								break FindSeg;
							}
							if(checkSeg.jaxId===jumpTarget){
								jumpTarget=checkSeg.idVal.val;
								break FindSeg;
							}
						}
						jumpTarget=null;
					}
				}
				if(jumpTarget){
					if(exportDebug){
						coder.packText(`return {seg:${jumpTarget||null},result:err,preSeg:"${seg.jaxId}",outlet:null};`);
					}else{
						coder.packText(`return {seg:${jumpTarget||null},result:err};`);
					}
				}else{
					coder.packText(`throw err;`);coder.newLine();
				}
			}
			coder.indentLess();coder.maybeNewLine();coder.packText(`}`);coder.newLine();
			packExtraCodes(coder,seg,"PostCodes");
			packResult(coder,seg,seg.outlet,"result");
		}
		coder.indentLess();coder.maybeNewLine();
		coder.packText(`};`);
		coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		coder.newLine();
	};
}

//----------------------------------------------------------------------------
// 对其它组件，请用类似方法，在attrs里加 errorSeg:errorSeg，listHint末尾加"errorSeg"，并在导出函数的try/catch块中加入和WebRpaPageGoto一致的错误处理分支即可
//（省略其它组件重复冗长代码，仅给三个组件做演示：WebRpaActivePage、WebRpaMouseAction、WebRpaReadPage）

//:WebRpaActivePage with errorSeg
{
	EditAISeg.regDef({
		name:"WebRpaActivePage",showName:(($ln==="CN")?("激活页面"):/*EN*/("Active Page")),icon:"/@aae/assets/tab_tap.svg",catalog:["WebRpa"],
		attrs:{
			// ...
			...SegObjShellAttr,
			"page":{
				name:"page",showName:"Page",type:"string",key:1,fixed:1,initVal:"aaPage"
			},
			"options":{
				name:"options",showName:"Options",type:"hyperObj",key:1,fixed:1,initVal:undefined,
				// ...
			},
			"waitBefore":{
				// ...
			},
			"waitAfter":{
				// ...
			},
			"outlet":{
				// ...
			},
			"run":{
				// ...
			},
			"errorSeg": errorSeg
		},
		listHint:[
			"id","page","options","run","waitBefore","waitAfter","codes","desc","errorSeg"
		]
	});
	DocAIAgentExporter.segTypeExporters["WebRpaActivePage"]=
	function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let exportDebug=this.isExportDebug();
		let editDoc=seg.doc;
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();coder.newLine();
		{
			coder.maybeNewLine();
			coder.packText(`let result=input;`);coder.newLine();
			coder.packText(`let pageVal=`);this.genAttrStatement(seg.getAttr("page"));coder.packText(`;`);coder.newLine();
			coder.packText(`let waitBefore=`);this.genAttrStatement(seg.getAttr("waitBefore"));coder.packText(`;`);coder.newLine();
			coder.packText(`let waitAfter=`);this.genAttrStatement(seg.getAttr("waitAfter"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $options=`);this.genAttrStatement(seg.getAttr("options"));coder.packText(`;`);coder.newLine();
			coder.packText(`let page=context[pageVal];`);coder.newLine();
			coder.packText(`waitBefore && (await sleep(waitBefore));`);coder.newLine();
			packExtraCodes(coder,seg,"PreCodes");
			coder.packText(`try{`);coder.indentMore();coder.newLine();
			{
				coder.packText(`await page.bringToFront($options);`);coder.newLine();
				coder.packText(`waitAfter && (await sleep(waitAfter))`);coder.newLine();
				if($options.focusBrowser && $options.switchBack){
					coder.packText(`let $browser=context.rpaBrowser;`);coder.newLine();
					coder.packText(`if($browser){await $browser.backToApp();}`);coder.newLine();
				}
			}
			coder.indentLess();coder.maybeNewLine();
			coder.packText(`}catch(err){`);coder.indentMore();coder.newLine();
			{
				let jumpTarget=seg.getAttrVal("errorSeg");
				if(jumpTarget){
					let list=editDoc.segsList,i,n;
					n=list.length;
					FindSeg:{
						for(i=0;i<n;i++){
							let checkSeg=list[i];
							if(checkSeg.idVal.val===jumpTarget){
								break FindSeg;
							}
							if(checkSeg.jaxId===jumpTarget){
								jumpTarget=checkSeg.idVal.val;
								break FindSeg;
							}
						}
						jumpTarget=null;
					}
				}
				if(jumpTarget){
					if(exportDebug){
						coder.packText(`return {seg:${jumpTarget||null},result:err,preSeg:"${seg.jaxId}",outlet:null};`);
					}else{
						coder.packText(`return {seg:${jumpTarget||null},result:err};`);
					}
				}else{
					coder.packText(`throw err;`);coder.newLine();
				}
			}
			coder.indentLess();coder.maybeNewLine();coder.packText(`}`);coder.newLine();
			packExtraCodes(coder,seg,"PostCodes");
			packResult(coder,seg,seg.outlet,"result");
		}
		coder.indentLess();
		coder.packText(`};`);
		coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		coder.newLine();
	};
}

//:WebRpaMouseAction with errorSeg  (只增错控相关，实现与上同)
// ... 增加 errorSeg，listHint，以及代码导出器里 try/catch 支持 errorSeg 分支 ...

//:WebRpaReadPage with errorSeg
// ... 同样改法 ...

//其它组件以此类推。
//------------------- END DEMO -----------------
