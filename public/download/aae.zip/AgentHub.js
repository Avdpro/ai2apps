import {VFACT,sleep} from "/@vfact";
import {tabNT,tabFS} from "/@tabos";
import {makeObjEventEmitter,makeNotify} from "/@events";

//****************************************************************************
//AgentNode
//****************************************************************************
let AgentNode,agentNode;
{
	//------------------------------------------------------------------------
	AgentNode=function(hub,state){
		this.hub=hub;
		this.state=state;
		this.name=state.name;
		this.description=state.description;
		this.external=state.external;
		this.active=state.active;
		this.workload=state.workload;
	};
	agentNode=AgentNode.prototype={};
	
	//------------------------------------------------------------------------
	agentNode.refresh=agentNode.updateState=async function(){
		let res;
		res=await tabNT.makeCall("AhNodeState",{name:this.name});
		if(res && res.code===200){
			let state;
			state=res.state;
			this.state=state;
			this.external=state.external;
			this.description=state.description;
			this.active=state.active;
			this.workload=state.workload;
		}else if(res && res.code===404){//Node stoped and removed.
			this.active=false;
			this.external=true;
			this.workload=undefined;
		}
	};
	
	//------------------------------------------------------------------------
	agentNode.startNode=async function(opts){
		let res;
		res=await tabNT.makeCall("StartAgentNode",{name:this.name,options:opts});
		if(res && res.code===200){
			return true;
		}
		return false;
	};

	//------------------------------------------------------------------------
	agentNode.stopNode=async function(){
		let res;
		res=await tabNT.makeCall("StopAgentNode",{name:this.name});
		if(res && res.code===200){
			return true;
		}
		return false;
	};

	//------------------------------------------------------------------------
	agentNode.startChat=async function(app){
		let meta,icon;
		meta=this.hub.chatAppMeta;
		if(!meta){
			icon="/~/-tabos/shared/assets/aalogo.svg";
			meta={
				type:"app",
				name:"Chat with Agent Node",
				caption:"Chat with Agent Node",
				icon:icon,
				appFrame:{
					group:"AgentNodeChat",caption:"Chat with Agent Node",openApp:true,multiInstance:false,
					icon:icon,width:600,height:600,
				}
			};
			this.hub.chatAppMeta=meta;
		}
		meta.appFrame.main=`/@aichat/app.html?chat=${encodeURIComponent("/@aichat/ai/RemoteChat.js")}&style=pro`;
		app.openAppMeta(meta,{file:"/@aichat/ai/RemoteChat.js",argument:{nodeName:this.name,callAgent:this.state.chatEntry,checkUpdate:false}},{});
	};
}

//****************************************************************************
//AgentNode
//****************************************************************************
let AgentHub,agentHub;
{
	//------------------------------------------------------------------------
	AgentHub=function(){
		this.nodes=null;
		this.nodeList=null;
		this.config=null;
		this.blockedNodes=new Set();
	};
	agentHub=AgentHub.prototype={};

	//------------------------------------------------------------------------
	agentHub.getNodes=async function(reload=false){
		let res,nodes,nodeList,node;
		if(this.nodes && !reload){
			return this.nodes;
		}
		
		nodes=this.nodes={};
		nodeList=this.nodeList=[];
		res=await tabNT.makeCall("AhListAgentNodes",{});
		if(res && res.code===200){
			let list,def;
			list=res.nodes;
			for(def of list){
				node=new AgentNode(this,def);
				nodes[node.name]=node;
				nodeList.push(node);
			}
			return nodes;
		}
		return null;
	};

	//------------------------------------------------------------------------
	agentHub.getNodeList=async function(reload=false){
		let nodes=await this.getNodes(reload);
		if(nodes){
			return this.nodeList;
		}
		return null;
	};
}

export {AgentHub,AgentNode}