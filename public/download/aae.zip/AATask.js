import {makeObjEventEmitter,makeNotify} from "/@events";
import {sleep} from "/@vfact";
import {tabNT,tabFS} from "/@tabos";

//****************************************************************************
//:AATaskReq
//****************************************************************************
let AATaskReq,aaTaskReq;
{
	//-----------------------------------------------------------------------
	AATaskReq=function(taskId,fromBot,hostBot,prompt,chatFlow,parentTask){
		this.id=taskId;
		this.parentTask=parentTask||null;
		this.fromBot=fromBot;
		this.execBot=hostBot;
		this.prompt=prompt;
		this.chatFlow=chatFlow;
		this.state="NA";//WAIT_ACCEPT,ACCEPT,WORKING,FINNISH,REJECT,FAIL
	};
	aaTaskReq=AATaskReq.prototype={};
	
	//-----------------------------------------------------------------------
	aaTaskReq.giveUp=async function(reason){
		let res;
		res=await tabNT.makeCall("AAETaskGiveUpTask",{taskId:this.id,from:this.fromBot,reason:reason});
		if(!res || res.code!==200){
			if(res && res.info){
				throw Error(res.info);
			}
			throw Error("Send bot message failed");
		}
	};
}

//****************************************************************************
//:AATaskWork
//****************************************************************************
let AATaskWork,aaTaskWork;
{
	//------------------------------------------------------------------------
	AATaskWork=function(taskId,fromBot,hostBot,prompt,chatFlow,parentTask){
		this.id=taskId;
		this.parentTask=parentTask||null;
		this.fromBot=fromBot;
		this.execBot=hostBot;
		this.prompt=prompt;
		this.chatFlow=chatFlow;
		this.state="WAIT";//WAIT,WORKING,FINNISH,REJECT,FAILED
		this.result="NA";
		Object.defineProperty(this,"_result",{
			get(){
				return this.result;
			},
			configurable:false,
			enumerable:true
		});
		makeNotify(this);
		makeObjEventEmitter(this);
	};
	aaTaskWork=AATaskWork.prototype={};
	//------------------------------------------------------------------------
	aaTaskWork.start=async function(){
		let res;
		res=await tabNT.makeCall("AAETaskStartWork",{taskId:this.id,from:this.execBot});
		if(!res || res.code!==200){
			if(res && res.info){
				throw Error(res.info);
			}
			throw Error("Send bot message failed");
		}
		this.state="WORKING";
		this.emit("Changed");
		this.emitNotify("Changed");
	};

	//------------------------------------------------------------------------
	aaTaskWork.getHierarchy=async function(){
		let res;
		res=await tabNT.makeCall("AAETaskGetHierarchy",{taskId:this.id});
		if(!res || res.code!==200){
			if(res && res.info){
				throw Error(res.info);
			}
			throw Error("Send bot message failed");
		}
		this.emit("Changed");
		this.emitNotify("Changed");
		return {parentTask:res.parentTask,subTasks:res.subTasks};
	};

	//-----------------------------------------------------------------------
	aaTaskWork.finish=async function(result,assets){
		let res;
		this.state="FINISH";
		if(assets){
			this.result=result;
			//TODO: Deal with assets?
		}else{
			this.result=result;
		}
		res=await tabNT.makeCall("AAETaskFinishWork",{taskId:this.id,from:this.execBot,result:result,assets:assets});
		if(!res || res.code!==200){
			if(res && res.info){
				throw Error(res.info);
			}
			throw Error("Send bot message failed");
		}
		this.emit("Changed");
		this.emitNotify("Changed");
	};

	//-----------------------------------------------------------------------
	aaTaskWork.fail=async function(reason){
		let res;
		this.state="FAILED";
		this.result=reason;
		res=await tabNT.makeCall("AAETaskFailWork",{taskId:this.id,from:this.execBot,reason:reason});
		if(!res || res.code!==200){
			if(res && res.info){
				throw Error(res.info);
			}
			throw Error("Send bot message failed");
		}
		this.emit("Changed");
		this.emitNotify("Changed");
	};
}

export {AATaskReq,AATaskWork};


