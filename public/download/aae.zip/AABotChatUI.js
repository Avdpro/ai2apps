import {AAChatFlow} from "./AAChatFlow.js";

//****************************************************************************
//AABotChatUI
//****************************************************************************
let AABotChatUI,aaBotChatUI;
{
	//------------------------------------------------------------------------
	AABotChatUI=function(chatBot,ui,chatFlow){
		this.chatBot=chatBot;
		this.outerUI=ui;
		this.chatFlow=chatFlow;
		this.chatTarget=null;
		chatBot.onNotify("AskReply",(msgVO)=>{
			let cbk;
			cbk=this.askReqs[msgVO.askReq];
			if(cbk){
				delete this.askReqs[msgVO.askReq];
				//TODO: make a log?
				cbk(msgVO.result);
			}
		});
	};
	aaBotChatUI=AABotChatUI.prototype={};
	
	//************************************************************************
	//Standard ChatUI API for session:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		aaBotChatUI.appendChatBlock=function(vo,def){
			let blk;
			//TODO: make a log?
			if(this.outerUI){
				blk=this.outerUI && this.outerUI.appendChatBlock(vo,def);
			}else{
				blk=null;
			}
			return blk;
		};

		//--------------------------------------------------------------------
		aaBotChatUI.removeChatBlock=function(blk,maybe){
			//TODO: make a log?
			return this.outerUI && this.outerUI.removeChatBlock(blk,maybe);
		};
		
		//--------------------------------------------------------------------
		aaBotChatUI.askRemote=async function(askType,vo){
			let msgVO,flowObj;
			let pms,replyCbk,errCbk;
			//TODO: make a log?
			if(!this.chatTarget){
				flowObj=await AAChatFlow.getFlow(this.chatFlow);
				this.chatTarget=flowObj.from;
			}
			msgVO={
				type:"Ask",askType:askType,askVO:vo,chatFlow:this.chatFlow
			};
			pms=new Promise((resolve,reject)=>{
				replyCbk=resolve;
				errCbk=reject;
			});
			await this.chatBot.sendAsk(this.chatTarget,msgVO,replyCbk);
			return pms;
		};
		
		//--------------------------------------------------------------------
		aaBotChatUI.askChatInput=async function(vo){
			return this.askRemote("askChatInput",vo);
		};

		//--------------------------------------------------------------------
		aaBotChatUI.askUser=async function(vo){
			return this.askRemote("askUser",vo);
		};

		//--------------------------------------------------------------------
		aaBotChatUI.askUserRaw=async function(vo){
			return this.askRemote("askUserRaw",vo);
		};

		//--------------------------------------------------------------------
		aaBotChatUI.incIndent=function(){
			return this.outerUI && this.outerUI.incIndent();
		};

		//--------------------------------------------------------------------
		aaBotChatUI.decIndent=function(){
			return this.outerUI && this.outerUI.decIndent();
		};
	}
}

export default AABotChatUI;
export {AABotChatUI};