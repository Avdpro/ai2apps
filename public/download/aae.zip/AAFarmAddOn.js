import {VFACT} from "/@vfact";
import {Actions,ActionFilter,BrowserArgs} from "./data/AppData.js";
import {AAFarm} from "./aafarm.js";

const $ln=VFACT.lanCode;

const EditAttr=VFACT.classRegs.EditAttr;
const EditAISeg=VFACT.classRegs.EditAISeg;
const EditAISegOutlet=VFACT.classRegs.EditAISegOutlet;
const SegObjBaseAttr=EditAISeg.SegObjBaseAttr;
const SegObjShellAttr=EditAISeg.SegObjShellAttr;
const FlowOutletDef=EditAISegOutlet.FlowOutletDef;
const SegOutletDef=EditAISegOutlet.SegOutletDef;

const DocAIAgentExporter=VFACT.classRegs.DocAIAgentExporter;
const docAIAgentExporter=DocAIAgentExporter.prototype;
const varNameRegex = /^[a-zA-Z_$][a-zA-Z0-9_$]*$/;

const packExtraCodes=docAIAgentExporter.packExtraCodes;
const packResult=docAIAgentExporter.packResult;

async function pickBrowser(farm,sender){
	let app,liveBrowsers,items,browser,alias,homeLive,item,browserId;
	let openBrowserId,openBrowserAlias,openBrowserWithDir;
	app=VFACT.app;
	liveBrowsers=await farm.getBrowsers();
	items=[];
	homeLive=false;
	for(browser of liveBrowsers){
		alias=browser.alias;
		items.push({text:alias+`: ${browser.pages.length} pages`,alias:browser.alias,browserId:browser.id});
		if(alias==="AAHOME"){
			homeLive=true;
		}
	}
	if(!homeLive){
		items.push({text:"AAHOME",alias:"AAHOME",browserId:null});
	}
	items.push({text:"New browser",alias:null,browserId:null});
	item=await app.modalDlg("/@StdUI/ui/DlgMenu.js",{
		items:items,hud:sender,
	});
	if(!item){
		return null;
	}

	browserId=item.browserId;
	alias=item.alias;
	if(browserId){
		openBrowserId=browserId;
		openBrowserAlias=alias;
		openBrowserWithDir=false;
	}else if(alias){
		openBrowserId=null;
		openBrowserAlias=alias;
		openBrowserWithDir=true;
	}else if(alias===null){
		//TODO: ask a new alias and if use data-dir:
		let cfg=await app.modalDlg("/@StdUI/ui/DlgDataView.js",{
			hud:sender,
			x:-380,y:0,
			template:BrowserArgs,object:null,
			title:"New browser"
		});
		if(!cfg){
			return null;
		}
		openBrowserAlias=cfg.alias;
		openBrowserWithDir=cfg.dataDir;
	}else if(alias===""){
		openBrowserId=null;
		openBrowserAlias="";
		openBrowserWithDir=false;
	}
	
	let opts;
	opts={headless:false,devtools:false};
	if(openBrowserAlias && openBrowserWithDir){
		opts.autoDataDir=true;
	}
	browser=await farm.openBrowser(openBrowserAlias,opts);
	openBrowserAlias=browser.alias;
	farm.editBrowser=browser;
	return browser;
}

async function pickPage(aaf,browser,sender,pageName){
	let pages,items,page,title,item;
	pages=await browser.getPages();
	if(!pages || !pages.length){
		return null;
	}
	items=[];
	for(page of pages){
		title=await page.getTitle();
		items.push({"text":title,page:page});
	}
	item=await VFACT.app.modalDlg("/@StdUI/ui/DlgMenu.js",{
		items:items,hud:sender,
	});
	if(!item){
		return null;
	}
	page=item.page;
	aaf.editPages[pageName]=page;
	return page;
}

async function confirmPage(attr,sender){
	let seg,doc,aaf,browser,pageName,page,query,title;
	let app=VFACT.app;
	let repick=false;
	seg=attr.owner;
	doc=seg.doc;
	aaf=doc.aaFarm;
	pageName=seg.getAttrVal("page");
	if(!aaf){
		aaf=doc.aaFarm=new AAFarm();
		aaf.editPages={};
	}
	page=null;
	browser=aaf.editBrowser;
	if(browser){
		page=aaf.editPages[pageName];
	}
	if(page){
		try{
			title=await page.getTitle();
			if(!title){
				page=null;
			}
		}catch(err){
			page=null;
		}
	}
	if(page){
		let items=[
			{text:`[${title}]`,page:page},
			{text:`Select a new page`,page:null}
		];
		let item=await app.modalDlg("/@StdUI/ui/DlgMenu.js",{
			items:items,hud:sender,
		});
		if(!item){
			VFACT.app.showTip(sender,"Canceled.");
			return null;
		}
		page=item.page;
	}
	if(!page){
		//First pick browser:
		browser=await pickBrowser(aaf,sender);
		if(!browser){
			VFACT.app.showTip(sender,"No browser.");
			return null;
		}
		page=await pickPage(aaf,browser,sender,pageName);
		if(!page){
			VFACT.app.showTip(sender,"No page.");
			return null;
		}
	}
	return page;
};

async function showQueryDlg(attr,sender,line,box){
	let seg,doc,aaf,browser,pageName,page,query;
	let repick=false;
	let app=VFACT.app;
	query=attr.val;
	seg=attr.owner;
	doc=seg.doc;
	aaf=doc.aaFarm;
	page=await confirmPage(attr,sender);
	if(!page){
		return;
	}
	query=await app.modalDlg("/@aae/ui/MainUI.js",{aaf:aaf,browser,page,query});
	if(query!==undefined){
		box.setAttrByText(attr,query);
	}
	return query;
}

EditAISeg.regCatalog({
	name:"AAF",showName:(($ln==="CN")?("AA Farm"):/*EN*/("AA Farm"))
});

//----------------------------------------------------------------------------
//:AISeg that start AAFarm:
EditAISeg.regDef({
	name:"AAFStart",showName:(($ln==="CN")?("启动AA Farm"):/*EN*/("Init AA Farm")),icon:"start.svg",catalog:["AAF"],
	attrs:{
		...SegObjShellAttr,
		"outlet":{name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc"},
		"catchlet":{
			name:"catchlet",showName:"Catch",type:"aioutlet",def:FlowOutletDef,key:1,fixed:1,edit:false,navi:"doc",
			attrs:{
				"id":{
					name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"NoAAE",
				},
			},
		},
		"aiQuery":{name:"aiQuery",showName:(($ln==="CN")?("启用AI查询"):/*EN*/("Enable AI search")),type:"bool",key:1,fixed:1,initVal:true},
	},
	listHint:["id","codes","aiQuery","desc"],
	importSource:{path:"/@aae/aafarm.js",name:"AAFarm"},
});

DocAIAgentExporter.segTypeExporters["AAFStart"]=
function(seg){
	let coder=this.coder;
	let segName=seg.idVal.val;
	let exportDebug=this.isExportDebug();
	segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
	coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
	coder.indentMore();
	coder.newLine();
	{
		coder.maybeNewLine();
		coder.packText(`let result=true;`);coder.newLine();
		coder.packText(`let aiQuery=`);this.genAttrStatement(seg.getAttr("aiQuery"));coder.packText(`;`);coder.newLine();
		packExtraCodes(coder,seg,"PreCodes");
		coder.packText(`try{`);
		coder.indentMore();coder.newLine();
		{
			coder.packText(`context.aaFarm=new AAFarm();`);coder.newLine();
			coder.packText(`aiQuery && (await context.aaFarm.setupAIQuery(session,context,basePath,"${seg.jaxId}"));`);coder.newLine();
			
		}
		coder.indentLess();coder.maybeNewLine();
		coder.packText(`}catch(err){`);
		coder.indentMore();coder.newLine();
		{
			let catchlet,catchSeg;
			catchlet=seg.catchlet||null;
			if(catchlet){
				catchSeg=catchlet.getLinkedSeg();
				if(catchSeg){
					packExtraCodes(coder,catchlet,"Codes");
					this.packUpdateContext(coder,catchlet);
					this.packUpdateGlobal(coder,catchlet);
					packResult(coder,seg,catchlet,"err");
				}else{
					packExtraCodes(coder,catchlet,"Codes");
					this.packUpdateContext(coder,catchlet);
					this.packUpdateGlobal(coder,catchlet);
					coder.packText(`throw err;`);coder.newLine();
				}
			}else{
				coder.packText(`throw err;`);coder.newLine();
			}
		}
		coder.indentLess();coder.maybeNewLine();coder.packText(`}`);coder.newLine();
		packExtraCodes(coder,seg,"PostCodes");
		this.packUpdateContext(coder,seg);
		this.packUpdateGlobal(coder,seg);
		packResult(coder,seg,seg.outlet,"result",false);
	}
	coder.indentLess();
	coder.newLine();
	coder.packText(`};`);
	coder.newLine();
	if(exportDebug){
		coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
	}
	coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
	coder.newLine();
};

//----------------------------------------------------------------------------
//:AISeg that open a browser:
EditAISeg.regDef({
	name:"AAFOpenBrowser",showName:(($ln==="CN")?("打开浏览器"):/*EN*/("Open Browser")),icon:"web.svg",catalog:["AAF"],
	attrs:{
		...SegObjShellAttr,
		"alias":{
			name:"alias",showName:"Alias",type:"string",key:1,fixed:1,initVal:"AAHOME"
		},
		"headless":{
			name:"headless",showName:"Headless",type:"bool",key:1,fixed:1,initVal:false
		},
		"devtools":{
			name:"devtools",showName:"Dev. Tools",type:"bool",key:1,fixed:1,initVal:false
		},
		"dataDir":{
			name:"dataDir",showName:"Data Dir",type:"bool",key:1,fixed:1,initVal:false
		},
		"outlet":{
			name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
		},
		"run":{
			name:"run",showName:"Run This Step",type:"auto",key:1,fixed:1,initVal:undefined,editType:"action",
			OnAction:async function(attrObj,sender,attrLine,editBox){
				let seg,doc,aaf,alias,browser;
				seg=attrObj.owner;
				doc=seg.doc;
				aaf=doc.aaFarm;
				if(!aaf){
					aaf=doc.aaFarm=new AAFarm();
					aaf.editPages={};
				}
				alias=seg.getAttrVal("alias");
				browser=await aaf.openBrowser(alias,{headless:false,devtools:true});
				aaf.editBrowser=browser;
			}
		}
	},
	listHint:[
		"id","alias","dataDir","headless","devtools","run","codes","desc",
	]
});

DocAIAgentExporter.segTypeExporters["AAFOpenBrowser"]=
function(seg){
	let coder=this.coder;
	let segName=seg.idVal.val;
	let exportDebug=this.isExportDebug();
	segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
	coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
	coder.indentMore();
	coder.newLine();
	{
		coder.maybeNewLine();
		coder.packText(`let result=true;`);coder.newLine();
		coder.packText(`let browser=null;`);coder.newLine();
		coder.packText(`let headless=`);this.genAttrStatement(seg.getAttr("headless"));coder.packText(`;`);coder.newLine();
		coder.packText(`let devtools=`);this.genAttrStatement(seg.getAttr("devtools"));coder.packText(`;`);coder.newLine();
		coder.packText(`let dataDir=`);this.genAttrStatement(seg.getAttr("dataDir"));coder.packText(`;`);coder.newLine();
		coder.packText(`let alias=`);this.genAttrStatement(seg.getAttr("alias"));coder.packText(`;`);coder.newLine();
		packExtraCodes(coder,seg,"PreCodes");
		coder.packText(`context.aaBrowser=browser=await context.aaFarm.openBrowser(alias,{headless,devtools,autoDataDir:dataDir});`);coder.newLine();
		coder.packText(`context.aaHostPage=browser.hostPage;`);coder.newLine();
		packExtraCodes(coder,seg,"PostCodes");
		packResult(coder,seg,seg.outlet,"result");
	}
	coder.indentLess();
	coder.newLine();
	coder.packText(`};`);
	coder.newLine();
	if(exportDebug){
		coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
	}
	coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
	coder.newLine();
};

//----------------------------------------------------------------------------
//:AISeg that open a page with url and set it's viewpoert size and user-agent:
EditAISeg.regDef({
	name:"AAFOpenPage",showName:(($ln==="CN")?("打开页面"):/*EN*/("Open Page")),icon:"/@aae/assets/tab_add.svg",catalog:["AAF"],
	attrs:{
		...SegObjShellAttr,
		"valName":{
			name:"valName",showName:"Page Val",type:"string",key:1,fixed:1,initVal:"aaPage"
		},
		"url":{
			name:"url",showName:"URL",type:"string",key:1,fixed:1,initVal:"https://www.google.com"
		},
		"vpWidth":{
			name:"vpWidth",showName:"Viewport Width",type:"int",key:1,fixed:1,initVal:800
		},
		"vpHeight":{
			name:"vpHeight",showName:"Viewport Height",type:"int",key:1,fixed:1,initVal:600
		},
		"userAgent":{
			name:"userAgent",showName:"User Agent",type:"string",key:1,fixed:1,initVal:""
		},
		"waitBefore":{
			name:"waitBefore",showName:"Wait Before",type:"int",key:1,fixed:1,initVal:0
		},
		"waitAfter":{
			name:"waitAfter",showName:"Wait After",type:"int",key:1,fixed:1,initVal:0
		},
		"outlet":{
			name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
		},
		"run":{
			name:"run",showName:"Run This Step",type:"auto",key:1,fixed:1,initVal:undefined,editType:"action",
			OnAction:async function(attrObj,sender,attrLine,editBox){
				let seg,doc,aaf,alias,browser,page,vw,vh,url,pageName;
				seg=attrObj.owner;
				doc=seg.doc;
				aaf=doc.aaFarm;
				if(!aaf){
					aaf=doc.aaFarm=new AAFarm();
					aaf.editPages={};
				}
				browser=aaf.editBrowser;
				if(!browser){
					browser=await pickBrowser(aaf,sender);
					if(!browser){
						VFACT.app.showTip(sender,"No browser.");
						return;
					}
				}
				pageName=seg.getAttrVal("valName");
				page=await browser.newPage();
				aaf.editPages[pageName]=page;
				vw=seg.getAttrVal("vpWidth");
				vh=seg.getAttrVal("vpHeight");
				url=seg.getAttrVal("url");
				await page.setViewport({width:vw,height:vh});
				await page.goto(url);
			}
		}
	},
	listHint:[
		"id","valName","url","vpWidth","vpHeight","userAgent","run","waitBefore","waitAfter","codes","desc",
	]
});

DocAIAgentExporter.segTypeExporters["AAFOpenPage"]=
function(seg){
	let coder=this.coder;
	let segName=seg.idVal.val;
	let exportDebug=this.isExportDebug();
	segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
	coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
	coder.indentMore();
	coder.newLine();
	{
		coder.maybeNewLine();
		coder.packText(`let pageVal=`);this.genAttrStatement(seg.getAttr("valName"));coder.packText(`;`);coder.newLine();
		coder.packText(`let $url=`);this.genAttrStatement(seg.getAttr("url"));coder.packText(`;`);coder.newLine();
		coder.packText(`let $waitBefore=`);this.genAttrStatement(seg.getAttr("waitBefore"));coder.packText(`;`);coder.newLine();
		coder.packText(`let $waitAfter=`);this.genAttrStatement(seg.getAttr("waitAfter"));coder.packText(`;`);coder.newLine();
		coder.packText(`let $width=`);this.genAttrStatement(seg.getAttr("vpWidth"));coder.packText(`;`);coder.newLine();
		coder.packText(`let $height=`);this.genAttrStatement(seg.getAttr("vpHeight"));coder.packText(`;`);coder.newLine();
		coder.packText(`let $userAgent=`);this.genAttrStatement(seg.getAttr("userAgent"));coder.packText(`;`);coder.newLine();
		coder.packText(`let page=null;`);coder.newLine();
		coder.packText(`$waitBefore && (await sleep($waitBefore));`);coder.newLine();
		packExtraCodes(coder,seg,"PreCodes");
		coder.packText(`context[pageVal]=page=await context.aaBrowser.newPage();`);coder.newLine();
		coder.packText(`($width && $height) && (await page.setViewport({width:$width,height:$height}));`);coder.newLine();
		coder.packText(`$userAgent && (await page.setUserAgent($userAgent));`);coder.newLine();
		coder.packText(`await page.goto($url);`);coder.newLine();
		coder.packText(`$waitAfter && (await sleep($waitAfter));`);coder.newLine();
		packExtraCodes(coder,seg,"PostCodes");
		packResult(coder,seg,seg.outlet,"page");
	}
	coder.indentLess();
	coder.newLine();
	coder.packText(`};`);
	coder.newLine();
	if(exportDebug){
		coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
	}
	coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
	coder.newLine();
};

//----------------------------------------------------------------------------
//:AISeg that close a page
EditAISeg.regDef({
	name:"AAFClosePage",showName:(($ln==="CN")?("关闭页面"):/*EN*/("Close Page")),icon:"/@aae/assets/tab_close.svg",catalog:["AAF"],
	attrs:{
		...SegObjShellAttr,
		"page":{
			name:"page",showName:"Page",type:"string",key:1,fixed:1,initVal:"aaPage"
		},
		"waitBefore":{
			name:"waitBefore",showName:"Wait Before",type:"int",key:1,fixed:1,initVal:0
		},
		"waitAfter":{
			name:"waitAfter",showName:"Wait After",type:"int",key:1,fixed:1,initVal:0
		},
		"outlet":{
			name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
		},
		"run":{
			name:"run",showName:"Run This Step",type:"auto",key:1,fixed:1,initVal:undefined,editType:"action",
			OnAction:async function(attrObj,sender,attrLine,editBox){
				let page,seg,doc,aaf,pageName;
				page=await confirmPage(attrObj,sender);
				if(page){
					seg=attrObj.owner;
					doc=seg.doc;
					aaf=doc.aaFarm;
					await page.close();
					pageName=seg.getAttrVal("page");
					aaf.editPages[pageName]=null;
					VFACT.app.showTip(sender,"Page closed.");
				}else{
					VFACT.app.showTip(sender,"No assigned page to close.");
				}
			}
		}
	},
	listHint:[
		"id","page","run","waitBefore","waitAfter","codes","desc",
	]
});

DocAIAgentExporter.segTypeExporters["AAFClosePage"]=
function(seg){
	let coder=this.coder;
	let segName=seg.idVal.val;
	let exportDebug=this.isExportDebug();
	segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
	coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
	coder.indentMore();coder.newLine();
	{
		coder.maybeNewLine();
		coder.packText(`let result=input;`);coder.newLine();
		coder.packText(`let pageVal=`);this.genAttrStatement(seg.getAttr("page"));coder.packText(`;`);coder.newLine();
		coder.packText(`let waitBefore=`);this.genAttrStatement(seg.getAttr("waitBefore"));coder.packText(`;`);coder.newLine();
		coder.packText(`let waitAfter=`);this.genAttrStatement(seg.getAttr("waitAfter"));coder.packText(`;`);coder.newLine();
		coder.packText(`let page=context[pageVal];`);coder.newLine();
		coder.packText(`waitBefore && (await sleep(waitBefore));`);coder.newLine();
		packExtraCodes(coder,seg,"PreCodes");
		coder.packText(`await page.close();`);coder.newLine();
		coder.packText(`waitAfter && (await sleep(waitAfter))`);coder.newLine();
		packExtraCodes(coder,seg,"PostCodes");
		packResult(coder,seg,seg.outlet,"result");
	}
	coder.indentLess();coder.maybeNewLine();
	coder.packText(`};`);
	coder.newLine();
	if(exportDebug){
		coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
	}
	coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
	coder.newLine();
};

//----------------------------------------------------------------------------
//:AISeg that active a page
EditAISeg.regDef({
	name:"AAFActivePage",showName:(($ln==="CN")?("激活页面"):/*EN*/("Active Page")),icon:"/@aae/assets/tab_tap.svg",catalog:["AAF"],
	attrs:{
		...SegObjShellAttr,
		"page":{
			name:"page",showName:"Page",type:"string",key:1,fixed:1,initVal:"aaPage"
		},
		"waitBefore":{
			name:"waitBefore",showName:"Wait Before",type:"int",key:1,fixed:1,initVal:0
		},
		"waitAfter":{
			name:"waitAfter",showName:"Wait After",type:"int",key:1,fixed:1,initVal:0
		},
		"outlet":{
			name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
		},
		"run":{
			name:"run",showName:"Run This Step",type:"auto",key:1,fixed:1,initVal:undefined,editType:"action",
			OnAction:async function(attrObj,sender,attrLine,editBox){
				let page=await confirmPage(attrObj,sender);
				if(page){
					page.active();
					VFACT.app.showTip(sender,"Page actived.");
				}else{
					VFACT.app.showTip(sender,"No page assigned.");
				}
			}
		}
	},
	listHint:[
		"id","page","run","waitBefore","waitAfter","codes","desc",
	]
});

DocAIAgentExporter.segTypeExporters["AAFActivePage"]=
function(seg){
	let coder=this.coder;
	let segName=seg.idVal.val;
	let exportDebug=this.isExportDebug();
	segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
	coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
	coder.indentMore();coder.newLine();
	{
		coder.maybeNewLine();
		coder.packText(`let result=input;`);coder.newLine();
		coder.packText(`let pageVal=`);this.genAttrStatement(seg.getAttr("page"));coder.packText(`;`);coder.newLine();
		coder.packText(`let waitBefore=`);this.genAttrStatement(seg.getAttr("waitBefore"));coder.packText(`;`);coder.newLine();
		coder.packText(`let waitAfter=`);this.genAttrStatement(seg.getAttr("waitAfter"));coder.packText(`;`);coder.newLine();
		coder.packText(`let page=context[pageVal];`);coder.newLine();
		coder.packText(`waitBefore && (await sleep(waitBefore));`);coder.newLine();
		packExtraCodes(coder,seg,"PreCodes");
		coder.packText(`await page.active();`);coder.newLine();
		coder.packText(`waitAfter && (await sleep(waitAfter))`);coder.newLine();
		packExtraCodes(coder,seg,"PostCodes");
		packResult(coder,seg,seg.outlet,"result");
	}
	coder.indentLess();coder.maybeNewLine();
	coder.packText(`};`);
	coder.newLine();
	if(exportDebug){
		coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
	}
	coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
	coder.newLine();
};

//----------------------------------------------------------------------------
//:AISeg that screenshot a page
EditAISeg.regDef({
	name:"AAFCapturePage",showName:(($ln==="CN")?("页面截图"):/*EN*/("Screenshot")),icon:"/@aae/assets/tab_cam.svg",catalog:["AAF"],
	attrs:{
		...SegObjShellAttr,
		"page":{
			name:"page",showName:"Page",type:"string",key:1,fixed:1,initVal:"aaPage"
		},
		"fullPage":{
			name:"fullPage",showName:"Full Page",type:"bool",key:1,fixed:1,initVal:true
		},
		"dataURL":{
			name:"dataURL",showName:"Result as Data-URL",type:"bool",key:1,fixed:1,initVal:true
		},
		"waitBefore":{
			name:"waitBefore",showName:"Wait Before",type:"int",key:1,fixed:1,initVal:0
		},
		"waitAfter":{
			name:"waitAfter",showName:"Wait After",type:"int",key:1,fixed:1,initVal:0
		},
		"outlet":{
			name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
		},
	},
	listHint:[
		"id","page","fullPage","dataURL","waitBefore","waitAfter","codes","desc",
	],
	attrOutlets:["input","result","data"]
	//attrOutlets:["input","result",{text:"data: image data without data-url-header.",value:"data"}]
});

DocAIAgentExporter.segTypeExporters["AAFCapturePage"]=
function(seg){
	let coder=this.coder;
	let segName=seg.idVal.val;
	let exportDebug=this.isExportDebug();
	let useDataURL=seg.getAttrVal("dataURL");
	segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
	coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
	coder.indentMore();coder.newLine();
	{
		coder.maybeNewLine();
		coder.packText(`let result=null;`);coder.newLine();
		coder.packText(`let data=null;`);coder.newLine();
		coder.packText(`let pageVal=`);this.genAttrStatement(seg.getAttr("page"));coder.packText(`;`);coder.newLine();
		coder.packText(`let fullPage=`);this.genAttrStatement(seg.getAttr("fullPage"));coder.packText(`;`);coder.newLine();
		coder.packText(`let waitBefore=`);this.genAttrStatement(seg.getAttr("waitBefore"));coder.packText(`;`);coder.newLine();
		coder.packText(`let waitAfter=`);this.genAttrStatement(seg.getAttr("waitAfter"));coder.packText(`;`);coder.newLine();
		coder.packText(`let page=context[pageVal];`);coder.newLine();
		coder.packText(`waitBefore && (await sleep(waitBefore));`);coder.newLine();
		packExtraCodes(coder,seg,"PreCodes");
		coder.packText(`result=await page.screenshot({fullPage:fullPage});`);coder.newLine();
		coder.packText(`data=result.substring(result.indexOf(","))`);coder.newLine();
		if(!useDataURL){
			coder.packText(`result=data;`);coder.newLine();
		}
		coder.packText(`waitAfter && (await sleep(waitAfter));`);coder.newLine();
		packExtraCodes(coder,seg,"PostCodes");
		this.packUpdateContext(coder,seg);
		this.packUpdateGlobal(coder,seg);
		packResult(coder,seg,seg.outlet,"result");
	}
	coder.indentLess();coder.maybeNewLine();
	coder.packText(`};`);
	coder.newLine();
	if(exportDebug){
		coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
	}
	coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
	coder.newLine();
};

//----------------------------------------------------------------------------
//:AISeg that makes page goto an URL
EditAISeg.regDef({
	name:"AAFPageGoto",showName:(($ln==="CN")?("前往网址"):/*EN*/("Goto URL")),icon:"/@aae/assets/wait_goto.svg",catalog:["AAF"],
	attrs:{
		...SegObjShellAttr,
		"page":{
			name:"page",showName:"Page",type:"string",key:1,fixed:1,initVal:"aaPage"
		},
		"url":{
			name:"url",showName:"URL",type:"string",key:1,fixed:1,initVal:"https://www.google.com"
		},
		"waitBefore":{
			name:"waitBefore",showName:"Wait Before",type:"int",key:1,fixed:1,initVal:0
		},
		"waitAfter":{
			name:"waitAfter",showName:"Wait After",type:"int",key:1,fixed:1,initVal:0
		},
		"outlet":{
			name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
		},
		"run":{
			name:"run",showName:"Run This Step",type:"auto",key:1,fixed:1,initVal:undefined,editType:"action",
			OnAction:async function(attrObj,sender,attrLine,editBox){
				let page=await confirmPage(attrObj,sender);
				if(page){
					let seg,url;
					seg=attrObj.owner;
					url=seg.getAttrVal("url");
					await page.goto(url);
				}else{
					VFACT.app.showTip(sender,"No page assigned.");
				}
			}
		}
	},
	listHint:[
		"id","page","url","run","waitBefore","waitAfter","codes","desc",
	]
});

DocAIAgentExporter.segTypeExporters["AAFPageGoto"]=
function(seg){
	let coder=this.coder;
	let segName=seg.idVal.val;
	let exportDebug=this.isExportDebug();
	segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
	coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
	coder.indentMore();
	coder.newLine();
	{
		coder.maybeNewLine();
		coder.packText(`let result=true;`);coder.newLine();
		coder.packText(`let pageVal=`);this.genAttrStatement(seg.getAttr("page"));coder.packText(`;`);coder.newLine();
		coder.packText(`let waitBefore=`);this.genAttrStatement(seg.getAttr("waitBefore"));coder.packText(`;`);coder.newLine();
		coder.packText(`let waitAfter=`);this.genAttrStatement(seg.getAttr("waitAfter"));coder.packText(`;`);coder.newLine();
		coder.packText(`let url=`);this.genAttrStatement(seg.getAttr("url"));coder.packText(`;`);coder.newLine();
		coder.packText(`let page=context[pageVal];`);coder.newLine();
		coder.packText(`waitBefore && (await sleep(waitBefore));`);coder.newLine();
		packExtraCodes(coder,seg,"PreCodes");
		coder.packText(`await page.goto(url,{});`);coder.newLine();
		coder.packText(`waitAfter && (await sleep(waitAfter))`);coder.newLine();
		packExtraCodes(coder,seg,"PostCodes");
		packResult(coder,seg,seg.outlet,"result");
	}
	coder.indentLess();
	coder.newLine();
	coder.packText(`};`);
	coder.newLine();
	if(exportDebug){
		coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
	}
	coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
	coder.newLine();
};

//----------------------------------------------------------------------------
//:AISeg that singal a wait flag for page action
EditAISeg.regDef({
	name:"AAFWaitFor",showName:(($ln==="CN")?("标记页面事件"):/*EN*/("Flag Event")),icon:"/@aae/assets/wait_event.svg",catalog:["AAF"],
	attrs:{
		...SegObjShellAttr,
		"page":{
			name:"page",showName:"Page",type:"string",key:1,fixed:1,initVal:"aaPage"
		},
		"action":{
			name:"action",showName:"Wait Event",type:"choice",key:1,fixed:1,initVal:"navi",
			vals:[
				["navi","Navigate","Navigate"],
				["query","Query","Query Selector"],
				["click","Click","Click"],
				["keydown","KeyDown","Key Down"],
				["networkidle","NetworkIdle","Network Idle"],
				["dialog","Dialog","Dialog"],
				["filechooser","FileChooser","File Chooser"],
				["function","Function","Function"],
			],
		},
		"flag":{
			name:"flag",showName:"Flag",type:"string",key:1,fixed:1,initVal:"Wait"
		},
		"query":{
			name:"query",showName:"Query",type:"string",key:1,fixed:1,initVal:"",
			editType:"choice",vals:[],
			showMenu:async function(attr,sender,line,box){
				return await showQueryDlg(attr,sender,line,box);
			}
		},
		"queryHint":{
			name:"queryHint",showName:(($ln==="CN")?("查询提示"):/*EN*/("Query Hint")),type:"string",key:1,fixed:1,initVal:""
		},
		"waitBefore":{
			name:"waitBefore",showName:"Wait Before",type:"int",key:1,fixed:1,initVal:0
		},
		"waitAfter":{
			name:"waitAfter",showName:"Wait After",type:"int",key:1,fixed:1,initVal:0
		},
		"outlet":{
			name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
		},
	},
	listHint:[
		"id","page","action","flag","query","queryHint","waitBefore","waitAfter","codes","desc",
	]
});

DocAIAgentExporter.segTypeExporters["AAFWaitFor"]=
function(seg){
	let coder=this.coder;
	let segName=seg.idVal.val;
	let exportDebug=this.isExportDebug();
	segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
	coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
	coder.indentMore();coder.newLine();
	{
		coder.maybeNewLine();
		coder.packText(`let result=true;`);coder.newLine();
		coder.packText(`let pageVal=`);this.genAttrStatement(seg.getAttr("page"));coder.packText(`;`);coder.newLine();
		coder.packText(`let $action=`);this.genAttrStatement(seg.getAttr("action"));coder.packText(`;`);coder.newLine();
		coder.packText(`let $flag=`);this.genAttrStatement(seg.getAttr("flag"));coder.packText(`;`);coder.newLine();
		coder.packText(`let $query=`);this.genAttrStatement(seg.getAttr("query"));coder.packText(`;`);coder.newLine();
		coder.packText(`let $queryHint=`);this.genAttrStatement(seg.getAttr("queryHint"));coder.packText(`;`);coder.newLine();
		coder.packText(`let $waitBefore=`);this.genAttrStatement(seg.getAttr("waitBefore"));coder.packText(`;`);coder.newLine();
		coder.packText(`let $waitAfter=`);this.genAttrStatement(seg.getAttr("waitAfter"));coder.packText(`;`);coder.newLine();
		coder.packText(`let $options={};`);coder.newLine();
		coder.packText(`let page=context[pageVal];`);coder.newLine();
		coder.packText(`$waitBefore && (await sleep($waitBefore));`);coder.newLine();
		packExtraCodes(coder,seg,"PreCodes");
		coder.packText(`switch($action){`);
		coder.indentMore();coder.newLine();
		{
			coder.packText(`case "navi":`);coder.newLine();
			coder.packText(`case "networkidle":`);coder.newLine();
			coder.packText(`case "dialog":`);coder.newLine();
			coder.packText(`case "filechooser":`);coder.newLine();
			coder.packText(`default:`);
			coder.indentMore();coder.newLine();
			{
				coder.packText(`page.waitFor($flag,$action,$options);`);coder.newLine();
				coder.packText(`break;`);coder.newLine();
			}
			coder.indentLess();coder.maybeNewLine();
			//Query:
			coder.packText(`case "query":`);
			coder.indentMore();coder.newLine();
			{
				coder.packText(`$query=$queryHint?(await page.confirmQuery($query,$queryHint,"${seg.jaxId}")):$query;`);coder.newLine();
				coder.packText(`if(!$query) throw Error("Missing query. Query hint: "+$queryHint);`);coder.newLine();
				coder.packText(`page.waitForQuery($flag,$query,$options);`);coder.newLine();
				coder.packText(`break;`);coder.newLine();
			}
			coder.indentLess();coder.maybeNewLine();
			//Function:
			coder.packText(`case "function":`);
			coder.indentMore();coder.newLine();
			{
				coder.packText(`page.waitForFunction($flag,$query,$options);`);coder.newLine();
				coder.packText(`break;`);coder.newLine();
			}
			coder.indentLess();coder.maybeNewLine();
		}
		coder.indentLess();coder.maybeNewLine();
		coder.packText(`}`);
		coder.packText(`$waitAfter && (await sleep($waitAfter))`);coder.newLine();
		packExtraCodes(coder,seg,"PostCodes");
		packResult(coder,seg,seg.outlet,"result");
	}
	coder.indentLess();coder.maybeNewLine();
	coder.packText(`};`);
	coder.newLine();
	if(exportDebug){
		coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
	}
	coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
	coder.newLine();
};

//----------------------------------------------------------------------------
//:AISeg that await a page action flag
EditAISeg.regDef({
	name:"AAFAWaitFor",showName:(($ln==="CN")?("等待事件发生"):/*EN*/("Wait Flag")),icon:"/@aae/assets/wait_await.svg",catalog:["AAF"],
	attrs:{
		...SegObjShellAttr,
		"page":{
			name:"page",showName:"Page",type:"string",key:1,fixed:1,initVal:"aaPage"
		},
		"flag":{
			name:"flag",showName:"Flag",type:"string",key:1,fixed:1,initVal:"Wait"
		},
		"waitBefore":{
			name:"waitBefore",showName:"Wait Before",type:"int",key:1,fixed:1,initVal:0
		},
		"waitAfter":{
			name:"waitAfter",showName:"Wait After",type:"int",key:1,fixed:1,initVal:0
		},
		"outlet":{
			name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
		},
	},
	listHint:[
		"id","page","flag","waitBefore","waitAfter","codes","desc",
	]
});

DocAIAgentExporter.segTypeExporters["AAFAWaitFor"]=
function(seg){
	let coder=this.coder;
	let segName=seg.idVal.val;
	let exportDebug=this.isExportDebug();
	segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
	coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
	coder.indentMore();coder.newLine();
	{
		coder.maybeNewLine();
		coder.packText(`let result=true;`);coder.newLine();
		coder.packText(`let pageVal=`);this.genAttrStatement(seg.getAttr("page"));coder.packText(`;`);coder.newLine();
		coder.packText(`let $flag=`);this.genAttrStatement(seg.getAttr("flag"));coder.packText(`;`);coder.newLine();
		coder.packText(`let $waitBefore=`);this.genAttrStatement(seg.getAttr("waitBefore"));coder.packText(`;`);coder.newLine();
		coder.packText(`let $waitAfter=`);this.genAttrStatement(seg.getAttr("waitAfter"));coder.packText(`;`);coder.newLine();
		coder.packText(`let page=context[pageVal];`);coder.newLine();
		coder.packText(`$waitBefore && (await sleep($waitBefore));`);coder.newLine();
		packExtraCodes(coder,seg,"PreCodes");
		coder.packText(`await page.awaitFor($flag);`);coder.newLine();
		coder.packText(`$waitAfter && (await sleep($waitAfter))`);coder.newLine();
		packExtraCodes(coder,seg,"PostCodes");
		packResult(coder,seg,seg.outlet,"result");
	}
	coder.indentLess();coder.maybeNewLine();
	coder.packText(`};`);
	coder.newLine();
	if(exportDebug){
		coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
	}
	coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
	coder.newLine();
};

//----------------------------------------------------------------------------
//:AISeg that send user-mouse/touch action to page
EditAISeg.regDef({
	name:"AAFMouseAction",showName:(($ln==="CN")?("鼠标动作"):/*EN*/("Mouse Action")),icon:"mouse.svg",catalog:["AAF"],
	attrs:{
		...SegObjShellAttr,
		"page":{
			name:"page",showName:"Page",type:"string",key:1,fixed:1,initVal:"aaPage"
		},
		"action":{
			name:"action",showName:(($ln==="CN")?("动作"):/*EN*/("Action")),type:"choice",key:1,fixed:1,initVal:"Click",
			vals:[
				["Click","Click","Click"],
				["Tap","Tap","Tap"],
				["MouseDown","Mouse Down","Mouse Down"],
				["MouseUp","Mouse Up","Mouse Up"],
				["MouseMove","Mouse Move","Mouse Move"],
				["MouseReset","Mouse Reset","Reset Mouse"],
				["TouchStart","Touch Start","Touch Start"],
				["TouchMove","Touch Move","Touch Move"],
				["TouchEnd","Touch End","Touch End"],
			],
		},
		"query":{
			name:"query",showName:"Query",type:"string",key:1,fixed:1,initVal:"",
			editType:"choice",vals:[],
			showMenu:async function(attr,sender,line,box){
				return await showQueryDlg(attr,sender,line,box);
			}
		},
		"queryHint":{
			name:"queryHint",showName:"Query Hint",type:"string",key:1,fixed:1,initVal:""
		},
		"dx":{
			name:"dx",showName:"Offset X",type:"int",key:1,fixed:1,initVal:0
		},
		"dy":{
			name:"dy",showName:"Offset Y",type:"int",key:1,fixed:1,initVal:0
		},
		"options":{
			name:"options",showName:"Options",type:"hyperObj",key:1,fixed:1,initVal:undefined,
			template:function(obj){
				let action;
				action=obj.getAttrVal("action");
				switch(action){
					default:
						return{
							title:"No options for this action",label:"",
							properties:{}
						};
					case "MouseDown":
					case "MouseUp":
						return {
							title:"Mouse action options:",label:"",
							properties:{
								button:{
									type:"auto",label:"Mouse button:",
									choices:[{text:"Left button",value:"left"},{text:"Right button",value:"right"},{text:"Middle button",value:"middle"}]
								}
							},
							wrapObject(vo){
								if(!vo.button){delete vo.button;}
								return vo;
							}
						};
					case "MouseMove":
						return {
							title:"Mouse move options:",label:"",
							properties:{
								steps:{
									type:"auto",label:"Move steps:",
									choices:[{text:"1 step",value:1},{text:"2 steps",value:2},{text:"5 steps",value:5},{text:"10 steps",value:10}]
								}
							},
							wrapObject(vo){
								if(!vo.steps){delete vo.steps;}
								return vo;
							}
						};
					case "Click":
						return {
							title:"Mouse click options:",
							label:"",//"Mouse action options:",
							properties:{
								button:{
									type:"auto",label:"Mouse button:",
									choices:[{text:"Left button",value:"left"},{text:"Right button",value:"right"},{text:"Middle button",value:"middle"}]
								},
								count:{
									type:"auto",label:"Click count:",desc:"Used in Action: Click.",
									choices:[{text:"1 click",value:1},{text:"2 clicks",value:2},{text:"3 clicks",value:3}]
								},
								delay:{
									type:"auto",label:"Delay:",desc:"Gap time between clicks.",
									choices:[{text:"50ms",value:50},{text:"100ms",value:100},{text:"200ms",value:300},{text:"500ms",value:500}]
								}
							},
							wrapObject(vo){
								if(!vo.button){delete vo.button;}
								if(!vo.count){delete vo.count;}
								if(!vo.delay){delete vo.delay;}
								return vo;
							}
						};
				}
			}
		},
		"waitBefore":{
			name:"waitBefore",showName:"Wait Before",type:"int",key:1,fixed:1,initVal:0
		},
		"waitAfter":{
			name:"waitAfter",showName:"Wait After",type:"int",key:1,fixed:1,initVal:0
		},
		"outlet":{
			name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
		},
		"run":{
			name:"run",showName:"Run This Step",type:"auto",key:1,fixed:1,initVal:undefined,editType:"action",
			OnAction:async function(attrObj,sender,attrLine,editBox){
				let seg,page,options,action,query,x,y;
				seg=attrObj.owner;
				action=seg.getAttrVal("action");
				options=seg.getAttrVal("options");
				query=seg.getAttrVal("query");
				x=seg.getAttrVal("dx");
				y=seg.getAttrVal("dy");
				page=await confirmPage(attrObj,sender);
				if(!page){
					VFACT.app.showTip(sender,"No page assigned.");
					return;
				}
				switch(action){
					case "Click":
						if(query){
							let opts={...options};
							if(x!==0 || y!==0){
								opts.offset={x,y};
							}
							await page.clickOn("::-p-xpath"+query,{...options,offset:((!!x) || (!!y))?{x:x||0,y:y||0}:undefined});
						}else{
							await page.mouseClick(x,y,{...options});
						}
						break;
					case "MouseDown":
						await page.mouseDown({...options});
						break;
					case "MouseUp":
						await page.mouseUp({...options});
						break;
					case "MouseMove":
						await page.mouseMove(x,y,{...options});
						break;
					case "MouseReset":
						await page.mouseReset();
						break;
					case "Tap":
						if(query){
							await page.tapOn("::-p-xpath"+query);
						}else{
							await page.touchTap(x,y);
						}
						break;
					case "TouchStart":
						await page.touchStart(x,y);
						break;
					case "TouchMove":
						await page.touchMove(x,y);
						break;
					case "TouchEnd":
						await page.touchEnd();
						break;
				}
			}
		}
	},
	listHint:[
		"id","page","action","query","queryHint","dx","dy","options","run","waitBefore","waitAfter","codes","desc",
	],
	OnAttrEdit(box,attr,value){
		if(!attr || attr.name==="action"){
			let action=this.getAttrVal("action");
			switch(action){
				case "Click":
				case "MouseMove":
				case "TouchStart":
				case "TouchMove":
					box.showAttrLine(this.getAttr("dx"));
					box.showAttrLine(this.getAttr("dy"));
					break;
				default:
					box.hideAttrLine(this.getAttr("dx"));
					box.hideAttrLine(this.getAttr("dy"));
					break;
			}
			switch(action){
				case "Click":
				case "Tap":
					box.showAttrLine(this.getAttr("query"));
					break;
				default:
					box.hideAttrLine(this.getAttr("query"));
					break;
			}
		}
	}
});

DocAIAgentExporter.segTypeExporters["AAFMouseAction"]=
function(seg){
	let coder=this.coder;
	let segName=seg.idVal.val;
	let exportDebug=this.isExportDebug();
	segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
	coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
	coder.indentMore();coder.newLine();
	{
		coder.maybeNewLine();
		coder.packText(`let result=true;`);coder.newLine();
		coder.packText(`let pageVal=`);this.genAttrStatement(seg.getAttr("page"));coder.packText(`;`);coder.newLine();
		coder.packText(`let $action=`);this.genAttrStatement(seg.getAttr("action"));coder.packText(`;`);coder.newLine();
		coder.packText(`let $query=`);this.genAttrStatement(seg.getAttr("query"));coder.packText(`;`);coder.newLine();
		coder.packText(`let $queryHint=`);this.genAttrStatement(seg.getAttr("queryHint"));coder.packText(`;`);coder.newLine();
		coder.packText(`let $x=`);this.genAttrStatement(seg.getAttr("dx"));coder.packText(`;`);coder.newLine();
		coder.packText(`let $y=`);this.genAttrStatement(seg.getAttr("dy"));coder.packText(`;`);coder.newLine();
		coder.packText(`let $options=`);this.genAttrStatement(seg.getAttr("options"));coder.packText(`;`);coder.newLine();
		coder.packText(`let $waitBefore=`);this.genAttrStatement(seg.getAttr("waitBefore"));coder.packText(`;`);coder.newLine();
		coder.packText(`let $waitAfter=`);this.genAttrStatement(seg.getAttr("waitAfter"));coder.packText(`;`);coder.newLine();
		coder.packText(`let page=context[pageVal];`);coder.newLine();
		coder.packText(`$waitBefore && (await sleep($waitBefore));`);coder.newLine();
		packExtraCodes(coder,seg,"PreCodes");
		coder.packText(`switch($action){`);
		coder.indentMore();coder.newLine();
		{
			//Click
			coder.packText(`case "Click":`);
			coder.indentMore();coder.newLine();
			{
				coder.packText(`if($query||$queryHint){`);
				coder.indentMore();coder.newLine();
				{
					coder.packText(`$query=$queryHint?(await page.confirmQuery($query,$queryHint,"${seg.jaxId}")):$query;`);coder.newLine();
					coder.packText(`if(!$query) throw Error("Missing query. Query hint: "+$queryHint);`);coder.newLine();
					coder.packText(`await page.clickOn("::-p-xpath"+$query,{...$options,offset:((!!$x) || (!!$y))?{x:$x||0,y:$y||0}:undefined});`);coder.newLine();
				}
				coder.indentLess();coder.maybeNewLine();
				coder.packText(`}else{`);
				coder.indentMore();coder.newLine();
				{
					coder.packText(`await page.mouseClick($x,$y,$options||{});`);coder.newLine();
				}
				coder.indentLess();coder.maybeNewLine();
				coder.packText(`}`);coder.maybeNewLine();
				coder.packText(`break;`);coder.newLine();
			}
			coder.indentLess();coder.maybeNewLine();

			//Tap
			coder.packText(`case "Tap":`);
			coder.indentMore();coder.newLine();
			{
				coder.packText(`if($query||$queryHint){`);
				coder.indentMore();coder.newLine();
				{
					coder.packText(`$query=$queryHint?(await page.confirmQuery($query,$queryHint,"${seg.jaxId}")):$query;`);coder.newLine();
					coder.packText(`if(!$query) throw Error("Missing query. Query hint: "+$queryHint);`);coder.newLine();
					coder.packText(`await page.tapOn("::-p-xpath"+$query);`);coder.newLine();
				}
				coder.indentLess();coder.maybeNewLine();
				coder.packText(`}else{`);
				coder.indentMore();coder.newLine();
				{
					coder.packText(`await page.touchTap($x,$y);`);coder.newLine();
				}
				coder.indentLess();coder.maybeNewLine();
				coder.packText(`}`);coder.maybeNewLine();
				coder.packText(`break;`);coder.newLine();
			}
			coder.indentLess();coder.maybeNewLine();

			//MouseMove
			coder.packText(`case "MouseMove":`);
			coder.indentMore();coder.newLine();
			{
				coder.packText(`await page.mouseMove($x,$y,$options||{});`);coder.newLine();
				coder.packText(`break;`);coder.newLine();
			}
			coder.indentLess();coder.maybeNewLine();

			//MouseDown
			coder.packText(`case "MouseDown":`);
			coder.indentMore();coder.newLine();
			{
				coder.packText(`await page.mouseDown($options||{});`);coder.newLine();
				coder.packText(`break;`);coder.newLine();
			}
			coder.indentLess();coder.maybeNewLine();

			//MouseUp
			coder.packText(`case "MouseUp":`);
			coder.indentMore();coder.newLine();
			{
				coder.packText(`await page.mouseUp($options||{});`);coder.newLine();
				coder.packText(`break;`);coder.newLine();
			}
			coder.indentLess();coder.maybeNewLine();
			
			//MouseReset
			coder.packText(`case "MouseReset":`);
			coder.indentMore();coder.newLine();
			{
				coder.packText(`await page.mouseReset();`);coder.newLine();
				coder.packText(`break;`);coder.newLine();
			}
			coder.indentLess();coder.maybeNewLine();

			//TouchStart
			coder.packText(`case "TouchStart":`);
			coder.indentMore();coder.newLine();
			{
				coder.packText(`await page.touchStart($x,$y);`);coder.newLine();
				coder.packText(`break;`);coder.newLine();
			}
			coder.indentLess();coder.maybeNewLine();

			//TouchMove
			coder.packText(`case "TouchMove":`);
			coder.indentMore();coder.newLine();
			{
				coder.packText(`await page.touchStart($x,$y);`);coder.newLine();
				coder.packText(`break;`);coder.newLine();
			}
			coder.indentLess();coder.maybeNewLine();

			//TouchEnd
			coder.packText(`case "TouchEnd":`);
			coder.indentMore();coder.newLine();
			{
				coder.packText(`await page.touchEnd();`);coder.newLine();
				coder.packText(`break;`);coder.newLine();
			}
			coder.indentLess();coder.maybeNewLine();
		}
		coder.indentLess();coder.maybeNewLine();
		coder.packText(`}`);coder.maybeNewLine();
		coder.packText(`$waitAfter && (await sleep($waitAfter))`);coder.newLine();
		packExtraCodes(coder,seg,"PostCodes");
		packResult(coder,seg,seg.outlet,"result");
	}
	coder.indentLess();coder.maybeNewLine();
	coder.packText(`};`);
	coder.newLine();
	if(exportDebug){
		coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
	}
	coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
	coder.newLine();
};

//----------------------------------------------------------------------------
//:AISeg that send keyboard action to page
EditAISeg.regDef({
	name:"AAFKeyboardAction",showName:(($ln==="CN")?("键盘动作"):/*EN*/("K.B. Action")),icon:"keybtn.svg",catalog:["AAF"],
	attrs:{
		...SegObjShellAttr,
		"page":{
			name:"page",showName:"Page",type:"string",key:1,fixed:1,initVal:"aaPage"
		},
		"action":{
			name:"action",showName:(($ln==="CN")?("动作"):/*EN*/("Action")),type:"choice",key:1,fixed:1,initVal:"Type",
			vals:[
				["Type","Type","Type"],
				["KeyPress","Key Press","Key Press"],
				["KeyDown","Key Down","Key Down"],
				["KeyUp","Key Up","Key Up"],
			],
		},
		"query":{
			name:"query",showName:"Query",type:"string",key:1,fixed:1,initVal:"",
			editType:"choice",vals:[],
			showMenu:async function(attr,sender,line,box){
				return await showQueryDlg(attr,sender,line,box);
			}
		},
		"queryHint":{
			name:"queryHint",showName:"Query Hint",type:"string",key:1,fixed:1,initVal:""
		},
		"key":{
			name:"key",showName:"Key or content",type:"string",key:1,fixed:1,initVal:"Enter"
		},
		"options":{
			name:"options",showName:"Options",type:"hyperObj",key:1,fixed:1,initVal:undefined,
			template:function(obj){
				let action;
				action=obj.getAttrVal("action");
				switch(action){
					default:
						return {
							title:"Keyboard options:",label:"",
							properties:{
								delay:{
									type:"auto",label:"Delay between keys:",
									choices:[{text:"50ms",value:50},{text:"100ms",value:100},{text:"200ms",value:300},{text:"500ms",value:500}]
								}
							},
							wrapObject(vo){
								if(!vo.delay){delete vo.delay;}
								return vo;
							}
						};
					case "Type":
						return {
							title:"Type string options:",label:"",
							properties:{
								delay:{
									type:"auto",label:"Delay between keys:",
									choices:[{text:"50ms",value:50},{text:"100ms",value:100},{text:"200ms",value:300},{text:"500ms",value:500}]
								},
								coverEnter:{
									type:"bool",label:"Cover enter:",initValue:false
								}
							},
							wrapObject(vo){
								if(!vo.delay){delete vo.delay;}
								return vo;
							}
						};
				}
			}
		},
		"waitBefore":{
			name:"waitBefore",showName:"Wait Before",type:"int",key:1,fixed:1,initVal:0
		},
		"waitAfter":{
			name:"waitAfter",showName:"Wait After",type:"int",key:1,fixed:1,initVal:0
		},
		"outlet":{
			name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
		},
		"run":{
			name:"run",showName:"Run This Step",type:"auto",key:1,fixed:1,initVal:undefined,editType:"action",
			OnAction:async function(attrObj,sender,attrLine,editBox){
				let seg,page,options,action,query,key;
				seg=attrObj.owner;
				action=seg.getAttrVal("action");
				options=seg.getAttrVal("options");
				query=seg.getAttrVal("query");
				key=seg.getAttrVal("key");
				page=await confirmPage(attrObj,sender);
				if(!page){
					VFACT.app.showTip(sender,"No page assigned.");
					return;
				}
				switch(action){
					case "Type":
						if(query){
							await page.typeOn(query,key,{...options});
						}else{
							await page.keyboardType(key,{...options});
						}
						break;
					case "KeyPress":
						await page.keyboardPress(key,{...options});
						break;
					case "KeyDown":
						await page.keyboardDown(key,{...options});
						break;
					case "KeyUp":
						await page.keyboardUp(key,{...options});
						break;
				}
			}
		}
	},
	listHint:[
		"id","page","action","query","queryHint","key","options","run","waitBefore","waitAfter","codes","desc",
	]
});

DocAIAgentExporter.segTypeExporters["AAFKeyboardAction"]=
function(seg){
	let coder=this.coder;
	let segName=seg.idVal.val;
	let exportDebug=this.isExportDebug();
	segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
	coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
	coder.indentMore();coder.newLine();
	{
		coder.maybeNewLine();
		coder.packText(`let result=true;`);coder.newLine();
		coder.packText(`let pageVal=`);this.genAttrStatement(seg.getAttr("page"));coder.packText(`;`);coder.newLine();
		coder.packText(`let $action=`);this.genAttrStatement(seg.getAttr("action"));coder.packText(`;`);coder.newLine();
		coder.packText(`let $query=`);this.genAttrStatement(seg.getAttr("query"));coder.packText(`;`);coder.newLine();
		coder.packText(`let $queryHint=`);this.genAttrStatement(seg.getAttr("queryHint"));coder.packText(`;`);coder.newLine();
		coder.packText(`let $key=`);this.genAttrStatement(seg.getAttr("key"));coder.packText(`;`);coder.newLine();
		coder.packText(`let $options=`);this.genAttrStatement(seg.getAttr("options"));coder.packText(`;`);coder.newLine();
		coder.packText(`let $waitBefore=`);this.genAttrStatement(seg.getAttr("waitBefore"));coder.packText(`;`);coder.newLine();
		coder.packText(`let $waitAfter=`);this.genAttrStatement(seg.getAttr("waitAfter"));coder.packText(`;`);coder.newLine();
		coder.packText(`let page=context[pageVal];`);coder.newLine();
		coder.packText(`$waitBefore && (await sleep($waitBefore));`);coder.newLine();
		packExtraCodes(coder,seg,"PreCodes");
		coder.packText(`switch($action){`);
		coder.indentMore();coder.newLine();
		{
			//Type
			coder.packText(`case "Type":`);
			coder.indentMore();coder.newLine();
			{
				coder.packText(`if($query||$queryHint){`);
				coder.indentMore();coder.newLine();
				{
					coder.packText(`$query=$queryHint?(await page.confirmQuery($query,$queryHint,"${seg.jaxId}")):$query;`);coder.newLine();
					coder.packText(`if(!$query) throw Error("Missing query. Query hint: "+$queryHint);`);coder.newLine();
					coder.packText(`await page.typeOn("::-p-xpath"+$query,$key,$options||{});`);coder.newLine();
				}
				coder.indentLess();coder.maybeNewLine();
				coder.packText(`}else{`);
				coder.indentMore();coder.newLine();
				{
					coder.packText(`await page.keyboardType($key,$options||{});`);coder.newLine();
				}
				coder.indentLess();coder.maybeNewLine();
				coder.packText(`}`);coder.maybeNewLine();
				coder.packText(`break;`);coder.newLine();
			}
			coder.indentLess();coder.maybeNewLine();

			//KeyPress
			coder.packText(`case "KeyPress":`);
			coder.indentMore();coder.newLine();
			{
				coder.packText(`await page.keyboardPress($key,$options||{});`);coder.newLine();
				coder.packText(`break;`);coder.newLine();
			}
			coder.indentLess();coder.maybeNewLine();

			//KeyDown
			coder.packText(`case "KeyDown":`);
			coder.indentMore();coder.newLine();
			{
				coder.packText(`await page.keyboardDown($key,$options||{});`);coder.newLine();
				coder.packText(`break;`);coder.newLine();
			}
			coder.indentLess();coder.maybeNewLine();

			//KeyUp
			coder.packText(`case "KeyUp":`);
			coder.indentMore();coder.newLine();
			{
				coder.packText(`await page.keyboardUp($key,$options||{});`);coder.newLine();
				coder.packText(`break;`);coder.newLine();
			}
			coder.indentLess();coder.maybeNewLine();
		}
		coder.indentLess();coder.maybeNewLine();
		coder.packText(`}`);
		coder.packText(`$waitAfter && (await sleep($waitAfter))`);coder.newLine();
		packExtraCodes(coder,seg,"PostCodes");
		packResult(coder,seg,seg.outlet,"result");
	}
	coder.indentLess();coder.maybeNewLine();
	coder.packText(`};`);
	coder.newLine();
	if(exportDebug){
		coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
	}
	coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
	coder.newLine();
};

//----------------------------------------------------------------------------
//:AISeg that read page content
EditAISeg.regDef({
	name:"AAFReadPage",showName:(($ln==="CN")?("读取页面"):/*EN*/("Read Page")),icon:"read.svg",catalog:["AAF"],
	attrs:{
		...SegObjShellAttr,
		"page":{
			name:"page",showName:"Page",type:"string",key:1,fixed:1,initVal:"aaPage"
		},
		"target":{
			name:"target",showName:"Read Target",type:"choice",key:1,fixed:1,initVal:"cleanHTML",
			vals:[
				["cleanHTML","CleanHTML","Cleaned HTML"],
				["html","HTML","Inner HTML"],
				["view","View","AAE Tagged Node View"],
				["text","Text","Inner Text"],
				["article","Article","Article"],
			],
		},
		"node":{
			name:"node",showName:"Read Node",type:"auto",key:1,fixed:1,initVal:null,
			editType:"choice",vals:[],
			showMenu:async function(attr,sender,line,box){
				return await showQueryDlg(attr,sender,line,box);
			}
		},
		"options":{
			name:"options",showName:"Options",type:"hyperObj",key:1,fixed:1,initVal:undefined,
			template:function(obj){
				let target;
				target=obj.getAttrVal("target");
				switch(target){
					case "cleanHTML":
						return {
							title:"Read page options:",label:"",
							properties:{
								compact:{
									type:"int",label:"Compact level:",initValue:undefined,
									choices:[
										{text:"0: None",value:"0"},
										{text:"1: Remove none render elements",value:1},
										{text:"2: Also remove hidden elements",value:2},
										{text:"3: Also remove helper AAE-atrributes",value:3},
										{text:"4: Also shorten text longer than 50 chars",value:4},
										{text:"5: Also merge isolated div element",value:5},
									]
								},
								cleanMarks:{
									type:"bool",label:"Clean all AAE-attributes: ",initValue:false,
								}
							}
						};
						break;
					case "html":
						return {
							title:"Read page options:",label:"",
							properties:{
								removeHidden:{
									type:"bool",label:"Remove hidden elements: ",initValue:true,
								},
								excludeNodeTags:{
									type:"auto",label:"Exclude node-tags:",initValue:true,
								},
								excludeNodeTypes:{
									type:"auto",label:"Exclude node-types:",initValue:false,
								},
								shortText:{
									type:"int",label:"Shorten text longer than: ",initValue:0,
									desc:"Set to zero to ignore."
								},
								cleanMarks:{
									type:"bool",label:"Clean all AAE-attributes: ",initValue:false,
								}
							},
							wrapObject(vo){
								return vo;
							}
						};
					default:
						return {
							title:"Read page options:",label:"",
							properties:{
								removeHidden:{
									type:"bool",label:"Remove hidden elements: ",initValue:true,
								},
								excludeNodeTags:{
									type:"bool",label:"Exclude node-tag-names:",initValue:true,
								},
								excludeNodeTypes:{
									type:"bool",label:"Exclude node-types:",initValue:true,
								}
							}
						};
				}
			}
		},
		"waitBefore":{
			name:"waitBefore",showName:"Wait Before",type:"int",key:1,fixed:1,initVal:0
		},
		"waitAfter":{
			name:"waitAfter",showName:"Wait After",type:"int",key:1,fixed:1,initVal:0
		},
		"outlet":{
			name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
		},
		"run":{
			name:"run",showName:"Run This Step",type:"auto",key:1,fixed:1,initVal:undefined,editType:"action",
			OnAction:async function(attrObj,sender,attrLine,editBox){
				let seg,page,options,target,query,result;
				seg=attrObj.owner;
				target=seg.getAttrVal("target");
				options=seg.getAttrVal("options");
				query=seg.getAttrVal("query")||null;
				page=await confirmPage(attrObj,sender);
				if(!page){
					VFACT.app.showTip(sender,"No page assigned.");
					return;
				}
				switch(target){
					case "cleanHTML":
						result=await page.readInnerHTML(query,{compact:2});
						break;
					case "html":
						result=await page.readInnerHTML(query,null);
						break;
					case "view":
						result=await page.readView(query,null);
						break;
					case "text":
						result=await page.readInnerText(query,null);
						break;
					case "article":
						result=await page.readArticle(query,null);
						break;
				}
				if(result){
					console.log("Action result:");
					console.log(result);
					//TODO: show edit-dialog:
				}
			}
		}
	},
	listHint:[
		"id","page","target","node","options","run","waitBefore","waitAfter","codes","desc",
	]
});

DocAIAgentExporter.segTypeExporters["AAFReadPage"]=
function(seg){
	let coder=this.coder;
	let segName=seg.idVal.val;
	let exportDebug=this.isExportDebug();
	segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
	coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
	coder.indentMore();coder.newLine();
	{
		coder.maybeNewLine();
		coder.packText(`let result=null;`);coder.newLine();
		coder.packText(`let pageVal=`);this.genAttrStatement(seg.getAttr("page"));coder.packText(`;`);coder.newLine();
		coder.packText(`let $target=`);this.genAttrStatement(seg.getAttr("target"));coder.packText(`;`);coder.newLine();
		coder.packText(`let $node=`);this.genAttrStatement(seg.getAttr("node"));coder.packText(`;`);coder.newLine();
		coder.packText(`let $options=`);this.genAttrStatement(seg.getAttr("options"));coder.packText(`;`);coder.newLine();
		coder.packText(`let $waitBefore=`);this.genAttrStatement(seg.getAttr("waitBefore"));coder.packText(`;`);coder.newLine();
		coder.packText(`let $waitAfter=`);this.genAttrStatement(seg.getAttr("waitAfter"));coder.packText(`;`);coder.newLine();
		coder.packText(`let page=context[pageVal];`);coder.newLine();
		coder.packText(`$waitBefore && (await sleep($waitBefore));`);coder.newLine();
		packExtraCodes(coder,seg,"PreCodes");
		coder.packText(`switch($target){`);
		coder.indentMore();coder.newLine();
		{
			//Cleaned HTML:
			coder.packText(`case "cleanHTML":`);
			coder.indentMore();coder.newLine();
			{
				coder.packText(`result=await page.readInnerHTML($node,{compact:2,...$options});`);coder.newLine();
				coder.packText(`break;`);coder.newLine();
			}
			coder.indentLess();coder.maybeNewLine();
			
			//Inner HTML:
			coder.packText(`case "html":`);
			coder.indentMore();coder.newLine();
			{
				coder.packText(`result=await page.readInnerHTML($node,{...$options});`);coder.newLine();
				coder.packText(`break;`);coder.newLine();
			}
			coder.indentLess();coder.maybeNewLine();

			//Node View:
			coder.packText(`case "view":`);
			coder.indentMore();coder.newLine();
			{
				coder.packText(`result=await page.readView($node,{...$options});`);coder.newLine();
				coder.packText(`break;`);coder.newLine();
			}
			coder.indentLess();coder.maybeNewLine();

			//Inner Text:
			coder.packText(`case "text":`);
			coder.indentMore();coder.newLine();
			{
				coder.packText(`result=await page.readInnerText($node,{...$options});`);coder.newLine();
				coder.packText(`break;`);coder.newLine();
			}
			coder.indentLess();coder.maybeNewLine();

			//Article:
			coder.packText(`case "article":`);
			coder.indentMore();coder.newLine();
			{
				coder.packText(`result=await page.readArticle($node,{...$options});`);coder.newLine();
				coder.packText(`break;`);coder.newLine();
			}
			coder.indentLess();coder.maybeNewLine();

		}
		coder.indentLess();coder.maybeNewLine();
		coder.packText(`}`);
		coder.packText(`$waitAfter && (await sleep($waitAfter))`);coder.newLine();
		packExtraCodes(coder,seg,"PostCodes");
		packResult(coder,seg,seg.outlet,"result");
	}
	coder.indentLess();coder.maybeNewLine();
	coder.packText(`};`);
	coder.newLine();
	if(exportDebug){
		coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
	}
	coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
	coder.newLine();
};

//----------------------------------------------------------------------------
//:AISeg that query node(s) in page
EditAISeg.regDef({
	name:"AAFQuery",showName:(($ln==="CN")?("查询元素"):/*EN*/("Query Node(s)")),icon:"/@aae/assets/wait_find.svg",catalog:["AAF"],
	attrs:{
		...SegObjShellAttr,
		"page":{
			name:"page",showName:"Page",type:"string",key:1,fixed:1,initVal:"aaPage"
		},
		"node":{
			name:"node",showName:"From Node",type:"auto",key:1,fixed:1,initVal:undefined
		},
		"query":{
			name:"query",showName:"Query",type:"string",key:1,fixed:1,initVal:"",
			editType:"choice",vals:[],
			showMenu:async function(attr,sender,line,box){
				return await showQueryDlg(attr,sender,line,box);
			}
		},
		"queryHint":{
			name:"queryHint",showName:"Query Hint",type:"string",key:1,fixed:1,initVal:""
		},
		"multi":{
			name:"multi",showName:"Multiple",type:"bool",key:1,fixed:1,initVal:false
		},
		"options":{
			name:"options",showName:"Options",type:"auto",key:1,fixed:1,initVal:undefined
		},
		"waitBefore":{
			name:"waitBefore",showName:"Wait Before",type:"int",key:1,fixed:1,initVal:0
		},
		"waitAfter":{
			name:"waitAfter",showName:"Wait After",type:"int",key:1,fixed:1,initVal:0
		},
		"outlet":{
			name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
		},
	},
	listHint:[
		"id","page","node","query","queryHint","multi","options","waitBefore","waitAfter","codes","desc",
	]
});

DocAIAgentExporter.segTypeExporters["AAFQuery"]=
function(seg){
	let coder=this.coder;
	let segName=seg.idVal.val;
	let exportDebug=this.isExportDebug();
	segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
	coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
	coder.indentMore();
	coder.newLine();
	{
		coder.maybeNewLine();
		coder.packText(`let result=true;`);coder.newLine();
		coder.packText(`let pageVal=`);this.genAttrStatement(seg.getAttr("page"));coder.packText(`;`);coder.newLine();
		coder.packText(`let $node=`);this.genAttrStatement(seg.getAttr("node"));coder.packText(`;`);coder.newLine();
		coder.packText(`let $query=`);this.genAttrStatement(seg.getAttr("query"));coder.packText(`;`);coder.newLine();
		coder.packText(`let $multi=`);this.genAttrStatement(seg.getAttr("multi"));coder.packText(`;`);coder.newLine();
		coder.packText(`let $options=`);this.genAttrStatement(seg.getAttr("options"));coder.packText(`;`);coder.newLine();
		coder.packText(`let $waitBefore=`);this.genAttrStatement(seg.getAttr("waitBefore"));coder.packText(`;`);coder.newLine();
		coder.packText(`let $waitAfter=`);this.genAttrStatement(seg.getAttr("waitAfter"));coder.packText(`;`);coder.newLine();
		coder.packText(`let page=context[pageVal];`);coder.newLine();
		coder.packText(`$waitBefore && (await sleep($waitBefore));`);coder.newLine();
		packExtraCodes(coder,seg,"PreCodes");
		coder.packText(`if($multi){`);
		coder.indentMore();coder.newLine();
		{
			coder.packText(`result=await page.queryNodes($node,$query,$options);`);coder.newLine();
		}
		coder.indentLess();coder.maybeNewLine();
		coder.packText(`}else{`);
		coder.indentMore();coder.newLine();
		{
			coder.packText(`result=await page.queryNode($node,$query,$options);`);coder.newLine();
		}
		coder.indentLess();coder.maybeNewLine();
		coder.packText(`}`);
		
		coder.packText(`$waitAfter && (await sleep($waitAfter))`);coder.newLine();
		packExtraCodes(coder,seg,"PostCodes");
		packResult(coder,seg,seg.outlet,"result");
	}
	coder.indentLess();
	coder.newLine();
	coder.packText(`};`);
	coder.newLine();
	if(exportDebug){
		coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
	}
	coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
	coder.newLine();
};

//----------------------------------------------------------------------------
//:AISeg that execute an action script:
if(false){
EditAISeg.regDef({
	name:"AAFRunActions",showName:(($ln==="CN")?("执行动作脚本"):/*EN*/("Run actions")),icon:"/@aae/assets/wait_gas.svg",catalog:["AAF"],
	attrs:{
		...SegObjShellAttr,
		"page":{
			name:"page",showName:"Page",type:"string",key:1,fixed:1,initVal:"aaPage"
		},
		"script":{
			name:"flag",showName:"Script",type:"file",key:1,fixed:1,initVal:""
		},
		"arguments":{
			name:"arguments",showName:"Arguments",type:"auto",key:1,fixed:1,initVal:{}
		},
		"waitBefore":{
			name:"waitBefore",showName:"Wait Before",type:"int",key:1,fixed:1,initVal:0
		},
		"waitAfter":{
			name:"waitAfter",showName:"Wait After",type:"int",key:1,fixed:1,initVal:0
		},
		"outlet":{
			name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
		},
	},
	listHint:[
		"id","page","script","arguments","waitBefore","waitAfter","codes","desc",
	]
});

DocAIAgentExporter.segTypeExporters["AAFRunActions"]=
function(seg){
	let coder=this.coder;
	let segName=seg.idVal.val;
	let exportDebug=this.isExportDebug();
	segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
	coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
	coder.indentMore();coder.newLine();
	{
		coder.maybeNewLine();
		coder.packText(`let result=true;`);coder.newLine();
		coder.packText(`let pageVal=`);this.genAttrStatement(seg.getAttr("page"));coder.packText(`;`);coder.newLine();
		coder.packText(`let script=`);this.genAttrStatement(seg.getAttr("script"));coder.packText(`;`);coder.newLine();
		coder.packText(`let path=pathLib.joinTabOSURL(basePath,script);`);coder.newLine();
		coder.packText(`let arguments=`);this.genAttrStatement(seg.getAttr("arguments"));coder.packText(`;`);coder.newLine();
		coder.packText(`let waitBefore=`);this.genAttrStatement(seg.getAttr("waitBefore"));coder.packText(`;`);coder.newLine();
		coder.packText(`let waitAfter=`);this.genAttrStatement(seg.getAttr("waitAfter"));coder.packText(`;`);coder.newLine();
		coder.packText(`let page=context[pageVal];`);coder.newLine();
		coder.packText(`script=await (await fetch(path)).json();`);coder.newLine();
		coder.packText(`waitBefore && (await sleep(waitBefore));`);coder.newLine();
		packExtraCodes(coder,seg,"PreCodes");
		coder.packText(`await page.runActionChain(script.actions,arguments);`);coder.newLine();
		coder.packText(`waitAfter && (await sleep(waitAfter))`);coder.newLine();
		packExtraCodes(coder,seg,"PostCodes");
		packResult(coder,seg,seg.outlet,"result");
	}
	coder.indentLess();coder.maybeNewLine();
	coder.packText(`};`);
	coder.newLine();
	if(exportDebug){
		coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
	}
	coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
	coder.newLine();
};
}

//----------------------------------------------------------------------------
//:AISeg start page trace:
EditAISeg.regDef({
	name:"AAFTraceEvents",showName:(($ln==="CN")?("追踪事件"):/*EN*/("Trace Events")),icon:"/@aae/assets/wait_trace.svg",catalog:["AAF"],reverseOutlets:true,
	attrs:{
		...SegObjShellAttr,
		"page":{
			name:"page",showName:"Page",type:"string",key:1,fixed:1,initVal:"aaPage"
		},
		"async":{
			name:"async",showName:"Async",type:"bool",key:1,fixed:1,initVal:false
		},
		"outlet":{
			name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
			attrs:{
				"id":{
					name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"Done",
				},
			},
		},
		"catchlet":{
			name:"catchlet",showName:"Catch",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
			attrs:{
				"id":{
					name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"OnEvent",
				},
			},
		}
	},
	listHint:["id","page","async","codes","desc"],
});

DocAIAgentExporter.segTypeExporters["AAFTraceEvents"]=
function(seg){
	let coder=this.coder;
	let segName=seg.idVal.val;
	let exportDebug=this.isExportDebug();
	let asyncMode=seg.getAttrVal("async");
	segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
	coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
	coder.indentMore();
	coder.newLine();
	{
		coder.maybeNewLine();
		coder.packText(`let result=true;`);coder.newLine();
		coder.packText(`let pageVal=`);this.genAttrStatement(seg.getAttr("page"));coder.packText(`;`);coder.newLine();
		coder.packText(`let page=context[pageVal];`);coder.newLine();
		coder.packText(`let callback,cr`);coder.newLine();
		packExtraCodes(coder,seg,"PreCodes");
		coder.packText(`callback=async function(event){`);
		coder.indentMore();coder.newLine();
		{
			let outlet=seg.catchlet||null;
			if(outlet){
				packExtraCodes(coder,seg,"PreEvent");
				coder.packText(`cr=`);this.packSegRun(coder,seg,outlet,"event",false);coder.newLine();
				packExtraCodes(coder,seg,"PostEvent");
				coder.packText(`if(cr===true){`);
				coder.indentMore();coder.newLine();
				{
					coder.packText(`page.stopTrace(callback);`);
				}
				coder.indentLess();coder.maybeNewLine();
				coder.packText(`}`);coder.newLine();
			}
		}
		coder.indentLess();coder.maybeNewLine();
		coder.packText(`};`);coder.newLine();
		if(asyncMode){
			coder.packText(`page.startTrace(callback);`);
		}else{
			coder.packText(`await page.startTrace(callback);`);
		}
		packExtraCodes(coder,seg,"PostCodes");
		packResult(coder,seg,seg.outlet,"result",false);
	}
	coder.indentLess();
	coder.newLine();
	coder.packText(`};`);
	coder.newLine();
	if(exportDebug){
		coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
	}
	coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
	coder.newLine();
};

//----------------------------------------------------------------------------
//:AISeg that upload file to exchange-zone
EditAISeg.regDef({
	name:"AAFUploadFile",showName:(($ln==="CN")?("准备文件"):/*EN*/("Push File")),icon:"/@aae/assets/wait_upload.svg",catalog:["AAF"],
	attrs:{
		...SegObjShellAttr,
		"fileName":{
			name:"fileName",showName:(($ln==="CN")?("文件名"):/*EN*/("File Name")),type:"string",key:1,fixed:1,initVal:""
		},
		"fileData":{
			name:"fileData",showName:(($ln==="CN")?("文件数据"):/*EN*/("File Data")),type:"auto",key:1,fixed:1,initVal:undefined
		},
		"waitBefore":{
			name:"waitBefore",showName:"Wait Before",type:"int",key:1,fixed:1,initVal:0
		},
		"waitAfter":{
			name:"waitAfter",showName:"Wait After",type:"int",key:1,fixed:1,initVal:0
		},
		"outlet":{
			name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
		},
	},
	listHint:[
		"id","fileName","fileData","waitBefore","waitAfter","codes","desc",
	]
});

DocAIAgentExporter.segTypeExporters["AAFUploadFile"]=
function(seg){
	let coder=this.coder;
	let segName=seg.idVal.val;
	let exportDebug=this.isExportDebug();
	segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
	coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
	coder.indentMore();coder.newLine();
	{
		coder.maybeNewLine();
		coder.packText(`let result=true;`);coder.newLine();
		coder.packText(`let $fileName=`);this.genAttrStatement(seg.getAttr("fileName"));coder.packText(`;`);coder.newLine();
		coder.packText(`let $fileData=`);this.genAttrStatement(seg.getAttr("fileData"));coder.packText(`;`);coder.newLine();
		coder.packText(`let $waitBefore=`);this.genAttrStatement(seg.getAttr("waitBefore"));coder.packText(`;`);coder.newLine();
		coder.packText(`let $waitAfter=`);this.genAttrStatement(seg.getAttr("waitAfter"));coder.packText(`;`);coder.newLine();
		coder.packText(`$waitBefore && (await sleep($waitBefore));`);coder.newLine();
		packExtraCodes(coder,seg,"PreCodes");
		coder.packText(`await context.aaBrowser.saveFile($fileName,$fileData);`);coder.newLine();
		coder.packText(`$waitAfter && (await sleep($waitAfter))`);coder.newLine();
		packExtraCodes(coder,seg,"PostCodes");
		packResult(coder,seg,seg.outlet,"result");
	}
	coder.indentLess();coder.maybeNewLine();
	coder.packText(`};`);
	coder.newLine();
	if(exportDebug){
		coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
	}
	coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
	coder.newLine();
};

//----------------------------------------------------------------------------
//:AISeg that handle (accept or dissmiss) dialog
EditAISeg.regDef({
	name:"AAFHandleDialog",showName:(($ln==="CN")?("处理对话框"):/*EN*/("Handle Dialog")),icon:"/@aae/assets/wait_dialog.svg",catalog:["AAF"],
	attrs:{
		...SegObjShellAttr,
		"page":{
			name:"page",showName:"Page",type:"string",key:1,fixed:1,initVal:"aaPage"
		},
		"action":{
			name:"action",showName:(($ln==="CN")?("动作"):/*EN*/("Action")),type:"choice",key:1,fixed:1,initVal:"accept",
			vals:[
				["accept","Accept","Accept"],
				["dissmiss","Dissmiss","Dissmiss"],
			]
		},
		"text":{
			name:"text",showName:(($ln==="CN")?("文本"):/*EN*/("Text")),type:"string",key:1,fixed:1,initVal:""
		},
		"fileName":{
			name:"fileName",showName:(($ln==="CN")?("文件名"):/*EN*/("File Name")),type:"string",key:1,fixed:1,initVal:""
		},
		"waitBefore":{
			name:"waitBefore",showName:"Wait Before",type:"int",key:1,fixed:1,initVal:0
		},
		"waitAfter":{
			name:"waitAfter",showName:"Wait After",type:"int",key:1,fixed:1,initVal:0
		},
		"outlet":{
			name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
		},
	},
	listHint:[
		"id","page","action","text","fileName","waitBefore","waitAfter","codes","desc",
	],
	OnAttrEdit(box,attr,value){
		if(!attr || attr.name==="action"){
			let action=this.getAttrVal("action");
			switch(action){
				case "accept":
					box.showAttrLine(this.getAttr("text"));
					box.showAttrLine(this.getAttr("fileName"));
					break;
				default:
					box.hideAttrLine(this.getAttr("text"));
					box.hideAttrLine(this.getAttr("fileName"));
					break;
			}
		}
	}
});

DocAIAgentExporter.segTypeExporters["AAFHandleDialog"]=
function(seg){
	let coder=this.coder;
	let segName=seg.idVal.val;
	let exportDebug=this.isExportDebug();
	segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
	coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
	coder.indentMore();coder.newLine();
	{
		coder.maybeNewLine();
		coder.packText(`let result=true;`);coder.newLine();
		coder.packText(`let $pageVal=`);this.genAttrStatement(seg.getAttr("page"));coder.packText(`;`);coder.newLine();
		coder.packText(`let $action=`);this.genAttrStatement(seg.getAttr("action"));coder.packText(`;`);coder.newLine();
		coder.packText(`let $text=`);this.genAttrStatement(seg.getAttr("text"));coder.packText(`;`);coder.newLine();
		coder.packText(`let $fileName=`);this.genAttrStatement(seg.getAttr("fileName"));coder.packText(`;`);coder.newLine();
		coder.packText(`let $waitBefore=`);this.genAttrStatement(seg.getAttr("waitBefore"));coder.packText(`;`);coder.newLine();
		coder.packText(`let $waitAfter=`);this.genAttrStatement(seg.getAttr("waitAfter"));coder.packText(`;`);coder.newLine();
		coder.packText(`let $page=context[$pageVal];`);coder.newLine();
		coder.packText(`$waitBefore && (await sleep($waitBefore));`);coder.newLine();
		packExtraCodes(coder,seg,"PreCodes");
		coder.packText(`if($action==="accept"){`);coder.indentMore();coder.newLine();
		{
			coder.packText(`await $page.acceptDialog($text,$fileName?[$fileName]:null);`);coder.newLine();
		}
		coder.indentLess();coder.maybeNewLine();coder.packText(`}else{`);coder.indentMore();coder.newLine();
		{
			coder.packText(`await $page.dissmissDialog();`);coder.newLine();
		}
		coder.indentLess();coder.maybeNewLine();coder.packText(`}`);coder.newLine();
		coder.packText(`$waitAfter && (await sleep($waitAfter))`);coder.newLine();
		packExtraCodes(coder,seg,"PostCodes");
		packResult(coder,seg,seg.outlet,"result");
	}
	coder.indentLess();coder.maybeNewLine();
	coder.packText(`};`);
	coder.newLine();
	if(exportDebug){
		coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
	}
	coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
	coder.newLine();
};


