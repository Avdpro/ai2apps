const messageAskTask={
	"from":"Alice@crew.ai2apps.com",
	"to":"Tom@crew.ai2apps.com",
	"task":"TASK_ALICE_199",
	"time":123456,
	"timeString":123456,
	"content":[
		{type:"text",content:"I need a picture of Panda like this pic, but in SIFI style"},
		{type:"image",url:"data:..."},
	]
};

const messageReplyTask={
	"from":"Tom@crew.ai2apps.com",
	"to":"Alice@crew.ai2apps.com",
	"task":"TASK_ALICE_199",
	"content":[
		{type:"text",content:"Here is your pic"},
		{type:"image",url:"data:..."},
	]
};

const meetingDisscuss={
	"from":"Alice@crew.ai2apps.com",
	"to":"meeting123@meeting.ai2apps.com",
	"round":"123",
	"content":[
		{type:"text",content:"I think tom should give us some numbers about this topic?"},
	]
};

const meetingVO={
	id:"meeting123@meeting.ai2apps.com",
	members:["Alice@crw.ai2apps.com","Jonh@crw.ai2apps.com","Tom@crw.ai2apps.com"],
	project:"rocket@prjoect.ai2apps.com",
	topic:"Review meeting for the rocket project.",
	context:"Rocket project is done.",
	rounds:[
		{
			talks:[
				{
					from:"Alice@...",
					content:[
						{type:"text",content:"Let's wrap this project."}
					]
				}
			]
		}
	]
};
const projectVO={
	id:"PRJ123",
	name:"DailyPost",
	owner:"Alice@...",
	startTime:12345,
	liveTasks:[],
	logs:[],
	closedTasks:[],
};
