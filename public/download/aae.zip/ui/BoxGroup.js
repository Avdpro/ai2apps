//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1I1BV49TB0StartDoc*/
/*}#1I1BV49TB0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BoxGroup=function(groupVO){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1I1BV49TB1LocalVals*/
	/*}#1I1BV49TB1LocalVals*/
	
	/*#{1I1BV49TB1PreState*/
	/*}#1I1BV49TB1PreState*/
	state={
		"toolNum":groupVO.tools.length+(groupVO.chains?groupVO.chains.length:0),"icon":appCfg.sharedAssets+"/browser.svg","label":groupVO.label||groupVO.name||groupVO.host,
		/*#{1I1BV49TC3ExState*/
		/*}#1I1BV49TC3ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1I1BV49TB1PostState*/
	let icon=groupVO.icon;
	if(icon){
		if(icon[0]!=="/"){
			icon=appCfg.sharedAssets+"/"+icon;
		}
		state.icon=icon;
	}
	let label=state.label;
	if(typeof(label)==="object"){
		label=label[$ln]||label["EN"];
		state.label=label;
	}
	/*}#1I1BV49TB1PostState*/
	cssVO={
		"hash":"1I1BV49TB1",nameHost:true,
		"type":"box","position":"relative","x":125,"y":35,"w":250,"h":70,"anchorX":1,"anchorY":1,"cursor":"pointer","margin":10,"padding":10,"minW":"","minH":"",
		"maxW":"","maxH":"","styleClass":"","background":cfgColor["body"],"border":1,"borderColor":cfgColor["secondary"],"corner":12,"contentLayout":"flex-x",
		children:[
			{
				"hash":"1IATBSDNR0",
				"type":"hud","position":"relative","x":0,"y":0,"w":50,"h":50,"uiEvent":-1,"styleClass":"",
				children:[
					{
						"hash":"1IATBSSOC0",
						"type":"image","position":"relative","x":"50%","y":"50%","w":50,"h":50,"anchorX":1,"anchorY":1,"uiEvent":-1,"padding":0,"minW":"","minH":"","maxW":"",
						"maxH":"","styleClass":"","image":$P(()=>(state.icon),state),"fitSize":true,
					}
				],
			},
			{
				"hash":"1I1BVAH750",
				"type":"hud","position":"relative","x":0,"y":0,"w":100,"h":"100%","uiEvent":-1,"margin":[0,0,0,5],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"flex":true,
				children:[
					{
						"hash":"1I1BVE9S90",
						"type":"text","x":0,"y":">calc(50% - 5px)","w":"100%","h":"","anchorY":1,"uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
						"text":$P(()=>(state.label),state),"fontWeight":"normal","fontStyle":"normal","textDecoration":"","ellipsis":true,
					},
					{
						"hash":"1I1BVI0RD0",
						"type":"text","x":0,"y":"100%","w":"100%","h":"","anchorY":2,"uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
						"text":(($ln==="CN")?($P(()=>(state.toolNum?(""+state.toolNum+"个项目"):"暂无项目"),state)):($P(()=>(""+state.toolNum+" Items"),state))),"fontSize":txtSize.smallPlus,
						"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignH":2,"alignV":1,
					}
				],
			}
		],
		/*#{1I1BV49TB1ExtraCSS*/
		/*}#1I1BV49TB1ExtraCSS*/
		faces:{
			"normal":{
				"#self":{
					"border":1,"padding":10,"background":cfgColor["body"]
				},
				"#1IATBSSOC0":{
					"alpha":0.7,"w":50,"h":50
				},
				"#1I1BVE9S90":{
					"color":cfgColor["fontBodySub"]
				},
				"#1I1BVI0RD0":{
					"color":cfgColor["fontBodySub"]
				}
			},"hover":{
				"#self":{
					"border":2,"padding":9,"background":cfgColor["body"]
				},
				"#1IATBSSOC0":{
					"alpha":1,"w":54,"h":54
				},
				"#1I1BVE9S90":{
					"color":cfgColor["fontBody"]
				},
				"#1I1BVI0RD0":{
					"color":cfgColor["fontBody"]
				}
			}
		},
		OnCreate:function(){
			self=this;
			
			/*#{1I1BV49TB1Create*/
			self.showFace("normal");
			self.aniShow();
			/*}#1I1BV49TB1Create*/
		},
		/*#{1I1BV49TB1EndCSS*/
		/*}#1I1BV49TB1EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.OnMouseInOut=function(isIn,event){
		/*#{1I1C0SC290FunctionBody*/
		if(isIn){
			self.showFace("hover");
		}else{
			self.showFace("normal");
		}
		/*}#1I1C0SC290FunctionBody*/
	};
	//------------------------------------------------------------------------
	cssVO.aniShow=async function(){
		/*#{1I1I5LB920Start*/
		self.animate({type:"in",scale:0.8,alpha:0.5,time:50+Math.floor(Math.random()*5)*50});
		/*}#1I1I5LB920Start*/
	};
	/*#{1I1BV49TB1PostCSSVO*/
	/*}#1I1BV49TB1PostCSSVO*/
	cssVO.constructor=BoxGroup;
	return cssVO;
};
/*#{1I1BV49TB1ExCodes*/
/*}#1I1BV49TB1ExCodes*/

//----------------------------------------------------------------------------
BoxGroup.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1I1BV49TB1PreAISpot*/
	/*}#1I1BV49TB1PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1I1BV49TB1PostAISpot*/
	/*}#1I1BV49TB1PostAISpot*/
	return exposeVO;
};

//----------------------------------------------------------------------------
BoxGroup.gearExport={
	framework: "jax",
	hudType: "box",
	"showName":"",icon:"gears.svg",previewImg:false,
	fixPose:false,initW:100,initH:100,
	catalog:"",
	args: {
		"groupVO": {
			"name": "groupVO", "showName": "groupVO", "type": "auto", "key": true, "fixed": true, 
			"initVal": {"label":"www.google.com","tools":[1,2,3,4,5],"chains":[1,2,3]}, "initValText": "#{label:\"www.google.com\",tools:[1,2,3,4,5],chains:[1,2,3]}"
		}
	},
	state:{
	},
	properties:["id","position","x","y","display"],
	faces:["normal","hover"],
	subContainers:{
	},
	/*#{1I1BV49TB0ExGearInfo*/
	/*}#1I1BV49TB0ExGearInfo*/
};
/*#{1I1BV49TB0EndDoc*/
/*}#1I1BV49TB0EndDoc*/

export default BoxGroup;
export{BoxGroup};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearBox",
//	"jaxId": "1I1BV49TB0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1I1BV49TB2",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1I1BV49TB3",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1I1BV49TC0",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1I1BV49TC1",
//			"attrs": {
//				"groupVO": {
//					"type": "auto",
//					"valText": "#{label:\"www.google.com\",tools:[1,2,3,4,5],chains:[1,2,3]}"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1I1BV49TC2",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1I1BV49TC3",
//			"attrs": {
//				"toolNum": {
//					"type": "auto",
//					"valText": "#groupVO.tools.length+(groupVO.chains?groupVO.chains.length:0)"
//				},
//				"icon": {
//					"type": "string",
//					"valText": "#appCfg.sharedAssets+\"/browser.svg\""
//				},
//				"label": {
//					"type": "string",
//					"valText": "#groupVO.label||groupVO.name||groupVO.host"
//				}
//			}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I1I5LB920",
//					"attrs": {
//						"id": "aniShow",
//						"label": "New AI Seg",
//						"x": "65",
//						"y": "70",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I1I5LMEB0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I1I5LMEB1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I1I5LMEB2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					}
//				}
//			]
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1I1BV49TC4",
//			"attrs": {
//				"normal": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1I1C0L4OK0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1I1C0MC0Q0",
//							"attrs": {}
//						}
//					}
//				},
//				"hover": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1I1C0LEE30",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1I1C0MC0Q1",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1I1BV49TC5",
//			"attrs": {}
//		},
//		"exposeToAI": "true",
//		"descAI": "",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "box",
//			"jaxId": "1I1BV49TB1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1I1BV49TC6",
//					"attrs": {
//						"type": "box",
//						"id": "",
//						"position": "Relative",
//						"x": "125",
//						"y": "35",
//						"w": "250",
//						"h": "70",
//						"anchorH": "Center",
//						"anchorV": "Center",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "pointer",
//						"zIndex": "0",
//						"margin": "10",
//						"padding": "10",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"background": "#cfgColor[\"body\"]",
//						"border": "1",
//						"borderStyle": "Solid",
//						"borderColor": "#cfgColor[\"secondary\"]",
//						"corner": "12",
//						"shadow": "false",
//						"shadowX": "2",
//						"shadowY": "2",
//						"shadowBlur": "3",
//						"shadowSpread": "0",
//						"shadowColor": "[0,0,0,0.50]",
//						"contentLayout": "Flex X"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1IATBSDNR0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IATBTC3M0",
//									"attrs": {
//										"type": "hud",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "50",
//										"h": "50",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": ""
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "image",
//											"jaxId": "1IATBSSOC0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IATBSSOC1",
//													"attrs": {
//														"type": "image",
//														"id": "",
//														"position": "relative",
//														"x": "50%",
//														"y": "50%",
//														"w": "50",
//														"h": "50",
//														"anchorH": "Center",
//														"anchorV": "Center",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "Tree Off",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "0",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"image": "${state.icon},state",
//														"autoSize": "false",
//														"fitSize": "Fit",
//														"repeat": "true",
//														"alignX": "Left",
//														"alignY": "Top"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IATBSSOD0",
//													"attrs": {
//														"1I1C0LEE30": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IATBSSOD1",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IATBSSOD2",
//																	"attrs": {
//																		"alpha": {
//																			"type": "number",
//																			"valText": "1",
//																			"editMode": "range",
//																			"editType": "range"
//																		},
//																		"w": {
//																			"type": "length",
//																			"valText": "54"
//																		},
//																		"h": {
//																			"type": "length",
//																			"valText": "54"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I1C0LEE30",
//															"faceTagName": "hover"
//														},
//														"1I1C0L4OK0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IATBSSOD3",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IATBSSOD4",
//																	"attrs": {
//																		"alpha": {
//																			"type": "number",
//																			"valText": "0.7",
//																			"editMode": "range",
//																			"editType": "range"
//																		},
//																		"w": {
//																			"type": "length",
//																			"valText": "50"
//																		},
//																		"h": {
//																			"type": "length",
//																			"valText": "50"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I1C0L4OK0",
//															"faceTagName": "normal"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IATBSSOD5",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IATBSSOD6",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1IATBTC3M1",
//									"attrs": {
//										"1I1C0L4OK0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IATBTQ6Q0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IATBTQ6Q1",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I1C0L4OK0",
//											"faceTagName": "normal"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1IATBTC3M2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IATBTC3M3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1I1BVAH750",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I1C00RP44",
//									"attrs": {
//										"type": "hud",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,5]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"flex": "true"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1I1BVE9S90",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I1C00RP45",
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "Absolute",
//														"x": "0",
//														"y": "50%-5",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Center",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "Tree Off",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBody\"]",
//														"text": "${state.label},state",
//														"font": "",
//														"fontSize": "16",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "true",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I1C00RP46",
//													"attrs": {
//														"1I1C0LEE30": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I1C0MC0Q6",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I1C0MC0Q7",
//																	"attrs": {
//																		"color": {
//																			"type": "colorRGB",
//																			"valText": "#cfgColor[\"fontBody\"]"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I1C0LEE30",
//															"faceTagName": "hover"
//														},
//														"1I1C0L4OK0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I1C0MC0Q8",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I1C0MC0Q9",
//																	"attrs": {
//																		"color": {
//																			"type": "colorRGB",
//																			"valText": "#cfgColor[\"fontBodySub\"]"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I1C0L4OK0",
//															"faceTagName": "normal"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I1C00RP47",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I1C00RP48",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1I1BVI0RD0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I1C00RP49",
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "Absolute",
//														"x": "0",
//														"y": "100%",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Bottom",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "Tree Off",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBody\"]",
//														"text": {
//															"type": "string",
//															"valText": "${\"\"+state.toolNum+\" Items\"},state",
//															"localize": {
//																"EN": "${\"\"+state.toolNum+\" Items\"},state",
//																"CN": "${state.toolNum?(\"\"+state.toolNum+\"个项目\"):\"暂无项目\"},state"
//															},
//															"localizable": true
//														},
//														"font": "",
//														"fontSize": "#txtSize.smallPlus",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Right",
//														"alignV": "Center",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I1C00RP410",
//													"attrs": {
//														"1I1C0LEE30": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I1C0MC0Q10",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I1C0MC0Q11",
//																	"attrs": {
//																		"color": {
//																			"type": "colorRGB",
//																			"valText": "#cfgColor[\"fontBody\"]"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I1C0LEE30",
//															"faceTagName": "hover"
//														},
//														"1I1C0L4OK0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I1C0MC0Q12",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I1C0MC0Q13",
//																	"attrs": {
//																		"color": {
//																			"type": "colorRGB",
//																			"valText": "#cfgColor[\"fontBodySub\"]"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I1C0L4OK0",
//															"faceTagName": "normal"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I1C00RP411",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I1C00RP412",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1I1C00RP413",
//									"attrs": {
//										"1I1C0L4OK0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IATBTQ6Q2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IATBTQ6Q3",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I1C0L4OK0",
//											"faceTagName": "normal"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1I1C00RP414",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1I1C00RP415",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1I1BV49TC7",
//					"attrs": {
//						"1I1C0LEE30": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1I1C0MC0Q18",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I1C0MC0Q19",
//									"attrs": {
//										"border": {
//											"type": "auto",
//											"valText": "2",
//											"editMode": "edges"
//										},
//										"padding": {
//											"type": "auto",
//											"valText": "9",
//											"editMode": "edges"
//										},
//										"background": {
//											"type": "colorRGBA",
//											"valText": "#cfgColor[\"body\"]"
//										}
//									}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1I1C0LEE30",
//							"faceTagName": "hover"
//						},
//						"1I1C0L4OK0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1I1C0MC0Q20",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I1C0MC0Q21",
//									"attrs": {
//										"border": {
//											"type": "auto",
//											"valText": "1",
//											"editMode": "edges"
//										},
//										"padding": {
//											"type": "auto",
//											"valText": "10",
//											"editMode": "edges"
//										},
//										"background": {
//											"type": "colorRGBA",
//											"valText": "#cfgColor[\"body\"]"
//										}
//									}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1I1C0L4OK0",
//							"faceTagName": "normal"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1I1BV49TC8",
//					"attrs": {
//						"OnMouseInOut": {
//							"type": "fixedFunc",
//							"jaxId": "1I1C0SC290",
//							"attrs": {
//								"callArgs": {
//									"jaxId": "1I1C0T1J22",
//									"attrs": {
//										"isIn": "",
//										"event": ""
//									}
//								},
//								"seg": ""
//							}
//						}
//					}
//				},
//				"extraPpts": {
//					"jaxId": "1I1BV49TC9",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "true",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1I1BV49TC10",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false",
//				"background": "false",
//				"color": "false",
//				"gradient": "false",
//				"border": "false",
//				"borders": "false",
//				"borderStyle": "false",
//				"borderColor": "false",
//				"borderColors": "false",
//				"corner": "false",
//				"coner": "false",
//				"coners": "false",
//				"shadow": "false",
//				"shadowX": "false",
//				"shadowY": "false",
//				"shadowBlur": "false",
//				"shadowSpread": "false",
//				"shadowColor": "false",
//				"maskImage": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}