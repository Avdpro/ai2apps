//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
/*#{1HL27BS8G0StartDoc*/
/*}#1HL27BS8G0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BtnNodeLine=function(client,node,inTree){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let btnOpen;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let name="Node of HTML";
	let icon=appCfg.sharedAssets+"/web.svg";
	
	/*#{1HL27BS8G1LocalVals*/
	let focused;
	let isOpen=false;
	/*}#1HL27BS8G1LocalVals*/
	
	/*#{1HL27BS8G1PreState*/
	if(!node.touchable){
		icon=appCfg.sharedAssets+"/dummy.svg";
	}
	switch(node.tagName){
		case "TEXTAREA":
			icon=appCfg.sharedAssets+"/hudedit.svg";
			break;
		case "INPUT":
			icon=appCfg.sharedAssets+"/hudbtn.svg";
			break;
	}
	if(node.nodeType===3){
		name=JSON.stringify(node.text);
		icon=appCfg.sharedAssets+"/hudtxt.svg";
	}else if(node.id){
		name=node.id;
	}else if(node.tagName){
		name=`[${node.tagName}]`
	}
	if(node.class){
		name+=`(${JSON.stringify(node.class)})`;
	}
	/*}#1HL27BS8G1PreState*/
	/*#{1HL27BS8G1PostState*/
	/*}#1HL27BS8G1PostState*/
	cssVO={
		"hash":"1HL27BS8G1",nameHost:true,
		"type":"button","position":"relative","x":0,"y":0,"w":"","h":25,"padding":[0,3,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
		"itemsAlign":1,
		children:[
			{
				"hash":"1HL27CCJA0",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["body"],
			},
			{
				"hash":"1HL27GU320",
				"type":BtnIcon("front",16,0,appCfg.sharedAssets+"/collapse.svg",null),"id":"BtnOpen","position":"relative","x":8,"y":8,"anchorX":1,"anchorY":1,"attached":!!inTree,
				"margin":[0,0,0,3],
				"OnClick":function(event){
					/*#{1HL3ES7P00FunctionBody*/
					if(!isOpen){
						self.parent.open();
					}else{
						self.parent.close();
					}
					/*}#1HL3ES7P00FunctionBody*/
				},
			},
			{
				"hash":"1HL27LJVM0",
				"type":"box","id":"BoxIcon","position":"relative","x":0,"y":0,"w":20,"h":20,"uiEvent":-1,"margin":[0,3,0,0],"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","background":cfgColor["fontBodySub"],"border":1,"maskImage":icon,
			},
			{
				"hash":"1HL27NJ9F0",
				"type":"text","id":"TxtNodeName","position":"relative","x":0,"y":0,"w":"","h":"100%","uiEvent":0,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"color":[0,0,0],"text":name,"fontSize":txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,
			}
		],
		/*#{1HL27BS8G1ExtraCSS*/
		node:node,
		/*}#1HL27BS8G1ExtraCSS*/
		faces:{
			"up":{
				/*#{1HL27EMK80PreCode*/
				$(){
					if(focused) 
						return false;
				},
				/*}#1HL27EMK80PreCode*/
				/*BoxBG*/"#1HL27CCJA0":{
					"background":cfgColor["body"]
				}
			},"over":{
				/*#{1HL27F1BL0PreCode*/
				$(){
					if(focused) 
						return false;
				},
				/*}#1HL27F1BL0PreCode*/
				/*BoxBG*/"#1HL27CCJA0":{
					"background":cfgColor["itemOver"]
				}
			},"down":{
				/*#{1HL27NCCV2PreCode*/
				$(){
					if(focused) 
						return false;
				},
				/*}#1HL27NCCV2PreCode*/
			},"open":{
				/*BtnOpen*/"#1HL27GU320":{
					"rotate":90
				},
				/*#{1HL27KVNL0Code*/
				$(){
					isOpen=true;
				}
				/*}#1HL27KVNL0Code*/
			},"close":{
				/*BtnOpen*/"#1HL27GU320":{
					"rotate":0
				},
				/*#{1HL27KO620Code*/
				$(){
					isOpen=false;
				}
				/*}#1HL27KO620Code*/
			},"focus":{
				/*BoxBG*/"#1HL27CCJA0":{
					"background":cfgColor["itemFocus"]
				},
				/*#{1HL29K69V0Code*/
				$(){
					focused=true;
				}
				/*}#1HL29K69V0Code*/
			},"blur":{
				/*BoxBG*/"#1HL27CCJA0":{
					"background":cfgColor["body"]
				},
				/*#{1HL29KN9S0Code*/
				$(){
					focused=false;
				}
				/*}#1HL29KN9S0Code*/
			},"noSub":{
				/*BtnOpen*/"#1HL27GU320":{
					"enable":false
				}
			}
		},
		OnCreate:function(){
			self=this;
			btnOpen=self.BtnOpen;
			/*#{1HL27BS8G1Create*/
			if(node.nodeType===3){
				btnOpen.enable=false;
			}
			/*}#1HL27BS8G1Create*/
		},
		/*#{1HL27BS8G1EndCSS*/
		/*}#1HL27BS8G1EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.OnClick=function(event){
		/*#{1HL3E8QNH0FunctionBody*/
		if(inTree){
			self.parent.focusNode();
		}
		/*}#1HL3E8QNH0FunctionBody*/
	};
	/*#{1HL27BS8G1PostCSSVO*/
	/*}#1HL27BS8G1PostCSSVO*/
	return cssVO;
};
/*#{1HL27BS8G1ExCodes*/
/*}#1HL27BS8G1ExCodes*/

BtnNodeLine.gearExport={
	framework: "jax",
	hudType: "button",
	"showName":"",icon:"gears.svg",previewImg:false,
	fixPose:false,initW:100,initH:100,
	catalog:"",
	args: {
		"client": {
			"name": "client", "showName": "client", "type": "auto", "key": true, "fixed": true, 
			"initVal": null
		}, 
		"node": {
			"name": "node", "showName": "node", "type": "auto", "key": true, "fixed": true, 
			"initVal": null
		}, 
		"inTree": {
			"name": "inTree", "showName": "inTree", "type": "bool", "key": true, "fixed": true, "initVal": true
		}
	},
	state:{
	},
	properties:["id","position","x","y","w","display"],
	faces:["up","over","down","open","close","focus","blur","noSub"],
	subContainers:{
	},
	/*#{1HL27BS8G0ExGearInfo*/
	/*}#1HL27BS8G0ExGearInfo*/
};
/*#{1HL27BS8G0EndDoc*/
/*}#1HL27BS8G0EndDoc*/

export default BtnNodeLine;
export{BtnNodeLine};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearButton",
//	"jaxId": "1HL27BS8G0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1HL27BS8G2",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1HL27BS8G3",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1HL27BS8G4",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1HL27BS8G5",
//			"attrs": {
//				"client": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"node": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"inTree": {
//					"type": "bool",
//					"valText": "true"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1HL27BS8G6",
//			"attrs": {
//				"name": {
//					"type": "string",
//					"valText": "Node of HTML"
//				},
//				"icon": {
//					"type": "string",
//					"valText": "#appCfg.sharedAssets+\"/web.svg\""
//				}
//			}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1HL27BS8G7",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1HL27BS8G8",
//			"attrs": {
//				"up": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HL27EMK80",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "true",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HL27NCCV0",
//							"attrs": {}
//						}
//					}
//				},
//				"over": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HL27F1BL0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "true",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HL27NCCV1",
//							"attrs": {}
//						}
//					}
//				},
//				"down": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HL27NCCV2",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "true",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HL27NCCV3",
//							"attrs": {}
//						}
//					}
//				},
//				"open": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HL27KVNL0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HL27NCCV4",
//							"attrs": {}
//						}
//					}
//				},
//				"close": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HL27KO620",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HL27NCCV5",
//							"attrs": {}
//						}
//					}
//				},
//				"focus": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HL29K69V0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HL29L1GF0",
//							"attrs": {}
//						}
//					}
//				},
//				"blur": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HL29KN9S0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HL29L1GF1",
//							"attrs": {}
//						}
//					}
//				},
//				"noSub": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HL9MCPRG0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HL9MCUCD0",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1HL27BS8G9",
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "button",
//			"jaxId": "1HL27BS8G1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1HL27BS8G10",
//					"attrs": {
//						"type": "button",
//						"id": "",
//						"position": "Relative",
//						"x": "0",
//						"y": "0",
//						"w": "",
//						"h": "25",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "[0,3,0,0]",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"enable": "true",
//						"drag": "NA",
//						"flex": "false",
//						"contentLayout": "Flex X",
//						"itemsAlign": "Center"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1HL27CCJA0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HL27NCD00",
//									"attrs": {
//										"type": "box",
//										"id": "BoxBG",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"body\"]",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HL27NCD01",
//									"attrs": {
//										"1HL27EMK80": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HL27NCD02",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HL27NCD03",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor[\"body\"]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HL27EMK80",
//											"faceTagName": "up"
//										},
//										"1HL27F1BL0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HL27NCD04",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HL27NCD05",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor[\"itemOver\"]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HL27F1BL0",
//											"faceTagName": "over"
//										},
//										"1HL27KO620": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HL27NCD06",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HL27NCD07",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HL27KO620",
//											"faceTagName": "close"
//										},
//										"1HL27KVNL0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HL27NCD08",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HL27NCD09",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HL27KVNL0",
//											"faceTagName": "open"
//										},
//										"1HL29K69V0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HL29L1GF2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HL29L1GF3",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor[\"itemFocus\"]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HL29K69V0",
//											"faceTagName": "focus"
//										},
//										"1HL29KN9S0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HL29L1GF4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HL29L1GF5",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor[\"body\"]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HL29KN9S0",
//											"faceTagName": "blur"
//										},
//										"1HL27NCCV2": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HL3EEA8J0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HL3EEA8J1",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HL27NCCV2",
//											"faceTagName": "down"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HL27NCD010",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HL27NCD011",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear/@StdUI/ui/BtnIcon.js",
//							"jaxId": "1HL27GU320",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1HL27NCD012",
//									"attrs": {
//										"style": "\"front\"",
//										"w": "16",
//										"h": "0",
//										"icon": "#appCfg.sharedAssets+\"/collapse.svg\"",
//										"colorBG": "null"
//									}
//								},
//								"properties": {
//									"jaxId": "1HL27NCD013",
//									"attrs": {
//										"type": "#null#>BtnIcon(\"front\",16,0,appCfg.sharedAssets+\"/collapse.svg\",null)",
//										"id": "BtnOpen",
//										"position": "relative",
//										"x": "8",
//										"y": "8",
//										"display": "On",
//										"face": "",
//										"anchorH": "Center",
//										"anchorV": "Center",
//										"attach": "#!!inTree",
//										"margin": "[0,0,0,3]"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HL27NCD014",
//									"attrs": {
//										"1HL27KO620": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HL27NCD015",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HL27NCD016",
//													"attrs": {
//														"rotate": {
//															"type": "number",
//															"valText": "0"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HL27KO620",
//											"faceTagName": "close"
//										},
//										"1HL27KVNL0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HL27NCD017",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HL27NCD018",
//													"attrs": {
//														"rotate": {
//															"type": "number",
//															"valText": "90"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HL27KVNL0",
//											"faceTagName": "open"
//										},
//										"1HL27F1BL0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HL3EEA8J4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HL3EEA8J5",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HL27F1BL0",
//											"faceTagName": "over"
//										},
//										"1HL27NCCV2": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HL3EEA8J6",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HL3EEA8J7",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HL27NCCV2",
//											"faceTagName": "down"
//										},
//										"1HL27EMK80": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HL3EH57Q0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HL3EH57Q1",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HL27EMK80",
//											"faceTagName": "up"
//										},
//										"1HL9MCPRG0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HL9MCUCE0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HL9MCUCE1",
//													"attrs": {
//														"enable": {
//															"type": "bool",
//															"valText": "false"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HL9MCPRG0",
//											"faceTagName": "noSub"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HL27NCD019",
//									"attrs": {
//										"OnClick": {
//											"type": "fixedFunc",
//											"jaxId": "1HL3ES7P00",
//											"attrs": {
//												"callArgs": {
//													"jaxId": "1HL3ETA880",
//													"attrs": {
//														"event": ""
//													}
//												},
//												"seg": ""
//											}
//										}
//									}
//								},
//								"extraPpts": {
//									"jaxId": "1HL27NCD020",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true",
//								"containerSlots": {
//									"jaxId": "1HL27NCD021",
//									"attrs": {}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1HL27LJVM0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HL27NCD022",
//									"attrs": {
//										"type": "box",
//										"id": "BoxIcon",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "20",
//										"h": "20",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,3,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"fontBodySub\"]",
//										"border": "1",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"maskImage": "#icon"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HL27NCD023",
//									"attrs": {
//										"1HL27F1BL0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HL3EEA8J10",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HL3EEA8J11",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HL27F1BL0",
//											"faceTagName": "over"
//										},
//										"1HL27NCCV2": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HL3EEA8J12",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HL3EEA8J13",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HL27NCCV2",
//											"faceTagName": "down"
//										},
//										"1HL27EMK80": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HL3EH57Q2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HL3EH57Q3",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HL27EMK80",
//											"faceTagName": "up"
//										},
//										"1HL27KVNL0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HL3F12NU0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HL3F12NU1",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HL27KVNL0",
//											"faceTagName": "open"
//										},
//										"1HL27KO620": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HL3F12NU2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HL3F12NU3",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HL27KO620",
//											"faceTagName": "close"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HL27NCD024",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HL27NCD025",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1HL27NJ9F0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HL27QMH80",
//									"attrs": {
//										"type": "text",
//										"id": "TxtNodeName",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "[0,0,0]",
//										"text": "#name",
//										"font": "",
//										"fontSize": "#txtSize.smallPlus",
//										"bold": "false",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Center",
//										"wrap": "false",
//										"ellipsis": "false",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HL27QMH81",
//									"attrs": {
//										"1HL27F1BL0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HL3EEA8J16",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HL3EEA8J17",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HL27F1BL0",
//											"faceTagName": "over"
//										},
//										"1HL27NCCV2": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HL3EEA8J18",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HL3EEA8J19",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HL27NCCV2",
//											"faceTagName": "down"
//										},
//										"1HL27EMK80": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HL3EH57Q4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HL3EH57Q5",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HL27EMK80",
//											"faceTagName": "up"
//										},
//										"1HL27KVNL0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HL3F12NU4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HL3F12NU5",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HL27KVNL0",
//											"faceTagName": "open"
//										},
//										"1HL27KO620": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HL3F12NU6",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HL3F12NU7",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HL27KO620",
//											"faceTagName": "close"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HL27QMH82",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HL27QMH83",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1HL27BS8G11",
//					"attrs": {
//						"1HL27F1BL0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HL27NCD026",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HL27NCD027",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HL27F1BL0",
//							"faceTagName": "over"
//						},
//						"1HL27KO620": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HL27NCD028",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HL27NCD029",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HL27KO620",
//							"faceTagName": "close"
//						},
//						"1HL27KVNL0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HL27NCD030",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HL27NCD031",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HL27KVNL0",
//							"faceTagName": "open"
//						},
//						"1HL27NCCV2": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HL3EEA8J22",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HL3EEA8J23",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HL27NCCV2",
//							"faceTagName": "down"
//						},
//						"1HL27EMK80": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HL3EH57Q6",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HL3EH57Q7",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HL27EMK80",
//							"faceTagName": "up"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1HL27BS8G12",
//					"attrs": {
//						"OnClick": {
//							"type": "fixedFunc",
//							"jaxId": "1HL3E8QNH0",
//							"attrs": {
//								"callArgs": {
//									"jaxId": "1HL3EA2EU0",
//									"attrs": {
//										"event": ""
//									}
//								},
//								"seg": ""
//							}
//						}
//					}
//				},
//				"extraPpts": {
//					"jaxId": "1HL27BS8G13",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1HL27BS8G14",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "true",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"enable": "false",
//				"drag": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}