//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
import {BoxGroup} from "./BoxGroup.js";
import {BoxTool} from "./BoxTool.js";
import {BtnToolCard} from "./BtnToolCard.js";
import {BtnState} from "./BtnState.js";
/*#{1I10E0NR20StartDoc*/
import {AppLib} from "/@homekit/data/AppLib.js";
import pathLib from "/@path";
import {tabOS,tabFS,tabNT} from "/@tabos";
import {AATools} from "/@tabos/AATools.js";
import {AABots} from "../AABots.js";
import {AgentHub} from "../AgentHub.js";
import {} from "../data/AppData.js";
import {BoxBot} from "./BoxBot.js";
import {runAgent,showChatThread} from "/@AgentBuilder/ai/RunAgent.js";
import Base64 from "/@tabos/utils/base64.js";
import {BtnChatAsset} from "/@aichat/ui/BtnChatAsset.js";
import {AppFrame} from "/@homekit/ui/AppFrame.js";
import {BtnChatSession} from "./BtnChatSession.js";
import {AIConfig} from "/@AgentBuilder/data/AIConfig.js";
import {BtnShortcut} from "./BtnShortcut.js";

import {AaChatClient} from "/@aichat/chatclient.js";

const agentURL=(new URL(import.meta.url)).pathname;
const basePath=pathLib.dirname(agentURL);
//----------------------------------------------------------------------------
function randomTag(digit=6,time=true){
	const characters = 'abcdefghijklmnopqrstuvwxyz0123456789';
	let result = '';
	const charactersLength = characters.length;
	if(time){
		time=""+Date.now();
		time=time.substring(time.length-6);
	}
	for (let i = 0; i < digit; i++) {
		result += characters.charAt(Math.floor(Math.random() * charactersLength));
	}
	return "$"+result+time;
};

//----------------------------------------------------------------------------
async function arrayBuffer(file){
	if(file.arrayBuffer){
		return file.arrayBuffer();
	}
	return new Promise((onDone,onError)=>{
		let reader=new FileReader();
		reader.onload=function(event) {
			let arrayBuffer = event.target.result;
			onDone(arrayBuffer);
		};
		reader.readAsArrayBuffer(file);
	})
}

/*}#1I10E0NR20StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let DashBoard=function(){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let boxHome,imgLogo,edCommand,txtInputTip,btnSendCmd,boxAssets,btnChatEntry,txtChatEntry,btnMenu,boxGroups,boxGroupMenu,boxGroupHeader,txtGroupName,btnGroupMenu,boxGroupItems,boxShortcuts,boxShortcutsHeader,boxShortcutCards,boxChats,boxNaviHeader,btnStateTool,btnStateBots,btnStateChain,boxChatList,btnShare,btnStore,txtWait,boxHeader,btnShowSideBar,btnNewChat2,boxTokenGas,txtToken,txtGas;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1I10E0NR21LocalVals*/
	const app=VFACT.app;
	let toolsIndex=null;
	let tools=new AATools();
	let agentHub=new AgentHub(app);
	let curGroup=null;
	let appTools=tools;
	let appBots=new AABots();
	let willSaveTools=false;
	let hotChatFrame=null;
	let chatFrames=[];
	let chatEntryTool=null;
	
	let shortcuts=null;
	
	let chatClient=new AaChatClient();
	let threadSyncVersion=1;
	/*}#1I10E0NR21LocalVals*/
	
	/*#{1I10E0NR21PreState*/
	let isUpdatingTokenGas=false;
	/*}#1I10E0NR21PreState*/
	state={
		"naviBoxW":250,
		/*#{1I10E0NR27ExState*/
		/*}#1I10E0NR27ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1I10E0NR21PostState*/
	/*}#1I10E0NR21PostState*/
	cssVO={
		"hash":"1I10E0NR21",nameHost:true,
		"type":"view","x":$P(()=>(state.naviBoxW+50),state),"y":0,"w":">calc(100% - 300px)","h":"100%","padding":10,"minW":"","minH":"","maxW":"","maxH":"",
		"styleClass":"","contentLayout":"flex-y","itemsAlign":1,
		children:[
			{
				"hash":"1ILNAB5GG0",
				"type":"hud","id":"BoxHome","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":1200,"maxH":"","styleClass":"","contentLayout":"flex-y","itemsAlign":1,
				children:[
					{
						"hash":"1I1US7JF80",
						"type":"hud","id":"BoxLogo","position":"relative","x":0,"y":0,"w":"100%","h":240,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
						"itemsAlign":1,
						children:[
							{
								"hash":"1I1USB7L80",
								"type":"hud","position":"relative","x":0,"y":0,"w":">calc(50% - 40px)","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
							},
							{
								"hash":"1I1USCCFA0",
								"type":"image","id":"ImgLogo","position":"relative","x":40,"y":40,"w":80,"h":80,"anchorX":1,"anchorY":1,"minW":"","minH":"","maxW":"","maxH":"",
								"styleClass":"","image":appCfg.sharedAssets+"/aalogo.svg","fitSize":true,
								"OnClick":function(event){
									/*#{1INAU90TS0FunctionBody*/
									/*}#1INAU90TS0FunctionBody*/
								},
							},
							{
								"hash":"1I1USDRD10",
								"type":"hud","position":"relative","x":0,"y":0,"w":">calc(50% - 40px)","h":"100%","padding":10,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
								"contentLayout":"flex-y",
							}
						],
					},
					{
						"hash":"1I10EHPSR0",
						"type":"box","id":"BoxInput","position":"relative","x":0,"y":0,"w":"60%","h":"","margin":[20,0,0,0],"padding":[8,10,5,10],"minW":"","minH":40,"maxW":800,
						"maxH":"","styleClass":"","background":cfgColor["chatInputBG"],"border":1,"borderColor":cfgColor["fontBodyLit"],"corner":16,"shadowX":0,"shadowColor":[0,0,0,0.2],
						"contentLayout":"flex-y","itemsAlign":1,"subAlign":1,"itemsWrap":1,
						children:[
							{
								"hash":"1ILI4K2S50",
								"type":"hud","id":"BoxInputLine","position":"relative","x":0,"y":0,"w":"100%","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
								"itemsAlign":2,"subAlign":1,
								children:[
									{
										"hash":"1I1M5M3QT0",
										"type":"memo","id":"EdCommand","position":"relative","x":0,"y":0,"w":">calc(100% - 40px)","h":"","minW":"","minH":30,"maxW":"","maxH":200,"styleClass":"",
										"color":cfgColor["fontBody"],"background":[255,255,255,0],"outline":0,"border":[0,0,1,0],"borderColor":cfgColor["fontBodyLit"],
										"OnInput":function(){
											/*#{1I1M64K3N0FunctionBody*/
											txtInputTip.display=!this.text;
											btnSendCmd.enable=!!this.text;
											/*}#1I1M64K3N0FunctionBody*/
										},
										"OnKeyDown":function(event){
											/*#{1I1M64K3N1FunctionBody*/
											if(event.code==="Enter"){
												if((!event.isComposing) &&(!event.shiftKey)){
													event.stopPropagation();
													event.preventDefault();
													self.runCommand();
												}
											}
											/*}#1I1M64K3N1FunctionBody*/
										},
									},
									{
										"hash":"1I1M69F3G0",
										"type":"text","id":"TxtInputTip","x":10,"y":0,"w":"","h":"100%","uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodyLit"],
										"text":(($ln==="CN")?("给出你的指令..."):("Make your command...")),"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,
									},
									{
										"hash":"1I10EONLD0",
										"type":BtnIcon("front",30,0,appCfg.sharedAssets+"/send.svg",null),"id":"BtnSendCmd","position":"relative","x":0,"y":0,"padding":3,"margin":[0,0,0,3],
										"enable":false,
										"OnClick":function(event){
											self.runCommand(this,event);
										},
									}
								],
								"OnClick":function(event){
									/*#{1IMS6SCEC0FunctionBody*/
									/*}#1IMS6SCEC0FunctionBody*/
								},
							},
							{
								"hash":"1ILIHN2E90",
								"type":"hud","id":"BoxAssets","position":"relative","x":0,"y":0,"w":">calc(100% - 60px)","h":"","padding":0,"minW":"","minH":"","maxW":"","maxH":"",
								"styleClass":"","contentLayout":"flex-y",
							},
							{
								"hash":"1ILJ8I23P0",
								"type":"hud","id":"BoxToolBtns","position":"relative","x":0,"y":0,"w":"100%","h":"","margin":[10,0,0,0],"padding":[0,5,5,5],"minW":"","minH":"",
								"maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x","itemsWrap":1,"itemsAlign":1,
								children:[
									{
										"hash":"1ILJ8I23P2",
										"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/asset.svg",null),"id":"BtnAddAssets","position":"relative","x":0,"y":0,"margin":[0,5,0,5],
										"tip":(($ln==="CN")?("附加内容"):("Add assets")),
										"OnClick":function(event){
											self.chooseChatAsset(this,event);
										},
									},
									{
										"hash":"1IMR7850A0",
										"type":"hud","id":"SegChatEntry","position":"relative","x":0,"y":0,"w":"","h":"100%","cursor":"pointer","margin":[0,5,0,5],"minW":"","minH":"",
										"maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x","itemsAlign":1,
										children:[
											{
												"hash":"1IMR7R2FE0",
												"type":"box","id":"BoxChatEntryBG","x":-2,"y":-2,"w":">calc(100% + 4px)","h":">calc(100% + 4px)","display":0,"uiEvent":-1,"minW":"","minH":"",
												"maxW":"","maxH":"","styleClass":"","background":cfgColor["hot"],"border":1,"borderColor":cfgColor["fontBodySub"],"corner":6,
											},
											{
												"hash":"1IMR791SD0",
												"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/appdata.svg",null),"id":"BtnChatEntry","position":"relative","x":0,"y":0,
												"tip":(($ln==="CN")?("选择对话智能体"):("Choose chat AI Agent")),
												"OnClick":function(event){
													self.showChatEntryMenu(this,event);
												},
											},
											{
												"hash":"1IMR7NS760",
												"type":"text","id":"TxtChatEntry","position":"relative","x":0,"y":0,"w":"","h":"","display":0,"uiEvent":-1,"margin":[0,3,0,3],"minW":"","minH":"",
												"maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],"text":"Web Search","fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal",
												"textDecoration":"",
											}
										],
										"OnClick":function(event){
											self.showChatEntryMenu(this,event);
										},
									},
									{
										"hash":"1ILR0R6B60",
										"type":"box","position":"relative","x":0,"y":0,"w":1,"h":16,"display":0,"margin":[0,0,0,5],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
										"background":cfgColor["fontBodyLit"],
									},
									{
										"hash":"1ILJ8I23Q21",
										"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/skillchain.svg",null),"id":"BtnUseChain","position":"relative","x":0,"y":0,"margin":[0,5,0,5],
										"enable":false,
										"tip":(($ln==="CN")?("选择智能链"):("Choose agent chain")),
									},
									{
										"hash":"1INGQM8N50",
										"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/settings.svg",null),"id":"BtnConfig","position":"relative","x":0,"y":0,"margin":[0,5,0,5],
										"tip":(($ln==="CN")?("AI 对话设置"):("AI Settings")),
										"OnClick":function(event){
											self.editConfig(this,event);
										},
									},
									{
										"hash":"1ILJ8QBSK0",
										"type":"hud","position":"relative","x":0,"y":0,"w":1,"h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","flex":true,
									},
									{
										"hash":"1I1HHL2Q00",
										"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/inc.svg",null),"id":"BtnMenu","position":"relative","x":0,"y":0,"padding":0,
										"tip":(($ln==="CN")?("添加智能体"):("Add Agent")),
										"OnClick":function(event){
											self.showMenu(this,event);
										},
									}
								],
							}
						],
					},
					{
						"hash":"1I11DDGM90",
						"type":"hud","id":"BoxContents","position":"relative","x":"50%","y":0,"w":"100%","h":100,"anchorX":1,"overflow":"auto-y","margin":[10,20,20,20],
						"padding":[20,50,20,50],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","flex":true,"itemsWrap":1,"subAlign":1,
						children:[
							{
								"hash":"1I19QVP9T0",
								"type":"hud","id":"BoxGroups","x":50,"y":0,"w":">calc(100% - 100px)","h":"","display":0,"overflow":"auto-y","padding":10,"minW":"","minH":"","maxW":"",
								"maxH":"","styleClass":"","contentLayout":"flex-x","subAlign":1,"itemsAlign":1,"itemsWrap":1,
								children:[
								],
							},
							{
								"hash":"1I1D4M7EH0",
								"type":"hud","id":"BoxGroupMenu","x":50,"y":0,"w":">calc(100% - 100px)","h":"","display":0,"overflow":"auto-y","padding":5,"minW":"","minH":"",
								"maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
								children:[
									{
										"hash":"1I1D525QM0",
										"type":"hud","id":"BoxGroupHeader","position":"relative","x":0,"y":0,"w":"100%","h":30,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
										"contentLayout":"flex-x",
										children:[
											{
												"hash":"1I1D52KLM0",
												"type":BtnIcon("front",30,0,appCfg.sharedAssets+"/arrowleft.svg",null),"id":"BtnCloseSiteMenu","position":"relative","x":0,"y":0,"margin":[0,5,0,0],
												"tip":(($ln==="CN")?("返回"):("Back")),
												"OnClick":function(event){
													self.closeSiteMenu(this,event);
												},
											},
											{
												"hash":"1I1D549G80",
												"type":"text","id":"TxtGroupName","position":"relative","x":0,"y":-10,"w":"","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
												"color":cfgColor["fontBodySub"],"text":"www.google.com","fontSize":txtSize.bigPlus,"fontWeight":"bold","fontStyle":"normal","textDecoration":"",
												"alignH":1,"flex":true,
											},
											{
												"hash":"1I1QBHS2K0",
												"type":BtnIcon("front",30,0,appCfg.sharedAssets+"/menu.svg",null),"id":"BtnGroupMenu","position":"relative","x":0,"y":0,"margin":[0,5,0,0],
												"tip":(($ln==="CN")?("选项"):("Options")),
												"OnClick":function(event){
													self.showGroupMenu(this,event);
												},
											}
										],
									},
									{
										"hash":"1I1D4RN860",
										"type":"hud","id":"BoxGroupItems","position":"relative","x":30,"y":0,"w":">calc(100% - 60px)","h":"","padding":[5,0,5,0],"minW":"","minH":"",
										"maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x","itemsWrap":1,"subAlign":1,
										children:[
										],
									}
								],
							},
							{
								"hash":"1IVP63JCP0",
								"type":"hud","id":"BoxShortcuts","x":50,"y":0,"w":">calc(100% - 100px)","h":"","overflow":"auto-y","padding":10,"minW":"","minH":"","maxW":"",
								"maxH":"","styleClass":"","contentLayout":"flex-y","subAlign":1,"itemsAlign":1,"itemsWrap":1,
								children:[
									{
										"hash":"1IVP7GV5Q0",
										"type":"hud","id":"BoxShortcutsHeader","position":"relative","x":0,"y":0,"w":"100%","h":30,"display":0,"minW":"","minH":"","maxW":"","maxH":"",
										"styleClass":"","contentLayout":"flex-x","itemsAlign":1,
										children:[
											{
												"hash":"1IVP7KFRF0",
												"type":BtnIcon("front",30,0,appCfg.sharedAssets+"/btncombo.svg",null),"id":"BtnShortcutType","position":"relative","x":0,"y":0,
											},
											{
												"hash":"1IVP7LL870",
												"type":"text","id":"TxtShortcuts","position":"relative","x":0,"y":0,"w":100,"h":"","margin":[0,0,0,5],"minW":"","minH":"","maxW":"","maxH":"",
												"styleClass":"","color":cfgColor["fontBody"],"text":"Featured","fontSize":txtSize.mid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
											}
										],
									},
									{
										"hash":"1IVP7HPJC0",
										"type":"hud","id":"BoxShortcutCards","position":"relative","x":0,"y":0,"w":"100%","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
										"contentLayout":"flex-x","itemsWrap":1,"itemsAlign":1,"subAlign":1,
										children:[
										],
									}
								],
							}
						],
					}
				],
			},
			{
				"hash":"1ILN7T8730",
				"type":"hud","id":"BoxChats","x":0,"y":30,"w":"100%","h":">calc(100% - 30px)","display":0,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
			},
			{
				"hash":"1ILN0BQ5L0",
				"type":"hud","id":"BoxNavi","x":$P(()=>(-state.naviBoxW),state),"y":0,"w":$P(()=>(state.naviBoxW),state),"h":"100%","padding":[0,5,5,5],"minW":"",
				"minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
				children:[
					{
						"hash":"1ILN6U0GJ0",
						"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["tool"],
						"shadow":true,"shadowX":-1,"shadowBlur":2,"shadowSpread":2,"shadowColor":[0,0,0,0.75],
					},
					{
						"hash":"1IVMGK95R0",
						"type":"hud","id":"BoxNaviHeader","position":"relative","x":0,"y":0,"w":"100%","h":30,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
						"itemsAlign":1,
						children:[
							{
								"hash":"1IVMGOSM40",
								"type":BtnIcon("front",28,0,appCfg.sharedAssets+"/uilefthide.svg",null),"id":"BtnHideSideBar","position":"relative","x":0,"y":0,
								"tip":(($ln==="CN")?("隐藏边栏"):("Hide sidebar")),
								"OnClick":function(event){
									self.hideSideBar(this,event);
								},
							},
							{
								"hash":"1IVMJOCPE0",
								"type":BtnIcon("front",28,0,appCfg.sharedAssets+"/chat_add.svg",null),"id":"BtnNewChat","position":"relative","x":0,"y":0,"margin":[0,0,0,10],
								"tip":(($ln==="CN")?("新对话"):("New conversation")),
								"OnClick":function(event){
									/*#{1IVMJOCPF0FunctionBody*/
									if(!boxHome.display){
										self.closeSiteMenu(this,event);
									}
									/*}#1IVMJOCPF0FunctionBody*/
								},
							}
						],
					},
					{
						"hash":"1ILN5BGIH0",
						"type":"hud","position":"relative","x":"50%","y":0,"w":60,"h":60,"anchorX":1,"margin":[5,5,15,5],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						children:[
							{
								"hash":"1ILN3AUOA0",
								"type":"box","position":"relative","x":"50%","y":"50%","w":40,"h":40,"anchorX":1,"anchorY":1,"cursor":"pointer","minW":"","minH":"","maxW":"",
								"maxH":"","styleClass":"","background":cfgColor["fontBody"],"maskImage":appCfg.sharedAssets+"/aalogo.svg",
								"OnClick":function(event){
									self.closeSiteMenu(this,event);
								},
							},
							{
								"hash":"1ILN5H7VB0",
								"type":"text","x":0,"y":">calc(100% - 10px)","w":"100%","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodyLit"],
								"text":"www.ai2apps.com","fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignH":1,
							}
						],
					},
					{
						"hash":"1I1UU28N70",
						"type":BtnState("appdata.svg","-",(($ln==="CN")?("智能体管理"):("Agents")),0,""),"id":"BtnStateTool","position":"relative","x":"10%","y":0,"w":"80%",
						"OnClick":function(event){
							self.showAllTools(this,event);
						},
					},
					{
						"hash":"1I2B3HVI30",
						"type":BtnState("agent.svg","-",(($ln==="CN")?("智能体节点"):("Agent Nodes")),0,""),"id":"BtnStateBots","position":"relative","x":"10%","y":0,"w":"80%",
						"OnClick":function(event){
							self.showBots(this,event);
						},
					},
					{
						"hash":"1I1UUF8SN0",
						"type":BtnState("skillchain.svg","-",(($ln==="CN")?("智能链管理"):("Agent Chain")),16,""),"id":"BtnStateChain","position":"relative","x":"10%","y":0,
						"display":0,"w":"80%","enable":false,
						"OnClick":function(event){
							self.showAllChains(this,event);
						},
					},
					{
						"hash":"1IUVB55T00",
						"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":10,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
					},
					{
						"hash":"1ILND4KDN0",
						"type":"hud","id":"BoxChatList","position":"relative","x":0,"y":0,"w":"100%","h":10,"overflow":"auto-y","margin":[10,0,0,0],"minW":"","minH":"",
						"maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y","flex":true,
					},
					{
						"hash":"1I29MDBOI0",
						"type":BtnState("qrcode.svg","-",(($ln==="CN")?("分享系统"):("Share System")),txtSize.smallPlus,""),"id":"BtnShare","position":"relative","x":"10%",
						"y":0,"w":"80%",
						"OnClick":function(event){
							self.showShareDlg(this,event);
						},
					},
					{
						"hash":"1J04JNPJK0",
						"type":BtnState("store.svg","-",(($ln==="CN")?("智能体超市"):("Agent Mart")),txtSize.smallPlus,"run.svg"),"id":"BtnStore","position":"relative","x":"10%",
						"y":0,"w":"80%",
						"OnClick":function(event){
							self.showAppMart(this,event);
						},
					}
				],
			},
			{
				"hash":"1IUTA4N0T0",
				"type":"box","id":"BoxWait","x":-250,"y":0,"w":">calc(100% + 250px)","h":"100%","display":0,"alpha":0.9,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"background":cfgColor["body"],
				children:[
					{
						"hash":"1IUTAA9HF0",
						"type":"text","id":"TxtWait","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
						"text":"Connecting to AI2Apps server...","fontSize":txtSize.bigPlus,"fontWeight":"bold","fontStyle":"normal","textDecoration":"","alignH":1,"alignV":1,
					}
				],
			},
			{
				"hash":"1I10E3UB90",
				"type":"hud","id":"BoxHeader","x":0,"y":0,"w":"100%","h":30,"padding":[0,5,0,5],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
				"itemsAlign":1,
				children:[
					{
						"hash":"1IVMFUCR40",
						"type":"box","id":"BoxHeaderBG","x":0,"y":0,"w":"100%","h":"100%","display":0,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["tool"],
					},
					{
						"hash":"1IVMCCT6J0",
						"type":"box","id":"BoxChatShadow","x":0,"y":"100%","w":"100%","h":1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":"linear-gradient(to right, rgba(0,0,0,0.5),rgba(0,0,0,0.1), rgba(0,0,0,0))",
					},
					{
						"hash":"1IVMNN6RP0",
						"type":"box","id":"BoxGap","x":-1,"y":5,"w":1,"h":">calc(100% - 10px)","display":0,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["fontBodySub"],
					},
					{
						"hash":"1IVH7QFMI0",
						"type":BtnIcon("front",28,0,appCfg.sharedAssets+"/uileft.svg",null),"id":"BtnShowSideBar","position":"relative","x":0,"y":0,"display":0,
						"tip":(($ln==="CN")?("显示边栏"):("Show sidebar")),
						"OnClick":function(event){
							self.showSideBar(this,event);
						},
					},
					{
						"hash":"1IVMJPUGG0",
						"type":BtnIcon("front",28,0,appCfg.sharedAssets+"/chat_add.svg",null),"id":"BtnNewChat2","position":"relative","x":0,"y":0,"display":0,"margin":[0,0,0,10],
						"tip":(($ln==="CN")?("新对话"):("New conversation")),
						"OnClick":function(event){
							/*#{1IVMJPUGH5FunctionBody*/
							if(!boxHome.display){
								self.closeSiteMenu(this,event);
							}
							/*}#1IVMJPUGH5FunctionBody*/
						},
					},
					{
						"hash":"1IVMD2MB00",
						"type":"hud","id":"BoxTokenGas","position":"relative","x":0,"y":0,"w":10,"h":"100%","margin":[0,0,0,10],"minW":"","minH":"","maxW":"","maxH":"",
						"styleClass":"","flex":true,"contentLayout":"flex-x","itemsAlign":1,
						children:[
							{
								"hash":"1ILOCUCU70",
								"type":BtnIcon("front",20,0,appCfg.sharedAssets+"/token.svg",null),"id":"BtnAddGas","position":"relative","x":0,"y":0,
								"OnClick":function(event){
									self.showTokenGasDlg(this,event);
								},
							},
							{
								"hash":"1ILOCJ1CA0",
								"type":"text","id":"TxtToken","position":"relative","x":0,"y":0,"w":"","h":"","minW":20,"minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
								"text":"-","fontSize":txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignH":1,
							},
							{
								"hash":"1ILOCT8VV0",
								"type":BtnIcon("front",20,0,appCfg.sharedAssets+"/gas.svg",null),"id":"BtnAddGas","position":"relative","x":0,"y":0,"margin":[0,0,0,10],
								"OnClick":function(event){
									self.showTokenGasDlg(this,event);
								},
							},
							{
								"hash":"1ILOCHRG80",
								"type":"text","id":"TxtGas","position":"relative","x":0,"y":0,"w":"","h":"","minW":20,"minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
								"text":"-","fontSize":txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignH":1,
							}
						],
					}
				],
			}
		],
		/*#{1I10E0NR21ExtraCSS*/
		/*}#1I10E0NR21ExtraCSS*/
		faces:{
			"sites":{
				/*#{1I1D5700V0PreCode*/
				/*}#1I1D5700V0PreCode*/
				/*BoxHome*/"#1ILNAB5GG0":{
					"display":1
				},
				/*BoxLogo*/"#1I1US7JF80":{
					"display":1
				},
				/*BoxInput*/"#1I10EHPSR0":{
					"display":1
				},
				/*BoxToolBtns*/"#1ILJ8I23P0":{
					"display":1
				},
				/*BoxContents*/"#1I11DDGM90":{
					"display":1
				},
				/*BoxGroups*/"#1I19QVP9T0":{
					"display":0
				},
				/*BoxGroupMenu*/"#1I1D4M7EH0":{
					"display":0
				},
				/*BoxShortcuts*/"#1IVP63JCP0":{
					"display":1
				},
				/*BoxChats*/"#1ILN7T8730":{
					"display":0
				},
				"#1ILN3AUOA0":{
					"background":cfgColor["fontBodySub"],"uiEvent":-1,"w":40,"h":40
				},
				"#1ILN5H7VB0":{
					"display":1
				},
				/*BtnStateTool*/"#1I1UU28N70":{
					"display":1
				},
				/*BtnStateBots*/"#1I2B3HVI30":{
					"display":1
				},
				/*BtnShare*/"#1I29MDBOI0":{
					"display":1
				},
				/*BtnStore*/"#1J04JNPJK0":{
					"display":1
				},
				/*BoxHeader*/"#1I10E3UB90":{
					"display":1
				},
				/*BoxHeaderBG*/"#1IVMFUCR40":{
					"display":0
				},
				/*BoxChatShadow*/"#1IVMCCT6J0":{
					"display":0
				},
				/*BoxGap*/"#1IVMNN6RP0":{
					"display":0
				},
				/*#{1I1D5700V0Code*/
				$(){
					self.showSession(null);
				}
				/*}#1I1D5700V0Code*/
			},"siteMenu":{
				/*BoxHome*/"#1ILNAB5GG0":{
					"display":1
				},
				/*BoxLogo*/"#1I1US7JF80":{
					"display":1
				},
				/*BoxInput*/"#1I10EHPSR0":{
					"display":0
				},
				/*BoxToolBtns*/"#1ILJ8I23P0":{
					"display":0
				},
				/*BoxContents*/"#1I11DDGM90":{
					"display":1
				},
				/*BoxGroups*/"#1I19QVP9T0":{
					"display":0
				},
				/*BoxGroupMenu*/"#1I1D4M7EH0":{
					"display":1
				},
				/*BoxShortcuts*/"#1IVP63JCP0":{
					"display":0
				},
				/*BoxChats*/"#1ILN7T8730":{
					"display":0
				},
				"#1ILN3AUOA0":{
					"background":cfgColor["fontBody"],"uiEvent":1,"w":60,"h":60
				},
				"#1ILN5H7VB0":{
					"display":0
				},
				/*BoxHeader*/"#1I10E3UB90":{
					"display":1
				},
				/*#{1I1D5774S0Code*/
				$(){
					self.showSession(null);
				}
				/*}#1I1D5774S0Code*/
			},"chat":{
				/*BoxHome*/"#1ILNAB5GG0":{
					"display":0
				},
				/*BoxChats*/"#1ILN7T8730":{
					"display":1
				},
				"#1ILN3AUOA0":{
					"uiEvent":1,"w":60,"h":60
				},
				"#1ILN5H7VB0":{
					"display":0
				},
				/*BoxHeaderBG*/"#1IVMFUCR40":{
					"display":1
				},
				/*BoxChatShadow*/"#1IVMCCT6J0":{
					"display":1
				},
				/*BoxGap*/"#1IVMNN6RP0":{
					"display":1
				},
				/*#{1ILN7H5CK0Code*/
				/*}#1ILN7H5CK0Code*/
			},"entryOn":{
				/*BoxChatEntryBG*/"#1IMR7R2FE0":{
					"display":1
				},
				/*TxtChatEntry*/"#1IMR7NS760":{
					"display":1
				}
			},"entryOff":{
				/*BoxChatEntryBG*/"#1IMR7R2FE0":{
					"display":0
				},
				/*TxtChatEntry*/"#1IMR7NS760":{
					"display":0
				}
			},"offline":{
				/*BoxWait*/"#1IUTA4N0T0":{
					"display":1
				}
			},"online":{
				/*BoxWait*/"#1IUTA4N0T0":{
					"display":0
				}
			},"sidebarOn":{
				"#self":{
					"x":$P(()=>(state.naviBoxW+50),state),"w":">calc(100% - 300px)"
				},
				/*BoxHome*/"#1ILNAB5GG0":{
					"x":0,"anchorX":0
				},
				/*BoxNavi*/"#1ILN0BQ5L0":{
					"display":1
				},
				/*BtnHideSideBar*/"#1IVMGOSM40":{
					"display":1
				},
				/*BtnNewChat*/"#1IVMJOCPE0":{
					"display":1
				},
				/*BoxGap*/"#1IVMNN6RP0":{
					"alpha":1
				},
				/*BtnShowSideBar*/"#1IVH7QFMI0":{
					"display":0
				},
				/*BtnNewChat2*/"#1IVMJPUGG0":{
					"display":0
				},
				/*#{1IVH6SHR30Code*/
				$(){
					//boxNaviHeader.appendChild(boxTokenGas);
				}
				/*}#1IVH6SHR30Code*/
			},"sidebarOff":{
				"#self":{
					"x":50,"w":">calc(100% - 50px)"
				},
				/*BoxHome*/"#1ILNAB5GG0":{
					"x":"50%","anchorX":1
				},
				/*BoxNavi*/"#1ILN0BQ5L0":{
					"display":0
				},
				/*BtnHideSideBar*/"#1IVMGOSM40":{
					"display":0
				},
				/*BtnNewChat*/"#1IVMJOCPE0":{
					"display":0
				},
				/*BoxGap*/"#1IVMNN6RP0":{
					"alpha":0
				},
				/*BtnShowSideBar*/"#1IVH7QFMI0":{
					"display":1
				},
				/*BtnNewChat2*/"#1IVMJPUGG0":{
					"display":1
				},
				/*#{1IVH6TC9J0Code*/
				$(){
					//boxHeader.appendChild(boxTokenGas);
				}
				/*}#1IVH6TC9J0Code*/
			}
		},
		OnCreate:function(){
			self=this;
			boxHome=self.BoxHome;imgLogo=self.ImgLogo;edCommand=self.EdCommand;txtInputTip=self.TxtInputTip;btnSendCmd=self.BtnSendCmd;boxAssets=self.BoxAssets;btnChatEntry=self.BtnChatEntry;txtChatEntry=self.TxtChatEntry;btnMenu=self.BtnMenu;boxGroups=self.BoxGroups;boxGroupMenu=self.BoxGroupMenu;boxGroupHeader=self.BoxGroupHeader;txtGroupName=self.TxtGroupName;btnGroupMenu=self.BtnGroupMenu;boxGroupItems=self.BoxGroupItems;boxShortcuts=self.BoxShortcuts;boxShortcutsHeader=self.BoxShortcutsHeader;boxShortcutCards=self.BoxShortcutCards;boxChats=self.BoxChats;boxNaviHeader=self.BoxNaviHeader;btnStateTool=self.BtnStateTool;btnStateBots=self.BtnStateBots;btnStateChain=self.BtnStateChain;boxChatList=self.BoxChatList;btnShare=self.BtnShare;btnStore=self.BtnStore;txtWait=self.TxtWait;boxHeader=self.BoxHeader;btnShowSideBar=self.BtnShowSideBar;btnNewChat2=self.BtnNewChat2;boxTokenGas=self.BoxTokenGas;txtToken=self.TxtToken;txtGas=self.TxtGas;
			/*#{1I10E0NR21Create*/
			let showSide=localStorage.getItem("Dashboard-Sidebar");
			if(showSide==="show"){
				self.showFace("sidebarOn");
			}else{
				self.showFace("sidebarOff");
			}
			self.showFace("sites");
			self.readIndex();
			app.on("ToolsChanged",self.maybeSaveTools);
			app.on("ToolsChanged",self.listTools);
			app.on("AISegCallLLMResult",self.updateTokenGas)
			let orgGetFrame=window.getAppFrame;
			window.getAppFrame=function(win){
				let frame;
				if(orgGetFrame){
					frame=orgGetFrame(win);
					if(frame){
						return frame;
					}
				}
				for(frame of chatFrames){
					let ifm;
					ifm=frame.getPageFrame();
					if(ifm && ifm.contentWindow===win){
						return frame;
					}
				}
			};
			self.showWait("");
			self.checkLogin(()=>{
				chatClient.connect({shadow:false});
			});
			app.on("UpdateTokenGas",()=>{
				tabOS.emitGlobalNotify("UpdateTokenGas");
			});
			tabOS.onNotify("UpdateTokenGas",self.updateTokenGas)
			self.updateTokenGas();
			tabOS.onNotify("Offline",()=>{
				self.showWait("");
				self.checkLogin(()=>{
					self.hideWait();
				});
			});
			if(window.tabApi && window.tabApi.dashboardReady){
				window.tabApi.dashboardReady();
			}
			self.checkShadowDomain();
			
			//----------------------------------------------------------------
			//ChatClient handlers:
			//----------------------------------------------------------------
			{
				chatClient.onNotify("Offline",()=>{
					self.reconnectClient();
				});
				chatClient.onNotify("ThreadsSynced",()=>{
					self.showThreads(chatClient.threads);
					self.hideWait();
				});
				chatClient.on("NewThread",async (thread)=>{
					let btn=await self.addSession(null,thread.title,thread,false);
					btn.showFace("blur");
				});
				chatClient.on("NewShadowThread",self.newShadowThread);
			
				chatClient.on("NewMessage",async (thread,message)=>{
					let btn=thread.sessionBtn;
					if(btn){
						boxChatList.insertBefore(btn,boxChatList.firstChild);
						if(!btn.focused){
							//TODO:
						}
					}
				});
			
				chatClient.on("ArchiveThread",async (thread)=>{
					let btn=thread.sessionBtn;
					let frame=btn.frame;
					if(frame && frame===hotChatFrame){
						return;
					}
					boxChatList.removeChild(btn);
				});
			
				chatClient.on("DeleteThread",async (thread)=>{
					let btn=thread.sessionBtn;
					let frame=btn.frame;
					if(frame && frame===hotChatFrame){
						return;
					}
					boxChatList.removeChild(btn);
				});
			}
			/*}#1I10E0NR21Create*/
		},
		/*#{1I10E0NR21EndCSS*/
		/*}#1I10E0NR21EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.readIndex=async function(){
		/*#{1I1C1K57N0Start*/
		let path,label,listJson;
		try{
			await tools.load();
		}catch(err){
			console.error(err);
		}
		callAfter(()=>{edCommand.focus();});
		//await self.listTools();
		await self.listShortcuts();
		/*}#1I1C1K57N0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.listTools=async function(){
		/*#{1I1C1JAVP0Start*/
		let groups,siteName,group,siteVO,css;
		boxGroups.clearChildren();
		groups=tools.getGroups();
		for(group of groups){
			css={
				type:BoxGroup(group),position:"relative",group:group,
				OnClick(){
					self.showGroup(this.group);
				}
			};
			boxGroups.appendNewChild(css);
		}
		//Sites:
		groups=tools.getSites();
		for(group of groups){
			css={
				type:BoxGroup(group),position:"relative",group:group,
				OnClick(){
					self.showGroup(this.group);
				}
			};
			boxGroups.appendNewChild(css);
		}
		btnStateTool.text=""+appTools.tools.size;
		btnStateChain.text=""+appTools.chains.size;
		try{
			let nodes;
			nodes=await agentHub.getNodes(true);
			if(nodes){
				btnStateBots.text=Object.values(nodes).length;
			}else{
				btnStateBots.text="NA";
			}
		}catch(err){
		}
		/*}#1I1C1JAVP0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.listShortcuts=async function(){
		/*#{1IVREL1V00Start*/
		let res,appInfo,tmp,agentSet,card,name;
		agentSet=new Set();
		//First, all system featured app-agents:
		if(!shortcuts){
			res=await tabNT.makeCall("GetAppList",{mode:"System"});
			if(!res || res.code!==200){
				return false;
			}
			shortcuts=res.apps;
		}
		boxShortcutCards.clearChildren();
		for(appInfo of shortcuts){
			tmp={
				type:BtnShortcut(appInfo),position:"relative",x:125,y:50,
				execShortcut:async function(){
					if(this.agentPath){
						let tool=appTools.getTool(this.agentPath);
						if(!tool){
							tool=await appTools.loadTool(this.agentInfo);
							if(!tool){
								tool=await appTools.loadTool(this.agentPath);
							}
						}
						if(tool){
							if(tool.type==="Agent"){
								if(tool.chatEntry==="Tool"){
									txtChatEntry.text=tool.getName($ln);
									self.showFace("entryOn");
									btnChatEntry.icon=tool.icon;
									chatEntryTool=tool;
									edCommand.focus();
								}else{
									self.runTool(tool);
								}
							}else{
								appTools.execTool(app,tool);
							}
						}
					}
				}
			};
			card=boxShortcutCards.appendNewChild(tmp);
			name=appInfo.name;
			name=name[$ln]||name["EN"]||name;
			agentSet.add(name);
		}
		{
			let chatTools,tool;
			chatTools=tools.getChatEntryTools();
			for(tool of chatTools){
				name=tool.name;
				name=name[$ln]||name["EN"]||name;
				if(agentSet.has(name)){
					continue;
				}
				tmp={
					type:BoxTool(tool,{}),position:"relative",tool:tool,
					OnClick(){
						let tool=this.tool;
						if(tool.type==="Agent"){
							if(tool.chatEntry==="Tool"){
								txtChatEntry.text=tool.getName($ln);
								self.showFace("entryOn");
								btnChatEntry.icon=tool.icon;
								chatEntryTool=tool;
								edCommand.focus();
							}else{
								self.runTool(tool);
							}
						}else{
							appTools.execTool(app,this.tool);
						}
					},
					showMenu(sender){
						self.showToolMenu(this.tool,curGroup,sender);
					}
				};
				boxShortcutCards.appendNewChild(tmp);
			}		
		}
		/*}#1IVREL1V00Start*/
	};
	//------------------------------------------------------------------------
	cssVO.createTool=async function(sender,event){
		/*#{1I19R1NLP0Start*/
		let result,line;
		result=await app.modalDlg("/@aichat/ui/DlgAIChat.js",{
			url:"/@aae/ai/PageBot.js",
			prompt:"",
			clearChat:true,
			allowEmptyChat:false,
			allowReset:false,
			autoClose:true
		},"CreateTool");
		/*}#1I19R1NLP0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.showGroup=async function(group){
		/*#{1I1I62ICH0Start*/
		let label,tools,tool,css,icon,chain,chains;
		curGroup=group;
		label=group.name;
		if(label["EN"]){
			label=label[$ln]||label["EN"];
		}
		icon=group.icon||"browser.svg";
		if(icon[0]!=="/"){
			icon=appCfg.sharedAssets+"/"+icon;
		}
		imgLogo.animate({
			type:"out",alpha:0,scale:1.2,time:150,
			OnFinish(){
				callAfter(()=>{
					imgLogo.image=icon;
					imgLogo.animate({type:"in",alpha:0,scale:1.2,time:300});
				});
			}
		});
		
		btnGroupMenu.enable=!(group.hostSite||group.allTools||group.allChains);
		
		self.showFace("siteMenu");
		boxGroupHeader.y=-20;
		boxGroupHeader.animate({type:"pose",y:0,time:80});
		txtGroupName.text=label;
		tools=group.tools||[];
		chains=group.chains||[];
		boxGroupItems.clearChildren();
		//List chains:
		for(chain of chains){
			css={
				type:BoxTool(chain,group),position:"relative",chain:chain,
				OnClick(){
					if(!group.allChains){
						appTools.execChain(app,this.chain);
					}else{
						self.showChainMenu(this.chain,curGroup,this);
					}
				},
				showMenu(sender){
					self.showChainMenu(this.chain,curGroup,sender);
				}
			};
			boxGroupItems.appendNewChild(css);
		}
		
		//List tools:
		for(tool of tools){
			css={
				type:BoxTool(tool,group),position:"relative",tool:tool,
				OnClick(){
					if(!group.allTools){
						appTools.execTool(app,this.tool);
					}else{
						self.showToolMenu(this.tool,group,this);
					}
				},
				showMenu(sender){
					self.showToolMenu(this.tool,curGroup,sender);
				}
			};
			boxGroupItems.appendNewChild(css);
		}
		//Add tool button:
		{
			css={
				type:BoxTool({
					name:(($ln==="CN")?("添加项目"):/*EN*/("Add item")),description:(($ln==="CN")?("通过AI对话、从文件或从云端添加新项目。"):/*EN*/("Add new items through AI chat, from files, or from the cloud.")),icon:"additem.svg",menu:false
				},group),position:"relative",tool:tool,
				OnClick(){
					self.showAddToolMenu(this);
				}
			};
			boxGroupItems.appendNewChild(css);
		}
		/*}#1I1I62ICH0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.closeSiteMenu=async function(sender,event){
		/*#{1I1I64CBJ0Start*/
		let list,i,n,box;
		curGroup=null;
		list=boxGroups.children
		n=list.length;
		for(i=0;i<n;i++){
			box=list[i];
			box.aniShow();
		}
		self.showFace("sites");
		imgLogo.animate({
			type:"out",alpha:0,scale:1.2,time:150,
			OnFinish(){
				imgLogo.image=appCfg.sharedAssets+"/aalogo.svg";
				imgLogo.animate({type:"in",alpha:0,scale:1.2,time:500});
			}
		});
		setTimeout(()=>{
			edCommand.focus();
		},50)
		/*}#1I1I64CBJ0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.showMenu=async function(sender,event){
		/*#{1I1IF0PR70Start*/
		/*}#1I1IF0PR70Start*/
		{
			let $items,$item;
			$items=[
				{id:"Cloud",text:(($ln==="CN")?("从智能体超市查找安装智能体"):("Find and install agent from Agent Mart")),icon:appCfg.sharedAssets+"/store.svg",enable:true},
				{id:"File",text:(($ln==="CN")?("从文件导入智能体或工具链"):("Import agent or tool-chain from file")),icon:appCfg.sharedAssets+"/folder.svg"},
				{id:"AddGroup",text:(($ln==="CN")?("新建工具组入口"):("New group entry")),icon:appCfg.sharedAssets+"/additem.svg",enable:true},
				{id:"Chat",text:(($ln==="CN")?("通过对话创建智能体"):("Create an AI agent by chat")),icon:appCfg.sharedAssets+"/aichat.svg",enable:false},
				{id:"GitHub",text:(($ln==="CN")?("从GitHub项目创建智能体"):("Create agent from GitHub project")),icon:appCfg.sharedAssets+"/star_e.svg",enable:false}
			];
			$item=await VFACT.app.modalDlg("/@StdUI/ui/DlgMenu.js",{hud:sender,items:$items});
			if($item){
				if($item.id==="Cloud"){
					/*#{1I1IF1JJO1*/
					self.showAppMart();
					/*}#1I1IF1JJO1*/
				}else if($item.id==="File"){
					/*#{1I1IF1JJO0*/
					self.addToolByPath(sender,null);
					/*}#1I1IF1JJO0*/
				}else if($item.id==="AddGroup"){
					/*#{1I1IF1JJO2*/
					self.addNewGroup();
					/*}#1I1IF1JJO2*/
				}else if($item.id==="Chat"){
					/*#{1I1Q3R1JQ0*/
					/*}#1I1Q3R1JQ0*/
				}else if($item.id==="GitHub"){
					/*#{1ILJLS5EV0*/
					/*}#1ILJLS5EV0*/
				}
			}
		}
	};
	//------------------------------------------------------------------------
	cssVO.showAddToolMenu=async function(sender){
		/*#{1I1IGCNVT0Start*/
		/*}#1I1IGCNVT0Start*/
		{
			let $items,$item;
			$items=[
				{id:"Cloud",text:(($ln==="CN")?("从智能体中心查找工具"):("Find tool from agent hub")),icon:appCfg.sharedAssets+"/cloud.svg",enable:false},
				{id:"File",text:(($ln==="CN")?("从文件导入工具"):("Import tool from file")),icon:appCfg.sharedAssets+"/folder.svg"},
				{id:"Chat",text:(($ln==="CN")?("通过与AI对话创建新工具"):("Create a new tool by chat with AI")),icon:appCfg.sharedAssets+"/aichat.svg",enable:false}
			];
			$item=await VFACT.app.modalDlg("/@StdUI/ui/DlgMenu.js",{hud:sender,items:$items});
			if($item){
				if($item.id==="Cloud"){
					/*#{1I1IGDBG51*/
					/*}#1I1IGDBG51*/
				}else if($item.id==="File"){
					/*#{1I1IGDBG50*/
					self.addToolByPath(sender,curGroup);
					/*}#1I1IGDBG50*/
				}else if($item.id==="Chat"){
					/*#{1I1JVCGEF0*/
					/*}#1I1JVCGEF0*/
				}
			}
		}
	};
	//------------------------------------------------------------------------
	cssVO.runCommand=async function(){
		/*#{1I1M6K4VG0Start*/
		let text,assets,frame,thread;
		text=edCommand.text;
		if(!text){
			return;
		}
		assets=[];
		{
			let list,i,n,line,url;
			list=boxAssets.children;
			n=list.length;
			for(i=0;i<n;i++){
				line=list[i];
				url=line.assetUrl;
				if(url){
					assets.push(url);
				}
			}
			assets=assets.length?assets:null;
		}
		self.showFace("chat");
		thread=await chatClient.newThread(text);
		if(chatEntryTool){
			let agent,agentNode,args,entryType;
			entryType=chatEntryTool.chatEntry;
			agent=chatEntryTool.filePath;
			agentNode=chatEntryTool.agentNode;
			if(agentNode){
				agent=pathLib.basename(agent);
			}
			if(entryType==="Root"){
				if(assets){
					let url;
					text+='\n\n- - -\n\n Assets:\n\n';
					for(url of assets){
						text+=`${url}\n\n`;
					}
					text+='- - -\n\n';
				}
				frame=await runAgent({chatClient:chatClient,chatThread:thread,agent:agent,agentNode:agentNode,args:text,title:"Chat with AI2Apps",embed:boxChats});
			}else{//Tool
				args={tool:chatEntryTool.filePath,prompt:text,assets:assets};
				frame=await runAgent({chatClient:chatClient,chatThread:thread,agent:"/@AgentBuilder/ai/SysTabOSChat.js",agentNode:null,args:args,title:"Chat with AI2Apps",embed:boxChats});
			}
		}else{
			if(assets){
				frame=await runAgent({chatClient:chatClient,chatThread:thread,agent:"/@AgentBuilder/ai/SysTabOSChat.js",agentNode:null,args:{prompt:text,assets:assets},title:"Chat with AI2Apps",embed:boxChats});
			}else{
				frame=await runAgent({chatClient:chatClient,chatThread:thread,agent:"/@AgentBuilder/ai/SysTabOSChat.js",agentNode:null,args:text,title:"Chat with AI2Apps",embed:boxChats});
			}
		}
		edCommand.text="";
		txtInputTip.display=true;
		boxAssets.clearChildren();
		self.addSession(frame,text,thread,true);
		return;
		/*}#1I1M6K4VG0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.runTool=async function(tool){
		/*#{1IVT3STI50Start*/
		let agent,agentNode,assets,frame;
		if(typeof(tool)==="string"){
			tool=appTools.loadTool(tool);
			if(!tool){
				return;
			}
		}
		assets=[];
		{
			let list,i,n,line,url;
			list=boxAssets.children;
			n=list.length;
			for(i=0;i<n;i++){
				line=list[i];
				url=line.assetUrl;
				if(url){
					assets.push(url);
				}
			}
			assets=assets.length?assets:null;
		}
		agent=tool.filePath;
		agentNode=tool.agentNode;
		if(agentNode){
			agent=pathLib.basename(agent);
		}
		let thread=await chatClient.newThread(tool.getName($ln));
		frame=await runAgent({chatClient:chatClient,chatThread:thread,agent:agent,agentNode:agentNode,args:"",title:"Chat with AI2Apps",embed:boxChats});
		edCommand.text="";
		txtInputTip.display=true;
		boxAssets.clearChildren();
		self.addSession(frame,tool.getName($ln),thread,true);
		/*}#1IVT3STI50Start*/
	};
	//------------------------------------------------------------------------
	cssVO.newShadowThread=async function(thread,args,tool){
		/*#{1IV3VOR810Start*/
		let chatEntryTool,frame,btn;
		chatEntryTool=tool||null;
		if(chatEntryTool){
			//TODO: Code this:
		}else{
			frame=await runAgent({chatClient:chatClient,chatThread:thread,agent:"/@AgentBuilder/ai/SysTabOSChat.js",agentNode:null,args:args,title:"Chat with AI2Apps",embed:boxChats});
		}
		edCommand.text="";
		txtInputTip.display=true;
		boxAssets.clearChildren();
		btn=await self.addSession(frame,args.prompt||args,thread,false);
		btn.showFace("blur");
		/*}#1IV3VOR810Start*/
	};
	//------------------------------------------------------------------------
	cssVO.addToolByPath=async function(hud,group){
		/*#{1I1OPT0RJ0Start*/
		let path,tool,ext2;
		path="/";
		path=await app.modalDlg("/@StdUI/ui/DlgFile.js",{
			mode:"open",
			path:path,options:{
				multiSelect:false,
				preview:true,
			},
			buttonText:(($ln==="CN")?("打开"):/*EN*/("Open")),
		});
		if(!path){
			return;
		}
		path="/~"+path;
		ext2=pathLib.ext2name(path);
		if(ext2===".toolchain.json" || ext2===".toolchain.js"){
			let chain;
			chain=await appTools.loadChain(path);
			if(!group){
				let items,item;
				items=appTools.getGroups();
				items=items.map((group)=>{
					let name,icon;
					name=group.label||group.name;
					if(name.EN){
						name=name[$ln]||name.EN;
					}
					icon=group.icon;
					if(icon[0]!=="/"){
						icon=appCfg.sharedAssets+"/"+icon;
					}
					return {text:name,icon:icon,group:group};
				});
				item=await app.modalDlg("/@StdUI/ui/DlgSelect.js",{
					hud:hud,
					title:(($ln==="CN")?("添加到组？"):/*EN*/("Add to group?")),
					items:items
				});
				if(item){
					item.group.addChain(chain);
				}
			}else{
				group.addChain(chain);
				self.showGroup(curGroup);
			}
		}else{
			tool=await appTools.loadTool(path);
			if(!tool){
				window.alert((($ln==="CN")?("添加智能体失败：无法读取智能体/工具信息"):/*EN*/("Failed to add agent: Unable to read agent/tool information")));
				return;
			}
			if(!group){
				let items,item;
				items=appTools.getGroups();
				items=items.map((group)=>{
					let name,icon;
					name=group.label||group.name;
					if(name.EN){
						name=name[$ln]||name.EN;
					}
					icon=group.icon;
					if(icon[0]!=="/"){
						icon=appCfg.sharedAssets+"/"+icon;
					}
					return {text:name,icon:icon,group:group};
				});
				item=await app.modalDlg("/@StdUI/ui/DlgSelect.js",{
					hud:hud,
					title:(($ln==="CN")?("添加到组？"):/*EN*/("Add to group?")),
					items:items
				});
				if(item){
					item.group.addTool(tool);
				}
			}else{
				group.addTool(tool);
				self.showGroup(curGroup);
			}
		}
		app.emit("ToolsChanged");
		/*}#1I1OPT0RJ0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.maybeSaveTools=async function(){
		/*#{1I1P0EB940Start*/
		if(willSaveTools){
			return;
		}
		willSaveTools=true;
		callAfter(self.saveTools);
		/*}#1I1P0EB940Start*/
	};
	//------------------------------------------------------------------------
	cssVO.saveTools=async function(){
		/*#{1I1P2K9ER0Start*/
		willSaveTools=false;
		let path,label;
		path="/coke/ToolIndex.json";
		try{
			let saveVO;
			saveVO=await appTools.genSaveVO();
			await tabFS.writeFile(path,JSON.stringify(saveVO,null,"\t"));
		}catch(err){
			console.error(err);
		}
		callAfter(()=>{edCommand.focus();});
		/*}#1I1P2K9ER0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.addNewGroup=async function(){
		/*#{1I1QAF8RC0Start*/
		let name,group;
		name="NewGroup";
		//name=window.prompt((($ln==="CN")?("输入新分组名称"):/*EN*/("Input new group name")),name);
		name=await app.modalDlg("/@StdUI/ui/DlgPrompt.js",{title:(($ln==="CN")?("输入新分组名称"):/*EN*/("Input new group name")),text:name});
		if(!name){
			return;
		}
		do{
			group=appTools.getGroup(name);
			if(!group){
				break;
			}
			window.alert((($ln==="CN")?("该群组名称已被使用！"):/*EN*/("Group name already taken!")));
			//name=window.prompt((($ln==="CN")?("输入新分组名称"):/*EN*/("Input new group name")),name);
			name=await app.modalDlg("/@StdUI/ui/DlgPrompt.js",{title:(($ln==="CN")?("输入新分组名称"):/*EN*/("Input new group name")),text:name});
			if(!name){
				return;
			}
		}while(1);
		group=appTools.addGroup(name);
		self.showGroup(group);
		app.emit("ToolsChanged");
		/*}#1I1QAF8RC0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.showGroupMenu=async function(sender){
		/*#{1I1QC7IVU0Start*/
		/*}#1I1QC7IVU0Start*/
		{
			let $items,$item;
			$items=[
				{id:"Rename",text:(($ln==="CN")?("改名"):("Rename")),icon:appCfg.sharedAssets+"/rename.svg"},
				{id:"Icon",text:(($ln==="CN")?("选择图标"):("Select icon")),icon:appCfg.sharedAssets+"/hudimg.svg"},
				{id:"Remove",text:(($ln==="CN")?("移除该组"):("Remove this group")),icon:appCfg.sharedAssets+"/trash.svg"}
			];
			$item=await VFACT.app.modalDlg("/@StdUI/ui/DlgMenu.js",{hud:sender,items:$items});
			if($item){
				if($item.id==="Rename"){
					/*#{1I1QC7UIB0*/
					let name,group;
					name=curGroup.name;
					if(name.EN){
						name=name[$ln]||name.EN;
					}
					//name=window.prompt((($ln==="CN")?("输入新的组名"):/*EN*/("Input new group name")),name);
					name=await app.modalDlg("/@StdUI/ui/DlgPrompt.js",{title:(($ln==="CN")?("输入新分组名称"):/*EN*/("Input new group name")),text:name});
					if(!name){
						return;
					}
					do{
						group=appTools.getGroup(name);
						if(!group){
							break;
						}
						window.alert((($ln==="CN")?("该群组名称已被使用！"):/*EN*/("Group name already taken!")));
						//name=window.prompt((($ln==="CN")?("输入新分组名称"):/*EN*/("Input new group name")),name);
						name=await app.modalDlg("/@StdUI/ui/DlgPrompt.js",{title:(($ln==="CN")?("输入新分组名称"):/*EN*/("Input new group name")),text:name});
						if(!name){
							return;
						}
					}while(1);
					appTools.renameGroup(curGroup,name);
					self.showGroup(curGroup);
					app.emit("ToolsChanged");
					/*}#1I1QC7UIB0*/
				}else if($item.id==="Icon"){
					/*#{1I1QC7UIB1*/
					let path;
					path="/-tabos/shared/assets";
					path=await app.modalDlg("/@homekit/ui/DlgFile.js",{
						mode:"open",
						path:path,
						options:{
							multiSelect:false,
							preview:true,
							filter:"*.png;*.svg;*.jpg"
						},
						buttonText:(($ln==="CN")?("打开"):/*EN*/("Open")),
					});
					if(!path){
						return;
					}
					path="/~"+path;
					curGroup.icon=path;
					self.showGroup(curGroup);
					app.emit("ToolsChanged");
					/*}#1I1QC7UIB1*/
				}else if($item.id==="Remove"){
					/*#{1I1QC7UIB2*/
					if(!window.confirm("Are sure to remove this group?")){
						return;
					}
					appTools.removeGroup(curGroup);
					app.emit("ToolsChanged");
					self.closeSiteMenu();
					/*}#1I1QC7UIB2*/
				}
			}
		}
	};
	//------------------------------------------------------------------------
	cssVO.showToolMenu=async function(tool,group,sender){
		/*#{1I1Q4CLTB0Start*/
		/*}#1I1Q4CLTB0Start*/
		{
			let $items,$item;
			$items=[
				{id:"Info",text:(($ln==="CN")?("工具信息"):("Tool Information")),icon:appCfg.sharedAssets+"/idcard.svg"},
				{id:"Open",text:(($ln==="CN")?("运行工具"):("Execute Tool")),icon:appCfg.sharedAssets+"/run.svg"},
				{id:"Enbable",text:(($ln==="CN")?("启用"):("Enable")),icon:appCfg.sharedAssets+"/check.svg"},
				{id:"Disable",text:(($ln==="CN")?("禁用"):("Disable")),icon:appCfg.sharedAssets+"/lock.svg"},
				{id:"Delete",text:(($ln==="CN")?("移除"):("Remove")),icon:appCfg.sharedAssets+"/trash.svg"}
			];
			/*#{1I1Q4J0LC2Items*/
			if(tool.keyTool){
				$items[2].check=true;
				$items[2].enable=false;
				$items[3].enable=false;
				$items[4].enable=false;
			}else if(tool.enable){
				$items[2].check=true;
				$items[2].enable=false;
			}else{
				$items[3].check=true;
				$items[3].enable=false;
			}
			/*}#1I1Q4J0LC2Items*/
			$item=await VFACT.app.modalDlg("/@StdUI/ui/DlgMenu.js",{hud:sender,items:$items});
			if($item){
				if($item.id==="Info"){
					/*#{1I278APR30*/
					let toolVO=tool.genInfoVO($ln);
					let title;
					if(toolVO.guide){
						title=(($ln==="CN")?("工具链信息"):/*EN*/("Tool Chain Info"));
					}else{
						title=(($ln==="CN")?("工具信息"):/*EN*/("Tool Info"));
					}
					app.modalDlg("/@StdUI/ui/DlgDataView.js",{
						title:title,
						w:480,
						template:"ToolInfo",
						object:toolVO,
						edit:false
					});
					/*}#1I278APR30*/
				}else if($item.id==="Open"){
					/*#{1I1Q4HMJ51*/
					appTools.execTool(app,tool);
					/*}#1I1Q4HMJ51*/
				}else if($item.id==="Enbable"){
					/*#{1I278F9M10*/
					tool.enable=true;
					tool.emitNotify("Changed");
					app.emit("ToolsChanged");
					/*}#1I278F9M10*/
				}else if($item.id==="Disable"){
					/*#{1I278EITH0*/
					tool.enable=false;
					tool.emitNotify("Changed");
					app.emit("ToolsChanged");
					/*}#1I278EITH0*/
				}else if($item.id==="Delete"){
					/*#{1I1Q4HMJ50*/
					if(group.allTools){
						let ref,g;
						ref=appTools.getToolRef(tool);
						if(ref.chains.length){
							window.alert("This tool is used in tool-chain(s). Remove tool-chain before remove tools it using.");
							return;
						}
						if(ref.groups.length){
							if(!window.confirm((($ln==="CN")?("你确定要移除这个工具并从全部工具组中移除对它吗?"):/*EN*/("Are you sure to remove this tool and remove all references to it from all tool groups?")))){
								return;
							}
						}else{
							if(!window.confirm((($ln==="CN")?("你确定要移除这个工具吗?"):/*EN*/("Are you sure to remove this tool?")))){
								return;
							}
						}
						//Remove tool:
						appTools.removeTool(tool,ref);
						app.emit("ToolsChanged");
						self.showAllTools();
					}else{
						group.removeTool(tool);
						self.showGroup(curGroup);
						app.emit("ToolsChanged");
					}
					/*}#1I1Q4HMJ50*/
				}
			}
			/*#{1I1Q4J0LC2Post*/
			/*}#1I1Q4J0LC2Post*/
		}
	};
	//------------------------------------------------------------------------
	cssVO.showChainMenu=async function(chain,group,sender){
		/*#{1I1V5OGU40Start*/
		/*}#1I1V5OGU40Start*/
		{
			let $items,$item;
			$items=[
				{id:"Info",text:(($ln==="CN")?("工具链信息"):("Chain information")),icon:appCfg.sharedAssets+"/idcard.svg"},
				{id:"Open",text:(($ln==="CN")?("执行工具链"):("Execute Tool Chain")),icon:appCfg.sharedAssets+"/run.svg"},
				{id:"Delete",text:(($ln==="CN")?("删除工具连锁"):("Delete Tool Chain")),icon:appCfg.sharedAssets+"/trash.svg"}
			];
			$item=await VFACT.app.modalDlg("/@StdUI/ui/DlgMenu.js",{hud:sender,items:$items});
			if($item){
				if($item.id==="Info"){
					/*#{1I29JHLIL0*/
					let vo=chain.genInfoVO($ln);
					app.modalDlg("/@aae/ui/DlgToolInfo.js",{tool:vo,title:"工具信息"});
					/*}#1I29JHLIL0*/
				}else if($item.id==="Open"){
					/*#{1I1V5PBT30*/
					appTools.execChain(app,chain);
					/*}#1I1V5PBT30*/
				}else if($item.id==="Delete"){
					/*#{1I1V5PBT31*/
					if(group.allChains){
						let ref,g;
						ref=appTools.getChainRef(chain);
						if(ref.groups.length){
							if(!window.confirm((($ln==="CN")?("你确定要移除这个工具链并从全部工具组中移除对它吗?"):/*EN*/("Are you sure to remove this tool-chain and remove all references to it from all tool groups?")))){
								return;
							}
						}else{
							if(!window.confirm((($ln==="CN")?("你确定要移除这个工具链吗?"):/*EN*/("Are you sure to remove this tool-chain?")))){
								return;
							}
						}
						appTools.removeChain(chain,ref);
						app.emit("ToolsChanged");
						self.showAllChains();
					}else{
						group.removeChain(chain);
						self.showGroup(curGroup);
						app.emit("ToolsChanged");
					}
					/*}#1I1V5PBT31*/
				}
			}
		}
	};
	//------------------------------------------------------------------------
	cssVO.showAllTools=async function(){
		/*#{1I268L5VR0Start*/
		let tools,group;
		tools=appTools.getTools(true);
		group={
			name:(($ln==="CN")?("智能体管理"):/*EN*/("Agent Management")),
			icon:"appdata.svg",
			allTools:true,
			tools:tools,
			menu:false
		};
		self.showGroup(group);
		/*}#1I268L5VR0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.showAllChains=async function(){
		/*#{1I268LO9T0Start*/
		let chains,group;
		chains=appTools.getChains(true);
		group={
			name:(($ln==="CN")?("工具管理链"):/*EN*/("Tool Chain Management")),
			icon:"toolchain.svg",
			allChains:true,
			chains:chains
		};
		self.showGroup(group);
		/*}#1I268LO9T0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.showBots=async function(){
		/*#{1I2ESN96I0Start*/
		let label,icon,nodes,node,css;
		label=(($ln==="CN")?("智能体节点"):/*EN*/("Agent Nodes"));
		if(label["EN"]){
			label=label[$ln]||label["EN"];
		}
		icon="agent.svg";
		if(icon[0]!=="/"){
			icon=appCfg.sharedAssets+"/"+icon;
		}
		imgLogo.animate({
			type:"out",alpha:0,scale:1.2,time:150,
			OnFinish(){
				callAfter(()=>{
					imgLogo.image=icon;
					imgLogo.animate({type:"in",alpha:0,scale:1.2,time:300});
				});
			}
		});
		
		btnGroupMenu.enable=true;
		self.showFace("siteMenu");
		boxGroupHeader.y=-20;
		boxGroupHeader.animate({type:"pose",y:0,time:80});
		txtGroupName.text=label;
		boxGroupItems.clearChildren();
		//List bots:
		nodes=await agentHub.getNodeList(true);
		for(node of nodes){
			css={
				type:BoxBot(node),position:"relative",bot:node,
				OnClick(){
				}
			};
			boxGroupItems.appendNewChild(css);
		}
		/*}#1I2ESN96I0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.chooseChatAsset=async function(sender,event){
		/*#{1ILIGIPH20Start*/
		let items,item;
		items=[
			{
				text:"Choose from Native OS",code:"NativeOS",
				labelHtml:'<input type="file" multiple="false" style="width:0px">',
				OnLabelAction(html){
					let item=this;
					item.file=html.files[0];
				}
			},
			{text:"Choose from Tab-OS",code:"TabOS"},
		];
		item=await app.modalDlg("/@StdUI/ui/DlgMenu.js",{items:items,hud:sender});
		if(item){
			if(item.code==="TabOS"){
				let path;
				path="/";
				path=await app.modalDlg("/@StdUI/ui/DlgFile.js",{
					path:path,
					title:(($ln==="CN")?("添加附件文件"):/*EN*/("Add asset")),
					buttonText:/*EN*/("Add")
				});
				if(path){
					let buf;
					buf=await tabFS.readFile(path);
					buf=Base64.encode(buf);
					await self.addChatAsset(pathLib.basename(path),buf);
				}
			}else if(item.code==="NativeOS" && item.file){
				let buf,byteAry,res;
				buf=await arrayBuffer(item.file);
				buf=Base64.encode(buf);
				await self.addChatAsset(item.file.name,buf);
			}
		}
		/*}#1ILIGIPH20Start*/
	};
	//------------------------------------------------------------------------
	cssVO.addChatAsset=async function(fileName,fileData){
		/*#{1ILIHR4B10Start*/
		let res,line,hubURL;
		res=await tabNT.makeCall("AhFileSave",{fileName:fileName,data:fileData});
		if(!res || res.code!==200){
			if(res && res.info){
				window.alert("Upload file to agent hub error: "+res.info);
			}else{
				window.alert("Upload file to agent hub error.");
			}
			return;
		}
		hubURL="hub://"+res.fileName;
		line=boxAssets.appendNewChild({
			type:BtnChatAsset({text:fileName}),margin:[3,5,3,5],
			assetName:fileName,assetUrl:hubURL,assetData:fileData,
			OnClick(){
				let text=edCommand.text;
				text+=" "+hubURL+" ";
				edCommand.text=text;
				txtInputTip.display=false;
			},
			OnDelete(){
				boxAssets.removeChild(line);
			}
		});
		/*}#1ILIHR4B10Start*/
	};
	//------------------------------------------------------------------------
	cssVO.addSession=async function(frame,prompt,thread,show){
		/*#{1ILNF7L6L0Start*/
		let btn;
		btn=boxChatList.insertNewBefore({
			type:BtnChatSession(frame,prompt,thread),position:"relative",
			OnClick(event){
				if(event.button===2){
					self.showSessionMenu(this);
				}else{
					self.showSession(this);
				}
			}
		},boxChatList.firstChild);
		if(thread){
			thread.sessionBtn=btn;
		}
		if(frame){
			frame.sessionBtn=btn;
			frame.sessionName=prompt;
			chatFrames.push(frame);
			if(show){
				self.showSession(btn);
			}
		}
		return btn;
		/*}#1ILNF7L6L0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.showSession=async function(btn){
		/*#{1ILNF8A870Start*/
		let orgBtn;
		let frame=null;
		if(btn){
			frame=btn.frame;
		}
		if(hotChatFrame && hotChatFrame!==frame){
			orgBtn=hotChatFrame.sessionBtn;
			//orgBtn.uiEvent=1;
			orgBtn.showFace("blur");
			hotChatFrame.display=false;
			hotChatFrame=null;
		}
		hotChatFrame=frame;
		if(btn){
			//btn.uiEvent=-1;
			btn.showFace("focus");
			if(orgBtn){
				if(frame){
					setTimeout(()=>{
						frame.animate({type:"in",alpha:0,dx:20,time:100});
					},200);
				}else if(btn.chatThread){
					frame=await showChatThread({chatThread:btn.chatThread,embed:boxChats});
					if(frame){
						frame.sessionBtn=btn;
						frame.sessionName=btn.chatThread.title;
						chatFrames.push(frame);
						hotChatFrame=frame;
						frame.display=true;
						btn.frame=frame;
					}
				}
			}else{
				if(frame){
					frame.display=true;
				}else if(btn.chatThread){
					frame=await showChatThread({chatThread:btn.chatThread,embed:boxChats});
					if(frame){
						frame.sessionBtn=btn;
						frame.sessionName=btn.chatThread.title;
						chatFrames.push(frame);
						hotChatFrame=frame;
						frame.display=true;
						btn.frame=frame;
					}
				}
			}
			self.showFace("chat");
		}
		/*}#1ILNF8A870Start*/
	};
	//------------------------------------------------------------------------
	cssVO.closeSession=async function(btn){
		/*#{1ILNF8ODG0Start*/
		let frame=btn.frame;
		let idx=chatFrames.indexOf(frame);
		if(idx>=0){
			chatFrames.splice(idx,1);
		}
		boxChatList.removeChild(btn);
		boxChats.removeChild(frame);
		if(frame===hotChatFrame){
			hotChatFrame=null;
		}
		self.showFace("sites");
		/*}#1ILNF8ODG0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.showSessionMenu=async function(btn){
		/*#{1ILNG25GU0Start*/
		let items,item,frame,chatThread,orgName;
		frame=btn.frame;
		chatThread=btn.chatThread;
		orgName=frame?frame.sessionName:(chatThread?chatThread.title:(($ln==="CN")?("AI 对话"):/*EN*/("AI Chat")));
		items=[
			{text:(($ln==="CN")?("重命名会话"):/*EN*/("Rename session")),code:"Rename"},
			{text:(($ln==="CN")?("归档会话"):/*EN*/("Archive session")),code:"Archive",enable:true},
			{text:(($ln==="CN")?("分享会话"):/*EN*/("Share session")),code:"Share",enable:false},
			"_",
			{text:(($ln==="CN")?("删除会话"):/*EN*/("Close session")),code:"Remove"},
		];
		item=await app.modalDlg("/@StdUI/ui/DlgMenu.js",{hud:btn,items:items});
		if(item){
			if(item.code==="Rename"){
				let name=await app.modalDlg("/@StdUI/ui/DlgPrompt.js",{title:(($ln==="CN")?("输入新会话名称"):/*EN*/("Input new session name")),text:orgName});
				if(name){
					if(chatClient && chatThread){
						chatClient.callServer("RenameThread",{thread:chatThread.id,name:name});
					}
					if(frame){
						frame.sessionName=name;
					}
					btn.setName(name);
				}
			}else if(item.code="Archive"){
				if(frame===hotChatFrame){
					await self.closeSiteMenu();
				}
				if(chatClient && chatThread){
					chatClient.callServer("ArchiveThread",{thread:chatThread.id});
				}
			}else if(item.code="Delete"){
				if(frame===hotChatFrame){
					await self.showHome();
				}
				if(chatClient && chatThread){
					chatClient.callServer("DeleteThread",{thread:chatThread.id});
				}
				//self.closeSession(btn);
			}
		}
		/*}#1ILNG25GU0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.updateTokenGas=async function(){
		/*#{1ILOCN62S0Start*/
		let res,userTokens,userGas;
		if(isUpdatingTokenGas){
			return;
		}
		isUpdatingTokenGas=true;
		function numText(num){
			if(num<0){
				return "-";
			}
			num=Math.floor(num);
			if(num>=100){
				return ""+num;
			}
			if(num>=10){
				return "0"+num;
			}
			return "00"+num;
		}
		if(!(await tabNT.checkLogin(false))){
			if(!(await tabNT.maybePreview())){
				userTokens=-1;
				userGas=-1;
				txtToken.text=numText(userTokens);
				txtGas.text=numText(userGas);
				isUpdatingTokenGas=false;
				return;
			}
		}
		try{
			res=await tabNT.makeCall("userCurrency",{});
			if(res.code===200){
				userTokens=res.coins||0;
				userGas=res.points||0;
			}else{
				userTokens=-1;
				userGas=-1;
			}
		}catch(err){
			userTokens=-1;
			userGas=-1;
		}
		txtToken.text=numText(userTokens);
		txtGas.text=numText(userGas);
		isUpdatingTokenGas=false;
		/*}#1ILOCN62S0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.showTokenGasDlg=async function(){
		/*#{1ILOD24FL0Start*/
		await app.modalDlg("/@homekit/ui/DlgTokenGas.js",{});
		/*}#1ILOD24FL0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.showRagMenu=async function(sender){
		/*#{1ILSL1LEM0Start*/
		let items,item;
		items=[
			{text:"Add knowledge",code:"Add",_icon:appCfg.sharedAssets+"/dbinsert.svg"},
			{text:"Query knowledge",code:"Query",_icon:appCfg.sharedAssets+"/dbload.svg"},
		];
		item=await app.modalDlg("/@StdUI/ui/DlgMenu.js",{hud:sender,items:items});
		if(item){
			if(item.code==="Add"){
				//TODO: Code this:
			}else if(item.code==="Query"){
				//TODO: Code this:
			}
		}
		/*}#1ILSL1LEM0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.showChatEntryMenu=async function(sender){
		/*#{1IMR949GQ0Start*/
		let items,item,chatTools,tool;
		items=[
			{text:(($ln==="CN")?("默认对话"):/*EN*/("Default Chat")),tool:null,icon:appCfg.sharedAssets+"/appdata.svg"},
		];
		chatTools=tools.getChatEntryTools();
		for(tool of chatTools){
			items.push({
				text:tool.getNameText($ln),
				tool:tool,
				icon:tool.icon||(appCfg.sharedAssets+"/appdata.svg")
			});
		}
		item=await app.modalDlg("/@StdUI/ui/DlgMenu.js",{hud:sender,items:items});
		if(item){
			let chatTool=item.tool;
			if(chatTool){
				if(chatTool.chatEntry==="Root"){
					self.runTool(chatTool);
					return;
					let agent,agentNode,assets,frame;
					assets=[];
					{
						let list,i,n,line,url;
						list=boxAssets.children;
						n=list.length;
						for(i=0;i<n;i++){
							line=list[i];
							url=line.assetUrl;
							if(url){
								assets.push(url);
							}
						}
						assets=assets.length?assets:null;
					}
					agent=chatTool.filePath;
					agentNode=chatTool.agentNode;
					if(agentNode){
						agent=pathLib.basename(agent);
					}
					let thread=await chatClient.newThread(chatTool.getName($ln));
					frame=await runAgent({chatClient:chatClient,chatThread:thread,agent:agent,agentNode:agentNode,args:"",title:"Chat with AI2Apps",embed:boxChats});
					edCommand.text="";
					txtInputTip.display=true;
					boxAssets.clearChildren();
					self.addSession(frame,chatTool.getName($ln),thread,true);
				}else{
					txtChatEntry.text=item.text;
					self.showFace("entryOn");
					btnChatEntry.icon=item.icon;
					chatEntryTool=item.tool;
				}
			}else{
				txtChatEntry.text="";
				btnChatEntry.icon=appCfg.sharedAssets+"/appdata.svg";
				self.showFace("entryOff");
				chatEntryTool=null;
			}
		}
		/*}#1IMR949GQ0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.clearChatEntryTool=async function(){
		/*#{1IMS6S28S0Start*/
		txtChatEntry.text="";
		self.showFace("entryOff");
		btnChatEntry.icon=appCfg.sharedAssets+"/appdata.svg";
		chatEntryTool=null;
		/*}#1IMS6S28S0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.editConfig=async function(sender,event){
		/*#{1INGQQFU50Start*/
		let config;
		try{
			config=await tabFS.readFile("/coke/ai.config.json","utf8");
			config=JSON.parse(config);
		}catch(err){
			config={
				models:{
					"default":{
						"platform": "OpenAI",
						"model": "gpt-4o"
					},
					"lite":{
						"platform": "OpenAI",
						"model": "gpt-4o-mini"
					},
					"fast":{
						"platform": "OpenAI",
						"model": "gpt-4o-mini"
					},
					"expert":{
						"platform": "OpenAI",
						"model": "gpt-4o"
					},
					"coding":{
						"platform": "OpenAI",
						"model": "gpt-4o"
					},
					"planning":{
						"platform": "OpenAI",
						"model": "gpt-4o"
					},
					"view":{
						"platform": "OpenAI",
						"model": "gpt-4o"
					},
				}
			};
			await tabFS.writeFile("/coke/ai.config.json",JSON.stringify(config,null,"\t"));
		}
		config=await app.modalDlg("/@StdUI/ui/DlgDataView.js",{
			template:AIConfig,object:config,title:(($ln==="CN")?("智能体会话设置"):/*EN*/("Agent Session Settings")),width:500,
		});
		if(config){
			await tabFS.writeFile("/coke/ai.config.json",JSON.stringify(config,null,"\t"));
		}
		/*}#1INGQQFU50Start*/
	};
	//------------------------------------------------------------------------
	cssVO.checkLogin=async function(callback){
		/*#{1IRPPTA4E0Start*/
		let res;
		res=await tabNT.makeCall("getKeyPackages",{});
		if(res.code===200){
			if(!(await tabNT.checkLogin(true,true))){
				if(!(await app.modalDlg("/@homekit/ui/DlgLogin.js",{x:app.width/2,y:100,alignH:1}))){
					self.checkLogin(callback);
				}else{
					self.updateTokenGas();
					callback();
				}
			}else{
				callback();
			}
		}else{
			window.alert((($ln==="CN")?("网络错误，请检查您的连接，并重试。"):/*EN*/("Network error, please check your connection and try again.")));	
			self.checkLogin(callback);
		}
		/*}#1IRPPTA4E0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.showThreads=async function(list){
		/*#{1IUKJE2JK0Start*/
		let thread,btn,n,i;
		n=list.length;
		for(i=n-1;i>=0;i--){
			thread=list[i];
			btn=thread.sessionBtn;
			if(!btn){
				btn=await self.addSession(null,thread.title,thread,false);
				btn.showFace("blur");
			}
			boxChatList.insertBefore(btn,boxChatList.firstChild);
		}
		let btns=boxChatList.children;
		n=btns.length;
		for(i=list.length;i<n;i++){
			btn=btns[i];
			boxChatList.removeChild(btn);
		}
		/*}#1IUKJE2JK0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.showWait=async function(text){
		/*#{1IUTAKDD30Start*/
		txtWait.text=text;
		self.showFace("offline");
		/*}#1IUTAKDD30Start*/
	};
	//------------------------------------------------------------------------
	cssVO.hideWait=async function(){
		/*#{1IUTAT3U90Start*/
		self.showFace("online");
		/*}#1IUTAT3U90Start*/
	};
	//------------------------------------------------------------------------
	cssVO.reconnectClient=async function(){
		/*#{1IUTCSNO50Start*/
		self.showWait("Reconnecting to AI2Apps server...");
		do{
			await sleep(3000);
			console.log("Retry connect ");
			if(await chatClient.connect({shadow:false})){
				return;
			}
		}while(true);
		/*}#1IUTCSNO50Start*/
	};
	//------------------------------------------------------------------------
	cssVO.showShareDlg=async function(){
		/*#{1IUV8S9RE0Start*/
		await app.modalDlg("./ui/DlgShare.js",{});
		self.checkShadowDomain();
		/*}#1IUV8S9RE0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.checkShadowDomain=async function(){
		/*#{1IV005SMO0Start*/
		let res;
		res=await tabNT.makeCall("shadowDomain",{action:"get"});
		if(!res || res.code!==200){
			return;
		}
		if(res.key && res.domain){
			if(window.tabApi){
				window.tabApi.shadowDomain({userId:tabNT.loginVO.userId,key:res.key,domain:res.domain});
			}
			btnShare.text=(($ln==="CN")?("启用"):/*EN*/("ON"));
		}else{
			if(window.tabApi){
				window.tabApi.shadowDomain(null);
			}
			btnShare.text=(($ln==="CN")?("停用"):/*EN*/("OFF"));
		}
		/*}#1IV005SMO0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.showSideBar=async function(){
		/*#{1IVMIS82D0Start*/
		self.showFace("sidebarOn");
		localStorage.setItem("Dashboard-Sidebar","show");
		/*}#1IVMIS82D0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.hideSideBar=async function(){
		/*#{1IVMISH2R0Start*/
		self.showFace("sidebarOff");
		localStorage.setItem("Dashboard-Sidebar","hide");
		/*}#1IVMISH2R0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.showAppMart=async function(){
		/*#{1J0DG20FA0Start*/
		await AppLib.ensurePackageInstalled(app,"user",false);
		app.openAppMeta("ToolMart@user");
		/*}#1J0DG20FA0Start*/
	};
	/*#{1I10E0NR21PostCSSVO*/
	/*}#1I10E0NR21PostCSSVO*/
	cssVO.constructor=DashBoard;
	return cssVO;
};
/*#{1I10E0NR21ExCodes*/
/*}#1I10E0NR21ExCodes*/

//----------------------------------------------------------------------------
DashBoard.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1I10E0NR21PreAISpot*/
	/*}#1I10E0NR21PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1I10E0NR21PostAISpot*/
	/*}#1I10E0NR21PostAISpot*/
	return exposeVO;
};

/*#{1I10E0NR20EndDoc*/
/*}#1I10E0NR20EndDoc*/

export default DashBoard;
export{DashBoard};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "UIView",
//	"jaxId": "1I10E0NR20",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1I10E0NR22",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "1200",
//				"screenH": "700",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1I10E0NR23",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1I10E0NR24",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1I10E0NR25",
//			"attrs": {}
//		},
//		"localVars": {
//			"jaxId": "1I10E0NR26",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1I10E0NR27",
//			"attrs": {
//				"naviBoxW": {
//					"type": "int",
//					"valText": "250"
//				}
//			}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I1C1K57N0",
//					"attrs": {
//						"id": "readIndex",
//						"label": "New AI Seg",
//						"x": "65",
//						"y": "50",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I1C1LTNG0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I1C1LTNG1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I1C1LTNG2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I1C1JAVP0",
//					"attrs": {
//						"id": "listTools",
//						"label": "New AI Seg",
//						"x": "65",
//						"y": "120",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I1C1LTNG3",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I1C1LTNG4",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I1C1LTNG5",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IVREL1V00",
//					"attrs": {
//						"id": "listShortcuts",
//						"label": "New AI Seg",
//						"x": "280",
//						"y": "120",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IVRELCR20",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IVRELCR21",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IVRELCR22",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I19R1NLP0",
//					"attrs": {
//						"id": "createTool",
//						"label": "New AI Seg",
//						"x": "65",
//						"y": "190",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I19R24EP0",
//							"attrs": {
//								"sender": {
//									"valText": "null"
//								},
//								"event": {
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I19R24EP1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I19R24EP2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I1I62ICH0",
//					"attrs": {
//						"id": "showGroup",
//						"label": "New AI Seg",
//						"x": "65",
//						"y": "265",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I1I62UCD0",
//							"attrs": {
//								"group": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I1I62UCD1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I1I62UCD2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I1I64CBJ0",
//					"attrs": {
//						"id": "closeSiteMenu",
//						"label": "New AI Seg",
//						"x": "65",
//						"y": "335",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I1I64MND0",
//							"attrs": {
//								"sender": {
//									"valText": "null"
//								},
//								"event": {
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I1I64MND1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I1I64MND2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I1IF0PR70",
//					"attrs": {
//						"id": "showMenu",
//						"label": "New AI Seg",
//						"x": "65",
//						"y": "415",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I1IF19DQ0",
//							"attrs": {
//								"sender": {
//									"valText": "null"
//								},
//								"event": {
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I1IF19DQ1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": [
//								{
//									"type": "flowseg",
//									"def": "Menu",
//									"jaxId": "1I1IF3KE60",
//									"attrs": {
//										"id": "menu",
//										"label": "New AI Seg",
//										"x": "280",
//										"y": "415",
//										"desc": "",
//										"codes": "false",
//										"launcher": "sender",
//										"outlets": {
//											"attrs": [
//												{
//													"type": "aioutlet",
//													"def": "MenuItem",
//													"jaxId": "1I1IF1JJO1",
//													"attrs": {
//														"id": "Cloud",
//														"text": {
//															"type": "string",
//															"valText": "Find and install agent from Agent Mart",
//															"localize": {
//																"EN": "Find and install agent from Agent Mart",
//																"CN": "从智能体超市查找安装智能体"
//															},
//															"localizable": true
//														},
//														"desc": "",
//														"enable": "true",
//														"icon": "#appCfg.sharedAssets+\"/store.svg\""
//													}
//												},
//												{
//													"type": "aioutlet",
//													"def": "MenuItem",
//													"jaxId": "1I1IF1JJO0",
//													"attrs": {
//														"id": "File",
//														"text": {
//															"type": "string",
//															"valText": "Import agent or tool-chain from file",
//															"localize": {
//																"EN": "Import agent or tool-chain from file",
//																"CN": "从文件导入智能体或工具链"
//															},
//															"localizable": true
//														},
//														"desc": "",
//														"icon": "#appCfg.sharedAssets+\"/folder.svg\""
//													}
//												},
//												{
//													"type": "aioutlet",
//													"def": "MenuItem",
//													"jaxId": "1I1IF1JJO2",
//													"attrs": {
//														"id": "AddGroup",
//														"text": {
//															"type": "string",
//															"valText": "New group entry",
//															"localize": {
//																"EN": "New group entry",
//																"CN": "新建工具组入口"
//															},
//															"localizable": true
//														},
//														"desc": "",
//														"enable": "true",
//														"icon": "#appCfg.sharedAssets+\"/additem.svg\""
//													}
//												},
//												{
//													"type": "aioutlet",
//													"def": "MenuItem",
//													"jaxId": "1I1Q3R1JQ0",
//													"attrs": {
//														"id": "Chat",
//														"text": {
//															"type": "string",
//															"valText": "Create an AI agent by chat",
//															"localize": {
//																"EN": "Create an AI agent by chat",
//																"CN": "通过对话创建智能体"
//															},
//															"localizable": true
//														},
//														"desc": "",
//														"icon": "#appCfg.sharedAssets+\"/aichat.svg\"",
//														"enable": "false"
//													}
//												},
//												{
//													"type": "aioutlet",
//													"def": "MenuItem",
//													"jaxId": "1ILJLS5EV0",
//													"attrs": {
//														"id": "GitHub",
//														"text": {
//															"type": "string",
//															"valText": "Create agent from GitHub project",
//															"localize": {
//																"EN": "Create agent from GitHub project",
//																"CN": "从GitHub项目创建智能体"
//															},
//															"localizable": true
//														},
//														"desc": "",
//														"enable": "false",
//														"icon": "#appCfg.sharedAssets+\"/star_e.svg\""
//													}
//												}
//											]
//										},
//										"outlet": {
//											"jaxId": "1I1IF3KE61",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											}
//										}
//									},
//									"icon": "menu.svg",
//									"reverseOutlets": true
//								}
//							]
//						},
//						"outlet": {
//							"jaxId": "1I1IF19DQ2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1IF3KE60"
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I1IGCNVT0",
//					"attrs": {
//						"id": "showAddToolMenu",
//						"label": "New AI Seg",
//						"x": "65",
//						"y": "600",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I1IGE7NS0",
//							"attrs": {
//								"sender": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I1IGE7NS1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": [
//								{
//									"type": "flowseg",
//									"def": "Menu",
//									"jaxId": "1I1IGE7NS2",
//									"attrs": {
//										"id": "menu",
//										"label": "New AI Seg",
//										"x": "330",
//										"y": "600",
//										"desc": "",
//										"codes": "false",
//										"launcher": "sender",
//										"outlets": {
//											"attrs": [
//												{
//													"type": "aioutlet",
//													"def": "MenuItem",
//													"jaxId": "1I1IGDBG51",
//													"attrs": {
//														"id": "Cloud",
//														"text": {
//															"type": "string",
//															"valText": "Find tool from agent hub",
//															"localize": {
//																"EN": "Find tool from agent hub",
//																"CN": "从智能体中心查找工具"
//															},
//															"localizable": true
//														},
//														"desc": "",
//														"icon": "#appCfg.sharedAssets+\"/cloud.svg\"",
//														"enable": "false"
//													}
//												},
//												{
//													"type": "aioutlet",
//													"def": "MenuItem",
//													"jaxId": "1I1IGDBG50",
//													"attrs": {
//														"id": "File",
//														"text": {
//															"type": "string",
//															"valText": "Import tool from file",
//															"localize": {
//																"EN": "Import tool from file",
//																"CN": "从文件导入工具"
//															},
//															"localizable": true
//														},
//														"desc": "",
//														"icon": "#appCfg.sharedAssets+\"/folder.svg\""
//													}
//												},
//												{
//													"type": "aioutlet",
//													"def": "MenuItem",
//													"jaxId": "1I1JVCGEF0",
//													"attrs": {
//														"id": "Chat",
//														"text": {
//															"type": "string",
//															"valText": "Create a new tool by chat with AI",
//															"localize": {
//																"EN": "Create a new tool by chat with AI",
//																"CN": "通过与AI对话创建新工具"
//															},
//															"localizable": true
//														},
//														"desc": "",
//														"icon": "#appCfg.sharedAssets+\"/aichat.svg\"",
//														"enable": "false"
//													}
//												}
//											]
//										},
//										"outlet": {
//											"jaxId": "1I1IGE7NS3",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											}
//										}
//									},
//									"icon": "menu.svg",
//									"reverseOutlets": true
//								}
//							]
//						},
//						"outlet": {
//							"jaxId": "1I1IGE7NS4",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1IGE7NS2"
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I1M6K4VG0",
//					"attrs": {
//						"id": "runCommand",
//						"label": "New AI Seg",
//						"x": "70",
//						"y": "700",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I1M6L3OP0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I1M6L3OP1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I1M6L3OP2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IVT3STI50",
//					"attrs": {
//						"id": "runTool",
//						"label": "New AI Seg",
//						"x": "280",
//						"y": "700",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IVT3TKOF0",
//							"attrs": {
//								"tool": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IVT3TKOF1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IVT3TKOF2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IV3VOR810",
//					"attrs": {
//						"id": "newShadowThread",
//						"label": "New AI Seg",
//						"x": "505",
//						"y": "700",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IV3VPLA90",
//							"attrs": {
//								"thread": {
//									"type": "auto",
//									"valText": ""
//								},
//								"args": {
//									"type": "auto",
//									"valText": ""
//								},
//								"tool": {
//									"type": "auto",
//									"valText": "#null"
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IV3VPLA91",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IV3VPLA92",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I1OPT0RJ0",
//					"attrs": {
//						"id": "addToolByPath",
//						"label": "New AI Seg",
//						"x": "65",
//						"y": "770",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I1OPTTF90",
//							"attrs": {
//								"hud": {
//									"type": "auto",
//									"valText": "null"
//								},
//								"group": {
//									"type": "auto",
//									"valText": "null"
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I1OPTTF91",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I1OPTTF92",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I1P0EB940",
//					"attrs": {
//						"id": "maybeSaveTools",
//						"label": "New AI Seg",
//						"x": "65",
//						"y": "860",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I1P0EI2M0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I1P0EI2M1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I1P0EI2M2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I1P2K9ER0",
//					"attrs": {
//						"id": "saveTools",
//						"label": "New AI Seg",
//						"x": "65",
//						"y": "950",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I1P34BTI0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I1P34BTI1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I1P34BTI2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I1QAF8RC0",
//					"attrs": {
//						"id": "addNewGroup",
//						"label": "New AI Seg",
//						"x": "65",
//						"y": "1160",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I1QAFL6H0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I1QAFL6H1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I1QAFL6H2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I1QC7IVU0",
//					"attrs": {
//						"id": "showGroupMenu",
//						"label": "New AI Seg",
//						"x": "65",
//						"y": "1280",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I1QCBLDM0",
//							"attrs": {
//								"sender": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I1QCBLDM1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": [
//								{
//									"type": "flowseg",
//									"def": "Menu",
//									"jaxId": "1I1QCBLDM2",
//									"attrs": {
//										"id": "menu",
//										"label": "New AI Seg",
//										"x": "325",
//										"y": "1280",
//										"desc": "",
//										"codes": "false",
//										"launcher": "sender",
//										"outlets": {
//											"attrs": [
//												{
//													"type": "aioutlet",
//													"def": "MenuItem",
//													"jaxId": "1I1QC7UIB0",
//													"attrs": {
//														"id": "Rename",
//														"text": {
//															"type": "string",
//															"valText": "Rename",
//															"localize": {
//																"EN": "Rename",
//																"CN": "改名"
//															},
//															"localizable": true
//														},
//														"desc": "",
//														"icon": "#appCfg.sharedAssets+\"/rename.svg\""
//													}
//												},
//												{
//													"type": "aioutlet",
//													"def": "MenuItem",
//													"jaxId": "1I1QC7UIB1",
//													"attrs": {
//														"id": "Icon",
//														"text": {
//															"type": "string",
//															"valText": "Select icon",
//															"localize": {
//																"EN": "Select icon",
//																"CN": "选择图标"
//															},
//															"localizable": true
//														},
//														"desc": "",
//														"icon": "#appCfg.sharedAssets+\"/hudimg.svg\""
//													}
//												},
//												{
//													"type": "aioutlet",
//													"def": "MenuItem",
//													"jaxId": "1I1QC7UIB2",
//													"attrs": {
//														"id": "Remove",
//														"text": {
//															"type": "string",
//															"valText": "Remove this group",
//															"localize": {
//																"EN": "Remove this group",
//																"CN": "移除该组"
//															},
//															"localizable": true
//														},
//														"desc": "",
//														"icon": "#appCfg.sharedAssets+\"/trash.svg\""
//													}
//												}
//											]
//										},
//										"outlet": {
//											"jaxId": "1I1QCBLDM3",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											}
//										}
//									},
//									"icon": "menu.svg",
//									"reverseOutlets": true
//								}
//							]
//						},
//						"outlet": {
//							"jaxId": "1I1QCBLDM4",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1QCBLDM2"
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I1Q4CLTB0",
//					"attrs": {
//						"id": "showToolMenu",
//						"label": "New AI Seg",
//						"x": "65",
//						"y": "1040",
//						"desc": "",
//						"codes": "true",
//						"args": {
//							"jaxId": "1I1Q4J0LC0",
//							"attrs": {
//								"tool": {
//									"type": "auto",
//									"valText": "null"
//								},
//								"group": {
//									"type": "auto",
//									"valText": ""
//								},
//								"sender": {
//									"type": "auto",
//									"valText": "null"
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I1Q4J0LC1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": [
//								{
//									"type": "flowseg",
//									"def": "Menu",
//									"jaxId": "1I1Q4J0LC2",
//									"attrs": {
//										"id": "menu",
//										"label": "New AI Seg",
//										"x": "315",
//										"y": "1040",
//										"desc": "",
//										"codes": "true",
//										"launcher": "sender",
//										"outlets": {
//											"attrs": [
//												{
//													"type": "aioutlet",
//													"def": "MenuItem",
//													"jaxId": "1I278APR30",
//													"attrs": {
//														"id": "Info",
//														"text": {
//															"type": "string",
//															"valText": "Tool Information",
//															"localize": {
//																"EN": "Tool Information",
//																"CN": "工具信息"
//															},
//															"localizable": true
//														},
//														"desc": "",
//														"icon": "#appCfg.sharedAssets+\"/idcard.svg\""
//													}
//												},
//												{
//													"type": "aioutlet",
//													"def": "MenuItem",
//													"jaxId": "1I1Q4HMJ51",
//													"attrs": {
//														"id": "Open",
//														"text": {
//															"type": "string",
//															"valText": "Execute Tool",
//															"localize": {
//																"EN": "Execute Tool",
//																"CN": "运行工具"
//															},
//															"localizable": true
//														},
//														"desc": "",
//														"icon": "#appCfg.sharedAssets+\"/run.svg\""
//													}
//												},
//												{
//													"type": "aioutlet",
//													"def": "MenuItem",
//													"jaxId": "1I278F9M10",
//													"attrs": {
//														"id": "Enbable",
//														"text": {
//															"type": "string",
//															"valText": "Enable",
//															"localize": {
//																"EN": "Enable",
//																"CN": "启用"
//															},
//															"localizable": true
//														},
//														"desc": "",
//														"icon": "#appCfg.sharedAssets+\"/check.svg\""
//													}
//												},
//												{
//													"type": "aioutlet",
//													"def": "MenuItem",
//													"jaxId": "1I278EITH0",
//													"attrs": {
//														"id": "Disable",
//														"text": {
//															"type": "string",
//															"valText": "Disable",
//															"localize": {
//																"EN": "Disable",
//																"CN": "禁用"
//															},
//															"localizable": true
//														},
//														"desc": "",
//														"icon": "#appCfg.sharedAssets+\"/lock.svg\""
//													}
//												},
//												{
//													"type": "aioutlet",
//													"def": "MenuItem",
//													"jaxId": "1I1Q4HMJ50",
//													"attrs": {
//														"id": "Delete",
//														"text": {
//															"type": "string",
//															"valText": "Remove",
//															"localize": {
//																"EN": "Remove",
//																"CN": "移除"
//															},
//															"localizable": true
//														},
//														"desc": "",
//														"icon": "#appCfg.sharedAssets+\"/trash.svg\""
//													}
//												}
//											]
//										},
//										"outlet": {
//											"jaxId": "1I1Q4J0LC3",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											}
//										}
//									},
//									"icon": "menu.svg",
//									"reverseOutlets": true
//								}
//							]
//						},
//						"outlet": {
//							"jaxId": "1I1Q4J0LC4",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1Q4J0LC2"
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I1V5OGU40",
//					"attrs": {
//						"id": "showChainMenu",
//						"label": "New AI Seg",
//						"x": "65",
//						"y": "1460",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I1V5R31F0",
//							"attrs": {
//								"chain": {
//									"type": "auto",
//									"valText": "null"
//								},
//								"group": {
//									"type": "auto",
//									"valText": "null"
//								},
//								"sender": {
//									"type": "auto",
//									"valText": "null"
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I1V5R31F1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": [
//								{
//									"type": "flowseg",
//									"def": "Menu",
//									"jaxId": "1I1V5R31F2",
//									"attrs": {
//										"id": "menu",
//										"label": "New AI Seg",
//										"x": "325",
//										"y": "1460",
//										"desc": "",
//										"codes": "false",
//										"launcher": "sender",
//										"outlets": {
//											"attrs": [
//												{
//													"type": "aioutlet",
//													"def": "MenuItem",
//													"jaxId": "1I29JHLIL0",
//													"attrs": {
//														"id": "Info",
//														"text": {
//															"type": "string",
//															"valText": "Chain information",
//															"localize": {
//																"EN": "Chain information",
//																"CN": "工具链信息"
//															},
//															"localizable": true
//														},
//														"desc": "",
//														"icon": "#appCfg.sharedAssets+\"/idcard.svg\""
//													}
//												},
//												{
//													"type": "aioutlet",
//													"def": "MenuItem",
//													"jaxId": "1I1V5PBT30",
//													"attrs": {
//														"id": "Open",
//														"text": {
//															"type": "string",
//															"valText": "Execute Tool Chain",
//															"localize": {
//																"EN": "Execute Tool Chain",
//																"CN": "执行工具链"
//															},
//															"localizable": true
//														},
//														"desc": "",
//														"icon": "#appCfg.sharedAssets+\"/run.svg\""
//													}
//												},
//												{
//													"type": "aioutlet",
//													"def": "MenuItem",
//													"jaxId": "1I1V5PBT31",
//													"attrs": {
//														"id": "Delete",
//														"text": {
//															"type": "string",
//															"valText": "Delete Tool Chain",
//															"localize": {
//																"EN": "Delete Tool Chain",
//																"CN": "删除工具连锁"
//															},
//															"localizable": true
//														},
//														"desc": "",
//														"icon": "#appCfg.sharedAssets+\"/trash.svg\""
//													}
//												}
//											]
//										},
//										"outlet": {
//											"jaxId": "1I1V5R31F3",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											}
//										}
//									},
//									"icon": "menu.svg",
//									"reverseOutlets": true
//								}
//							]
//						},
//						"outlet": {
//							"jaxId": "1I1V5R31F4",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1V5R31F2"
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I268L5VR0",
//					"attrs": {
//						"id": "showAllTools",
//						"label": "New AI Seg",
//						"x": "325",
//						"y": "1640",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I268LHSS0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I268LHSS1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I268LHSS2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I268LO9T0",
//					"attrs": {
//						"id": "showAllChains",
//						"label": "New AI Seg",
//						"x": "585",
//						"y": "1640",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I268M3J20",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I268M3J21",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I268M3J22",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I2ESN96I0",
//					"attrs": {
//						"id": "showBots",
//						"label": "New AI Seg",
//						"x": "65",
//						"y": "1640",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I2ESNKFT0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I2ESNKFT1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I2ESNKFT2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1ILIGIPH20",
//					"attrs": {
//						"id": "chooseChatAsset",
//						"label": "New AI Seg",
//						"x": "65",
//						"y": "1755",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1ILIGJUN80",
//							"attrs": {
//								"sender": {
//									"type": "auto",
//									"valText": ""
//								},
//								"event": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1ILIGJUN81",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1ILIGJUN82",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1ILIHR4B10",
//					"attrs": {
//						"id": "addChatAsset",
//						"label": "New AI Seg",
//						"x": "325",
//						"y": "1755",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1ILIHVHNB0",
//							"attrs": {
//								"fileName": {
//									"type": "string",
//									"valText": ""
//								},
//								"fileData": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1ILIHVHNB1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1ILIHVHNB2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1ILNF7L6L0",
//					"attrs": {
//						"id": "addSession",
//						"label": "New AI Seg",
//						"x": "65",
//						"y": "1860",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1ILNF89TK0",
//							"attrs": {
//								"frame": {
//									"type": "auto",
//									"valText": "null"
//								},
//								"prompt": {
//									"type": "string",
//									"valText": ""
//								},
//								"thread": {
//									"type": "auto",
//									"valText": ""
//								},
//								"show": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1ILNF89TK1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1ILNF89TK2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1ILNF8A870",
//					"attrs": {
//						"id": "showSession",
//						"label": "New AI Seg",
//						"x": "325",
//						"y": "1860",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1ILNF8A880",
//							"attrs": {
//								"btn": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1ILNF8A881",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1ILNF8A882",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1ILNF8ODG0",
//					"attrs": {
//						"id": "closeSession",
//						"label": "New AI Seg",
//						"x": "585",
//						"y": "1860",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1ILNF8ODG1",
//							"attrs": {
//								"btn": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1ILNF8ODG2",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1ILNF8ODG3",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1ILNG25GU0",
//					"attrs": {
//						"id": "showSessionMenu",
//						"label": "New AI Seg",
//						"x": "825",
//						"y": "1860",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1ILNG2IC60",
//							"attrs": {
//								"btn": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1ILNG2IC61",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1ILNG2IC62",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1ILOCN62S0",
//					"attrs": {
//						"id": "updateTokenGas",
//						"label": "New AI Seg",
//						"x": "740",
//						"y": "50",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1ILOCNNTH0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1ILOCNNTH1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1ILOCNNTH2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1ILOD24FL0",
//					"attrs": {
//						"id": "showTokenGasDlg",
//						"label": "New AI Seg",
//						"x": "1000",
//						"y": "50",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1ILOD2R3M0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1ILOD2R3M1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1ILOD2R3M2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1ILSL1LEM0",
//					"attrs": {
//						"id": "showRagMenu",
//						"label": "New AI Seg",
//						"x": "1110",
//						"y": "1755",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1ILSL4PKP0",
//							"attrs": {
//								"sender": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1ILSL4PKP1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1ILSL4PKP2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IMR949GQ0",
//					"attrs": {
//						"id": "showChatEntryMenu",
//						"label": "New AI Seg",
//						"x": "585",
//						"y": "1755",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IMR94VDR0",
//							"attrs": {
//								"sender": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IMR94VDR1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IMR94VDR2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IMS6S28S0",
//					"attrs": {
//						"id": "clearChatEntryTool",
//						"label": "New AI Seg",
//						"x": "850",
//						"y": "1755",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IMS6SCEO0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IMS6SCEO1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IMS6SCEO2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1INGQQFU50",
//					"attrs": {
//						"id": "editConfig",
//						"label": "New AI Seg",
//						"x": "280",
//						"y": "190",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1INGQR5Q80",
//							"attrs": {
//								"sender": {
//									"type": "auto",
//									"valText": ""
//								},
//								"event": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1INGQR5Q81",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1INGQR5Q82",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IRPPTA4E0",
//					"attrs": {
//						"id": "checkLogin",
//						"label": "New AI Seg",
//						"x": "505",
//						"y": "50",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IRPPTGSL0",
//							"attrs": {
//								"callback": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IRPPTGSL1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IRPPTGSL2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IUKJE2JK0",
//					"attrs": {
//						"id": "showThreads",
//						"label": "New AI Seg",
//						"x": "65",
//						"y": "1955",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IUKJEKVI0",
//							"attrs": {
//								"list": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IUKJEKVI1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IUKJEKVI2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IUTAKDD30",
//					"attrs": {
//						"id": "showWait",
//						"label": "New AI Seg",
//						"x": "280",
//						"y": "50",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IUTAKPOU0",
//							"attrs": {
//								"text": {
//									"type": "string",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IUTAKPOU1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IUTAKPOU2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IUTAT3U90",
//					"attrs": {
//						"id": "hideWait",
//						"label": "New AI Seg",
//						"x": "505",
//						"y": "120",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IUTAT9240",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IUTAT9241",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IUTAT9242",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IUTCSNO50",
//					"attrs": {
//						"id": "reconnectClient",
//						"label": "New AI Seg",
//						"x": "730",
//						"y": "120",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IUTCT93G0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IUTCT93G1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IUTCT93G2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IUV8S9RE0",
//					"attrs": {
//						"id": "showShareDlg",
//						"label": "New AI Seg",
//						"x": "325",
//						"y": "1960",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IUV8SLFG0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IUV8SLFG1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IUV8SLFG2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IV005SMO0",
//					"attrs": {
//						"id": "checkShadowDomain",
//						"label": "New AI Seg",
//						"x": "965",
//						"y": "120",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IV006AVK0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IV006AVK1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IV006AVK2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IVMIS82D0",
//					"attrs": {
//						"id": "showSideBar",
//						"label": "New AI Seg",
//						"x": "505",
//						"y": "265",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IVMITNP90",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IVMITNP91",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IVMITNP92",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IVMISH2R0",
//					"attrs": {
//						"id": "hideSideBar",
//						"label": "New AI Seg",
//						"x": "740",
//						"y": "265",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IVMITNP93",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IVMITNP94",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IVMITNP95",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1J0DG20FA0",
//					"attrs": {
//						"id": "showAppMart",
//						"label": "New AI Seg",
//						"x": "605",
//						"y": "400",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1J0DG2CT50",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1J0DG2CT51",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1J0DG2CT52",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				}
//			]
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1I10E0NR28",
//			"attrs": {
//				"sites": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1I1D5700V0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "true",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1I1D58F460",
//							"attrs": {}
//						}
//					}
//				},
//				"siteMenu": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1I1D5774S0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1I1D58F461",
//							"attrs": {}
//						}
//					}
//				},
//				"chat": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1ILN7H5CK0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1ILN7IHKQ0",
//							"attrs": {}
//						}
//					}
//				},
//				"entryOn": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IMR8US3B0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IMR90II40",
//							"attrs": {}
//						}
//					}
//				},
//				"entryOff": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IMR8V39V0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IMR90II41",
//							"attrs": {}
//						}
//					}
//				},
//				"offline": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IUTA2UGH0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IUTA8SR10",
//							"attrs": {}
//						}
//					}
//				},
//				"online": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IUTA32CV0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IUTA8SR11",
//							"attrs": {}
//						}
//					}
//				},
//				"sidebarOn": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IVH6SHR30",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IVH71KB00",
//							"attrs": {}
//						}
//					}
//				},
//				"sidebarOff": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IVH6TC9J0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IVH71KB01",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1I10E0NR29",
//			"attrs": {}
//		},
//		"exposeToAI": "true",
//		"descAI": "",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "view",
//			"jaxId": "1I10E0NR21",
//			"attrs": {
//				"properties": {
//					"jaxId": "1I10E0NR210",
//					"attrs": {
//						"type": "view",
//						"id": "",
//						"position": "Absolute",
//						"x": "${state.naviBoxW+50},state",
//						"y": "0",
//						"w": "100%-300",
//						"h": "100%",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "[0,0,0,0]",
//						"padding": "10",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Flex Y",
//						"subAlign": "Start",
//						"itemsAlign": "Center"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1ILNAB5GG0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1ILNAF7KT0",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxHome",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "1200",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex Y",
//										"subAlign": "Start",
//										"itemsAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1I1US7JF80",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I1USEVPL0",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxLogo",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "240",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "0",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex X",
//														"itemsAlign": "Center",
//														"flex": "false"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1I1USB7L80",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I1USDQBC0",
//																	"attrs": {
//																		"type": "hud",
//																		"id": "",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "50%-40",
//																		"h": "100%",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1I1USDQBC1",
//																	"attrs": {
//																		"1IMR8US3B0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IMR90II410",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IMR90II411",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IMR8US3B0",
//																			"faceTagName": "entryOn"
//																		},
//																		"1I1D5774S0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IUVB7R1914",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IUVB7R1915",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I1D5774S0",
//																			"faceTagName": "siteMenu"
//																		},
//																		"1IMR8V39V0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IUVB7R1920",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IUVB7R1921",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IMR8V39V0",
//																			"faceTagName": "entryOff"
//																		},
//																		"1IUTA32CV0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVMJ6PDI0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVMJ6PDI1",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IUTA32CV0",
//																			"faceTagName": "online"
//																		},
//																		"1IVH6SHR30": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVMNKTM70",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVMNKTM71",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IVH6SHR30",
//																			"faceTagName": "sidebarOn"
//																		},
//																		"1ILN7H5CK0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVMOBA2Q0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVMOBA2Q1",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1ILN7H5CK0",
//																			"faceTagName": "chat"
//																		},
//																		"1I1D5700V0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J04JIM5V0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J04JIM5V1",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I1D5700V0",
//																			"faceTagName": "sites"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1I1USDQBC2",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1I1USDQBC3",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false",
//																"exposeContainer": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "image",
//															"jaxId": "1I1USCCFA0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I1USCCFA1",
//																	"attrs": {
//																		"type": "image",
//																		"id": "ImgLogo",
//																		"position": "relative",
//																		"x": "40",
//																		"y": "40",
//																		"w": "80",
//																		"h": "80",
//																		"anchorH": "Center",
//																		"anchorV": "Center",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "0",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"image": "#appCfg.sharedAssets+\"/aalogo.svg\"",
//																		"autoSize": "false",
//																		"fitSize": "Fit",
//																		"repeat": "true",
//																		"alignX": "Left",
//																		"alignY": "Top"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1I1USCCFB0",
//																	"attrs": {
//																		"1IMR8US3B0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IMR90II414",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IMR90II415",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IMR8US3B0",
//																			"faceTagName": "entryOn"
//																		},
//																		"1I1D5774S0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IUVB7R1922",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IUVB7R1923",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I1D5774S0",
//																			"faceTagName": "siteMenu"
//																		},
//																		"1IMR8V39V0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IUVB7R1928",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IUVB7R1929",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IMR8V39V0",
//																			"faceTagName": "entryOff"
//																		},
//																		"1IUTA32CV0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVMJ6PDI4",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVMJ6PDI5",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IUTA32CV0",
//																			"faceTagName": "online"
//																		},
//																		"1IVH6SHR30": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVMNKTM80",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVMNKTM81",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IVH6SHR30",
//																			"faceTagName": "sidebarOn"
//																		},
//																		"1ILN7H5CK0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVMOBA2Q4",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVMOBA2Q5",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1ILN7H5CK0",
//																			"faceTagName": "chat"
//																		},
//																		"1I1D5700V0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J04JIM5V2",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J04JIM5V3",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I1D5700V0",
//																			"faceTagName": "sites"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1I1USCCFB3",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1INAU90TS0",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1INAU97EB0",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1I1USCCFB4",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "true"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1I1USDRD10",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I1USDRD11",
//																	"attrs": {
//																		"type": "hud",
//																		"id": "",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "50%-40",
//																		"h": "100%",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "10",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"contentLayout": "Flex Y",
//																		"subAlign": "Start"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1I1USDRD20",
//																	"attrs": {
//																		"1IMR8US3B0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IMR90II418",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IMR90II419",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IMR8US3B0",
//																			"faceTagName": "entryOn"
//																		},
//																		"1I1D5774S0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IUVB7R1930",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IUVB7R1931",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I1D5774S0",
//																			"faceTagName": "siteMenu"
//																		},
//																		"1IMR8V39V0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IUVB7R1936",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IUVB7R1937",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IMR8V39V0",
//																			"faceTagName": "entryOff"
//																		},
//																		"1IUTA32CV0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVMJ6PDI8",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVMJ6PDI9",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IUTA32CV0",
//																			"faceTagName": "online"
//																		},
//																		"1IVH6SHR30": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVMNKTM82",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVMNKTM83",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IVH6SHR30",
//																			"faceTagName": "sidebarOn"
//																		},
//																		"1ILN7H5CK0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVMOBA2Q8",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVMOBA2Q9",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1ILN7H5CK0",
//																			"faceTagName": "chat"
//																		},
//																		"1I1D5700V0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J04JIM5V4",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J04JIM5V5",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I1D5700V0",
//																			"faceTagName": "sites"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1I1USDRD21",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1I1USDRD22",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false",
//																"exposeContainer": "false"
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1I1USEVPL1",
//													"attrs": {
//														"1I1D5700V0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1ILN5JB7F10",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1ILN5JB7F11",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I1D5700V0",
//															"faceTagName": "sites"
//														},
//														"1I1D5774S0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1ILN7IHKQ11",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1ILN7IHKQ12",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I1D5774S0",
//															"faceTagName": "siteMenu"
//														},
//														"1IMR8US3B0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IMR90II422",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IMR90II423",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IMR8US3B0",
//															"faceTagName": "entryOn"
//														},
//														"1IMR8V39V0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IUVB7R1942",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IUVB7R1943",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IMR8V39V0",
//															"faceTagName": "entryOff"
//														},
//														"1IUTA32CV0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVMJ6PDI12",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVMJ6PDI13",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IUTA32CV0",
//															"faceTagName": "online"
//														},
//														"1IVH6SHR30": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVMNKTM84",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVMNKTM85",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IVH6SHR30",
//															"faceTagName": "sidebarOn"
//														},
//														"1ILN7H5CK0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVMOBA2Q12",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVMOBA2Q13",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1ILN7H5CK0",
//															"faceTagName": "chat"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I1USEVPL2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I1USEVPL3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1I10EHPSR0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I10ESI3K0",
//													"attrs": {
//														"type": "box",
//														"id": "BoxInput",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "60%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[20,0,0,0]",
//														"padding": "[8,10,5,10]",
//														"minW": "",
//														"minH": "40",
//														"maxW": "800",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "#cfgColor[\"chatInputBG\"]",
//														"border": "1",
//														"borderStyle": "Solid",
//														"borderColor": "#cfgColor[\"fontBodyLit\"]",
//														"corner": "16",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.20]",
//														"contentLayout": "Flex Y",
//														"itemsAlign": "Center",
//														"subAlign": "Center",
//														"itemsWrap": "Wrap"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1ILI4K2S50",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1ILI4O1SU0",
//																	"attrs": {
//																		"type": "hud",
//																		"id": "BoxInputLine",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"contentLayout": "Flex X",
//																		"itemsAlign": "End",
//																		"subAlign": "Center"
//																	}
//																},
//																"subHuds": {
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "memo",
//																			"jaxId": "1I1M5M3QT0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I1M5P2NB0",
//																					"attrs": {
//																						"type": "memo",
//																						"id": "EdCommand",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "100%-40",
//																						"h": "",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "30",
//																						"maxW": "",
//																						"maxH": "200",
//																						"face": "",
//																						"styleClass": "",
//																						"text": "",
//																						"color": "#cfgColor[\"fontBody\"]",
//																						"bgColor": "[255,255,255,0.00]",
//																						"font": "",
//																						"fontSize": "16",
//																						"outline": "0",
//																						"border": "[0,0,1,0]",
//																						"borderStyle": "Solid",
//																						"borderColor": "#cfgColor[\"fontBodyLit\"]",
//																						"corner": "0",
//																						"readOnly": "false",
//																						"selectOnFocus": "true",
//																						"spellCheck": "true"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1I1M5P2NB1",
//																					"attrs": {
//																						"1IMR8US3B0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IMR90II426",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IMR90II427",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IMR8US3B0",
//																							"faceTagName": "entryOn"
//																						},
//																						"1I1D5774S0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IUVB7R1944",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IUVB7R1945",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1I1D5774S0",
//																							"faceTagName": "siteMenu"
//																						},
//																						"1IMR8V39V0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IUVB7R1950",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IUVB7R1951",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IMR8V39V0",
//																							"faceTagName": "entryOff"
//																						},
//																						"1IUTA32CV0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IVMJ6PDI16",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IVMJ6PDI17",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IUTA32CV0",
//																							"faceTagName": "online"
//																						},
//																						"1IVH6SHR30": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IVMNKTM86",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IVMNKTM87",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IVH6SHR30",
//																							"faceTagName": "sidebarOn"
//																						},
//																						"1ILN7H5CK0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IVMOBA2Q16",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IVMOBA2Q17",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1ILN7H5CK0",
//																							"faceTagName": "chat"
//																						},
//																						"1I1D5700V0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1J04JIM5V6",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1J04JIM5V7",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1I1D5700V0",
//																							"faceTagName": "sites"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1I1M5P2NB2",
//																					"attrs": {
//																						"OnInput": {
//																							"type": "fixedFunc",
//																							"jaxId": "1I1M64K3N0",
//																							"attrs": {
//																								"callArgs": {
//																									"jaxId": "1I1M64K3Q0",
//																									"attrs": {}
//																								},
//																								"seg": ""
//																							}
//																						},
//																						"OnKeyDown": {
//																							"type": "fixedFunc",
//																							"jaxId": "1I1M64K3N1",
//																							"attrs": {
//																								"callArgs": {
//																									"jaxId": "1I1M64K3Q1",
//																									"attrs": {
//																										"event": ""
//																									}
//																								},
//																								"seg": ""
//																							}
//																						}
//																					}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1I1M5P2NB3",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "true"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "text",
//																			"jaxId": "1I1M69F3G0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I1M6CT890",
//																					"attrs": {
//																						"type": "text",
//																						"id": "TxtInputTip",
//																						"position": "Absolute",
//																						"x": "10",
//																						"y": "0",
//																						"w": "",
//																						"h": "100%",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "Tree Off",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"color": "#cfgColor[\"fontBodyLit\"]",
//																						"text": {
//																							"type": "string",
//																							"valText": "Make your command...",
//																							"localize": {
//																								"EN": "Make your command...",
//																								"CN": "给出你的指令..."
//																							},
//																							"localizable": true
//																						},
//																						"font": "",
//																						"fontSize": "16",
//																						"bold": "false",
//																						"italic": "false",
//																						"underline": "false",
//																						"alignH": "Left",
//																						"alignV": "Center",
//																						"wrap": "false",
//																						"ellipsis": "false",
//																						"lineClamp": "0",
//																						"select": "false",
//																						"shadow": "false",
//																						"shadowX": "0",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowColor": "[0,0,0,1.00]",
//																						"shadowEx": "",
//																						"maxTextW": "0"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1I1M6CT891",
//																					"attrs": {
//																						"1IMR8US3B0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IMR90II430",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IMR90II431",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IMR8US3B0",
//																							"faceTagName": "entryOn"
//																						},
//																						"1I1D5774S0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IUVB7R1952",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IUVB7R1953",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1I1D5774S0",
//																							"faceTagName": "siteMenu"
//																						},
//																						"1IMR8V39V0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IUVB7R1958",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IUVB7R1959",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IMR8V39V0",
//																							"faceTagName": "entryOff"
//																						},
//																						"1IUTA32CV0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IVMJ6PDI20",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IVMJ6PDI21",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IUTA32CV0",
//																							"faceTagName": "online"
//																						},
//																						"1IVH6SHR30": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IVMNKTM88",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IVMNKTM89",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IVH6SHR30",
//																							"faceTagName": "sidebarOn"
//																						},
//																						"1ILN7H5CK0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IVMOBA2Q20",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IVMOBA2Q21",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1ILN7H5CK0",
//																							"faceTagName": "chat"
//																						},
//																						"1I1D5700V0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1J04JIM5V8",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1J04JIM5V9",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1I1D5700V0",
//																							"faceTagName": "sites"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1I1M6CT892",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1I1M6CT893",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "true"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "Gear/@StdUI/ui/BtnIcon.js",
//																			"jaxId": "1I10EONLD0",
//																			"attrs": {
//																				"createArgs": {
//																					"jaxId": "1I10ESI3K5",
//																					"attrs": {
//																						"style": "\"front\"",
//																						"w": "30",
//																						"h": "0",
//																						"icon": "#appCfg.sharedAssets+\"/send.svg\"",
//																						"colorBG": "null"
//																					}
//																				},
//																				"properties": {
//																					"jaxId": "1I10ESI3K6",
//																					"attrs": {
//																						"type": "#null#>BtnIcon(\"front\",30,0,appCfg.sharedAssets+\"/send.svg\",null)",
//																						"id": "BtnSendCmd",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"display": "On",
//																						"face": "",
//																						"padding": "3",
//																						"margin": "[0,0,0,3]",
//																						"enable": "false"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1I10ESI3K7",
//																					"attrs": {
//																						"1IMR8US3B0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IMR90II434",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IMR90II435",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IMR8US3B0",
//																							"faceTagName": "entryOn"
//																						},
//																						"1I1D5774S0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IUVB7R1960",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IUVB7R1961",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1I1D5774S0",
//																							"faceTagName": "siteMenu"
//																						},
//																						"1IMR8V39V0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IUVB7R1966",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IUVB7R1967",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IMR8V39V0",
//																							"faceTagName": "entryOff"
//																						},
//																						"1IUTA32CV0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IVMJ6PDI24",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IVMJ6PDI25",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IUTA32CV0",
//																							"faceTagName": "online"
//																						},
//																						"1IVH6SHR30": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IVMNKTM810",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IVMNKTM811",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IVH6SHR30",
//																							"faceTagName": "sidebarOn"
//																						},
//																						"1ILN7H5CK0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IVMOBA2Q24",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IVMOBA2Q25",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1ILN7H5CK0",
//																							"faceTagName": "chat"
//																						},
//																						"1I1D5700V0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1J04JIM5V10",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1J04JIM5V11",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1I1D5700V0",
//																							"faceTagName": "sites"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1I10ESI3K8",
//																					"attrs": {
//																						"OnClick": {
//																							"type": "fixedFunc",
//																							"jaxId": "1I1OOIH1D0",
//																							"attrs": {
//																								"callArgs": {
//																									"jaxId": "1I1OOIH1D1",
//																									"attrs": {
//																										"event": ""
//																									}
//																								},
//																								"seg": "1I1M6K4VG0"
//																							}
//																						}
//																					}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1I10ESI3K9",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "true",
//																				"containerSlots": {
//																					"jaxId": "1I10ESI3K10",
//																					"attrs": {}
//																				}
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"jaxId": "1ILI4O1SU1",
//																	"attrs": {
//																		"1IMR8US3B0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IMR90II438",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IMR90II439",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IMR8US3B0",
//																			"faceTagName": "entryOn"
//																		},
//																		"1I1D5774S0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IUVB7R1968",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IUVB7R1969",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I1D5774S0",
//																			"faceTagName": "siteMenu"
//																		},
//																		"1IMR8V39V0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IUVB7R1974",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IUVB7R1975",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IMR8V39V0",
//																			"faceTagName": "entryOff"
//																		},
//																		"1IUTA32CV0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVMJ6PDI28",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVMJ6PDI29",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IUTA32CV0",
//																			"faceTagName": "online"
//																		},
//																		"1IVH6SHR30": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVMNKTM812",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVMNKTM813",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IVH6SHR30",
//																			"faceTagName": "sidebarOn"
//																		},
//																		"1ILN7H5CK0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVMOBA2Q28",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVMOBA2Q29",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1ILN7H5CK0",
//																			"faceTagName": "chat"
//																		},
//																		"1I1D5700V0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J04JIM600",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J04JIM601",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I1D5700V0",
//																			"faceTagName": "sites"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1ILI4O1SU2",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1IMS6SCEC0",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1IMS6SCEO3",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1ILI4O1SU3",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false",
//																"exposeContainer": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1ILIHN2E90",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1ILIHPKE20",
//																	"attrs": {
//																		"type": "hud",
//																		"id": "BoxAssets",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%-60",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "0",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"contentLayout": "Flex Y"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1ILIHPKE21",
//																	"attrs": {
//																		"1IMR8US3B0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IMR90II442",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IMR90II443",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IMR8US3B0",
//																			"faceTagName": "entryOn"
//																		},
//																		"1I1D5774S0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IUVB7R1976",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IUVB7R1977",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I1D5774S0",
//																			"faceTagName": "siteMenu"
//																		},
//																		"1IMR8V39V0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IUVB7R1982",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IUVB7R1983",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IMR8V39V0",
//																			"faceTagName": "entryOff"
//																		},
//																		"1IUTA32CV0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVMJ6PDI32",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVMJ6PDI33",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IUTA32CV0",
//																			"faceTagName": "online"
//																		},
//																		"1IVH6SHR30": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVMNKTM814",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVMNKTM815",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IVH6SHR30",
//																			"faceTagName": "sidebarOn"
//																		},
//																		"1ILN7H5CK0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVMOBA2Q32",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVMOBA2Q33",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1ILN7H5CK0",
//																			"faceTagName": "chat"
//																		},
//																		"1I1D5700V0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J04JIM602",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J04JIM603",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I1D5700V0",
//																			"faceTagName": "sites"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1ILIHPKE22",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1ILIHPKE23",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "true",
//																"exposeContainer": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1ILJ8I23P0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1ILJ8I23P1",
//																	"attrs": {
//																		"type": "hud",
//																		"id": "BoxToolBtns",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[10,0,0,0]",
//																		"padding": "[0,5,5,5]",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"contentLayout": "Flex X",
//																		"itemsWrap": "Wrap",
//																		"itemsAlign": "Center",
//																		"subAlign": "Start"
//																	}
//																},
//																"subHuds": {
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "Gear/@StdUI/ui/BtnIcon.js",
//																			"jaxId": "1ILJ8I23P2",
//																			"attrs": {
//																				"createArgs": {
//																					"jaxId": "1ILJ8I23P3",
//																					"attrs": {
//																						"style": "\"front\"",
//																						"w": "24",
//																						"h": "0",
//																						"icon": "#appCfg.sharedAssets+\"/asset.svg\"",
//																						"colorBG": "null"
//																					}
//																				},
//																				"properties": {
//																					"jaxId": "1ILJ8I23Q0",
//																					"attrs": {
//																						"type": "#null#>BtnIcon(\"front\",24,0,appCfg.sharedAssets+\"/asset.svg\",null)",
//																						"id": "BtnAddAssets",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"display": "On",
//																						"face": "",
//																						"margin": "[0,5,0,5]"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1ILJ8I23Q1",
//																					"attrs": {
//																						"1IMR8US3B0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IMR90II446",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IMR90II447",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IMR8US3B0",
//																							"faceTagName": "entryOn"
//																						},
//																						"1I1D5774S0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IUVB7R1984",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IUVB7R1985",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1I1D5774S0",
//																							"faceTagName": "siteMenu"
//																						},
//																						"1IMR8V39V0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IUVB7R1990",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IUVB7R1991",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IMR8V39V0",
//																							"faceTagName": "entryOff"
//																						},
//																						"1IUTA32CV0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IVMJ6PDI36",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IVMJ6PDI37",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IUTA32CV0",
//																							"faceTagName": "online"
//																						},
//																						"1IVH6SHR30": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IVMNKTM816",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IVMNKTM817",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IVH6SHR30",
//																							"faceTagName": "sidebarOn"
//																						},
//																						"1ILN7H5CK0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IVMOBA2Q36",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IVMOBA2Q37",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1ILN7H5CK0",
//																							"faceTagName": "chat"
//																						},
//																						"1I1D5700V0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1J04JIM604",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1J04JIM605",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1I1D5700V0",
//																							"faceTagName": "sites"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1ILJ8I23Q2",
//																					"attrs": {
//																						"OnClick": {
//																							"type": "fixedFunc",
//																							"jaxId": "1ILJ8I23Q3",
//																							"attrs": {
//																								"callArgs": {
//																									"jaxId": "1ILJ8I23Q4",
//																									"attrs": {
//																										"event": ""
//																									}
//																								},
//																								"seg": "1ILIGIPH20"
//																							}
//																						}
//																					}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1ILJ8I23Q5",
//																					"attrs": {
//																						"tip": {
//																							"type": "string",
//																							"valText": "Add assets",
//																							"localize": {
//																								"EN": "Add assets",
//																								"CN": "附加内容"
//																							},
//																							"localizable": true
//																						}
//																					}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false",
//																				"containerSlots": {
//																					"jaxId": "1ILJ8I23Q6",
//																					"attrs": {}
//																				}
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "hud",
//																			"jaxId": "1IMR7850A0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IMR7BO8M24",
//																					"attrs": {
//																						"type": "hud",
//																						"id": "SegChatEntry",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "",
//																						"h": "100%",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "pointer",
//																						"zIndex": "0",
//																						"margin": "[0,5,0,5]",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"contentLayout": "Flex X",
//																						"itemsAlign": "Center"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": [
//																						{
//																							"type": "hudobj",
//																							"def": "box",
//																							"jaxId": "1IMR7R2FE0",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IMR7US620",
//																									"attrs": {
//																										"type": "box",
//																										"id": "BoxChatEntryBG",
//																										"position": "Absolute",
//																										"x": "-2",
//																										"y": "-2",
//																										"w": "100%+4",
//																										"h": "100%+4",
//																										"anchorH": "Left",
//																										"anchorV": "Top",
//																										"autoLayout": "false",
//																										"display": "Off",
//																										"clip": "Off",
//																										"uiEvent": "Tree Off",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "",
//																										"zIndex": "0",
//																										"margin": "",
//																										"padding": "",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": "",
//																										"background": "#cfgColor[\"hot\"]",
//																										"border": "1",
//																										"borderStyle": "Solid",
//																										"borderColor": "#cfgColor[\"fontBodySub\"]",
//																										"corner": "6",
//																										"shadow": "false",
//																										"shadowX": "2",
//																										"shadowY": "2",
//																										"shadowBlur": "3",
//																										"shadowSpread": "0",
//																										"shadowColor": "[0,0,0,0.50]"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1IMR7US621",
//																									"attrs": {
//																										"1IMR8US3B0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IMR90II450",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IMR90II451",
//																													"attrs": {
//																														"display": {
//																															"type": "choice",
//																															"valText": "On"
//																														}
//																													}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IMR8US3B0",
//																											"faceTagName": "entryOn"
//																										},
//																										"1IMR8V39V0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IMR90II452",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IMR90II453",
//																													"attrs": {
//																														"display": {
//																															"type": "choice",
//																															"valText": "Off"
//																														}
//																													}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IMR8V39V0",
//																											"faceTagName": "entryOff"
//																										},
//																										"1I1D5774S0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IUVB7R1992",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IUVB7R1993",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1I1D5774S0",
//																											"faceTagName": "siteMenu"
//																										},
//																										"1IUTA32CV0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IVMJ6PDI40",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IVMJ6PDI41",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IUTA32CV0",
//																											"faceTagName": "online"
//																										},
//																										"1IVH6SHR30": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IVMNKTM818",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IVMNKTM819",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IVH6SHR30",
//																											"faceTagName": "sidebarOn"
//																										},
//																										"1ILN7H5CK0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IVMOBA2Q40",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IVMOBA2Q41",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1ILN7H5CK0",
//																											"faceTagName": "chat"
//																										},
//																										"1I1D5700V0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1J04JIM606",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1J04JIM607",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1I1D5700V0",
//																											"faceTagName": "sites"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1IMR7US622",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1IMR7US623",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "true",
//																								"nameVal": "false"
//																							}
//																						},
//																						{
//																							"type": "hudobj",
//																							"def": "Gear/@StdUI/ui/BtnIcon.js",
//																							"jaxId": "1IMR791SD0",
//																							"attrs": {
//																								"createArgs": {
//																									"jaxId": "1IMR791SD1",
//																									"attrs": {
//																										"style": "\"front\"",
//																										"w": "24",
//																										"h": "0",
//																										"icon": "#appCfg.sharedAssets+\"/appdata.svg\"",
//																										"colorBG": "null"
//																									}
//																								},
//																								"properties": {
//																									"jaxId": "1IMR791SD2",
//																									"attrs": {
//																										"type": "#null#>BtnIcon(\"front\",24,0,appCfg.sharedAssets+\"/appdata.svg\",null)",
//																										"id": "BtnChatEntry",
//																										"position": "relative",
//																										"x": "0",
//																										"y": "0",
//																										"display": "On",
//																										"face": "",
//																										"margin": "0",
//																										"enable": "true"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1IMR791SD3",
//																									"attrs": {
//																										"1IMR8US3B0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IMR90II454",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IMR90II455",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IMR8US3B0",
//																											"faceTagName": "entryOn"
//																										},
//																										"1I1D5774S0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IUVB7R1998",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IUVB7R1999",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1I1D5774S0",
//																											"faceTagName": "siteMenu"
//																										},
//																										"1IMR8V39V0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IUVB7R19104",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IUVB7R19105",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IMR8V39V0",
//																											"faceTagName": "entryOff"
//																										},
//																										"1IUTA32CV0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IVMJ6PDI44",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IVMJ6PDI45",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IUTA32CV0",
//																											"faceTagName": "online"
//																										},
//																										"1IVH6SHR30": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IVMNKTM820",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IVMNKTM821",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IVH6SHR30",
//																											"faceTagName": "sidebarOn"
//																										},
//																										"1ILN7H5CK0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IVMOBA2Q44",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IVMOBA2Q45",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1ILN7H5CK0",
//																											"faceTagName": "chat"
//																										},
//																										"1I1D5700V0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1J04JIM608",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1J04JIM609",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1I1D5700V0",
//																											"faceTagName": "sites"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1IMR791SD10",
//																									"attrs": {
//																										"OnClick": {
//																											"type": "fixedFunc",
//																											"jaxId": "1IMR791SE0",
//																											"attrs": {
//																												"callArgs": {
//																													"jaxId": "1IMR791SE1",
//																													"attrs": {
//																														"event": ""
//																													}
//																												},
//																												"seg": "1IMR949GQ0"
//																											}
//																										}
//																									}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1IMR791SE2",
//																									"attrs": {
//																										"tip": {
//																											"type": "string",
//																											"valText": "Choose chat AI Agent",
//																											"localize": {
//																												"EN": "Choose chat AI Agent",
//																												"CN": "选择对话智能体"
//																											},
//																											"localizable": true
//																										}
//																									}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "true",
//																								"containerSlots": {
//																									"jaxId": "1IMR791SE3",
//																									"attrs": {}
//																								}
//																							}
//																						},
//																						{
//																							"type": "hudobj",
//																							"def": "text",
//																							"jaxId": "1IMR7NS760",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IMR7US624",
//																									"attrs": {
//																										"type": "text",
//																										"id": "TxtChatEntry",
//																										"position": "relative",
//																										"x": "0",
//																										"y": "0",
//																										"w": "",
//																										"h": "",
//																										"anchorH": "Left",
//																										"anchorV": "Top",
//																										"autoLayout": "false",
//																										"display": "Off",
//																										"clip": "Off",
//																										"uiEvent": "Tree Off",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "",
//																										"zIndex": "0",
//																										"margin": "[0,3,0,3]",
//																										"padding": "",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": "",
//																										"color": "#cfgColor[\"fontBody\"]",
//																										"text": "Web Search",
//																										"font": "",
//																										"fontSize": "#txtSize.small",
//																										"bold": "false",
//																										"italic": "false",
//																										"underline": "false",
//																										"alignH": "Left",
//																										"alignV": "Top",
//																										"wrap": "false",
//																										"ellipsis": "false",
//																										"lineClamp": "0",
//																										"select": "false",
//																										"shadow": "false",
//																										"shadowX": "0",
//																										"shadowY": "2",
//																										"shadowBlur": "3",
//																										"shadowColor": "[0,0,0,1.00]",
//																										"shadowEx": "",
//																										"maxTextW": "0"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1IMR7US625",
//																									"attrs": {
//																										"1IMR8US3B0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IMR90II458",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IMR90II459",
//																													"attrs": {
//																														"display": {
//																															"type": "choice",
//																															"valText": "On"
//																														}
//																													}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IMR8US3B0",
//																											"faceTagName": "entryOn"
//																										},
//																										"1IMR8V39V0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IMR90II460",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IMR90II461",
//																													"attrs": {
//																														"display": {
//																															"type": "choice",
//																															"valText": "Off"
//																														}
//																													}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IMR8V39V0",
//																											"faceTagName": "entryOff"
//																										},
//																										"1I1D5774S0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IUVB7R19106",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IUVB7R19107",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1I1D5774S0",
//																											"faceTagName": "siteMenu"
//																										},
//																										"1IUTA32CV0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IVMJ6PDI48",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IVMJ6PDI49",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IUTA32CV0",
//																											"faceTagName": "online"
//																										},
//																										"1IVH6SHR30": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IVMNKTM822",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IVMNKTM823",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IVH6SHR30",
//																											"faceTagName": "sidebarOn"
//																										},
//																										"1ILN7H5CK0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IVMOBA2Q48",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IVMOBA2Q49",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1ILN7H5CK0",
//																											"faceTagName": "chat"
//																										},
//																										"1I1D5700V0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1J04JIM6010",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1J04JIM6011",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1I1D5700V0",
//																											"faceTagName": "sites"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1IMR7US626",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1IMR7US627",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "true"
//																							}
//																						}
//																					]
//																				},
//																				"faces": {
//																					"jaxId": "1IMR7BO8N0",
//																					"attrs": {
//																						"1IMR8US3B0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IMR90II462",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IMR90II463",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IMR8US3B0",
//																							"faceTagName": "entryOn"
//																						},
//																						"1I1D5774S0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IUVB7R19112",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IUVB7R19113",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1I1D5774S0",
//																							"faceTagName": "siteMenu"
//																						},
//																						"1IMR8V39V0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IUVB7R19118",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IUVB7R19119",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IMR8V39V0",
//																							"faceTagName": "entryOff"
//																						},
//																						"1IUTA32CV0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IVMJ6PDJ0",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IVMJ6PDJ1",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IUTA32CV0",
//																							"faceTagName": "online"
//																						},
//																						"1IVH6SHR30": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IVMNKTM824",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IVMNKTM825",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IVH6SHR30",
//																							"faceTagName": "sidebarOn"
//																						},
//																						"1ILN7H5CK0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IVMOBA2Q52",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IVMOBA2Q53",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1ILN7H5CK0",
//																							"faceTagName": "chat"
//																						},
//																						"1I1D5700V0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1J04JIM6012",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1J04JIM6013",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1I1D5700V0",
//																							"faceTagName": "sites"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1IMR7BO8N1",
//																					"attrs": {
//																						"OnClick": {
//																							"type": "fixedFunc",
//																							"jaxId": "1IMS6TDMS0",
//																							"attrs": {
//																								"callArgs": {
//																									"jaxId": "1IMS6TDMS1",
//																									"attrs": {
//																										"event": ""
//																									}
//																								},
//																								"seg": "1IMR949GQ0"
//																							}
//																						}
//																					}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1IMR7BO8N2",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "false",
//																				"exposeContainer": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "box",
//																			"jaxId": "1ILR0R6B60",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1ILR0R6B61",
//																					"attrs": {
//																						"type": "box",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "1",
//																						"h": "16",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "Off",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "[0,0,0,5]",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"background": "#cfgColor[\"fontBodyLit\"]",
//																						"border": "0",
//																						"borderStyle": "Solid",
//																						"borderColor": "[0,0,0,1.00]",
//																						"corner": "0",
//																						"shadow": "false",
//																						"shadowX": "2",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowSpread": "0",
//																						"shadowColor": "[0,0,0,0.50]"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1ILR0R6B62",
//																					"attrs": {
//																						"1IMR8US3B0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IMR90II470",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IMR90II471",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IMR8US3B0",
//																							"faceTagName": "entryOn"
//																						},
//																						"1I1D5774S0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IUVB7R19120",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IUVB7R19121",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1I1D5774S0",
//																							"faceTagName": "siteMenu"
//																						},
//																						"1IMR8V39V0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IUVB7R19126",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IUVB7R19127",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IMR8V39V0",
//																							"faceTagName": "entryOff"
//																						},
//																						"1IUTA32CV0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IVMJ6PDJ4",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IVMJ6PDJ5",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IUTA32CV0",
//																							"faceTagName": "online"
//																						},
//																						"1IVH6SHR30": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IVMNKTM826",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IVMNKTM827",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IVH6SHR30",
//																							"faceTagName": "sidebarOn"
//																						},
//																						"1ILN7H5CK0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IVMOBA2Q56",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IVMOBA2Q57",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1ILN7H5CK0",
//																							"faceTagName": "chat"
//																						},
//																						"1I1D5700V0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1J04JIM6014",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1J04JIM6015",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1I1D5700V0",
//																							"faceTagName": "sites"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1ILR0R6B63",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1ILR0R6B64",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "Gear/@StdUI/ui/BtnIcon.js",
//																			"jaxId": "1ILJ8I23Q21",
//																			"attrs": {
//																				"createArgs": {
//																					"jaxId": "1ILJ8I23Q22",
//																					"attrs": {
//																						"style": "\"front\"",
//																						"w": "24",
//																						"h": "0",
//																						"icon": "#appCfg.sharedAssets+\"/skillchain.svg\"",
//																						"colorBG": "null"
//																					}
//																				},
//																				"properties": {
//																					"jaxId": "1ILJ8I23Q23",
//																					"attrs": {
//																						"type": "#null#>BtnIcon(\"front\",24,0,appCfg.sharedAssets+\"/skillchain.svg\",null)",
//																						"id": "BtnUseChain",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"display": "On",
//																						"face": "",
//																						"margin": "[0,5,0,5]",
//																						"enable": "false"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1ILJ8I23Q24",
//																					"attrs": {
//																						"1IMR8US3B0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IMR90II474",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IMR90II475",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IMR8US3B0",
//																							"faceTagName": "entryOn"
//																						},
//																						"1I1D5774S0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IUVB7R19128",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IUVB7R19129",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1I1D5774S0",
//																							"faceTagName": "siteMenu"
//																						},
//																						"1IMR8V39V0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IUVB7R19134",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IUVB7R19135",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IMR8V39V0",
//																							"faceTagName": "entryOff"
//																						},
//																						"1IUTA32CV0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IVMJ6PDJ8",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IVMJ6PDJ9",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IUTA32CV0",
//																							"faceTagName": "online"
//																						},
//																						"1IVH6SHR30": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IVMNKTM828",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IVMNKTM829",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IVH6SHR30",
//																							"faceTagName": "sidebarOn"
//																						},
//																						"1ILN7H5CK0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IVMOBA2Q60",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IVMOBA2Q61",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1ILN7H5CK0",
//																							"faceTagName": "chat"
//																						},
//																						"1I1D5700V0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1J04JIM6016",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1J04JIM6017",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1I1D5700V0",
//																							"faceTagName": "sites"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1ILJ8I23Q25",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1ILJ8I23Q26",
//																					"attrs": {
//																						"tip": {
//																							"type": "string",
//																							"valText": "Choose agent chain",
//																							"localize": {
//																								"EN": "Choose agent chain",
//																								"CN": "选择智能链"
//																							},
//																							"localizable": true
//																						}
//																					}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false",
//																				"containerSlots": {
//																					"jaxId": "1ILJ8I23Q27",
//																					"attrs": {}
//																				}
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "Gear/@StdUI/ui/BtnIcon.js",
//																			"jaxId": "1INGQM8N50",
//																			"attrs": {
//																				"createArgs": {
//																					"jaxId": "1INGQM8N60",
//																					"attrs": {
//																						"style": "\"front\"",
//																						"w": "24",
//																						"h": "0",
//																						"icon": "#appCfg.sharedAssets+\"/settings.svg\"",
//																						"colorBG": "null"
//																					}
//																				},
//																				"properties": {
//																					"jaxId": "1INGQM8N61",
//																					"attrs": {
//																						"type": "#null#>BtnIcon(\"front\",24,0,appCfg.sharedAssets+\"/settings.svg\",null)",
//																						"id": "BtnConfig",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"display": "On",
//																						"face": "",
//																						"margin": "[0,5,0,5]",
//																						"enable": "true"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1INGQM8N62",
//																					"attrs": {
//																						"1IMR8US3B0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1INGQM8N67",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1INGQM8N68",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IMR8US3B0",
//																							"faceTagName": "entryOn"
//																						},
//																						"1I1D5774S0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IUVB7R19136",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IUVB7R19137",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1I1D5774S0",
//																							"faceTagName": "siteMenu"
//																						},
//																						"1IMR8V39V0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IUVB7R19142",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IUVB7R19143",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IMR8V39V0",
//																							"faceTagName": "entryOff"
//																						},
//																						"1IUTA32CV0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IVMJ6PDJ12",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IVMJ6PDJ13",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IUTA32CV0",
//																							"faceTagName": "online"
//																						},
//																						"1IVH6SHR30": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IVMNKTM830",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IVMNKTM831",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IVH6SHR30",
//																							"faceTagName": "sidebarOn"
//																						},
//																						"1ILN7H5CK0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IVMOBA2Q64",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IVMOBA2Q65",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1ILN7H5CK0",
//																							"faceTagName": "chat"
//																						},
//																						"1I1D5700V0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1J04JIM6018",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1J04JIM6019",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1I1D5700V0",
//																							"faceTagName": "sites"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1INGQM8N69",
//																					"attrs": {
//																						"OnClick": {
//																							"type": "fixedFunc",
//																							"jaxId": "1INGTBFQN0",
//																							"attrs": {
//																								"callArgs": {
//																									"jaxId": "1INGTBFQN1",
//																									"attrs": {
//																										"event": ""
//																									}
//																								},
//																								"seg": "1INGQQFU50"
//																							}
//																						}
//																					}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1INGQM8N610",
//																					"attrs": {
//																						"tip": {
//																							"type": "string",
//																							"valText": "AI Settings",
//																							"localize": {
//																								"EN": "AI Settings",
//																								"CN": "AI 对话设置"
//																							},
//																							"localizable": true
//																						}
//																					}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false",
//																				"containerSlots": {
//																					"jaxId": "1INGQM8N611",
//																					"attrs": {}
//																				}
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "hud",
//																			"jaxId": "1ILJ8QBSK0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1ILJ8QRES0",
//																					"attrs": {
//																						"type": "hud",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "1",
//																						"h": "100%",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"flex": "true"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1ILJ8QRES1",
//																					"attrs": {
//																						"1IMR8US3B0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IMR90II478",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IMR90II479",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IMR8US3B0",
//																							"faceTagName": "entryOn"
//																						},
//																						"1I1D5774S0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IUVB7R19144",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IUVB7R19145",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1I1D5774S0",
//																							"faceTagName": "siteMenu"
//																						},
//																						"1IMR8V39V0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IUVB7R19150",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IUVB7R19151",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IMR8V39V0",
//																							"faceTagName": "entryOff"
//																						},
//																						"1IUTA32CV0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IVMJ6PDJ16",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IVMJ6PDJ17",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IUTA32CV0",
//																							"faceTagName": "online"
//																						},
//																						"1IVH6SHR30": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IVMNKTM832",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IVMNKTM833",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IVH6SHR30",
//																							"faceTagName": "sidebarOn"
//																						},
//																						"1ILN7H5CK0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IVMOBA2Q68",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IVMOBA2Q69",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1ILN7H5CK0",
//																							"faceTagName": "chat"
//																						},
//																						"1I1D5700V0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1J04JIM6020",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1J04JIM6021",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1I1D5700V0",
//																							"faceTagName": "sites"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1ILJ8QRES2",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1ILJ8QRES3",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "false",
//																				"exposeContainer": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "Gear/@StdUI/ui/BtnIcon.js",
//																			"jaxId": "1I1HHL2Q00",
//																			"attrs": {
//																				"createArgs": {
//																					"jaxId": "1I1HHL2Q01",
//																					"attrs": {
//																						"style": "\"front\"",
//																						"w": "24",
//																						"h": "0",
//																						"icon": "#appCfg.sharedAssets+\"/inc.svg\"",
//																						"colorBG": "null"
//																					}
//																				},
//																				"properties": {
//																					"jaxId": "1I1HHL2Q02",
//																					"attrs": {
//																						"type": "#null#>BtnIcon(\"front\",24,0,appCfg.sharedAssets+\"/inc.svg\",null)",
//																						"id": "BtnMenu",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"display": "On",
//																						"face": "",
//																						"margin": "0",
//																						"padding": "0"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1I1HHL2Q10",
//																					"attrs": {
//																						"1IMR8US3B0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IMR90II482",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IMR90II483",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IMR8US3B0",
//																							"faceTagName": "entryOn"
//																						},
//																						"1I1D5774S0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IUVB7R19152",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IUVB7R19153",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1I1D5774S0",
//																							"faceTagName": "siteMenu"
//																						},
//																						"1IMR8V39V0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IUVB7R19158",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IUVB7R19159",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IMR8V39V0",
//																							"faceTagName": "entryOff"
//																						},
//																						"1IUTA32CV0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IVMJ6PDJ20",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IVMJ6PDJ21",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IUTA32CV0",
//																							"faceTagName": "online"
//																						},
//																						"1IVH6SHR30": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IVMNKTM834",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IVMNKTM835",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IVH6SHR30",
//																							"faceTagName": "sidebarOn"
//																						},
//																						"1ILN7H5CK0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IVMOBA2R0",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IVMOBA2R1",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1ILN7H5CK0",
//																							"faceTagName": "chat"
//																						},
//																						"1I1D5700V0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1J04JIM6022",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1J04JIM6023",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1I1D5700V0",
//																							"faceTagName": "sites"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1I1HHL2Q13",
//																					"attrs": {
//																						"OnClick": {
//																							"type": "fixedFunc",
//																							"jaxId": "1I1IF19DQ3",
//																							"attrs": {
//																								"callArgs": {
//																									"jaxId": "1I1IF19DQ4",
//																									"attrs": {
//																										"event": ""
//																									}
//																								},
//																								"seg": "1I1IF0PR70"
//																							}
//																						}
//																					}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1I1HHL2Q14",
//																					"attrs": {
//																						"tip": {
//																							"type": "string",
//																							"valText": "Add Agent",
//																							"localize": {
//																								"EN": "Add Agent",
//																								"CN": "添加智能体"
//																							},
//																							"localizable": true
//																						}
//																					}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "true",
//																				"containerSlots": {
//																					"jaxId": "1I1HHL2Q15",
//																					"attrs": {}
//																				}
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"jaxId": "1ILJ8I23Q28",
//																	"attrs": {
//																		"1I1D5700V0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1ILJ8I23R0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1ILJ8I23R1",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I1D5700V0",
//																			"faceTagName": "sites"
//																		},
//																		"1I1D5774S0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1ILJ8I23R2",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1ILJ8I23R3",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I1D5774S0",
//																			"faceTagName": "siteMenu"
//																		},
//																		"1IMR8US3B0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IMR90II486",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IMR90II487",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IMR8US3B0",
//																			"faceTagName": "entryOn"
//																		},
//																		"1IMR8V39V0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IUVB7R19164",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IUVB7R19165",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IMR8V39V0",
//																			"faceTagName": "entryOff"
//																		},
//																		"1IUTA32CV0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVMJ6PDJ24",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVMJ6PDJ25",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IUTA32CV0",
//																			"faceTagName": "online"
//																		},
//																		"1IVH6SHR30": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVMNKTM836",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVMNKTM837",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IVH6SHR30",
//																			"faceTagName": "sidebarOn"
//																		},
//																		"1ILN7H5CK0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVMOBA2R4",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVMOBA2R5",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1ILN7H5CK0",
//																			"faceTagName": "chat"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1ILJ8I23R4",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1ILJ8I23R5",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false",
//																"exposeContainer": "false"
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1I10ESI3K11",
//													"attrs": {
//														"1I1D5700V0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I1I5GNM720",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I1I5GNM721",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I1D5700V0",
//															"faceTagName": "sites"
//														},
//														"1I1D5774S0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I1IDDJNP20",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I1IDDJNP21",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I1D5774S0",
//															"faceTagName": "siteMenu"
//														},
//														"1IMR8US3B0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IMR90II490",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IMR90II491",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IMR8US3B0",
//															"faceTagName": "entryOn"
//														},
//														"1IMR8V39V0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IUVB7R19170",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IUVB7R19171",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IMR8V39V0",
//															"faceTagName": "entryOff"
//														},
//														"1IUTA32CV0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVMJ6PDJ28",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVMJ6PDJ29",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IUTA32CV0",
//															"faceTagName": "online"
//														},
//														"1IVH6SHR30": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVMNKTM838",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVMNKTM839",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IVH6SHR30",
//															"faceTagName": "sidebarOn"
//														},
//														"1ILN7H5CK0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVMOBA2R8",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVMOBA2R9",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1ILN7H5CK0",
//															"faceTagName": "chat"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I10ESI3K12",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I10ESI3K13",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1I11DDGM90",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I11DGKMG0",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxContents",
//														"position": "relative",
//														"x": "50%",
//														"y": "0",
//														"w": "100%",
//														"h": "100",
//														"anchorH": "Center",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Auto Scroll Y",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[10,20,20,20]",
//														"padding": "[20,50,20,50]",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"flex": "true",
//														"contentLayout": "Block",
//														"itemsWrap": "Wrap",
//														"itemsAlign": "Start",
//														"subAlign": "Center"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1I19QVP9T0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I19R05DJ0",
//																	"attrs": {
//																		"type": "hud",
//																		"id": "BoxGroups",
//																		"position": "Absolute",
//																		"x": "50",
//																		"y": "0",
//																		"w": "100%-100",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "Off",
//																		"clip": "Auto Scroll Y",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "10",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"contentLayout": "Flex X",
//																		"subAlign": "Center",
//																		"itemsAlign": "Center",
//																		"itemsWrap": "Wrap"
//																	}
//																},
//																"subHuds": {
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "Gear1I1BV49TB0",
//																			"jaxId": "1I1C03A9B0",
//																			"attrs": {
//																				"createArgs": {
//																					"jaxId": "1I1C046KG0",
//																					"attrs": {
//																						"groupVO": "#{label:\"www.google.com\",tools:[1,2,3,4,5],chains:[1,2,3]}"
//																					}
//																				},
//																				"properties": {
//																					"jaxId": "1I1C046KG1",
//																					"attrs": {
//																						"type": "#null#>BoxGroup({label:\"www.google.com\",tools:[1,2,3,4,5],chains:[1,2,3]})",
//																						"id": "",
//																						"position": "relative",
//																						"x": "125",
//																						"y": "35",
//																						"display": "On",
//																						"face": ""
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1I1C046KG2",
//																					"attrs": {
//																						"1IMR8US3B0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IMR90II494",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IMR90II495",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IMR8US3B0",
//																							"faceTagName": "entryOn"
//																						},
//																						"1I1D5774S0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IUVB7R1A0",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IUVB7R1A1",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1I1D5774S0",
//																							"faceTagName": "siteMenu"
//																						},
//																						"1IMR8V39V0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IUVB7R1A6",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IUVB7R1A7",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IMR8V39V0",
//																							"faceTagName": "entryOff"
//																						},
//																						"1IUTA32CV0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IVMJ6PDJ32",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IVMJ6PDJ33",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IUTA32CV0",
//																							"faceTagName": "online"
//																						},
//																						"1IVH6SHR30": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IVMNKTM840",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IVMNKTM841",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IVH6SHR30",
//																							"faceTagName": "sidebarOn"
//																						},
//																						"1ILN7H5CK0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IVMOBA2R12",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IVMOBA2R13",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1ILN7H5CK0",
//																							"faceTagName": "chat"
//																						},
//																						"1I1D5700V0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1J04JIM6024",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1J04JIM6025",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1I1D5700V0",
//																							"faceTagName": "sites"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1I1C046KG3",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1I1C046KG4",
//																					"attrs": {}
//																				},
//																				"mockup": "true",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false",
//																				"containerSlots": {
//																					"jaxId": "1I1C046KG5",
//																					"attrs": {}
//																				}
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"jaxId": "1I19R05DK0",
//																	"attrs": {
//																		"1I1D5774S0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I1D58F4767",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I1D58F4768",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I1D5774S0",
//																			"faceTagName": "siteMenu"
//																		},
//																		"1I1D5700V0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I1D58F4769",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I1D58F4770",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I1D5700V0",
//																			"faceTagName": "sites"
//																		},
//																		"1IMR8US3B0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IMR90II498",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IMR90II499",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IMR8US3B0",
//																			"faceTagName": "entryOn"
//																		},
//																		"1IMR8V39V0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IUVB7R1A12",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IUVB7R1A13",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IMR8V39V0",
//																			"faceTagName": "entryOff"
//																		},
//																		"1IUTA32CV0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVMJ6PDJ36",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVMJ6PDJ37",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IUTA32CV0",
//																			"faceTagName": "online"
//																		},
//																		"1IVH6SHR30": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVMNKTM842",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVMNKTM843",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IVH6SHR30",
//																			"faceTagName": "sidebarOn"
//																		},
//																		"1ILN7H5CK0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVMOBA2R16",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVMOBA2R17",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1ILN7H5CK0",
//																			"faceTagName": "chat"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1I19R05DK1",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1I19R05DK2",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "true",
//																"exposeContainer": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1I1D4M7EH0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I1D4N6FM0",
//																	"attrs": {
//																		"type": "hud",
//																		"id": "BoxGroupMenu",
//																		"position": "Absolute",
//																		"x": "50",
//																		"y": "0",
//																		"w": "100%-100",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "Off",
//																		"clip": "Auto Scroll Y",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "5",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"contentLayout": "Flex Y"
//																	}
//																},
//																"subHuds": {
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "hud",
//																			"jaxId": "1I1D525QM0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I1D545LC0",
//																					"attrs": {
//																						"type": "hud",
//																						"id": "BoxGroupHeader",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "100%",
//																						"h": "30",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"contentLayout": "Flex X"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": [
//																						{
//																							"type": "hudobj",
//																							"def": "Gear/@StdUI/ui/BtnIcon.js",
//																							"jaxId": "1I1D52KLM0",
//																							"attrs": {
//																								"createArgs": {
//																									"jaxId": "1I1D545LC1",
//																									"attrs": {
//																										"style": "\"front\"",
//																										"w": "30",
//																										"h": "0",
//																										"icon": "#appCfg.sharedAssets+\"/arrowleft.svg\"",
//																										"colorBG": "null"
//																									}
//																								},
//																								"properties": {
//																									"jaxId": "1I1D545LC2",
//																									"attrs": {
//																										"type": "#null#>BtnIcon(\"front\",30,0,appCfg.sharedAssets+\"/arrowleft.svg\",null)",
//																										"id": "BtnCloseSiteMenu",
//																										"position": "Relative",
//																										"x": "0",
//																										"y": "0",
//																										"display": "On",
//																										"face": "",
//																										"margin": "[0,5,0,0]"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1I1D545LC3",
//																									"attrs": {
//																										"1IMR8US3B0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IMR90II4102",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IMR90II50",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IMR8US3B0",
//																											"faceTagName": "entryOn"
//																										},
//																										"1I1D5774S0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IUVB7R1A14",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IUVB7R1A15",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1I1D5774S0",
//																											"faceTagName": "siteMenu"
//																										},
//																										"1IMR8V39V0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IUVB7R1A20",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IUVB7R1A21",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IMR8V39V0",
//																											"faceTagName": "entryOff"
//																										},
//																										"1IUTA32CV0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IVMJ6PDJ40",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IVMJ6PDJ41",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IUTA32CV0",
//																											"faceTagName": "online"
//																										},
//																										"1IVH6SHR30": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IVMNKTM844",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IVMNKTM845",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IVH6SHR30",
//																											"faceTagName": "sidebarOn"
//																										},
//																										"1ILN7H5CK0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IVMOBA2R20",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IVMOBA2R21",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1ILN7H5CK0",
//																											"faceTagName": "chat"
//																										},
//																										"1I1D5700V0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1J04JIM6026",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1J04JIM6027",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1I1D5700V0",
//																											"faceTagName": "sites"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1I1D545LC4",
//																									"attrs": {
//																										"OnClick": {
//																											"type": "fixedFunc",
//																											"jaxId": "1I1I64ARH0",
//																											"attrs": {
//																												"callArgs": {
//																													"jaxId": "1I1I64MNF0",
//																													"attrs": {
//																														"event": ""
//																													}
//																												},
//																												"seg": "1I1I64CBJ0"
//																											}
//																										}
//																									}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1I1D545LC5",
//																									"attrs": {
//																										"tip": {
//																											"type": "string",
//																											"valText": "Back",
//																											"localize": {
//																												"EN": "Back",
//																												"CN": "返回"
//																											},
//																											"localizable": true
//																										}
//																									}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "false",
//																								"containerSlots": {
//																									"jaxId": "1I1D545LC6",
//																									"attrs": {}
//																								}
//																							}
//																						},
//																						{
//																							"type": "hudobj",
//																							"def": "text",
//																							"jaxId": "1I1D549G80",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1I1D549G81",
//																									"attrs": {
//																										"type": "text",
//																										"id": "TxtGroupName",
//																										"position": "relative",
//																										"x": "0",
//																										"y": "-10",
//																										"w": "",
//																										"h": "",
//																										"anchorH": "Left",
//																										"anchorV": "Top",
//																										"autoLayout": "false",
//																										"display": "On",
//																										"clip": "Off",
//																										"uiEvent": "On",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "",
//																										"zIndex": "0",
//																										"margin": "",
//																										"padding": "",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": "",
//																										"color": "#cfgColor[\"fontBodySub\"]",
//																										"text": "www.google.com",
//																										"font": "",
//																										"fontSize": "#txtSize.bigPlus",
//																										"bold": "true",
//																										"italic": "false",
//																										"underline": "false",
//																										"alignH": "Center",
//																										"alignV": "Top",
//																										"wrap": "false",
//																										"ellipsis": "false",
//																										"lineClamp": "0",
//																										"select": "false",
//																										"shadow": "false",
//																										"shadowX": "0",
//																										"shadowY": "2",
//																										"shadowBlur": "3",
//																										"shadowColor": "[0,0,0,1.00]",
//																										"shadowEx": "",
//																										"maxTextW": "0",
//																										"flex": "true"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1I1D549G90",
//																									"attrs": {
//																										"1IMR8US3B0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IMR90II53",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IMR90II54",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IMR8US3B0",
//																											"faceTagName": "entryOn"
//																										},
//																										"1I1D5774S0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IUVB7R1A22",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IUVB7R1A23",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1I1D5774S0",
//																											"faceTagName": "siteMenu"
//																										},
//																										"1IMR8V39V0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IUVB7R1A28",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IUVB7R1A29",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IMR8V39V0",
//																											"faceTagName": "entryOff"
//																										},
//																										"1IUTA32CV0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IVMJ6PDJ44",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IVMJ6PDJ45",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IUTA32CV0",
//																											"faceTagName": "online"
//																										},
//																										"1IVH6SHR30": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IVMNKTM846",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IVMNKTM847",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IVH6SHR30",
//																											"faceTagName": "sidebarOn"
//																										},
//																										"1ILN7H5CK0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IVMOBA2R24",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IVMOBA2R25",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1ILN7H5CK0",
//																											"faceTagName": "chat"
//																										},
//																										"1I1D5700V0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1J04JIM6028",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1J04JIM6029",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1I1D5700V0",
//																											"faceTagName": "sites"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1I1D549G91",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1I1D549G92",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "true"
//																							}
//																						},
//																						{
//																							"type": "hudobj",
//																							"def": "Gear/@StdUI/ui/BtnIcon.js",
//																							"jaxId": "1I1QBHS2K0",
//																							"attrs": {
//																								"createArgs": {
//																									"jaxId": "1I1QBHS2K1",
//																									"attrs": {
//																										"style": "\"front\"",
//																										"w": "30",
//																										"h": "0",
//																										"icon": "#appCfg.sharedAssets+\"/menu.svg\"",
//																										"colorBG": "null"
//																									}
//																								},
//																								"properties": {
//																									"jaxId": "1I1QBHS2K2",
//																									"attrs": {
//																										"type": "#null#>BtnIcon(\"front\",30,0,appCfg.sharedAssets+\"/menu.svg\",null)",
//																										"id": "BtnGroupMenu",
//																										"position": "Relative",
//																										"x": "0",
//																										"y": "0",
//																										"display": "On",
//																										"face": "",
//																										"margin": "[0,5,0,0]"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1I1QBHS2L0",
//																									"attrs": {
//																										"1IMR8US3B0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IMR90II57",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IMR90II58",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IMR8US3B0",
//																											"faceTagName": "entryOn"
//																										},
//																										"1I1D5774S0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IUVB7R1A30",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IUVB7R1A31",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1I1D5774S0",
//																											"faceTagName": "siteMenu"
//																										},
//																										"1IMR8V39V0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IUVB7R1A36",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IUVB7R1A37",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IMR8V39V0",
//																											"faceTagName": "entryOff"
//																										},
//																										"1IUTA32CV0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IVMJ6PDJ48",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IVMJ6PDJ49",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IUTA32CV0",
//																											"faceTagName": "online"
//																										},
//																										"1IVH6SHR30": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IVMNKTM848",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IVMNKTM849",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IVH6SHR30",
//																											"faceTagName": "sidebarOn"
//																										},
//																										"1ILN7H5CK0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IVMOBA2R28",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IVMOBA2R29",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1ILN7H5CK0",
//																											"faceTagName": "chat"
//																										},
//																										"1I1D5700V0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1J04JIM6030",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1J04JIM6031",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1I1D5700V0",
//																											"faceTagName": "sites"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1I1QBHS2L3",
//																									"attrs": {
//																										"OnClick": {
//																											"type": "fixedFunc",
//																											"jaxId": "1I1QBHS2L4",
//																											"attrs": {
//																												"callArgs": {
//																													"jaxId": "1I1QBHS2L5",
//																													"attrs": {
//																														"event": ""
//																													}
//																												},
//																												"seg": "1I1QC7IVU0"
//																											}
//																										}
//																									}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1I1QBHS2L6",
//																									"attrs": {
//																										"tip": {
//																											"type": "string",
//																											"valText": "Options",
//																											"localize": {
//																												"EN": "Options",
//																												"CN": "选项"
//																											},
//																											"localizable": true
//																										}
//																									}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "true",
//																								"containerSlots": {
//																									"jaxId": "1I1QBHS2L7",
//																									"attrs": {}
//																								}
//																							}
//																						}
//																					]
//																				},
//																				"faces": {
//																					"jaxId": "1I1D545LC7",
//																					"attrs": {
//																						"1IMR8US3B0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IMR90II511",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IMR90II512",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IMR8US3B0",
//																							"faceTagName": "entryOn"
//																						},
//																						"1I1D5774S0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IUVB7R1A38",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IUVB7R1A39",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1I1D5774S0",
//																							"faceTagName": "siteMenu"
//																						},
//																						"1IMR8V39V0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IUVB7R1A44",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IUVB7R1A45",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IMR8V39V0",
//																							"faceTagName": "entryOff"
//																						},
//																						"1IUTA32CV0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IVMJ6PDJ52",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IVMJ6PDJ53",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IUTA32CV0",
//																							"faceTagName": "online"
//																						},
//																						"1IVH6SHR30": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IVMNKTM90",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IVMNKTM91",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IVH6SHR30",
//																							"faceTagName": "sidebarOn"
//																						},
//																						"1ILN7H5CK0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IVMOBA2R32",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IVMOBA2R33",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1ILN7H5CK0",
//																							"faceTagName": "chat"
//																						},
//																						"1I1D5700V0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1J04JIM6032",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1J04JIM6033",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1I1D5700V0",
//																							"faceTagName": "sites"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1I1D545LC8",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1I1D545LC9",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "true",
//																				"exposeContainer": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "hud",
//																			"jaxId": "1I1D4RN860",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I1D4SM5O4",
//																					"attrs": {
//																						"type": "hud",
//																						"id": "BoxGroupItems",
//																						"position": "relative",
//																						"x": "30",
//																						"y": "0",
//																						"w": "100%-60",
//																						"h": "",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "[5,0,5,0]",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"contentLayout": "Flex X",
//																						"itemsWrap": "Wrap",
//																						"subAlign": "Center"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": [
//																						{
//																							"type": "hudobj",
//																							"def": "Gear1I1I7N5V30",
//																							"jaxId": "1I1I81DE20",
//																							"attrs": {
//																								"createArgs": {
//																									"jaxId": "1I1I81DE21",
//																									"attrs": {
//																										"tool": "#{label:\"www.google.com\",tools:[1,2,3,4,5]}",
//																										"group": "{}"
//																									}
//																								},
//																								"properties": {
//																									"jaxId": "1I1I81DE22",
//																									"attrs": {
//																										"type": "#null#>BoxTool({label:\"www.google.com\",tools:[1,2,3,4,5]},{})",
//																										"id": "",
//																										"position": "Relative",
//																										"x": "125",
//																										"y": "35",
//																										"display": "On",
//																										"face": ""
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1I1I81DE23",
//																									"attrs": {
//																										"1IMR8US3B0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IMR90II515",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IMR90II516",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IMR8US3B0",
//																											"faceTagName": "entryOn"
//																										},
//																										"1I1D5774S0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IUVB7R1A46",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IUVB7R1A47",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1I1D5774S0",
//																											"faceTagName": "siteMenu"
//																										},
//																										"1IMR8V39V0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IUVB7R1A52",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IUVB7R1A53",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IMR8V39V0",
//																											"faceTagName": "entryOff"
//																										},
//																										"1IUTA32CV0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IVMJ6PDJ56",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IVMJ6PDJ57",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IUTA32CV0",
//																											"faceTagName": "online"
//																										},
//																										"1IVH6SHR30": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IVMNKTM92",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IVMNKTM93",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IVH6SHR30",
//																											"faceTagName": "sidebarOn"
//																										},
//																										"1ILN7H5CK0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IVMOBA2R36",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IVMOBA2R37",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1ILN7H5CK0",
//																											"faceTagName": "chat"
//																										},
//																										"1I1D5700V0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1J04JIM6034",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1J04JIM6035",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1I1D5700V0",
//																											"faceTagName": "sites"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1I1I81DE24",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1I1I81DE25",
//																									"attrs": {}
//																								},
//																								"mockup": "true",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "false",
//																								"containerSlots": {
//																									"jaxId": "1I1I81DE26",
//																									"attrs": {}
//																								}
//																							}
//																						},
//																						{
//																							"type": "hudobj",
//																							"def": "Gear1I1I7N5V30",
//																							"jaxId": "1I1I82G4F0",
//																							"attrs": {
//																								"createArgs": {
//																									"jaxId": "1I1I82G4F1",
//																									"attrs": {
//																										"tool": "#{label:\"www.google.com\",tools:[1,2,3,4,5]}",
//																										"group": "{}"
//																									}
//																								},
//																								"properties": {
//																									"jaxId": "1I1I82G4F2",
//																									"attrs": {
//																										"type": "#null#>BoxTool({label:\"www.google.com\",tools:[1,2,3,4,5]},{})",
//																										"id": "",
//																										"position": "Relative",
//																										"x": "125",
//																										"y": "35",
//																										"display": "On",
//																										"face": ""
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1I1I82G4F3",
//																									"attrs": {
//																										"1IMR8US3B0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IMR90II519",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IMR90II520",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IMR8US3B0",
//																											"faceTagName": "entryOn"
//																										},
//																										"1I1D5774S0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IUVB7R1A54",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IUVB7R1A55",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1I1D5774S0",
//																											"faceTagName": "siteMenu"
//																										},
//																										"1IMR8V39V0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IUVB7R1A60",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IUVB7R1A61",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IMR8V39V0",
//																											"faceTagName": "entryOff"
//																										},
//																										"1IUTA32CV0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IVMJ6PDJ60",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IVMJ6PDJ61",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IUTA32CV0",
//																											"faceTagName": "online"
//																										},
//																										"1IVH6SHR30": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IVMNKTM94",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IVMNKTM95",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IVH6SHR30",
//																											"faceTagName": "sidebarOn"
//																										},
//																										"1ILN7H5CK0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IVMOBA2R40",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IVMOBA2R41",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1ILN7H5CK0",
//																											"faceTagName": "chat"
//																										},
//																										"1I1D5700V0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1J04JIM6036",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1J04JIM6037",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1I1D5700V0",
//																											"faceTagName": "sites"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1I1I82G4F4",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1I1I82G4F5",
//																									"attrs": {}
//																								},
//																								"mockup": "true",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "false",
//																								"containerSlots": {
//																									"jaxId": "1I1I82G4F6",
//																									"attrs": {}
//																								}
//																							}
//																						},
//																						{
//																							"type": "hudobj",
//																							"def": "Gear1I1I7N5V30",
//																							"jaxId": "1I1I82HKS0",
//																							"attrs": {
//																								"createArgs": {
//																									"jaxId": "1I1I82HKS1",
//																									"attrs": {
//																										"tool": "#{label:\"www.google.com\",tools:[1,2,3,4,5]}",
//																										"group": "{}"
//																									}
//																								},
//																								"properties": {
//																									"jaxId": "1I1I82HKS2",
//																									"attrs": {
//																										"type": "#null#>BoxTool({label:\"www.google.com\",tools:[1,2,3,4,5]},{})",
//																										"id": "",
//																										"position": "Relative",
//																										"x": "125",
//																										"y": "35",
//																										"display": "On",
//																										"face": ""
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1I1I82HKS3",
//																									"attrs": {
//																										"1IMR8US3B0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IMR90II523",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IMR90II524",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IMR8US3B0",
//																											"faceTagName": "entryOn"
//																										},
//																										"1I1D5774S0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IUVB7R1A62",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IUVB7R1A63",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1I1D5774S0",
//																											"faceTagName": "siteMenu"
//																										},
//																										"1IMR8V39V0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IUVB7R1A68",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IUVB7R1A69",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IMR8V39V0",
//																											"faceTagName": "entryOff"
//																										},
//																										"1IUTA32CV0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IVMJ6PDJ64",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IVMJ6PDJ65",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IUTA32CV0",
//																											"faceTagName": "online"
//																										},
//																										"1IVH6SHR30": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IVMNKTM96",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IVMNKTM97",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IVH6SHR30",
//																											"faceTagName": "sidebarOn"
//																										},
//																										"1ILN7H5CK0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IVMOBA2R44",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IVMOBA2R45",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1ILN7H5CK0",
//																											"faceTagName": "chat"
//																										},
//																										"1I1D5700V0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1J04JIM6038",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1J04JIM6039",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1I1D5700V0",
//																											"faceTagName": "sites"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1I1I82HKS4",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1I1I82HKS5",
//																									"attrs": {}
//																								},
//																								"mockup": "true",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "false",
//																								"containerSlots": {
//																									"jaxId": "1I1I82HKS6",
//																									"attrs": {}
//																								}
//																							}
//																						}
//																					]
//																				},
//																				"faces": {
//																					"jaxId": "1I1D4SM5O5",
//																					"attrs": {
//																						"1IMR8US3B0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IMR90II527",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IMR90II528",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IMR8US3B0",
//																							"faceTagName": "entryOn"
//																						},
//																						"1I1D5774S0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IUVB7R1A70",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IUVB7R1A71",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1I1D5774S0",
//																							"faceTagName": "siteMenu"
//																						},
//																						"1IMR8V39V0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IUVB7R1A76",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IUVB7R1A77",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IMR8V39V0",
//																							"faceTagName": "entryOff"
//																						},
//																						"1IUTA32CV0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IVMJ6PDJ68",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IVMJ6PDJ69",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IUTA32CV0",
//																							"faceTagName": "online"
//																						},
//																						"1IVH6SHR30": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IVMNKTM98",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IVMNKTM99",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IVH6SHR30",
//																							"faceTagName": "sidebarOn"
//																						},
//																						"1ILN7H5CK0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IVMOBA2R48",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IVMOBA2R49",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1ILN7H5CK0",
//																							"faceTagName": "chat"
//																						},
//																						"1I1D5700V0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1J04JIM6040",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1J04JIM6041",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1I1D5700V0",
//																							"faceTagName": "sites"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1I1D4SM5O6",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1I1D4SM5O7",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "true",
//																				"exposeContainer": "false"
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"jaxId": "1I1D4N6FM1",
//																	"attrs": {
//																		"1I1D5774S0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I1D58F4795",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I1D58F4796",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I1D5774S0",
//																			"faceTagName": "siteMenu"
//																		},
//																		"1I1D5700V0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I1D58F4797",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I1D58F4798",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I1D5700V0",
//																			"faceTagName": "sites"
//																		},
//																		"1IMR8US3B0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IMR90II531",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IMR90II532",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IMR8US3B0",
//																			"faceTagName": "entryOn"
//																		},
//																		"1IMR8V39V0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IUVB7R1A82",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IUVB7R1A83",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IMR8V39V0",
//																			"faceTagName": "entryOff"
//																		},
//																		"1IUTA32CV0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVMJ6PDJ72",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVMJ6PDJ73",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IUTA32CV0",
//																			"faceTagName": "online"
//																		},
//																		"1IVH6SHR30": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVMNKTM910",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVMNKTM911",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IVH6SHR30",
//																			"faceTagName": "sidebarOn"
//																		},
//																		"1ILN7H5CK0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVMOBA2R52",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVMOBA2R53",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1ILN7H5CK0",
//																			"faceTagName": "chat"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1I1D4N6FM2",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1I1D4N6FM3",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "true",
//																"exposeContainer": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1IVP63JCP0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVP63JCP1",
//																	"attrs": {
//																		"type": "hud",
//																		"id": "BoxShortcuts",
//																		"position": "Absolute",
//																		"x": "50",
//																		"y": "0",
//																		"w": "100%-100",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Auto Scroll Y",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "10",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"contentLayout": "Flex Y",
//																		"subAlign": "Center",
//																		"itemsAlign": "Center",
//																		"itemsWrap": "Wrap"
//																	}
//																},
//																"subHuds": {
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "hud",
//																			"jaxId": "1IVP7GV5Q0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVPE342H0",
//																					"attrs": {
//																						"type": "hud",
//																						"id": "BoxShortcutsHeader",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "100%",
//																						"h": "30",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "Off",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"contentLayout": "Flex X",
//																						"itemsAlign": "Center"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": [
//																						{
//																							"type": "hudobj",
//																							"def": "Gear/@StdUI/ui/BtnIcon.js",
//																							"jaxId": "1IVP7KFRF0",
//																							"attrs": {
//																								"createArgs": {
//																									"jaxId": "1IVPE342H1",
//																									"attrs": {
//																										"style": "\"front\"",
//																										"w": "30",
//																										"h": "0",
//																										"icon": "#appCfg.sharedAssets+\"/btncombo.svg\"",
//																										"colorBG": "null"
//																									}
//																								},
//																								"properties": {
//																									"jaxId": "1IVPE342H2",
//																									"attrs": {
//																										"type": "#null#>BtnIcon(\"front\",30,0,appCfg.sharedAssets+\"/btncombo.svg\",null)",
//																										"id": "BtnShortcutType",
//																										"position": "relative",
//																										"x": "0",
//																										"y": "0",
//																										"display": "On",
//																										"face": ""
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1IVPE342H3",
//																									"attrs": {
//																										"1I1D5700V0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1J04JIM6042",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1J04JIM6043",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1I1D5700V0",
//																											"faceTagName": "sites"
//																										},
//																										"1ILN7H5CK0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1J04JIM6044",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1J04JIM6045",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1ILN7H5CK0",
//																											"faceTagName": "chat"
//																										},
//																										"1IVH6SHR30": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1J04JIM6046",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1J04JIM6047",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IVH6SHR30",
//																											"faceTagName": "sidebarOn"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1IVPE342H4",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1IVPE342H5",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "false",
//																								"containerSlots": {
//																									"jaxId": "1IVPE342H6",
//																									"attrs": {}
//																								}
//																							}
//																						},
//																						{
//																							"type": "hudobj",
//																							"def": "text",
//																							"jaxId": "1IVP7LL870",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IVPE342H7",
//																									"attrs": {
//																										"type": "text",
//																										"id": "TxtShortcuts",
//																										"position": "relative",
//																										"x": "0",
//																										"y": "0",
//																										"w": "100",
//																										"h": "",
//																										"anchorH": "Left",
//																										"anchorV": "Top",
//																										"autoLayout": "false",
//																										"display": "On",
//																										"clip": "Off",
//																										"uiEvent": "On",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "",
//																										"zIndex": "0",
//																										"margin": "[0,0,0,5]",
//																										"padding": "",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": "",
//																										"color": "#cfgColor[\"fontBody\"]",
//																										"text": "Featured",
//																										"font": "",
//																										"fontSize": "#txtSize.mid",
//																										"bold": "false",
//																										"italic": "false",
//																										"underline": "false",
//																										"alignH": "Left",
//																										"alignV": "Top",
//																										"wrap": "false",
//																										"ellipsis": "false",
//																										"lineClamp": "0",
//																										"select": "false",
//																										"shadow": "false",
//																										"shadowX": "0",
//																										"shadowY": "2",
//																										"shadowBlur": "3",
//																										"shadowColor": "[0,0,0,1.00]",
//																										"shadowEx": "",
//																										"maxTextW": "0"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1IVPE342H8",
//																									"attrs": {
//																										"1I1D5700V0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1J04JIM6048",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1J04JIM6049",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1I1D5700V0",
//																											"faceTagName": "sites"
//																										},
//																										"1ILN7H5CK0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1J04JIM6050",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1J04JIM6051",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1ILN7H5CK0",
//																											"faceTagName": "chat"
//																										},
//																										"1IVH6SHR30": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1J04JIM6052",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1J04JIM6053",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IVH6SHR30",
//																											"faceTagName": "sidebarOn"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1IVPE342H9",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1IVPE342H10",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "false"
//																							}
//																						}
//																					]
//																				},
//																				"faces": {
//																					"jaxId": "1IVPE342H11",
//																					"attrs": {
//																						"1I1D5700V0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1J04JIM6054",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1J04JIM6055",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1I1D5700V0",
//																							"faceTagName": "sites"
//																						},
//																						"1ILN7H5CK0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1J04JIM6056",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1J04JIM6057",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1ILN7H5CK0",
//																							"faceTagName": "chat"
//																						},
//																						"1IVH6SHR30": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1J04JIM6058",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1J04JIM6059",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IVH6SHR30",
//																							"faceTagName": "sidebarOn"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1IVPE342H12",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1IVPE342H13",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "true",
//																				"exposeContainer": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "hud",
//																			"jaxId": "1IVP7HPJC0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVPE342H14",
//																					"attrs": {
//																						"type": "hud",
//																						"id": "BoxShortcutCards",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "100%",
//																						"h": "",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"contentLayout": "Flex X",
//																						"itemsWrap": "Wrap",
//																						"itemsAlign": "Center",
//																						"subAlign": "Center"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": [
//																						{
//																							"type": "hudobj",
//																							"def": "Gear1IVOTP04N0",
//																							"jaxId": "1IVP64OD60",
//																							"attrs": {
//																								"createArgs": {
//																									"jaxId": "1IVP66AMT0",
//																									"attrs": {
//																										"tool": "#{label:\"www.google.com\",tools:[1,2,3,4,5],description:\"深度思考，This is an deepsearch agent.\"}"
//																									}
//																								},
//																								"properties": {
//																									"jaxId": "1IVP66AMT1",
//																									"attrs": {
//																										"type": "#null#>BtnToolCard({label:\"www.google.com\",tools:[1,2,3,4,5],description:\"深度思考，This is an deepsearch agent.\"})",
//																										"id": "",
//																										"position": "Relative",
//																										"x": "125",
//																										"y": "50",
//																										"display": "On",
//																										"face": ""
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1IVP66AMT2",
//																									"attrs": {
//																										"1I1D5700V0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1J04JIM6060",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1J04JIM6061",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1I1D5700V0",
//																											"faceTagName": "sites"
//																										},
//																										"1ILN7H5CK0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1J04JIM6062",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1J04JIM6063",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1ILN7H5CK0",
//																											"faceTagName": "chat"
//																										},
//																										"1IVH6SHR30": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1J04JIM6064",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1J04JIM6065",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IVH6SHR30",
//																											"faceTagName": "sidebarOn"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1IVP66AMT3",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1IVP66AMT4",
//																									"attrs": {}
//																								},
//																								"mockup": "true",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "false",
//																								"containerSlots": {
//																									"jaxId": "1IVP66AMT5",
//																									"attrs": {}
//																								}
//																							}
//																						}
//																					]
//																				},
//																				"faces": {
//																					"jaxId": "1IVPE342H15",
//																					"attrs": {
//																						"1I1D5700V0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1J04JIM6066",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1J04JIM6067",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1I1D5700V0",
//																							"faceTagName": "sites"
//																						},
//																						"1ILN7H5CK0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1J04JIM6068",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1J04JIM6069",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1ILN7H5CK0",
//																							"faceTagName": "chat"
//																						},
//																						"1IVH6SHR30": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1J04JIM6070",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1J04JIM6071",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IVH6SHR30",
//																							"faceTagName": "sidebarOn"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1IVPE342H16",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1IVPE342H17",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "true",
//																				"exposeContainer": "false"
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"jaxId": "1IVP63JCQ17",
//																	"attrs": {
//																		"1I1D5774S0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVP63JCQ18",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVP63JCQ19",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I1D5774S0",
//																			"faceTagName": "siteMenu"
//																		},
//																		"1I1D5700V0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVP63JCQ20",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVP63JCQ21",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I1D5700V0",
//																			"faceTagName": "sites"
//																		},
//																		"1IMR8US3B0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVP63JCQ22",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVP63JCQ23",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IMR8US3B0",
//																			"faceTagName": "entryOn"
//																		},
//																		"1IMR8V39V0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVP63JCQ24",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVP63JCQ25",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IMR8V39V0",
//																			"faceTagName": "entryOff"
//																		},
//																		"1IUTA32CV0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVP63JCQ26",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVP63JCQ27",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IUTA32CV0",
//																			"faceTagName": "online"
//																		},
//																		"1IVH6SHR30": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVP63JCQ28",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVP63JCQ29",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IVH6SHR30",
//																			"faceTagName": "sidebarOn"
//																		},
//																		"1ILN7H5CK0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVP63JCR0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVP63JCR1",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1ILN7H5CK0",
//																			"faceTagName": "chat"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1IVP63JCR2",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1IVP63JCR3",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "true",
//																"exposeContainer": "false"
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1I11DGKMG1",
//													"attrs": {
//														"1I1D5700V0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1ILN5JB7F52",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1ILN5JB7F53",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I1D5700V0",
//															"faceTagName": "sites"
//														},
//														"1I1D5774S0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1ILN7IHKR18",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1ILN7IHKR19",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I1D5774S0",
//															"faceTagName": "siteMenu"
//														},
//														"1IMR8US3B0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IMR90II535",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IMR90II536",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IMR8US3B0",
//															"faceTagName": "entryOn"
//														},
//														"1IMR8V39V0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IUVB7R1A88",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IUVB7R1A89",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IMR8V39V0",
//															"faceTagName": "entryOff"
//														},
//														"1IUTA32CV0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVMJ6PDJ76",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVMJ6PDJ77",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IUTA32CV0",
//															"faceTagName": "online"
//														},
//														"1IVH6SHR30": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVMNKTM912",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVMNKTM913",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IVH6SHR30",
//															"faceTagName": "sidebarOn"
//														},
//														"1ILN7H5CK0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVMOBA2R56",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVMOBA2R57",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1ILN7H5CK0",
//															"faceTagName": "chat"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I11DGKMG2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I11DGKMG3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1ILNAF7KU52",
//									"attrs": {
//										"1ILN7H5CK0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1ILNAF7KU53",
//											"attrs": {
//												"properties": {
//													"jaxId": "1ILNAF7KU54",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1ILN7H5CK0",
//											"faceTagName": "chat"
//										},
//										"1I1D5774S0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1ILNAI7GH0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1ILNAI7GH1",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I1D5774S0",
//											"faceTagName": "siteMenu"
//										},
//										"1I1D5700V0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1ILNAI7GH2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1ILNAI7GH3",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I1D5700V0",
//											"faceTagName": "sites"
//										},
//										"1IMR8US3B0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IMR90II539",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IMR90II540",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IMR8US3B0",
//											"faceTagName": "entryOn"
//										},
//										"1IMR8V39V0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IUVB7R1A92",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IUVB7R1A93",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IMR8V39V0",
//											"faceTagName": "entryOff"
//										},
//										"1IVH6TC9J0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IVMINBSI16",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IVMINBSI17",
//													"attrs": {
//														"x": {
//															"type": "length",
//															"valText": "50%"
//														},
//														"anchorH": {
//															"type": "choice",
//															"valText": "Center"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IVH6TC9J0",
//											"faceTagName": "sidebarOff"
//										},
//										"1IUTA32CV0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IVMJ6PDJ80",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IVMJ6PDJ81",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IUTA32CV0",
//											"faceTagName": "online"
//										},
//										"1IVH6SHR30": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IVMNKTM914",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IVMNKTM915",
//													"attrs": {
//														"x": {
//															"type": "length",
//															"valText": "0"
//														},
//														"anchorH": {
//															"type": "choice",
//															"valText": "Left"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IVH6SHR30",
//											"faceTagName": "sidebarOn"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1ILNAF7KU55",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1ILNAF7KU56",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1ILN7T8730",
//							"attrs": {
//								"properties": {
//									"jaxId": "1ILN802D970",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxChats",
//										"position": "Absolute",
//										"x": "0",
//										"y": "30",
//										"w": "100%",
//										"h": "100%-30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "Off",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": ""
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1ILN802D971",
//									"attrs": {
//										"1ILN7H5CK0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1ILN802D972",
//											"attrs": {
//												"properties": {
//													"jaxId": "1ILN802D973",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1ILN7H5CK0",
//											"faceTagName": "chat"
//										},
//										"1I1D5700V0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1ILN802D974",
//											"attrs": {
//												"properties": {
//													"jaxId": "1ILN802D975",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I1D5700V0",
//											"faceTagName": "sites"
//										},
//										"1I1D5774S0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1ILN802D976",
//											"attrs": {
//												"properties": {
//													"jaxId": "1ILN802D977",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I1D5774S0",
//											"faceTagName": "siteMenu"
//										},
//										"1IMR8US3B0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IMR90II543",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IMR90II544",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IMR8US3B0",
//											"faceTagName": "entryOn"
//										},
//										"1IMR8V39V0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IUVB7R1A96",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IUVB7R1A97",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IMR8V39V0",
//											"faceTagName": "entryOff"
//										},
//										"1IUTA32CV0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IVMJ6PDJ84",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IVMJ6PDJ85",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IUTA32CV0",
//											"faceTagName": "online"
//										},
//										"1IVH6SHR30": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IVMNKTM916",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IVMNKTM917",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IVH6SHR30",
//											"faceTagName": "sidebarOn"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1ILN802D978",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1ILN802D979",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1ILN0BQ5L0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1ILN0RFNG0",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxNavi",
//										"position": "Absolute",
//										"x": "${-state.naviBoxW},state",
//										"y": "0",
//										"w": "${state.naviBoxW},state",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "[0,5,5,5]",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex Y",
//										"itemsAlign": "Start"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1ILN6U0GJ0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1ILN722LB0",
//													"attrs": {
//														"type": "box",
//														"id": "BoxBG",
//														"position": "Absolute",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "#cfgColor[\"tool\"]",
//														"border": "0",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"shadow": "true",
//														"shadowX": "-1",
//														"shadowY": "2",
//														"shadowBlur": "2",
//														"shadowSpread": "2",
//														"shadowColor": "[0,0,0,0.750]"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1ILN722LB1",
//													"attrs": {
//														"1IMR8US3B0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IMR90II547",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IMR90II548",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IMR8US3B0",
//															"faceTagName": "entryOn"
//														},
//														"1I1D5774S0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IUVB7R1A98",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IUVB7R1A99",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I1D5774S0",
//															"faceTagName": "siteMenu"
//														},
//														"1IMR8V39V0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IUVB7R1A104",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IUVB7R1A105",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IMR8V39V0",
//															"faceTagName": "entryOff"
//														},
//														"1IUTA32CV0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVMJ6PDJ88",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVMJ6PDJ89",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IUTA32CV0",
//															"faceTagName": "online"
//														},
//														"1IVH6SHR30": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVMNKTM918",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVMNKTM919",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IVH6SHR30",
//															"faceTagName": "sidebarOn"
//														},
//														"1ILN7H5CK0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVMOBA2R62",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVMOBA2R63",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1ILN7H5CK0",
//															"faceTagName": "chat"
//														},
//														"1I1D5700V0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J04JIM6072",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J04JIM6073",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I1D5700V0",
//															"faceTagName": "sites"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1ILN722LB2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1ILN722LB3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1IVMGK95R0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IVMGK95R1",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxNaviHeader",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "30",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"flex": "false",
//														"contentLayout": "Flex X",
//														"itemsAlign": "Center"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1IVMGOSM40",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1IVMGOSM41",
//																	"attrs": {
//																		"style": "\"front\"",
//																		"w": "28",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/uilefthide.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1IVMGOSM50",
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"front\",28,0,appCfg.sharedAssets+\"/uilefthide.svg\",null)",
//																		"id": "BtnHideSideBar",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IVMGOSM51",
//																	"attrs": {
//																		"1IVH6SHR30": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVMGOSM52",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVMGOSM53",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IVH6SHR30",
//																			"faceTagName": "sidebarOn"
//																		},
//																		"1IVH6TC9J0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVMGOSM54",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVMGOSM55",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IVH6TC9J0",
//																			"faceTagName": "sidebarOff"
//																		},
//																		"1I1D5774S0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVMGOSM58",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVMGOSM59",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I1D5774S0",
//																			"faceTagName": "siteMenu"
//																		},
//																		"1IUTA32CV0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVMJ6PDJ92",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVMJ6PDJ93",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IUTA32CV0",
//																			"faceTagName": "online"
//																		},
//																		"1ILN7H5CK0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVMOBA2R66",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVMOBA2R67",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1ILN7H5CK0",
//																			"faceTagName": "chat"
//																		},
//																		"1I1D5700V0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J04JIM6074",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J04JIM6075",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I1D5700V0",
//																			"faceTagName": "sites"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1IVMGOSM510",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1IVMJ5AD90",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1IVMJ5AD91",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": "1IVMISH2R0"
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1IVMGOSM511",
//																	"attrs": {
//																		"tip": {
//																			"type": "string",
//																			"valText": "Hide sidebar",
//																			"localize": {
//																				"EN": "Hide sidebar",
//																				"CN": "隐藏边栏"
//																			},
//																			"localizable": true
//																		}
//																	}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1IVMGOSM512",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1IVMJOCPE0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1IVMJOCPE1",
//																	"attrs": {
//																		"style": "\"front\"",
//																		"w": "28",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/chat_add.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1IVMJOCPE2",
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"front\",28,0,appCfg.sharedAssets+\"/chat_add.svg\",null)",
//																		"id": "BtnNewChat",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"margin": "[0,0,0,10]"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IVMJOCPE3",
//																	"attrs": {
//																		"1IVH6SHR30": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVMJOCPE4",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVMJOCPE5",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IVH6SHR30",
//																			"faceTagName": "sidebarOn"
//																		},
//																		"1IVH6TC9J0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVMJOCPE6",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVMJOCPE7",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IVH6TC9J0",
//																			"faceTagName": "sidebarOff"
//																		},
//																		"1I1D5774S0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVMJOCPE10",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVMJOCPE11",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I1D5774S0",
//																			"faceTagName": "siteMenu"
//																		},
//																		"1IUTA32CV0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVMJOCPE12",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVMJOCPE13",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IUTA32CV0",
//																			"faceTagName": "online"
//																		},
//																		"1ILN7H5CK0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVMOBA2R68",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVMOBA2R69",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1ILN7H5CK0",
//																			"faceTagName": "chat"
//																		},
//																		"1I1D5700V0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J04JIM6076",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J04JIM6077",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I1D5700V0",
//																			"faceTagName": "sites"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1IVMJOCPE14",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1IVMJOCPF0",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1IVMJOCPF1",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1IVMJOCPF2",
//																	"attrs": {
//																		"tip": {
//																			"type": "string",
//																			"valText": "New conversation",
//																			"localize": {
//																				"EN": "New conversation",
//																				"CN": "新对话"
//																			},
//																			"localizable": true
//																		}
//																	}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1IVMJOCPF3",
//																	"attrs": {}
//																}
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1IVMGK95R2",
//													"attrs": {
//														"1I1D5774S0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVMGK95R5",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVMGK95R6",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I1D5774S0",
//															"faceTagName": "siteMenu"
//														},
//														"1IUTA32CV0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVMJ6PDK20",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVMJ6PDK21",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IUTA32CV0",
//															"faceTagName": "online"
//														},
//														"1IVH6SHR30": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVMNKTM920",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVMNKTM921",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IVH6SHR30",
//															"faceTagName": "sidebarOn"
//														},
//														"1ILN7H5CK0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVMOBA2R70",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVMOBA2R71",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1ILN7H5CK0",
//															"faceTagName": "chat"
//														},
//														"1I1D5700V0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J04JIM6078",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J04JIM6079",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I1D5700V0",
//															"faceTagName": "sites"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IVMGK95R7",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IVMGK95R8",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "true",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1ILN5BGIH0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1ILN5F51M54",
//													"attrs": {
//														"type": "hud",
//														"id": "",
//														"position": "relative",
//														"x": "50%",
//														"y": "0",
//														"w": "60",
//														"h": "60",
//														"anchorH": "Center",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[5,5,15,5]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": ""
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "box",
//															"jaxId": "1ILN3AUOA0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1ILN3D3400",
//																	"attrs": {
//																		"type": "box",
//																		"id": "",
//																		"position": "relative",
//																		"x": "50%",
//																		"y": "50%",
//																		"w": "40",
//																		"h": "40",
//																		"anchorH": "Center",
//																		"anchorV": "Center",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "pointer",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"background": "#cfgColor[\"fontBody\"]",
//																		"border": "0",
//																		"borderStyle": "Solid",
//																		"borderColor": "[0,0,0,1.00]",
//																		"corner": "0",
//																		"shadow": "false",
//																		"shadowX": "2",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowSpread": "0",
//																		"shadowColor": "[0,0,0,0.50]",
//																		"maskImage": "#appCfg.sharedAssets+\"/aalogo.svg\""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1ILN3D3401",
//																	"attrs": {
//																		"1I1D5700V0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1ILN5ADBC54",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1ILN5ADBC55",
//																					"attrs": {
//																						"background": {
//																							"type": "colorRGBA",
//																							"valText": "#cfgColor[\"fontBodySub\"]"
//																						},
//																						"uiEvent": {
//																							"type": "choice",
//																							"valText": "Tree Off"
//																						},
//																						"w": {
//																							"type": "length",
//																							"valText": "40"
//																						},
//																						"h": {
//																							"type": "length",
//																							"valText": "40"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I1D5700V0",
//																			"faceTagName": "sites"
//																		},
//																		"1I1D5774S0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1ILN5ADBC56",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1ILN5ADBC57",
//																					"attrs": {
//																						"background": {
//																							"type": "colorRGBA",
//																							"valText": "#cfgColor[\"fontBody\"]"
//																						},
//																						"uiEvent": {
//																							"type": "choice",
//																							"valText": "On"
//																						},
//																						"w": {
//																							"type": "length",
//																							"valText": "60"
//																						},
//																						"h": {
//																							"type": "length",
//																							"valText": "60"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I1D5774S0",
//																			"faceTagName": "siteMenu"
//																		},
//																		"1ILN7H5CK0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1ILNAF7KU59",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1ILNAF7KU60",
//																					"attrs": {
//																						"uiEvent": {
//																							"type": "choice",
//																							"valText": "On"
//																						},
//																						"w": {
//																							"type": "length",
//																							"valText": "60"
//																						},
//																						"h": {
//																							"type": "length",
//																							"valText": "60"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1ILN7H5CK0",
//																			"faceTagName": "chat"
//																		},
//																		"1IMR8US3B0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IMR90II571",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IMR90II572",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IMR8US3B0",
//																			"faceTagName": "entryOn"
//																		},
//																		"1IMR8V39V0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IUVB7R1A148",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IUVB7R1A149",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IMR8V39V0",
//																			"faceTagName": "entryOff"
//																		},
//																		"1IUTA32CV0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVMJ6PDK24",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVMJ6PDK25",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IUTA32CV0",
//																			"faceTagName": "online"
//																		},
//																		"1IVH6SHR30": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVMNKTM922",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVMNKTM923",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IVH6SHR30",
//																			"faceTagName": "sidebarOn"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1ILN3D3402",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1ILN7FUFJ0",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1ILN7FUFJ1",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": "1I1I64CBJ0"
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1ILN3D3403",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1ILN5H7VB0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1ILN5JB7F54",
//																	"attrs": {
//																		"type": "text",
//																		"id": "",
//																		"position": "Absolute",
//																		"x": "0",
//																		"y": "100%-10",
//																		"w": "100%",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontBodyLit\"]",
//																		"text": "www.ai2apps.com",
//																		"font": "",
//																		"fontSize": "#txtSize.small",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Center",
//																		"alignV": "Top",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"lineClamp": "0",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1ILN5JB7F55",
//																	"attrs": {
//																		"1I1D5700V0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1ILN5JB7F56",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1ILN5JB7F57",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I1D5700V0",
//																			"faceTagName": "sites"
//																		},
//																		"1I1D5774S0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1ILN5JB7F58",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1ILN5JB7F59",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I1D5774S0",
//																			"faceTagName": "siteMenu"
//																		},
//																		"1ILN7H5CK0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1ILNAF7KU61",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1ILNAF7KU62",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1ILN7H5CK0",
//																			"faceTagName": "chat"
//																		},
//																		"1IMR8US3B0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IMR90II575",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IMR90II576",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IMR8US3B0",
//																			"faceTagName": "entryOn"
//																		},
//																		"1IMR8V39V0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IUVB7R1A152",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IUVB7R1A153",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IMR8V39V0",
//																			"faceTagName": "entryOff"
//																		},
//																		"1IUTA32CV0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVMJ6PDK28",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVMJ6PDK29",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IUTA32CV0",
//																			"faceTagName": "online"
//																		},
//																		"1IVH6SHR30": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVMNKTM924",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVMNKTM925",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IVH6SHR30",
//																			"faceTagName": "sidebarOn"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1ILN5JB7F60",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1ILN5JB7F61",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false"
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1ILN5F51N0",
//													"attrs": {
//														"1IMR8US3B0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IMR90II579",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IMR90II580",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IMR8US3B0",
//															"faceTagName": "entryOn"
//														},
//														"1I1D5774S0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IUVB7R1A154",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IUVB7R1A155",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I1D5774S0",
//															"faceTagName": "siteMenu"
//														},
//														"1IMR8V39V0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IUVB7R1A160",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IUVB7R1A161",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IMR8V39V0",
//															"faceTagName": "entryOff"
//														},
//														"1IUTA32CV0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVMJ6PDK32",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVMJ6PDK33",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IUTA32CV0",
//															"faceTagName": "online"
//														},
//														"1IVH6SHR30": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVMNKTM926",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVMNKTM927",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IVH6SHR30",
//															"faceTagName": "sidebarOn"
//														},
//														"1ILN7H5CK0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVMOBA2R78",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVMOBA2R79",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1ILN7H5CK0",
//															"faceTagName": "chat"
//														},
//														"1I1D5700V0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J04JIM610",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J04JIM611",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I1D5700V0",
//															"faceTagName": "sites"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1ILN5F51N3",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1ILN5F51N4",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear1I1UT4SUC0",
//											"jaxId": "1I1UU28N70",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1I1UU3EFU0",
//													"attrs": {
//														"icon": "appdata.svg",
//														"text": "-",
//														"tip": {
//															"type": "string",
//															"valText": "Agents",
//															"localize": {
//																"EN": "Agents",
//																"CN": "智能体管理"
//															},
//															"localizable": true
//														},
//														"tipSize": "0",
//														"tipIcon": ""
//													}
//												},
//												"properties": {
//													"jaxId": "1I1UU3EFU1",
//													"attrs": {
//														"type": "#null#>BtnState(\"appdata.svg\",\"-\",(($ln===\"CN\")?(\"智能体管理\"):(\"Agents\")),0,\"\")",
//														"id": "BtnStateTool",
//														"position": "Relative",
//														"x": "10%",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"anchorH": "Left",
//														"w": "80%"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I1UU3EFU2",
//													"attrs": {
//														"1I1D5700V0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I1V0C7MT18",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I1V0C7MT19",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I1D5700V0",
//															"faceTagName": "sites"
//														},
//														"1IMR8US3B0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IMR90II583",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IMR90II584",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IMR8US3B0",
//															"faceTagName": "entryOn"
//														},
//														"1I1D5774S0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IUVB7R1A162",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IUVB7R1A163",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I1D5774S0",
//															"faceTagName": "siteMenu"
//														},
//														"1IMR8V39V0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IUVB7R1A168",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IUVB7R1A169",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IMR8V39V0",
//															"faceTagName": "entryOff"
//														},
//														"1IUTA32CV0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVMJ6PDK36",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVMJ6PDK37",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IUTA32CV0",
//															"faceTagName": "online"
//														},
//														"1IVH6SHR30": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVMNKTM928",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVMNKTM929",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IVH6SHR30",
//															"faceTagName": "sidebarOn"
//														},
//														"1ILN7H5CK0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVMOBA2S0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVMOBA2S1",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1ILN7H5CK0",
//															"faceTagName": "chat"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I1UU3EFU3",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1I275U5D70",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1I275U5D71",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": "1I268L5VR0"
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1I1UU3EFU4",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1I1UU3EFU5",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear1I1UT4SUC0",
//											"jaxId": "1I2B3HVI30",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1I2B3HVI31",
//													"attrs": {
//														"icon": "agent.svg",
//														"text": "-",
//														"tip": {
//															"type": "string",
//															"valText": "Agent Nodes",
//															"localize": {
//																"EN": "Agent Nodes",
//																"CN": "智能体节点"
//															},
//															"localizable": true
//														},
//														"tipSize": "0",
//														"tipIcon": ""
//													}
//												},
//												"properties": {
//													"jaxId": "1I2B3HVI32",
//													"attrs": {
//														"type": "#null#>BtnState(\"agent.svg\",\"-\",(($ln===\"CN\")?(\"智能体节点\"):(\"Agent Nodes\")),0,\"\")",
//														"id": "BtnStateBots",
//														"position": "Relative",
//														"x": "10%",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"anchorH": "Left",
//														"w": "80%"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I2B3HVI40",
//													"attrs": {
//														"1I1D5700V0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I2B3HVI41",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I2B3HVI42",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I1D5700V0",
//															"faceTagName": "sites"
//														},
//														"1IMR8US3B0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IMR90II587",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IMR90II588",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IMR8US3B0",
//															"faceTagName": "entryOn"
//														},
//														"1I1D5774S0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IUVB7R1A170",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IUVB7R1A171",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I1D5774S0",
//															"faceTagName": "siteMenu"
//														},
//														"1IMR8V39V0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IUVB7R1A176",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IUVB7R1A177",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IMR8V39V0",
//															"faceTagName": "entryOff"
//														},
//														"1IUTA32CV0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVMJ6PDK40",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVMJ6PDK41",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IUTA32CV0",
//															"faceTagName": "online"
//														},
//														"1IVH6SHR30": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVMNKTM930",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVMNKTM931",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IVH6SHR30",
//															"faceTagName": "sidebarOn"
//														},
//														"1ILN7H5CK0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVMOBA2S4",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVMOBA2S5",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1ILN7H5CK0",
//															"faceTagName": "chat"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I2B3HVI45",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1I2B3HVI50",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1I2B3HVI51",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": "1I2ESN96I0"
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1I2B3HVI52",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1I2B3HVI53",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear1I1UT4SUC0",
//											"jaxId": "1I1UUF8SN0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1I1UUF8SN1",
//													"attrs": {
//														"icon": "skillchain.svg",
//														"text": "-",
//														"tip": {
//															"type": "string",
//															"valText": "Agent Chain",
//															"localize": {
//																"EN": "Agent Chain",
//																"CN": "智能链管理"
//															},
//															"localizable": true
//														},
//														"tipSize": "16",
//														"tipIcon": ""
//													}
//												},
//												"properties": {
//													"jaxId": "1I1UUF8SN2",
//													"attrs": {
//														"type": "#null#>BtnState(\"skillchain.svg\",\"-\",(($ln===\"CN\")?(\"智能链管理\"):(\"Agent Chain\")),16,\"\")",
//														"id": "BtnStateChain",
//														"position": "Relative",
//														"x": "10%",
//														"y": "0",
//														"display": "Off",
//														"face": "",
//														"anchorH": "Left",
//														"w": "80%",
//														"enable": "false"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I1UUF8SO0",
//													"attrs": {
//														"1IMR8US3B0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IMR90II591",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IMR90II592",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IMR8US3B0",
//															"faceTagName": "entryOn"
//														},
//														"1I1D5774S0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IUVB7R1A178",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IUVB7R1A179",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I1D5774S0",
//															"faceTagName": "siteMenu"
//														},
//														"1IMR8V39V0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IUVB7R1A184",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IUVB7R1A185",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IMR8V39V0",
//															"faceTagName": "entryOff"
//														},
//														"1IUTA32CV0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVMJ6PDK44",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVMJ6PDK45",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IUTA32CV0",
//															"faceTagName": "online"
//														},
//														"1IVH6SHR30": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVMNKTM932",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVMNKTM933",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IVH6SHR30",
//															"faceTagName": "sidebarOn"
//														},
//														"1ILN7H5CK0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVMOBA2S8",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVMOBA2S9",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1ILN7H5CK0",
//															"faceTagName": "chat"
//														},
//														"1I1D5700V0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J04JIM612",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J04JIM613",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I1D5700V0",
//															"faceTagName": "sites"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I1UUF8SO1",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1I276Q38H0",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1I276Q38H1",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": "1I268LO9T0"
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1I1UUF8SO2",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1I1UUF8SO3",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1IUVB55T00",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IUVB5GRG0",
//													"attrs": {
//														"type": "hud",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "10",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": ""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IUVB5GRG1",
//													"attrs": {
//														"1I1D5774S0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IUVB7R1A188",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IUVB7R1A189",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I1D5774S0",
//															"faceTagName": "siteMenu"
//														},
//														"1IMR8US3B0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IUVB7R1A192",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IUVB7R1A193",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IMR8US3B0",
//															"faceTagName": "entryOn"
//														},
//														"1IMR8V39V0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IUVB7R1A196",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IUVB7R1A197",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IMR8V39V0",
//															"faceTagName": "entryOff"
//														},
//														"1IUTA32CV0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVMJ6PDK48",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVMJ6PDK49",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IUTA32CV0",
//															"faceTagName": "online"
//														},
//														"1IVH6SHR30": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVMNKTM934",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVMNKTM935",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IVH6SHR30",
//															"faceTagName": "sidebarOn"
//														},
//														"1ILN7H5CK0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVMOBA2S12",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVMOBA2S13",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1ILN7H5CK0",
//															"faceTagName": "chat"
//														},
//														"1I1D5700V0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J04JIM614",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J04JIM615",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I1D5700V0",
//															"faceTagName": "sites"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IUVB5GRG2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IUVB5GRG3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1ILND4KDN0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1ILND6SM40",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxChatList",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "10",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Auto Scroll Y",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[10,0,0,0]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex Y",
//														"flex": "true",
//														"subAlign": "Start"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1ILND6SM41",
//													"attrs": {
//														"1IMR8US3B0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IMR90II599",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IMR90II5100",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IMR8US3B0",
//															"faceTagName": "entryOn"
//														},
//														"1I1D5774S0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IUVB7R1A206",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IUVB7R1A207",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I1D5774S0",
//															"faceTagName": "siteMenu"
//														},
//														"1IMR8V39V0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IUVB7R1A212",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IUVB7R1A213",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IMR8V39V0",
//															"faceTagName": "entryOff"
//														},
//														"1IUTA32CV0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVMJ6PDK56",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVMJ6PDK57",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IUTA32CV0",
//															"faceTagName": "online"
//														},
//														"1IVH6SHR30": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVMNKTM938",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVMNKTM939",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IVH6SHR30",
//															"faceTagName": "sidebarOn"
//														},
//														"1ILN7H5CK0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVMOBA2S20",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVMOBA2S21",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1ILN7H5CK0",
//															"faceTagName": "chat"
//														},
//														"1I1D5700V0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J04JIM616",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J04JIM617",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I1D5700V0",
//															"faceTagName": "sites"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1ILND6SM42",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1ILND6SM43",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "true",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear1I1UT4SUC0",
//											"jaxId": "1I29MDBOI0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1I29MDBOI1",
//													"attrs": {
//														"icon": "qrcode.svg",
//														"text": "-",
//														"tip": {
//															"type": "string",
//															"valText": "Share System",
//															"localize": {
//																"EN": "Share System",
//																"CN": "分享系统"
//															},
//															"localizable": true
//														},
//														"tipSize": "#txtSize.smallPlus",
//														"tipIcon": ""
//													}
//												},
//												"properties": {
//													"jaxId": "1I29MDBOI2",
//													"attrs": {
//														"type": "#null#>BtnState(\"qrcode.svg\",\"-\",(($ln===\"CN\")?(\"分享系统\"):(\"Share System\")),txtSize.smallPlus,\"\")",
//														"id": "BtnShare",
//														"position": "Relative",
//														"x": "10%",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"anchorH": "Left",
//														"w": "80%",
//														"enable": "true"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I29MDBOJ0",
//													"attrs": {
//														"1I1D5700V0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I29MDBOJ1",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I29MDBOJ2",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I1D5700V0",
//															"faceTagName": "sites"
//														},
//														"1IMR8US3B0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IMR90II595",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IMR90II596",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IMR8US3B0",
//															"faceTagName": "entryOn"
//														},
//														"1I1D5774S0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IUVB7R1A198",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IUVB7R1A199",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I1D5774S0",
//															"faceTagName": "siteMenu"
//														},
//														"1IMR8V39V0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IUVB7R1A204",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IUVB7R1A205",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IMR8V39V0",
//															"faceTagName": "entryOff"
//														},
//														"1IUTA32CV0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVMJ6PDK52",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVMJ6PDK53",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IUTA32CV0",
//															"faceTagName": "online"
//														},
//														"1IVH6SHR30": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVMNKTM936",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVMNKTM937",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IVH6SHR30",
//															"faceTagName": "sidebarOn"
//														},
//														"1ILN7H5CK0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVMOBA2S16",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVMOBA2S17",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1ILN7H5CK0",
//															"faceTagName": "chat"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I29MDBOJ5",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1I29MDBOJ6",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1I29MDBOJ7",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": "1IUV8S9RE0"
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1I29MDBOJ8",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1I29MDBOJ9",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear1I1UT4SUC0",
//											"jaxId": "1J04JNPJK0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1J04JNPJK1",
//													"attrs": {
//														"icon": "store.svg",
//														"text": "-",
//														"tip": {
//															"type": "string",
//															"valText": "Agent Mart",
//															"localize": {
//																"EN": "Agent Mart",
//																"CN": "智能体超市"
//															},
//															"localizable": true
//														},
//														"tipSize": "#txtSize.smallPlus",
//														"tipIcon": "run.svg"
//													}
//												},
//												"properties": {
//													"jaxId": "1J04JNPJK2",
//													"attrs": {
//														"type": "#null#>BtnState(\"store.svg\",\"-\",(($ln===\"CN\")?(\"智能体超市\"):(\"Agent Mart\")),txtSize.smallPlus,\"run.svg\")",
//														"id": "BtnStore",
//														"position": "Relative",
//														"x": "10%",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"anchorH": "Left",
//														"w": "80%",
//														"enable": "true"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1J04JNPJK3",
//													"attrs": {
//														"1I1D5700V0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J04JNPJL0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J04JNPJL1",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I1D5700V0",
//															"faceTagName": "sites"
//														},
//														"1IMR8US3B0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J04JNPJL2",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J04JNPJL3",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IMR8US3B0",
//															"faceTagName": "entryOn"
//														},
//														"1I1D5774S0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J04JNPJL4",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J04JNPJL5",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I1D5774S0",
//															"faceTagName": "siteMenu"
//														},
//														"1IMR8V39V0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J04JNPJL6",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J04JNPJL7",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IMR8V39V0",
//															"faceTagName": "entryOff"
//														},
//														"1IUTA32CV0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J04JNPJL8",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J04JNPJL9",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IUTA32CV0",
//															"faceTagName": "online"
//														},
//														"1IVH6SHR30": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J04JNPJL10",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J04JNPJL11",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IVH6SHR30",
//															"faceTagName": "sidebarOn"
//														},
//														"1ILN7H5CK0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J04JNPJL12",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J04JNPJL13",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1ILN7H5CK0",
//															"faceTagName": "chat"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1J04JNPJL14",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1J04JNPJL15",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1J04JNPJL16",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": "1J0DG20FA0"
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1J04JNPJL17",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1J04JNPJL18",
//													"attrs": {}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1ILN0RFNG1",
//									"attrs": {
//										"1IMR8US3B0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IMR90II5103",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IMR90II5104",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IMR8US3B0",
//											"faceTagName": "entryOn"
//										},
//										"1I1D5774S0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IUVB7R1B0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IUVB7R1B1",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I1D5774S0",
//											"faceTagName": "siteMenu"
//										},
//										"1IMR8V39V0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IUVB7R1B6",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IUVB7R1B7",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IMR8V39V0",
//											"faceTagName": "entryOff"
//										},
//										"1IVH6SHR30": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IVH75IHG64",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IVH75IHG65",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IVH6SHR30",
//											"faceTagName": "sidebarOn"
//										},
//										"1IVH6TC9J0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IVH774J038",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IVH774J039",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IVH6TC9J0",
//											"faceTagName": "sidebarOff"
//										},
//										"1IUTA32CV0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IVMJ6PDK60",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IVMJ6PDK61",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IUTA32CV0",
//											"faceTagName": "online"
//										},
//										"1ILN7H5CK0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IVMOBA2S24",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IVMOBA2S25",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1ILN7H5CK0",
//											"faceTagName": "chat"
//										},
//										"1I1D5700V0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1J04JIM618",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J04JIM619",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I1D5700V0",
//											"faceTagName": "sites"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1ILN0RFNG2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1ILN0RFNG3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1IUTA4N0T0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IUTA8SR342",
//									"attrs": {
//										"type": "box",
//										"id": "BoxWait",
//										"position": "Absolute",
//										"x": "-250",
//										"y": "0",
//										"w": "100%+250",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "Off",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "0.9",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"body\"]",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1IUTAA9HF0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IUTAD9JL0",
//													"attrs": {
//														"type": "text",
//														"id": "TxtWait",
//														"position": "Absolute",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBody\"]",
//														"text": "Connecting to AI2Apps server...",
//														"font": "",
//														"fontSize": "#txtSize.bigPlus",
//														"bold": "true",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Center",
//														"alignV": "Center",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IUTAD9JL1",
//													"attrs": {
//														"1I1D5774S0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IUVB7R1B10",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IUVB7R1B11",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I1D5774S0",
//															"faceTagName": "siteMenu"
//														},
//														"1IMR8US3B0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IUVB7R1B14",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IUVB7R1B15",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IMR8US3B0",
//															"faceTagName": "entryOn"
//														},
//														"1IMR8V39V0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IUVB7R1B18",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IUVB7R1B19",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IMR8V39V0",
//															"faceTagName": "entryOff"
//														},
//														"1IUTA32CV0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVMJ6PDK62",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVMJ6PDK63",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IUTA32CV0",
//															"faceTagName": "online"
//														},
//														"1IVH6SHR30": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVMNKTM940",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVMNKTM941",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IVH6SHR30",
//															"faceTagName": "sidebarOn"
//														},
//														"1ILN7H5CK0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVMOBA2S26",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVMOBA2S27",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1ILN7H5CK0",
//															"faceTagName": "chat"
//														},
//														"1I1D5700V0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J04JIM6110",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J04JIM6111",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I1D5700V0",
//															"faceTagName": "sites"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IUTAD9JL2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IUTAD9JL3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1IUTA8SR343",
//									"attrs": {
//										"1IUTA2UGH0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IUTA9C5B2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IUTA9C5B3",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IUTA2UGH0",
//											"faceTagName": "offline"
//										},
//										"1IUTA32CV0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IUTA9C5B4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IUTA9C5B5",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IUTA32CV0",
//											"faceTagName": "online"
//										},
//										"1I1D5774S0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IUVB7R1B22",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IUVB7R1B23",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I1D5774S0",
//											"faceTagName": "siteMenu"
//										},
//										"1IMR8US3B0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IUVB7R1B26",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IUVB7R1B27",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IMR8US3B0",
//											"faceTagName": "entryOn"
//										},
//										"1IMR8V39V0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IUVB7R1B28",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IUVB7R1B29",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IMR8V39V0",
//											"faceTagName": "entryOff"
//										},
//										"1IVH6SHR30": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IVMNKTM942",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IVMNKTM943",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IVH6SHR30",
//											"faceTagName": "sidebarOn"
//										},
//										"1ILN7H5CK0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IVMOBA2S30",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IVMOBA2S31",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1ILN7H5CK0",
//											"faceTagName": "chat"
//										},
//										"1I1D5700V0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1J04JIM6112",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J04JIM6113",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I1D5700V0",
//											"faceTagName": "sites"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1IUTA8SR344",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IUTA8SR345",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "true",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1I10E3UB90",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I10E5VED0",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxHeader",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "[0,5,0,5]",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex X",
//										"itemsAlign": "Center",
//										"subAlign": "Start"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1IVMFUCR40",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IVMG2IED0",
//													"attrs": {
//														"type": "box",
//														"id": "BoxHeaderBG",
//														"position": "Absolute",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "Off",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "#cfgColor[\"tool\"]",
//														"border": "0",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IVMG2IED1",
//													"attrs": {
//														"1I1D5700V0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVMG2IED2",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVMG2IED3",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I1D5700V0",
//															"faceTagName": "sites"
//														},
//														"1ILN7H5CK0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVMG2IED4",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVMG2IED5",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1ILN7H5CK0",
//															"faceTagName": "chat"
//														},
//														"1IUTA32CV0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVMJ6PDK68",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVMJ6PDK69",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IUTA32CV0",
//															"faceTagName": "online"
//														},
//														"1IVH6SHR30": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVMNKTM944",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVMNKTM945",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IVH6SHR30",
//															"faceTagName": "sidebarOn"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IVMG2IED6",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IVMG2IED7",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1IVMCCT6J0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IVMCE42O0",
//													"attrs": {
//														"type": "box",
//														"id": "BoxChatShadow",
//														"position": "Absolute",
//														"x": "0",
//														"y": "100%",
//														"w": "100%",
//														"h": "1",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "linear-gradient(to right, rgba(0,0,0,0.5),rgba(0,0,0,0.1), rgba(0,0,0,0))",
//														"border": "0",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IVMCE42O1",
//													"attrs": {
//														"1I1D5700V0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVMF1FJ626",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVMF1FJ627",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I1D5700V0",
//															"faceTagName": "sites"
//														},
//														"1ILN7H5CK0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVMF1FJ628",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVMF1FJ629",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1ILN7H5CK0",
//															"faceTagName": "chat"
//														},
//														"1I1D5774S0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVMF1FJ630",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVMF1FJ631",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I1D5774S0",
//															"faceTagName": "siteMenu"
//														},
//														"1IUTA32CV0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVMJ6PDK72",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVMJ6PDK73",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IUTA32CV0",
//															"faceTagName": "online"
//														},
//														"1IVH6SHR30": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVMNKTMA0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVMNKTMA1",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IVH6SHR30",
//															"faceTagName": "sidebarOn"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IVMCE42O2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IVMCE42O3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1IVMNN6RP0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IVMNN6RP1",
//													"attrs": {
//														"type": "box",
//														"id": "BoxGap",
//														"position": "Absolute",
//														"x": "-1",
//														"y": "5",
//														"w": "1",
//														"h": "100%-10",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "Off",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "#cfgColor[\"fontBodySub\"]",
//														"border": "0",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IVMNN6RP2",
//													"attrs": {
//														"1I1D5700V0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVMNN6RP3",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVMNN6RQ0",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I1D5700V0",
//															"faceTagName": "sites"
//														},
//														"1ILN7H5CK0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVMNN6RQ1",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVMNN6RQ2",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1ILN7H5CK0",
//															"faceTagName": "chat"
//														},
//														"1IUTA32CV0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVMNN6RQ3",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVMNN6RQ4",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IUTA32CV0",
//															"faceTagName": "online"
//														},
//														"1IVH6SHR30": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVMNN6RQ5",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVMNN6RQ6",
//																	"attrs": {
//																		"alpha": {
//																			"type": "number",
//																			"valText": "1",
//																			"editMode": "range",
//																			"editType": "range"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IVH6SHR30",
//															"faceTagName": "sidebarOn"
//														},
//														"1IVH6TC9J0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVMOBA2S38",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVMOBA2S39",
//																	"attrs": {
//																		"alpha": {
//																			"type": "number",
//																			"valText": "0.00",
//																			"editMode": "range",
//																			"editType": "range"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IVH6TC9J0",
//															"faceTagName": "sidebarOff"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IVMNN6RQ7",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IVMNN6RQ8",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1IVH7QFMI0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1IVH7URL10",
//													"attrs": {
//														"style": "\"front\"",
//														"w": "28",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/uileft.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1IVH7URL11",
//													"attrs": {
//														"type": "#null#>BtnIcon(\"front\",28,0,appCfg.sharedAssets+\"/uileft.svg\",null)",
//														"id": "BtnShowSideBar",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "Off",
//														"face": ""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IVH7URL12",
//													"attrs": {
//														"1IVH6SHR30": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVMBUOUO0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVMBUOUO1",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IVH6SHR30",
//															"faceTagName": "sidebarOn"
//														},
//														"1IVH6TC9J0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVMBUOUO2",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVMBUOUO3",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IVH6TC9J0",
//															"faceTagName": "sidebarOff"
//														},
//														"1I1D5774S0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVMF1FJ636",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVMF1FJ637",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I1D5774S0",
//															"faceTagName": "siteMenu"
//														},
//														"1IUTA32CV0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVMJ6PDK76",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVMJ6PDK77",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IUTA32CV0",
//															"faceTagName": "online"
//														},
//														"1ILN7H5CK0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVMOBA2S40",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVMOBA2S41",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1ILN7H5CK0",
//															"faceTagName": "chat"
//														},
//														"1I1D5700V0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J04JIM6114",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J04JIM6115",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I1D5700V0",
//															"faceTagName": "sites"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IVH7URL13",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1IVMJ5ADA0",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1IVMJ5ADA1",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": "1IVMIS82D0"
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1IVH7URL14",
//													"attrs": {
//														"tip": {
//															"type": "string",
//															"valText": "Show sidebar",
//															"localize": {
//																"EN": "Show sidebar",
//																"CN": "显示边栏"
//															},
//															"localizable": true
//														}
//													}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1IVH7URL15",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1IVMJPUGG0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1IVMJPUGG1",
//													"attrs": {
//														"style": "\"front\"",
//														"w": "28",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/chat_add.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1IVMJPUGG2",
//													"attrs": {
//														"type": "#null#>BtnIcon(\"front\",28,0,appCfg.sharedAssets+\"/chat_add.svg\",null)",
//														"id": "BtnNewChat2",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "Off",
//														"face": "",
//														"margin": "[0,0,0,10]"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IVMJPUGG3",
//													"attrs": {
//														"1IVH6SHR30": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVMJPUGG4",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVMJPUGG5",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IVH6SHR30",
//															"faceTagName": "sidebarOn"
//														},
//														"1IVH6TC9J0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVMJPUGG6",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVMJPUGG7",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IVH6TC9J0",
//															"faceTagName": "sidebarOff"
//														},
//														"1I1D5774S0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVMJPUGH0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVMJPUGH1",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I1D5774S0",
//															"faceTagName": "siteMenu"
//														},
//														"1IUTA32CV0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVMJPUGH2",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVMJPUGH3",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IUTA32CV0",
//															"faceTagName": "online"
//														},
//														"1ILN7H5CK0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVMOBA2S42",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVMOBA2S43",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1ILN7H5CK0",
//															"faceTagName": "chat"
//														},
//														"1I1D5700V0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J04JIM6116",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J04JIM6117",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I1D5700V0",
//															"faceTagName": "sites"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IVMJPUGH4",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1IVMJPUGH5",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1IVMJPUGH6",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1IVMJPUGH7",
//													"attrs": {
//														"tip": {
//															"type": "string",
//															"valText": "New conversation",
//															"localize": {
//																"EN": "New conversation",
//																"CN": "新对话"
//															},
//															"localizable": true
//														}
//													}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1IVMJPUGH8",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1IVMD2MB00",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IVMD31C90",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxTokenGas",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "10",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[0,0,0,10]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"flex": "true",
//														"contentLayout": "Flex X",
//														"itemsAlign": "Center"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1ILOCUCU70",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1ILOCUCU71",
//																	"attrs": {
//																		"style": "\"front\"",
//																		"w": "20",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/token.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1ILOCUCU72",
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"front\",20,0,appCfg.sharedAssets+\"/token.svg\",null)",
//																		"id": "BtnAddGas",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"margin": "0"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1ILOCUCU73",
//																	"attrs": {
//																		"1IMR8US3B0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IMR90II551",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IMR90II552",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IMR8US3B0",
//																			"faceTagName": "entryOn"
//																		},
//																		"1I1D5774S0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IUVB7R1A106",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IUVB7R1A107",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I1D5774S0",
//																			"faceTagName": "siteMenu"
//																		},
//																		"1IMR8V39V0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IUVB7R1A112",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IUVB7R1A113",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IMR8V39V0",
//																			"faceTagName": "entryOff"
//																		},
//																		"1IUTA32CV0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVMJ6PDK0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVMJ6PDK1",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IUTA32CV0",
//																			"faceTagName": "online"
//																		},
//																		"1IVH6SHR30": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVMNKTMA2",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVMNKTMA3",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IVH6SHR30",
//																			"faceTagName": "sidebarOn"
//																		},
//																		"1ILN7H5CK0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVMOBA2S44",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVMOBA2S45",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1ILN7H5CK0",
//																			"faceTagName": "chat"
//																		},
//																		"1I1D5700V0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J04JIM6118",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J04JIM6119",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I1D5700V0",
//																			"faceTagName": "sites"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1ILOCUCU74",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1ILOD48FJ0",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1ILOD48FJ1",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": "1ILOD24FL0"
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1ILOCUCU75",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1ILOCUCU76",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1ILOCJ1CA0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1ILOCJ1CA1",
//																	"attrs": {
//																		"type": "text",
//																		"id": "TxtToken",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "20",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontBody\"]",
//																		"text": "-",
//																		"font": "",
//																		"fontSize": "#txtSize.smallPlus",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Center",
//																		"alignV": "Top",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"lineClamp": "0",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1ILOCJ1CB0",
//																	"attrs": {
//																		"1IMR8US3B0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IMR90II555",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IMR90II556",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IMR8US3B0",
//																			"faceTagName": "entryOn"
//																		},
//																		"1I1D5774S0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IUVB7R1A114",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IUVB7R1A115",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I1D5774S0",
//																			"faceTagName": "siteMenu"
//																		},
//																		"1IMR8V39V0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IUVB7R1A120",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IUVB7R1A121",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IMR8V39V0",
//																			"faceTagName": "entryOff"
//																		},
//																		"1IUTA32CV0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVMJ6PDK4",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVMJ6PDK5",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IUTA32CV0",
//																			"faceTagName": "online"
//																		},
//																		"1IVH6SHR30": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVMNKTMA4",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVMNKTMA5",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IVH6SHR30",
//																			"faceTagName": "sidebarOn"
//																		},
//																		"1ILN7H5CK0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVMOBA2S48",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVMOBA2S49",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1ILN7H5CK0",
//																			"faceTagName": "chat"
//																		},
//																		"1I1D5700V0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J04JIM6120",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J04JIM6121",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I1D5700V0",
//																			"faceTagName": "sites"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1ILOCJ1CB1",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1ILOCJ1CB2",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1ILOCT8VV0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1ILOCU8M70",
//																	"attrs": {
//																		"style": "\"front\"",
//																		"w": "20",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/gas.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1ILOCU8M71",
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"front\",20,0,appCfg.sharedAssets+\"/gas.svg\",null)",
//																		"id": "BtnAddGas",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"margin": "[0,0,0,10]"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1ILOCU8M72",
//																	"attrs": {
//																		"1IMR8US3B0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IMR90II559",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IMR90II560",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IMR8US3B0",
//																			"faceTagName": "entryOn"
//																		},
//																		"1I1D5774S0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IUVB7R1A122",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IUVB7R1A123",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I1D5774S0",
//																			"faceTagName": "siteMenu"
//																		},
//																		"1IMR8V39V0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IUVB7R1A128",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IUVB7R1A129",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IMR8V39V0",
//																			"faceTagName": "entryOff"
//																		},
//																		"1IUTA32CV0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVMJ6PDK8",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVMJ6PDK9",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IUTA32CV0",
//																			"faceTagName": "online"
//																		},
//																		"1IVH6SHR30": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVMNKTMA6",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVMNKTMA7",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IVH6SHR30",
//																			"faceTagName": "sidebarOn"
//																		},
//																		"1ILN7H5CK0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVMOBA2S52",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVMOBA2S53",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1ILN7H5CK0",
//																			"faceTagName": "chat"
//																		},
//																		"1I1D5700V0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J04JIM6122",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J04JIM6123",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I1D5700V0",
//																			"faceTagName": "sites"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1ILOCU8M73",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1ILOD48FJ2",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1ILOD48FJ3",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": "1ILOD24FL0"
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1ILOCU8M74",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1ILOCU8M80",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1ILOCHRG80",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1ILOCIVPG0",
//																	"attrs": {
//																		"type": "text",
//																		"id": "TxtGas",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "20",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontBody\"]",
//																		"text": "-",
//																		"font": "",
//																		"fontSize": "#txtSize.smallPlus",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Center",
//																		"alignV": "Top",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"lineClamp": "0",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1ILOCIVPG1",
//																	"attrs": {
//																		"1IMR8US3B0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IMR90II563",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IMR90II564",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IMR8US3B0",
//																			"faceTagName": "entryOn"
//																		},
//																		"1I1D5774S0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IUVB7R1A130",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IUVB7R1A131",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I1D5774S0",
//																			"faceTagName": "siteMenu"
//																		},
//																		"1IMR8V39V0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IUVB7R1A136",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IUVB7R1A137",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IMR8V39V0",
//																			"faceTagName": "entryOff"
//																		},
//																		"1IUTA32CV0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVMJ6PDK12",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVMJ6PDK13",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IUTA32CV0",
//																			"faceTagName": "online"
//																		},
//																		"1IVH6SHR30": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVMNKTMA8",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVMNKTMA9",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IVH6SHR30",
//																			"faceTagName": "sidebarOn"
//																		},
//																		"1ILN7H5CK0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVMOBA2S56",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVMOBA2S57",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1ILN7H5CK0",
//																			"faceTagName": "chat"
//																		},
//																		"1I1D5700V0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J04JIM6124",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J04JIM6125",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I1D5700V0",
//																			"faceTagName": "sites"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1ILOCIVPG2",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1ILOCIVPG3",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true"
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1IVMD31CA0",
//													"attrs": {
//														"1I1D5774S0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVMF1FJ648",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVMF1FJ649",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I1D5774S0",
//															"faceTagName": "siteMenu"
//														},
//														"1IUTA32CV0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVMJ6PDK16",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVMJ6PDK17",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IUTA32CV0",
//															"faceTagName": "online"
//														},
//														"1IVH6SHR30": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVMNKTMA10",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVMNKTMA11",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IVH6SHR30",
//															"faceTagName": "sidebarOn"
//														},
//														"1ILN7H5CK0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVMOBA2S60",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVMOBA2S61",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1ILN7H5CK0",
//															"faceTagName": "chat"
//														},
//														"1I1D5700V0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J04JIM6126",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J04JIM6127",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I1D5700V0",
//															"faceTagName": "sites"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IVMD31CA1",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IVMD31CA2",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "true",
//												"exposeContainer": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1I10E5VED7",
//									"attrs": {
//										"1I1D5700V0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1ILN5JB7F2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1ILN5JB7F3",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I1D5700V0",
//											"faceTagName": "sites"
//										},
//										"1I1D5774S0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1ILN7IHKQ3",
//											"attrs": {
//												"properties": {
//													"jaxId": "1ILN7IHKQ4",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I1D5774S0",
//											"faceTagName": "siteMenu"
//										},
//										"1IMR8US3B0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IMR90II46",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IMR90II47",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IMR8US3B0",
//											"faceTagName": "entryOn"
//										},
//										"1IMR8V39V0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IUVB7R1912",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IUVB7R1913",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IMR8V39V0",
//											"faceTagName": "entryOff"
//										},
//										"1IUTA32CV0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IVMJ6PDK78",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IVMJ6PDK79",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IUTA32CV0",
//											"faceTagName": "online"
//										},
//										"1IVH6SHR30": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IVMNKTMA12",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IVMNKTMA13",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IVH6SHR30",
//											"faceTagName": "sidebarOn"
//										},
//										"1ILN7H5CK0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IVMOBA2S64",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IVMOBA2S65",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1ILN7H5CK0",
//											"faceTagName": "chat"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1I10E5VED8",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1I10E5VED9",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1I10E0NR30",
//					"attrs": {
//						"1IMR8US3B0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1IMR90II5107",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IMR90II5108",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1IMR8US3B0",
//							"faceTagName": "entryOn"
//						},
//						"1I1D5774S0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1IUVB7R1B30",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IUVB7R1B31",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1I1D5774S0",
//							"faceTagName": "siteMenu"
//						},
//						"1IMR8V39V0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1IUVB7R1B36",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IUVB7R1B37",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1IMR8V39V0",
//							"faceTagName": "entryOff"
//						},
//						"1IVH6SHR30": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1IVH75IHG70",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IVH75IHG71",
//									"attrs": {
//										"x": {
//											"type": "length",
//											"valText": "${state.naviBoxW+50},state"
//										},
//										"w": {
//											"type": "length",
//											"valText": "100%-300"
//										}
//									}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1IVH6SHR30",
//							"faceTagName": "sidebarOn"
//						},
//						"1IVH6TC9J0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1IVH774J044",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IVH774J045",
//									"attrs": {
//										"x": {
//											"type": "length",
//											"valText": "50"
//										},
//										"w": {
//											"type": "length",
//											"valText": "100%-50"
//										}
//									}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1IVH6TC9J0",
//							"faceTagName": "sidebarOff"
//						},
//						"1IUTA32CV0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1IVMJ6PDK82",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IVMJ6PDK83",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1IUTA32CV0",
//							"faceTagName": "online"
//						},
//						"1ILN7H5CK0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1IVMOBA2S68",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IVMOBA2S69",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1ILN7H5CK0",
//							"faceTagName": "chat"
//						},
//						"1I1D5700V0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1J04JIM6128",
//							"attrs": {
//								"properties": {
//									"jaxId": "1J04JIM6129",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1I1D5700V0",
//							"faceTagName": "sites"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1I10E0NR31",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1I10E0NR32",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1I10E0NR33",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}