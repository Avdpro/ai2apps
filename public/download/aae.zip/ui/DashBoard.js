//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
import {BtnState} from "./BtnState.js";
import {BtnText} from "/@StdUI/ui/BtnText.js";
import {BoxGroup} from "./BoxGroup.js";
import {BoxTool} from "./BoxTool.js";
/*#{1I10E0NR20StartDoc*/
import {AppLib} from "/@homekit/data/AppLib.js";
import pathLib from "/@path";
import {tabFS,tabNT} from "/@tabos";
import {AAFarm} from "../aafarm.js";
import {AATools} from "/@tabos/AATools.js";
import {AABots} from "../AABots.js";
import {AgentHub} from "../AgentHub.js";
import {} from "../data/AppData.js";
import {BoxBot} from "./BoxBot.js";
import {runAgent} from "/@AgentBuilder/ai/RunAgent.js";

const agentURL=(new URL(import.meta.url)).pathname;
const basePath=pathLib.dirname(agentURL);
//----------------------------------------------------------------------------
function randomTag(digit=6,time=true){
	const characters = 'abcdefghijklmnopqrstuvwxyz0123456789';
	let result = '';
	const charactersLength = characters.length;
	if(time){
		time=""+Date.now();
		time=time.substring(time.length-6);
	}
	for (let i = 0; i < digit; i++) {
		result += characters.charAt(Math.floor(Math.random() * charactersLength));
	}
	return "$"+result+time;
};
/*}#1I10E0NR20StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let DashBoard=function(){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let btnBot,txtBrowserAlias,imgLogo,btnStateBots,btnStateTool,btnStateChain,btnMessages,btnSendCmd,edCommand,txtInputTip,btnRunTask,btnCreateTool,boxGroups,boxGroupMenu,boxGroupHeader,txtGroupName,btnGroupMenu,boxGroupItems;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1I10E0NR21LocalVals*/
	const app=VFACT.app;
	let toolsIndex=null;
	let tools=new AATools();
	let agentHub=new AgentHub(app);
	let curGroup=null;
	let appTools=tools;
	let appBots=new AABots();
	let willSaveTools=false;
	/*}#1I10E0NR21LocalVals*/
	
	/*#{1I10E0NR21PreState*/
	/*}#1I10E0NR21PreState*/
	/*#{1I10E0NR21PostState*/
	/*}#1I10E0NR21PostState*/
	cssVO={
		"hash":"1I10E0NR21",nameHost:true,
		"type":"view","x":"50%","y":0,"w":">calc(100% - 50px)","h":"100%","anchorX":1,"padding":10,"minW":"","minH":"","maxW":1000,"maxH":"","styleClass":"",
		"contentLayout":"flex-y","itemsAlign":1,
		children:[
			{
				"hash":"1I10E3UB90",
				"type":"hud","id":"BoxHeader","position":"relative","x":0,"y":0,"w":"100%","h":30,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
				"itemsAlign":1,"subAlign":2,
				children:[
					{
						"hash":"1I10ECJ960",
						"type":"text","position":"relative","x":0,"y":0,"w":100,"h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodySub"],
						"text":(($ln==="CN")?("强大的AI智能体，超级网页自动化，听候您的调遣"):("Powerful AI agent, super web automation, at your command")),"fontSize":txtSize.mid,"fontWeight":"bold",
						"fontStyle":"normal","textDecoration":"","alignH":1,"alignV":1,"flex":true,
					},
					{
						"hash":"1I121UDDO0",
						"type":BtnIcon("front",30,0,appCfg.sharedAssets+"/agent.svg",null),"id":"BtnBot","position":"relative","x":15,"y":15,"display":0,"cursor":"pointer",
						"margin":[0,5,0,0],"anchorX":1,"anchorY":1,
						"tip":(($ln==="CN")?("当前工仔"):("Current Bot")),
					},
					{
						"hash":"1I121VNAK0",
						"type":"text","id":"TxtBrowserAlias","position":"relative","x":0,"y":"50%","w":"","h":"100%","anchorY":1,"display":0,"cursor":"pointer","margin":[0,10,0,0],
						"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],"text":"- - - - -","fontWeight":"bold","fontStyle":"normal",
						"textDecoration":"underline","alignV":1,
					},
					{
						"hash":"1I10E4MUE0",
						"type":BtnIcon("front",30,0,appCfg.sharedAssets+"/settings.svg",null),"id":"BtnCfg","position":"relative","x":0,"y":0,"display":0,"cursor":"pointer",
					}
				],
			},
			{
				"hash":"1I10E9V2M0",
				"type":"text","position":"relative","x":0,"y":0,"w":"100%","h":"","display":0,"margin":[0,0,50,0],"padding":[0,0,0,0],"minW":"","minH":"","maxW":"",
				"maxH":"","styleClass":"","color":cfgColor["fontBodyLit"],"text":"www.ai2apps.com","fontSize":txtSize.smallPlus,"fontWeight":"bold","fontStyle":"normal",
				"textDecoration":"","alignH":1,
			},
			{
				"hash":"1I1US7JF80",
				"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":240,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
				"itemsAlign":1,
				children:[
					{
						"hash":"1I1USB7L80",
						"type":"hud","position":"relative","x":0,"y":0,"w":">calc(50% - 40px)","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
					},
					{
						"hash":"1I1USCCFA0",
						"type":"image","id":"ImgLogo","position":"relative","x":40,"y":40,"w":80,"h":80,"anchorX":1,"anchorY":1,"minW":"","minH":"","maxW":"","maxH":"",
						"styleClass":"","image":appCfg.sharedAssets+"/aalogo.svg","fitSize":true,
					},
					{
						"hash":"1I1USDRD10",
						"type":"hud","position":"relative","x":0,"y":0,"w":">calc(50% - 40px)","h":"100%","padding":10,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						"contentLayout":"flex-y",
						children:[
							{
								"hash":"1I2B3HVI30",
								"type":BtnState("agent.svg","-",(($ln==="CN")?("工仔群"):("Bots Workgroup"))),"id":"BtnStateBots","position":"relative","x":"100%","y":0,"anchorX":2,
								"OnClick":function(event){
									self.showBots(this,event);
								},
							},
							{
								"hash":"1I1UU28N70",
								"type":BtnState("appdata.svg","-",(($ln==="CN")?("工具管理"):("Tool management"))),"id":"BtnStateTool","position":"relative","x":"100%","y":0,"anchorX":2,
								"OnClick":function(event){
									self.showAllTools(this,event);
								},
							},
							{
								"hash":"1I1UUF8SN0",
								"type":BtnState("skillchain.svg","-",(($ln==="CN")?("工具链管理"):("Tool Chain Management"))),"id":"BtnStateChain","position":"relative","x":"100%",
								"y":0,"anchorX":2,
								"OnClick":function(event){
									self.showAllChains(this,event);
								},
							},
							{
								"hash":"1I29MDBOI0",
								"type":BtnState("mail.svg","-",(($ln==="CN")?("消息"):("Messages"))),"id":"BtnMessages","position":"relative","x":"100%","y":0,"anchorX":2,
								"OnClick":function(event){
									self.showAllChains(this,event);
								},
							}
						],
					}
				],
			},
			{
				"hash":"1I10EHPSR0",
				"type":"box","id":"BoxInput","position":"relative","x":0,"y":0,"w":"60%","h":"","margin":[20,0,0,0],"padding":[5,10,5,10],"minW":"","minH":40,"maxW":800,
				"maxH":"","styleClass":"","background":cfgColor["chatInputBG"],"borderColor":cfgColor["fontBodyLit"],"corner":32,"shadowX":0,"shadowColor":[0,0,0,0.2],
				"contentLayout":"flex-x","itemsAlign":2,"subAlign":1,
				children:[
					{
						"hash":"1I1HHL2Q00",
						"type":BtnIcon("front",30,0,appCfg.sharedAssets+"/menu.svg",null),"id":"BtnSendCmd","position":"relative","x":0,"y":0,"margin":[0,5,0,0],
						"OnClick":function(event){
							self.showMenu(this,event);
						},
					},
					{
						"hash":"1I1M5M3QT0",
						"type":"memo","id":"EdCommand","position":"relative","x":0,"y":0,"w":">calc(100% - 70px)","h":"","minW":"","minH":30,"maxW":"","maxH":200,"styleClass":"",
						"color":cfgColor["fontBody"],"background":[255,255,255,0],"outline":0,"border":[0,0,1,0],"borderColor":cfgColor["fontBodyLit"],
						"OnInput":function(){
							/*#{1I1M64K3N0FunctionBody*/
							txtInputTip.display=!this.text;
							btnSendCmd.enable=!!this.text;
							/*}#1I1M64K3N0FunctionBody*/
						},
						"OnKeyDown":function(event){
							/*#{1I1M64K3N1FunctionBody*/
							if(event.code==="Enter"){
								if((!event.isComposing) &&(!event.shiftKey)){
									event.stopPropagation();
									event.preventDefault();
									self.runCommand();
								}
							}
							/*}#1I1M64K3N1FunctionBody*/
						},
					},
					{
						"hash":"1I1M69F3G0",
						"type":"text","id":"TxtInputTip","x":52,"y":0,"w":"","h":"100%","uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodyLit"],
						"text":(($ln==="CN")?("给出你的指令..."):("Make your command...")),"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,
					},
					{
						"hash":"1I10EONLD0",
						"type":BtnIcon("front",30,0,appCfg.sharedAssets+"/send.svg",null),"id":"BtnSendCmd","position":"relative","x":0,"y":0,"padding":3,"margin":[0,0,0,3],
						"enable":false,
						"OnClick":function(event){
							self.runCommand(this,event);
						},
					}
				],
			},
			{
				"hash":"1I11BTJ790",
				"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":"","display":0,"margin":[30,0,15,0],"padding":[0,10,0,10],"minW":"","minH":"","maxW":"",
				"maxH":"","styleClass":"","contentLayout":"flex-x","itemsWrap":1,"itemsAlign":1,"subAlign":1,
				children:[
					{
						"hash":"1I11CBT0C0",
						"type":BtnText("secondary",150,28,"Execute Task",true,appCfg.sharedAssets+"/run.svg"),"id":"BtnRunTask","position":"relative","x":0,"y":0,"margin":[0,10,0,10],
						"enable":false,
					},
					{
						"hash":"1I11BUR250",
						"type":BtnText("secondary",150,28,"Create a Tool",true,appCfg.sharedAssets+"/additem.svg"),"id":"BtnCreateTool","position":"relative","x":0,"y":0,
						"margin":[0,10,0,10],"padding":0,
						"OnClick":function(event){
							self.createTool(this,event);
						},
					},
					{
						"hash":"1I11C3IL90",
						"type":BtnText("secondary",150,28,"Tool Hub",true,appCfg.sharedAssets+"/cloud.svg"),"id":"BtnToolHub","position":"relative","x":0,"y":0,"margin":[0,10,0,10],
						"padding":[0,3,0,0],"enable":false,
					}
				],
			},
			{
				"hash":"1I11DDGM90",
				"type":"hud","id":"BoxContents","position":"relative","x":"50%","y":0,"w":"100%","h":100,"anchorX":1,"overflow":"auto-y","margin":20,"padding":[20,50,20,50],
				"minW":"","minH":"","maxW":"","maxH":360,"styleClass":"","flex":true,"itemsWrap":1,"subAlign":1,
				children:[
					{
						"hash":"1I19QVP9T0",
						"type":"hud","id":"BoxGroups","x":50,"y":0,"w":">calc(100% - 100px)","h":"","display":0,"overflow":"auto-y","padding":10,"minW":"","minH":"","maxW":"",
						"maxH":"","styleClass":"","contentLayout":"flex-x","subAlign":1,"itemsAlign":1,"itemsWrap":1,
						children:[
						],
					},
					{
						"hash":"1I1D4M7EH0",
						"type":"hud","id":"BoxGroupMenu","x":50,"y":0,"w":">calc(100% - 100px)","h":"","overflow":"auto-y","padding":5,"minW":"","minH":"","maxW":"","maxH":"",
						"styleClass":"","contentLayout":"flex-y",
						children:[
							{
								"hash":"1I1D525QM0",
								"type":"hud","id":"BoxGroupHeader","position":"relative","x":0,"y":0,"w":"100%","h":30,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
								"contentLayout":"flex-x",
								children:[
									{
										"hash":"1I1D52KLM0",
										"type":BtnIcon("front",30,0,appCfg.sharedAssets+"/arrowleft.svg",null),"id":"BtnCloseSiteMenu","position":"relative","x":0,"y":0,"margin":[0,5,0,0],
										"tip":(($ln==="CN")?("返回"):("Back")),
										"OnClick":function(event){
											self.closeSiteMenu(this,event);
										},
									},
									{
										"hash":"1I1D549G80",
										"type":"text","id":"TxtGroupName","position":"relative","x":0,"y":-10,"w":"","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
										"color":cfgColor["fontBodySub"],"text":"www.google.com","fontSize":txtSize.bigPlus,"fontWeight":"bold","fontStyle":"normal","textDecoration":"",
										"alignH":1,"flex":true,
									},
									{
										"hash":"1I1QBHS2K0",
										"type":BtnIcon("front",30,0,appCfg.sharedAssets+"/menu.svg",null),"id":"BtnGroupMenu","position":"relative","x":0,"y":0,"margin":[0,5,0,0],
										"tip":(($ln==="CN")?("选项"):("Options")),
										"OnClick":function(event){
											self.showGroupMenu(this,event);
										},
									}
								],
							},
							{
								"hash":"1I1D4RN860",
								"type":"hud","id":"BoxGroupItems","position":"relative","x":30,"y":0,"w":">calc(100% - 60px)","h":"","padding":[5,0,5,0],"minW":"","minH":"","maxW":"",
								"maxH":"","styleClass":"","contentLayout":"flex-x","itemsWrap":1,"subAlign":1,
								children:[
								],
							}
						],
					}
				],
			}
		],
		/*#{1I10E0NR21ExtraCSS*/
		/*}#1I10E0NR21ExtraCSS*/
		faces:{
			"sites":{
				/*BtnStateBots*/"#1I2B3HVI30":{
					"display":1
				},
				/*BtnStateTool*/"#1I1UU28N70":{
					"display":1
				},
				/*BtnStateChain*/"#1I1UUF8SN0":{
					"display":1
				},
				/*BtnMessages*/"#1I29MDBOI0":{
					"display":1
				},
				/*BoxInput*/"#1I10EHPSR0":{
					"display":1
				},
				/*BoxGroups*/"#1I19QVP9T0":{
					"display":1
				},
				/*BoxGroupMenu*/"#1I1D4M7EH0":{
					"display":0
				}
			},"siteMenu":{
				/*BtnStateBots*/"#1I2B3HVI30":{
					"display":0
				},
				/*BtnStateTool*/"#1I1UU28N70":{
					"display":0
				},
				/*BtnStateChain*/"#1I1UUF8SN0":{
					"display":0
				},
				/*BtnMessages*/"#1I29MDBOI0":{
					"display":0
				},
				/*BoxInput*/"#1I10EHPSR0":{
					"display":0
				},
				/*BoxGroups*/"#1I19QVP9T0":{
					"display":0
				},
				/*BoxGroupMenu*/"#1I1D4M7EH0":{
					"display":1
				}
			}
		},
		OnCreate:function(){
			self=this;
			btnBot=self.BtnBot;txtBrowserAlias=self.TxtBrowserAlias;imgLogo=self.ImgLogo;btnStateBots=self.BtnStateBots;btnStateTool=self.BtnStateTool;btnStateChain=self.BtnStateChain;btnMessages=self.BtnMessages;btnSendCmd=self.BtnSendCmd;edCommand=self.EdCommand;txtInputTip=self.TxtInputTip;btnSendCmd=self.BtnSendCmd;btnRunTask=self.BtnRunTask;btnCreateTool=self.BtnCreateTool;boxGroups=self.BoxGroups;boxGroupMenu=self.BoxGroupMenu;boxGroupHeader=self.BoxGroupHeader;txtGroupName=self.TxtGroupName;btnGroupMenu=self.BtnGroupMenu;boxGroupItems=self.BoxGroupItems;
			/*#{1I10E0NR21Create*/
			self.showFace("sites");
			self.readIndex();
			app.on("ToolsChanged",self.maybeSaveTools);
			app.on("ToolsChanged",self.listTools);
			/*}#1I10E0NR21Create*/
		},
		/*#{1I10E0NR21EndCSS*/
		/*}#1I10E0NR21EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.readIndex=async function(){
		/*#{1I1C1K57N0Start*/
		let path,label,listJson;
		try{
			await tools.load();
		}catch(err){
			console.error(err);
		}
		callAfter(()=>{edCommand.focus();});
		await self.listTools();
		//Get browser alias:
		{
			let tag,oldTitle,doc,res,alias;
			alias=await AAFarm.getLocalAlias();
			if(alias){
				btnBot.display=true;
				txtBrowserAlias.display=true;
				txtBrowserAlias.text=alias;
				btnBot.animate({type:"in",scale:0.8,alpha:0.5,time:150});
				txtBrowserAlias.animate({type:"in",scale:0.5,alpha:0.0,time:150});
			}else{
				txtBrowserAlias.display=false;
				txtBrowserAlias.text="? ? ?";
			}
		}
		/*}#1I1C1K57N0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.listTools=async function(){
		/*#{1I1C1JAVP0Start*/
		let groups,siteName,group,siteVO,css;
		boxGroups.clearChildren();
		groups=tools.getGroups();
		for(group of groups){
			css={
				type:BoxGroup(group),position:"relative",group:group,
				OnClick(){
					self.showGroup(this.group);
				}
			};
			boxGroups.appendNewChild(css);
		}
		//Sites:
		groups=tools.getSites();
		for(group of groups){
			css={
				type:BoxGroup(group),position:"relative",group:group,
				OnClick(){
					self.showGroup(this.group);
				}
			};
			boxGroups.appendNewChild(css);
		}
		btnStateTool.text=""+appTools.tools.size;
		btnStateChain.text=""+appTools.chains.size;
		try{
			let nodes;
			nodes=await agentHub.getNodes(true);
			if(nodes){
				btnStateBots.text=Object.values(nodes).length;
			}else{
				btnStateBots.text="NA";
			}
		}catch(err){
		}
		/*}#1I1C1JAVP0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.createTool=async function(sender,event){
		/*#{1I19R1NLP0Start*/
		let result,line;
		result=await app.modalDlg("/@aichat/ui/DlgAIChat.js",{
			url:"/@aae/ai/PageBot.js",
			prompt:"",
			clearChat:true,
			allowEmptyChat:false,
			allowReset:false,
			autoClose:true
		},"CreateTool");
		/*}#1I19R1NLP0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.showGroup=async function(group){
		/*#{1I1I62ICH0Start*/
		let label,tools,tool,css,icon,chain,chains;
		curGroup=group;
		label=group.name;
		if(label["EN"]){
			label=label[$ln]||label["EN"];
		}
		icon=group.icon||"browser.svg";
		if(icon[0]!=="/"){
			icon=appCfg.sharedAssets+"/"+icon;
		}
		imgLogo.animate({
			type:"out",alpha:0,scale:1.2,time:150,
			OnFinish(){
				callAfter(()=>{
					imgLogo.image=icon;
					imgLogo.animate({type:"in",alpha:0,scale:1.2,time:300});
				});
			}
		});
		
		btnGroupMenu.enable=!(group.hostSite||group.allTools||group.allChains);
		
		self.showFace("siteMenu");
		boxGroupHeader.y=-20;
		boxGroupHeader.animate({type:"pose",y:0,time:80});
		txtGroupName.text=label;
		tools=group.tools||[];
		chains=group.chains||[];
		boxGroupItems.clearChildren();
		//List chains:
		for(chain of chains){
			css={
				type:BoxTool(chain,group),position:"relative",chain:chain,
				OnClick(){
					if(!group.allChains){
						appTools.execChain(app,this.chain);
					}else{
						self.showChainMenu(this.chain,curGroup,this);
					}
				},
				showMenu(sender){
					self.showChainMenu(this.chain,curGroup,sender);
				}
			};
			boxGroupItems.appendNewChild(css);
		}
		
		//List tools:
		for(tool of tools){
			css={
				type:BoxTool(tool,group),position:"relative",tool:tool,
				OnClick(){
					if(!group.allTools){
						appTools.execTool(app,this.tool);
					}else{
						self.showToolMenu(this.tool,group,this);
					}
				},
				showMenu(sender){
					self.showToolMenu(this.tool,curGroup,sender);
				}
			};
			boxGroupItems.appendNewChild(css);
		}
		//Add tool button:
		{
			css={
				type:BoxTool({
					name:(($ln==="CN")?("添加项目"):/*EN*/("Add item")),description:(($ln==="CN")?("通过AI对话、从文件或从云端添加新项目。"):/*EN*/("Add new items through AI chat, from files, or from the cloud.")),icon:"additem.svg",menu:false
				},group),position:"relative",tool:tool,
				OnClick(){
					self.showAddToolMenu(this);
				}
			};
			boxGroupItems.appendNewChild(css);
		}
		/*}#1I1I62ICH0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.closeSiteMenu=async function(sender,event){
		/*#{1I1I64CBJ0Start*/
		let list,i,n,box;
		curGroup=null;
		list=boxGroups.children
		n=list.length;
		for(i=0;i<n;i++){
			box=list[i];
			box.aniShow();
		}
		self.showFace("sites");
		imgLogo.animate({
			type:"out",alpha:0,scale:1.2,time:150,
			OnFinish(){
				imgLogo.image=appCfg.sharedAssets+"/aalogo.svg";
				imgLogo.animate({type:"in",alpha:0,scale:1.2,time:500});
			}
		});
		/*}#1I1I64CBJ0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.showMenu=async function(sender,event){
		/*#{1I1IF0PR70Start*/
		/*}#1I1IF0PR70Start*/
		{
			let $items,$item;
			$items=[
				{id:"Cloud",text:(($ln==="CN")?("从工具市场查找工具"):("Find tool from Tool Mart")),icon:appCfg.sharedAssets+"/cloud.svg",enable:true},
				{id:"File",text:(($ln==="CN")?("从文件导入工具或工具链"):("Import tool or tool-chain from file")),icon:appCfg.sharedAssets+"/folder.svg"},
				{id:"AddGroup",text:(($ln==="CN")?("新建工具组入口"):("New group entry")),icon:appCfg.sharedAssets+"/additem.svg",enable:true},
				{id:"Chat",text:(($ln==="CN")?("通过对话创建智能体"):("Create an AI agent by chat")),icon:appCfg.sharedAssets+"/aichat.svg",enable:false}
			];
			$item=await VFACT.app.modalDlg("/@StdUI/ui/DlgMenu.js",{hud:sender,items:$items});
			if($item){
				if($item.id==="Cloud"){
					/*#{1I1IF1JJO1*/
					await AppLib.ensurePackageInstalled(app,"user",false);
					app.openAppMeta("ToolMart@user");
					/*}#1I1IF1JJO1*/
				}else if($item.id==="File"){
					/*#{1I1IF1JJO0*/
					self.addToolByPath(sender,null);
					/*}#1I1IF1JJO0*/
				}else if($item.id==="AddGroup"){
					/*#{1I1IF1JJO2*/
					self.addNewGroup();
					/*}#1I1IF1JJO2*/
				}else if($item.id==="Chat"){
					/*#{1I1Q3R1JQ0*/
					/*}#1I1Q3R1JQ0*/
				}
			}
		}
	};
	//------------------------------------------------------------------------
	cssVO.showAddToolMenu=async function(sender){
		/*#{1I1IGCNVT0Start*/
		/*}#1I1IGCNVT0Start*/
		{
			let $items,$item;
			$items=[
				{id:"Cloud",text:(($ln==="CN")?("从智能体中心查找工具"):("Find tool from agent hub")),icon:appCfg.sharedAssets+"/cloud.svg",enable:false},
				{id:"File",text:(($ln==="CN")?("从文件导入工具"):("Import tool from file")),icon:appCfg.sharedAssets+"/folder.svg"},
				{id:"Chat",text:(($ln==="CN")?("通过与AI对话创建新工具"):("Create a new tool by chat with AI")),icon:appCfg.sharedAssets+"/aichat.svg",enable:false}
			];
			$item=await VFACT.app.modalDlg("/@StdUI/ui/DlgMenu.js",{hud:sender,items:$items});
			if($item){
				if($item.id==="Cloud"){
					/*#{1I1IGDBG51*/
					/*}#1I1IGDBG51*/
				}else if($item.id==="File"){
					/*#{1I1IGDBG50*/
					self.addToolByPath(sender,curGroup);
					/*}#1I1IGDBG50*/
				}else if($item.id==="Chat"){
					/*#{1I1JVCGEF0*/
					/*}#1I1JVCGEF0*/
				}
			}
		}
	};
	//------------------------------------------------------------------------
	cssVO.runCommand=async function(){
		/*#{1I1M6K4VG0Start*/
		let text;
		text=edCommand.text;
		if(!text){
			return;
		}
		runAgent({agent:"/@AgentBuilder/ai/SysTabOSChat.js",agentNode:null,args:text,title:"Chat with AI2Apps"});
		return;
		let meta,icon;
		meta=appTools.appMeta;
		if(!meta){
			icon="/~/-tabos/shared/assets/aalogo.svg";
			meta={
				type:"app",
				name:"Run command",
				caption:"Run command",
				icon:icon,
				appFrame:{
					group:"RunCommand",caption:"Run command",openApp:true,multiInstance:false,
					icon:icon,width:600,height:600,
				}
			};
			appTools.appMeta=meta;
		}
		meta.appFrame.main=`/@aichat/app.html?chat=${encodeURIComponent("/@aae/ai/ToolChat.js")}&prompt=${encodeURIComponent(text)}&style=pro`;
		app.newFrameApp(meta,null,{});
		/*}#1I1M6K4VG0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.addToolByPath=async function(hud,group){
		/*#{1I1OPT0RJ0Start*/
		let path,tool,ext2;
		path="/";
		path=await app.modalDlg("/@homekit/ui/DlgFile.js",{
			mode:"open",
			path:path,options:{
				multiSelect:false,
				preview:true,
			},
			buttonText:(($ln==="CN")?("打开"):/*EN*/("Open")),
		});
		if(!path){
			return;
		}
		path="/~"+path;
		ext2=pathLib.ext2name(path);
		if(ext2===".toolchain.json" || ext2===".toolchain.js"){
			let chain;
			chain=await appTools.loadChain(path);
			if(!group){
				let items,item;
				items=appTools.getGroups();
				items=items.map((group)=>{
					let name,icon;
					name=group.label||group.name;
					if(name.EN){
						name=name[$ln]||name.EN;
					}
					icon=group.icon;
					if(icon[0]!=="/"){
						icon=appCfg.sharedAssets+"/"+icon;
					}
					return {text:name,icon:icon,group:group};
				});
				item=await app.modalDlg("/@StdUI/ui/DlgSelect.js",{
					hud:hud,
					title:(($ln==="CN")?("添加到组？"):/*EN*/("Add to group?")),
					items:items
				});
				if(item){
					item.group.addChain(chain);
				}
			}else{
				group.addChain(chain);
				self.showGroup(curGroup);
			}
		}else{
			tool=await appTools.loadTool(path);
			if(!group){
				let items,item;
				items=appTools.getGroups();
				items=items.map((group)=>{
					let name,icon;
					name=group.label||group.name;
					if(name.EN){
						name=name[$ln]||name.EN;
					}
					icon=group.icon;
					if(icon[0]!=="/"){
						icon=appCfg.sharedAssets+"/"+icon;
					}
					return {text:name,icon:icon,group:group};
				});
				item=await app.modalDlg("/@StdUI/ui/DlgSelect.js",{
					hud:hud,
					title:(($ln==="CN")?("添加到组？"):/*EN*/("Add to group?")),
					items:items
				});
				if(item){
					item.group.addTool(tool);
				}
			}else{
				group.addTool(tool);
				self.showGroup(curGroup);
			}
		}
		app.emit("ToolsChanged");
		/*}#1I1OPT0RJ0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.maybeSaveTools=async function(){
		/*#{1I1P0EB940Start*/
		if(willSaveTools){
			return;
		}
		willSaveTools=true;
		callAfter(self.saveTools);
		/*}#1I1P0EB940Start*/
	};
	//------------------------------------------------------------------------
	cssVO.saveTools=async function(){
		/*#{1I1P2K9ER0Start*/
		willSaveTools=false;
		let path,label;
		path="/coke/ToolIndex.json";
		try{
			let saveVO;
			saveVO=await appTools.genSaveVO();
			await tabFS.writeFile(path,JSON.stringify(saveVO,null,"\t"));
		}catch(err){
			console.error(err);
		}
		callAfter(()=>{edCommand.focus();});
		/*}#1I1P2K9ER0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.addNewGroup=async function(){
		/*#{1I1QAF8RC0Start*/
		let name,group;
		name="NewGroup";
		name=window.prompt((($ln==="CN")?("输入新分组名称"):/*EN*/("Input new group name")),name);
		if(!name){
			return;
		}
		do{
			group=appTools.getGroup(name);
			if(!group){
				break;
			}
			window.alert((($ln==="CN")?("该群组名称已被使用！"):/*EN*/("Group name already taken!")));
			name=window.prompt((($ln==="CN")?("输入新分组名称"):/*EN*/("Input new group name")),name);
			if(!name){
				return;
			}
		}while(1);
		group=appTools.addGroup(name);
		self.showGroup(group);
		app.emit("ToolsChanged");
		/*}#1I1QAF8RC0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.showGroupMenu=async function(sender){
		/*#{1I1QC7IVU0Start*/
		/*}#1I1QC7IVU0Start*/
		{
			let $items,$item;
			$items=[
				{id:"Rename",text:(($ln==="CN")?("改名"):("Rename")),icon:appCfg.sharedAssets+"/rename.svg"},
				{id:"Icon",text:(($ln==="CN")?("选择图标"):("Select icon")),icon:appCfg.sharedAssets+"/hudimg.svg"},
				{id:"Remove",text:(($ln==="CN")?("移除该组"):("Remove this group")),icon:appCfg.sharedAssets+"/trash.svg"}
			];
			$item=await VFACT.app.modalDlg("/@StdUI/ui/DlgMenu.js",{hud:sender,items:$items});
			if($item){
				if($item.id==="Rename"){
					/*#{1I1QC7UIB0*/
					let name,group;
					name=curGroup.name;
					if(name.EN){
						name=name[$ln]||name.EN;
					}
					name=window.prompt((($ln==="CN")?("输入新的组名"):/*EN*/("Input new group name")),name);
					if(!name){
						return;
					}
					do{
						group=appTools.getGroup(name);
						if(!group){
							break;
						}
						window.alert((($ln==="CN")?("该群组名称已被使用！"):/*EN*/("Group name already taken!")));
						name=window.prompt((($ln==="CN")?("输入新分组名称"):/*EN*/("Input new group name")),name);
						if(!name){
							return;
						}
					}while(1);
					appTools.renameGroup(curGroup,name);
					self.showGroup(curGroup);
					app.emit("ToolsChanged");
					/*}#1I1QC7UIB0*/
				}else if($item.id==="Icon"){
					/*#{1I1QC7UIB1*/
					let path;
					path="/-tabos/shared/assets";
					path=await app.modalDlg("/@homekit/ui/DlgFile.js",{
						mode:"open",
						path:path,
						options:{
							multiSelect:false,
							preview:true,
							filter:"*.png;*.svg;*.jpg"
						},
						buttonText:(($ln==="CN")?("打开"):/*EN*/("Open")),
					});
					if(!path){
						return;
					}
					path="/~"+path;
					curGroup.icon=path;
					self.showGroup(curGroup);
					app.emit("ToolsChanged");
					/*}#1I1QC7UIB1*/
				}else if($item.id==="Remove"){
					/*#{1I1QC7UIB2*/
					if(!window.confirm("Are sure to remove this group?")){
						return;
					}
					appTools.removeGroup(curGroup);
					app.emit("ToolsChanged");
					self.closeSiteMenu();
					/*}#1I1QC7UIB2*/
				}
			}
		}
	};
	//------------------------------------------------------------------------
	cssVO.showToolMenu=async function(tool,group,sender){
		/*#{1I1Q4CLTB0Start*/
		/*}#1I1Q4CLTB0Start*/
		{
			let $items,$item;
			$items=[
				{id:"Info",text:(($ln==="CN")?("工具信息"):("Tool Information")),icon:appCfg.sharedAssets+"/idcard.svg"},
				{id:"Open",text:(($ln==="CN")?("运行工具"):("Execute Tool")),icon:appCfg.sharedAssets+"/run.svg"},
				{id:"Enbable",text:(($ln==="CN")?("启用"):("Enable")),icon:appCfg.sharedAssets+"/check.svg"},
				{id:"Disable",text:(($ln==="CN")?("禁用"):("Disable")),icon:appCfg.sharedAssets+"/lock.svg"},
				{id:"Delete",text:(($ln==="CN")?("移除"):("Remove")),icon:appCfg.sharedAssets+"/trash.svg"}
			];
			/*#{1I1Q4J0LC2Items*/
			if(tool.keyTool){
				$items[2].check=true;
				$items[2].enable=false;
				$items[3].enable=false;
				$items[4].enable=false;
			}else if(tool.enable){
				$items[2].check=true;
				$items[2].enable=false;
			}else{
				$items[3].check=true;
				$items[3].enable=false;
			}
			/*}#1I1Q4J0LC2Items*/
			$item=await VFACT.app.modalDlg("/@StdUI/ui/DlgMenu.js",{hud:sender,items:$items});
			if($item){
				if($item.id==="Info"){
					/*#{1I278APR30*/
					let toolVO=tool.genInfoVO($ln);
					let title;
					if(toolVO.guide){
						title=(($ln==="CN")?("工具链信息"):/*EN*/("Tool Chain Info"));
					}else{
						title=(($ln==="CN")?("工具信息"):/*EN*/("Tool Info"));
					}
					app.modalDlg("/@StdUI/ui/DlgDataView.js",{
						title:title,
						w:480,
						template:"ToolInfo",
						object:toolVO,
						edit:false
					});
					/*}#1I278APR30*/
				}else if($item.id==="Open"){
					/*#{1I1Q4HMJ51*/
					appTools.execTool(app,tool);
					/*}#1I1Q4HMJ51*/
				}else if($item.id==="Enbable"){
					/*#{1I278F9M10*/
					tool.enable=true;
					tool.emitNotify("Changed");
					app.emit("ToolsChanged");
					/*}#1I278F9M10*/
				}else if($item.id==="Disable"){
					/*#{1I278EITH0*/
					tool.enable=false;
					tool.emitNotify("Changed");
					app.emit("ToolsChanged");
					/*}#1I278EITH0*/
				}else if($item.id==="Delete"){
					/*#{1I1Q4HMJ50*/
					if(group.allTools){
						let ref,g;
						ref=appTools.getToolRef(tool);
						if(ref.chains.length){
							window.alert("This tool is used in tool-chain(s). Remove tool-chain before remove tools it using.");
							return;
						}
						if(ref.groups.length){
							if(!window.confirm((($ln==="CN")?("你确定要移除这个工具并从全部工具组中移除对它吗?"):/*EN*/("Are you sure to remove this tool and remove all references to it from all tool groups?")))){
								return;
							}
						}else{
							if(!window.confirm((($ln==="CN")?("你确定要移除这个工具吗?"):/*EN*/("Are you sure to remove this tool?")))){
								return;
							}
						}
						//Remove tool:
						appTools.removeTool(tool,ref);
						app.emit("ToolsChanged");
						self.showAllTools();
					}else{
						group.removeTool(tool);
						self.showGroup(curGroup);
						app.emit("ToolsChanged");
					}
					/*}#1I1Q4HMJ50*/
				}
			}
			/*#{1I1Q4J0LC2Post*/
			/*}#1I1Q4J0LC2Post*/
		}
	};
	//------------------------------------------------------------------------
	cssVO.showChainMenu=async function(chain,group,sender){
		/*#{1I1V5OGU40Start*/
		/*}#1I1V5OGU40Start*/
		{
			let $items,$item;
			$items=[
				{id:"Info",text:(($ln==="CN")?("工具链信息"):("Chain information")),icon:appCfg.sharedAssets+"/idcard.svg"},
				{id:"Open",text:(($ln==="CN")?("执行工具链"):("Execute Tool Chain")),icon:appCfg.sharedAssets+"/run.svg"},
				{id:"Delete",text:(($ln==="CN")?("删除工具连锁"):("Delete Tool Chain")),icon:appCfg.sharedAssets+"/trash.svg"}
			];
			$item=await VFACT.app.modalDlg("/@StdUI/ui/DlgMenu.js",{hud:sender,items:$items});
			if($item){
				if($item.id==="Info"){
					/*#{1I29JHLIL0*/
					let vo=chain.genInfoVO($ln);
					app.modalDlg("/@aae/ui/DlgToolInfo.js",{tool:vo,title:"工具信息"});
					/*}#1I29JHLIL0*/
				}else if($item.id==="Open"){
					/*#{1I1V5PBT30*/
					appTools.execChain(app,chain);
					/*}#1I1V5PBT30*/
				}else if($item.id==="Delete"){
					/*#{1I1V5PBT31*/
					if(group.allChains){
						let ref,g;
						ref=appTools.getChainRef(chain);
						if(ref.groups.length){
							if(!window.confirm((($ln==="CN")?("你确定要移除这个工具链并从全部工具组中移除对它吗?"):/*EN*/("Are you sure to remove this tool-chain and remove all references to it from all tool groups?")))){
								return;
							}
						}else{
							if(!window.confirm((($ln==="CN")?("你确定要移除这个工具链吗?"):/*EN*/("Are you sure to remove this tool-chain?")))){
								return;
							}
						}
						appTools.removeChain(chain,ref);
						app.emit("ToolsChanged");
						self.showAllChains();
					}else{
						group.removeChain(chain);
						self.showGroup(curGroup);
						app.emit("ToolsChanged");
					}
					/*}#1I1V5PBT31*/
				}
			}
		}
	};
	//------------------------------------------------------------------------
	cssVO.showAllTools=async function(){
		/*#{1I268L5VR0Start*/
		let tools,group;
		tools=appTools.getTools(true);
		group={
			name:(($ln==="CN")?("工具管理"):/*EN*/("Tool Management")),
			icon:"appdata.svg",
			allTools:true,
			tools:tools,
			menu:false
		};
		self.showGroup(group);
		/*}#1I268L5VR0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.showAllChains=async function(){
		/*#{1I268LO9T0Start*/
		let chains,group;
		chains=appTools.getChains(true);
		group={
			name:(($ln==="CN")?("工具管理链"):/*EN*/("Tool Chain Management")),
			icon:"toolchain.svg",
			allChains:true,
			chains:chains
		};
		self.showGroup(group);
		/*}#1I268LO9T0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.showBots=async function(){
		/*#{1I2ESN96I0Start*/
		let label,icon,nodes,node,css;
		label=(($ln==="CN")?("智能体节点"):/*EN*/("Agent Nodes"));
		if(label["EN"]){
			label=label[$ln]||label["EN"];
		}
		icon="agent.svg";
		if(icon[0]!=="/"){
			icon=appCfg.sharedAssets+"/"+icon;
		}
		imgLogo.animate({
			type:"out",alpha:0,scale:1.2,time:150,
			OnFinish(){
				callAfter(()=>{
					imgLogo.image=icon;
					imgLogo.animate({type:"in",alpha:0,scale:1.2,time:300});
				});
			}
		});
		
		btnGroupMenu.enable=true;
		self.showFace("siteMenu");
		boxGroupHeader.y=-20;
		boxGroupHeader.animate({type:"pose",y:0,time:80});
		txtGroupName.text=label;
		boxGroupItems.clearChildren();
		//List bots:
		nodes=await agentHub.getNodeList(true);
		for(node of nodes){
			css={
				type:BoxBot(node),position:"relative",bot:node,
				OnClick(){
				}
			};
			boxGroupItems.appendNewChild(css);
		}
		/*}#1I2ESN96I0Start*/
	};
	/*#{1I10E0NR21PostCSSVO*/
	/*}#1I10E0NR21PostCSSVO*/
	cssVO.constructor=DashBoard;
	return cssVO;
};
/*#{1I10E0NR21ExCodes*/
/*}#1I10E0NR21ExCodes*/

//----------------------------------------------------------------------------
DashBoard.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1I10E0NR21PreAISpot*/
	/*}#1I10E0NR21PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1I10E0NR21PostAISpot*/
	/*}#1I10E0NR21PostAISpot*/
	return exposeVO;
};

/*#{1I10E0NR20EndDoc*/
/*}#1I10E0NR20EndDoc*/

export default DashBoard;
export{DashBoard};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "UIView",
//	"jaxId": "1I10E0NR20",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1I10E0NR22",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "900",
//				"screenH": "700",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1I10E0NR23",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1I10E0NR24",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1I10E0NR25",
//			"attrs": {}
//		},
//		"localVars": {
//			"jaxId": "1I10E0NR26",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1I10E0NR27",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I1C1K57N0",
//					"attrs": {
//						"id": "readIndex",
//						"label": "New AI Seg",
//						"x": "65",
//						"y": "50",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I1C1LTNG0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I1C1LTNG1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I1C1LTNG2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I1C1JAVP0",
//					"attrs": {
//						"id": "listTools",
//						"label": "New AI Seg",
//						"x": "65",
//						"y": "120",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I1C1LTNG3",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I1C1LTNG4",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I1C1LTNG5",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I19R1NLP0",
//					"attrs": {
//						"id": "createTool",
//						"label": "New AI Seg",
//						"x": "65",
//						"y": "190",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I19R24EP0",
//							"attrs": {
//								"sender": {
//									"valText": "null"
//								},
//								"event": {
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I19R24EP1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I19R24EP2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I1I62ICH0",
//					"attrs": {
//						"id": "showGroup",
//						"label": "New AI Seg",
//						"x": "65",
//						"y": "265",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I1I62UCD0",
//							"attrs": {
//								"group": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I1I62UCD1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I1I62UCD2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I1I64CBJ0",
//					"attrs": {
//						"id": "closeSiteMenu",
//						"label": "New AI Seg",
//						"x": "65",
//						"y": "335",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I1I64MND0",
//							"attrs": {
//								"sender": {
//									"valText": "null"
//								},
//								"event": {
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I1I64MND1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I1I64MND2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I1IF0PR70",
//					"attrs": {
//						"id": "showMenu",
//						"label": "New AI Seg",
//						"x": "65",
//						"y": "415",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I1IF19DQ0",
//							"attrs": {
//								"sender": {
//									"valText": "null"
//								},
//								"event": {
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I1IF19DQ1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": [
//								{
//									"type": "flowseg",
//									"def": "Menu",
//									"jaxId": "1I1IF3KE60",
//									"attrs": {
//										"id": "menu",
//										"label": "New AI Seg",
//										"x": "280",
//										"y": "415",
//										"desc": "",
//										"codes": "false",
//										"launcher": "sender",
//										"outlets": {
//											"attrs": [
//												{
//													"type": "aioutlet",
//													"def": "MenuItem",
//													"jaxId": "1I1IF1JJO1",
//													"attrs": {
//														"id": "Cloud",
//														"text": {
//															"type": "string",
//															"valText": "Find tool from Tool Mart",
//															"localize": {
//																"EN": "Find tool from Tool Mart",
//																"CN": "从工具市场查找工具"
//															},
//															"localizable": true
//														},
//														"desc": "",
//														"enable": "true",
//														"icon": "#appCfg.sharedAssets+\"/cloud.svg\""
//													}
//												},
//												{
//													"type": "aioutlet",
//													"def": "MenuItem",
//													"jaxId": "1I1IF1JJO0",
//													"attrs": {
//														"id": "File",
//														"text": {
//															"type": "string",
//															"valText": "Import tool or tool-chain from file",
//															"localize": {
//																"EN": "Import tool or tool-chain from file",
//																"CN": "从文件导入工具或工具链"
//															},
//															"localizable": true
//														},
//														"desc": "",
//														"icon": "#appCfg.sharedAssets+\"/folder.svg\""
//													}
//												},
//												{
//													"type": "aioutlet",
//													"def": "MenuItem",
//													"jaxId": "1I1IF1JJO2",
//													"attrs": {
//														"id": "AddGroup",
//														"text": {
//															"type": "string",
//															"valText": "New group entry",
//															"localize": {
//																"EN": "New group entry",
//																"CN": "新建工具组入口"
//															},
//															"localizable": true
//														},
//														"desc": "",
//														"enable": "true",
//														"icon": "#appCfg.sharedAssets+\"/additem.svg\""
//													}
//												},
//												{
//													"type": "aioutlet",
//													"def": "MenuItem",
//													"jaxId": "1I1Q3R1JQ0",
//													"attrs": {
//														"id": "Chat",
//														"text": {
//															"type": "string",
//															"valText": "Create an AI agent by chat",
//															"localize": {
//																"EN": "Create an AI agent by chat",
//																"CN": "通过对话创建智能体"
//															},
//															"localizable": true
//														},
//														"desc": "",
//														"icon": "#appCfg.sharedAssets+\"/aichat.svg\"",
//														"enable": "false"
//													}
//												}
//											]
//										},
//										"outlet": {
//											"jaxId": "1I1IF3KE61",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											}
//										}
//									},
//									"icon": "menu.svg",
//									"reverseOutlets": true
//								}
//							]
//						},
//						"outlet": {
//							"jaxId": "1I1IF19DQ2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1IF3KE60"
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I1IGCNVT0",
//					"attrs": {
//						"id": "showAddToolMenu",
//						"label": "New AI Seg",
//						"x": "70",
//						"y": "620",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I1IGE7NS0",
//							"attrs": {
//								"sender": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I1IGE7NS1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": [
//								{
//									"type": "flowseg",
//									"def": "Menu",
//									"jaxId": "1I1IGE7NS2",
//									"attrs": {
//										"id": "menu",
//										"label": "New AI Seg",
//										"x": "335",
//										"y": "620",
//										"desc": "",
//										"codes": "false",
//										"launcher": "sender",
//										"outlets": {
//											"attrs": [
//												{
//													"type": "aioutlet",
//													"def": "MenuItem",
//													"jaxId": "1I1IGDBG51",
//													"attrs": {
//														"id": "Cloud",
//														"text": {
//															"type": "string",
//															"valText": "Find tool from agent hub",
//															"localize": {
//																"EN": "Find tool from agent hub",
//																"CN": "从智能体中心查找工具"
//															},
//															"localizable": true
//														},
//														"desc": "",
//														"icon": "#appCfg.sharedAssets+\"/cloud.svg\"",
//														"enable": "false"
//													}
//												},
//												{
//													"type": "aioutlet",
//													"def": "MenuItem",
//													"jaxId": "1I1IGDBG50",
//													"attrs": {
//														"id": "File",
//														"text": {
//															"type": "string",
//															"valText": "Import tool from file",
//															"localize": {
//																"EN": "Import tool from file",
//																"CN": "从文件导入工具"
//															},
//															"localizable": true
//														},
//														"desc": "",
//														"icon": "#appCfg.sharedAssets+\"/folder.svg\""
//													}
//												},
//												{
//													"type": "aioutlet",
//													"def": "MenuItem",
//													"jaxId": "1I1JVCGEF0",
//													"attrs": {
//														"id": "Chat",
//														"text": {
//															"type": "string",
//															"valText": "Create a new tool by chat with AI",
//															"localize": {
//																"EN": "Create a new tool by chat with AI",
//																"CN": "通过与AI对话创建新工具"
//															},
//															"localizable": true
//														},
//														"desc": "",
//														"icon": "#appCfg.sharedAssets+\"/aichat.svg\"",
//														"enable": "false"
//													}
//												}
//											]
//										},
//										"outlet": {
//											"jaxId": "1I1IGE7NS3",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											}
//										}
//									},
//									"icon": "menu.svg",
//									"reverseOutlets": true
//								}
//							]
//						},
//						"outlet": {
//							"jaxId": "1I1IGE7NS4",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1IGE7NS2"
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I1M6K4VG0",
//					"attrs": {
//						"id": "runCommand",
//						"label": "New AI Seg",
//						"x": "70",
//						"y": "700",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I1M6L3OP0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I1M6L3OP1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I1M6L3OP2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I1OPT0RJ0",
//					"attrs": {
//						"id": "addToolByPath",
//						"label": "New AI Seg",
//						"x": "65",
//						"y": "770",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I1OPTTF90",
//							"attrs": {
//								"hud": {
//									"type": "auto",
//									"valText": "null"
//								},
//								"group": {
//									"type": "auto",
//									"valText": "null"
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I1OPTTF91",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I1OPTTF92",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I1P0EB940",
//					"attrs": {
//						"id": "maybeSaveTools",
//						"label": "New AI Seg",
//						"x": "65",
//						"y": "860",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I1P0EI2M0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I1P0EI2M1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I1P0EI2M2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I1P2K9ER0",
//					"attrs": {
//						"id": "saveTools",
//						"label": "New AI Seg",
//						"x": "65",
//						"y": "950",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I1P34BTI0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I1P34BTI1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I1P34BTI2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I1QAF8RC0",
//					"attrs": {
//						"id": "addNewGroup",
//						"label": "New AI Seg",
//						"x": "65",
//						"y": "1160",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I1QAFL6H0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I1QAFL6H1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I1QAFL6H2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I1QC7IVU0",
//					"attrs": {
//						"id": "showGroupMenu",
//						"label": "New AI Seg",
//						"x": "65",
//						"y": "1280",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I1QCBLDM0",
//							"attrs": {
//								"sender": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I1QCBLDM1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": [
//								{
//									"type": "flowseg",
//									"def": "Menu",
//									"jaxId": "1I1QCBLDM2",
//									"attrs": {
//										"id": "menu",
//										"label": "New AI Seg",
//										"x": "325",
//										"y": "1280",
//										"desc": "",
//										"codes": "false",
//										"launcher": "sender",
//										"outlets": {
//											"attrs": [
//												{
//													"type": "aioutlet",
//													"def": "MenuItem",
//													"jaxId": "1I1QC7UIB0",
//													"attrs": {
//														"id": "Rename",
//														"text": {
//															"type": "string",
//															"valText": "Rename",
//															"localize": {
//																"EN": "Rename",
//																"CN": "改名"
//															},
//															"localizable": true
//														},
//														"desc": "",
//														"icon": "#appCfg.sharedAssets+\"/rename.svg\""
//													}
//												},
//												{
//													"type": "aioutlet",
//													"def": "MenuItem",
//													"jaxId": "1I1QC7UIB1",
//													"attrs": {
//														"id": "Icon",
//														"text": {
//															"type": "string",
//															"valText": "Select icon",
//															"localize": {
//																"EN": "Select icon",
//																"CN": "选择图标"
//															},
//															"localizable": true
//														},
//														"desc": "",
//														"icon": "#appCfg.sharedAssets+\"/hudimg.svg\""
//													}
//												},
//												{
//													"type": "aioutlet",
//													"def": "MenuItem",
//													"jaxId": "1I1QC7UIB2",
//													"attrs": {
//														"id": "Remove",
//														"text": {
//															"type": "string",
//															"valText": "Remove this group",
//															"localize": {
//																"EN": "Remove this group",
//																"CN": "移除该组"
//															},
//															"localizable": true
//														},
//														"desc": "",
//														"icon": "#appCfg.sharedAssets+\"/trash.svg\""
//													}
//												}
//											]
//										},
//										"outlet": {
//											"jaxId": "1I1QCBLDM3",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											}
//										}
//									},
//									"icon": "menu.svg",
//									"reverseOutlets": true
//								}
//							]
//						},
//						"outlet": {
//							"jaxId": "1I1QCBLDM4",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1QCBLDM2"
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I1Q4CLTB0",
//					"attrs": {
//						"id": "showToolMenu",
//						"label": "New AI Seg",
//						"x": "65",
//						"y": "1040",
//						"desc": "",
//						"codes": "true",
//						"args": {
//							"jaxId": "1I1Q4J0LC0",
//							"attrs": {
//								"tool": {
//									"type": "auto",
//									"valText": "null"
//								},
//								"group": {
//									"type": "auto",
//									"valText": ""
//								},
//								"sender": {
//									"type": "auto",
//									"valText": "null"
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I1Q4J0LC1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": [
//								{
//									"type": "flowseg",
//									"def": "Menu",
//									"jaxId": "1I1Q4J0LC2",
//									"attrs": {
//										"id": "menu",
//										"label": "New AI Seg",
//										"x": "315",
//										"y": "1040",
//										"desc": "",
//										"codes": "true",
//										"launcher": "sender",
//										"outlets": {
//											"attrs": [
//												{
//													"type": "aioutlet",
//													"def": "MenuItem",
//													"jaxId": "1I278APR30",
//													"attrs": {
//														"id": "Info",
//														"text": {
//															"type": "string",
//															"valText": "Tool Information",
//															"localize": {
//																"EN": "Tool Information",
//																"CN": "工具信息"
//															},
//															"localizable": true
//														},
//														"desc": "",
//														"icon": "#appCfg.sharedAssets+\"/idcard.svg\""
//													}
//												},
//												{
//													"type": "aioutlet",
//													"def": "MenuItem",
//													"jaxId": "1I1Q4HMJ51",
//													"attrs": {
//														"id": "Open",
//														"text": {
//															"type": "string",
//															"valText": "Execute Tool",
//															"localize": {
//																"EN": "Execute Tool",
//																"CN": "运行工具"
//															},
//															"localizable": true
//														},
//														"desc": "",
//														"icon": "#appCfg.sharedAssets+\"/run.svg\""
//													}
//												},
//												{
//													"type": "aioutlet",
//													"def": "MenuItem",
//													"jaxId": "1I278F9M10",
//													"attrs": {
//														"id": "Enbable",
//														"text": {
//															"type": "string",
//															"valText": "Enable",
//															"localize": {
//																"EN": "Enable",
//																"CN": "启用"
//															},
//															"localizable": true
//														},
//														"desc": "",
//														"icon": "#appCfg.sharedAssets+\"/check.svg\""
//													}
//												},
//												{
//													"type": "aioutlet",
//													"def": "MenuItem",
//													"jaxId": "1I278EITH0",
//													"attrs": {
//														"id": "Disable",
//														"text": {
//															"type": "string",
//															"valText": "Disable",
//															"localize": {
//																"EN": "Disable",
//																"CN": "禁用"
//															},
//															"localizable": true
//														},
//														"desc": "",
//														"icon": "#appCfg.sharedAssets+\"/lock.svg\""
//													}
//												},
//												{
//													"type": "aioutlet",
//													"def": "MenuItem",
//													"jaxId": "1I1Q4HMJ50",
//													"attrs": {
//														"id": "Delete",
//														"text": {
//															"type": "string",
//															"valText": "Remove",
//															"localize": {
//																"EN": "Remove",
//																"CN": "移除"
//															},
//															"localizable": true
//														},
//														"desc": "",
//														"icon": "#appCfg.sharedAssets+\"/trash.svg\""
//													}
//												}
//											]
//										},
//										"outlet": {
//											"jaxId": "1I1Q4J0LC3",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											}
//										}
//									},
//									"icon": "menu.svg",
//									"reverseOutlets": true
//								}
//							]
//						},
//						"outlet": {
//							"jaxId": "1I1Q4J0LC4",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1Q4J0LC2"
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I1V5OGU40",
//					"attrs": {
//						"id": "showChainMenu",
//						"label": "New AI Seg",
//						"x": "65",
//						"y": "1460",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I1V5R31F0",
//							"attrs": {
//								"chain": {
//									"type": "auto",
//									"valText": "null"
//								},
//								"group": {
//									"type": "auto",
//									"valText": "null"
//								},
//								"sender": {
//									"type": "auto",
//									"valText": "null"
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I1V5R31F1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": [
//								{
//									"type": "flowseg",
//									"def": "Menu",
//									"jaxId": "1I1V5R31F2",
//									"attrs": {
//										"id": "menu",
//										"label": "New AI Seg",
//										"x": "325",
//										"y": "1460",
//										"desc": "",
//										"codes": "false",
//										"launcher": "sender",
//										"outlets": {
//											"attrs": [
//												{
//													"type": "aioutlet",
//													"def": "MenuItem",
//													"jaxId": "1I29JHLIL0",
//													"attrs": {
//														"id": "Info",
//														"text": {
//															"type": "string",
//															"valText": "Chain information",
//															"localize": {
//																"EN": "Chain information",
//																"CN": "工具链信息"
//															},
//															"localizable": true
//														},
//														"desc": "",
//														"icon": "#appCfg.sharedAssets+\"/idcard.svg\""
//													}
//												},
//												{
//													"type": "aioutlet",
//													"def": "MenuItem",
//													"jaxId": "1I1V5PBT30",
//													"attrs": {
//														"id": "Open",
//														"text": {
//															"type": "string",
//															"valText": "Execute Tool Chain",
//															"localize": {
//																"EN": "Execute Tool Chain",
//																"CN": "执行工具链"
//															},
//															"localizable": true
//														},
//														"desc": "",
//														"icon": "#appCfg.sharedAssets+\"/run.svg\""
//													}
//												},
//												{
//													"type": "aioutlet",
//													"def": "MenuItem",
//													"jaxId": "1I1V5PBT31",
//													"attrs": {
//														"id": "Delete",
//														"text": {
//															"type": "string",
//															"valText": "Delete Tool Chain",
//															"localize": {
//																"EN": "Delete Tool Chain",
//																"CN": "删除工具连锁"
//															},
//															"localizable": true
//														},
//														"desc": "",
//														"icon": "#appCfg.sharedAssets+\"/trash.svg\""
//													}
//												}
//											]
//										},
//										"outlet": {
//											"jaxId": "1I1V5R31F3",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											}
//										}
//									},
//									"icon": "menu.svg",
//									"reverseOutlets": true
//								}
//							]
//						},
//						"outlet": {
//							"jaxId": "1I1V5R31F4",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1V5R31F2"
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I268L5VR0",
//					"attrs": {
//						"id": "showAllTools",
//						"label": "New AI Seg",
//						"x": "65",
//						"y": "1640",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I268LHSS0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I268LHSS1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I268LHSS2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I268LO9T0",
//					"attrs": {
//						"id": "showAllChains",
//						"label": "New AI Seg",
//						"x": "65",
//						"y": "1750",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I268M3J20",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I268M3J21",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I268M3J22",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I2ESN96I0",
//					"attrs": {
//						"id": "showBots",
//						"label": "New AI Seg",
//						"x": "65",
//						"y": "1855",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I2ESNKFT0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I2ESNKFT1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I2ESNKFT2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				}
//			]
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1I10E0NR28",
//			"attrs": {
//				"sites": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1I1D5700V0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1I1D58F460",
//							"attrs": {}
//						}
//					}
//				},
//				"siteMenu": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1I1D5774S0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1I1D58F461",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1I10E0NR29",
//			"attrs": {}
//		},
//		"exposeToAI": "true",
//		"descAI": "",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "view",
//			"jaxId": "1I10E0NR21",
//			"attrs": {
//				"properties": {
//					"jaxId": "1I10E0NR210",
//					"attrs": {
//						"type": "view",
//						"id": "",
//						"position": "Absolute",
//						"x": "50%",
//						"y": "0",
//						"w": "100%-50",
//						"h": "100%",
//						"anchorH": "Center",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "[0,0,0,0]",
//						"padding": "10",
//						"minW": "",
//						"minH": "",
//						"maxW": "1000",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Flex Y",
//						"subAlign": "Start",
//						"itemsAlign": "Center"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1I10E3UB90",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I10E5VED0",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxHeader",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex X",
//										"itemsAlign": "Center",
//										"subAlign": "End"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1I10ECJ960",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I10EG4K00",
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBodySub\"]",
//														"text": {
//															"type": "string",
//															"valText": "Powerful AI agent, super web automation, at your command",
//															"localize": {
//																"EN": "Powerful AI agent, super web automation, at your command",
//																"CN": "强大的AI智能体，超级网页自动化，听候您的调遣"
//															},
//															"localizable": true
//														},
//														"font": "",
//														"fontSize": "#txtSize.mid",
//														"bold": "true",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Center",
//														"alignV": "Center",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0",
//														"flex": "true"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I10EG4K01",
//													"attrs": {
//														"1I1D5774S0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I1IDDJNP0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I1IDDJNP1",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I1D5774S0",
//															"faceTagName": "siteMenu"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I10EG4K02",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I10EG4K03",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1I121UDDO0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1I1220QMG0",
//													"attrs": {
//														"style": "\"front\"",
//														"w": "30",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/agent.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1I1220QMG1",
//													"attrs": {
//														"type": "#null#>BtnIcon(\"front\",30,0,appCfg.sharedAssets+\"/agent.svg\",null)",
//														"id": "BtnBot",
//														"position": "relative",
//														"x": "15",
//														"y": "15",
//														"display": "Off",
//														"face": "",
//														"cursor": "pointer",
//														"margin": "[0,5,0,0]",
//														"anchorH": "Center",
//														"autoLayout": "false",
//														"anchorV": "Center"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I1220QMG2",
//													"attrs": {
//														"1I1D5774S0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I1IDDJNP2",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I1IDDJNP3",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I1D5774S0",
//															"faceTagName": "siteMenu"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I1220QMG3",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I1220QMG4",
//													"attrs": {
//														"tip": {
//															"type": "string",
//															"valText": "Current Bot",
//															"localize": {
//																"EN": "Current Bot",
//																"CN": "当前工仔"
//															},
//															"localizable": true
//														}
//													}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1I1220QMG5",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1I121VNAK0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I1220QMG6",
//													"attrs": {
//														"type": "text",
//														"id": "TxtBrowserAlias",
//														"position": "relative",
//														"x": "0",
//														"y": "50%",
//														"w": "",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Center",
//														"autoLayout": "false",
//														"display": "Off",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "pointer",
//														"zIndex": "0",
//														"margin": "[0,10,0,0]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBody\"]",
//														"text": "- - - - -",
//														"font": "",
//														"fontSize": "16",
//														"bold": "true",
//														"italic": "false",
//														"underline": "true",
//														"alignH": "Left",
//														"alignV": "Center",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I1220QMG7",
//													"attrs": {
//														"1I1D5774S0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I1IDDJNP4",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I1IDDJNP5",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I1D5774S0",
//															"faceTagName": "siteMenu"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I1220QMG8",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I1220QMG9",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1I10E4MUE0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1I10E5VED1",
//													"attrs": {
//														"style": "\"front\"",
//														"w": "30",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/settings.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1I10E5VED2",
//													"attrs": {
//														"type": "#null#>BtnIcon(\"front\",30,0,appCfg.sharedAssets+\"/settings.svg\",null)",
//														"id": "BtnCfg",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"display": "Off",
//														"face": "",
//														"cursor": "pointer"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I10E5VED3",
//													"attrs": {
//														"1I1D5774S0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I1IDDJNP6",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I1IDDJNP7",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I1D5774S0",
//															"faceTagName": "siteMenu"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I10E5VED4",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I10E5VED5",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1I10E5VED6",
//													"attrs": {}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1I10E5VED7",
//									"attrs": {
//										"1I1D5774S0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I1IDDJNP8",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I1IDDJNP9",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I1D5774S0",
//											"faceTagName": "siteMenu"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1I10E5VED8",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1I10E5VED9",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1I10E9V2M0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I10EAO5Q0",
//									"attrs": {
//										"type": "text",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "Off",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,50,0]",
//										"padding": "[0,0,0,0]",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#cfgColor[\"fontBodyLit\"]",
//										"text": "www.ai2apps.com",
//										"font": "",
//										"fontSize": "#txtSize.smallPlus",
//										"bold": "true",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Center",
//										"alignV": "Top",
//										"wrap": "false",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1I10EAO5Q1",
//									"attrs": {
//										"1I1D5774S0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I1IDDJNP12",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I1IDDJNP13",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I1D5774S0",
//											"faceTagName": "siteMenu"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1I10EAO5Q2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1I10EAO5Q3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1I1US7JF80",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I1USEVPL0",
//									"attrs": {
//										"type": "hud",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "240",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "0",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex X",
//										"itemsAlign": "Center",
//										"flex": "false"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1I1USB7L80",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I1USDQBC0",
//													"attrs": {
//														"type": "hud",
//														"id": "",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"w": "50%-40",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": ""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I1USDQBC1",
//													"attrs": {
//														"1I1D5774S0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I1V0C7MT14",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I1V0C7MT15",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I1D5774S0",
//															"faceTagName": "siteMenu"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I1USDQBC2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I1USDQBC3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "image",
//											"jaxId": "1I1USCCFA0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I1USCCFA1",
//													"attrs": {
//														"type": "image",
//														"id": "ImgLogo",
//														"position": "relative",
//														"x": "40",
//														"y": "40",
//														"w": "80",
//														"h": "80",
//														"anchorH": "Center",
//														"anchorV": "Center",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "0",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"image": "#appCfg.sharedAssets+\"/aalogo.svg\"",
//														"autoSize": "false",
//														"fitSize": "Fit",
//														"repeat": "true",
//														"alignX": "Left",
//														"alignY": "Top"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I1USCCFB0",
//													"attrs": {
//														"1I1D5774S0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I1USCCFB1",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I1USCCFB2",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I1D5774S0",
//															"faceTagName": "siteMenu"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I1USCCFB3",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I1USCCFB4",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "true"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1I1USDRD10",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I1USDRD11",
//													"attrs": {
//														"type": "hud",
//														"id": "",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"w": "50%-40",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "10",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex Y",
//														"subAlign": "Start"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "Gear1I1UT4SUC0",
//															"jaxId": "1I2B3HVI30",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1I2B3HVI31",
//																	"attrs": {
//																		"icon": "agent.svg",
//																		"text": "-",
//																		"tip": {
//																			"type": "string",
//																			"valText": "Bots Workgroup",
//																			"localize": {
//																				"EN": "Bots Workgroup",
//																				"CN": "工仔群"
//																			},
//																			"localizable": true
//																		}
//																	}
//																},
//																"properties": {
//																	"jaxId": "1I2B3HVI32",
//																	"attrs": {
//																		"type": "#null#>BtnState(\"agent.svg\",\"-\",(($ln===\"CN\")?(\"工仔群\"):(\"Bots Workgroup\")))",
//																		"id": "BtnStateBots",
//																		"position": "Relative",
//																		"x": "100%",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"anchorH": "Right"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1I2B3HVI40",
//																	"attrs": {
//																		"1I1D5700V0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I2B3HVI41",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I2B3HVI42",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I1D5700V0",
//																			"faceTagName": "sites"
//																		},
//																		"1I1D5774S0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I2B3HVI43",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I2B3HVI44",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I1D5774S0",
//																			"faceTagName": "siteMenu"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1I2B3HVI45",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1I2B3HVI50",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1I2B3HVI51",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": "1I2ESN96I0"
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1I2B3HVI52",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1I2B3HVI53",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear1I1UT4SUC0",
//															"jaxId": "1I1UU28N70",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1I1UU3EFU0",
//																	"attrs": {
//																		"icon": "appdata.svg",
//																		"text": "-",
//																		"tip": {
//																			"type": "string",
//																			"valText": "Tool management",
//																			"localize": {
//																				"EN": "Tool management",
//																				"CN": "工具管理"
//																			},
//																			"localizable": true
//																		}
//																	}
//																},
//																"properties": {
//																	"jaxId": "1I1UU3EFU1",
//																	"attrs": {
//																		"type": "#null#>BtnState(\"appdata.svg\",\"-\",(($ln===\"CN\")?(\"工具管理\"):(\"Tool management\")))",
//																		"id": "BtnStateTool",
//																		"position": "Relative",
//																		"x": "100%",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"anchorH": "Right"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1I1UU3EFU2",
//																	"attrs": {
//																		"1I1D5700V0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I1V0C7MT18",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I1V0C7MT19",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I1D5700V0",
//																			"faceTagName": "sites"
//																		},
//																		"1I1D5774S0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I1V0C7MT20",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I1V0C7MT21",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I1D5774S0",
//																			"faceTagName": "siteMenu"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1I1UU3EFU3",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1I275U5D70",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1I275U5D71",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": "1I268L5VR0"
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1I1UU3EFU4",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1I1UU3EFU5",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear1I1UT4SUC0",
//															"jaxId": "1I1UUF8SN0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1I1UUF8SN1",
//																	"attrs": {
//																		"icon": "skillchain.svg",
//																		"text": "-",
//																		"tip": {
//																			"type": "string",
//																			"valText": "Tool Chain Management",
//																			"localize": {
//																				"EN": "Tool Chain Management",
//																				"CN": "工具链管理"
//																			},
//																			"localizable": true
//																		}
//																	}
//																},
//																"properties": {
//																	"jaxId": "1I1UUF8SN2",
//																	"attrs": {
//																		"type": "#null#>BtnState(\"skillchain.svg\",\"-\",(($ln===\"CN\")?(\"工具链管理\"):(\"Tool Chain Management\")))",
//																		"id": "BtnStateChain",
//																		"position": "Relative",
//																		"x": "100%",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"anchorH": "Right"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1I1UUF8SO0",
//																	"attrs": {
//																		"1I1D5700V0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I1V0C7MU0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I1V0C7MU1",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I1D5700V0",
//																			"faceTagName": "sites"
//																		},
//																		"1I1D5774S0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I1V0C7MU2",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I1V0C7MU3",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I1D5774S0",
//																			"faceTagName": "siteMenu"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1I1UUF8SO1",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1I276Q38H0",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1I276Q38H1",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": "1I268LO9T0"
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1I1UUF8SO2",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1I1UUF8SO3",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear1I1UT4SUC0",
//															"jaxId": "1I29MDBOI0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1I29MDBOI1",
//																	"attrs": {
//																		"icon": "mail.svg",
//																		"text": "-",
//																		"tip": {
//																			"type": "string",
//																			"valText": "Messages",
//																			"localize": {
//																				"EN": "Messages",
//																				"CN": "消息"
//																			},
//																			"localizable": true
//																		}
//																	}
//																},
//																"properties": {
//																	"jaxId": "1I29MDBOI2",
//																	"attrs": {
//																		"type": "#null#>BtnState(\"mail.svg\",\"-\",(($ln===\"CN\")?(\"消息\"):(\"Messages\")))",
//																		"id": "BtnMessages",
//																		"position": "Relative",
//																		"x": "100%",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"anchorH": "Right"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1I29MDBOJ0",
//																	"attrs": {
//																		"1I1D5700V0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I29MDBOJ1",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I29MDBOJ2",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I1D5700V0",
//																			"faceTagName": "sites"
//																		},
//																		"1I1D5774S0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I29MDBOJ3",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I29MDBOJ4",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I1D5774S0",
//																			"faceTagName": "siteMenu"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1I29MDBOJ5",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1I29MDBOJ6",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1I29MDBOJ7",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": "1I268LO9T0"
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1I29MDBOJ8",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1I29MDBOJ9",
//																	"attrs": {}
//																}
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1I1USDRD20",
//													"attrs": {
//														"1I1D5774S0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I1V0C7MU6",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I1V0C7MU7",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I1D5774S0",
//															"faceTagName": "siteMenu"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I1USDRD21",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I1USDRD22",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1I1USEVPL1",
//									"attrs": {
//										"1I1D5774S0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I1V0C7MU10",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I1V0C7MU11",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I1D5774S0",
//											"faceTagName": "siteMenu"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1I1USEVPL2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1I1USEVPL3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1I10EHPSR0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I10ESI3K0",
//									"attrs": {
//										"type": "box",
//										"id": "BoxInput",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "60%",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[20,0,0,0]",
//										"padding": "[5,10,5,10]",
//										"minW": "",
//										"minH": "40",
//										"maxW": "800",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"chatInputBG\"]",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor[\"fontBodyLit\"]",
//										"corner": "32",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.20]",
//										"contentLayout": "Flex X",
//										"itemsAlign": "End",
//										"subAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1I1HHL2Q00",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1I1HHL2Q01",
//													"attrs": {
//														"style": "\"front\"",
//														"w": "30",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/menu.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1I1HHL2Q02",
//													"attrs": {
//														"type": "#null#>BtnIcon(\"front\",30,0,appCfg.sharedAssets+\"/menu.svg\",null)",
//														"id": "BtnSendCmd",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"margin": "[0,5,0,0]"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I1HHL2Q10",
//													"attrs": {
//														"1I1D5774S0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I1IDDJNP14",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I1IDDJNP15",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I1D5774S0",
//															"faceTagName": "siteMenu"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I1HHL2Q13",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1I1IF19DQ3",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1I1IF19DQ4",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": "1I1IF0PR70"
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1I1HHL2Q14",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1I1HHL2Q15",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "memo",
//											"jaxId": "1I1M5M3QT0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I1M5P2NB0",
//													"attrs": {
//														"type": "memo",
//														"id": "EdCommand",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%-70",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "30",
//														"maxW": "",
//														"maxH": "200",
//														"face": "",
//														"styleClass": "",
//														"text": "",
//														"color": "#cfgColor[\"fontBody\"]",
//														"bgColor": "[255,255,255,0.00]",
//														"font": "",
//														"fontSize": "16",
//														"outline": "0",
//														"border": "[0,0,1,0]",
//														"borderStyle": "Solid",
//														"borderColor": "#cfgColor[\"fontBodyLit\"]",
//														"corner": "0",
//														"readOnly": "false",
//														"selectOnFocus": "true",
//														"spellCheck": "true"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I1M5P2NB1",
//													"attrs": {
//														"1I1D5774S0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I1V0C7MU16",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I1V0C7MU17",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I1D5774S0",
//															"faceTagName": "siteMenu"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I1M5P2NB2",
//													"attrs": {
//														"OnInput": {
//															"type": "fixedFunc",
//															"jaxId": "1I1M64K3N0",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1I1M64K3Q0",
//																	"attrs": {}
//																},
//																"seg": ""
//															}
//														},
//														"OnKeyDown": {
//															"type": "fixedFunc",
//															"jaxId": "1I1M64K3N1",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1I1M64K3Q1",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1I1M5P2NB3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1I1M69F3G0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I1M6CT890",
//													"attrs": {
//														"type": "text",
//														"id": "TxtInputTip",
//														"position": "Absolute",
//														"x": "52",
//														"y": "0",
//														"w": "",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "Tree Off",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBodyLit\"]",
//														"text": {
//															"type": "string",
//															"valText": "Make your command...",
//															"localize": {
//																"EN": "Make your command...",
//																"CN": "给出你的指令..."
//															},
//															"localizable": true
//														},
//														"font": "",
//														"fontSize": "16",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Center",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I1M6CT891",
//													"attrs": {
//														"1I1D5774S0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I1V0C7MU20",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I1V0C7MU21",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I1D5774S0",
//															"faceTagName": "siteMenu"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I1M6CT892",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I1M6CT893",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1I10EONLD0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1I10ESI3K5",
//													"attrs": {
//														"style": "\"front\"",
//														"w": "30",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/send.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1I10ESI3K6",
//													"attrs": {
//														"type": "#null#>BtnIcon(\"front\",30,0,appCfg.sharedAssets+\"/send.svg\",null)",
//														"id": "BtnSendCmd",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"padding": "3",
//														"margin": "[0,0,0,3]",
//														"enable": "false"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I10ESI3K7",
//													"attrs": {
//														"1I1D5774S0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I1IDDJNP18",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I1IDDJNP19",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I1D5774S0",
//															"faceTagName": "siteMenu"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I10ESI3K8",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1I1OOIH1D0",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1I1OOIH1D1",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": "1I1M6K4VG0"
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1I10ESI3K9",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1I10ESI3K10",
//													"attrs": {}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1I10ESI3K11",
//									"attrs": {
//										"1I1D5700V0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I1I5GNM720",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I1I5GNM721",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I1D5700V0",
//											"faceTagName": "sites"
//										},
//										"1I1D5774S0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I1IDDJNP20",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I1IDDJNP21",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I1D5774S0",
//											"faceTagName": "siteMenu"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1I10ESI3K12",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1I10ESI3K13",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1I11BTJ790",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I11C2RA00",
//									"attrs": {
//										"type": "hud",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "Off",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[30,0,15,0]",
//										"padding": "[0,10,0,10]",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex X",
//										"itemsWrap": "Wrap",
//										"itemsAlign": "Center",
//										"subAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnText.js",
//											"jaxId": "1I11CBT0C0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1I11CBT0C1",
//													"attrs": {
//														"style": "secondary",
//														"w": "150",
//														"h": "28",
//														"text": "Execute Task",
//														"outlined": "true",
//														"icon": "#appCfg.sharedAssets+\"/run.svg\""
//													}
//												},
//												"properties": {
//													"jaxId": "1I11CBT0C2",
//													"attrs": {
//														"type": "#null#>BtnText(\"secondary\",150,28,\"Execute Task\",true,appCfg.sharedAssets+\"/run.svg\")",
//														"id": "BtnRunTask",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"margin": "[0,10,0,10]",
//														"enable": "false"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I11CBT0D0",
//													"attrs": {
//														"1I1D5774S0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I1IDDJNP22",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I1IDDJNP23",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I1D5774S0",
//															"faceTagName": "siteMenu"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I11CBT0D1",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I11CBT0D2",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1I11CBT0D3",
//													"attrs": {
//														"Slot1H2F6U36O0": {
//															"jaxId": "1I11CBT0D4",
//															"attrs": {
//																"subHuds": {
//																	"attrs": []
//																},
//																"container": "true"
//															}
//														}
//													}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnText.js",
//											"jaxId": "1I11BUR250",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1I11C2RA01",
//													"attrs": {
//														"style": "secondary",
//														"w": "150",
//														"h": "28",
//														"text": "Create a Tool",
//														"outlined": "true",
//														"icon": "#appCfg.sharedAssets+\"/additem.svg\""
//													}
//												},
//												"properties": {
//													"jaxId": "1I11C2RA02",
//													"attrs": {
//														"type": "#null#>BtnText(\"secondary\",150,28,\"Create a Tool\",true,appCfg.sharedAssets+\"/additem.svg\")",
//														"id": "BtnCreateTool",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"margin": "[0,10,0,10]",
//														"padding": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I11C2RA03",
//													"attrs": {
//														"1I1D5774S0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I1IDDJNP24",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I1IDDJNP25",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I1D5774S0",
//															"faceTagName": "siteMenu"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I11C2RA04",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1I19R24EP3",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1I19R24EP4",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": "1I19R1NLP0"
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1I11C2RA05",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1I11C2RA06",
//													"attrs": {
//														"Slot1H2F6U36O0": {
//															"jaxId": "1I11C2RA07",
//															"attrs": {
//																"subHuds": {
//																	"attrs": []
//																},
//																"container": "true"
//															}
//														}
//													}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnText.js",
//											"jaxId": "1I11C3IL90",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1I11C3IL91",
//													"attrs": {
//														"style": "secondary",
//														"w": "150",
//														"h": "28",
//														"text": "Tool Hub",
//														"outlined": "true",
//														"icon": "#appCfg.sharedAssets+\"/cloud.svg\""
//													}
//												},
//												"properties": {
//													"jaxId": "1I11C3IL92",
//													"attrs": {
//														"type": "#null#>BtnText(\"secondary\",150,28,\"Tool Hub\",true,appCfg.sharedAssets+\"/cloud.svg\")",
//														"id": "BtnToolHub",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"margin": "[0,10,0,10]",
//														"padding": "[0,3,0,0]",
//														"enable": "false"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I11C3IL93",
//													"attrs": {
//														"1I1D5774S0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I1IDDJNP26",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I1IDDJNP27",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I1D5774S0",
//															"faceTagName": "siteMenu"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I11C3IL94",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I11C3IL95",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1I11C3IL96",
//													"attrs": {
//														"Slot1H2F6U36O0": {
//															"jaxId": "1I11C3IL97",
//															"attrs": {
//																"subHuds": {
//																	"attrs": []
//																},
//																"container": "true"
//															}
//														}
//													}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1I11C2RA08",
//									"attrs": {
//										"1I1D5774S0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I1IDDJNP28",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I1IDDJNP29",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I1D5774S0",
//											"faceTagName": "siteMenu"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1I11C2RA09",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1I11C2RA010",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1I11DDGM90",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I11DGKMG0",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxContents",
//										"position": "relative",
//										"x": "50%",
//										"y": "0",
//										"w": "100%",
//										"h": "100",
//										"anchorH": "Center",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Auto Scroll Y",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "20",
//										"padding": "[20,50,20,50]",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "360",
//										"face": "",
//										"styleClass": "",
//										"flex": "true",
//										"contentLayout": "Block",
//										"itemsWrap": "Wrap",
//										"itemsAlign": "Start",
//										"subAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1I19QVP9T0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I19R05DJ0",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxGroups",
//														"position": "Absolute",
//														"x": "50",
//														"y": "0",
//														"w": "100%-100",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "Off",
//														"clip": "Auto Scroll Y",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "10",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex X",
//														"subAlign": "Center",
//														"itemsAlign": "Center",
//														"itemsWrap": "Wrap"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "Gear1I1BV49TB0",
//															"jaxId": "1I1C03A9B0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1I1C046KG0",
//																	"attrs": {
//																		"groupVO": "#{label:\"www.google.com\",tools:[1,2,3,4,5],chains:[1,2,3]}"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1I1C046KG1",
//																	"attrs": {
//																		"type": "#null#>BoxGroup({label:\"www.google.com\",tools:[1,2,3,4,5],chains:[1,2,3]})",
//																		"id": "",
//																		"position": "relative",
//																		"x": "125",
//																		"y": "35",
//																		"display": "On",
//																		"face": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1I1C046KG2",
//																	"attrs": {
//																		"1I1D5774S0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I1IDDJNP30",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I1IDDJNP31",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I1D5774S0",
//																			"faceTagName": "siteMenu"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1I1C046KG3",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1I1C046KG4",
//																	"attrs": {}
//																},
//																"mockup": "true",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1I1C046KG5",
//																	"attrs": {}
//																}
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1I19R05DK0",
//													"attrs": {
//														"1I1D5774S0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I1D58F4767",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I1D58F4768",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I1D5774S0",
//															"faceTagName": "siteMenu"
//														},
//														"1I1D5700V0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I1D58F4769",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I1D58F4770",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I1D5700V0",
//															"faceTagName": "sites"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I19R05DK1",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I19R05DK2",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "true",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1I1D4M7EH0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I1D4N6FM0",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxGroupMenu",
//														"position": "Absolute",
//														"x": "50",
//														"y": "0",
//														"w": "100%-100",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Auto Scroll Y",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "5",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex Y"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1I1D525QM0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I1D545LC0",
//																	"attrs": {
//																		"type": "hud",
//																		"id": "BoxGroupHeader",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "30",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"contentLayout": "Flex X"
//																	}
//																},
//																"subHuds": {
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "Gear/@StdUI/ui/BtnIcon.js",
//																			"jaxId": "1I1D52KLM0",
//																			"attrs": {
//																				"createArgs": {
//																					"jaxId": "1I1D545LC1",
//																					"attrs": {
//																						"style": "\"front\"",
//																						"w": "30",
//																						"h": "0",
//																						"icon": "#appCfg.sharedAssets+\"/arrowleft.svg\"",
//																						"colorBG": "null"
//																					}
//																				},
//																				"properties": {
//																					"jaxId": "1I1D545LC2",
//																					"attrs": {
//																						"type": "#null#>BtnIcon(\"front\",30,0,appCfg.sharedAssets+\"/arrowleft.svg\",null)",
//																						"id": "BtnCloseSiteMenu",
//																						"position": "Relative",
//																						"x": "0",
//																						"y": "0",
//																						"display": "On",
//																						"face": "",
//																						"margin": "[0,5,0,0]"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1I1D545LC3",
//																					"attrs": {
//																						"1I1D5774S0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1I1IDDJNP32",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1I1IDDJNP33",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1I1D5774S0",
//																							"faceTagName": "siteMenu"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1I1D545LC4",
//																					"attrs": {
//																						"OnClick": {
//																							"type": "fixedFunc",
//																							"jaxId": "1I1I64ARH0",
//																							"attrs": {
//																								"callArgs": {
//																									"jaxId": "1I1I64MNF0",
//																									"attrs": {
//																										"event": ""
//																									}
//																								},
//																								"seg": "1I1I64CBJ0"
//																							}
//																						}
//																					}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1I1D545LC5",
//																					"attrs": {
//																						"tip": {
//																							"type": "string",
//																							"valText": "Back",
//																							"localize": {
//																								"EN": "Back",
//																								"CN": "返回"
//																							},
//																							"localizable": true
//																						}
//																					}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false",
//																				"containerSlots": {
//																					"jaxId": "1I1D545LC6",
//																					"attrs": {}
//																				}
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "text",
//																			"jaxId": "1I1D549G80",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I1D549G81",
//																					"attrs": {
//																						"type": "text",
//																						"id": "TxtGroupName",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "-10",
//																						"w": "",
//																						"h": "",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"color": "#cfgColor[\"fontBodySub\"]",
//																						"text": "www.google.com",
//																						"font": "",
//																						"fontSize": "#txtSize.bigPlus",
//																						"bold": "true",
//																						"italic": "false",
//																						"underline": "false",
//																						"alignH": "Center",
//																						"alignV": "Top",
//																						"wrap": "false",
//																						"ellipsis": "false",
//																						"lineClamp": "0",
//																						"select": "false",
//																						"shadow": "false",
//																						"shadowX": "0",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowColor": "[0,0,0,1.00]",
//																						"shadowEx": "",
//																						"maxTextW": "0",
//																						"flex": "true"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1I1D549G90",
//																					"attrs": {
//																						"1I1D5774S0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1I1IDDJNP34",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1I1IDDJNP35",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1I1D5774S0",
//																							"faceTagName": "siteMenu"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1I1D549G91",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1I1D549G92",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "true"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "Gear/@StdUI/ui/BtnIcon.js",
//																			"jaxId": "1I1QBHS2K0",
//																			"attrs": {
//																				"createArgs": {
//																					"jaxId": "1I1QBHS2K1",
//																					"attrs": {
//																						"style": "\"front\"",
//																						"w": "30",
//																						"h": "0",
//																						"icon": "#appCfg.sharedAssets+\"/menu.svg\"",
//																						"colorBG": "null"
//																					}
//																				},
//																				"properties": {
//																					"jaxId": "1I1QBHS2K2",
//																					"attrs": {
//																						"type": "#null#>BtnIcon(\"front\",30,0,appCfg.sharedAssets+\"/menu.svg\",null)",
//																						"id": "BtnGroupMenu",
//																						"position": "Relative",
//																						"x": "0",
//																						"y": "0",
//																						"display": "On",
//																						"face": "",
//																						"margin": "[0,5,0,0]"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1I1QBHS2L0",
//																					"attrs": {
//																						"1I1D5774S0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1I1QBHS2L1",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1I1QBHS2L2",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1I1D5774S0",
//																							"faceTagName": "siteMenu"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1I1QBHS2L3",
//																					"attrs": {
//																						"OnClick": {
//																							"type": "fixedFunc",
//																							"jaxId": "1I1QBHS2L4",
//																							"attrs": {
//																								"callArgs": {
//																									"jaxId": "1I1QBHS2L5",
//																									"attrs": {
//																										"event": ""
//																									}
//																								},
//																								"seg": "1I1QC7IVU0"
//																							}
//																						}
//																					}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1I1QBHS2L6",
//																					"attrs": {
//																						"tip": {
//																							"type": "string",
//																							"valText": "Options",
//																							"localize": {
//																								"EN": "Options",
//																								"CN": "选项"
//																							},
//																							"localizable": true
//																						}
//																					}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "true",
//																				"containerSlots": {
//																					"jaxId": "1I1QBHS2L7",
//																					"attrs": {}
//																				}
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"jaxId": "1I1D545LC7",
//																	"attrs": {
//																		"1I1D5774S0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I1IDDJNP36",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I1IDDJNP37",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I1D5774S0",
//																			"faceTagName": "siteMenu"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1I1D545LC8",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1I1D545LC9",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "true",
//																"exposeContainer": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1I1D4RN860",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I1D4SM5O4",
//																	"attrs": {
//																		"type": "hud",
//																		"id": "BoxGroupItems",
//																		"position": "relative",
//																		"x": "30",
//																		"y": "0",
//																		"w": "100%-60",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "[5,0,5,0]",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"contentLayout": "Flex X",
//																		"itemsWrap": "Wrap",
//																		"subAlign": "Center"
//																	}
//																},
//																"subHuds": {
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "Gear1I1I7N5V30",
//																			"jaxId": "1I1I81DE20",
//																			"attrs": {
//																				"createArgs": {
//																					"jaxId": "1I1I81DE21",
//																					"attrs": {
//																						"tool": "#{label:\"www.google.com\",tools:[1,2,3,4,5]}",
//																						"group": "{}"
//																					}
//																				},
//																				"properties": {
//																					"jaxId": "1I1I81DE22",
//																					"attrs": {
//																						"type": "#null#>BoxTool({label:\"www.google.com\",tools:[1,2,3,4,5]},{})",
//																						"id": "",
//																						"position": "Relative",
//																						"x": "125",
//																						"y": "35",
//																						"display": "On",
//																						"face": ""
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1I1I81DE23",
//																					"attrs": {
//																						"1I1D5774S0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1I1IDDJNP38",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1I1IDDJNP39",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1I1D5774S0",
//																							"faceTagName": "siteMenu"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1I1I81DE24",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1I1I81DE25",
//																					"attrs": {}
//																				},
//																				"mockup": "true",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false",
//																				"containerSlots": {
//																					"jaxId": "1I1I81DE26",
//																					"attrs": {}
//																				}
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "Gear1I1I7N5V30",
//																			"jaxId": "1I1I82G4F0",
//																			"attrs": {
//																				"createArgs": {
//																					"jaxId": "1I1I82G4F1",
//																					"attrs": {
//																						"tool": "#{label:\"www.google.com\",tools:[1,2,3,4,5]}",
//																						"group": "{}"
//																					}
//																				},
//																				"properties": {
//																					"jaxId": "1I1I82G4F2",
//																					"attrs": {
//																						"type": "#null#>BoxTool({label:\"www.google.com\",tools:[1,2,3,4,5]},{})",
//																						"id": "",
//																						"position": "Relative",
//																						"x": "125",
//																						"y": "35",
//																						"display": "On",
//																						"face": ""
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1I1I82G4F3",
//																					"attrs": {
//																						"1I1D5774S0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1I1IDDJNP40",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1I1IDDJNP41",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1I1D5774S0",
//																							"faceTagName": "siteMenu"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1I1I82G4F4",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1I1I82G4F5",
//																					"attrs": {}
//																				},
//																				"mockup": "true",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false",
//																				"containerSlots": {
//																					"jaxId": "1I1I82G4F6",
//																					"attrs": {}
//																				}
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "Gear1I1I7N5V30",
//																			"jaxId": "1I1I82HKS0",
//																			"attrs": {
//																				"createArgs": {
//																					"jaxId": "1I1I82HKS1",
//																					"attrs": {
//																						"tool": "#{label:\"www.google.com\",tools:[1,2,3,4,5]}",
//																						"group": "{}"
//																					}
//																				},
//																				"properties": {
//																					"jaxId": "1I1I82HKS2",
//																					"attrs": {
//																						"type": "#null#>BoxTool({label:\"www.google.com\",tools:[1,2,3,4,5]},{})",
//																						"id": "",
//																						"position": "Relative",
//																						"x": "125",
//																						"y": "35",
//																						"display": "On",
//																						"face": ""
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1I1I82HKS3",
//																					"attrs": {
//																						"1I1D5774S0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1I1IDDJNP42",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1I1IDDJNQ0",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1I1D5774S0",
//																							"faceTagName": "siteMenu"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1I1I82HKS4",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1I1I82HKS5",
//																					"attrs": {}
//																				},
//																				"mockup": "true",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false",
//																				"containerSlots": {
//																					"jaxId": "1I1I82HKS6",
//																					"attrs": {}
//																				}
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"jaxId": "1I1D4SM5O5",
//																	"attrs": {
//																		"1I1D5774S0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I1IDDJNQ1",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I1IDDJNQ2",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I1D5774S0",
//																			"faceTagName": "siteMenu"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1I1D4SM5O6",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1I1D4SM5O7",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "true",
//																"exposeContainer": "false"
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1I1D4N6FM1",
//													"attrs": {
//														"1I1D5774S0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I1D58F4795",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I1D58F4796",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I1D5774S0",
//															"faceTagName": "siteMenu"
//														},
//														"1I1D5700V0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I1D58F4797",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I1D58F4798",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I1D5700V0",
//															"faceTagName": "sites"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I1D4N6FM2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I1D4N6FM3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "true",
//												"exposeContainer": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1I11DGKMG1",
//									"attrs": {
//										"1I1D5774S0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I1IDDJNQ3",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I1IDDJNQ4",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I1D5774S0",
//											"faceTagName": "siteMenu"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1I11DGKMG2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1I11DGKMG3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1I10E0NR30",
//					"attrs": {
//						"1I1D5774S0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1I1IDDJNQ5",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I1IDDJNQ6",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1I1D5774S0",
//							"faceTagName": "siteMenu"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1I10E0NR31",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1I10E0NR32",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1I10E0NR33",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}