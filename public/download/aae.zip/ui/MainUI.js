//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
import {BtnCheck} from "/@StdUI/ui/BtnCheck.js";
import {BtnText} from "/@StdUI/ui/BtnText.js";
import {DataView} from "/@StdUI/ui/DataView.js";
import {BtnNaviItem} from "/@StdUI/ui/BtnNaviItem.js";
import {BoxNodeInfo} from "./BoxNodeInfo.js";
import {NaviToolBar} from "/@StdUI/ui/NaviToolBar.js";
/*#{1GGJKM84D0StartDoc*/
import {tabFS,tabOS} from "/@tabos";
import {AAFarm} from "../aafarm.js";
import AAE from "../aae.js";
import {BtnNodeLine} from "./BtnNodeLine.js";
import {BoxDomNode} from "./BoxDomNode.js";
import {BoxQueryBlock} from "./BoxQueryBlock.js";
import {BoxEvent} from "./BoxEvent.js";
import {BtnEvent} from "./BtnEvent.js";
import {Actions,ActionFilter,BrowserArgs} from "../data/AppData.js";
/*}#1GGJKM84D0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let MainUI=function(app,appFrame){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let btnBrowser,txtBrowser,btnWaitPage,btnHistory,edURL,btnHeadless,btnDevTools,btnViewport,edViewportW,edViewportH,boxNaviScroll,boxNodesList,boxQueryBlocks,btnGenQuery,edQuery,btnQuery,btnUseQuery,boxQueryResults,boxEventsFrame,boxEventsScroll,dvActions,boxPageImage,imgPage,boxPoseH,boxPoseV,boxPose,boxNodeInfo,boxEventView,boxEvents,dvEvent,boxCopyEvent,boxFootNavi,btnModeNavi,btnModeQuery,boxModeEvent,btnModeEvent,boxEventMark;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let actions=Actions.newObject();
	
	/*#{1GGJKM84D1LocalVals*/
	let farm=new AAFarm();
	let browser=null;
	let page=null;
	let client=null;
	let pageInfo=null;
	let hotNodeLine=null;
	let curNode=null;
	let boxViewNodeInfo=null;
	let boxEventNodeInfo=null;
	let viewRootNode=null;
	let zmP2I=0.5;
	let zmI2P=2;
	let uiMode="Navi";
	let events=[];
	let usageJSON=null;
	let queryKeySet=new Set();
	
	let lastPickTime=0;
	let lastPickX=0;
	let lastPickY=0;
	let canvasWidth=0;
	let curEventBtn;
	let eventConfig={
		network:true,
		navigation:true,
		action:true
	};
	let eventFilter=new Set(["load","popup","request","response","click","dblclick","keydown","input"]);
	
	let openBrowserId=null;
	let openBrowserAlias="AAHOME";
	let openBrowserWithDir=false;
	
	let hotQueryLine=null;
	let tgtQueryNode=null;
	/*}#1GGJKM84D1LocalVals*/
	
	/*#{1GGJKM84D1PreState*/
	/*}#1GGJKM84D1PreState*/
	state={
		"counter":0,"curNode":null,
		/*#{1GGJKM84D6ExState*/
		/*}#1GGJKM84D6ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1GGJKM84D1PostState*/
	function nodeCSS(node){
		return {
			type:BoxDomNode(page,node,self,true),position:"relative",node:node,
			focusNode(){
				self.focusViewNode(this);
			}
		};
	}
	function eventCSS(event){
		return {
			type:BoxEvent(client,event,self),position:"relative",event:event,
			focusNode(){
				let node=event.target;
				if(node && node.AAEId){
					node=self.getNodeByAAEId(node.AAEId);
					if(node){
						self.showNode(node,true,true);
					}
				}
			}
		};
	}
	function isPicked(node,x,y){
		let rect;
		rect=node.rect;
		if(!rect){
			return false;
		}
		if(!node.touchable){
			return false;
		}
		if(x>=rect.x && x<rect.x+rect.width && y>=rect.y && y<rect.y+rect.height){
			return true;
		}
		return false;
	}
	/*}#1GGJKM84D1PostState*/
	cssVO={
		"hash":"1GGJKM84D1",nameHost:true,
		"type":"view","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
		children:[
			{
				"hash":"1HVNF199H0",
				"type":"box","id":"BoxBG","x":-2,"y":-2,"w":">calc(100% + 4px)","h":">calc(100% + 4px)","display":0,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"background":[255,255,255,1],"border":2,"shadow":true,"shadowX":10,"shadowY":15,"shadowBlur":12,"shadowColor":[0,0,0,0.3],
			},
			{
				"hash":"1HMJURVH80",
				"type":"text","id":"TxtInitTip","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodyLit"],
				"text":"Pick a page tab or open a new URL to inspect","fontSize":txtSize.bigPlus,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignH":1,
				"alignV":1,
			},
			{
				"hash":"1HL22KVCS0",
				"type":"box","id":"BoxHeader","x":0,"y":0,"w":"100%","h":30,"padding":[0,5,0,5],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["body"],
				"border":[1,0,1,0],"borderColor":cfgColor["lineBodySub"],"contentLayout":"flex-x","itemsAlign":1,
				children:[
					{
						"hash":"1HL247PKA0",
						"type":"box","id":"BoxState","position":"relative","x":0,"y":0,"w":20,"h":20,"display":0,"uiEvent":-1,"alpha":0.6,"margin":[0,3,0,0],"minW":"","minH":"",
						"maxW":"","maxH":"","styleClass":"","background":cfgColor["fontBodySub"],"maskImage":appCfg.sharedAssets+"/web.svg",
					},
					{
						"hash":"1HUB0JGH10",
						"type":BtnIcon("front",22,0,appCfg.sharedAssets+"/web.svg",null),"id":"BtnBrowser","position":"relative","x":0,"y":0,
						"tip":"Browser Profile",
						"OnClick":function(event){
							self.pickBrowser(this,event);
						},
					},
					{
						"hash":"1HUNBTMCD0",
						"type":"text","id":"TxtBrowser","position":"relative","x":0,"y":0,"w":"","h":"","margin":[0,5,0,0],"minW":"","minH":"","maxW":100,"maxH":"","styleClass":"",
						"color":[0,0,0],"text":"AAHOME","fontSize":txtSize.small,"fontWeight":"bold","fontStyle":"normal","textDecoration":"","ellipsis":true,
					},
					{
						"hash":"1HMCK5HGF0",
						"type":BtnIcon("front",22,0,"assets/findtab.svg",null),"id":"BtnWaitPage","position":"relative","x":0,"y":0,"margin":[0,5,0,0],
						"tip":"Pick a page to start",
						"OnClick":function(event){
							self.pickPage(this,event);
						},
					},
					{
						"hash":"1HL24FPD80",
						"type":BtnIcon(cfgColor.fontBodySub,25,0,appCfg.sharedAssets+"/btncombo.svg",null),"id":"BtnHistory","position":"relative","x":0,"y":0,"enable":false,
						"tip":(($ln==="CN")?("打开最近的URL进行检查"):("Open recent URL to inspect")),
						"OnClick":function(event){
							self.openHistory(this,event);
						},
					},
					{
						"hash":"1HL242G9D0",
						"type":"edit","id":"EdURL","position":"relative","x":0,"y":0,"w":380,"h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","placeHolder":"Page URL to be inspect",
						"color":[0,0,0],"fontSize":txtSize.smallPlus,"outline":0,"border":[0,0,1,0],
						"OnKeyDown":function(event){
							/*#{1HNDBG2A70FunctionBody*/
							if(event.code==="Enter"){
								if((!event.isComposing) &&(!event.shiftKey)){
									event.stopPropagation();
									event.preventDefault();
									page=null;
									self.openPage(this,event);
								}
							}
							/*}#1HNDBG2A70FunctionBody*/
						},
					},
					{
						"hash":"1HSJ97TN80",
						"type":BtnCheck(16,"Headless",false,false),"id":"BtnHeadless","position":"relative","x":0,"y":0,"margin":[0,5,0,5],
					},
					{
						"hash":"1HSJ985O70",
						"type":BtnCheck(16,"Dev. Tools",false,false),"id":"BtnDevTools","position":"relative","x":0,"y":0,"margin":[0,5,0,5],
					},
					{
						"hash":"1HSJAPKRK0",
						"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","margin":[0,0,0,5],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":[0,0,0],
						"text":"Viewport:","fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
					},
					{
						"hash":"1HSJAQTOG0",
						"type":BtnIcon("front",22,0,appCfg.sharedAssets+"/btncombo.svg",null),"id":"BtnViewport","position":"relative","x":0,"y":0,
						"OnClick":function(event){
							self.showViewportMenu(this,event);
						},
					},
					{
						"hash":"1HSJASBC00",
						"type":"edit","id":"EdViewportW","position":"relative","x":0,"y":0,"w":40,"h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","text":"800",
						"color":[0,0,0],"fontSize":txtSize.smallPlus,"outline":0,"border":[0,0,1,0],
					},
					{
						"hash":"1HSJASUE60",
						"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":[0,0,0],"text":"x",
						"fontSize":txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
					},
					{
						"hash":"1HSJATQIC0",
						"type":"edit","id":"EdViewportH","position":"relative","x":0,"y":0,"w":40,"h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","text":"600",
						"color":[0,0,0],"fontSize":txtSize.smallPlus,"outline":0,"border":[0,0,1,0],
					}
				],
			},
			{
				"hash":"1HL22OAA50",
				"type":"hud","id":"BoxMid","x":0,"y":30,"w":"100%","h":">calc(100% - 60px)","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				children:[
					{
						"hash":"1HL23283C0",
						"type":"box","id":"BoxModeNavi","x":0,"y":0,"w":300,"h":"100%","display":0,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":[255,255,255,1],
						"border":[0,2,0,0],"borderColor":cfgColor["fontBodySub"],"contentLayout":"flex-y",
						children:[
							{
								"hash":"1HL24NM3C0",
								"type":"box","id":"BoxNaviHeader","position":"relative","x":0,"y":0,"w":"100%","h":25,"padding":[0,0,0,3],"minW":"","minH":"","maxW":"","maxH":"",
								"styleClass":"","background":[255,255,255,1],"border":[0,0,1,0],"borderColor":cfgColor["fontBodySub"],"contentLayout":"flex-x","itemsAlign":1,
								children:[
									{
										"hash":"1HL256IOU0",
										"type":BtnIcon(cfgColor.fontBodySub,24,0,appCfg.sharedAssets+"/undo.svg",null),"id":"BtnViewDoc","position":"relative","x":0,"y":0,"margin":[0,3,0,0],
										"enable":false,
										"OnClick":function(event){
											self.showPageView(this,event);
										},
									},
									{
										"hash":"1HL2591OS0",
										"type":BtnIcon(cfgColor.fontBodySub,24,0,appCfg.sharedAssets+"/spot.svg",null),"id":"BtnFindNode","position":"relative","x":0,"y":0,"margin":[0,3,0,0],
										"enable":false,
										"tip":"Make query on selected node",
										"OnClick":function(event){
											self.fillQuery(this,event);
										},
									},
									{
										"hash":"1HSKB0LHD0",
										"type":"hud","position":"relative","x":0,"y":0,"w":100,"h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","flex":true,
									},
									{
										"hash":"1HSKB5OHA0",
										"type":BtnIcon(cfgColor.fontBodySub,24,0,appCfg.sharedAssets+"/read.svg",null),"id":"BtnRead","position":"relative","x":0,"y":0,"margin":[0,3,0,0],
										"enable":false,
										"tip":"Make query on selected node",
										"OnClick":function(event){
											self.readView(this,event);
										},
									}
								],
							},
							{
								"hash":"1HL24QIKL0",
								"type":"hud","id":"BoxNaviScroll","position":"relative","x":0,"y":0,"w":"100%","h":">calc(100% - 25px)","overflow":"auto","minW":"","minH":"",
								"maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
								children:[
									{
										"hash":"1HL24SGV90",
										"type":"hud","id":"BoxNodesList","position":"relative","x":0,"y":0,"w":"","h":"","minW":"100%","minH":50,"maxW":"","maxH":"","styleClass":"",
										"contentLayout":"flex-y",
									}
								],
							}
						],
					},
					{
						"hash":"1HL5MC9T00",
						"type":"box","id":"BoxQueryFrame","x":0,"y":0,"w":300,"h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":[255,255,255,1],
						"border":[0,2,0,0],
						children:[
							{
								"hash":"1HL5MC9T10",
								"type":"box","id":"BoxQueryHeader","position":"relative","x":0,"y":0,"w":"100%","h":25,"padding":[0,0,0,3],"minW":"","minH":"","maxW":"","maxH":"",
								"styleClass":"","background":[255,255,255,1],"border":[0,0,1,0],"borderColor":cfgColor["fontBodySub"],"contentLayout":"flex-x","itemsAlign":1,
								children:[
									{
										"hash":"1HL5MC9T20",
										"type":BtnIcon(cfgColor.fontBodySub,24,0,appCfg.sharedAssets+"/undo.svg",null),"id":"BtnRefillQuery","position":"relative","x":0,"y":0,"margin":[0,3,0,0],
										"enable":false,
										"OnClick":function(event){
											self.fillQuery(this,event);
										},
									},
									{
										"hash":"1I01UT0O00",
										"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/aichat.svg",null),"id":"BtnAIQuery","position":"relative","x":0,"y":"50%","scale":1,"anchorY":1,
										"OnClick":function(event){
											self.queryWithAI(this,event);
										},
									}
								],
							},
							{
								"hash":"1HL5ME54B0",
								"type":"hud","id":"BoxQueryScroll","position":"relative","x":0,"y":0,"w":"100%","h":">calc(100% - 25px)","overflow":"auto-y","padding":[5,5,50,5],
								"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
								children:[
									{
										"hash":"1HL5ME54C0",
										"type":"hud","id":"BoxQueryBlocks","position":"relative","x":0,"y":0,"w":"100%","h":"","minW":"","minH":20,"maxW":"","maxH":"","styleClass":"",
										"contentLayout":"flex-y",
									},
									{
										"hash":"1HNAQE5IH0",
										"type":BtnText("primary",160,24,"Gen Query String",false,""),"id":"BtnGenQuery","position":"relative","x":"50%","y":0,"margin":[5,0,10,0],"anchorX":1,
										"OnClick":function(event){
											/*#{1HNAQE5II7FunctionBody*/
											self.buildQuery(this,event);
											/*}#1HNAQE5II7FunctionBody*/
										},
									},
									{
										"hash":"1HLF4UKJG0",
										"type":"text","position":"relative","x":0,"y":0,"w":"100%","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":[0,0,0],"text":"XPath query selector:",
										"fontSize":txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
									},
									{
										"hash":"1HLEPSAM80",
										"type":"edit","id":"EdQuery","position":"relative","x":5,"y":0,"w":">calc(100% - 10px)","h":20,"margin":[5,0,10,0],"minW":"","minH":"","maxW":"",
										"maxH":"","styleClass":"","placeHolder":"Query string","color":[0,0,0],"fontSize":txtSize.smallPlus,"outline":0,"border":[0,0,1,0],"autoSelect":false,
										"spellCheck":false,
										"OnKeyDown":function(event){
											/*#{1HNDASRUV0FunctionBody*/
											if(event.code==="Enter"){
												if((!event.isComposing) &&(!event.shiftKey)){
													event.stopPropagation();
													event.preventDefault();
													self.doQuery();
												}
											}
											/*}#1HNDASRUV0FunctionBody*/
										},
									},
									{
										"hash":"1HLF50TFP0",
										"type":BtnCheck(18,"Touchable only",true,false),"id":"BtnQueryTouch","position":"relative","x":0,"y":0,"display":0,"margin":[0,0,5,0],
									},
									{
										"hash":"1HLEP6HS20",
										"type":BtnText("primary",160,24,"Query",false,""),"id":"BtnQuery","position":"relative","x":"50%","y":0,"margin":[5,0,10,0],"anchorX":1,
										"OnClick":function(event){
											self.doQuery(this,event);
										},
									},
									{
										"hash":"1HVPU79040",
										"type":BtnText("success",160,24,"Use and Close",false,""),"id":"BtnUseQuery","position":"relative","x":"50%","y":0,"margin":[5,0,10,0],"anchorX":1,
										"OnClick":function(event){
											self.useQuery(this,event);
										},
									},
									{
										"hash":"1HLELF1A30",
										"type":"box","position":"relative","x":"10%","y":0,"w":"80%","h":1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["fontBodySub"],
									},
									{
										"hash":"1HLELBPI40",
										"type":"hud","id":"BoxQueryResults","position":"relative","x":0,"y":0,"w":"100%","h":"","minW":"","minH":50,"maxW":"","maxH":"","styleClass":"",
										"contentLayout":"flex-y",
									}
								],
							}
						],
					},
					{
						"hash":"1HL23VHIQ0",
						"type":"box","id":"BoxEventsFrame","x":0,"y":0,"w":300,"h":"100%","display":0,"overflow":1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						"background":[255,255,255,1],"border":[0,2,0,0],"contentLayout":"flex-y",
						children:[
							{
								"hash":"1HL24L7070",
								"type":"box","id":"BoxEventsHeader","position":"relative","x":0,"y":0,"w":"100%","h":25,"padding":[0,0,0,3],"minW":"","minH":"","maxW":"","maxH":"",
								"styleClass":"","background":[255,255,255,1],"border":[0,0,1,0],"borderColor":cfgColor["fontBodySub"],"contentLayout":"flex-x",
								children:[
									{
										"hash":"1HRFT6IG60",
										"type":BtnIcon(cfgColor.fontBodySub,24,0,appCfg.sharedAssets+"/folder.svg",null),"id":"BtnOpenActions","position":"relative","x":0,"y":0,"margin":[0,3,0,0],
										"enable":false,
										"tip":"Open Action",
										"OnClick":function(event){
											self.ClearAction(this,event);
										},
									},
									{
										"hash":"1HRFT76200",
										"type":BtnIcon(cfgColor.fontBodySub,24,0,appCfg.sharedAssets+"/save.svg",null),"id":"BtnSaveActions","position":"relative","x":0,"y":0,"margin":[0,3,0,0],
										"enable":false,
										"tip":"Save Action",
										"OnClick":function(event){
											self.ClearAction(this,event);
										},
									},
									{
										"hash":"1HRFTD03N0",
										"type":"hud","position":"relative","x":0,"y":0,"w":20,"h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
									},
									{
										"hash":"1HRFTB7ND0",
										"type":BtnIcon(cfgColor.fontBodySub,24,0,appCfg.sharedAssets+"/run.svg",null),"id":"BtnRunActions","position":"relative","x":0,"y":0,"margin":[0,3,0,0],
										"enable":false,
										"tip":"Run Actions",
										"OnClick":function(event){
											self.ClearAction(this,event);
										},
									},
									{
										"hash":"1HL25CK140",
										"type":BtnIcon(cfgColor.fontBodySub,24,0,appCfg.sharedAssets+"/trash.svg",null),"id":"BtnClearActions","position":"relative","x":0,"y":0,"margin":[0,3,0,0],
										"enable":false,
										"tip":"Clear Actions",
										"OnClick":function(event){
											self.ClearAction(this,event);
										},
									}
								],
							},
							{
								"hash":"1HL24JH7U0",
								"type":"hud","id":"BoxEventsScroll","position":"relative","x":0,"y":0,"w":"100%","h":">calc(100% - 25px)","overflow":"auto-y","padding":[0,5,0,5],
								"minW":"","minH":50,"maxW":"","maxH":"","styleClass":"",
								children:[
									{
										"hash":"1HRERGE4B0",
										"type":DataView(null,"1HRER99Q80",actions,"",{"titleHeight":30,"titleSize":16,"titleColor":cfgColor["fontBody"],"titleBold":true,"lineHeight":30,"lineGap":5,"labelSize":12,"labelColor":cfgColor["fontBody"],"labelBold":false,"labelLine":false,"valueSize":14,"valueColor":cfgColor["fontBody"],"valueBold":false,"segHeight":20,"segSize":14,"segBold":true,"segColor":cfgColor["fontBody"],"trace":false,"edit":true,"noteSize":12,"autoCollapse":false,"hideCollapse":false,"valueRightAlign":false,"gridLine":false},""),
										"id":"DvActions","position":"relative","x":0,"y":0,
										/*#{1HRERGE4B0Codes*/
										OnPptAction(line,btn,action){
											let dataView,actVO;
											dataView=line.dataView;
											actVO=dataView.getEditedVO();
											console.log(actVO);
											self.runOneAction(line.dataView);
										}
										/*}#1HRERGE4B0Codes*/
									}
								],
							}
						],
					},
					{
						"hash":"1HU3U79P00",
						"type":"box","id":"BoxViewHeader","x":300,"y":0,"w":">calc(100% - 300px)","h":25,"padding":[0,5,0,5],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						"background":[255,255,255,1],"border":[0,0,1,0],"contentLayout":"flex-x",
						children:[
							{
								"hash":"1HU3UB4480",
								"type":BtnNaviItem("Home","Page view",[0,0,0,1],appCfg.sharedAssets+"/web.svg",undefined,txtSize.smallPlus,false,0,true),"position":"relative",
								"x":0,"y":0,"face":"focus",
								"OnClick":function(event){
									/*#{1HU41BKBO0FunctionBody*/
									self.showFace("pageView");
									/*}#1HU41BKBO0FunctionBody*/
								},
							},
							{
								"hash":"1HU3UD9HR0",
								"type":BtnNaviItem("Home","Events",[0,0,0,1],appCfg.sharedAssets+"/gas.svg",undefined,txtSize.smallPlus,false,0,true),"position":"relative","x":0,
								"y":0,
								"OnClick":function(event){
									/*#{1HU41BKBO1FunctionBody*/
									self.showFace("eventView");
									/*}#1HU41BKBO1FunctionBody*/
								},
							}
						],
					},
					{
						"hash":"1HL4REOPC0",
						"type":"box","id":"BoxModeView","x":300,"y":25,"w":">calc(100% - 300px)","h":">calc(100% - 25px)","display":0,"minW":"","minH":"","maxW":"","maxH":"",
						"styleClass":"","background":[255,255,255,1],
						children:[
							{
								"hash":"1HL5NITDK0",
								"type":"hud","id":"BoxViewScroll","x":0,"y":0,"w":"100%","h":">calc(100% - 200px)","overflow":"auto","padding":20,"minW":"","minH":"","maxW":"",
								"maxH":"","styleClass":"","contentLayout":"flex-y",
								children:[
									{
										"hash":"1HL5NLLFP0",
										"type":"box","id":"BoxPageImage","position":"relative","x":0,"y":0,"w":"100%","h":"100%","overflow":1,"minW":"","minH":"","maxW":"","maxH":"",
										"styleClass":"","background":[255,255,255,1],"border":2,"corner":6,
										children:[
											{
												"hash":"1HL5NLLFQ0",
												"type":"image","id":"ImgPage","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","fitSize":"contain",
												"repeat":false,
												"OnLoad":function(){
													/*#{1HL5NLLFQ8FunctionBody*/
													if(canvasWidth>0 && this.imageW>0){
														zmP2I=canvasWidth/this.imageW*0.5;
													}else{
														zmP2I=0.5;
													}
													boxPageImage.w=this.imageW*zmP2I+4;
													boxPageImage.h=this.imageH*zmP2I+4;
													/*}#1HL5NLLFQ8FunctionBody*/
												},
												"OnClick":function(event){
													self.imgPageOnClick(this,event);
												},
											},
											{
												"hash":"1HL6J7UQM0",
												"type":"box","id":"BoxPoseH","x":0,"y":0,"w":"100%","h":20,"display":0,"uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
												"background":[0,155,255,0],"border":[1,0,1,0],
											},
											{
												"hash":"1HL6J9QL40",
												"type":"box","id":"BoxPoseV","x":0,"y":0,"w":20,"h":"100%","display":0,"uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
												"background":[0,155,255,0],"border":[0,1,0,1],
											},
											{
												"hash":"1HL9JK6CL0",
												"type":"box","id":"BoxPose","x":270,"y":86,"w":100,"h":100,"display":0,"uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
												"background":[0,155,255,0.3],"border":1,
											}
										],
									}
								],
							},
							{
								"hash":"1HL5OABSP0",
								"type":"box","id":"BoxImgInfo","x":0,"y":">calc(100% - 200px)","w":"100%","h":175,"overflow":"auto-y","padding":5,"minW":"","minH":"","maxW":"",
								"maxH":"","styleClass":"","background":[255,255,255,1],"border":[1,0,1,0],"contentLayout":"flex-y",
								children:[
									{
										"hash":"1HL6HTJ1I0",
										"type":BoxNodeInfo(),"id":"BoxNodeInfo","position":"relative","x":0,"y":0,
									}
								],
							},
							{
								"hash":"1HLF5700O0",
								"type":"hud","id":"BoxSendAction","x":0,"y":">calc(100% - 25px)","w":"100%","h":25,"padding":[0,5,0,5],"minW":"","minH":"","maxW":"","maxH":"",
								"styleClass":"","contentLayout":"flex-x","itemsAlign":1,
							}
						],
					},
					{
						"hash":"1HU404MGI0",
						"type":"hud","id":"BoxEventView","x":300,"y":25,"w":">calc(100% - 300px)","h":">calc(100% - 25px)","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						children:[
							{
								"hash":"1HU40OQFI0",
								"type":"box","x":0,"y":0,"w":"100%","h":">calc(100% - 25px)","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["body"],
								"contentLayout":"flex-y",
								children:[
									{
										"hash":"1HU4VJKUP0",
										"type":"hud","id":"BoxEvents","x":0,"y":0,"w":250,"h":"100%","overflow":"auto-y","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
									},
									{
										"hash":"1HU504SL40",
										"type":"box","x":250,"y":0,"w":1,"h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["secondary"],
									},
									{
										"hash":"1HU6JR20P0",
										"type":"hud","id":"BoxEventInfo","position":"relative","x":250,"y":0,"w":">calc(100% - 250px)","h":"100%","overflow":"auto-y","minW":"","minH":"",
										"maxW":"","maxH":"","styleClass":"",
										children:[
											{
												"hash":"1HU6JSGK40",
												"type":DataView(null,null,null,"",{"titleHeight":30,"titleSize":18,"titleColor":cfgColor["fontBody"],"titleBold":true,"lineHeight":30,"lineGap":5,"labelSize":12,"labelColor":cfgColor["fontBody"],"labelBold":false,"labelLine":false,"valueSize":14,"valueColor":cfgColor["fontBody"],"valueBold":false,"segHeight":20,"segSize":14,"segBold":true,"segColor":cfgColor["fontBody"],"trace":false,"edit":false,"noteSize":12,"autoCollapse":false,"hideCollapse":false,"valueRightAlign":false,"gridLine":false},""),
												"id":"DvEvent","x":0,"y":0,"w":"100%","h":"100%",
											},
											{
												"hash":"1HU6KBJB00",
												"type":"box","id":"BoxCopyEvent","x":">calc(100% - 50px)","y":7,"w":36,"h":36,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":[255,255,255,1],
												"border":1,"corner":6,
												children:[
													{
														"hash":"1HU6KCPAN0",
														"type":BtnIcon("front",30,0,appCfg.sharedAssets+"/copy.svg",null),"x":"50%","y":"50%","anchorX":1,"anchorY":1,
														"OnClick":function(event){
															self.copyEvent(this,event);
														},
													}
												],
											}
										],
									}
								],
							},
							{
								"hash":"1HU40NHGT0",
								"type":"box","id":"BoxEventFooter","x":0,"y":">calc(100% - 25px)","w":"100%","h":25,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":[255,255,255,1],
								"border":[1,0,0,0],"contentLayout":"flex-x","itemsAlign":1,
								children:[
									{
										"hash":"1HU6JJJUB0",
										"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/trash.svg",null),"position":"relative","x":0,"y":0,
										"OnClick":function(event){
											self.clearEvents(this,event);
										},
									},
									{
										"hash":"1HU6OUM1B0",
										"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/menu.svg",null),"position":"relative","x":0,"y":0,
										"OnClick":function(event){
											self.eventConfig(this,event);
										},
									}
								],
							}
						],
					}
				],
			},
			{
				"hash":"1HL22PA5I0",
				"type":"box","id":"BoxFooter","x":0,"y":">calc(100% - 30px)","w":"100%","h":30,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":[255,255,255,1],
				"border":[1,0,0,0],
				children:[
					{
						"hash":"1HL4QD39G0",
						"type":"hud","x":0,"y":0,"w":">calc(100% - 300px)","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						children:[
							{
								"hash":"1HL4QDRCJ0",
								"type":NaviToolBar(true),"id":"BoxFootNavi","x":0,"y":0,
								subContainers:{
									"1HL4P0I9P0":[
										{
											"hash":"1HL4QKDA00",
											"type":BtnIcon("front",22,0,appCfg.sharedAssets+"/uitree.svg",null),"id":"BtnModeNavi","position":"relative","x":0,"y":0,"margin":[0,10,0,0],
											"OnClick":function(event){
												self.showModeNavi(this,event);
											},
										},
										{
											"hash":"1HL4QLFUF0",
											"type":BtnIcon("front",22,0,appCfg.sharedAssets+"/spot.svg",null),"id":"BtnModeQuery","position":"relative","x":0,"y":0,"margin":[0,5,0,0],
											"OnClick":function(event){
												self.showModeQuery(this,event);
											},
										},
										{
											"hash":"1HL6GESIM0",
											"type":"hud","id":"BoxModeEvent","position":"relative","x":0,"y":0,"w":22,"h":22,"margin":[0,10,0,0],"minW":"","minH":"","maxW":"","maxH":"",
											"styleClass":"",
											children:[
												{
													"hash":"1HL6GFDBO0",
													"type":BtnIcon("front",22,0,appCfg.sharedAssets+"/event.svg",null),"id":"BtnModeEvent","position":"relative","x":0,"y":0,"margin":[0,10,0,0],
													"OnClick":function(event){
														/*#{1HL6GFDBP12FunctionBody*/
														this.parent.OnClick(event);
														/*}#1HL6GFDBP12FunctionBody*/
													},
												},
												{
													"hash":"1HL6GMFG70",
													"type":"box","id":"BoxEventMark","x":">calc(100% - 10px)","y":0,"w":12,"h":12,"display":0,"uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"",
													"styleClass":"","background":cfgColor["error"],"corner":6,
												}
											],
											"OnClick":function(event){
												self.showModeEvent(this,event);
											},
										}
									]
								},
							}
						],
					}
				],
			},
			{
				"hash":"1HVNF5G9D0",
				"type":"box","id":"BoxDlgHeader","x":0,"y":0,"w":"100%","h":30,"padding":[0,5,0,5],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":[255,255,255,1],
				"border":[0,0,1,0],"contentLayout":"flex-x","itemsAlign":1,
				children:[
					{
						"hash":"1HVNIGOP30",
						"type":"text","position":"relative","x":0,"y":0,"w":"","h":"100%","uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":[0,0,0],
						"text":"AAF-Spy","fontSize":txtSize.smallPlus,"fontWeight":"bold","fontStyle":"normal","textDecoration":"","alignV":1,"flex":true,
					},
					{
						"hash":"1HVNIJMKQ0",
						"type":BtnIcon("front",28,0,appCfg.sharedAssets+"/close.svg",null),"id":"BtnClose","position":"relative","x":0,"y":0,
						"OnClick":function(event){
							self.close(this,event);
						},
					}
				],
			}
		],
		/*#{1GGJKM84D1ExtraCSS*/
		/*}#1GGJKM84D1ExtraCSS*/
		faces:{
			"openPage":{
				/*BoxState*/"#1HL247PKA0":{
					"alpha":0.6
				},
				/*BtnHistory*/"#1HL24FPD80":{
					"enable":false
				},
				/*BtnViewDoc*/"#1HL256IOU0":{
					"enable":false
				},
				/*BtnFindNode*/"#1HL2591OS0":{
					"enable":false
				},
				/*BtnRead*/"#1HSKB5OHA0":{
					"enable":false
				},
				/*BtnRefillQuery*/"#1HL5MC9T20":{
					"enable":false
				},
				/*BtnOpenActions*/"#1HRFT6IG60":{
					"enable":false
				},
				/*BtnSaveActions*/"#1HRFT76200":{
					"enable":false
				},
				/*BtnRunActions*/"#1HRFTB7ND0":{
					"enable":false
				},
				/*BtnClearActions*/"#1HL25CK140":{
					"enable":false
				}
			},"pageReady":{
				/*BoxState*/"#1HL247PKA0":{
					"alpha":1
				},
				/*BtnHistory*/"#1HL24FPD80":{
					"enable":true
				},
				/*BoxMid*/"#1HL22OAA50":{
					"display":1
				},
				/*BtnViewDoc*/"#1HL256IOU0":{
					"enable":true
				},
				/*BtnFindNode*/"#1HL2591OS0":{
					"enable":true
				},
				/*BtnRead*/"#1HSKB5OHA0":{
					"enable":true
				},
				/*BtnRefillQuery*/"#1HL5MC9T20":{
					"enable":true
				},
				/*BtnOpenActions*/"#1HRFT6IG60":{
					"enable":true
				},
				/*BtnSaveActions*/"#1HRFT76200":{
					"enable":true
				},
				/*BtnRunActions*/"#1HRFTB7ND0":{
					"enable":true
				},
				/*BtnClearActions*/"#1HL25CK140":{
					"enable":true
				},
				/*BoxFooter*/"#1HL22PA5I0":{
					"display":1
				},
				/*#{1HL26Q52O0Code*/
				$(){
					boxFootNavi.moveTab(false);
				}
				/*}#1HL26Q52O0Code*/
			},"modeNavi":{
				/*BoxModeNavi*/"#1HL23283C0":{
					"display":1,"w":300
				},
				/*BoxQueryFrame*/"#1HL5MC9T00":{
					"display":0
				},
				/*BoxEventsFrame*/"#1HL23VHIQ0":{
					"display":0
				},
				/*BoxModeView*/"#1HL4REOPC0":{
					"display":1
				},
				/*#{1HL4R98SI0Code*/
				$(){
					uiMode="Navi";
				}
				/*}#1HL4R98SI0Code*/
			},"modeEvent":{
				/*BoxModeNavi*/"#1HL23283C0":{
					"display":0,"w":">calc(100% - 300px)"
				},
				/*BoxQueryFrame*/"#1HL5MC9T00":{
					"display":0
				},
				/*BoxEventsFrame*/"#1HL23VHIQ0":{
					"display":1
				},
				/*BoxModeView*/"#1HL4REOPC0":{
					"display":1
				},
				/*#{1HL4RBDGD1Code*/
				$(){
					uiMode="Event";
				}
				/*}#1HL4RBDGD1Code*/
			},"modeQuery":{
				/*BoxModeNavi*/"#1HL23283C0":{
					"display":0
				},
				/*BoxQueryFrame*/"#1HL5MC9T00":{
					"display":1
				},
				/*BoxEventsFrame*/"#1HL23VHIQ0":{
					"display":0
				},
				/*BoxModeView*/"#1HL4REOPC0":{
					"display":1
				},
				/*#{1HL4RBDGD3Code*/
				$(){
					if(uiMode==="Navi"){
						let node;
						//Set target query node
						if(!hotNodeLine){
							uiMode="Query";
							return;
						}
						node=hotNodeLine.node;
						self.setQueryTarget(node);
					}
					uiMode="Query";
				}
				/*}#1HL4RBDGD3Code*/
			},"init":{
				/*BoxBG*/"#1HVNF199H0":{
					"display":0
				},
				/*TxtInitTip*/"#1HMJURVH80":{
					"display":1
				},
				/*BoxMid*/"#1HL22OAA50":{
					"display":0
				},
				/*BoxFooter*/"#1HL22PA5I0":{
					"display":0
				},
				/*BoxDlgHeader*/"#1HVNF5G9D0":{
					"display":0
				}
			},"pageView":{
				"#1HU3UB4480":{
					"face":"focus"
				},
				"#1HU3UD9HR0":{
					"face":"blur"
				},
				/*BoxModeView*/"#1HL4REOPC0":{
					"display":1
				},
				/*BoxEventView*/"#1HU404MGI0":{
					"display":0
				}
			},"eventView":{
				"#1HU3UB4480":{
					"face":"blur"
				},
				"#1HU3UD9HR0":{
					"face":"focus"
				},
				/*BoxModeView*/"#1HL4REOPC0":{
					"display":0
				},
				/*BoxEventView*/"#1HU404MGI0":{
					"display":1
				}
			},"dialog":{
				"#self":{
					"anchorX":1
				},
				/*BoxBG*/"#1HVNF199H0":{
					"display":1
				},
				/*BoxDlgHeader*/"#1HVNF5G9D0":{
					"display":1
				}
			}
		},
		OnCreate:function(){
			self=this;
			btnBrowser=self.BtnBrowser;txtBrowser=self.TxtBrowser;btnWaitPage=self.BtnWaitPage;btnHistory=self.BtnHistory;edURL=self.EdURL;btnHeadless=self.BtnHeadless;btnDevTools=self.BtnDevTools;btnViewport=self.BtnViewport;edViewportW=self.EdViewportW;edViewportH=self.EdViewportH;boxNaviScroll=self.BoxNaviScroll;boxNodesList=self.BoxNodesList;boxQueryBlocks=self.BoxQueryBlocks;btnGenQuery=self.BtnGenQuery;edQuery=self.EdQuery;btnQuery=self.BtnQuery;btnUseQuery=self.BtnUseQuery;boxQueryResults=self.BoxQueryResults;boxEventsFrame=self.BoxEventsFrame;boxEventsScroll=self.BoxEventsScroll;dvActions=self.DvActions;boxPageImage=self.BoxPageImage;imgPage=self.ImgPage;boxPoseH=self.BoxPoseH;boxPoseV=self.BoxPoseV;boxPose=self.BoxPose;boxNodeInfo=self.BoxNodeInfo;boxEventView=self.BoxEventView;boxEvents=self.BoxEvents;dvEvent=self.DvEvent;boxCopyEvent=self.BoxCopyEvent;boxFootNavi=self.BoxFootNavi;btnModeNavi=self.BtnModeNavi;btnModeQuery=self.BtnModeQuery;boxModeEvent=self.BoxModeEvent;btnModeEvent=self.BtnModeEvent;boxEventMark=self.BoxEventMark;
			/*#{1GGJKM84D1Create*/
			if(!app.mainUI){
				document.title="AI2Apps Browser Spy: [AAHOME]";
			}
			VFACT.applyMoveDrag(self.BoxDlgHeader,self);
			app.aafMainUI=self;
			self.showFace("modeNavi");
			self.init();
			/*}#1GGJKM84D1Create*/
		},
		/*#{1GGJKM84D1EndCSS*/
		/*}#1GGJKM84D1EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.init=async function(){
		/*#{1HLC9JIP00Start*/
		let path,json;
		/*}#1HLC9JIP00Start*/
		
		//ReadUsage
		/*#{1HLC9JIP01*/
		self.showFace("init");
		path=app.path2AppFilePath("usage.json");
		try{
			json=await tabFS.readFile(path,"utf8");
			json=JSON.parse(json);
		}catch(err){
			json={
				lastURL:"",
				history:[],
				browsers:[],
				lastBrowser:""
			};
		}
		usageJSON=json;
		if(json.lastURL){
			edURL.text=json.lastURL;
			if(json.history && json.history.length>0){
				btnHistory.enable=true;
			}
		}
		if(json.lastBrowser){
			openBrowserAlias=json.lastBrowser;
			txtBrowser.text=openBrowserAlias;
		}
		/*}#1HLC9JIP01*/
	};
	//------------------------------------------------------------------------
	cssVO.openPage=async function(sender,event){
		/*#{1HL25IP6J0Start*/
		let url,title,useAAEE=false;
		/*}#1HL25IP6J0Start*/
		
		//CheckAAEE
		/*#{1HNP4TGOC0*/
		if(!browser){
			browser=await farm.openBrowser(openBrowserAlias,{headless:btnHeadless.checked,devtools:btnDevTools.checked});
		}
		//page=await browser.newPage();
		if(!page){
			let w,h;
			page=await browser.newPage();
			w=parseInt(edViewportW.text)||800;
			h=parseInt(edViewportH.text)||600;
			await page.setViewport({width:w,height:h});
		}
		/*}#1HNP4TGOC0*/
		
		//GetURL
		/*#{1HL25PSC60*/
		url=edURL.text;
		/*}#1HL25PSC60*/
		self.showFace("openPage");
		
		//OpenClient
		/*#{1HL25TEIL0*/
		await page.goto(edURL.text);
		/*}#1HL25TEIL0*/
		
		//Wait page load.
		/*#{1HL262SG50*/
		url=await page.getURL();
		title=await page.getTitle();
		pageInfo={url,title};
		console.log("Page loaded: ");
		console.log(pageInfo);
		/*}#1HL262SG50*/
		self.showFace("pageReady");
		
		//ShowPageView
		/*#{1HL3ABDV20*/
		await self.showPageView(true);
		
		//Update usage:
		if(usageJSON && pageInfo && pageInfo.url){
			let list,idx;
			usageJSON.lastURL=url;
			list=usageJSON.history;
			idx=list.findIndex((item)=>item.url===url);
			if(idx>=0){
				list.splice(idx,1);
			}
			list.unshift({url:pageInfo.url,title:pageInfo.title});
			tabFS.writeFile(app.path2AppFilePath("usage.json"),JSON.stringify(usageJSON,null,"\t"));
		}
		/*}#1HL3ABDV20*/
		
		//WatchPage
		/*#{1HL3PATVK0*/
		/*}#1HL3PATVK0*/
	};
	//------------------------------------------------------------------------
	cssVO.clearEvents=async function(sender,event){
		/*#{1HL25E0NJ0Start*/
		//TODO: Fix this:
		boxEventsList.clearChildren();
		/*}#1HL25E0NJ0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.showPageView=async function(delay){
		/*#{1HL3ABDV21Start*/
		let bodyNodeView=null;
		let imgData=null;
		
		function markNode(node){
			let sub,subs;
			subs=node.children;
			if(subs){
				for(sub of subs){
					sub.parent=node;
					markNode(sub);
				}
			}
			node.hud=null;
		}
		/*}#1HL3ABDV21Start*/
		
		//GetPageView
		/*#{1HL3ABDV30*/
		self.showFace("pageView");
		self.focusViewNode(null);
		//await page.active();
		boxNodesList.clearChildren();
		if(delay!==false){
			await sleep(1000);
		}
		bodyNodeView=await page.readView(null,{compactTree:false,output:"tree"});
		imgData=await page.screenshot();
		viewRootNode=bodyNodeView;
		if(bodyNodeView){
			markNode(bodyNodeView);
		}
		self.updateView(bodyNodeView,imgData);
		self.tracePage();
		/*}#1HL3ABDV30*/
	};
	//------------------------------------------------------------------------
	cssVO.updateView=async function(nodes,imgData){
		/*#{1HL3ALN380Start*/
		if(!Array.isArray(nodes)){
			nodes=[nodes];
		}
		/*}#1HL3ALN380Start*/
		VFACT.syncDataList2View(boxNodesList,nodes,nodeCSS,true);
		
		//UpdateImage
		/*#{1HL5NC5UI0*/
		if(nodes[0]){
			canvasWidth=nodes[0].rect.width;
		}else{
			canvasWidth=0;
		}
		imgPage.image=imgData;
		/*}#1HL5NC5UI0*/
	};
	//------------------------------------------------------------------------
	cssVO.drawNode=async function(node){
		/*#{1HVPLPPBN0Start*/
		if(node){
			let rect=node.rect;
			if(rect){
				boxNodeInfo.showInfo(page,node);
		
				boxPose.display=true;
				boxPose.x=rect.x*0.5;
				boxPose.w=rect.width*0.5;
				boxPose.y=rect.y*0.5;
				boxPose.h=rect.height*0.5;
		
				boxPoseH.display=true;
				boxPoseH.y=rect.y*0.5;
				boxPoseH.h=rect.height*0.5;
		
				boxPoseV.display=true;
				boxPoseV.x=rect.x*0.5;
				boxPoseV.w=rect.width*0.5;
			}else{
				boxPose.display=false;
				boxPoseV.display=false;
				boxPoseH.display=false;
			}
		}
		/*}#1HVPLPPBN0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.focusViewNode=async function(line){
		/*#{1HL3E0TG90Start*/
		if(hotNodeLine){
			if(hotNodeLine===line){
				hotNodeLine.showFace("blur");
				hotNodeLine=null;
				return;
			}
			hotNodeLine.showFace("blur");
		}
		hotNodeLine=line;
		if(line){
			line.showFace("focus");
			self.drawNode(line.node);
			state.curNode=line.node;
		}else{
			boxPose.display=false;
			boxPoseV.display=false;
			boxPoseH.display=false;
			boxNodeInfo.showInfo(client,null);
			state.curNode=null;
		}
		/*}#1HL3E0TG90Start*/
	};
	//------------------------------------------------------------------------
	cssVO.addEvent=async function(data){
		/*#{1HL3T1KDA0Start*/
		if(!boxEventsFrame.display){
			boxEventMark.display=true;
		}
		if(data.type==="event" && data.event==="input"){
			let lastEvent=events[events.length-1];
			if(lastEvent && lastEvent.hud && lastEvent.type==="event" && lastEvent.event==="input" && lastEvent.target.aaeId===data.event.aaeId){
				//Remove last event stub:
				events.pop();
				boxEventsList.removeChild(lastEvent.hud);
			}
		}
		events.push(data);
		boxEventsList.appendNewChild(eventCSS(data));
		/*}#1HL3T1KDA0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.showModeNavi=function(sender,event){
		/*#{1HL5MTCII0Start*/
		/*}#1HL5MTCII0Start*/
		self.showFace("modeNavi");
	};
	//------------------------------------------------------------------------
	cssVO.showModeEvent=function(){
		/*#{1HL5N0K4N0Start*/
		boxEventMark.display=false;
		/*}#1HL5N0K4N0Start*/
		self.showFace("modeEvent");
	};
	//------------------------------------------------------------------------
	cssVO.showModeQuery=function(){
		/*#{1HL5N0K4N1Start*/
		/*}#1HL5N0K4N1Start*/
		self.showFace("modeQuery");
	};
	//------------------------------------------------------------------------
	cssVO.imgPageOnClick=async function(sender,event){
		/*#{1HL9L7USU0Start*/
		let x,y,curAAEId,minAAEId,maxAAEId,pickedNodes,node,time;
		function picNode(node){
			let subs,sub,rect;
			if(isPicked(node,x,y)){
				pickedNodes.push(node);
			}
			rect=node.rect;
			if(rect && (rect.width>0 || rect.height>0)){
				subs=node.children;
				if(subs){
					for(sub of subs){
						picNode(sub);
					}
				}
			}
		}
		node=null;
		pickedNodes=[];
		x=event.offsetX*zmI2P;
		y=event.offsetY*zmI2P;
		picNode(viewRootNode);
		time=Date.now();
		if(lastPickTime>0 && time-lastPickTime<2000 && lastPickX===x && lastPickY===y){
			let curNode,idx;
			if(uiMode==="Query"){
				curNode=tgtQueryNode;
			}else{
				curNode=hotNodeLine?hotNodeLine.node:null;
			}
			idx=pickedNodes.indexOf(curNode);
			if(idx>0){
				node=pickedNodes[idx-1];
			}else{
				node=pickedNodes[pickedNodes.length-1];
			}
		}else{
			node=pickedNodes[pickedNodes.length-1];
		}
		lastPickX=x;
		lastPickY=y;
		lastPickTime=time;
		if(node){
			self.showNode(node,true,true);
		}
		/*}#1HL9L7USU0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.showNode=async function(node,open,scroll){
		/*#{1HLA091M50Start*/
		let hud=node.hud;
		let pnode,phud;
		if(uiMode==="Query"){
			self.drawNode(node);
			self.setQueryTarget(node);
			return;
		}else if(uiMode!=="Navi"){
			btnModeNavi.OnClick();
		}
		pnode=node.parent;
		if(hud){
			if(!hud.webObj.offsetParent){
				if(!open||!pnode){
					return null;
				}
				phud=await self.showNode(pnode,true);
				phud.open();
			}
			if(scroll){
				VFACT.scrollToShow(hud,boxNaviScroll);
				self.focusViewNode(hud);
			}
			return hud;
		}
		if(!open||!pnode){
			return null;
		}
		phud=await self.showNode(pnode,true,false);
		phud.open();
		hud=node.hud;
		if(!hud){
			return null;
		}
		if(scroll){
			VFACT.scrollToShow(hud,boxNaviScroll);
			self.focusViewNode(hud);
		}
		return hud;
		/*}#1HLA091M50Start*/
	};
	//------------------------------------------------------------------------
	cssVO.getNodeByAAEId=function(aaeId){
		/*#{1HLC87P2M0Start*/
		function checkNode(node){
			let subs,sub,ret;
			if(node.AAEId===aaeId){
				return node;
			}
			subs=node.children;
			if(subs){
				for(sub of subs){
					ret=checkNode(sub);
					if(ret){
						return ret;
					}
				}
			}
			return null;
		}
		return checkNode(viewRootNode);
		/*}#1HLC87P2M0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.openHistory=async function(sender,event){
		/*#{1HLEHV5M70Start*/
		let items,list,item;
		if(!usageJSON){
			return;
		}
		list=usageJSON.history;
		items=list.map((item)=>{return {text:item.title,url:item.url}});
		item=await app.modalDlg("/@StdUI/ui/DlgMenu.js",{
			items:items,hud:btnHistory,
		});
		if(!item){
			return;
		}
		edURL.text=item.url;
		self.openPage(); 
		/*}#1HLEHV5M70Start*/
	};
	//------------------------------------------------------------------------
	cssVO.clearQuery=async function(){
		/*#{1HVPOP28N0Start*/
		tgtQueryNode=null;
		edQuery.text="";
		self.clearQueryResults();
		boxQueryBlocks.clearChildren();
		btnGenQuery.display=false; 
		btnUseQuery.display=false;
		/*}#1HVPOP28N0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.setQueryTarget=async function(node){
		/*#{1HVPQ4FP40Start*/
		let css,line;
		let nodeList=[];
		if(node===tgtQueryNode){
			return;
		}
		self.clearQuery();
		tgtQueryNode=node;
		if(!node){
			return;
		}
		btnGenQuery.display=true;
		while(node){
			nodeList.unshift(node);
			node=await page.getNodeParent(node);
			if(node && node.tagName==="HTML"){
				break;
			}
		}
		for(node of nodeList){
			css=BoxQueryBlock(page,node);
			line=boxQueryBlocks.appendNewChild(css);
		}
		line.showFace("use");
		/*}#1HVPQ4FP40Start*/
	};
	//------------------------------------------------------------------------
	cssVO.fillQuery=async function(nodeLine,node){
		/*#{1HLEMFR7B0Start*/
		btnModeQuery.OnClick();
		/*}#1HLEMFR7B0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.updateQueryBlock=async function(block,node){
		/*#{1HMK6RHE40Start*/
		/*}#1HMK6RHE40Start*/
	};
	//------------------------------------------------------------------------
	cssVO.clearQueryResults=async function(){
		/*#{1HVPMSEDU0Start*/
		hotQueryLine=null;
		boxQueryResults.clearChildren();
		/*}#1HVPMSEDU0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.focusQueryNode=async function(nodeLine){
		/*#{1HVPMJJOB0Start*/
		if(hotQueryLine===nodeLine){
			return;
		}
		if(hotQueryLine){
			hotQueryLine.showFace("blur");
		}
		hotQueryLine=nodeLine;
		if(hotQueryLine){
			hotQueryLine.showFace("focus");
		}
		/*}#1HVPMJJOB0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.doQuery=async function(sender,event){
		/*#{1HLEQEAV20Start*/
		let queryText,list,i,n,node,css,line,tgtId;
		if(tgtQueryNode){
			tgtId=tgtQueryNode.AAEId;
		}else if(!hotNodeLine){
			tgtId=null;
		}else{
			tgtId=hotNodeLine.node.AAEId;
		}
		queryText=edQuery.text;
		list=await page.queryNodes(null,queryText,{filterVisible:false});
		console.log("Query resutl:");
		console.log(list);
		self.clearQueryResults();
		n=list.length;
		if(n>0){
			btnUseQuery.display=true;
			for(i=0;i<n;i++){
				css={
					type:BtnNodeLine(client,list[i],false),poisition:"relative",//uiEvent:-1,
					OnClick(sender){
						let node=this.node;
						self.focusQueryNode(this);
						self.drawNode(node);
					}
				};
				line=boxQueryResults.appendNewChild(css);
				if(tgtId && list[i].AAEId!==tgtId){
					line.alpha=0.5;
				}
			}
		}else{
			btnUseQuery.display=false;
			css={
				type:"text",poisition:"relative",text:"No element match your selector string.",w:"100%",alignH:1,color:cfgColor.fontBodySub,fontSize:txtSize.small,margin:[5,0,5,0]
			};
			boxQueryResults.appendNewChild(css);
		}
		/*}#1HLEQEAV20Start*/
	};
	//------------------------------------------------------------------------
	cssVO.pickPage=async function(sender,event){
		/*#{1HMCK7G700Start*/
		let result,pages,i,n,item;
		if(!browser){
			browser=await farm.openBrowser(openBrowserAlias,{headless:btnHeadless.checked,devtools:btnDevTools.checked});
		}
		pages=await browser.getPages();
		n=pages.length;
		for(i=0;i<n;i++){
			pages[i].title=await pages[i].getTitle();
			pages[i].url=await pages[i].getURL();
		}
		//Show pages list for choose:
		item=await app.modalDlg("/@StdUI/ui/DlgMenu.js",{
			hud:btnWaitPage,
			items:pages.map((item,idx)=>{return {text:(idx+1)+": "+item.title,page:item};})
		});
		if(!item){
			return;
		}
		page=item.page;
		self.showFace("pageReady");
		await self.showPageView(true);
		/*}#1HMCK7G700Start*/
	};
	//------------------------------------------------------------------------
	cssVO.AddAction=async function(){
		/*#{1HPKRSTCP0Start*/
		/*}#1HPKRSTCP0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.ClearAction=async function(){
		/*#{1HPKRSTCP1Start*/
		/*}#1HPKRSTCP1Start*/
	};
	//------------------------------------------------------------------------
	cssVO.getActionArgs=function(){
		/*#{1HSIRK3QG0Start*/
		let dvArgs,argList,args,arg;
		dvArgs=dvActions.getPptLine("arguments");
		argList=dvArgs.getEditedVO();
		args={};
		for(arg of argList){
			args[arg.name]=arg.value;
		}
		return args;
		/*}#1HSIRK3QG0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.runOneAction=async function(dv){
		/*#{1HSIR1NQV0Start*/
		let actVO,args;
		actVO=dv.getEditedVO();
		args=self.getActionArgs();
		page.runActionChain(actVO,args);
		/*}#1HSIR1NQV0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.runActions=async function(){
		/*#{1HSIRKN8U0Start*/
		let actVO,args;
		args=self.getActionArgs();
		actVO=dvActions.getEditedVO().actions;
		page.runActionChain(actVO,args);
		/*}#1HSIRKN8U0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.doSaveAction=async function(){
		/*#{1HSJ7IRME0Start*/
		let path;
		path=VFACT.appDirFilePath+"/actions";
		app.showDlg("/@homekit/ui/DlgFile.js",{
			mode:"save",
			path:path,
			buttonText:(($ln==="CN")?("保存"):/*EN*/("Save")),
			options:{
				multiSelect:false,
				preview:true,
			},
			callback:async function(filePath){
				if(!filePath){
					return;
				}
				try{
					let vo,code;
					vo=dvActions.getEditedVO();
					await tabFS.writeFile(filePath,JSON.stringify(vo,null,"\t"),"utf8");
				}catch(e){
				}
			}
		});
		/*}#1HSJ7IRME0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.doReadAction=async function(){
		/*#{1HSJ7IRME1Start*/
		let path;
		path=VFACT.appDirFilePath+"/actions";
		app.showDlg("/@homekit/ui/DlgFile.js",{
			mode:"open",
			path:path,
			buttonText:(($ln==="CN")?("读取"):/*EN*/("Open")),
			options:{
				multiSelect:false,
				preview:true,
			},
			callback:async function(filePath){
				if(!filePath){
					return;
				}
				try{
					let vo,code;
					code=await tabFS.readFile(filePath,"utf8");
					vo=JSON.parse(code);
					dvActions.setObject(null,vo,null);
				}catch(e){
				}
			}
		});
		/*}#1HSJ7IRME1Start*/
	};
	//------------------------------------------------------------------------
	cssVO.doClearAction=async function(){
		/*#{1HSJ7IRME2Start*/
		/*}#1HSJ7IRME2Start*/
	};
	//------------------------------------------------------------------------
	cssVO.showViewportMenu=async function(sender,event){
		/*#{1HSJB79K40Start*/
		let w,h;
		/*}#1HSJB79K40Start*/
		{
			let $items,$item;
			$items=[
				{id:"375x750",text:"375x750"},
				{id:"800x600",text:"800x600"},
				{id:"1024x768",text:"1024x768"},
				{id:"1280x1024",text:"1280x1024"},
				{id:"1600x900",text:"1600x900"}
			];
			$item=await VFACT.app.modalDlg("/@StdUI/ui/DlgMenu.js",{hud:btnViewport,items:$items});
			if($item){
				if($item.id==="375x750"){
					/*#{1HSJBHIHC0*/
					w=375;h=750;
					/*}#1HSJBHIHC0*/
				}else if($item.id==="800x600"){
					/*#{1HSJBC1HI0*/
					w=800;h=600;
					/*}#1HSJBC1HI0*/
				}else if($item.id==="1024x768"){
					/*#{1HSJBC1HI1*/
					w=1024;h=768;
					/*}#1HSJBC1HI1*/
				}else if($item.id==="1280x1024"){
					/*#{1HSJBC1HI2*/
					w=1280;h=1024;
					/*}#1HSJBC1HI2*/
				}else if($item.id==="1600x900"){
					/*#{1HSJBHIHC1*/
					w=1600;h=900;
					/*}#1HSJBHIHC1*/
				}
			}
		}
		
		//SetEdit
		/*#{1HSJBHIHC2*/
		edViewportW.text=""+w;
		edViewportH.text=""+h;
		/*}#1HSJBHIHC2*/
	};
	//------------------------------------------------------------------------
	cssVO.readView=async function(sender,event){
		/*#{1HSKB6IDL0Start*/
		let node,content;
		node=hotNodeLine?hotNodeLine.node:null;
		/*}#1HSKB6IDL0Start*/
		{
			let $items,$item;
			$items=[
				{id:"HTML",text:"Read Inner-HTML"},
				{id:"Text",text:"Read Inner-Text"},
				{id:"View",text:"Read JSON-View"},
				{id:"Article",text:"Read Article"}
			];
			$item=await VFACT.app.modalDlg("/@StdUI/ui/DlgMenu.js",{hud:sender,items:$items});
			if($item){
				if($item.id==="HTML"){
					/*#{1HSKBBRMP0*/
					content=await page.readInnerHTML(node,{compact:1,cleanMarks:true});
					//content=await page.readInnerHTML(node);
					/*}#1HSKBBRMP0*/
				}else if($item.id==="Text"){
					/*#{1HSKBBRMP1*/
					content=await page.readInnerText(node);
					/*}#1HSKBBRMP1*/
				}else if($item.id==="View"){
					/*#{1HSKBBRMP2*/
					content=await page.readView(node,{compactTree:false,output:"tree"});
					/*}#1HSKBBRMP2*/
				}else if($item.id==="Article"){
					/*#{1HSKBMM2C0*/
					content=await page.readArticle();
					/*}#1HSKBMM2C0*/
				}
			}
		}
		
		//Read
		/*#{1HSKBT2CK0*/
		/*}#1HSKBT2CK0*/
		
		//Show Result
		/*#{1HSKBT2CK1*/
		if(content){
			console.log(content);
			console.log(content.length);
			app.showTip(sender,"Result is shown in browser console.");
		}
		/*}#1HSKBT2CK1*/
	};
	//------------------------------------------------------------------------
	cssVO.clearEvents=async function(sender,event){
		/*#{1HU6JKP700Start*/
		boxEvents.clearChildren();
		dvEvent.setObject(null,null);
		/*}#1HU6JKP700Start*/
	};
	//------------------------------------------------------------------------
	cssVO.copyEvent=async function(sender,event){
		/*#{1HU6LENEL0Start*/
		if(!curEventBtn)
			return;
		let obj=curEventBtn.event;
		navigator.clipboard.writeText(JSON.stringify(obj,null,"\t"));
		app.showTip(boxCopyEvent,"Copied into clipboard.");
		/*}#1HU6LENEL0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.eventConfig=async function(sender,event){
		/*#{1HU6P0BN10Start*/
		let cfg,list,i,n,btn;
		cfg=await app.modalDlg("/@StdUI/ui/DlgDataView.js",{
			hud:self,
			x:(self.w-360)/2,y:30,
			template:ActionFilter,object:eventConfig,
			title:"Event filters"
		});
		Object.assign(eventConfig,cfg);
		if(eventConfig.network){
			eventFilter.add("request");
			eventFilter.add("response");
		}else{
			eventFilter.delete("request");
			eventFilter.delete("response");
		}
		if(eventConfig.navigation){
			eventFilter.add("load");
			eventFilter.add("popup");
		}else{
			eventFilter.delete("load");
			eventFilter.delete("popup");
		}
		if(eventConfig.action){
			eventFilter.add("click");
			eventFilter.add("dblclick");
			eventFilter.add("keydown");
			eventFilter.add("input");
		}else{
			eventFilter.delete("click");
			eventFilter.delete("dblclick");
			eventFilter.delete("keydown");
			eventFilter.delete("input");
		}
		//Filter events
		list=boxEvents.children;
		n=list.length;
		for(i=0;i<n;i++){
			btn=list[i];
			if(eventFilter.has(btn.event.event)){
				btn.display=true;
			}else{
				btn.display=false;
			}
		}
		/*}#1HU6P0BN10Start*/
	};
	//------------------------------------------------------------------------
	cssVO.pickBrowser=async function(sender,event){
		/*#{1HUB11E740Start*/
		let liveBrowsers,items,list,item,browser,alias,browserId,liveSet;
		liveSet=new Set();
		liveBrowsers=await farm.getBrowsers();
		items=[];
		for(browser of liveBrowsers){
			items.push({text:browser.alias+`: ${browser.pages.length} pages`,alias:browser.alias,browserId:browser.id});
			liveSet.add(browser.alias);
		}
		if(usageJSON && usageJSON.browsers){
			let i,n;
			list=usageJSON.browsers;
			n=list.length;
			for(i=0;i<n;i++){
				alias=list[i];
				if(!liveSet.has(alias)){
					items.push({text:"Open: "+alias,alias:alias});
				}
			}
		}
		items.push({text:"New Temporary Browser",alias:""});
		items.push({text:"New Aliased Browser",alias:null});
		item=await app.modalDlg("/@StdUI/ui/DlgMenu.js",{
			items:items,hud:btnBrowser,
		});
		if(!item){
			return;
		}
		browserId=item.browserId;
		alias=item.alias;
		if(browserId){
			openBrowserId=browserId;
			openBrowserAlias=alias;
			openBrowserWithDir=false;
		}else if(alias){
			openBrowserId=null;
			openBrowserAlias=alias;
			openBrowserWithDir=true;
		}else if(alias===null){
			//TODO: ask a new alias and if use data-dir:
			let cfg=await app.modalDlg("/@StdUI/ui/DlgDataView.js",{
				hud:self,
				x:(self.w-360)/2,y:30,
				template:BrowserArgs,object:eventConfig,
				title:"New browser"
			});
			if(!cfg){
				return;
			}
			openBrowserAlias=cfg.alias;
			openBrowserWithDir=cfg.dataDir;
		}else if(alias===""){
			openBrowserId=null;
			openBrowserAlias="";
			openBrowserWithDir=false;
		}
		await self.openBrowser();
		if(browser){
			txtBrowser.text=openBrowserAlias;
		}
		/*}#1HUB11E740Start*/
	};
	//------------------------------------------------------------------------
	cssVO.close=async function(sender,event){
		/*#{1HVNILP2L0Start*/
		app.closeDlg(self);
		/*}#1HVNILP2L0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.useQuery=async function(sender,event){
		/*#{1HVPUBCI70Start*/
		app.closeDlg(self,edQuery.text);
		/*}#1HVPUBCI70Start*/
	};
	//------------------------------------------------------------------------
	cssVO.queryWithAI=async function(sender,event){
		/*#{1I01V500Q0Start*/
		let aaeId;
		if(tgtQueryNode){
			aaeId=tgtQueryNode.AAEId;
		}
		app.showDlg("/@aichat/ui/DlgAIChat.js",{url:"/@aae/ai/SmartQuery.js",prompt:{targetPage:page,aaeId},autoClose:false,clearChat:true},"AgentHelper");
		/*}#1I01V500Q0Start*/
	};
	/*#{1GGJKM84D1PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.showDlg=function(vo){
		farm=vo.aaf;
		browser=vo.browser;
		page=vo.page;
		self.w=1000;
		self.h=700;
		self.x=(self.parent.w-100)*0.5;
		self.y=0;
		self.showFace("modeNavi");
		self.showFace("init");
		self.showFace("pageReady");
		self.showFace("dialog");
		self.animate({type:"pose",y:20,time:80});
		btnModeNavi.OnClick();
		self.showPageView(false).then(()=>{
			if(vo.query){
				self.clearQuery();
				edQuery.text=vo.query;
				btnModeQuery.OnClick();
				self.doQuery(btnQuery,{});
			}
		})
	};
	
	//------------------------------------------------------------------------
	cssVO.openBrowser=async function(){
		if(!browser){
			let opts;
			opts={headless:btnHeadless.checked,devtools:btnDevTools.checked};
			if(openBrowserAlias && openBrowserWithDir){
				opts.autoDataDir=true;
			}
			browser=await farm.openBrowser(openBrowserAlias,opts);
			openBrowserAlias=browser.alias;
		}
		if(browser){
			let alias,list,idx;
			btnBrowser.enable=false;
			//Update usage:
			alias=browser.alias;
			if(usageJSON && (!alias.startsWith("TMP_"))){
				list=usageJSON.browsers||[];
				idx=list.indexOf(alias);
				if(idx>=0){
					list.splice(idx,1);
				}
				list.unshift(alias);
				usageJSON.browsers=list;
				usageJSON.lastBrowser=alias;
				tabFS.writeFile(app.path2AppFilePath("usage.json"),JSON.stringify(usageJSON,null,"\t"));
			}
		}
	};
	
	//------------------------------------------------------------------------
	function mergeQuery(list,len){
		let i,stub,query;
		query="";
		if(!len){
			len=list.length;
		}
		for(i=0;i<len;i++){
			stub=list[i];
			query=`(${query}//${stub.query})`;
			if(stub.idx>0){
				query=`(${query}[${stub.idx}])`;
			}
		}
		return query;
	}
	
	//------------------------------------------------------------------------
	function buildAction(vo,args){
		//TODO: Code this:
	}
	
	//------------------------------------------------------------------------
	function buildActions(vo){
		let actions,actAry,act,args,argAry,arg;
		argAry=vo.arguments||[];
		actAry=vo.actions||[];
		args={};
		for(arg of argAry){
			args[arg.name]=arg.value;
		}
		args={
			keys:Object.keys(args),
			values:Object.values(args),
		};
		actions=[];
		for(act of actAry){
			actions.push(buildAction(act,args));
		}
		return actions;
	}
	
	//------------------------------------------------------------------------
	app.buildQuery=cssVO.buildQuery=async function(){
		let blocks,i,n,block,queryList,queryString,result,node,m,j,idx;
		app.showWait("Building querry...",0);
		blocks=boxQueryBlocks.children;
		n=blocks.length;
		queryList=[];
		queryString="";
		for(i=0;i<n;i++){
			block=blocks[i];
			node=block.node;
			if(block.buildQuery && block.inQuery){
				block.buildQuery(queryList);
				//Run current query and locate this block's node:
				queryString=mergeQuery(queryList);
				result=await page.queryNodes(null,queryString);
				//result = document.evaluate(queryString, document, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);
				idx=-1;
				m=0;
				if(result){
					m=result.length
					for(j=0;j<m;j++){
						if(result[j].AAEId===node.AAEId){
							idx=j;
							break;
						}
					}
				}
				block.setQueryIndex(idx,m);
			}
		}
		app.closeWait();
		edQuery.text=mergeQuery(queryList);
		self.doQuery();
	};
	
	//------------------------------------------------------------------------
	let traceCallback=async function(data){
		let btn;
		//console.log("EVENT:");
		//console.log(data);
		if(data.event==="input"){
			let lastEvent=events[events.length-1];
			if(lastEvent && lastEvent.hud && lastEvent.event==="input" && lastEvent.target.aaeId===data.target.aaeId){
				//Remove last event stub:
				events.pop();
				boxEvents.removeChild(lastEvent.hud);
			}
		}
		events.push(data);
		btn=boxEvents.appendNewChild({
			type:BtnEvent(data),position:"relative",event:data,
			OnClick(evt){
				self.focusEvent(this);
			},
			showNode(node){
				node=self.getNodeByAAEId(node.AAEId);
				if(node){
					self.showNode(node,true,true);
					self.showFace("pageView");
				}
			}
		});
		//Filter event:
		if(eventFilter.has(btn.event.event)){
			btn.display=true;
		}else{
			btn.display=false;
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.focusEvent=function(eventBtn){
		let event=eventBtn.event;
		if(curEventBtn){
			curEventBtn.showFace("blur");
		}
		curEventBtn=eventBtn;
		if(eventBtn){
			eventBtn.showFace("focus");
			dvEvent.setObject(VFACT.genTemplateByObject(event),event);
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.showEventInfo=function(event){
		if(event){
			dvEvent.display=true;
			boxCopyEvent.display=true;
			dvEvent.setObject(VFACT.genTemplateByObject(event),event);
		}else{
			dvEvent.display=false;
			boxCopyEvent.display=false;
			dvEvent.setObject(null,null);
		}
	};
	
	//------------------------------------------------------------------------
	let tracedPage=null;
	cssVO.tracePage=async function(){
		curEventBtn=null;
		boxEvents.clearChildren();
		if(tracedPage){
			tracedPage.stopTrace(traceCallback);
		}
		tracedPage=page;
		if(page){
			tracedPage.startTrace(traceCallback);
		}
	};
	/*}#1GGJKM84D1PostCSSVO*/
	cssVO.constructor=MainUI;
	return cssVO;
};
/*#{1GGJKM84D1ExCodes*/
/*}#1GGJKM84D1ExCodes*/

//----------------------------------------------------------------------------
MainUI.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1GGJKM84D1PreAISpot*/
	/*}#1GGJKM84D1PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1GGJKM84D1PostAISpot*/
	/*}#1GGJKM84D1PostAISpot*/
	return exposeVO;
};

/*#{1GGJKM84D0EndDoc*/
/*}#1GGJKM84D0EndDoc*/

export default MainUI;
export{MainUI};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "UIView",
//	"jaxId": "1GGJKM84D0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1GGJKM84D2",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "1000",
//				"screenH": "600",
//				"bgColor": "#cfgColor.body",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1GGJKM84D3",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1H90TKKV70",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1GGJKM84D4",
//			"attrs": {
//				"app": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"appFrame": {
//					"type": "auto",
//					"valText": "null"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1GGJKM84D5",
//			"attrs": {
//				"actions": {
//					"type": "auto",
//					"valText": "#null#>Actions.newObject()"
//				}
//			}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1GGJKM84D6",
//			"attrs": {
//				"counter": {
//					"type": "int",
//					"valText": "0"
//				},
//				"curNode": {
//					"type": "auto",
//					"valText": "null"
//				}
//			}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HLC9JIP00",
//					"attrs": {
//						"id": "init",
//						"label": "New AI Seg",
//						"x": "100",
//						"y": "10",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HLC9JIPB0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1HLC9JIPB1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": [
//								{
//									"type": "flowseg",
//									"def": "Code",
//									"jaxId": "1HLC9JIP01",
//									"attrs": {
//										"id": "ReadUsage",
//										"label": "New AI Seg",
//										"x": "270",
//										"y": "10",
//										"desc": "",
//										"codes": "false",
//										"outlet": {
//											"jaxId": "1HLC9JIPB2",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											}
//										}
//									},
//									"icon": "tab_css.svg"
//								}
//							]
//						},
//						"outlet": {
//							"jaxId": "1HLC9JIPB3",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1HLC9JIP01"
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HL25IP6J0",
//					"attrs": {
//						"id": "openPage",
//						"label": "New AI Seg",
//						"x": "100",
//						"y": "110",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HL25OD5M0",
//							"attrs": {
//								"sender": {
//									"valText": "null"
//								},
//								"event": {
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1HL25OD5M1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": [
//								{
//									"type": "flowseg",
//									"def": "Code",
//									"jaxId": "1HL25PSC60",
//									"attrs": {
//										"id": "GetURL",
//										"label": "New AI Seg",
//										"x": "540",
//										"y": "110",
//										"desc": "",
//										"codes": "false",
//										"outlet": {
//											"jaxId": "1HL25QR7L0",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											},
//											"linkedSeg": "1HL262SGC0"
//										}
//									},
//									"icon": "tab_css.svg"
//								},
//								{
//									"type": "flowseg",
//									"def": "Code",
//									"jaxId": "1HL25TEIL0",
//									"attrs": {
//										"id": "OpenClient",
//										"label": "New AI Seg",
//										"x": "910",
//										"y": "110",
//										"desc": "",
//										"codes": "false",
//										"outlet": {
//											"jaxId": "1HL25UEAG0",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											},
//											"linkedSeg": "1HL262SG50"
//										}
//									},
//									"icon": "tab_css.svg"
//								},
//								{
//									"type": "flowseg",
//									"def": "SetFace",
//									"jaxId": "1HL262SGC0",
//									"attrs": {
//										"id": "",
//										"label": "New AI Seg",
//										"x": "740",
//										"y": "110",
//										"desc": "",
//										"codes": "false",
//										"component": "self",
//										"face": "openPage",
//										"outlet": {
//											"jaxId": "1HL262SGC1",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											},
//											"linkedSeg": "1HL25TEIL0"
//										}
//									},
//									"icon": "faces.svg"
//								},
//								{
//									"type": "flowseg",
//									"def": "Code",
//									"jaxId": "1HL262SG50",
//									"attrs": {
//										"id": "WaitLoad",
//										"label": "New AI Seg",
//										"x": "1140",
//										"y": "110",
//										"desc": "Wait page load.",
//										"codes": "false",
//										"outlet": {
//											"jaxId": "1HL262SGC2",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											},
//											"linkedSeg": "1HL26RLRA0"
//										}
//									},
//									"icon": "tab_css.svg"
//								},
//								{
//									"type": "flowseg",
//									"def": "SetFace",
//									"jaxId": "1HL26RLRA0",
//									"attrs": {
//										"id": "",
//										"label": "New AI Seg",
//										"x": "1350",
//										"y": "110",
//										"desc": "",
//										"codes": "false",
//										"component": "self",
//										"face": "pageReady",
//										"outlet": {
//											"jaxId": "1HL26RLRA1",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											},
//											"linkedSeg": "1HL3ABDV20"
//										}
//									},
//									"icon": "faces.svg"
//								},
//								{
//									"type": "flowseg",
//									"def": "Code",
//									"jaxId": "1HL3ABDV20",
//									"attrs": {
//										"id": "ShowPageView",
//										"label": "New AI Seg",
//										"x": "1520",
//										"y": "110",
//										"desc": "",
//										"codes": "false",
//										"outlet": {
//											"jaxId": "1HL3ABDV70",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											},
//											"linkedSeg": "1HL3PATVK0"
//										}
//									},
//									"icon": "tab_css.svg"
//								},
//								{
//									"type": "flowseg",
//									"def": "Code",
//									"jaxId": "1HNP4TGOC0",
//									"attrs": {
//										"id": "CheckAAEE",
//										"label": "New AI Seg",
//										"x": "310",
//										"y": "110",
//										"desc": "",
//										"codes": "false",
//										"outlet": {
//											"jaxId": "1HNP4TGOO0",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											},
//											"linkedSeg": "1HL25PSC60"
//										}
//									},
//									"icon": "tab_css.svg"
//								}
//							]
//						},
//						"outlet": {
//							"jaxId": "1HL25OD5M2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1HNP4TGOC0"
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HL25E0NJ0",
//					"attrs": {
//						"id": "clearEvents",
//						"label": "New AI Seg",
//						"x": "100",
//						"y": "230",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HL25FOR50",
//							"attrs": {
//								"sender": {
//									"valText": "null"
//								},
//								"event": {
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1HL25FOR51",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1HL25FOR52",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HL3ABDV21",
//					"attrs": {
//						"id": "showPageView",
//						"label": "New AI Seg",
//						"x": "100",
//						"y": "340",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HL3ABDV71",
//							"attrs": {
//								"delay": {
//									"type": "bool",
//									"valText": "true"
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1HL3ABDV72",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": [
//								{
//									"type": "flowseg",
//									"def": "Code",
//									"jaxId": "1HL3ABDV30",
//									"attrs": {
//										"id": "GetPageView",
//										"label": "New AI Seg",
//										"x": "340",
//										"y": "340",
//										"desc": "",
//										"codes": "false",
//										"outlet": {
//											"jaxId": "1HL3ABDV73",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											}
//										}
//									},
//									"icon": "tab_css.svg"
//								}
//							]
//						},
//						"outlet": {
//							"jaxId": "1HL3ABDV74",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1HL3ABDV30"
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HL3ALN380",
//					"attrs": {
//						"id": "updateView",
//						"label": "New AI Seg",
//						"x": "100",
//						"y": "460",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HL3ALN3H0",
//							"attrs": {
//								"nodes": {
//									"type": "auto",
//									"valText": "null"
//								},
//								"imgData": {
//									"type": "auto",
//									"valText": "null"
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1HL3ALN3H1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": [
//								{
//									"type": "flowseg",
//									"def": "RenderData",
//									"jaxId": "1HL3AP2F10",
//									"attrs": {
//										"id": "UpdateView",
//										"label": "New AI Seg",
//										"x": "340",
//										"y": "460",
//										"desc": "",
//										"codes": "false",
//										"view": "boxNodesList",
//										"data": "nodes",
//										"uiDef": "nodeCSS",
//										"clear": "true",
//										"assign": "",
//										"outlet": {
//											"jaxId": "1HL3AP2F11",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											},
//											"linkedSeg": "1HL5NC5UI0"
//										}
//									},
//									"icon": "hudlbx.svg",
//									"reverseOutlets": true
//								},
//								{
//									"type": "flowseg",
//									"def": "Code",
//									"jaxId": "1HL5NC5UI0",
//									"attrs": {
//										"id": "UpdateImage",
//										"label": "New AI Seg",
//										"x": "570",
//										"y": "460",
//										"desc": "",
//										"codes": "false",
//										"outlet": {
//											"jaxId": "1HL5NELFD0",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											}
//										}
//									},
//									"icon": "tab_css.svg"
//								}
//							]
//						},
//						"outlet": {
//							"jaxId": "1HL3ALN3H3",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1HL3AP2F10"
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HVPLPPBN0",
//					"attrs": {
//						"id": "drawNode",
//						"label": "New AI Seg",
//						"x": "100",
//						"y": "3760",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HVPLQQ590",
//							"attrs": {
//								"node": {
//									"type": "auto",
//									"valText": "null"
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1HVPLQQ591",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1HVPLQQ592",
//							"attrs": {
//								"id": "Next",
//								"desc": "Outlet."
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HL3E0TG90",
//					"attrs": {
//						"id": "focusViewNode",
//						"label": "New AI Seg",
//						"x": "100",
//						"y": "560",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HL3E25R90",
//							"attrs": {
//								"line": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1HL3E25R91",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1HL3E25R92",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Code",
//					"jaxId": "1HL3PATVK0",
//					"attrs": {
//						"id": "WatchPage",
//						"label": "New AI Seg",
//						"x": "1760",
//						"y": "110",
//						"desc": "",
//						"codes": "false",
//						"outlet": {
//							"jaxId": "1HL3PB8J10",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						}
//					},
//					"icon": "tab_css.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HL3T1KDA0",
//					"attrs": {
//						"id": "addEvent",
//						"label": "New AI Seg",
//						"x": "100",
//						"y": "670",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HL3T1KDH0",
//							"attrs": {
//								"data": {
//									"type": "auto",
//									"valText": "null"
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1HL3T1KDH1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1HL3T1KDH2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HL5MTCII0",
//					"attrs": {
//						"id": "showModeNavi",
//						"label": "New AI Seg",
//						"x": "100",
//						"y": "770",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HL5N0K4S0",
//							"attrs": {
//								"sender": {
//									"valText": "null"
//								},
//								"event": {
//									"valText": ""
//								}
//							}
//						},
//						"async": "false",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1HL5N0K4S1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": [
//								{
//									"type": "flowseg",
//									"def": "SetFace",
//									"jaxId": "1HL5N0K4S2",
//									"attrs": {
//										"id": "",
//										"label": "New AI Seg",
//										"x": "340",
//										"y": "770",
//										"desc": "",
//										"codes": "false",
//										"component": "self",
//										"face": "modeNavi",
//										"outlet": {
//											"jaxId": "1HL5N0K4S3",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											}
//										}
//									},
//									"icon": "faces.svg"
//								}
//							]
//						},
//						"outlet": {
//							"jaxId": "1HL5N0K4S4",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1HL5N0K4S2"
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HL5N0K4N0",
//					"attrs": {
//						"id": "showModeEvent",
//						"label": "New AI Seg",
//						"x": "100",
//						"y": "860",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HL5N0K4S5",
//							"attrs": {}
//						},
//						"async": "false",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1HL5N0K4S6",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": [
//								{
//									"type": "flowseg",
//									"def": "SetFace",
//									"jaxId": "1HL5N0K4S7",
//									"attrs": {
//										"id": "",
//										"label": "New AI Seg",
//										"x": "350",
//										"y": "860",
//										"desc": "",
//										"codes": "false",
//										"component": "self",
//										"face": "modeEvent",
//										"outlet": {
//											"jaxId": "1HL5N0K4S8",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											}
//										}
//									},
//									"icon": "faces.svg"
//								}
//							]
//						},
//						"outlet": {
//							"jaxId": "1HL5N0K4S9",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1HL5N0K4S7"
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HL5N0K4N1",
//					"attrs": {
//						"id": "showModeQuery",
//						"label": "New AI Seg",
//						"x": "100",
//						"y": "960",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HL5N0K4S10",
//							"attrs": {}
//						},
//						"async": "false",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1HL5N0K4S11",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": [
//								{
//									"type": "flowseg",
//									"def": "SetFace",
//									"jaxId": "1HL5N0K4S12",
//									"attrs": {
//										"id": "",
//										"label": "New AI Seg",
//										"x": "350",
//										"y": "960",
//										"desc": "",
//										"codes": "false",
//										"component": "self",
//										"face": "modeQuery",
//										"outlet": {
//											"jaxId": "1HL5N0K4S13",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											}
//										}
//									},
//									"icon": "faces.svg"
//								}
//							]
//						},
//						"outlet": {
//							"jaxId": "1HL5N0K4S14",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1HL5N0K4S12"
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HL9L7USU0",
//					"attrs": {
//						"id": "imgPageOnClick",
//						"label": "New AI Seg",
//						"x": "100",
//						"y": "1060",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HL9L95OE0",
//							"attrs": {
//								"sender": {
//									"valText": "null"
//								},
//								"event": {
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1HL9L95OE1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1HL9L95OE2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HLA091M50",
//					"attrs": {
//						"id": "showNode",
//						"label": "New AI Seg",
//						"x": "100",
//						"y": "1160",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HLA091MD0",
//							"attrs": {
//								"node": {
//									"type": "auto",
//									"valText": ""
//								},
//								"open": {
//									"type": "bool",
//									"valText": "false"
//								},
//								"scroll": {
//									"type": "bool",
//									"valText": "false"
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1HLA091MD1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1HLA091MD2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HLC87P2M0",
//					"attrs": {
//						"id": "getNodeByAAEId",
//						"label": "New AI Seg",
//						"x": "100",
//						"y": "1250",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HLC87P2V0",
//							"attrs": {
//								"aaeId": {
//									"type": "string",
//									"valText": ""
//								}
//							}
//						},
//						"async": "false",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1HLC87P2V1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1HLC87P2V2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HLEHV5M70",
//					"attrs": {
//						"id": "openHistory",
//						"label": "New AI Seg",
//						"x": "100",
//						"y": "1340",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HLEI12TT0",
//							"attrs": {
//								"sender": {
//									"valText": "null"
//								},
//								"event": {
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1HLEI12TT1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1HLEI12TT2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HVPOP28N0",
//					"attrs": {
//						"id": "clearQuery",
//						"label": "New AI Seg",
//						"x": "100",
//						"y": "1430",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HVPOPK5D0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1HVPOPK5D1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1HVPOPK5D2",
//							"attrs": {
//								"id": "Next",
//								"desc": "Outlet."
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HVPQ4FP40",
//					"attrs": {
//						"id": "setQueryTarget",
//						"label": "New AI Seg",
//						"x": "100",
//						"y": "1510",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HVPQ6ERT0",
//							"attrs": {
//								"node": {
//									"type": "auto",
//									"valText": "null"
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1HVPQ6ERT1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1HVPQ6ERT2",
//							"attrs": {
//								"id": "Next",
//								"desc": "Outlet."
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HLEMFR7B0",
//					"attrs": {
//						"id": "fillQuery",
//						"label": "New AI Seg",
//						"x": "100",
//						"y": "1590",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HLEMFR7L0",
//							"attrs": {
//								"nodeLine": {
//									"type": "auto",
//									"valText": ""
//								},
//								"node": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1HLEMFR7L1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1HLEMFR7L2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HMK6RHE40",
//					"attrs": {
//						"id": "updateQueryBlock",
//						"label": "New AI Seg",
//						"x": "100",
//						"y": "1665",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HMK6RHEJ0",
//							"attrs": {
//								"block": {
//									"type": "auto",
//									"valText": "null"
//								},
//								"node": {
//									"type": "auto",
//									"valText": "null"
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1HMK6RHEJ1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1HMK6RHEJ2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HVPMSEDU0",
//					"attrs": {
//						"id": "clearQueryResults",
//						"label": "New AI Seg",
//						"x": "100",
//						"y": "1750",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HVPMV9530",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1HVPMV9531",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1HVPMV9532",
//							"attrs": {
//								"id": "Next",
//								"desc": "Outlet."
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HVPMJJOB0",
//					"attrs": {
//						"id": "focusQueryNode",
//						"label": "New AI Seg",
//						"x": "100",
//						"y": "1830",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HVPMM4N30",
//							"attrs": {
//								"nodeLine": {
//									"type": "auto",
//									"valText": "null"
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1HVPMM4N31",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1HVPMM4N32",
//							"attrs": {
//								"id": "Next",
//								"desc": "Outlet."
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HLEQEAV20",
//					"attrs": {
//						"id": "doQuery",
//						"label": "New AI Seg",
//						"x": "100",
//						"y": "1905",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HLEQEP840",
//							"attrs": {
//								"sender": {
//									"valText": "null"
//								},
//								"event": {
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1HLEQEP841",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1HLEQEP842",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HMCK7G700",
//					"attrs": {
//						"id": "pickPage",
//						"label": "New AI Seg",
//						"x": "105",
//						"y": "1990",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HMCK8BT40",
//							"attrs": {
//								"sender": {
//									"valText": "null"
//								},
//								"event": {
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1HMCK8BT41",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1HMCK8BT42",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HPKRSTCP0",
//					"attrs": {
//						"id": "AddAction",
//						"label": "New AI Seg",
//						"x": "100",
//						"y": "2085",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HPKRU2MB0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1HPKRU2MB1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1HPKRU2MB2",
//							"attrs": {
//								"id": "Next",
//								"desc": "Outlet."
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HPKRSTCP1",
//					"attrs": {
//						"id": "ClearAction",
//						"label": "New AI Seg",
//						"x": "100",
//						"y": "2185",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HPKRU2MB3",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1HPKRU2MB4",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1HPKRU2MB5",
//							"attrs": {
//								"id": "Next",
//								"desc": "Outlet."
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HSIRK3QG0",
//					"attrs": {
//						"id": "getActionArgs",
//						"label": "New AI Seg",
//						"x": "95",
//						"y": "2290",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HSIRKN970",
//							"attrs": {}
//						},
//						"async": "false",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1HSIRKN971",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1HSIRKN972",
//							"attrs": {
//								"id": "Next",
//								"desc": "Outlet."
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HSIR1NQV0",
//					"attrs": {
//						"id": "runOneAction",
//						"label": "New AI Seg",
//						"x": "95",
//						"y": "2390",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HSIR1ST90",
//							"attrs": {
//								"dv": {
//									"type": "auto",
//									"valText": "null"
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1HSIR1ST91",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1HSIR1ST92",
//							"attrs": {
//								"id": "Next",
//								"desc": "Outlet."
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HSIRKN8U0",
//					"attrs": {
//						"id": "runActions",
//						"label": "New AI Seg",
//						"x": "95",
//						"y": "2500",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HSIRKN973",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1HSIRKN974",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1HSIRKN975",
//							"attrs": {
//								"id": "Next",
//								"desc": "Outlet."
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HSJ7IRME0",
//					"attrs": {
//						"id": "doSaveAction",
//						"label": "New AI Seg",
//						"x": "95",
//						"y": "2600",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HSJ7IRMM0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1HSJ7IRMM1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1HSJ7IRMM2",
//							"attrs": {
//								"id": "Next",
//								"desc": "Outlet."
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HSJ7IRME1",
//					"attrs": {
//						"id": "doReadAction",
//						"label": "New AI Seg",
//						"x": "90",
//						"y": "2705",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HSJ7IRMM3",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1HSJ7IRMM4",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1HSJ7IRMM5",
//							"attrs": {
//								"id": "Next",
//								"desc": "Outlet."
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HSJ7IRME2",
//					"attrs": {
//						"id": "doClearAction",
//						"label": "New AI Seg",
//						"x": "90",
//						"y": "2800",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HSJ7IRMM6",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1HSJ7IRMM7",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1HSJ7IRMM8",
//							"attrs": {
//								"id": "Next",
//								"desc": "Outlet."
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HSJB79K40",
//					"attrs": {
//						"id": "showViewportMenu",
//						"label": "New AI Seg",
//						"x": "90",
//						"y": "2920",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HSJBB0AO0",
//							"attrs": {
//								"sender": {
//									"valText": "null"
//								},
//								"event": {
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1HSJBB0AO1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": [
//								{
//									"type": "flowseg",
//									"def": "Menu",
//									"jaxId": "1HSJBHIHV0",
//									"attrs": {
//										"id": "Menu",
//										"label": "New AI Seg",
//										"x": "350",
//										"y": "2920",
//										"desc": "",
//										"codes": "false",
//										"launcher": "btnViewport",
//										"outlets": {
//											"attrs": [
//												{
//													"type": "aioutlet",
//													"def": "MenuItem",
//													"jaxId": "1HSJBHIHC0",
//													"attrs": {
//														"id": "375x750",
//														"text": "375x750",
//														"desc": ""
//													}
//												},
//												{
//													"type": "aioutlet",
//													"def": "MenuItem",
//													"jaxId": "1HSJBC1HI0",
//													"attrs": {
//														"id": "800x600",
//														"text": "800x600",
//														"desc": ""
//													}
//												},
//												{
//													"type": "aioutlet",
//													"def": "MenuItem",
//													"jaxId": "1HSJBC1HI1",
//													"attrs": {
//														"id": "1024x768",
//														"text": "1024x768",
//														"desc": ""
//													}
//												},
//												{
//													"type": "aioutlet",
//													"def": "MenuItem",
//													"jaxId": "1HSJBC1HI2",
//													"attrs": {
//														"id": "1280x1024",
//														"text": "1280x1024",
//														"desc": ""
//													}
//												},
//												{
//													"type": "aioutlet",
//													"def": "MenuItem",
//													"jaxId": "1HSJBHIHC1",
//													"attrs": {
//														"id": "1600x900",
//														"text": "1600x900",
//														"desc": ""
//													}
//												}
//											]
//										},
//										"outlet": {
//											"jaxId": "1HSJBHIHV1",
//											"attrs": {
//												"id": "Next",
//												"desc": "Outlet."
//											},
//											"linkedSeg": "1HSJBHIHC2"
//										}
//									},
//									"icon": "menu.svg",
//									"reverseOutlets": true
//								},
//								{
//									"type": "flowseg",
//									"def": "Code",
//									"jaxId": "1HSJBHIHC2",
//									"attrs": {
//										"id": "SetEdit",
//										"label": "New AI Seg",
//										"x": "610",
//										"y": "2910",
//										"desc": "",
//										"codes": "false",
//										"outlet": {
//											"jaxId": "1HSJBHIHV2",
//											"attrs": {
//												"id": "Next",
//												"desc": "Outlet."
//											}
//										}
//									},
//									"icon": "tab_css.svg"
//								}
//							]
//						},
//						"outlet": {
//							"jaxId": "1HSJBB0AO2",
//							"attrs": {
//								"id": "Next",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1HSJBHIHV0"
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HSKB6IDL0",
//					"attrs": {
//						"id": "readView",
//						"label": "New AI Seg",
//						"x": "95",
//						"y": "3165",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HSKBI1H50",
//							"attrs": {
//								"sender": {
//									"valText": "null"
//								},
//								"event": {
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1HSKBI1H51",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": [
//								{
//									"type": "flowseg",
//									"def": "Menu",
//									"jaxId": "1HSKBI1H52",
//									"attrs": {
//										"id": "Menu",
//										"label": "New AI Seg",
//										"x": "295",
//										"y": "3165",
//										"desc": "",
//										"codes": "false",
//										"launcher": "sender",
//										"outlets": {
//											"attrs": [
//												{
//													"type": "aioutlet",
//													"def": "MenuItem",
//													"jaxId": "1HSKBBRMP0",
//													"attrs": {
//														"id": "HTML",
//														"text": "Read Inner-HTML",
//														"desc": ""
//													}
//												},
//												{
//													"type": "aioutlet",
//													"def": "MenuItem",
//													"jaxId": "1HSKBBRMP1",
//													"attrs": {
//														"id": "Text",
//														"text": "Read Inner-Text",
//														"desc": ""
//													}
//												},
//												{
//													"type": "aioutlet",
//													"def": "MenuItem",
//													"jaxId": "1HSKBBRMP2",
//													"attrs": {
//														"id": "View",
//														"text": "Read JSON-View",
//														"desc": ""
//													}
//												},
//												{
//													"type": "aioutlet",
//													"def": "MenuItem",
//													"jaxId": "1HSKBMM2C0",
//													"attrs": {
//														"id": "Article",
//														"text": "Read Article",
//														"desc": ""
//													}
//												}
//											]
//										},
//										"outlet": {
//											"jaxId": "1HSKBI1H53",
//											"attrs": {
//												"id": "Next",
//												"desc": "Outlet."
//											},
//											"linkedSeg": "1HSKBT2CK0"
//										}
//									},
//									"icon": "menu.svg",
//									"reverseOutlets": true
//								},
//								{
//									"type": "flowseg",
//									"def": "Code",
//									"jaxId": "1HSKBT2CK0",
//									"attrs": {
//										"id": "Read",
//										"label": "New AI Seg",
//										"x": "535",
//										"y": "3155",
//										"desc": "",
//										"codes": "false",
//										"outlet": {
//											"jaxId": "1HSKBT2CV0",
//											"attrs": {
//												"id": "Next",
//												"desc": "Outlet."
//											},
//											"linkedSeg": "1HSKBT2CK1"
//										}
//									},
//									"icon": "tab_css.svg"
//								},
//								{
//									"type": "flowseg",
//									"def": "Code",
//									"jaxId": "1HSKBT2CK1",
//									"attrs": {
//										"id": "Show Result",
//										"label": "New AI Seg",
//										"x": "725",
//										"y": "3155",
//										"desc": "",
//										"codes": "false",
//										"outlet": {
//											"jaxId": "1HSKBT2CV1",
//											"attrs": {
//												"id": "Next",
//												"desc": "Outlet."
//											}
//										}
//									},
//									"icon": "tab_css.svg"
//								}
//							]
//						},
//						"outlet": {
//							"jaxId": "1HSKBI1H54",
//							"attrs": {
//								"id": "Next",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1HSKBI1H52"
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HU6JKP700",
//					"attrs": {
//						"id": "clearEvents",
//						"label": "New AI Seg",
//						"x": "100",
//						"y": "3265",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HU6JLPPU0",
//							"attrs": {
//								"sender": {
//									"valText": "null"
//								},
//								"event": {
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1HU6JLPPU1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1HU6JLPPU2",
//							"attrs": {
//								"id": "Next",
//								"desc": "Outlet."
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HU6LENEL0",
//					"attrs": {
//						"id": "copyEvent",
//						"label": "New AI Seg",
//						"x": "100",
//						"y": "3365",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HU6LGJNP0",
//							"attrs": {
//								"sender": {
//									"valText": "null"
//								},
//								"event": {
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1HU6LGJNP1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1HU6LGJNP2",
//							"attrs": {
//								"id": "Next",
//								"desc": "Outlet."
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HU6P0BN10",
//					"attrs": {
//						"id": "eventConfig",
//						"label": "New AI Seg",
//						"x": "100",
//						"y": "3465",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HU6P2PLG0",
//							"attrs": {
//								"sender": {
//									"valText": "null"
//								},
//								"event": {
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1HU6P2PLG1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1HU6P2PLG2",
//							"attrs": {
//								"id": "Next",
//								"desc": "Outlet."
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HUB11E740",
//					"attrs": {
//						"id": "pickBrowser",
//						"label": "New AI Seg",
//						"x": "100",
//						"y": "3565",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HUB14UB50",
//							"attrs": {
//								"sender": {
//									"valText": "null"
//								},
//								"event": {
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1HUB14UB51",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1HUB14UB52",
//							"attrs": {
//								"id": "Next",
//								"desc": "Outlet."
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HVNILP2L0",
//					"attrs": {
//						"id": "close",
//						"label": "New AI Seg",
//						"x": "100",
//						"y": "3665",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HVNIMCK80",
//							"attrs": {
//								"sender": {
//									"valText": "null"
//								},
//								"event": {
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1HVNIMCK81",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1HVNIMCK82",
//							"attrs": {
//								"id": "Next",
//								"desc": "Outlet."
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HVPUBCI70",
//					"attrs": {
//						"id": "useQuery",
//						"label": "New AI Seg",
//						"x": "100",
//						"y": "3835",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HVPUDIRG0",
//							"attrs": {
//								"sender": {
//									"valText": "null"
//								},
//								"event": {
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1HVPUDIRG1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1HVPUDIRG2",
//							"attrs": {
//								"id": "Next",
//								"desc": "Outlet."
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I01V500Q0",
//					"attrs": {
//						"id": "queryWithAI",
//						"label": "New AI Seg",
//						"x": "100",
//						"y": "3935",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I01V5KTO0",
//							"attrs": {
//								"sender": {
//									"valText": "null"
//								},
//								"event": {
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I01V5KTO1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I01V5KTO2",
//							"attrs": {
//								"id": "Next",
//								"desc": "Outlet."
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				}
//			]
//		},
//		"exportTarget": "VFACT document",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1GGJKM84D7",
//			"attrs": {
//				"openPage": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HL262SGC3",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HL262SGC4",
//							"attrs": {}
//						}
//					}
//				},
//				"pageReady": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HL26Q52O0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HL26QJ3J0",
//							"attrs": {}
//						}
//					}
//				},
//				"modeNavi": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HL4R98SI0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HL4RBDGD0",
//							"attrs": {}
//						}
//					}
//				},
//				"modeEvent": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HL4RBDGD1",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HL4RBDGD2",
//							"attrs": {}
//						}
//					}
//				},
//				"modeQuery": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HL4RBDGD3",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HL4RBDGD4",
//							"attrs": {}
//						}
//					}
//				},
//				"init": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HMJUGP5A0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HMJUHFO50",
//							"attrs": {}
//						}
//					}
//				},
//				"pageView": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HU3VNM1Q0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HU3VP15A0",
//							"attrs": {}
//						}
//					}
//				},
//				"eventView": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HU3VP9B60",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HU3VPV3R0",
//							"attrs": {}
//						}
//					}
//				},
//				"dialog": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HVNF6QSB0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HVNF7BCP0",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1HL22K6010",
//			"attrs": {}
//		},
//		"exposeToAI": "true",
//		"descAI": "",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "view",
//			"jaxId": "1GGJKM84D1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1GGJKM84D8",
//					"attrs": {
//						"type": "view",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "100%",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": ""
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1HVNF199H0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HVNF4RG60",
//									"attrs": {
//										"type": "box",
//										"id": "BoxBG",
//										"position": "Absolute",
//										"x": "-2",
//										"y": "-2",
//										"w": "100%+4",
//										"h": "100%+4",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "Off",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "[255,255,255,1.00]",
//										"border": "2",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "true",
//										"shadowX": "10",
//										"shadowY": "15",
//										"shadowBlur": "12",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.30]"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HVNF4RG61",
//									"attrs": {
//										"1HVNF6QSB0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HVNF7BCP1",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HVNF7BCP2",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HVNF6QSB0",
//											"faceTagName": "dialog"
//										},
//										"1HL262SGC3": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HVNF82570",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HVNF82571",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HL262SGC3",
//											"faceTagName": "openPage"
//										},
//										"1HMJUGP5A0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HVNF82572",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HVNF82573",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HMJUGP5A0",
//											"faceTagName": "init"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HVNF4RG62",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HVNF4RG63",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1HMJURVH80",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HMJURVH81",
//									"attrs": {
//										"type": "text",
//										"id": "TxtInitTip",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#cfgColor[\"fontBodyLit\"]",
//										"text": "Pick a page tab or open a new URL to inspect",
//										"font": "",
//										"fontSize": "#txtSize.bigPlus",
//										"bold": "false",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Center",
//										"alignV": "Center",
//										"wrap": "false",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HMJURVH82",
//									"attrs": {
//										"1HMJUGP5A0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HMJUSN1412",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HMJUSN1413",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HMJUGP5A0",
//											"faceTagName": "init"
//										},
//										"1HL262SGC3": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HNBK0C3F0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HNBK0C3F1",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HL262SGC3",
//											"faceTagName": "openPage"
//										},
//										"1HU3VNM1Q0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HU40LIBS0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HU40LIBS1",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HU3VNM1Q0",
//											"faceTagName": "pageView"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HMJURVH83",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HMJURVH84",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1HL22KVCS0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HL22QSD60",
//									"attrs": {
//										"type": "box",
//										"id": "BoxHeader",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "[0,5,0,5]",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"body\"]",
//										"border": "[1,0,1,0]",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor[\"lineBodySub\"]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"contentLayout": "Flex X",
//										"itemsWrap": "No Wrap",
//										"itemsAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1HL247PKA0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HL24C4T20",
//													"attrs": {
//														"type": "box",
//														"id": "BoxState",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "20",
//														"h": "20",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "Off",
//														"clip": "Off",
//														"uiEvent": "Tree Off",
//														"alpha": "0.60",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[0,3,0,0]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "#cfgColor[\"fontBodySub\"]",
//														"border": "0",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]",
//														"maskImage": "#appCfg.sharedAssets+\"/web.svg\""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HL24C4T21",
//													"attrs": {
//														"1HL262SGC3": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HL26TEOG0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HL26TEOG1",
//																	"attrs": {
//																		"alpha": {
//																			"type": "number",
//																			"valText": "0.60",
//																			"editMode": "range",
//																			"editType": "range"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HL262SGC3",
//															"faceTagName": "openPage"
//														},
//														"1HL26Q52O0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HL26TEOG2",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HL26TEOG3",
//																	"attrs": {
//																		"alpha": {
//																			"type": "number",
//																			"valText": "1.00",
//																			"editMode": "range",
//																			"editType": "range"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HL26Q52O0",
//															"faceTagName": "pageReady"
//														},
//														"1HL4RBDGD1": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HL5QD97V0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HL5QD97V1",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HL4RBDGD1",
//															"faceTagName": "modeEvent"
//														},
//														"1HL4R98SI0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HL6IIVT40",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HL6IIVT41",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HL4R98SI0",
//															"faceTagName": "modeNavi"
//														},
//														"1HL4RBDGD3": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HLBUNSI70",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HLBUNSI71",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HL4RBDGD3",
//															"faceTagName": "modeQuery"
//														},
//														"1HU3VNM1Q0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HU40LIBS4",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HU40LIBS5",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HU3VNM1Q0",
//															"faceTagName": "pageView"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HL24C4T22",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HL24C4T23",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1HUB0JGH10",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1HUB0JGH11",
//													"attrs": {
//														"style": "\"front\"",
//														"w": "22",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/web.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1HUB0JGH12",
//													"attrs": {
//														"type": "#null#>BtnIcon(\"front\",22,0,appCfg.sharedAssets+\"/web.svg\",null)",
//														"id": "BtnBrowser",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"margin": "[0,0,0,0]"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HUB0JGH13",
//													"attrs": {
//														"1HL4R98SI0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HUB0JGH20",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HUB0JGH21",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HL4R98SI0",
//															"faceTagName": "modeNavi"
//														},
//														"1HL4RBDGD1": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HUB0JGH22",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HUB0JGH23",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HL4RBDGD1",
//															"faceTagName": "modeEvent"
//														},
//														"1HL4RBDGD3": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HUB0JGH24",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HUB0JGH25",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HL4RBDGD3",
//															"faceTagName": "modeQuery"
//														},
//														"1HL262SGC3": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HUB0JGH28",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HUB0JGH29",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HL262SGC3",
//															"faceTagName": "openPage"
//														},
//														"1HU3VNM1Q0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HUB0JGH210",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HUB0JGH211",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HU3VNM1Q0",
//															"faceTagName": "pageView"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HUB0JGH212",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1HUB0JGH213",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1HUB0JGH214",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": "1HUB11E740"
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1HUB0JGH215",
//													"attrs": {
//														"tip": {
//															"type": "string",
//															"valText": "Browser Profile",
//															"localizable": true
//														}
//													}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1HUB0JGH216",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1HUNBTMCD0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HUNBTMCD1",
//													"attrs": {
//														"type": "text",
//														"id": "TxtBrowser",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[0,5,0,0]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "100",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "[0,0,0]",
//														"text": "AAHOME",
//														"font": "",
//														"fontSize": "#txtSize.small",
//														"bold": "true",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "true",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HUNBTMCE0",
//													"attrs": {
//														"1HU3VNM1Q0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HUNBTMCE1",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HUNBTMCE2",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HU3VNM1Q0",
//															"faceTagName": "pageView"
//														},
//														"1HL262SGC3": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HVNF82574",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HVNF82575",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HL262SGC3",
//															"faceTagName": "openPage"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HUNBTMCE3",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HUNBTMCE4",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1HMCK5HGF0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1HMCK5HGF1",
//													"attrs": {
//														"style": "\"front\"",
//														"w": "22",
//														"h": "0",
//														"icon": "assets/findtab.svg",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1HMCK5HGF2",
//													"attrs": {
//														"type": "#null#>BtnIcon(\"front\",22,0,\"assets/findtab.svg\",null)",
//														"id": "BtnWaitPage",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"margin": "[0,5,0,0]"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HMCK5HGF3",
//													"attrs": {
//														"1HL4R98SI0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HMCK5HGF4",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HMCK5HGF5",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HL4R98SI0",
//															"faceTagName": "modeNavi"
//														},
//														"1HL4RBDGD1": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HMCK5HGF6",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HMCK5HGF7",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HL4RBDGD1",
//															"faceTagName": "modeEvent"
//														},
//														"1HL4RBDGD3": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HMCK5HGF8",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HMCK5HGF9",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HL4RBDGD3",
//															"faceTagName": "modeQuery"
//														},
//														"1HL262SGC3": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HNBK0C3F2",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HNBK0C3F3",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HL262SGC3",
//															"faceTagName": "openPage"
//														},
//														"1HU3VNM1Q0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HU40LIBS8",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HU40LIBS9",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HU3VNM1Q0",
//															"faceTagName": "pageView"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HMCK5HGF14",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1HMCK5HGF15",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1HMCK5HGF16",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": "1HMCK7G700"
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1HMCK5HGF17",
//													"attrs": {
//														"tip": {
//															"type": "string",
//															"valText": "Pick a page to start",
//															"localizable": true
//														}
//													}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1HMCK5HGG0",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1HL24FPD80",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1HL24HKFO0",
//													"attrs": {
//														"style": "#cfgColor.fontBodySub",
//														"w": "25",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/btncombo.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1HL24HKFO1",
//													"attrs": {
//														"type": "#null#>BtnIcon(cfgColor.fontBodySub,25,0,appCfg.sharedAssets+\"/btncombo.svg\",null)",
//														"id": "BtnHistory",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"enable": "false"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HL24HKFO2",
//													"attrs": {
//														"1HL262SGC3": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HL26KVBI2",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HL26KVBI3",
//																	"attrs": {
//																		"enable": {
//																			"type": "bool",
//																			"valText": "false"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HL262SGC3",
//															"faceTagName": "openPage"
//														},
//														"1HL26Q52O0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HL26QJ3K0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HL26QJ3K1",
//																	"attrs": {
//																		"enable": {
//																			"type": "bool",
//																			"valText": "true"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HL26Q52O0",
//															"faceTagName": "pageReady"
//														},
//														"1HL4RBDGD1": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HL5QD97V2",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HL5QD97V3",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HL4RBDGD1",
//															"faceTagName": "modeEvent"
//														},
//														"1HL4R98SI0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HL6IIVT44",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HL6IIVT45",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HL4R98SI0",
//															"faceTagName": "modeNavi"
//														},
//														"1HL4RBDGD3": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HLBUNSI72",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HLBUNSI73",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HL4RBDGD3",
//															"faceTagName": "modeQuery"
//														},
//														"1HU3VNM1Q0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HU40LIBS12",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HU40LIBS13",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HU3VNM1Q0",
//															"faceTagName": "pageView"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HL24HKFO3",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1HLEI12TT3",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1HLEI12TT4",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": "1HLEHV5M70"
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1HL24HKFO4",
//													"attrs": {
//														"tip": {
//															"type": "string",
//															"valText": "Open recent URL to inspect",
//															"localize": {
//																"EN": "Open recent URL to inspect",
//																"CN": "打开最近的URL进行检查"
//															},
//															"localizable": true
//														}
//													}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1HL24HKFO5",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "edit",
//											"jaxId": "1HL242G9D0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HL24C4T24",
//													"attrs": {
//														"type": "edit",
//														"id": "EdURL",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"w": "380",
//														"h": "20",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"inputType": "Text",
//														"text": "",
//														"placeHolder": "Page URL to be inspect",
//														"color": "[0,0,0]",
//														"bgColor": "[255,255,255,1.00]",
//														"font": "",
//														"fontSize": "#txtSize.smallPlus",
//														"outline": "0",
//														"border": "[0,0,1,0]",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"selectOnFocus": "true",
//														"spellCheck": "true"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HL24C4T25",
//													"attrs": {
//														"1HL4RBDGD1": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HL5QD97V4",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HL5QD97V5",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HL4RBDGD1",
//															"faceTagName": "modeEvent"
//														},
//														"1HL4R98SI0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HL6IIVT48",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HL6IIVT49",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HL4R98SI0",
//															"faceTagName": "modeNavi"
//														},
//														"1HL4RBDGD3": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HLBUNSI74",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HLBUNSI75",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HL4RBDGD3",
//															"faceTagName": "modeQuery"
//														},
//														"1HL262SGC3": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HNBK0C3F4",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HNBK0C3F5",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HL262SGC3",
//															"faceTagName": "openPage"
//														},
//														"1HU3VNM1Q0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HU40LIBS16",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HU40LIBS17",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HU3VNM1Q0",
//															"faceTagName": "pageView"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HL24C4T26",
//													"attrs": {
//														"OnKeyDown": {
//															"type": "fixedFunc",
//															"jaxId": "1HNDBG2A70",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1HNDBH1GE0",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1HL24C4T27",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnCheck.js",
//											"jaxId": "1HSJ97TN80",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1HSJ97TN81",
//													"attrs": {
//														"size": "16",
//														"text": "Headless",
//														"checked": "false",
//														"radio": "false"
//													}
//												},
//												"properties": {
//													"jaxId": "1HSJ97TN90",
//													"attrs": {
//														"type": "#null#>BtnCheck(16,\"Headless\",false,false)",
//														"id": "BtnHeadless",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"margin": "[0,5,0,5]",
//														"enable": "true"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HSJ97TN91",
//													"attrs": {
//														"1HU3VNM1Q0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HU40LIBS20",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HU40LIBS21",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HU3VNM1Q0",
//															"faceTagName": "pageView"
//														},
//														"1HL262SGC3": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HVNF82578",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HVNF82579",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HL262SGC3",
//															"faceTagName": "openPage"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HSJ97TN92",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HSJ97TN93",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1HSJ97TN94",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnCheck.js",
//											"jaxId": "1HSJ985O70",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1HSJ985O71",
//													"attrs": {
//														"size": "16",
//														"text": "Dev. Tools",
//														"checked": "false",
//														"radio": "false"
//													}
//												},
//												"properties": {
//													"jaxId": "1HSJ985O72",
//													"attrs": {
//														"type": "#null#>BtnCheck(16,\"Dev. Tools\",false,false)",
//														"id": "BtnDevTools",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"margin": "[0,5,0,5]",
//														"enable": "true"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HSJ985O73",
//													"attrs": {
//														"1HU3VNM1Q0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HU40LIBS24",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HU40LIBS25",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HU3VNM1Q0",
//															"faceTagName": "pageView"
//														},
//														"1HL262SGC3": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HVNF825712",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HVNF825713",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HL262SGC3",
//															"faceTagName": "openPage"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HSJ985O74",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HSJ985O75",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1HSJ985O76",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1HSJAPKRK0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HSJASTMC0",
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[0,0,0,5]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "[0,0,0]",
//														"text": "Viewport:",
//														"font": "",
//														"fontSize": "#txtSize.small",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HSJASTMD0",
//													"attrs": {
//														"1HU3VNM1Q0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HU40LIBS28",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HU40LIBS29",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HU3VNM1Q0",
//															"faceTagName": "pageView"
//														},
//														"1HL262SGC3": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HVNF825716",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HVNF825717",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HL262SGC3",
//															"faceTagName": "openPage"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HSJASTMD1",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HSJASTMD2",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1HSJAQTOG0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1HSJAVB640",
//													"attrs": {
//														"style": "\"front\"",
//														"w": "22",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/btncombo.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1HSJAVB641",
//													"attrs": {
//														"type": "#null#>BtnIcon(\"front\",22,0,appCfg.sharedAssets+\"/btncombo.svg\",null)",
//														"id": "BtnViewport",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": ""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HSJAVB642",
//													"attrs": {
//														"1HU3VNM1Q0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HU40LIBS32",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HU40LIBS33",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HU3VNM1Q0",
//															"faceTagName": "pageView"
//														},
//														"1HL262SGC3": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HVNF825720",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HVNF825721",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HL262SGC3",
//															"faceTagName": "openPage"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HSJAVB643",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1HSJBB0AP0",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1HSJBB0AP1",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": "1HSJB79K40"
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1HSJAVB644",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1HSJAVB645",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "edit",
//											"jaxId": "1HSJASBC00",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HSJATPB50",
//													"attrs": {
//														"type": "edit",
//														"id": "EdViewportW",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "40",
//														"h": "20",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"inputType": "Text",
//														"text": "800",
//														"placeHolder": "",
//														"color": "[0,0,0]",
//														"bgColor": "[255,255,255,1.00]",
//														"font": "",
//														"fontSize": "#txtSize.smallPlus",
//														"outline": "",
//														"border": "[0,0,1,0]",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"selectOnFocus": "true",
//														"spellCheck": "true"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HSJATPB51",
//													"attrs": {
//														"1HU3VNM1Q0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HU40LIBS36",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HU40LIBS37",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HU3VNM1Q0",
//															"faceTagName": "pageView"
//														},
//														"1HL262SGC3": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HVNF825724",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HVNF825725",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HL262SGC3",
//															"faceTagName": "openPage"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HSJATPB52",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HSJATPB53",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1HSJASUE60",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HSJASUE61",
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "[0,0,0]",
//														"text": "x",
//														"font": "",
//														"fontSize": "#txtSize.smallPlus",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HSJASUE70",
//													"attrs": {
//														"1HU3VNM1Q0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HU40LIBS40",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HU40LIBS41",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HU3VNM1Q0",
//															"faceTagName": "pageView"
//														},
//														"1HL262SGC3": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HVNF825728",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HVNF825729",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HL262SGC3",
//															"faceTagName": "openPage"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HSJASUE71",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HSJASUE72",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "edit",
//											"jaxId": "1HSJATQIC0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HSJATQIC1",
//													"attrs": {
//														"type": "edit",
//														"id": "EdViewportH",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "40",
//														"h": "20",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"inputType": "Text",
//														"text": "600",
//														"placeHolder": "",
//														"color": "[0,0,0]",
//														"bgColor": "[255,255,255,1.00]",
//														"font": "",
//														"fontSize": "#txtSize.smallPlus",
//														"outline": "",
//														"border": "[0,0,1,0]",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"selectOnFocus": "true",
//														"spellCheck": "true"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HSJATQIC2",
//													"attrs": {
//														"1HU3VNM1Q0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HU40LIBS44",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HU40LIBS45",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HU3VNM1Q0",
//															"faceTagName": "pageView"
//														},
//														"1HL262SGC3": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HVNF825732",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HVNF825733",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HL262SGC3",
//															"faceTagName": "openPage"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HSJATQIC3",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HSJATQIC4",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1HL22QSD61",
//									"attrs": {
//										"1HL4RBDGD1": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HL5QD97V12",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HL5QD97V13",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HL4RBDGD1",
//											"faceTagName": "modeEvent"
//										},
//										"1HL4R98SI0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HL6IIVT416",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HL6IIVT417",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HL4R98SI0",
//											"faceTagName": "modeNavi"
//										},
//										"1HL4RBDGD3": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HLBUNSI78",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HLBUNSI79",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HL4RBDGD3",
//											"faceTagName": "modeQuery"
//										},
//										"1HL262SGC3": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HNBK0C3F6",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HNBK0C3F7",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HL262SGC3",
//											"faceTagName": "openPage"
//										},
//										"1HU3VNM1Q0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HU40LIBS48",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HU40LIBS49",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HU3VNM1Q0",
//											"faceTagName": "pageView"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HL22QSD62",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HL22QSD63",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1HL22OAA50",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HL22QSD64",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxMid",
//										"position": "Absolute",
//										"x": "0",
//										"y": "30",
//										"w": "100%",
//										"h": "100%-60",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": ""
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1HL23283C0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HL233GTF0",
//													"attrs": {
//														"type": "box",
//														"id": "BoxModeNavi",
//														"position": "Absolute",
//														"x": "0",
//														"y": "0",
//														"w": "300",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "Off",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "[255,255,255,1.00]",
//														"border": "[0,2,0,0]",
//														"borderStyle": "Solid",
//														"borderColor": "#cfgColor[\"fontBodySub\"]",
//														"corner": "0",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]",
//														"contentLayout": "Flex Y"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "box",
//															"jaxId": "1HL24NM3C0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HL24NM3C1",
//																	"attrs": {
//																		"type": "box",
//																		"id": "BoxNaviHeader",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "25",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "[0,0,0,3]",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"background": "[255,255,255,1.00]",
//																		"border": "[0,0,1,0]",
//																		"borderStyle": "Solid",
//																		"borderColor": "#cfgColor[\"fontBodySub\"]",
//																		"corner": "0",
//																		"shadow": "false",
//																		"shadowX": "2",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowSpread": "0",
//																		"shadowColor": "[0,0,0,0.50]",
//																		"contentLayout": "Flex X",
//																		"itemsAlign": "Center"
//																	}
//																},
//																"subHuds": {
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "Gear/@StdUI/ui/BtnIcon.js",
//																			"jaxId": "1HL256IOU0",
//																			"attrs": {
//																				"createArgs": {
//																					"jaxId": "1HL257Q3N0",
//																					"attrs": {
//																						"style": "#cfgColor.fontBodySub",
//																						"w": "24",
//																						"h": "0",
//																						"icon": "#appCfg.sharedAssets+\"/undo.svg\"",
//																						"colorBG": "null"
//																					}
//																				},
//																				"properties": {
//																					"jaxId": "1HL257Q3N1",
//																					"attrs": {
//																						"type": "#null#>BtnIcon(cfgColor.fontBodySub,24,0,appCfg.sharedAssets+\"/undo.svg\",null)",
//																						"id": "BtnViewDoc",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"display": "On",
//																						"face": "",
//																						"margin": "[0,3,0,0]",
//																						"enable": "false"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1HL257Q3N2",
//																					"attrs": {
//																						"1HL262SGC3": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HL26KVBI10",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HL26KVBI11",
//																									"attrs": {
//																										"enable": {
//																											"type": "bool",
//																											"valText": "false"
//																										}
//																									}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL262SGC3",
//																							"faceTagName": "openPage"
//																						},
//																						"1HL26Q52O0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HL26QJ3K8",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HL26QJ3K9",
//																									"attrs": {
//																										"enable": {
//																											"type": "bool",
//																											"valText": "true"
//																										}
//																									}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL26Q52O0",
//																							"faceTagName": "pageReady"
//																						},
//																						"1HL4RBDGD1": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HL5QD97V18",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HL5QD97V19",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL4RBDGD1",
//																							"faceTagName": "modeEvent"
//																						},
//																						"1HL4R98SI0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HL6IIVT420",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HL6IIVT421",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL4R98SI0",
//																							"faceTagName": "modeNavi"
//																						},
//																						"1HL4RBDGD3": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HLBUNSI710",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HLBUNSI711",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL4RBDGD3",
//																							"faceTagName": "modeQuery"
//																						},
//																						"1HU3VNM1Q0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HU40LIBS52",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HU40LIBS53",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HU3VNM1Q0",
//																							"faceTagName": "pageView"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1HL257Q3N3",
//																					"attrs": {
//																						"OnClick": {
//																							"type": "fixedFunc",
//																							"jaxId": "1HL3M4D1U0",
//																							"attrs": {
//																								"callArgs": {
//																									"jaxId": "1HL3M4D1U1",
//																									"attrs": {
//																										"event": ""
//																									}
//																								},
//																								"seg": "1HL3ABDV21"
//																							}
//																						}
//																					}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1HL257Q3N4",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false",
//																				"containerSlots": {
//																					"jaxId": "1HL257Q3N5",
//																					"attrs": {}
//																				}
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "Gear/@StdUI/ui/BtnIcon.js",
//																			"jaxId": "1HL2591OS0",
//																			"attrs": {
//																				"createArgs": {
//																					"jaxId": "1HL2591OS1",
//																					"attrs": {
//																						"style": "#cfgColor.fontBodySub",
//																						"w": "24",
//																						"h": "0",
//																						"icon": "#appCfg.sharedAssets+\"/spot.svg\"",
//																						"colorBG": "null"
//																					}
//																				},
//																				"properties": {
//																					"jaxId": "1HL2591OS2",
//																					"attrs": {
//																						"type": "#null#>BtnIcon(cfgColor.fontBodySub,24,0,appCfg.sharedAssets+\"/spot.svg\",null)",
//																						"id": "BtnFindNode",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"display": "On",
//																						"face": "",
//																						"margin": "[0,3,0,0]",
//																						"enable": "false"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1HL2591OS3",
//																					"attrs": {
//																						"1HL262SGC3": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HL26KVBI12",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HL26KVBI13",
//																									"attrs": {
//																										"enable": {
//																											"type": "bool",
//																											"valText": "false"
//																										}
//																									}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL262SGC3",
//																							"faceTagName": "openPage"
//																						},
//																						"1HL26Q52O0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HL26QJ3K10",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HL26QJ3K11",
//																									"attrs": {
//																										"enable": {
//																											"type": "bool",
//																											"valText": "true"
//																										}
//																									}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL26Q52O0",
//																							"faceTagName": "pageReady"
//																						},
//																						"1HL4RBDGD1": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HL5QD97V20",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HL5QD97V21",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL4RBDGD1",
//																							"faceTagName": "modeEvent"
//																						},
//																						"1HL4R98SI0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HL6IIVT424",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HL6IIVT425",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL4R98SI0",
//																							"faceTagName": "modeNavi"
//																						},
//																						"1HL4RBDGD3": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HLBUNSI712",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HLBUNSI713",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL4RBDGD3",
//																							"faceTagName": "modeQuery"
//																						},
//																						"1HU3VNM1Q0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HU40LIBS56",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HU40LIBS57",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HU3VNM1Q0",
//																							"faceTagName": "pageView"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1HL2591OS4",
//																					"attrs": {
//																						"OnClick": {
//																							"type": "fixedFunc",
//																							"jaxId": "1HLEMU6410",
//																							"attrs": {
//																								"callArgs": {
//																									"jaxId": "1HLEMU6411",
//																									"attrs": {
//																										"event": ""
//																									}
//																								},
//																								"seg": "1HLEMFR7B0"
//																							}
//																						}
//																					}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1HL2591OS5",
//																					"attrs": {
//																						"tip": {
//																							"type": "string",
//																							"valText": "Make query on selected node",
//																							"localizable": true
//																						}
//																					}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false",
//																				"containerSlots": {
//																					"jaxId": "1HL2591OS6",
//																					"attrs": {}
//																				}
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "hud",
//																			"jaxId": "1HSKB0LHD0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HSKBI1H55",
//																					"attrs": {
//																						"type": "hud",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "100",
//																						"h": "100%",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"flex": "true"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1HSKBI1H56",
//																					"attrs": {
//																						"1HU3VNM1Q0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HU40LIBS60",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HU40LIBS61",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HU3VNM1Q0",
//																							"faceTagName": "pageView"
//																						},
//																						"1HL262SGC3": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HVNF82580",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HVNF82581",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL262SGC3",
//																							"faceTagName": "openPage"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1HSKBI1H57",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1HSKBI1H58",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "false",
//																				"exposeContainer": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "Gear/@StdUI/ui/BtnIcon.js",
//																			"jaxId": "1HSKB5OHA0",
//																			"attrs": {
//																				"createArgs": {
//																					"jaxId": "1HSKB5OHA1",
//																					"attrs": {
//																						"style": "#cfgColor.fontBodySub",
//																						"w": "24",
//																						"h": "0",
//																						"icon": "#appCfg.sharedAssets+\"/read.svg\"",
//																						"colorBG": "null"
//																					}
//																				},
//																				"properties": {
//																					"jaxId": "1HSKB5OHA2",
//																					"attrs": {
//																						"type": "#null#>BtnIcon(cfgColor.fontBodySub,24,0,appCfg.sharedAssets+\"/read.svg\",null)",
//																						"id": "BtnRead",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"display": "On",
//																						"face": "",
//																						"margin": "[0,3,0,0]",
//																						"enable": "false"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1HSKB5OHA3",
//																					"attrs": {
//																						"1HL262SGC3": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HSKB5OHB0",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HSKB5OHB1",
//																									"attrs": {
//																										"enable": {
//																											"type": "bool",
//																											"valText": "false"
//																										}
//																									}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL262SGC3",
//																							"faceTagName": "openPage"
//																						},
//																						"1HL26Q52O0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HSKB5OHB2",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HSKB5OHB3",
//																									"attrs": {
//																										"enable": {
//																											"type": "bool",
//																											"valText": "true"
//																										}
//																									}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL26Q52O0",
//																							"faceTagName": "pageReady"
//																						},
//																						"1HL4RBDGD1": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HSKB5OHB4",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HSKB5OHB5",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL4RBDGD1",
//																							"faceTagName": "modeEvent"
//																						},
//																						"1HL4R98SI0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HSKB5OHB6",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HSKB5OHB7",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL4R98SI0",
//																							"faceTagName": "modeNavi"
//																						},
//																						"1HL4RBDGD3": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HSKB5OHB8",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HSKB5OHB9",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL4RBDGD3",
//																							"faceTagName": "modeQuery"
//																						},
//																						"1HU3VNM1Q0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HU40LIBS64",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HU40LIBS65",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HU3VNM1Q0",
//																							"faceTagName": "pageView"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1HSKB5OHB12",
//																					"attrs": {
//																						"OnClick": {
//																							"type": "fixedFunc",
//																							"jaxId": "1HSKB5OHB13",
//																							"attrs": {
//																								"callArgs": {
//																									"jaxId": "1HSKB5OHB14",
//																									"attrs": {
//																										"event": ""
//																									}
//																								},
//																								"seg": "1HSKB6IDL0"
//																							}
//																						}
//																					}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1HSKB5OHB15",
//																					"attrs": {
//																						"tip": {
//																							"type": "string",
//																							"valText": "Make query on selected node",
//																							"localizable": true
//																						}
//																					}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false",
//																				"containerSlots": {
//																					"jaxId": "1HSKB5OHB16",
//																					"attrs": {}
//																				}
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"jaxId": "1HL24NM3C2",
//																	"attrs": {
//																		"1HL4RBDGD1": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HL5QD97V22",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HL5QD97V23",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HL4RBDGD1",
//																			"faceTagName": "modeEvent"
//																		},
//																		"1HL4R98SI0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HL6IIVT428",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HL6IIVT429",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HL4R98SI0",
//																			"faceTagName": "modeNavi"
//																		},
//																		"1HL4RBDGD3": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HLBUNSI714",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HLBUNSI715",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HL4RBDGD3",
//																			"faceTagName": "modeQuery"
//																		},
//																		"1HL262SGC3": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HNBK0C3F8",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HNBK0C3F9",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HL262SGC3",
//																			"faceTagName": "openPage"
//																		},
//																		"1HU3VNM1Q0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HU40LIBS68",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HU40LIBS69",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HU3VNM1Q0",
//																			"faceTagName": "pageView"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HL24NM3C3",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HL24NM3C4",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1HL24QIKL0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HL24TS7K0",
//																	"attrs": {
//																		"type": "hud",
//																		"id": "BoxNaviScroll",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "100%-25",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Auto Scroll",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"contentLayout": "Flex Y"
//																	}
//																},
//																"subHuds": {
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "hud",
//																			"jaxId": "1HL24SGV90",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HL24TS7K1",
//																					"attrs": {
//																						"type": "hud",
//																						"id": "BoxNodesList",
//																						"position": "Relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "",
//																						"h": "",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "100%",
//																						"minH": "50",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"contentLayout": "Flex Y"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1HL24TS7K2",
//																					"attrs": {
//																						"1HL4RBDGD1": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HL5QD97V28",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HL5QD97V29",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL4RBDGD1",
//																							"faceTagName": "modeEvent"
//																						},
//																						"1HL4R98SI0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HL6IIVT432",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HL6IIVT433",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL4R98SI0",
//																							"faceTagName": "modeNavi"
//																						},
//																						"1HL4RBDGD3": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HLBUNSI80",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HLBUNSI81",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL4RBDGD3",
//																							"faceTagName": "modeQuery"
//																						},
//																						"1HL262SGC3": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HNBK0C3F10",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HNBK0C3F11",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL262SGC3",
//																							"faceTagName": "openPage"
//																						},
//																						"1HU3VNM1Q0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HU40LIBS72",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HU40LIBS73",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HU3VNM1Q0",
//																							"faceTagName": "pageView"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1HL24TS7K3",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1HL24TS7K4",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "true",
//																				"exposeContainer": "false"
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"jaxId": "1HL24TS7K5",
//																	"attrs": {
//																		"1HL4RBDGD1": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HL5QD97V34",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HL5QD97V35",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HL4RBDGD1",
//																			"faceTagName": "modeEvent"
//																		},
//																		"1HL4R98SI0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HL6IIVT436",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HL6IIVT437",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HL4R98SI0",
//																			"faceTagName": "modeNavi"
//																		},
//																		"1HL4RBDGD3": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HLBUNSI82",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HLBUNSI83",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HL4RBDGD3",
//																			"faceTagName": "modeQuery"
//																		},
//																		"1HL262SGC3": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HNBK0C3F12",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HNBK0C3F13",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HL262SGC3",
//																			"faceTagName": "openPage"
//																		},
//																		"1HU3VNM1Q0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HU40LIBS76",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HU40LIBS77",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HU3VNM1Q0",
//																			"faceTagName": "pageView"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HL24TS7K6",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HL24TS7K7",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "true",
//																"exposeContainer": "false"
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1HL233GTF1",
//													"attrs": {
//														"1HL4R98SI0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HL5MBQ9E20",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HL5MBQ9E21",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		},
//																		"w": {
//																			"type": "length",
//																			"valText": "300"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HL4R98SI0",
//															"faceTagName": "modeNavi"
//														},
//														"1HL4RBDGD1": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HL5MOANN12",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HL5MOANN13",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		},
//																		"w": {
//																			"type": "length",
//																			"valText": "100%-300"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HL4RBDGD1",
//															"faceTagName": "modeEvent"
//														},
//														"1HL4RBDGD3": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HL5MOANN14",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HL5MOANN15",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HL4RBDGD3",
//															"faceTagName": "modeQuery"
//														},
//														"1HL262SGC3": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HNBK0C3F14",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HNBK0C3F15",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HL262SGC3",
//															"faceTagName": "openPage"
//														},
//														"1HU3VNM1Q0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HU40LIBS80",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HU40LIBS81",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HU3VNM1Q0",
//															"faceTagName": "pageView"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HL233GTF2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HL233GTF3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1HL5MC9T00",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HL5MC9T01",
//													"attrs": {
//														"type": "box",
//														"id": "BoxQueryFrame",
//														"position": "Absolute",
//														"x": "0",
//														"y": "0",
//														"w": "300",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "[255,255,255,1.00]",
//														"border": "[0,2,0,0]",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "box",
//															"jaxId": "1HL5MC9T10",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HL5MC9T11",
//																	"attrs": {
//																		"type": "box",
//																		"id": "BoxQueryHeader",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "25",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "[0,0,0,3]",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"background": "[255,255,255,1.00]",
//																		"border": "[0,0,1,0]",
//																		"borderStyle": "Solid",
//																		"borderColor": "#cfgColor[\"fontBodySub\"]",
//																		"corner": "0",
//																		"shadow": "false",
//																		"shadowX": "2",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowSpread": "0",
//																		"shadowColor": "[0,0,0,0.50]",
//																		"contentLayout": "Flex X",
//																		"itemsAlign": "Center"
//																	}
//																},
//																"subHuds": {
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "Gear/@StdUI/ui/BtnIcon.js",
//																			"jaxId": "1HL5MC9T20",
//																			"attrs": {
//																				"createArgs": {
//																					"jaxId": "1HL5MC9T21",
//																					"attrs": {
//																						"style": "#cfgColor.fontBodySub",
//																						"w": "24",
//																						"h": "0",
//																						"icon": "#appCfg.sharedAssets+\"/undo.svg\"",
//																						"colorBG": "null"
//																					}
//																				},
//																				"properties": {
//																					"jaxId": "1HL5MC9T22",
//																					"attrs": {
//																						"type": "#null#>BtnIcon(cfgColor.fontBodySub,24,0,appCfg.sharedAssets+\"/undo.svg\",null)",
//																						"id": "BtnRefillQuery",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"display": "On",
//																						"face": "",
//																						"margin": "[0,3,0,0]",
//																						"enable": "false"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1HL5MC9T23",
//																					"attrs": {
//																						"1HL262SGC3": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HL5MC9T24",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HL5MC9T25",
//																									"attrs": {
//																										"enable": {
//																											"type": "bool",
//																											"valText": "false"
//																										}
//																									}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL262SGC3",
//																							"faceTagName": "openPage"
//																						},
//																						"1HL26Q52O0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HL5MC9T26",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HL5MC9T27",
//																									"attrs": {
//																										"enable": {
//																											"type": "bool",
//																											"valText": "true"
//																										}
//																									}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL26Q52O0",
//																							"faceTagName": "pageReady"
//																						},
//																						"1HL4RBDGD1": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HL5QD97V44",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HL5QD97V45",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL4RBDGD1",
//																							"faceTagName": "modeEvent"
//																						},
//																						"1HL4R98SI0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HL6IIVT440",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HL6IIVT441",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL4R98SI0",
//																							"faceTagName": "modeNavi"
//																						},
//																						"1HL4RBDGD3": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HLBUNSI84",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HLBUNSI85",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL4RBDGD3",
//																							"faceTagName": "modeQuery"
//																						},
//																						"1HU3VNM1Q0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HU40LIBT0",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HU40LIBT1",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HU3VNM1Q0",
//																							"faceTagName": "pageView"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1HL5MC9T28",
//																					"attrs": {
//																						"OnClick": {
//																							"type": "fixedFunc",
//																							"jaxId": "1HL5MC9T30",
//																							"attrs": {
//																								"callArgs": {
//																									"jaxId": "1HL5MC9T31",
//																									"attrs": {
//																										"event": ""
//																									}
//																								},
//																								"seg": "1HLEMFR7B0"
//																							}
//																						}
//																					}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1HL5MC9T32",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false",
//																				"containerSlots": {
//																					"jaxId": "1HL5MC9T33",
//																					"attrs": {}
//																				}
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "Gear/@StdUI/ui/BtnIcon.js",
//																			"jaxId": "1I01UT0O00",
//																			"attrs": {
//																				"createArgs": {
//																					"jaxId": "1I01V03RG0",
//																					"attrs": {
//																						"style": "\"front\"",
//																						"w": "24",
//																						"h": "0",
//																						"icon": "#appCfg.sharedAssets+\"/aichat.svg\"",
//																						"colorBG": "null"
//																					}
//																				},
//																				"properties": {
//																					"jaxId": "1I01V03RG1",
//																					"attrs": {
//																						"type": "#null#>BtnIcon(\"front\",24,0,appCfg.sharedAssets+\"/aichat.svg\",null)",
//																						"id": "BtnAIQuery",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "50%",
//																						"display": "On",
//																						"face": "",
//																						"scale": "1",
//																						"anchorV": "Center"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1I01V03RG2",
//																					"attrs": {}
//																				},
//																				"functions": {
//																					"jaxId": "1I01V03RG3",
//																					"attrs": {
//																						"OnClick": {
//																							"type": "fixedFunc",
//																							"jaxId": "1I01V5KTP0",
//																							"attrs": {
//																								"callArgs": {
//																									"jaxId": "1I01V5KTP1",
//																									"attrs": {
//																										"event": ""
//																									}
//																								},
//																								"seg": "1I01V500Q0"
//																							}
//																						}
//																					}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1I01V03RG4",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false",
//																				"containerSlots": {
//																					"jaxId": "1I01V03RG5",
//																					"attrs": {}
//																				}
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"jaxId": "1HL5MC9T315",
//																	"attrs": {
//																		"1HL4RBDGD1": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HL5QD97V48",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HL5QD97V49",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HL4RBDGD1",
//																			"faceTagName": "modeEvent"
//																		},
//																		"1HL4R98SI0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HL6IIVT54",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HL6IIVT55",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HL4R98SI0",
//																			"faceTagName": "modeNavi"
//																		},
//																		"1HL4RBDGD3": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HLBUNSI88",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HLBUNSI89",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HL4RBDGD3",
//																			"faceTagName": "modeQuery"
//																		},
//																		"1HL262SGC3": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HNBK0C3G0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HNBK0C3G1",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HL262SGC3",
//																			"faceTagName": "openPage"
//																		},
//																		"1HU3VNM1Q0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HU40LIBT4",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HU40LIBT5",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HU3VNM1Q0",
//																			"faceTagName": "pageView"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HL5MC9T316",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HL5MC9T317",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1HL5ME54B0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HL5ME54B1",
//																	"attrs": {
//																		"type": "hud",
//																		"id": "BoxQueryScroll",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "100%-25",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Auto Scroll Y",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "[5,5,50,5]",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"contentLayout": "Flex Y"
//																	}
//																},
//																"subHuds": {
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "hud",
//																			"jaxId": "1HL5ME54C0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HL5ME54C1",
//																					"attrs": {
//																						"type": "hud",
//																						"id": "BoxQueryBlocks",
//																						"position": "Relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "100%",
//																						"h": "",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "20",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"contentLayout": "Flex Y"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1HL5ME54C2",
//																					"attrs": {
//																						"1HL4RBDGD1": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HL5QD97V54",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HL5QD97V55",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL4RBDGD1",
//																							"faceTagName": "modeEvent"
//																						},
//																						"1HL4R98SI0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HL6IIVT58",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HL6IIVT59",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL4R98SI0",
//																							"faceTagName": "modeNavi"
//																						},
//																						"1HL4RBDGD3": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HLBUNSI810",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HLBUNSI811",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL4RBDGD3",
//																							"faceTagName": "modeQuery"
//																						},
//																						"1HL262SGC3": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HNBK0C3G2",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HNBK0C3G3",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL262SGC3",
//																							"faceTagName": "openPage"
//																						},
//																						"1HU3VNM1Q0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HU40LIBT8",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HU40LIBT9",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HU3VNM1Q0",
//																							"faceTagName": "pageView"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1HL5ME54C3",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1HL5ME54C4",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "true",
//																				"exposeContainer": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "Gear/@StdUI/ui/BtnText.js",
//																			"jaxId": "1HNAQE5IH0",
//																			"attrs": {
//																				"createArgs": {
//																					"jaxId": "1HNAQE5IH1",
//																					"attrs": {
//																						"style": "primary",
//																						"w": "160",
//																						"h": "24",
//																						"text": "Gen Query String",
//																						"outlined": "false",
//																						"icon": ""
//																					}
//																				},
//																				"properties": {
//																					"jaxId": "1HNAQE5IH2",
//																					"attrs": {
//																						"type": "#null#>BtnText(\"primary\",160,24,\"Gen Query String\",false,\"\")",
//																						"id": "BtnGenQuery",
//																						"position": "relative",
//																						"x": "50%",
//																						"y": "0",
//																						"display": "On",
//																						"face": "",
//																						"margin": "[5,0,10,0]",
//																						"anchorH": "Center"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1HNAQE5IH3",
//																					"attrs": {
//																						"1HL4R98SI0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HNAQE5IH4",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HNAQE5IH5",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL4R98SI0",
//																							"faceTagName": "modeNavi"
//																						},
//																						"1HL4RBDGD1": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HNAQE5II0",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HNAQE5II1",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL4RBDGD1",
//																							"faceTagName": "modeEvent"
//																						},
//																						"1HL4RBDGD3": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HNAQE5II2",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HNAQE5II3",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL4RBDGD3",
//																							"faceTagName": "modeQuery"
//																						},
//																						"1HL262SGC3": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HNBK0C3G4",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HNBK0C3G5",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL262SGC3",
//																							"faceTagName": "openPage"
//																						},
//																						"1HU3VNM1Q0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HU40LIBT12",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HU40LIBT13",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HU3VNM1Q0",
//																							"faceTagName": "pageView"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1HNAQE5II6",
//																					"attrs": {
//																						"OnClick": {
//																							"type": "fixedFunc",
//																							"jaxId": "1HNAQE5II7",
//																							"attrs": {
//																								"callArgs": {
//																									"jaxId": "1HNAQE5II8",
//																									"attrs": {
//																										"event": ""
//																									}
//																								},
//																								"seg": ""
//																							}
//																						}
//																					}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1HNAQE5II9",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "true",
//																				"containerSlots": {
//																					"jaxId": "1HNAQE5II10",
//																					"attrs": {
//																						"Slot1H2F6U36O0": {
//																							"jaxId": "1HNAQE5II11",
//																							"attrs": {
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"container": "true"
//																							}
//																						}
//																					}
//																				}
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "text",
//																			"jaxId": "1HLF4UKJG0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HLF50HD80",
//																					"attrs": {
//																						"type": "text",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "100%",
//																						"h": "",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"color": "[0,0,0]",
//																						"text": "XPath query selector:",
//																						"font": "",
//																						"fontSize": "#txtSize.smallPlus",
//																						"bold": "false",
//																						"italic": "false",
//																						"underline": "false",
//																						"alignH": "Left",
//																						"alignV": "Top",
//																						"wrap": "false",
//																						"ellipsis": "false",
//																						"lineClamp": "0",
//																						"select": "false",
//																						"shadow": "false",
//																						"shadowX": "0",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowColor": "[0,0,0,1.00]",
//																						"shadowEx": "",
//																						"maxTextW": "0"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1HLF50HD81",
//																					"attrs": {
//																						"1HL4R98SI0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HLH3PIP314",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HLH3PIP315",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL4R98SI0",
//																							"faceTagName": "modeNavi"
//																						},
//																						"1HL4RBDGD1": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HLH3PIP316",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HLH3PIP317",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL4RBDGD1",
//																							"faceTagName": "modeEvent"
//																						},
//																						"1HL4RBDGD3": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HLH3PIP318",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HLH3PIP319",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL4RBDGD3",
//																							"faceTagName": "modeQuery"
//																						},
//																						"1HL262SGC3": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HNBK0C3G6",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HNBK0C3G7",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL262SGC3",
//																							"faceTagName": "openPage"
//																						},
//																						"1HU3VNM1Q0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HU40LIBT16",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HU40LIBT17",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HU3VNM1Q0",
//																							"faceTagName": "pageView"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1HLF50HD82",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1HLF50HD83",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "edit",
//																			"jaxId": "1HLEPSAM80",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HLEPVTCR0",
//																					"attrs": {
//																						"type": "edit",
//																						"id": "EdQuery",
//																						"position": "relative",
//																						"x": "5",
//																						"y": "0",
//																						"w": "100%-10",
//																						"h": "20",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "[5,0,10,0]",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"inputType": "Text",
//																						"text": "",
//																						"placeHolder": "Query string",
//																						"color": "[0,0,0]",
//																						"bgColor": "[255,255,255,1.00]",
//																						"font": "",
//																						"fontSize": "#txtSize.smallPlus",
//																						"outline": "",
//																						"border": "[0,0,1,0]",
//																						"borderStyle": "Solid",
//																						"borderColor": "[0,0,0,1.00]",
//																						"corner": "0",
//																						"selectOnFocus": "false",
//																						"spellCheck": "false"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1HLEPVTCR1",
//																					"attrs": {
//																						"1HL4R98SI0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HLH3PIP324",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HLH3PIP325",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL4R98SI0",
//																							"faceTagName": "modeNavi"
//																						},
//																						"1HL4RBDGD1": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HLH3PIP326",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HLH3PIP327",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL4RBDGD1",
//																							"faceTagName": "modeEvent"
//																						},
//																						"1HL4RBDGD3": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HLH3PIP328",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HLH3PIP329",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL4RBDGD3",
//																							"faceTagName": "modeQuery"
//																						},
//																						"1HL262SGC3": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HNBK0C3G8",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HNBK0C3G9",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL262SGC3",
//																							"faceTagName": "openPage"
//																						},
//																						"1HU3VNM1Q0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HU40LIBT20",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HU40LIBT21",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HU3VNM1Q0",
//																							"faceTagName": "pageView"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1HLEPVTCR2",
//																					"attrs": {
//																						"OnKeyDown": {
//																							"type": "fixedFunc",
//																							"jaxId": "1HNDASRUV0",
//																							"attrs": {
//																								"callArgs": {
//																									"jaxId": "1HNDATBM30",
//																									"attrs": {
//																										"event": ""
//																									}
//																								},
//																								"seg": ""
//																							}
//																						}
//																					}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1HLEPVTCR3",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "true"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "Gear/@StdUI/ui/BtnCheck.js",
//																			"jaxId": "1HLF50TFP0",
//																			"attrs": {
//																				"createArgs": {
//																					"jaxId": "1HLF55HVU0",
//																					"attrs": {
//																						"size": "18",
//																						"text": "Touchable only",
//																						"checked": "true",
//																						"radio": "false"
//																					}
//																				},
//																				"properties": {
//																					"jaxId": "1HLF55HVU1",
//																					"attrs": {
//																						"type": "#null#>BtnCheck(18,\"Touchable only\",true,false)",
//																						"id": "BtnQueryTouch",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"display": "Off",
//																						"face": "",
//																						"margin": "[0,0,5,0]"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1HLF55HVU2",
//																					"attrs": {
//																						"1HL4R98SI0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HLH3PIP334",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HLH3PIP335",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL4R98SI0",
//																							"faceTagName": "modeNavi"
//																						},
//																						"1HL4RBDGD1": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HLH3PIP336",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HLH3PIP337",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL4RBDGD1",
//																							"faceTagName": "modeEvent"
//																						},
//																						"1HL4RBDGD3": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HLH3PIP338",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HLH3PIP339",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL4RBDGD3",
//																							"faceTagName": "modeQuery"
//																						},
//																						"1HL262SGC3": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HNBK0C3G10",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HNBK0C3G11",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL262SGC3",
//																							"faceTagName": "openPage"
//																						},
//																						"1HU3VNM1Q0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HU40LIBT24",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HU40LIBT25",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HU3VNM1Q0",
//																							"faceTagName": "pageView"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1HLF55HVU3",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1HLF55HVU4",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false",
//																				"containerSlots": {
//																					"jaxId": "1HLF55HVU5",
//																					"attrs": {}
//																				}
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "Gear/@StdUI/ui/BtnText.js",
//																			"jaxId": "1HLEP6HS20",
//																			"attrs": {
//																				"createArgs": {
//																					"jaxId": "1HLEP8GBK0",
//																					"attrs": {
//																						"style": "primary",
//																						"w": "160",
//																						"h": "24",
//																						"text": "Query",
//																						"outlined": "false",
//																						"icon": ""
//																					}
//																				},
//																				"properties": {
//																					"jaxId": "1HLEP8GBK1",
//																					"attrs": {
//																						"type": "#null#>BtnText(\"primary\",160,24,\"Query\",false,\"\")",
//																						"id": "BtnQuery",
//																						"position": "relative",
//																						"x": "50%",
//																						"y": "0",
//																						"display": "On",
//																						"face": "",
//																						"margin": "[5,0,10,0]",
//																						"anchorH": "Center"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1HLEP8GBK2",
//																					"attrs": {
//																						"1HL4R98SI0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HLH3PIP344",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HLH3PIP345",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL4R98SI0",
//																							"faceTagName": "modeNavi"
//																						},
//																						"1HL4RBDGD1": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HLH3PIP346",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HLH3PIP347",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL4RBDGD1",
//																							"faceTagName": "modeEvent"
//																						},
//																						"1HL4RBDGD3": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HLH3PIP348",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HLH3PIP349",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL4RBDGD3",
//																							"faceTagName": "modeQuery"
//																						},
//																						"1HL262SGC3": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HNBK0C3G12",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HNBK0C3G13",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL262SGC3",
//																							"faceTagName": "openPage"
//																						},
//																						"1HU3VNM1Q0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HU40LIBT28",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HU40LIBT29",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HU3VNM1Q0",
//																							"faceTagName": "pageView"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1HLEP8GBK3",
//																					"attrs": {
//																						"OnClick": {
//																							"type": "fixedFunc",
//																							"jaxId": "1HLEQEP843",
//																							"attrs": {
//																								"callArgs": {
//																									"jaxId": "1HLEQEP844",
//																									"attrs": {
//																										"event": ""
//																									}
//																								},
//																								"seg": "1HLEQEAV20"
//																							}
//																						}
//																					}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1HLEP8GBK4",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "true",
//																				"containerSlots": {
//																					"jaxId": "1HLEP8GBK5",
//																					"attrs": {
//																						"Slot1H2F6U36O0": {
//																							"jaxId": "1HLEP8GBK6",
//																							"attrs": {
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"container": "true"
//																							}
//																						}
//																					}
//																				}
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "Gear/@StdUI/ui/BtnText.js",
//																			"jaxId": "1HVPU79040",
//																			"attrs": {
//																				"createArgs": {
//																					"jaxId": "1HVPU79041",
//																					"attrs": {
//																						"style": "success",
//																						"w": "160",
//																						"h": "24",
//																						"text": "Use and Close",
//																						"outlined": "false",
//																						"icon": ""
//																					}
//																				},
//																				"properties": {
//																					"jaxId": "1HVPU79042",
//																					"attrs": {
//																						"type": "#null#>BtnText(\"success\",160,24,\"Use and Close\",false,\"\")",
//																						"id": "BtnUseQuery",
//																						"position": "relative",
//																						"x": "50%",
//																						"y": "0",
//																						"display": "On",
//																						"face": "",
//																						"margin": "[5,0,10,0]",
//																						"anchorH": "Center"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1HVPU79050",
//																					"attrs": {
//																						"1HL4R98SI0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HVPU79051",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HVPU79052",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL4R98SI0",
//																							"faceTagName": "modeNavi"
//																						},
//																						"1HL4RBDGD1": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HVPU79053",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HVPU79054",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL4RBDGD1",
//																							"faceTagName": "modeEvent"
//																						},
//																						"1HL4RBDGD3": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HVPU79055",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HVPU79056",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL4RBDGD3",
//																							"faceTagName": "modeQuery"
//																						},
//																						"1HL262SGC3": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HVPU79057",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HVPU79058",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL262SGC3",
//																							"faceTagName": "openPage"
//																						},
//																						"1HU3VNM1Q0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HVPU79059",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HVPU790510",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HU3VNM1Q0",
//																							"faceTagName": "pageView"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1HVPU790511",
//																					"attrs": {
//																						"OnClick": {
//																							"type": "fixedFunc",
//																							"jaxId": "1HVPU790512",
//																							"attrs": {
//																								"callArgs": {
//																									"jaxId": "1HVPU790513",
//																									"attrs": {
//																										"event": ""
//																									}
//																								},
//																								"seg": "1HVPUBCI70"
//																							}
//																						}
//																					}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1HVPU790514",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "true",
//																				"containerSlots": {
//																					"jaxId": "1HVPU790515",
//																					"attrs": {
//																						"Slot1H2F6U36O0": {
//																							"jaxId": "1HVPU790516",
//																							"attrs": {
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"container": "true"
//																							}
//																						}
//																					}
//																				}
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "box",
//																			"jaxId": "1HLELF1A30",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HLELGF780",
//																					"attrs": {
//																						"type": "box",
//																						"id": "",
//																						"position": "relative",
//																						"x": "10%",
//																						"y": "0",
//																						"w": "80%",
//																						"h": "1",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"background": "#cfgColor[\"fontBodySub\"]",
//																						"border": "0",
//																						"borderStyle": "Solid",
//																						"borderColor": "[0,0,0,1.00]",
//																						"corner": "0",
//																						"shadow": "false",
//																						"shadowX": "2",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowSpread": "0",
//																						"shadowColor": "[0,0,0,0.50]"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1HLELGF781",
//																					"attrs": {
//																						"1HL4R98SI0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HLH3PIP354",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HLH3PIP355",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL4R98SI0",
//																							"faceTagName": "modeNavi"
//																						},
//																						"1HL4RBDGD1": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HLH3PIP356",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HLH3PIP357",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL4RBDGD1",
//																							"faceTagName": "modeEvent"
//																						},
//																						"1HL4RBDGD3": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HLH3PIP358",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HLH3PIP359",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL4RBDGD3",
//																							"faceTagName": "modeQuery"
//																						},
//																						"1HL262SGC3": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HNBK0C3G14",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HNBK0C3G15",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL262SGC3",
//																							"faceTagName": "openPage"
//																						},
//																						"1HU3VNM1Q0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HU40LIBT32",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HU40LIBT33",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HU3VNM1Q0",
//																							"faceTagName": "pageView"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1HLELGF782",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1HLELGF783",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "hud",
//																			"jaxId": "1HLELBPI40",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HLELBPI41",
//																					"attrs": {
//																						"type": "hud",
//																						"id": "BoxQueryResults",
//																						"position": "Relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "100%",
//																						"h": "",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "50",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"contentLayout": "Flex Y"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1HLELBPI42",
//																					"attrs": {
//																						"1HL4RBDGD1": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HLELBPI50",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HLELBPI51",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL4RBDGD1",
//																							"faceTagName": "modeEvent"
//																						},
//																						"1HL4R98SI0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HLELBPI56",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HLELBPI57",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL4R98SI0",
//																							"faceTagName": "modeNavi"
//																						},
//																						"1HL4RBDGD3": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HLELBPI58",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HLELBPI59",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL4RBDGD3",
//																							"faceTagName": "modeQuery"
//																						},
//																						"1HL262SGC3": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HNBK0C3G16",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HNBK0C3G17",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL262SGC3",
//																							"faceTagName": "openPage"
//																						},
//																						"1HU3VNM1Q0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HU40LIBT36",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HU40LIBT37",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HU3VNM1Q0",
//																							"faceTagName": "pageView"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1HLELBPI510",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1HLELBPI511",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "true",
//																				"exposeContainer": "false"
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"jaxId": "1HL5ME54C5",
//																	"attrs": {
//																		"1HL4RBDGD1": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HL5QD97V60",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HL5QD97V61",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HL4RBDGD1",
//																			"faceTagName": "modeEvent"
//																		},
//																		"1HL4R98SI0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HL6IIVT512",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HL6IIVT513",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HL4R98SI0",
//																			"faceTagName": "modeNavi"
//																		},
//																		"1HL4RBDGD3": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HLBUNSI812",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HLBUNSI813",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HL4RBDGD3",
//																			"faceTagName": "modeQuery"
//																		},
//																		"1HL262SGC3": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HNBK0C3G18",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HNBK0C3G19",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HL262SGC3",
//																			"faceTagName": "openPage"
//																		},
//																		"1HU3VNM1Q0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HU40LIBT40",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HU40LIBT41",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HU3VNM1Q0",
//																			"faceTagName": "pageView"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HL5ME54C6",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HL5ME54C7",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false",
//																"exposeContainer": "false"
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1HL5MC9T410",
//													"attrs": {
//														"1HL4R98SI0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HL5MC9T411",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HL5MC9T412",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HL4R98SI0",
//															"faceTagName": "modeNavi"
//														},
//														"1HL4RBDGD1": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HL5MOANN80",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HL5MOANN81",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HL4RBDGD1",
//															"faceTagName": "modeEvent"
//														},
//														"1HL4RBDGD3": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HL5MOANN82",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HL5MOANN83",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HL4RBDGD3",
//															"faceTagName": "modeQuery"
//														},
//														"1HL262SGC3": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HNBK0C3G20",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HNBK0C3G21",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HL262SGC3",
//															"faceTagName": "openPage"
//														},
//														"1HU3VNM1Q0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HU40LIBT44",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HU40LIBT45",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HU3VNM1Q0",
//															"faceTagName": "pageView"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HL5MC9T413",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HL5MC9T414",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1HL23VHIQ0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HL24C4T28",
//													"attrs": {
//														"type": "box",
//														"id": "BoxEventsFrame",
//														"position": "Absolute",
//														"x": "0",
//														"y": "0",
//														"w": "300",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "Off",
//														"clip": "On",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "[255,255,255,1.00]",
//														"border": "[0,2,0,0]",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]",
//														"contentLayout": "Flex Y"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "box",
//															"jaxId": "1HL24L7070",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HL24MRIR0",
//																	"attrs": {
//																		"type": "box",
//																		"id": "BoxEventsHeader",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "25",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "[0,0,0,3]",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"background": "[255,255,255,1.00]",
//																		"border": "[0,0,1,0]",
//																		"borderStyle": "Solid",
//																		"borderColor": "#cfgColor[\"fontBodySub\"]",
//																		"corner": "0",
//																		"shadow": "false",
//																		"shadowX": "2",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowSpread": "0",
//																		"shadowColor": "[0,0,0,0.50]",
//																		"contentLayout": "Flex X"
//																	}
//																},
//																"subHuds": {
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "Gear/@StdUI/ui/BtnIcon.js",
//																			"jaxId": "1HRFT6IG60",
//																			"attrs": {
//																				"createArgs": {
//																					"jaxId": "1HRFT6IG61",
//																					"attrs": {
//																						"style": "#cfgColor.fontBodySub",
//																						"w": "24",
//																						"h": "0",
//																						"icon": "#appCfg.sharedAssets+\"/folder.svg\"",
//																						"colorBG": "null"
//																					}
//																				},
//																				"properties": {
//																					"jaxId": "1HRFT6IG62",
//																					"attrs": {
//																						"type": "#null#>BtnIcon(cfgColor.fontBodySub,24,0,appCfg.sharedAssets+\"/folder.svg\",null)",
//																						"id": "BtnOpenActions",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"display": "On",
//																						"face": "",
//																						"margin": "[0,3,0,0]",
//																						"enable": "false"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1HRFT6IG63",
//																					"attrs": {
//																						"1HL262SGC3": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HRFT6IG64",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HRFT6IG65",
//																									"attrs": {
//																										"enable": {
//																											"type": "bool",
//																											"valText": "false"
//																										}
//																									}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL262SGC3",
//																							"faceTagName": "openPage"
//																						},
//																						"1HL26Q52O0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HRFT6IG66",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HRFT6IG67",
//																									"attrs": {
//																										"enable": {
//																											"type": "bool",
//																											"valText": "true"
//																										}
//																									}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL26Q52O0",
//																							"faceTagName": "pageReady"
//																						},
//																						"1HL4RBDGD1": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HRFT6IG70",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HRFT6IG71",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL4RBDGD1",
//																							"faceTagName": "modeEvent"
//																						},
//																						"1HL4R98SI0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HRFT6IG72",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HRFT6IG73",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL4R98SI0",
//																							"faceTagName": "modeNavi"
//																						},
//																						"1HL4RBDGD3": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HRFT6IG74",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HRFT6IG75",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL4RBDGD3",
//																							"faceTagName": "modeQuery"
//																						},
//																						"1HU3VNM1Q0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HU40LIBT48",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HU40LIBT49",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HU3VNM1Q0",
//																							"faceTagName": "pageView"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1HRFT6IG78",
//																					"attrs": {
//																						"OnClick": {
//																							"type": "fixedFunc",
//																							"jaxId": "1HRFT6IG79",
//																							"attrs": {
//																								"callArgs": {
//																									"jaxId": "1HRFT6IG710",
//																									"attrs": {
//																										"event": ""
//																									}
//																								},
//																								"seg": "1HPKRSTCP1"
//																							}
//																						}
//																					}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1HRFT6IG711",
//																					"attrs": {
//																						"tip": {
//																							"type": "string",
//																							"valText": "Open Action",
//																							"localizable": true
//																						}
//																					}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false",
//																				"containerSlots": {
//																					"jaxId": "1HRFT6IG712",
//																					"attrs": {}
//																				}
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "Gear/@StdUI/ui/BtnIcon.js",
//																			"jaxId": "1HRFT76200",
//																			"attrs": {
//																				"createArgs": {
//																					"jaxId": "1HRFT76201",
//																					"attrs": {
//																						"style": "#cfgColor.fontBodySub",
//																						"w": "24",
//																						"h": "0",
//																						"icon": "#appCfg.sharedAssets+\"/save.svg\"",
//																						"colorBG": "null"
//																					}
//																				},
//																				"properties": {
//																					"jaxId": "1HRFT76210",
//																					"attrs": {
//																						"type": "#null#>BtnIcon(cfgColor.fontBodySub,24,0,appCfg.sharedAssets+\"/save.svg\",null)",
//																						"id": "BtnSaveActions",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"display": "On",
//																						"face": "",
//																						"margin": "[0,3,0,0]",
//																						"enable": "false"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1HRFT76211",
//																					"attrs": {
//																						"1HL262SGC3": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HRFT76212",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HRFT76213",
//																									"attrs": {
//																										"enable": {
//																											"type": "bool",
//																											"valText": "false"
//																										}
//																									}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL262SGC3",
//																							"faceTagName": "openPage"
//																						},
//																						"1HL26Q52O0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HRFT76220",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HRFT76221",
//																									"attrs": {
//																										"enable": {
//																											"type": "bool",
//																											"valText": "true"
//																										}
//																									}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL26Q52O0",
//																							"faceTagName": "pageReady"
//																						},
//																						"1HL4RBDGD1": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HRFT76222",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HRFT76223",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL4RBDGD1",
//																							"faceTagName": "modeEvent"
//																						},
//																						"1HL4R98SI0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HRFT76224",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HRFT76225",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL4R98SI0",
//																							"faceTagName": "modeNavi"
//																						},
//																						"1HL4RBDGD3": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HRFT76226",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HRFT76227",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL4RBDGD3",
//																							"faceTagName": "modeQuery"
//																						},
//																						"1HU3VNM1Q0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HU40LIBT52",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HU40LIBT53",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HU3VNM1Q0",
//																							"faceTagName": "pageView"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1HRFT762210",
//																					"attrs": {
//																						"OnClick": {
//																							"type": "fixedFunc",
//																							"jaxId": "1HRFT762211",
//																							"attrs": {
//																								"callArgs": {
//																									"jaxId": "1HRFT762212",
//																									"attrs": {
//																										"event": ""
//																									}
//																								},
//																								"seg": "1HPKRSTCP1"
//																							}
//																						}
//																					}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1HRFT762213",
//																					"attrs": {
//																						"tip": {
//																							"type": "string",
//																							"valText": "Save Action",
//																							"localizable": true
//																						}
//																					}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false",
//																				"containerSlots": {
//																					"jaxId": "1HRFT762214",
//																					"attrs": {}
//																				}
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "hud",
//																			"jaxId": "1HRFTD03N0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HRFTI9O80",
//																					"attrs": {
//																						"type": "hud",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "20",
//																						"h": "100%",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": ""
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1HRFTI9O81",
//																					"attrs": {
//																						"1HU3VNM1Q0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HU40LIBT56",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HU40LIBT57",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HU3VNM1Q0",
//																							"faceTagName": "pageView"
//																						},
//																						"1HL262SGC3": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HVNF82584",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HVNF82585",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL262SGC3",
//																							"faceTagName": "openPage"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1HRFTI9O82",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1HRFTI9O83",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "false",
//																				"exposeContainer": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "Gear/@StdUI/ui/BtnIcon.js",
//																			"jaxId": "1HRFTB7ND0",
//																			"attrs": {
//																				"createArgs": {
//																					"jaxId": "1HRFTB7ND1",
//																					"attrs": {
//																						"style": "#cfgColor.fontBodySub",
//																						"w": "24",
//																						"h": "0",
//																						"icon": "#appCfg.sharedAssets+\"/run.svg\"",
//																						"colorBG": "null"
//																					}
//																				},
//																				"properties": {
//																					"jaxId": "1HRFTB7ND2",
//																					"attrs": {
//																						"type": "#null#>BtnIcon(cfgColor.fontBodySub,24,0,appCfg.sharedAssets+\"/run.svg\",null)",
//																						"id": "BtnRunActions",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"display": "On",
//																						"face": "",
//																						"margin": "[0,3,0,0]",
//																						"enable": "false"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1HRFTB7NE0",
//																					"attrs": {
//																						"1HL262SGC3": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HRFTB7NE1",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HRFTB7NE2",
//																									"attrs": {
//																										"enable": {
//																											"type": "bool",
//																											"valText": "false"
//																										}
//																									}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL262SGC3",
//																							"faceTagName": "openPage"
//																						},
//																						"1HL26Q52O0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HRFTB7NE3",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HRFTB7NE4",
//																									"attrs": {
//																										"enable": {
//																											"type": "bool",
//																											"valText": "true"
//																										}
//																									}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL26Q52O0",
//																							"faceTagName": "pageReady"
//																						},
//																						"1HL4RBDGD1": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HRFTB7NE5",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HRFTB7NE6",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL4RBDGD1",
//																							"faceTagName": "modeEvent"
//																						},
//																						"1HL4R98SI0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HRFTB7NE7",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HRFTB7NE8",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL4R98SI0",
//																							"faceTagName": "modeNavi"
//																						},
//																						"1HL4RBDGD3": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HRFTB7NE9",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HRFTB7NE10",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL4RBDGD3",
//																							"faceTagName": "modeQuery"
//																						},
//																						"1HU3VNM1Q0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HU40LIBT60",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HU40LIBT61",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HU3VNM1Q0",
//																							"faceTagName": "pageView"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1HRFTB7NE13",
//																					"attrs": {
//																						"OnClick": {
//																							"type": "fixedFunc",
//																							"jaxId": "1HRFTB7NE14",
//																							"attrs": {
//																								"callArgs": {
//																									"jaxId": "1HRFTB7NE15",
//																									"attrs": {
//																										"event": ""
//																									}
//																								},
//																								"seg": "1HPKRSTCP1"
//																							}
//																						}
//																					}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1HRFTB7NE16",
//																					"attrs": {
//																						"tip": {
//																							"type": "string",
//																							"valText": "Run Actions",
//																							"localizable": true
//																						}
//																					}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false",
//																				"containerSlots": {
//																					"jaxId": "1HRFTB7NE17",
//																					"attrs": {}
//																				}
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "Gear/@StdUI/ui/BtnIcon.js",
//																			"jaxId": "1HL25CK140",
//																			"attrs": {
//																				"createArgs": {
//																					"jaxId": "1HL25CK141",
//																					"attrs": {
//																						"style": "#cfgColor.fontBodySub",
//																						"w": "24",
//																						"h": "0",
//																						"icon": "#appCfg.sharedAssets+\"/trash.svg\"",
//																						"colorBG": "null"
//																					}
//																				},
//																				"properties": {
//																					"jaxId": "1HL25CK142",
//																					"attrs": {
//																						"type": "#null#>BtnIcon(cfgColor.fontBodySub,24,0,appCfg.sharedAssets+\"/trash.svg\",null)",
//																						"id": "BtnClearActions",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"display": "On",
//																						"face": "",
//																						"margin": "[0,3,0,0]",
//																						"enable": "false"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1HL25CK143",
//																					"attrs": {
//																						"1HL262SGC3": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HL26KVBJ2",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HL26KVBJ3",
//																									"attrs": {
//																										"enable": {
//																											"type": "bool",
//																											"valText": "false"
//																										}
//																									}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL262SGC3",
//																							"faceTagName": "openPage"
//																						},
//																						"1HL26Q52O0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HL26QJ3K20",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HL26QJ3K21",
//																									"attrs": {
//																										"enable": {
//																											"type": "bool",
//																											"valText": "true"
//																										}
//																									}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL26Q52O0",
//																							"faceTagName": "pageReady"
//																						},
//																						"1HL4RBDGD1": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HL5QD97V70",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HL5QD97V71",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL4RBDGD1",
//																							"faceTagName": "modeEvent"
//																						},
//																						"1HL4R98SI0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HL6IIVT516",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HL6IIVT517",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL4R98SI0",
//																							"faceTagName": "modeNavi"
//																						},
//																						"1HL4RBDGD3": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HLBUNSI814",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HLBUNSI815",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL4RBDGD3",
//																							"faceTagName": "modeQuery"
//																						},
//																						"1HU3VNM1Q0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HU40LIBT64",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HU40LIBT65",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HU3VNM1Q0",
//																							"faceTagName": "pageView"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1HL25CK144",
//																					"attrs": {
//																						"OnClick": {
//																							"type": "fixedFunc",
//																							"jaxId": "1HL25FOR60",
//																							"attrs": {
//																								"callArgs": {
//																									"jaxId": "1HL25FOR61",
//																									"attrs": {
//																										"event": ""
//																									}
//																								},
//																								"seg": "1HPKRSTCP1"
//																							}
//																						}
//																					}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1HL25CK150",
//																					"attrs": {
//																						"tip": {
//																							"type": "string",
//																							"valText": "Clear Actions",
//																							"localizable": true
//																						}
//																					}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false",
//																				"containerSlots": {
//																					"jaxId": "1HL25CK151",
//																					"attrs": {}
//																				}
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"jaxId": "1HL24MRIR1",
//																	"attrs": {
//																		"1HL4RBDGD1": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HL5QD97V72",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HL5QD97V73",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HL4RBDGD1",
//																			"faceTagName": "modeEvent"
//																		},
//																		"1HL4R98SI0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HL6IIVT520",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HL6IIVT521",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HL4R98SI0",
//																			"faceTagName": "modeNavi"
//																		},
//																		"1HL4RBDGD3": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HLBUNSI816",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HLBUNSI817",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HL4RBDGD3",
//																			"faceTagName": "modeQuery"
//																		},
//																		"1HL262SGC3": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HNBK0C3G22",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HNBK0C3G23",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HL262SGC3",
//																			"faceTagName": "openPage"
//																		},
//																		"1HU3VNM1Q0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HU40LIBT68",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HU40LIBT69",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HU3VNM1Q0",
//																			"faceTagName": "pageView"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HL24MRIR2",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HL24MRIR3",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1HL24JH7U0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HL24MRIR4",
//																	"attrs": {
//																		"type": "hud",
//																		"id": "BoxEventsScroll",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "100%-25",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Auto Scroll Y",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "[0,5,0,5]",
//																		"minW": "",
//																		"minH": "50",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "Gear/@StdUI/ui/DataView.js",
//																			"jaxId": "1HRERGE4B0",
//																			"attrs": {
//																				"createArgs": {
//																					"jaxId": "1HRERGE4B1",
//																					"attrs": {
//																						"box": "null",
//																						"template": "\"1HRER99Q80\"",
//																						"dataObj": "#actions",
//																						"property": "",
//																						"options": {
//																							"jaxId": "1HRERGE4B2",
//																							"attrs": {
//																								"titleHeight": "30",
//																								"titleSize": "16",
//																								"titleColor": "#cfgColor[\"fontBody\"]",
//																								"titleBold": "true",
//																								"lineHeight": "30",
//																								"lineGap": "5",
//																								"labelSize": "12",
//																								"labelColor": "#cfgColor[\"fontBody\"]",
//																								"labelBold": "false",
//																								"labelLine": "false",
//																								"valueSize": "14",
//																								"valueColor": "#cfgColor[\"fontBody\"]",
//																								"valueBold": "false",
//																								"segHeight": "20",
//																								"segSize": "14",
//																								"segBold": "true",
//																								"segColor": "#cfgColor[\"fontBody\"]",
//																								"trace": "false",
//																								"edit": "true",
//																								"noteSize": "12",
//																								"autoCollapse": "false",
//																								"hideCollapse": "false",
//																								"valueRightAlign": "false",
//																								"gridLine": "false"
//																							}
//																						},
//																						"title": ""
//																					}
//																				},
//																				"properties": {
//																					"jaxId": "1HRERGE4B3",
//																					"attrs": {
//																						"type": "#null#>DataView(null,\"1HRER99Q80\",actions,\"\",{\"titleHeight\":30,\"titleSize\":16,\"titleColor\":cfgColor[\"fontBody\"],\"titleBold\":true,\"lineHeight\":30,\"lineGap\":5,\"labelSize\":12,\"labelColor\":cfgColor[\"fontBody\"],\"labelBold\":false,\"labelLine\":false,\"valueSize\":14,\"valueColor\":cfgColor[\"fontBody\"],\"valueBold\":false,\"segHeight\":20,\"segSize\":14,\"segBold\":true,\"segColor\":cfgColor[\"fontBody\"],\"trace\":false,\"edit\":true,\"noteSize\":12,\"autoCollapse\":false,\"hideCollapse\":false,\"valueRightAlign\":false,\"gridLine\":false},\"\")",
//																						"id": "DvActions",
//																						"position": "Relative",
//																						"x": "0",
//																						"y": "0",
//																						"display": "On",
//																						"face": ""
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1HRERGE4B4",
//																					"attrs": {
//																						"1HU3VNM1Q0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HU40LIBT72",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HU40LIBT73",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HU3VNM1Q0",
//																							"faceTagName": "pageView"
//																						},
//																						"1HL262SGC3": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HVNF82588",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HVNF82589",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL262SGC3",
//																							"faceTagName": "openPage"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1HRERGE4B5",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1HRERGE4B6",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "true",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "true",
//																				"containerSlots": {
//																					"jaxId": "1HRERGE4B7",
//																					"attrs": {}
//																				}
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"jaxId": "1HL24MRIR5",
//																	"attrs": {
//																		"1HL4RBDGD1": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HL5QD97V84",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HL5QD97V85",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HL4RBDGD1",
//																			"faceTagName": "modeEvent"
//																		},
//																		"1HL4R98SI0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HL6IIVT528",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HL6IIVT529",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HL4R98SI0",
//																			"faceTagName": "modeNavi"
//																		},
//																		"1HL4RBDGD3": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HLBUNSI820",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HLBUNSI821",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HL4RBDGD3",
//																			"faceTagName": "modeQuery"
//																		},
//																		"1HL262SGC3": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HNBK0C3G26",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HNBK0C3G27",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HL262SGC3",
//																			"faceTagName": "openPage"
//																		},
//																		"1HU3VNM1Q0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HU40LIBT76",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HU40LIBT77",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HU3VNM1Q0",
//																			"faceTagName": "pageView"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HL24MRIR6",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HL24MRIR7",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "true",
//																"exposeContainer": "false"
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1HL24C4T29",
//													"attrs": {
//														"1HL4R98SI0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HL5MOANN108",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HL5MOANN109",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HL4R98SI0",
//															"faceTagName": "modeNavi"
//														},
//														"1HL4RBDGD1": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HL5MOANN110",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HL5MOANN111",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HL4RBDGD1",
//															"faceTagName": "modeEvent"
//														},
//														"1HL4RBDGD3": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HL5QD97V94",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HL5QD97V95",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HL4RBDGD3",
//															"faceTagName": "modeQuery"
//														},
//														"1HL262SGC3": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HNBK0C3G28",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HNBK0C3G29",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HL262SGC3",
//															"faceTagName": "openPage"
//														},
//														"1HU3VNM1Q0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HU40LIBT80",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HU40LIBT81",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HU3VNM1Q0",
//															"faceTagName": "pageView"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HL24C4T210",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HL24C4T211",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "true"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1HU3U79P00",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HU3U8T3M0",
//													"attrs": {
//														"type": "box",
//														"id": "BoxViewHeader",
//														"position": "Absolute",
//														"x": "300",
//														"y": "0",
//														"w": "100%-300",
//														"h": "25",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "[0,5,0,5]",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "[255,255,255,1.00]",
//														"border": "[0,0,1,0]",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]",
//														"contentLayout": "Flex X"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnNaviItem.js",
//															"jaxId": "1HU3UB4480",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1HU3UD8FR0",
//																	"attrs": {
//																		"code": "Home",
//																		"text": "Page view",
//																		"color": "[0,0,0,1.00]",
//																		"icon": "#appCfg.sharedAssets+\"/web.svg\"",
//																		"items": "",
//																		"fontSize": "#txtSize.smallPlus",
//																		"hasClose": "false",
//																		"iconSize": "0",
//																		"mark": "true"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1HU3UD8FR1",
//																	"attrs": {
//																		"type": "#null#>BtnNaviItem(\"Home\",\"Page view\",[0,0,0,1],appCfg.sharedAssets+\"/web.svg\",undefined,txtSize.smallPlus,false,0,true)",
//																		"id": "",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "\"focus\""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HU3UD8FR2",
//																	"attrs": {
//																		"1HU3VNM1Q0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HU3VP15C18",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HU3VP15C19",
//																					"attrs": {
//																						"face": {
//																							"type": "auto",
//																							"valText": "\"focus\"",
//																							"editType": "face"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HU3VNM1Q0",
//																			"faceTagName": "pageView"
//																		},
//																		"1HU3VP9B60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HU3VPV3S74",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HU3VPV3S75",
//																					"attrs": {
//																						"face": {
//																							"type": "auto",
//																							"valText": "\"blur\"",
//																							"editType": "face"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HU3VP9B60",
//																			"faceTagName": "eventView"
//																		},
//																		"1HL262SGC3": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HVNF82590",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HVNF82591",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HL262SGC3",
//																			"faceTagName": "openPage"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HU3UD8FR3",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HU41BKBO0",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1HU41C8VT0",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1HU3UD8FR4",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1HU3UD8FR5",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnNaviItem.js",
//															"jaxId": "1HU3UD9HR0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1HU3UD9HR1",
//																	"attrs": {
//																		"code": "Home",
//																		"text": "Events",
//																		"color": "[0,0,0,1.00]",
//																		"icon": "#appCfg.sharedAssets+\"/gas.svg\"",
//																		"items": "",
//																		"fontSize": "#txtSize.smallPlus",
//																		"hasClose": "false",
//																		"iconSize": "0",
//																		"mark": "true"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1HU3UD9HR2",
//																	"attrs": {
//																		"type": "#null#>BtnNaviItem(\"Home\",\"Events\",[0,0,0,1],appCfg.sharedAssets+\"/gas.svg\",undefined,txtSize.smallPlus,false,0,true)",
//																		"id": "",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"margin": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HU3UD9HS0",
//																	"attrs": {
//																		"1HU3VNM1Q0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HU3VP15C20",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HU3VP15C21",
//																					"attrs": {
//																						"face": {
//																							"type": "auto",
//																							"valText": "\"blur\"",
//																							"editType": "face"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HU3VNM1Q0",
//																			"faceTagName": "pageView"
//																		},
//																		"1HU3VP9B60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HU3VPV3S76",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HU3VPV3S77",
//																					"attrs": {
//																						"face": {
//																							"type": "auto",
//																							"valText": "\"focus\"",
//																							"editType": "face"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HU3VP9B60",
//																			"faceTagName": "eventView"
//																		},
//																		"1HL262SGC3": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HVNF82594",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HVNF82595",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HL262SGC3",
//																			"faceTagName": "openPage"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HU3UD9HS1",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HU41BKBO1",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1HU41C8VT1",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1HU3UD9HS2",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1HU3UD9HS3",
//																	"attrs": {}
//																}
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1HU3U8T3N0",
//													"attrs": {
//														"1HU3VNM1Q0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HU40LIBT84",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HU40LIBT85",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HU3VNM1Q0",
//															"faceTagName": "pageView"
//														},
//														"1HL262SGC3": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HVNF82598",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HVNF82599",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HL262SGC3",
//															"faceTagName": "openPage"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HU3U8T3N1",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HU3U8T3N2",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1HL4REOPC0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HL4RGRLV0",
//													"attrs": {
//														"type": "box",
//														"id": "BoxModeView",
//														"position": "Absolute",
//														"x": "300",
//														"y": "25",
//														"w": "100%-300",
//														"h": "100%-25",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "Off",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "[255,255,255,1.00]",
//														"border": "0",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1HL5NITDK0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HL5NLEP00",
//																	"attrs": {
//																		"type": "hud",
//																		"id": "BoxViewScroll",
//																		"position": "Absolute",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "100%-200",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Auto Scroll",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "20",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"contentLayout": "Flex Y"
//																	}
//																},
//																"subHuds": {
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "box",
//																			"jaxId": "1HL5NLLFP0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HL5NLLFP1",
//																					"attrs": {
//																						"type": "box",
//																						"id": "BoxPageImage",
//																						"position": "Relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "100%",
//																						"h": "100%",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "On",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"background": "[255,255,255,1.00]",
//																						"border": "2",
//																						"borderStyle": "Solid",
//																						"borderColor": "[0,0,0,1.00]",
//																						"corner": "6",
//																						"shadow": "false",
//																						"shadowX": "2",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowSpread": "0",
//																						"shadowColor": "[0,0,0,0.50]"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": [
//																						{
//																							"type": "hudobj",
//																							"def": "image",
//																							"jaxId": "1HL5NLLFQ0",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HL5NLLFQ1",
//																									"attrs": {
//																										"type": "image",
//																										"id": "ImgPage",
//																										"position": "Absolute",
//																										"x": "0",
//																										"y": "0",
//																										"w": "100%",
//																										"h": "100%",
//																										"anchorH": "Left",
//																										"anchorV": "Top",
//																										"autoLayout": "false",
//																										"display": "On",
//																										"clip": "Off",
//																										"uiEvent": "On",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "",
//																										"zIndex": "0",
//																										"margin": "",
//																										"padding": "",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": "",
//																										"image": "",
//																										"autoSize": "false",
//																										"fitSize": "Contain",
//																										"repeat": "false",
//																										"alignX": "Left",
//																										"alignY": "Top"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1HL5NLLFQ2",
//																									"attrs": {
//																										"1HL4RBDGD1": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HL5Q99G96",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HL5Q99G97",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HL4RBDGD1",
//																											"faceTagName": "modeEvent"
//																										},
//																										"1HL4R98SI0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HL6IIVT532",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HL6IIVT533",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HL4R98SI0",
//																											"faceTagName": "modeNavi"
//																										},
//																										"1HL4RBDGD3": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HLBUNSI822",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HLBUNSI823",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HL4RBDGD3",
//																											"faceTagName": "modeQuery"
//																										},
//																										"1HL262SGC3": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HNBK0C3G30",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HNBK0C3G31",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HL262SGC3",
//																											"faceTagName": "openPage"
//																										},
//																										"1HU3VNM1Q0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HU40LIBT88",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HU40LIBT89",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HU3VNM1Q0",
//																											"faceTagName": "pageView"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1HL5NLLFQ7",
//																									"attrs": {
//																										"OnLoad": {
//																											"type": "fixedFunc",
//																											"jaxId": "1HL5NLLFQ8",
//																											"attrs": {
//																												"callArgs": {
//																													"jaxId": "1HL5NLLFQ9",
//																													"attrs": {}
//																												},
//																												"seg": ""
//																											}
//																										},
//																										"OnClick": {
//																											"type": "fixedFunc",
//																											"jaxId": "1HL9L7SSN0",
//																											"attrs": {
//																												"callArgs": {
//																													"jaxId": "1HL9L95OH0",
//																													"attrs": {
//																														"event": ""
//																													}
//																												},
//																												"seg": "1HL9L7USU0"
//																											}
//																										}
//																									}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1HL5NLLFQ10",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "true",
//																								"container": "false",
//																								"nameVal": "true"
//																							}
//																						},
//																						{
//																							"type": "hudobj",
//																							"def": "box",
//																							"jaxId": "1HL6J7UQM0",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HL6J9ICQ0",
//																									"attrs": {
//																										"type": "box",
//																										"id": "BoxPoseH",
//																										"position": "Absolute",
//																										"x": "0",
//																										"y": "0",
//																										"w": "100%",
//																										"h": "20",
//																										"anchorH": "Left",
//																										"anchorV": "Top",
//																										"autoLayout": "false",
//																										"display": "Off",
//																										"clip": "Off",
//																										"uiEvent": "Tree Off",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "",
//																										"zIndex": "0",
//																										"margin": "",
//																										"padding": "",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": "",
//																										"background": "[0,155,255,0]",
//																										"border": "[1,0,1,0]",
//																										"borderStyle": "Solid",
//																										"borderColor": "[0,0,0,1.00]",
//																										"corner": "0",
//																										"shadow": "false",
//																										"shadowX": "2",
//																										"shadowY": "2",
//																										"shadowBlur": "3",
//																										"shadowSpread": "0",
//																										"shadowColor": "[0,0,0,0.50]"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1HL6J9ICR0",
//																									"attrs": {
//																										"1HL4R98SI0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HLBUNSI824",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HLBUNSI825",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HL4R98SI0",
//																											"faceTagName": "modeNavi"
//																										},
//																										"1HL4RBDGD1": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HLBUNSI826",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HLBUNSI827",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HL4RBDGD1",
//																											"faceTagName": "modeEvent"
//																										},
//																										"1HL4RBDGD3": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HLBUNSI828",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HLBUNSI829",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HL4RBDGD3",
//																											"faceTagName": "modeQuery"
//																										},
//																										"1HL262SGC3": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HNBK0C3G32",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HNBK0C3G33",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HL262SGC3",
//																											"faceTagName": "openPage"
//																										},
//																										"1HU3VNM1Q0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HU40LIBT92",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HU40LIBT93",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HU3VNM1Q0",
//																											"faceTagName": "pageView"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1HL6J9ICR1",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1HL6J9ICR2",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "true",
//																								"nameVal": "true"
//																							}
//																						},
//																						{
//																							"type": "hudobj",
//																							"def": "box",
//																							"jaxId": "1HL6J9QL40",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HL6J9QL41",
//																									"attrs": {
//																										"type": "box",
//																										"id": "BoxPoseV",
//																										"position": "Absolute",
//																										"x": "0",
//																										"y": "0",
//																										"w": "20",
//																										"h": "100%",
//																										"anchorH": "Left",
//																										"anchorV": "Top",
//																										"autoLayout": "false",
//																										"display": "Off",
//																										"clip": "Off",
//																										"uiEvent": "Tree Off",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "",
//																										"zIndex": "0",
//																										"margin": "",
//																										"padding": "",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": "",
//																										"background": "[0,155,255,0.0]",
//																										"border": "[0,1,0,1]",
//																										"borderStyle": "Solid",
//																										"borderColor": "[0,0,0,1.00]",
//																										"corner": "0",
//																										"shadow": "false",
//																										"shadowX": "2",
//																										"shadowY": "2",
//																										"shadowBlur": "3",
//																										"shadowSpread": "0",
//																										"shadowColor": "[0,0,0,0.50]"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1HL6J9QL50",
//																									"attrs": {
//																										"1HL4R98SI0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HLBUNSI830",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HLBUNSI831",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HL4R98SI0",
//																											"faceTagName": "modeNavi"
//																										},
//																										"1HL4RBDGD1": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HLBUNSI832",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HLBUNSI833",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HL4RBDGD1",
//																											"faceTagName": "modeEvent"
//																										},
//																										"1HL4RBDGD3": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HLBUNSI834",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HLBUNSI835",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HL4RBDGD3",
//																											"faceTagName": "modeQuery"
//																										},
//																										"1HL262SGC3": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HNBK0C3G34",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HNBK0C3G35",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HL262SGC3",
//																											"faceTagName": "openPage"
//																										},
//																										"1HU3VNM1Q0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HU40LIBT96",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HU40LIBT97",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HU3VNM1Q0",
//																											"faceTagName": "pageView"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1HL6J9QL51",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1HL6J9QL52",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "true",
//																								"nameVal": "true"
//																							}
//																						},
//																						{
//																							"type": "hudobj",
//																							"def": "box",
//																							"jaxId": "1HL9JK6CL0",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HL9JLCA60",
//																									"attrs": {
//																										"type": "box",
//																										"id": "BoxPose",
//																										"position": "Absolute",
//																										"x": "270",
//																										"y": "86",
//																										"w": "100",
//																										"h": "100",
//																										"anchorH": "Left",
//																										"anchorV": "Top",
//																										"autoLayout": "false",
//																										"display": "Off",
//																										"clip": "Off",
//																										"uiEvent": "Tree Off",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "",
//																										"zIndex": "0",
//																										"margin": "",
//																										"padding": "",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": "",
//																										"background": "[0,155,255,0.3]",
//																										"border": "1",
//																										"borderStyle": "Solid",
//																										"borderColor": "[0,0,0,1.00]",
//																										"corner": "0",
//																										"shadow": "false",
//																										"shadowX": "2",
//																										"shadowY": "2",
//																										"shadowBlur": "3",
//																										"shadowSpread": "0",
//																										"shadowColor": "[0,0,0,0.50]"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1HL9JLCA70",
//																									"attrs": {
//																										"1HL4R98SI0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HLBUNSI836",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HLBUNSI837",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HL4R98SI0",
//																											"faceTagName": "modeNavi"
//																										},
//																										"1HL4RBDGD1": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HLBUNSI838",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HLBUNSI839",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HL4RBDGD1",
//																											"faceTagName": "modeEvent"
//																										},
//																										"1HL4RBDGD3": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HLBUNSI840",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HLBUNSI841",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HL4RBDGD3",
//																											"faceTagName": "modeQuery"
//																										},
//																										"1HL262SGC3": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HNBK0C3G36",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HNBK0C3G37",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HL262SGC3",
//																											"faceTagName": "openPage"
//																										},
//																										"1HU3VNM1Q0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HU40LIBT100",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HU40LIBT101",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HU3VNM1Q0",
//																											"faceTagName": "pageView"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1HL9JLCA71",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1HL9JLCA72",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "true",
//																								"nameVal": "true"
//																							}
//																						}
//																					]
//																				},
//																				"faces": {
//																					"jaxId": "1HL5NLLFQ11",
//																					"attrs": {
//																						"1HL4RBDGD1": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HL5Q99G98",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HL5Q99G99",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL4RBDGD1",
//																							"faceTagName": "modeEvent"
//																						},
//																						"1HL4R98SI0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HL6IIVT536",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HL6IIVT537",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL4R98SI0",
//																							"faceTagName": "modeNavi"
//																						},
//																						"1HL4RBDGD3": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HLBUNSI842",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HLBUNSI843",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL4RBDGD3",
//																							"faceTagName": "modeQuery"
//																						},
//																						"1HL262SGC3": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HNBK0C3G38",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HNBK0C3G39",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL262SGC3",
//																							"faceTagName": "openPage"
//																						},
//																						"1HU3VNM1Q0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HU40LIBT104",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HU40LIBT105",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HU3VNM1Q0",
//																							"faceTagName": "pageView"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1HL5NLLFQ16",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1HL5NLLFQ17",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "true"
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"jaxId": "1HL5NLEP01",
//																	"attrs": {
//																		"1HL4RBDGD1": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HL5Q99G910",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HL5Q99G911",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HL4RBDGD1",
//																			"faceTagName": "modeEvent"
//																		},
//																		"1HL4R98SI0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HL6IIVT540",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HL6IIVT541",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HL4R98SI0",
//																			"faceTagName": "modeNavi"
//																		},
//																		"1HL4RBDGD3": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HLBUNSI844",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HLBUNSI845",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HL4RBDGD3",
//																			"faceTagName": "modeQuery"
//																		},
//																		"1HL262SGC3": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HNBK0C3G40",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HNBK0C3G41",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HL262SGC3",
//																			"faceTagName": "openPage"
//																		},
//																		"1HU3VNM1Q0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HU40LIBT108",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HU40LIBT109",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HU3VNM1Q0",
//																			"faceTagName": "pageView"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HL5NLEP02",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HL5NLEP03",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false",
//																"exposeContainer": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "box",
//															"jaxId": "1HL5OABSP0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HL5ODOF80",
//																	"attrs": {
//																		"type": "box",
//																		"id": "BoxImgInfo",
//																		"position": "Absolute",
//																		"x": "0",
//																		"y": "100%-200",
//																		"w": "100%",
//																		"h": "175",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Auto Scroll Y",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "5",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"background": "[255,255,255,1.00]",
//																		"border": "[1,0,1,0]",
//																		"borderStyle": "Solid",
//																		"borderColor": "[0,0,0,1.00]",
//																		"corner": "0",
//																		"shadow": "false",
//																		"shadowX": "2",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowSpread": "0",
//																		"shadowColor": "[0,0,0,0.50]",
//																		"contentLayout": "Flex Y"
//																	}
//																},
//																"subHuds": {
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "Gear1HL2BCKSE0",
//																			"jaxId": "1HL6HTJ1I0",
//																			"attrs": {
//																				"createArgs": {
//																					"jaxId": "1HL6HUB3C0",
//																					"attrs": {}
//																				},
//																				"properties": {
//																					"jaxId": "1HL6HUB3C1",
//																					"attrs": {
//																						"type": "#null#>BoxNodeInfo()",
//																						"id": "BoxNodeInfo",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"display": "On",
//																						"face": ""
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1HL6HUB3C2",
//																					"attrs": {
//																						"1HL4RBDGD1": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HL6IEMVO0",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HL6IEMVO1",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL4RBDGD1",
//																							"faceTagName": "modeEvent"
//																						},
//																						"1HL4R98SI0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HL6IIVT544",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HL6IIVT545",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL4R98SI0",
//																							"faceTagName": "modeNavi"
//																						},
//																						"1HL4RBDGD3": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HLBUNSI846",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HLBUNSI847",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL4RBDGD3",
//																							"faceTagName": "modeQuery"
//																						},
//																						"1HL262SGC3": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HNBK0C3G42",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HNBK0C3G43",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL262SGC3",
//																							"faceTagName": "openPage"
//																						},
//																						"1HU3VNM1Q0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HU40LIBT112",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HU40LIBT113",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HU3VNM1Q0",
//																							"faceTagName": "pageView"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1HL6HUB3C3",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1HL6HUB3C4",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "true",
//																				"containerSlots": {
//																					"jaxId": "1HL6HUB3C5",
//																					"attrs": {}
//																				}
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"jaxId": "1HL5ODOF81",
//																	"attrs": {
//																		"1HL4RBDGD1": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HL5Q99G912",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HL5Q99G913",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HL4RBDGD1",
//																			"faceTagName": "modeEvent"
//																		},
//																		"1HL4R98SI0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HL6IIVT548",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HL6IIVT549",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HL4R98SI0",
//																			"faceTagName": "modeNavi"
//																		},
//																		"1HL4RBDGD3": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HLBUNSI848",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HLBUNSI849",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HL4RBDGD3",
//																			"faceTagName": "modeQuery"
//																		},
//																		"1HL262SGC3": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HNBK0C3G44",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HNBK0C3G45",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HL262SGC3",
//																			"faceTagName": "openPage"
//																		},
//																		"1HU3VNM1Q0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HU40LIBU0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HU40LIBU1",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HU3VNM1Q0",
//																			"faceTagName": "pageView"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HL5ODOF82",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HL5ODOF83",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "true",
//																"container": "true",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1HLF5700O0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HLF57H6O0",
//																	"attrs": {
//																		"type": "hud",
//																		"id": "BoxSendAction",
//																		"position": "Absolute",
//																		"x": "0",
//																		"y": "100%-25",
//																		"w": "100%",
//																		"h": "25",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "[0,5,0,5]",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"contentLayout": "Flex X",
//																		"itemsAlign": "Center"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HLF57H6O1",
//																	"attrs": {
//																		"1HL4R98SI0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HLH3PIP414",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HLH3PIP415",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HL4R98SI0",
//																			"faceTagName": "modeNavi"
//																		},
//																		"1HL4RBDGD1": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HLH3PIP416",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HLH3PIP417",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HL4RBDGD1",
//																			"faceTagName": "modeEvent"
//																		},
//																		"1HL4RBDGD3": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HLH3PIP418",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HLH3PIP419",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HL4RBDGD3",
//																			"faceTagName": "modeQuery"
//																		},
//																		"1HL262SGC3": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HNBK0C3G52",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HNBK0C3G53",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HL262SGC3",
//																			"faceTagName": "openPage"
//																		},
//																		"1HU3VNM1Q0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HU40LIBU4",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HU40LIBU5",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HU3VNM1Q0",
//																			"faceTagName": "pageView"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HLF57H6O2",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HLF57H6O3",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false",
//																"exposeContainer": "false"
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1HL4RGRLV1",
//													"attrs": {
//														"1HL4R98SI0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HL5MBQ9F10",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HL5MBQ9F11",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HL4R98SI0",
//															"faceTagName": "modeNavi"
//														},
//														"1HL4RBDGD1": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HL5MOANN46",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HL5MOANN47",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HL4RBDGD1",
//															"faceTagName": "modeEvent"
//														},
//														"1HL4RBDGD3": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HL5MOANN48",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HL5MOANN49",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HL4RBDGD3",
//															"faceTagName": "modeQuery"
//														},
//														"1HL262SGC3": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HNBK0C3G54",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HNBK0C3G55",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HL262SGC3",
//															"faceTagName": "openPage"
//														},
//														"1HU3VNM1Q0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HU3VP15C16",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HU3VP15C17",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HU3VNM1Q0",
//															"faceTagName": "pageView"
//														},
//														"1HU3VP9B60": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HU3VPV3S72",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HU3VPV3S73",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HU3VP9B60",
//															"faceTagName": "eventView"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HL4RGRLV2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HL4RGRLV3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1HU404MGI0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HU405PUT0",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxEventView",
//														"position": "Absolute",
//														"x": "300",
//														"y": "25",
//														"w": "100%-300",
//														"h": "100%-25",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": ""
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "box",
//															"jaxId": "1HU40OQFI0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HU40Q0N30",
//																	"attrs": {
//																		"type": "box",
//																		"id": "",
//																		"position": "Absolute",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "100%-25",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"background": "#cfgColor[\"body\"]",
//																		"border": "0",
//																		"borderStyle": "Solid",
//																		"borderColor": "[0,0,0,1.00]",
//																		"corner": "0",
//																		"shadow": "false",
//																		"shadowX": "2",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowSpread": "0",
//																		"shadowColor": "[0,0,0,0.50]",
//																		"contentLayout": "Flex Y"
//																	}
//																},
//																"subHuds": {
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "hud",
//																			"jaxId": "1HU4VJKUP0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HU4VPBB20",
//																					"attrs": {
//																						"type": "hud",
//																						"id": "BoxEvents",
//																						"position": "Absolute",
//																						"x": "0",
//																						"y": "0",
//																						"w": "250",
//																						"h": "100%",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Auto Scroll Y",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": ""
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1HU4VPBB21",
//																					"attrs": {
//																						"1HL262SGC3": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HVNF825912",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HVNF825913",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL262SGC3",
//																							"faceTagName": "openPage"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1HU4VPBB22",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1HU4VPBB23",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "true",
//																				"exposeContainer": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "box",
//																			"jaxId": "1HU504SL40",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HU505LLO0",
//																					"attrs": {
//																						"type": "box",
//																						"id": "",
//																						"position": "Absolute",
//																						"x": "250",
//																						"y": "0",
//																						"w": "1",
//																						"h": "100%",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"background": "#cfgColor[\"secondary\"]",
//																						"border": "0",
//																						"borderStyle": "Solid",
//																						"borderColor": "[0,0,0,1.00]",
//																						"corner": "0",
//																						"shadow": "false",
//																						"shadowX": "2",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowSpread": "0",
//																						"shadowColor": "[0,0,0,0.50]"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1HU505LLO1",
//																					"attrs": {
//																						"1HL262SGC3": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HVNF825916",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HVNF825917",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL262SGC3",
//																							"faceTagName": "openPage"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1HU505LLO2",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1HU505LLO3",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "hud",
//																			"jaxId": "1HU6JR20P0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HU6JS69S0",
//																					"attrs": {
//																						"type": "hud",
//																						"id": "BoxEventInfo",
//																						"position": "relative",
//																						"x": "250",
//																						"y": "0",
//																						"w": "100%-250",
//																						"h": "100%",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Auto Scroll Y",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": ""
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": [
//																						{
//																							"type": "hudobj",
//																							"def": "Gear/@StdUI/ui/DataView.js",
//																							"jaxId": "1HU6JSGK40",
//																							"attrs": {
//																								"createArgs": {
//																									"jaxId": "1HU6JSGK41",
//																									"attrs": {
//																										"box": "null",
//																										"template": "null",
//																										"dataObj": "null",
//																										"property": "",
//																										"options": {
//																											"jaxId": "1HU6JSGK42",
//																											"attrs": {
//																												"titleHeight": "30",
//																												"titleSize": "18",
//																												"titleColor": "#cfgColor[\"fontBody\"]",
//																												"titleBold": "true",
//																												"lineHeight": "30",
//																												"lineGap": "5",
//																												"labelSize": "12",
//																												"labelColor": "#cfgColor[\"fontBody\"]",
//																												"labelBold": "false",
//																												"labelLine": "false",
//																												"valueSize": "14",
//																												"valueColor": "#cfgColor[\"fontBody\"]",
//																												"valueBold": "false",
//																												"segHeight": "20",
//																												"segSize": "14",
//																												"segBold": "true",
//																												"segColor": "#cfgColor[\"fontBody\"]",
//																												"trace": "false",
//																												"edit": "false",
//																												"noteSize": "12",
//																												"autoCollapse": "false",
//																												"hideCollapse": "false",
//																												"valueRightAlign": "false",
//																												"gridLine": "false"
//																											}
//																										},
//																										"title": ""
//																									}
//																								},
//																								"properties": {
//																									"jaxId": "1HU6JSGK50",
//																									"attrs": {
//																										"type": "#null#>DataView(null,null,null,\"\",{\"titleHeight\":30,\"titleSize\":18,\"titleColor\":cfgColor[\"fontBody\"],\"titleBold\":true,\"lineHeight\":30,\"lineGap\":5,\"labelSize\":12,\"labelColor\":cfgColor[\"fontBody\"],\"labelBold\":false,\"labelLine\":false,\"valueSize\":14,\"valueColor\":cfgColor[\"fontBody\"],\"valueBold\":false,\"segHeight\":20,\"segSize\":14,\"segBold\":true,\"segColor\":cfgColor[\"fontBody\"],\"trace\":false,\"edit\":false,\"noteSize\":12,\"autoCollapse\":false,\"hideCollapse\":false,\"valueRightAlign\":false,\"gridLine\":false},\"\")",
//																										"id": "DvEvent",
//																										"position": "Absolute",
//																										"x": "0",
//																										"y": "0",
//																										"display": "On",
//																										"face": "",
//																										"w": "100%",
//																										"h": "100%"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1HU6JSGK51",
//																									"attrs": {
//																										"1HL262SGC3": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HVNF825920",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HVNF825921",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HL262SGC3",
//																											"faceTagName": "openPage"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1HU6JSGK52",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1HU6JSGK53",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "true",
//																								"containerSlots": {
//																									"jaxId": "1HU6JSGK54",
//																									"attrs": {}
//																								}
//																							}
//																						},
//																						{
//																							"type": "hudobj",
//																							"def": "box",
//																							"jaxId": "1HU6KBJB00",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HU6KE8OI0",
//																									"attrs": {
//																										"type": "box",
//																										"id": "BoxCopyEvent",
//																										"position": "Absolute",
//																										"x": "100%-50",
//																										"y": "7",
//																										"w": "36",
//																										"h": "36",
//																										"anchorH": "Left",
//																										"anchorV": "Top",
//																										"autoLayout": "false",
//																										"display": "On",
//																										"clip": "Off",
//																										"uiEvent": "On",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "",
//																										"zIndex": "0",
//																										"margin": "",
//																										"padding": "",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": "",
//																										"background": "[255,255,255,1.00]",
//																										"border": "1",
//																										"borderStyle": "Solid",
//																										"borderColor": "[0,0,0,1.00]",
//																										"corner": "6",
//																										"shadow": "false",
//																										"shadowX": "2",
//																										"shadowY": "2",
//																										"shadowBlur": "3",
//																										"shadowSpread": "0",
//																										"shadowColor": "[0,0,0,0.50]"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": [
//																										{
//																											"type": "hudobj",
//																											"def": "Gear/@StdUI/ui/BtnIcon.js",
//																											"jaxId": "1HU6KCPAN0",
//																											"attrs": {
//																												"createArgs": {
//																													"jaxId": "1HU6KE8OI1",
//																													"attrs": {
//																														"style": "\"front\"",
//																														"w": "30",
//																														"h": "0",
//																														"icon": "#appCfg.sharedAssets+\"/copy.svg\"",
//																														"colorBG": "null"
//																													}
//																												},
//																												"properties": {
//																													"jaxId": "1HU6KE8OI2",
//																													"attrs": {
//																														"type": "#null#>BtnIcon(\"front\",30,0,appCfg.sharedAssets+\"/copy.svg\",null)",
//																														"id": "",
//																														"position": "Absolute",
//																														"x": "50%",
//																														"y": "50%",
//																														"display": "On",
//																														"face": "",
//																														"anchorH": "Center",
//																														"anchorV": "Center"
//																													}
//																												},
//																												"subHuds": {
//																													"attrs": []
//																												},
//																												"faces": {
//																													"jaxId": "1HU6KE8OI3",
//																													"attrs": {
//																														"1HL262SGC3": {
//																															"type": "hudface",
//																															"def": "HudFace",
//																															"jaxId": "1HVNF825924",
//																															"attrs": {
//																																"properties": {
//																																	"jaxId": "1HVNF825925",
//																																	"attrs": {}
//																																},
//																																"anis": {
//																																	"attrs": []
//																																}
//																															},
//																															"faceTagId": "1HL262SGC3",
//																															"faceTagName": "openPage"
//																														}
//																													}
//																												},
//																												"functions": {
//																													"jaxId": "1HU6KE8OI4",
//																													"attrs": {
//																														"OnClick": {
//																															"type": "fixedFunc",
//																															"jaxId": "1HU6LEKUJ0",
//																															"attrs": {
//																																"callArgs": {
//																																	"jaxId": "1HU6LGJNQ0",
//																																	"attrs": {
//																																		"event": ""
//																																	}
//																																},
//																																"seg": "1HU6LENEL0"
//																															}
//																														}
//																													}
//																												},
//																												"extraPpts": {
//																													"jaxId": "1HU6KE8OI5",
//																													"attrs": {}
//																												},
//																												"mockup": "false",
//																												"codes": "false",
//																												"locked": "false",
//																												"container": "false",
//																												"nameVal": "false",
//																												"containerSlots": {
//																													"jaxId": "1HU6KE8OI6",
//																													"attrs": {}
//																												}
//																											}
//																										}
//																									]
//																								},
//																								"faces": {
//																									"jaxId": "1HU6KE8OI7",
//																									"attrs": {
//																										"1HL262SGC3": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HVNF825928",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HVNF825929",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HL262SGC3",
//																											"faceTagName": "openPage"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1HU6KE8OI8",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1HU6KE8OI9",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "true",
//																								"nameVal": "true"
//																							}
//																						}
//																					]
//																				},
//																				"faces": {
//																					"jaxId": "1HU6JS69S1",
//																					"attrs": {
//																						"1HL262SGC3": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HVNF825932",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HVNF825933",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL262SGC3",
//																							"faceTagName": "openPage"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1HU6JS69S2",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1HU6JS69S3",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "false",
//																				"exposeContainer": "false"
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"jaxId": "1HU40Q0N31",
//																	"attrs": {
//																		"1HL262SGC3": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HVNF825936",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HVNF825937",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HL262SGC3",
//																			"faceTagName": "openPage"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HU40Q0N32",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HU40Q0N33",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "box",
//															"jaxId": "1HU40NHGT0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HU40OBR50",
//																	"attrs": {
//																		"type": "box",
//																		"id": "BoxEventFooter",
//																		"position": "Absolute",
//																		"x": "0",
//																		"y": "100%-25",
//																		"w": "100%",
//																		"h": "25",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"background": "[255,255,255,1.00]",
//																		"border": "[1,0,0,0]",
//																		"borderStyle": "Solid",
//																		"borderColor": "[0,0,0,1.00]",
//																		"corner": "0",
//																		"shadow": "false",
//																		"shadowX": "2",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowSpread": "0",
//																		"shadowColor": "[0,0,0,0.50]",
//																		"contentLayout": "Flex X",
//																		"itemsAlign": "Center"
//																	}
//																},
//																"subHuds": {
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "Gear/@StdUI/ui/BtnIcon.js",
//																			"jaxId": "1HU6JJJUB0",
//																			"attrs": {
//																				"createArgs": {
//																					"jaxId": "1HU6JLPPV0",
//																					"attrs": {
//																						"style": "\"front\"",
//																						"w": "24",
//																						"h": "0",
//																						"icon": "#appCfg.sharedAssets+\"/trash.svg\"",
//																						"colorBG": "null"
//																					}
//																				},
//																				"properties": {
//																					"jaxId": "1HU6JLPPV1",
//																					"attrs": {
//																						"type": "#null#>BtnIcon(\"front\",24,0,appCfg.sharedAssets+\"/trash.svg\",null)",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"display": "On",
//																						"face": ""
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1HU6JLPPV2",
//																					"attrs": {
//																						"1HL262SGC3": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HVNF825940",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HVNF825941",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL262SGC3",
//																							"faceTagName": "openPage"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1HU6JLPPV3",
//																					"attrs": {
//																						"OnClick": {
//																							"type": "fixedFunc",
//																							"jaxId": "1HU6JLPPV4",
//																							"attrs": {
//																								"callArgs": {
//																									"jaxId": "1HU6JLPPV5",
//																									"attrs": {
//																										"event": ""
//																									}
//																								},
//																								"seg": "1HU6JKP700"
//																							}
//																						}
//																					}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1HU6JLPPV6",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false",
//																				"containerSlots": {
//																					"jaxId": "1HU6JLPPV7",
//																					"attrs": {}
//																				}
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "Gear/@StdUI/ui/BtnIcon.js",
//																			"jaxId": "1HU6OUM1B0",
//																			"attrs": {
//																				"createArgs": {
//																					"jaxId": "1HU6OUM1B1",
//																					"attrs": {
//																						"style": "\"front\"",
//																						"w": "24",
//																						"h": "0",
//																						"icon": "#appCfg.sharedAssets+\"/menu.svg\"",
//																						"colorBG": "null"
//																					}
//																				},
//																				"properties": {
//																					"jaxId": "1HU6OUM1B2",
//																					"attrs": {
//																						"type": "#null#>BtnIcon(\"front\",24,0,appCfg.sharedAssets+\"/menu.svg\",null)",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"display": "On",
//																						"face": ""
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1HU6OUM1B3",
//																					"attrs": {
//																						"1HL262SGC3": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HVNF825944",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HVNF825945",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HL262SGC3",
//																							"faceTagName": "openPage"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1HU6OUM1B4",
//																					"attrs": {
//																						"OnClick": {
//																							"type": "fixedFunc",
//																							"jaxId": "1HU6OUM1B5",
//																							"attrs": {
//																								"callArgs": {
//																									"jaxId": "1HU6OUM1B6",
//																									"attrs": {
//																										"event": ""
//																									}
//																								},
//																								"seg": "1HU6P0BN10"
//																							}
//																						}
//																					}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1HU6OUM1B7",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false",
//																				"containerSlots": {
//																					"jaxId": "1HU6OUM1B8",
//																					"attrs": {}
//																				}
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"jaxId": "1HU40OBR51",
//																	"attrs": {
//																		"1HL262SGC3": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HVNF825948",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HVNF825949",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HL262SGC3",
//																			"faceTagName": "openPage"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HU40OBR52",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HU40OBR53",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false"
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1HU405PUT1",
//													"attrs": {
//														"1HU3VNM1Q0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HU40LIBU8",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HU40LIBU9",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HU3VNM1Q0",
//															"faceTagName": "pageView"
//														},
//														"1HU3VP9B60": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HU40LIBU10",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HU40LIBU11",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HU3VP9B60",
//															"faceTagName": "eventView"
//														},
//														"1HL262SGC3": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HVNF825952",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HVNF825953",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HL262SGC3",
//															"faceTagName": "openPage"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HU405PUT2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HU405PUT3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "true",
//												"exposeContainer": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1HL22QSD65",
//									"attrs": {
//										"1HL4RBDGD1": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HL5QD98020",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HL5QD98021",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HL4RBDGD1",
//											"faceTagName": "modeEvent"
//										},
//										"1HL26Q52O0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HL5QD98024",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HL5QD98025",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HL26Q52O0",
//											"faceTagName": "pageReady"
//										},
//										"1HL4R98SI0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HL6IIVT552",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HL6IIVT553",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HL4R98SI0",
//											"faceTagName": "modeNavi"
//										},
//										"1HL4RBDGD3": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HLBUNSI850",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HLBUNSI851",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HL4RBDGD3",
//											"faceTagName": "modeQuery"
//										},
//										"1HMJUGP5A0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HMJUHFO728",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HMJUHFO729",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HMJUGP5A0",
//											"faceTagName": "init"
//										},
//										"1HL262SGC3": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HNBK0C3G56",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HNBK0C3G57",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HL262SGC3",
//											"faceTagName": "openPage"
//										},
//										"1HU3VNM1Q0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HU40LIBU12",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HU40LIBU13",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HU3VNM1Q0",
//											"faceTagName": "pageView"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HL22QSD66",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HL22QSD67",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1HL22PA5I0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HL22QSD68",
//									"attrs": {
//										"type": "box",
//										"id": "BoxFooter",
//										"position": "Absolute",
//										"x": "0",
//										"y": "100%-30",
//										"w": "100%",
//										"h": "30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "[255,255,255,1.00]",
//										"border": "[1,0,0,0]",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1HL4QD39G0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HL4QM3ML0",
//													"attrs": {
//														"type": "hud",
//														"id": "",
//														"position": "Absolute",
//														"x": "0",
//														"y": "0",
//														"w": "100%-300",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": ""
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/NaviToolBar.js",
//															"jaxId": "1HL4QDRCJ0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1HL4QM3ML1",
//																	"attrs": {
//																		"tabBG": "true"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1HL4QM3ML2",
//																	"attrs": {
//																		"type": "#null#>NaviToolBar(true)",
//																		"id": "BoxFootNavi",
//																		"position": "Absolute",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HL4QM3ML3",
//																	"attrs": {
//																		"1HL4RBDGD1": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HL5QD98026",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HL5QD98027",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HL4RBDGD1",
//																			"faceTagName": "modeEvent"
//																		},
//																		"1HL4R98SI0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HL6IIVT556",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HL6IIVT557",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HL4R98SI0",
//																			"faceTagName": "modeNavi"
//																		},
//																		"1HL4RBDGD3": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HLBUNSI852",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HLBUNSI853",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HL4RBDGD3",
//																			"faceTagName": "modeQuery"
//																		},
//																		"1HL262SGC3": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HNBK0C3G58",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HNBK0C3G59",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HL262SGC3",
//																			"faceTagName": "openPage"
//																		},
//																		"1HU3VNM1Q0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HU40LIBU16",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HU40LIBU17",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HU3VNM1Q0",
//																			"faceTagName": "pageView"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HL4QM3ML4",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HL4QM3ML5",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1HL4QM3ML6",
//																	"attrs": {
//																		"Slot1HL4P0I9P0": {
//																			"jaxId": "1HL4QE5EI0",
//																			"attrs": {
//																				"subHuds": {
//																					"attrs": [
//																						{
//																							"type": "hudobj",
//																							"def": "Gear/@StdUI/ui/BtnIcon.js",
//																							"jaxId": "1HL4QKDA00",
//																							"attrs": {
//																								"createArgs": {
//																									"jaxId": "1HL4QKDA01",
//																									"attrs": {
//																										"style": "\"front\"",
//																										"w": "22",
//																										"h": "0",
//																										"icon": "#appCfg.sharedAssets+\"/uitree.svg\"",
//																										"colorBG": "null"
//																									}
//																								},
//																								"properties": {
//																									"jaxId": "1HL4QKDA02",
//																									"attrs": {
//																										"type": "#null#>BtnIcon(\"front\",22,0,appCfg.sharedAssets+\"/uitree.svg\",null)",
//																										"id": "BtnModeNavi",
//																										"position": "relative",
//																										"x": "0",
//																										"y": "0",
//																										"display": "On",
//																										"face": "",
//																										"margin": "[0,10,0,0]"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1HL4QKDA03",
//																									"attrs": {
//																										"1HL4R98SI0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HL4RBDGD7",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HL4RBDGD8",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HL4R98SI0",
//																											"faceTagName": "modeNavi"
//																										},
//																										"1HL4RBDGD1": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HL5MOANN130",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HL5MOANN131",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HL4RBDGD1",
//																											"faceTagName": "modeEvent"
//																										},
//																										"1HL4RBDGD3": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HL5MOANN132",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HL5MOANN133",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HL4RBDGD3",
//																											"faceTagName": "modeQuery"
//																										},
//																										"1HL26Q52O0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HL5MT1RC4",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HL5MT1RC5",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HL26Q52O0",
//																											"faceTagName": "pageReady"
//																										},
//																										"1HL262SGC3": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HL5MT1RC6",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HL5MT1RC7",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HL262SGC3",
//																											"faceTagName": "openPage"
//																										},
//																										"1HMJUGP5A0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HMJUHFO732",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HMJUHFO733",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HMJUGP5A0",
//																											"faceTagName": "init"
//																										},
//																										"1HU3VNM1Q0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HU3VP15C28",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HU3VP15C29",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HU3VNM1Q0",
//																											"faceTagName": "pageView"
//																										},
//																										"1HU3VP9B60": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HU3VPV3T6",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HU3VPV3T7",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HU3VP9B60",
//																											"faceTagName": "eventView"
//																										},
//																										"1HVNF6QSB0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HVNF7BCR70",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HVNF7BCR71",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HVNF6QSB0",
//																											"faceTagName": "dialog"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1HL4QKDA04",
//																									"attrs": {
//																										"OnClick": {
//																											"type": "fixedFunc",
//																											"jaxId": "1HL5N1LUM0",
//																											"attrs": {
//																												"callArgs": {
//																													"jaxId": "1HL5N1LUM1",
//																													"attrs": {
//																														"event": ""
//																													}
//																												},
//																												"seg": "1HL5MTCII0"
//																											}
//																										}
//																									}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1HL4QKDA05",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "true",
//																								"containerSlots": {
//																									"jaxId": "1HL4QKDA06",
//																									"attrs": {}
//																								}
//																							}
//																						},
//																						{
//																							"type": "hudobj",
//																							"def": "Gear/@StdUI/ui/BtnIcon.js",
//																							"jaxId": "1HL4QLFUF0",
//																							"attrs": {
//																								"createArgs": {
//																									"jaxId": "1HL4QLFUF1",
//																									"attrs": {
//																										"style": "\"front\"",
//																										"w": "22",
//																										"h": "0",
//																										"icon": "#appCfg.sharedAssets+\"/spot.svg\"",
//																										"colorBG": "null"
//																									}
//																								},
//																								"properties": {
//																									"jaxId": "1HL4QLFUF2",
//																									"attrs": {
//																										"type": "#null#>BtnIcon(\"front\",22,0,appCfg.sharedAssets+\"/spot.svg\",null)",
//																										"id": "BtnModeQuery",
//																										"position": "relative",
//																										"x": "0",
//																										"y": "0",
//																										"display": "On",
//																										"face": "",
//																										"margin": "[0,5,0,0]"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1HL4QLFUF3",
//																									"attrs": {
//																										"1HL4R98SI0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HL4RBDGD9",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HL4RBDGD10",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HL4R98SI0",
//																											"faceTagName": "modeNavi"
//																										},
//																										"1HL4RBDGD1": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HL5MOANN134",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HL5MOANN135",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HL4RBDGD1",
//																											"faceTagName": "modeEvent"
//																										},
//																										"1HL4RBDGD3": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HL5MOANN136",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HL5MOANN137",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HL4RBDGD3",
//																											"faceTagName": "modeQuery"
//																										},
//																										"1HL26Q52O0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HL5MT1RC8",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HL5MT1RC9",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HL26Q52O0",
//																											"faceTagName": "pageReady"
//																										},
//																										"1HL262SGC3": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HL5MT1RC10",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HL5MT1RC11",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HL262SGC3",
//																											"faceTagName": "openPage"
//																										},
//																										"1HMJUGP5A0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HMJUHFO740",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HMJUHFO741",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HMJUGP5A0",
//																											"faceTagName": "init"
//																										},
//																										"1HU3VNM1Q0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HU3VP15C30",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HU3VP15C31",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HU3VNM1Q0",
//																											"faceTagName": "pageView"
//																										},
//																										"1HU3VP9B60": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HU3VPV3T8",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HU3VPV3T9",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HU3VP9B60",
//																											"faceTagName": "eventView"
//																										},
//																										"1HVNF6QSB0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HVNF7BCR72",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HVNF7BCR73",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HVNF6QSB0",
//																											"faceTagName": "dialog"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1HL4QLFUF4",
//																									"attrs": {
//																										"OnClick": {
//																											"type": "fixedFunc",
//																											"jaxId": "1HL5N1LUM2",
//																											"attrs": {
//																												"callArgs": {
//																													"jaxId": "1HL5N1LUM3",
//																													"attrs": {
//																														"event": ""
//																													}
//																												},
//																												"seg": "1HL5N0K4N1"
//																											}
//																										}
//																									}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1HL4QLFUF5",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "true",
//																								"containerSlots": {
//																									"jaxId": "1HL4QLFUF6",
//																									"attrs": {}
//																								}
//																							}
//																						},
//																						{
//																							"type": "hudobj",
//																							"def": "hud",
//																							"jaxId": "1HL6GESIM0",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HL6GFLBV0",
//																									"attrs": {
//																										"type": "hud",
//																										"id": "BoxModeEvent",
//																										"position": "relative",
//																										"x": "0",
//																										"y": "0",
//																										"w": "22",
//																										"h": "22",
//																										"anchorH": "Left",
//																										"anchorV": "Top",
//																										"autoLayout": "false",
//																										"display": "On",
//																										"clip": "Off",
//																										"uiEvent": "On",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "",
//																										"zIndex": "0",
//																										"margin": "[0,10,0,0]",
//																										"padding": "",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": ""
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": [
//																										{
//																											"type": "hudobj",
//																											"def": "Gear/@StdUI/ui/BtnIcon.js",
//																											"jaxId": "1HL6GFDBO0",
//																											"attrs": {
//																												"createArgs": {
//																													"jaxId": "1HL6GFDBO1",
//																													"attrs": {
//																														"style": "\"front\"",
//																														"w": "22",
//																														"h": "0",
//																														"icon": "#appCfg.sharedAssets+\"/event.svg\"",
//																														"colorBG": "null"
//																													}
//																												},
//																												"properties": {
//																													"jaxId": "1HL6GFDBO2",
//																													"attrs": {
//																														"type": "#null#>BtnIcon(\"front\",22,0,appCfg.sharedAssets+\"/event.svg\",null)",
//																														"id": "BtnModeEvent",
//																														"position": "relative",
//																														"x": "0",
//																														"y": "0",
//																														"display": "On",
//																														"face": "",
//																														"margin": "[0,10,0,0]"
//																													}
//																												},
//																												"subHuds": {
//																													"attrs": []
//																												},
//																												"faces": {
//																													"jaxId": "1HL6GFDBP0",
//																													"attrs": {
//																														"1HL4R98SI0": {
//																															"type": "hudface",
//																															"def": "HudFace",
//																															"jaxId": "1HL6GFDBP1",
//																															"attrs": {
//																																"properties": {
//																																	"jaxId": "1HL6GFDBP2",
//																																	"attrs": {}
//																																},
//																																"anis": {
//																																	"attrs": []
//																																}
//																															},
//																															"faceTagId": "1HL4R98SI0",
//																															"faceTagName": "modeNavi"
//																														},
//																														"1HL4RBDGD1": {
//																															"type": "hudface",
//																															"def": "HudFace",
//																															"jaxId": "1HL6GFDBP3",
//																															"attrs": {
//																																"properties": {
//																																	"jaxId": "1HL6GFDBP4",
//																																	"attrs": {}
//																																},
//																																"anis": {
//																																	"attrs": []
//																																}
//																															},
//																															"faceTagId": "1HL4RBDGD1",
//																															"faceTagName": "modeEvent"
//																														},
//																														"1HL4RBDGD3": {
//																															"type": "hudface",
//																															"def": "HudFace",
//																															"jaxId": "1HL6GFDBP5",
//																															"attrs": {
//																																"properties": {
//																																	"jaxId": "1HL6GFDBP6",
//																																	"attrs": {}
//																																},
//																																"anis": {
//																																	"attrs": []
//																																}
//																															},
//																															"faceTagId": "1HL4RBDGD3",
//																															"faceTagName": "modeQuery"
//																														},
//																														"1HL26Q52O0": {
//																															"type": "hudface",
//																															"def": "HudFace",
//																															"jaxId": "1HL6GFDBP7",
//																															"attrs": {
//																																"properties": {
//																																	"jaxId": "1HL6GFDBP8",
//																																	"attrs": {}
//																																},
//																																"anis": {
//																																	"attrs": []
//																																}
//																															},
//																															"faceTagId": "1HL26Q52O0",
//																															"faceTagName": "pageReady"
//																														},
//																														"1HL262SGC3": {
//																															"type": "hudface",
//																															"def": "HudFace",
//																															"jaxId": "1HL6GFDBP9",
//																															"attrs": {
//																																"properties": {
//																																	"jaxId": "1HL6GFDBP10",
//																																	"attrs": {}
//																																},
//																																"anis": {
//																																	"attrs": []
//																																}
//																															},
//																															"faceTagId": "1HL262SGC3",
//																															"faceTagName": "openPage"
//																														},
//																														"1HMJUGP5A0": {
//																															"type": "hudface",
//																															"def": "HudFace",
//																															"jaxId": "1HMJUHFO734",
//																															"attrs": {
//																																"properties": {
//																																	"jaxId": "1HMJUHFO735",
//																																	"attrs": {}
//																																},
//																																"anis": {
//																																	"attrs": []
//																																}
//																															},
//																															"faceTagId": "1HMJUGP5A0",
//																															"faceTagName": "init"
//																														},
//																														"1HU3VNM1Q0": {
//																															"type": "hudface",
//																															"def": "HudFace",
//																															"jaxId": "1HU3VP15C32",
//																															"attrs": {
//																																"properties": {
//																																	"jaxId": "1HU3VP15C33",
//																																	"attrs": {}
//																																},
//																																"anis": {
//																																	"attrs": []
//																																}
//																															},
//																															"faceTagId": "1HU3VNM1Q0",
//																															"faceTagName": "pageView"
//																														},
//																														"1HU3VP9B60": {
//																															"type": "hudface",
//																															"def": "HudFace",
//																															"jaxId": "1HU3VPV3T10",
//																															"attrs": {
//																																"properties": {
//																																	"jaxId": "1HU3VPV3T11",
//																																	"attrs": {}
//																																},
//																																"anis": {
//																																	"attrs": []
//																																}
//																															},
//																															"faceTagId": "1HU3VP9B60",
//																															"faceTagName": "eventView"
//																														},
//																														"1HVNF6QSB0": {
//																															"type": "hudface",
//																															"def": "HudFace",
//																															"jaxId": "1HVNF7BCR74",
//																															"attrs": {
//																																"properties": {
//																																	"jaxId": "1HVNF7BCR75",
//																																	"attrs": {}
//																																},
//																																"anis": {
//																																	"attrs": []
//																																}
//																															},
//																															"faceTagId": "1HVNF6QSB0",
//																															"faceTagName": "dialog"
//																														}
//																													}
//																												},
//																												"functions": {
//																													"jaxId": "1HL6GFDBP11",
//																													"attrs": {
//																														"OnClick": {
//																															"type": "fixedFunc",
//																															"jaxId": "1HL6GFDBP12",
//																															"attrs": {
//																																"callArgs": {
//																																	"jaxId": "1HL6GFDBP13",
//																																	"attrs": {
//																																		"event": ""
//																																	}
//																																},
//																																"seg": ""
//																															}
//																														}
//																													}
//																												},
//																												"extraPpts": {
//																													"jaxId": "1HL6GFDBP14",
//																													"attrs": {}
//																												},
//																												"mockup": "false",
//																												"codes": "false",
//																												"locked": "false",
//																												"container": "false",
//																												"nameVal": "true",
//																												"containerSlots": {
//																													"jaxId": "1HL6GFDBP15",
//																													"attrs": {}
//																												}
//																											}
//																										},
//																										{
//																											"type": "hudobj",
//																											"def": "box",
//																											"jaxId": "1HL6GMFG70",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HL6GQI2B0",
//																													"attrs": {
//																														"type": "box",
//																														"id": "BoxEventMark",
//																														"position": "Absolute",
//																														"x": "100%-10",
//																														"y": "0",
//																														"w": "12",
//																														"h": "12",
//																														"anchorH": "Left",
//																														"anchorV": "Top",
//																														"autoLayout": "false",
//																														"display": "Off",
//																														"clip": "Off",
//																														"uiEvent": "Tree Off",
//																														"alpha": "1",
//																														"rotate": "0",
//																														"scale": "",
//																														"filter": "",
//																														"cursor": "",
//																														"zIndex": "0",
//																														"margin": "",
//																														"padding": "",
//																														"minW": "",
//																														"minH": "",
//																														"maxW": "",
//																														"maxH": "",
//																														"face": "",
//																														"styleClass": "",
//																														"background": "#cfgColor[\"error\"]",
//																														"border": "0",
//																														"borderStyle": "Solid",
//																														"borderColor": "[0,0,0,1.00]",
//																														"corner": "6",
//																														"shadow": "false",
//																														"shadowX": "2",
//																														"shadowY": "2",
//																														"shadowBlur": "3",
//																														"shadowSpread": "0",
//																														"shadowColor": "[0,0,0,0.50]"
//																													}
//																												},
//																												"subHuds": {
//																													"attrs": []
//																												},
//																												"faces": {
//																													"jaxId": "1HL6GQI2B1",
//																													"attrs": {
//																														"1HL4RBDGD1": {
//																															"type": "hudface",
//																															"def": "HudFace",
//																															"jaxId": "1HL6IEMVP0",
//																															"attrs": {
//																																"properties": {
//																																	"jaxId": "1HL6IEMVP1",
//																																	"attrs": {}
//																																},
//																																"anis": {
//																																	"attrs": []
//																																}
//																															},
//																															"faceTagId": "1HL4RBDGD1",
//																															"faceTagName": "modeEvent"
//																														},
//																														"1HL4R98SI0": {
//																															"type": "hudface",
//																															"def": "HudFace",
//																															"jaxId": "1HL6IEMVP2",
//																															"attrs": {
//																																"properties": {
//																																	"jaxId": "1HL6IEMVP3",
//																																	"attrs": {}
//																																},
//																																"anis": {
//																																	"attrs": []
//																																}
//																															},
//																															"faceTagId": "1HL4R98SI0",
//																															"faceTagName": "modeNavi"
//																														},
//																														"1HL4RBDGD3": {
//																															"type": "hudface",
//																															"def": "HudFace",
//																															"jaxId": "1HL6IG21J8",
//																															"attrs": {
//																																"properties": {
//																																	"jaxId": "1HL6IG21J9",
//																																	"attrs": {}
//																																},
//																																"anis": {
//																																	"attrs": []
//																																}
//																															},
//																															"faceTagId": "1HL4RBDGD3",
//																															"faceTagName": "modeQuery"
//																														},
//																														"1HL262SGC3": {
//																															"type": "hudface",
//																															"def": "HudFace",
//																															"jaxId": "1HLH3PIP420",
//																															"attrs": {
//																																"properties": {
//																																	"jaxId": "1HLH3PIP421",
//																																	"attrs": {}
//																																},
//																																"anis": {
//																																	"attrs": []
//																																}
//																															},
//																															"faceTagId": "1HL262SGC3",
//																															"faceTagName": "openPage"
//																														},
//																														"1HL26Q52O0": {
//																															"type": "hudface",
//																															"def": "HudFace",
//																															"jaxId": "1HLH3PIP422",
//																															"attrs": {
//																																"properties": {
//																																	"jaxId": "1HLH3PIP423",
//																																	"attrs": {}
//																																},
//																																"anis": {
//																																	"attrs": []
//																																}
//																															},
//																															"faceTagId": "1HL26Q52O0",
//																															"faceTagName": "pageReady"
//																														},
//																														"1HMJUGP5A0": {
//																															"type": "hudface",
//																															"def": "HudFace",
//																															"jaxId": "1HMJUHFO736",
//																															"attrs": {
//																																"properties": {
//																																	"jaxId": "1HMJUHFO737",
//																																	"attrs": {}
//																																},
//																																"anis": {
//																																	"attrs": []
//																																}
//																															},
//																															"faceTagId": "1HMJUGP5A0",
//																															"faceTagName": "init"
//																														},
//																														"1HU3VNM1Q0": {
//																															"type": "hudface",
//																															"def": "HudFace",
//																															"jaxId": "1HU3VP15C34",
//																															"attrs": {
//																																"properties": {
//																																	"jaxId": "1HU3VP15C35",
//																																	"attrs": {}
//																																},
//																																"anis": {
//																																	"attrs": []
//																																}
//																															},
//																															"faceTagId": "1HU3VNM1Q0",
//																															"faceTagName": "pageView"
//																														},
//																														"1HU3VP9B60": {
//																															"type": "hudface",
//																															"def": "HudFace",
//																															"jaxId": "1HU3VPV3T12",
//																															"attrs": {
//																																"properties": {
//																																	"jaxId": "1HU3VPV3T13",
//																																	"attrs": {}
//																																},
//																																"anis": {
//																																	"attrs": []
//																																}
//																															},
//																															"faceTagId": "1HU3VP9B60",
//																															"faceTagName": "eventView"
//																														},
//																														"1HVNF6QSB0": {
//																															"type": "hudface",
//																															"def": "HudFace",
//																															"jaxId": "1HVNF7BCR76",
//																															"attrs": {
//																																"properties": {
//																																	"jaxId": "1HVNF7BCS0",
//																																	"attrs": {}
//																																},
//																																"anis": {
//																																	"attrs": []
//																																}
//																															},
//																															"faceTagId": "1HVNF6QSB0",
//																															"faceTagName": "dialog"
//																														}
//																													}
//																												},
//																												"functions": {
//																													"jaxId": "1HL6GQI2B2",
//																													"attrs": {}
//																												},
//																												"extraPpts": {
//																													"jaxId": "1HL6GQI2B3",
//																													"attrs": {}
//																												},
//																												"mockup": "false",
//																												"codes": "false",
//																												"locked": "false",
//																												"container": "true",
//																												"nameVal": "true"
//																											}
//																										}
//																									]
//																								},
//																								"faces": {
//																									"jaxId": "1HL6GFLBV1",
//																									"attrs": {
//																										"1HL4RBDGD1": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HL6IEMVP4",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HL6IEMVP5",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HL4RBDGD1",
//																											"faceTagName": "modeEvent"
//																										},
//																										"1HL4R98SI0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HL6IEMVP6",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HL6IEMVP7",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HL4R98SI0",
//																											"faceTagName": "modeNavi"
//																										},
//																										"1HL4RBDGD3": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HL6IG21J10",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HL6IG21J11",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HL4RBDGD3",
//																											"faceTagName": "modeQuery"
//																										},
//																										"1HL262SGC3": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HLH3PIP424",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HLH3PIP425",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HL262SGC3",
//																											"faceTagName": "openPage"
//																										},
//																										"1HL26Q52O0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HLH3PIP426",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HLH3PIP427",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HL26Q52O0",
//																											"faceTagName": "pageReady"
//																										},
//																										"1HMJUGP5A0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HMJUHFO738",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HMJUHFO739",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HMJUGP5A0",
//																											"faceTagName": "init"
//																										},
//																										"1HU3VNM1Q0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HU3VP15C36",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HU3VP15C37",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HU3VNM1Q0",
//																											"faceTagName": "pageView"
//																										},
//																										"1HU3VP9B60": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HU3VPV3T14",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HU3VPV3T15",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HU3VP9B60",
//																											"faceTagName": "eventView"
//																										},
//																										"1HVNF6QSB0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HVNF7BCS1",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HVNF7BCS2",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HVNF6QSB0",
//																											"faceTagName": "dialog"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1HL6GFLBV2",
//																									"attrs": {
//																										"OnClick": {
//																											"type": "fixedFunc",
//																											"jaxId": "1HL6GLQUC0",
//																											"attrs": {
//																												"callArgs": {
//																													"jaxId": "1HL6GLQUC1",
//																													"attrs": {
//																														"event": ""
//																													}
//																												},
//																												"seg": "1HL5N0K4N0"
//																											}
//																										}
//																									}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1HL6GFLBV3",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "true",
//																								"nameVal": "true",
//																								"exposeContainer": "false"
//																							}
//																						}
//																					]
//																				},
//																				"container": "true"
//																			}
//																		}
//																	}
//																}
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1HL4QM3ML7",
//													"attrs": {
//														"1HL4RBDGD1": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HL5QD98032",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HL5QD98033",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HL4RBDGD1",
//															"faceTagName": "modeEvent"
//														},
//														"1HL4R98SI0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HL6IIVT560",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HL6IIVT561",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HL4R98SI0",
//															"faceTagName": "modeNavi"
//														},
//														"1HL4RBDGD3": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HLBUNSI854",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HLBUNSI855",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HL4RBDGD3",
//															"faceTagName": "modeQuery"
//														},
//														"1HL262SGC3": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HNBK0C3G60",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HNBK0C3G61",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HL262SGC3",
//															"faceTagName": "openPage"
//														},
//														"1HU3VNM1Q0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HU40LIBU20",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HU40LIBU21",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HU3VNM1Q0",
//															"faceTagName": "pageView"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HL4QM3ML8",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HL4QM3ML9",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1HL22QSD69",
//									"attrs": {
//										"1HL4RBDGD1": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HL5QD98038",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HL5QD98039",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HL4RBDGD1",
//											"faceTagName": "modeEvent"
//										},
//										"1HL26Q52O0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HL5QD98042",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HL5QD98043",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HL26Q52O0",
//											"faceTagName": "pageReady"
//										},
//										"1HL4R98SI0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HL6IIVT564",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HL6IIVT565",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HL4R98SI0",
//											"faceTagName": "modeNavi"
//										},
//										"1HL4RBDGD3": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HLBUNSI856",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HLBUNSI857",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HL4RBDGD3",
//											"faceTagName": "modeQuery"
//										},
//										"1HMJUGP5A0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HMJUHFO744",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HMJUHFO745",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HMJUGP5A0",
//											"faceTagName": "init"
//										},
//										"1HL262SGC3": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HNBK0C3G62",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HNBK0C3G63",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HL262SGC3",
//											"faceTagName": "openPage"
//										},
//										"1HU3VNM1Q0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HU40LIBU24",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HU40LIBU25",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HU3VNM1Q0",
//											"faceTagName": "pageView"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HL22QSD610",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HL22QSD611",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1HVNF5G9D0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HVNF6E5U0",
//									"attrs": {
//										"type": "box",
//										"id": "BoxDlgHeader",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "[0,5,0,5]",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "[255,255,255,1.00]",
//										"border": "[0,0,1,0]",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"contentLayout": "Flex X",
//										"itemsAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1HVNIGOP30",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HVNILC9N0",
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"w": "",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "Tree Off",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "[0,0,0]",
//														"text": "AAF-Spy",
//														"font": "",
//														"fontSize": "#txtSize.smallPlus",
//														"bold": "true",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Center",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0",
//														"flex": "true"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HVNILC9N1",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1HVNILC9N2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HVNILC9N3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1HVNIJMKQ0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1HVNILC9N4",
//													"attrs": {
//														"style": "\"front\"",
//														"w": "28",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/close.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1HVNILC9N5",
//													"attrs": {
//														"type": "#null#>BtnIcon(\"front\",28,0,appCfg.sharedAssets+\"/close.svg\",null)",
//														"id": "BtnClose",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": ""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HVNILC9N6",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1HVNILC9N7",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1HVNIMCKA0",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1HVNIMCKA1",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": "1HVNILP2L0"
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1HVNILC9N8",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1HVNILC9N9",
//													"attrs": {}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1HVNF6E5U1",
//									"attrs": {
//										"1HVNF6QSB0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HVNF7BCS7",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HVNF7BCS8",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HVNF6QSB0",
//											"faceTagName": "dialog"
//										},
//										"1HL262SGC3": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HVNF825A0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HVNF825A1",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HL262SGC3",
//											"faceTagName": "openPage"
//										},
//										"1HMJUGP5A0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HVNF825A2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HVNF825A3",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HMJUGP5A0",
//											"faceTagName": "init"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HVNF6E5U2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HVNF6E5U3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1GGJKM84D9",
//					"attrs": {
//						"1HL4RBDGD1": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HL5QD98044",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HL5QD98045",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HL4RBDGD1",
//							"faceTagName": "modeEvent"
//						},
//						"1HL4R98SI0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HL6IIVT568",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HL6IIVT569",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HL4R98SI0",
//							"faceTagName": "modeNavi"
//						},
//						"1HL4RBDGD3": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HLBUNSI858",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HLBUNSI859",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HL4RBDGD3",
//							"faceTagName": "modeQuery"
//						},
//						"1HL262SGC3": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HNBK0C3G64",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HNBK0C3G65",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HL262SGC3",
//							"faceTagName": "openPage"
//						},
//						"1HU3VNM1Q0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HU40LIBU28",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HU40LIBU29",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HU3VNM1Q0",
//							"faceTagName": "pageView"
//						},
//						"1HVNF6QSB0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HVNF7BCS9",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HVNF7BCS10",
//									"attrs": {
//										"anchorH": {
//											"type": "choice",
//											"valText": "Center"
//										}
//									}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HVNF6QSB0",
//							"faceTagName": "dialog"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1GGJKM84D10",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1GGJKM84D11",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1GGJKM84D12",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false",
//				"innerLayout": {
//					"valText": "false"
//				},
//				"marginL": {
//					"valText": "false"
//				},
//				"marginR": {
//					"valText": "false"
//				},
//				"marginT": {
//					"valText": "false"
//				},
//				"marginB": {
//					"valText": "false"
//				},
//				"paddingL": {
//					"valText": "false"
//				},
//				"paddingR": {
//					"valText": "false"
//				},
//				"paddingT": {
//					"valText": "false"
//				},
//				"paddingB": {
//					"valText": "false"
//				},
//				"attach": {
//					"valText": "false"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}