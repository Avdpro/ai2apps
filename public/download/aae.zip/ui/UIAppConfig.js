//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnText} from "/@StdUI/ui/BtnText.js";
import {DataView} from "/@StdUI/ui/DataView.js";
/*#{1IT1O07DP0StartDoc*/
import {AppConfig} from "../data/AppConfig.js";
/*}#1IT1O07DP0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let UIAppConfig=function(){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let btnReset,btnApply,dvConfig;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1IT1O07DP1LocalVals*/
	let orgConfig=null;
	/*}#1IT1O07DP1LocalVals*/
	
	/*#{1IT1O07DP1PreState*/
	/*}#1IT1O07DP1PreState*/
	/*#{1IT1O07DP1PostState*/
	/*}#1IT1O07DP1PostState*/
	cssVO={
		"hash":"1IT1O07DP1",nameHost:true,
		"type":"hud","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
		children:[
			{
				"hash":"1IT1PQ67R0",
				"type":"hud","id":"BoxHeader","x":0,"y":0,"w":"100%","h":40,"padding":[0,30,0,10],"styleClass":"","contentLayout":"flex-x","itemsAlign":1,
				children:[
					{
						"hash":"1IT1RR5F40",
						"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","styleClass":"","background":cfgColor["body"],"border":[0,0,1,0],"borderColor":cfgColor["fontBodySub"],
					},
					{
						"hash":"1IT1RJ8370",
						"type":"image","position":"relative","x":0,"y":0,"w":36,"h":36,"margin":[0,5,0,0],"styleClass":"","image":"/@tabos/shared/assets/aalogo.svg","fitSize":true,
					},
					{
						"hash":"1IT1QS37T0",
						"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","styleClass":"","color":cfgColor["fontBody"],"text":(($ln==="CN")?("系统设置"):("System settings")),
						"fontSize":txtSize.big,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
					},
					{
						"hash":"1IT1RMC8O0",
						"type":"hud","position":"relative","x":0,"y":0,"w":10,"h":"100%","maxW":"","styleClass":"","flex":true,
					},
					{
						"hash":"1IT1RLVHM0",
						"type":BtnText("warning",100,24,(($ln==="CN")?("重置"):("Reset")),false,""),"id":"BtnReset","position":"relative","x":0,"y":0,"margin":[0,10,0,0],
						"OnClick":function(event){
							self.resetConfig(this,event);
						},
					},
					{
						"hash":"1IT1RNTVB0",
						"type":BtnText("primary",100,24,(($ln==="CN")?("应用"):("Apply")),false,""),"id":"BtnApply","position":"relative","x":0,"y":0,
						"OnClick":function(event){
							self.applyConfig(this,event);
						},
					}
				],
			},
			{
				"hash":"1IT1PR0BD0",
				"type":"hud","id":"BoxContent","x":0,"y":40,"w":"100%","h":">calc(100% - 40px)","overflow":"auto","padding":10,"styleClass":"","contentLayout":"flex-y",
				children:[
					{
						"hash":"1IT1S3O570",
						"type":DataView(null,"1IT1SN0JL2",null,"",{"titleHeight":30,"titleSize":18,"titleColor":cfgColor["fontBody"],"titleBold":true,"lineHeight":30,"lineGap":20,"labelSize":txtSize.smallPlus,"labelColor":cfgColor["fontBody"],"labelBold":true,"labelLine":false,"valueSize":14,"valueColor":cfgColor["fontBody"],"valueBold":false,"segHeight":20,"segSize":14,"segBold":true,"segColor":cfgColor["fontBody"],"trace":false,"edit":true,"noteSize":12,"autoCollapse":false,"hideCollapse":false,"valueRightAlign":false,"gridLine":false},""),
						"id":"DvConfig","position":"relative","x":0,"y":0,"maxW":600,
					},
					{
						"hash":"1IT2GLIOS0",
						"type":"text","id":"TxtError","position":"relative","x":0,"y":0,"w":"100%","h":"","styleClass":"","color":[0,0,0],"text":(($ln==="CN")?("错误：系统配置API不可用。系统设置只能在AI2Apps应用程序内运行。"):("Error: System config API not available. System settings can only run inside AI2Apps App.")),
						"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
					}
				],
			}
		],
		/*#{1IT1O07DP1ExtraCSS*/
		/*}#1IT1O07DP1ExtraCSS*/
		faces:{
			"NoApi":{
				/*BtnReset*/"#1IT1RLVHM0":{
					"enable":false
				},
				/*BtnApply*/"#1IT1RNTVB0":{
					"enable":false
				},
				/*DvConfig*/"#1IT1S3O570":{
					"display":0
				},
				/*TxtError*/"#1IT2GLIOS0":{
					"display":1
				}
			},"HasApi":{
				/*BtnReset*/"#1IT1RLVHM0":{
					"enable":true
				},
				/*BtnApply*/"#1IT1RNTVB0":{
					"enable":true
				},
				/*DvConfig*/"#1IT1S3O570":{
					"display":0
				},
				/*TxtError*/"#1IT2GLIOS0":{
					"display":0
				}
			}
		},
		OnCreate:function(){
			self=this;
			btnReset=self.BtnReset;btnApply=self.BtnApply;dvConfig=self.DvConfig;
			/*#{1IT1O07DP1Create*/
			if(window.tabApi){
				self.showFace("HasApi");
				self.getConfig();
			}else{
				self.showFace("NoApi");
			}
			/*}#1IT1O07DP1Create*/
		},
		/*#{1IT1O07DP1EndCSS*/
		/*}#1IT1O07DP1EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.getConfig=async function(){
		/*#{1IT2KECAL0Start*/
		let config;
		try{
			config=await window.tabApi.getConfig();
		}catch(err){
			config=null;
		}
		if(config){
			orgConfig=config;
			dvConfig.setObject(AppConfig,config,{});
			dvConfig.display=true;
		}else{
			self.showFace("NoApi");
		}
		/*}#1IT2KECAL0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.applyConfig=async function(){
		/*#{1IT2KFP9N0Start*/
		let config;
		config=dvConfig.getEditedVO();
		if(config){
			if(!window.confirm((($ln==="CN")?("AI2Apps将会重新启动，您确定要更新系统配置吗?"):/*EN*/("AI2Apps will be restarted, are you sure to update system config?")))){
				return;
			}
			window.tabApi.setConfig(config);
		}
		/*}#1IT2KFP9N0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.resetConfig=async function(){
		/*#{1IT2PK4RG0Start*/
		dvConfig.setObject(AppConfig,orgConfig,{});
		/*}#1IT2PK4RG0Start*/
	};
	/*#{1IT1O07DP1PostCSSVO*/
	/*}#1IT1O07DP1PostCSSVO*/
	cssVO.constructor=UIAppConfig;
	return cssVO;
};
/*#{1IT1O07DP1ExCodes*/
/*}#1IT1O07DP1ExCodes*/

//----------------------------------------------------------------------------
UIAppConfig.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1IT1O07DP1PreAISpot*/
	/*}#1IT1O07DP1PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1IT1O07DP1PostAISpot*/
	/*}#1IT1O07DP1PostAISpot*/
	return exposeVO;
};

/*#{1IT1O07DP0EndDoc*/
/*}#1IT1O07DP0EndDoc*/

export default UIAppConfig;
export{UIAppConfig};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1IT1O07DP0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1IT1O07DP2",
//			"attrs": {
//				"device": "Desktop 800x600",
//				"screenW": "800",
//				"screenH": "600",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1IT1O07DP3",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1IT1O07DP4",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1IT1O07DP5",
//			"attrs": {}
//		},
//		"localVars": {
//			"jaxId": "1IT1O07DP6",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1IT1O07DP7",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IT2KECAL0",
//					"attrs": {
//						"id": "getConfig",
//						"label": "New AI Seg",
//						"x": "95",
//						"y": "95",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IT2KEKBA0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IT2KEKBA1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IT2KEKBA2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IT2KFP9N0",
//					"attrs": {
//						"id": "applyConfig",
//						"label": "New AI Seg",
//						"x": "95",
//						"y": "190",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IT2KKH4S0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IT2KKH4S1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IT2KKH4S2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IT2PK4RG0",
//					"attrs": {
//						"id": "resetConfig",
//						"label": "New AI Seg",
//						"x": "95",
//						"y": "280",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IT2PKGNS0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IT2PKGNS1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IT2PKGNS2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				}
//			]
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1IT1O07DP8",
//			"attrs": {
//				"NoApi": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IT2KCDG00",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IT2KD51F0",
//							"attrs": {}
//						}
//					}
//				},
//				"HasApi": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IT2KDD8H0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IT2KE28G0",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1IT1O07DP9",
//			"attrs": {}
//		},
//		"exposeToAI": "true",
//		"descAI": "",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1IT1O07DP1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1IT1O07DP10",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "100%",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": ""
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1IT1PQ67R0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IT1PQP090",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxHeader",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "40",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "[0,30,0,10]",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex X",
//										"itemsAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1IT1RR5F40",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IT1RS3HF0",
//													"attrs": {
//														"type": "box",
//														"id": "BoxBG",
//														"position": "Absolute",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "#cfgColor[\"body\"]",
//														"border": "[0,0,1,0]",
//														"borderStyle": "Solid",
//														"borderColor": "#cfgColor[\"fontBodySub\"]",
//														"corner": "0",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IT1RS3HF1",
//													"attrs": {
//														"1IT2KCDG00": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IT2KRNF80",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IT2KRNF81",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IT2KCDG00",
//															"faceTagName": "NoApi"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IT1RS3HF2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IT1RS3HF3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "image",
//											"jaxId": "1IT1RJ8370",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IT1RPLPD0",
//													"attrs": {
//														"type": "image",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "36",
//														"h": "36",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[0,5,0,0]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"image": "/@tabos/shared/assets/aalogo.svg",
//														"autoSize": "false",
//														"fitSize": "Fit",
//														"repeat": "true",
//														"alignX": "Left",
//														"alignY": "Top"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IT1RPLPD1",
//													"attrs": {
//														"1IT2KCDG00": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IT2KRNF84",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IT2KRNF85",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IT2KCDG00",
//															"faceTagName": "NoApi"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IT1RPLPD2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IT1RPLPD3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1IT1QS37T0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IT1RPLPD4",
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBody\"]",
//														"text": {
//															"type": "string",
//															"valText": "System settings",
//															"localize": {
//																"EN": "System settings",
//																"CN": "系统设置"
//															},
//															"localizable": true
//														},
//														"font": "",
//														"fontSize": "#txtSize.big",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IT1RPLPD5",
//													"attrs": {
//														"1IT2KCDG00": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IT2KRNF88",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IT2KRNF89",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IT2KCDG00",
//															"faceTagName": "NoApi"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IT1RPLPD6",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IT1RPLPD7",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1IT1RMC8O0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IT1RPLPD8",
//													"attrs": {
//														"type": "hud",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "10",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"flex": "true"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IT1RPLPD9",
//													"attrs": {
//														"1IT2KCDG00": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IT2KRNF812",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IT2KRNF813",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IT2KCDG00",
//															"faceTagName": "NoApi"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IT1RPLPD10",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IT1RPLPD11",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnText.js",
//											"jaxId": "1IT1RLVHM0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1IT1RPLPD12",
//													"attrs": {
//														"style": "warning",
//														"w": "100",
//														"h": "24",
//														"text": {
//															"type": "string",
//															"valText": "Reset",
//															"localize": {
//																"EN": "Reset",
//																"CN": "重置"
//															},
//															"localizable": true
//														},
//														"outlined": "false",
//														"icon": ""
//													}
//												},
//												"properties": {
//													"jaxId": "1IT1RPLPD13",
//													"attrs": {
//														"type": "#null#>BtnText(\"warning\",100,24,(($ln===\"CN\")?(\"重置\"):(\"Reset\")),false,\"\")",
//														"id": "BtnReset",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"enable": "true",
//														"margin": "[0,10,0,0]"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IT1RPLPD14",
//													"attrs": {
//														"1IT2KCDG00": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IT2KRNF816",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IT2KRNF817",
//																	"attrs": {
//																		"enable": "false"
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IT2KCDG00",
//															"faceTagName": "NoApi"
//														},
//														"1IT2KDD8H0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IT2KRNF818",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IT2KRNF819",
//																	"attrs": {
//																		"enable": "true"
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IT2KDD8H0",
//															"faceTagName": "HasApi"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IT1RPLPD15",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1IT2PLFJF0",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1IT2PLFJF1",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": "1IT2PK4RG0"
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1IT1RPLPD16",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1IT1RPLPD17",
//													"attrs": {
//														"Slot1H2F6U36O0": {
//															"jaxId": "1IT1RPLPD18",
//															"attrs": {
//																"subHuds": {
//																	"attrs": []
//																},
//																"container": "true"
//															}
//														}
//													}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnText.js",
//											"jaxId": "1IT1RNTVB0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1IT1RPLPD19",
//													"attrs": {
//														"style": "primary",
//														"w": "100",
//														"h": "24",
//														"text": {
//															"type": "string",
//															"valText": "Apply",
//															"localize": {
//																"EN": "Apply",
//																"CN": "应用"
//															},
//															"localizable": true
//														},
//														"outlined": "false",
//														"icon": ""
//													}
//												},
//												"properties": {
//													"jaxId": "1IT1RPLPD20",
//													"attrs": {
//														"type": "#null#>BtnText(\"primary\",100,24,(($ln===\"CN\")?(\"应用\"):(\"Apply\")),false,\"\")",
//														"id": "BtnApply",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": ""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IT1RPLPD21",
//													"attrs": {
//														"1IT2KCDG00": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IT2KRNF820",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IT2KRNF821",
//																	"attrs": {
//																		"enable": "false"
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IT2KCDG00",
//															"faceTagName": "NoApi"
//														},
//														"1IT2KDD8H0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IT2KRNF822",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IT2KRNF823",
//																	"attrs": {
//																		"enable": "true"
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IT2KDD8H0",
//															"faceTagName": "HasApi"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IT1RPLPD22",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1IT2PLFJF2",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1IT2PLFJF3",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": "1IT2KFP9N0"
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1IT1RPLPD23",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1IT1RPLPD24",
//													"attrs": {
//														"Slot1H2F6U36O0": {
//															"jaxId": "1IT1RPLPD25",
//															"attrs": {
//																"subHuds": {
//																	"attrs": []
//																},
//																"container": "true"
//															}
//														}
//													}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1IT1PQP091",
//									"attrs": {
//										"1IT2KCDG00": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IT2KRNF824",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IT2KRNF825",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IT2KCDG00",
//											"faceTagName": "NoApi"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1IT1PQP092",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IT1PQP093",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "true",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1IT1PR0BD0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IT1RPLPD26",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxContent",
//										"position": "Absolute",
//										"x": "0",
//										"y": "40",
//										"w": "100%",
//										"h": "100%-40",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Auto Scroll",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "10",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex Y"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/DataView.js",
//											"jaxId": "1IT1S3O570",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1IT1S4BC90",
//													"attrs": {
//														"box": "null",
//														"template": "\"1IT1SN0JL2\"",
//														"dataObj": "null",
//														"property": "",
//														"options": {
//															"jaxId": "1IT1S4BC91",
//															"attrs": {
//																"titleHeight": "30",
//																"titleSize": "18",
//																"titleColor": "#cfgColor[\"fontBody\"]",
//																"titleBold": "true",
//																"lineHeight": "30",
//																"lineGap": "20",
//																"labelSize": "#txtSize.smallPlus",
//																"labelColor": "#cfgColor[\"fontBody\"]",
//																"labelBold": "true",
//																"labelLine": "false",
//																"valueSize": "14",
//																"valueColor": "#cfgColor[\"fontBody\"]",
//																"valueBold": "false",
//																"segHeight": "20",
//																"segSize": "14",
//																"segBold": "true",
//																"segColor": "#cfgColor[\"fontBody\"]",
//																"trace": "false",
//																"edit": "true",
//																"noteSize": "12",
//																"autoCollapse": "false",
//																"hideCollapse": "false",
//																"valueRightAlign": "false",
//																"gridLine": "false"
//															}
//														},
//														"title": ""
//													}
//												},
//												"properties": {
//													"jaxId": "1IT1S4BC92",
//													"attrs": {
//														"type": "#null#>DataView(null,\"1IT1SN0JL2\",null,\"\",{\"titleHeight\":30,\"titleSize\":18,\"titleColor\":cfgColor[\"fontBody\"],\"titleBold\":true,\"lineHeight\":30,\"lineGap\":20,\"labelSize\":txtSize.smallPlus,\"labelColor\":cfgColor[\"fontBody\"],\"labelBold\":true,\"labelLine\":false,\"valueSize\":14,\"valueColor\":cfgColor[\"fontBody\"],\"valueBold\":false,\"segHeight\":20,\"segSize\":14,\"segBold\":true,\"segColor\":cfgColor[\"fontBody\"],\"trace\":false,\"edit\":true,\"noteSize\":12,\"autoCollapse\":false,\"hideCollapse\":false,\"valueRightAlign\":false,\"gridLine\":false},\"\")",
//														"id": "DvConfig",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"maxW": "600"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IT1S4BC93",
//													"attrs": {
//														"1IT2KCDG00": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IT2KD51G12",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IT2KD51G13",
//																	"attrs": {
//																		"display": "Off"
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IT2KCDG00",
//															"faceTagName": "NoApi"
//														},
//														"1IT2KDD8H0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IT2KE28G15",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IT2KE28G16",
//																	"attrs": {
//																		"display": "Off"
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IT2KDD8H0",
//															"faceTagName": "HasApi"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IT1S4BC94",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IT1S4BC95",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1IT1S4BC96",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1IT2GLIOS0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IT2GOVQT0",
//													"attrs": {
//														"type": "text",
//														"id": "TxtError",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "[0,0,0]",
//														"text": {
//															"type": "string",
//															"valText": "Error: System config API not available. System settings can only run inside AI2Apps App.",
//															"localize": {
//																"EN": "Error: System config API not available. System settings can only run inside AI2Apps App.",
//																"CN": "错误：系统配置API不可用。系统设置只能在AI2Apps应用程序内运行。"
//															},
//															"localizable": true
//														},
//														"font": "",
//														"fontSize": "16",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IT2GOVQT1",
//													"attrs": {
//														"1IT2KCDG00": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IT2KD51G14",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IT2KD51G15",
//																	"attrs": {
//																		"display": "On"
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IT2KCDG00",
//															"faceTagName": "NoApi"
//														},
//														"1IT2KDD8H0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IT2KE28G17",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IT2KE28G18",
//																	"attrs": {
//																		"display": "Off"
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IT2KDD8H0",
//															"faceTagName": "HasApi"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IT2GOVQT2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IT2GOVQT3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1IT1RPLPD27",
//									"attrs": {
//										"1IT2KCDG00": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IT2KRNF828",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IT2KRNF829",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IT2KCDG00",
//											"faceTagName": "NoApi"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1IT1RPLPD28",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IT1RPLPD29",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1IT1O07DP11",
//					"attrs": {
//						"1IT2KCDG00": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1IT2KRNF832",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IT2KRNF833",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1IT2KCDG00",
//							"faceTagName": "NoApi"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1IT1O07DP12",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1IT1O07DP13",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1IT1O07DP14",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}