//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1I5N374210StartDoc*/
import {tabFS} from "/@tabos";
import pathLib from "/@path";
/*}#1I5N374210StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BoxAAChatAsset=function(session,label,url){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let imgPic;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let image=true;
	let audio=false;
	
	/*#{1I5N374211LocalVals*/
	let app,labelExt,urlExt;
	app=VFACT.app;
	labelExt=pathLib.extname(label).toLowerCase();
	urlExt=pathLib.extname(url).toLowerCase();
	switch(labelExt){
		case ".jpg":
		case ".png":
		case ".gif":
		case ".svg":
			image=true;
			break;
		case ".mp3":
			audio=true;
			break;
	}
	switch(urlExt){
		case ".jpg":
		case ".png":
		case ".gif":
		case ".svg":
			image=true;
			break;
		case ".mp3":
			audio=true;
			break;
	}
	/*}#1I5N374211LocalVals*/
	
	/*#{1I5N374211PreState*/
	/*}#1I5N374211PreState*/
	/*#{1I5N374211PostState*/
	/*}#1I5N374211PostState*/
	cssVO={
		"hash":"1I5N374211",nameHost:true,
		"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":"","minW":"","minH":20,"maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
		children:[
			{
				"hash":"1I5N38D3Q0",
				"type":"hud","id":"BoxHeader","position":"relative","x":0,"y":0,"w":"100%","h":24,"margin":[0,0,5,0],"padding":[0,5,0,5],"styleClass":"","contentLayout":"flex-x",
				"itemsAlign":1,
				children:[
					{
						"hash":"1I5N39Q9R0",
						"type":"box","position":"relative","x":0,"y":0,"w":20,"h":20,"margin":[0,5,0,0],"styleClass":"","background":cfgColor["fontBodySub"],"border":1,
						"maskImage":appCfg.sharedAssets+"/link.svg",
					},
					{
						"hash":"1I5N3BIJM0",
						"type":"text","id":"TxtLabel","position":"relative","x":0,"y":0,"w":"","h":"","cursor":"pointer","styleClass":"","color":[0,0,0],"text":label,"fontSize":txtSize.smallPlus,
						"fontWeight":"bold","fontStyle":"normal","textDecoration":"underline",
						"OnClick":function(event){
							self.OnAssetClick(this,event);
						},
					}
				],
			},
			{
				"hash":"1I5N3K1AA0",
				"type":"image","id":"ImgPic","position":"relative","x":20,"y":0,"w":100,"h":100,"styleClass":"","fitSize":true,"attached":image,
				"OnLoad":function(){
					/*#{1I5N3NADA0FunctionBody*/
					let imgW,imgH,pw,maxW,maxH,ph;
					imgW=this.imageW;imgH=this.imageH;
					pw=this.parent.w;
					maxW=pw*0.8;
					maxH=pw*2;
					if(imgW<maxW && imgH<maxH){
						this.w=imgW;this.h=imgH;
					}else if(imgW>=maxW && imgH>=maxH){
						ph=maxH/imgH;
						pw=maxW/imgW;
						if(pw>ph){
							this.h=maxH;
							this.w=maxH/imgH*imgW;
						}else{
							this.w=maxW;
							this.h=maxW/imgW*imgH;
						}
					}else if(imgW>=maxW){
						this.w=maxW;
						this.h=maxW/imgW*imgH;
					}else{
						this.h=maxH;
						this.w=maxH/imgH*imgW;
					}
					/*}#1I5N3NADA0FunctionBody*/
				},
			}
		],
		/*#{1I5N374211ExtraCSS*/
		/*}#1I5N374211ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			self=this;
			imgPic=self.ImgPic;
			/*#{1I5N374211Create*/
			if(image){
				imgPic.image=url;
			}
			if(audio){
				//TODO: Code this:
			}
			/*}#1I5N374211Create*/
		},
		/*#{1I5N374211EndCSS*/
		/*}#1I5N374211EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.saveAsset=async function(){
		/*#{1I5N43H450Start*/
		let data,path,filePath;
		data=await (await fetch(url)).arrayBuffer();
		//TODO: Code this:
		path="/doc";//TODO: save and load?
		filePath=await app.modalDlg("/@homekit/ui/DlgFile.js",{
			mode:"save",
			path:path,
			fileName:pathLib.basename(label),
			options:{
				preview:false,
			},
			callback:async function(filePath){
				let list,doc;
			}
		});
		if(!filePath){
			return;
		}
		await tabFS.writeFile(filePath,data);
		/*}#1I5N43H450Start*/
	};
	//------------------------------------------------------------------------
	cssVO.downloadAsset=async function(){
		/*#{1I5N43S3D0Start*/
		let fileName;
		function downloadBuf(data){
			var img = new Image();
			img.crossOrigin = "Anonymous";
			img.src = data;
			img.onload = function () {
				var canvas = document.createElement("canvas");
				var context = canvas.getContext("2d");
				canvas.width = img.width;
				canvas.height = img.height;
				context.drawImage(img, 0, 0);
				var dataURL = canvas.toDataURL("image/png");
				var link = document.createElement("a");
				link.href = dataURL;
				link.download = "image.png";
				link.click();
		
				//Release the URLData:
				window.setTimeout(() => {
					URL.revokeObjectURL(dataURL);
				}, 10000);
			};
		}
		function downloadFile(data){
			let e,blob,url;
			blob = new Blob([data], {type: "application/octet-stream"});
			url = URL.createObjectURL(blob);
			VFACT.webFileDownload.download = fileName;
			VFACT.webFileDownload.href = url;
		
			//Generate a mouse click:
			e = document.createEvent('MouseEvents');
			e.initEvent('click', true, false, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null);
			VFACT.webFileDownload.dispatchEvent(e);
		
			//Release the URLData:
			window.setTimeout(() => {
				URL.revokeObjectURL(url);
			}, 10000);
		}
		fileName=label;
		if(fileName.startsWith("data:image/jpeg;")){
			fileName="image.jpg";
			downloadBuf(url);
		}else if(fileName.startsWith("data:image/png;")){
			fileName="image.png";
			downloadBuf(url);
		}else if(fileName.startsWith("data:image/gif;")){
			fileName="image.gif";
			downloadBuf(url);
		}else{
			let data=await (await fetch(url)).arrayBuffer();
			fileName=pathLib.basename(fileName);
			downloadFile(data);
		}
		/*}#1I5N43S3D0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.saveAudio=async function(){
		/*#{1I5N442AM0Start*/
		/*}#1I5N442AM0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.OnAssetClick=async function(sender,event){
		/*#{1I5N78RU80Start*/
		/*}#1I5N78RU80Start*/
		{
			let $items,$item;
			$items=[
				{id:"Use",text:(($ln==="CN")?("在对话中使用"):("Use in prompt"))},
				{id:"Download",text:(($ln==="CN")?("下载项目"):("Download asset"))},
				{id:"Save",text:(($ln==="CN")?("保存文件到 Tab-OS 中"):("Save asset in Tab-OS"))}
			];
			$item=await VFACT.app.modalDlg("/@StdUI/ui/DlgMenu.js",{hud:sender,items:$items});
			if($item){
				if($item.id==="Use"){
					//UseAsset
					/*#{1I5N7BGHH0*/
					if(session.aaUseAsset){
						session.aaUseAsset(label);
					}
					/*}#1I5N7BGHH0*/
				}else if($item.id==="Download"){
					//Download
					/*#{1I5N7G4J30*/
					await self.downloadAsset();
					/*}#1I5N7G4J30*/
				}else if($item.id==="Save"){
					//SaveAsset
					/*#{1I5N7C37K0*/
					await self.saveAsset();
					/*}#1I5N7C37K0*/
				}
			}
		}
	};
	/*#{1I5N374211PostCSSVO*/
	/*}#1I5N374211PostCSSVO*/
	return cssVO;
};
/*#{1I5N374211ExCodes*/
/*}#1I5N374211ExCodes*/


/*#{1I5N374210EndDoc*/
/*}#1I5N374210EndDoc*/

export default BoxAAChatAsset;
export{BoxAAChatAsset};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1I5N374210",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1I5N374212",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1I5N374213",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1I5N374214",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1I5N374215",
//			"attrs": {
//				"session": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"label": {
//					"type": "string",
//					"valText": "hub://image.svg"
//				},
//				"url": {
//					"type": "string",
//					"valText": "#appCfg.sharedAssets+\"/home.svg\""
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1I5N374216",
//			"attrs": {
//				"image": {
//					"type": "bool",
//					"valText": "true"
//				},
//				"audio": {
//					"type": "bool",
//					"valText": "false"
//				}
//			}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1I5N374217",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I5N43H450",
//					"attrs": {
//						"id": "saveAsset",
//						"label": "New AI Seg",
//						"x": "75",
//						"y": "60",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I5N44AEP0",
//							"attrs": {}
//						},
//						"async": "true",
//						"localVars": {
//							"jaxId": "1I5N44AEP1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I5N44AEP2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						}
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I5N43S3D0",
//					"attrs": {
//						"id": "downloadAsset",
//						"label": "New AI Seg",
//						"x": "75",
//						"y": "135",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I5N44AEP3",
//							"attrs": {}
//						},
//						"async": "true",
//						"localVars": {
//							"jaxId": "1I5N44AEP4",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I5N44AEP5",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						}
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I5N442AM0",
//					"attrs": {
//						"id": "saveAudio",
//						"label": "New AI Seg",
//						"x": "75",
//						"y": "210",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I5N44AEP6",
//							"attrs": {}
//						},
//						"async": "true",
//						"localVars": {
//							"jaxId": "1I5N44AEP7",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I5N44AEP8",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						}
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I5N78RU80",
//					"attrs": {
//						"id": "OnAssetClick",
//						"label": "New AI Seg",
//						"x": "75",
//						"y": "290",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I5N79EPB0",
//							"attrs": {
//								"sender": "null",
//								"event": ""
//							}
//						},
//						"async": "true",
//						"localVars": {
//							"jaxId": "1I5N79EPB1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": [
//								{
//									"type": "flowseg",
//									"def": "Menu",
//									"jaxId": "1I5N7CD7F0",
//									"attrs": {
//										"id": "Menu",
//										"label": "New AI Seg",
//										"x": "310",
//										"y": "290",
//										"desc": "",
//										"codes": "false",
//										"launcher": "sender",
//										"outlets": {
//											"attrs": [
//												{
//													"type": "aioutlet",
//													"def": "MenuItem",
//													"jaxId": "1I5N79MQL0",
//													"attrs": {
//														"id": "Use",
//														"text": {
//															"type": "string",
//															"valText": "Use in prompt",
//															"localize": {
//																"EN": "Use in prompt",
//																"CN": "在对话中使用"
//															},
//															"localizable": true
//														},
//														"desc": ""
//													},
//													"linkedSeg": "1I5N7BGHH0"
//												},
//												{
//													"type": "aioutlet",
//													"def": "MenuItem",
//													"jaxId": "1I5N7FQ3L0",
//													"attrs": {
//														"id": "Download",
//														"text": {
//															"type": "string",
//															"valText": "Download asset",
//															"localize": {
//																"EN": "Download asset",
//																"CN": "下载项目"
//															},
//															"localizable": true
//														},
//														"desc": ""
//													},
//													"linkedSeg": "1I5N7G4J30"
//												},
//												{
//													"type": "aioutlet",
//													"def": "MenuItem",
//													"jaxId": "1I5N79MQL1",
//													"attrs": {
//														"id": "Save",
//														"text": {
//															"type": "string",
//															"valText": "Save asset in Tab-OS",
//															"localize": {
//																"EN": "Save asset in Tab-OS",
//																"CN": "保存文件到 Tab-OS 中"
//															},
//															"localizable": true
//														},
//														"desc": ""
//													},
//													"linkedSeg": "1I5N7C37K0"
//												}
//											]
//										},
//										"outlet": {
//											"jaxId": "1I5N7CD7F1",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											}
//										}
//									}
//								},
//								{
//									"type": "flowseg",
//									"def": "Code",
//									"jaxId": "1I5N7BGHH0",
//									"attrs": {
//										"id": "UseAsset",
//										"label": "New AI Seg",
//										"x": "525",
//										"y": "215",
//										"desc": "",
//										"codes": "false",
//										"outlet": {
//											"jaxId": "1I5N7CD7F2",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											}
//										}
//									}
//								},
//								{
//									"type": "flowseg",
//									"def": "Code",
//									"jaxId": "1I5N7C37K0",
//									"attrs": {
//										"id": "SaveAsset",
//										"label": "New AI Seg",
//										"x": "525",
//										"y": "335",
//										"desc": "",
//										"codes": "false",
//										"outlet": {
//											"jaxId": "1I5N7CD7F3",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											}
//										}
//									}
//								},
//								{
//									"type": "flowseg",
//									"def": "Code",
//									"jaxId": "1I5N7G4J30",
//									"attrs": {
//										"id": "Download",
//										"label": "New AI Seg",
//										"x": "525",
//										"y": "275",
//										"desc": "",
//										"codes": "false",
//										"outlet": {
//											"jaxId": "1I5N7H4MU0",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											}
//										}
//									}
//								}
//							]
//						},
//						"outlet": {
//							"jaxId": "1I5N79EPB2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I5N7CD7F0"
//						}
//					}
//				}
//			]
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1I5N374218",
//			"attrs": {}
//		},
//		"mockupStates": {
//			"jaxId": "1I5N374219",
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1I5N374211",
//			"attrs": {
//				"properties": {
//					"jaxId": "1I5N3742110",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Relative",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "",
//						"minW": "",
//						"minH": "20",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Flex Y"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1I5N38D3Q0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I5N3C2SM0",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxHeader",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "24",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,5,0]",
//										"padding": "[0,5,0,5]",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex X",
//										"itemsAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1I5N39Q9R0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I5N3C2SM1",
//													"attrs": {
//														"type": "box",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "20",
//														"h": "20",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[0,5,0,0]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "#cfgColor[\"fontBodySub\"]",
//														"border": "1",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]",
//														"maskImage": "#appCfg.sharedAssets+\"/link.svg\""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I5N3C2SM2",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1I5N3C2SM3",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I5N3C2SM4",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1I5N3BIJM0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I5N3C2SM5",
//													"attrs": {
//														"type": "text",
//														"id": "TxtLabel",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "pointer",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "[0,0,0]",
//														"text": "#label",
//														"font": "",
//														"fontSize": "#txtSize.smallPlus",
//														"bold": "true",
//														"italic": "false",
//														"underline": "true",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I5N3C2SM6",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1I5N3C2SM7",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1I5N79EPB3",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1I5N79EPB4",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": "1I5N78RU80"
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1I5N3C2SM8",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1I5N3C2SM9",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1I5N3C2SM10",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1I5N3C2SM11",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "image",
//							"jaxId": "1I5N3K1AA0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I5N3LPN70",
//									"attrs": {
//										"type": "image",
//										"id": "ImgPic",
//										"position": "relative",
//										"x": "20",
//										"y": "0",
//										"w": "100",
//										"h": "100",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"image": "",
//										"autoSize": "false",
//										"fitSize": "Fit",
//										"repeat": "true",
//										"alignX": "Left",
//										"alignY": "Top",
//										"attach": "#image"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1I5N3LPN71",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1I5N3LPN72",
//									"attrs": {
//										"OnLoad": {
//											"type": "fixedFunc",
//											"jaxId": "1I5N3NADA0",
//											"attrs": {
//												"callArgs": {
//													"jaxId": "1I5N3NGMG0",
//													"attrs": {}
//												},
//												"seg": ""
//											}
//										}
//									}
//								},
//								"extraPpts": {
//									"jaxId": "1I5N3LPN73",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1I5N3742111",
//					"attrs": {}
//				},
//				"functions": {
//					"jaxId": "1I5N3742112",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1I5N3742113",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1I5N3742114",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}