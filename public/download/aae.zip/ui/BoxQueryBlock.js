//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnCheck} from "/@StdUI/ui/BtnCheck.js";
import {BtnNodeLine} from "./BtnNodeLine.js";
/*#{1HMHJ4NAT0StartDoc*/
import {BoxQueryLine} from "./BoxQueryLine.js";
import {AAE} from "../aae.js";
/*}#1HMHJ4NAT0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BoxQueryBlock=function(page,node){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let btnUse,btnNodeLine,boxItems,btnUseTag,boxAttrs,txtQuery,btnQueryIdx,edQueryIdx,txtQueryNum;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1HMHJ4NAT1LocalVals*/
	const app=VFACT.app;
	const mainUI=app.aafMainUI;
	/*}#1HMHJ4NAT1LocalVals*/
	
	/*#{1HMHJ4NAT1PreState*/
	function attrLine(key,value){
	}
	/*}#1HMHJ4NAT1PreState*/
	state={
		"queryString":"","tagName":node.tagName,
		/*#{1HMHJ4NAU5ExState*/
		/*}#1HMHJ4NAU5ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1HMHJ4NAT1PostState*/
	/*}#1HMHJ4NAT1PostState*/
	cssVO={
		"hash":"1HMHJ4NAT1",nameHost:true,
		"type":"box","position":"relative","x":0,"y":0,"w":"100%","h":"","margin":[0,0,10,0],"padding":10,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
		"background":[255,255,255,1],"border":2,"corner":8,"contentLayout":"flex-y",
		children:[
			{
				"hash":"1HMHJDU1S0",
				"type":BtnCheck(20,"Use in query",false,false),"id":"BtnUse","position":"relative","x":0,"y":0,"margin":[0,0,5,0],
				/*#{1HMHJDU1S0Codes*/
				OnCheck(check){
					self.showFace(check?"use":"!use");
				}
				/*}#1HMHJDU1S0Codes*/
			},
			{
				"hash":"1HMHJJBH60",
				"type":BtnNodeLine(page,node,false),"id":"BtnNodeLine","position":"relative","x":0,"y":0,
			},
			{
				"hash":"1HMHJE6TE0",
				"type":"box","id":"Line","position":"relative","x":0,"y":0,"w":"100%","h":1,"margin":[0,0,5,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"background":cfgColor["fontBodyLit"],
			},
			{
				"hash":"1HMHJG6QB0",
				"type":"hud","id":"BoxItems","position":"relative","x":10,"y":0,"w":">calc(100% - 10px)","h":"","margin":[5,0,10,0],"minW":"","minH":"","maxW":"",
				"maxH":"","styleClass":"","contentLayout":"flex-y",
				children:[
					{
						"hash":"1HMHJHFN80",
						"type":BtnCheck(20,`HTML Tag: ${state.tagName}`,true,false),"id":"BtnUseTag","position":"relative","x":0,"y":0,"fontSize":12,"margin":[0,0,5,0],
					},
					{
						"hash":"1HN91U22A0",
						"type":"hud","id":"BoxAttrs","position":"relative","x":0,"y":0,"w":"100%","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
					}
				],
			},
			{
				"hash":"1HMHJRR4A0",
				"type":"box","id":"Line","position":"relative","x":0,"y":0,"w":"100%","h":1,"margin":[0,0,5,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"background":cfgColor["fontBodyLit"],
			},
			{
				"hash":"1HMHJRIJ50",
				"type":"text","id":"TxtQuery","position":"relative","x":0,"y":0,"w":"100%","h":"","margin":[0,0,5,0],"padding":0,"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","color":[0,0,0],"text":$P(()=>(`Query string: ${state.queryString}`),state),"fontSize":txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal",
				"textDecoration":"","wrap":true,
			},
			{
				"hash":"1HMHJURJE0",
				"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":20,"padding":[0,5,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
				"itemsAlign":1,
				children:[
					{
						"hash":"1HMHKFT520",
						"type":BtnCheck(16,"Pick index:",false,false),"id":"BtnQueryIdx","position":"relative","x":0,"y":0,"fontSize":txtSize.smallPlus,"margin":[0,3,0,0],
					},
					{
						"hash":"1HMHK132Q0",
						"type":"edit","id":"EdQueryIdx","position":"relative","x":0,"y":0,"w":30,"h":20,"minW":"","minH":"","maxW":30,"maxH":"","styleClass":"","text":"-",
						"color":[0,0,0],"outline":0,"border":[0,0,1,0],"selectOnFocus":false,"spellCheck":false,
					},
					{
						"hash":"1HN9JLR0E0",
						"type":"text","id":"TxtQueryNum","position":"relative","x":0,"y":0,"w":"","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":[0,0,0],
						"text":"/?","fontSize":txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,
					}
				],
			}
		],
		/*#{1HMHJ4NAT1ExtraCSS*/
		node:node,
		get $$inQuery(){return btnUse.checked;},
		set $$inQuery(v){btnUse.checked=v;},
		get $$useQueryIdx(){return btnQueryIdx.checked;},
		/*}#1HMHJ4NAT1ExtraCSS*/
		faces:{
			"use":{
				/*BtnUse*/"#1HMHJDU1S0":{
					"checked":true
				},
				/*Line*/"#1HMHJE6TE0":{
					"display":1
				},
				/*BoxItems*/"#1HMHJG6QB0":{
					"display":1
				},
				/*Line*/"#1HMHJRR4A0":{
					"display":1
				},
				/*TxtQuery*/"#1HMHJRIJ50":{
					"display":1
				},
				"#1HMHJURJE0":{
					"display":1
				}
			},"!use":{
				/*BtnUse*/"#1HMHJDU1S0":{
					"checked":false
				},
				/*Line*/"#1HMHJE6TE0":{
					"display":0
				},
				/*BoxItems*/"#1HMHJG6QB0":{
					"display":0
				},
				/*Line*/"#1HMHJRR4A0":{
					"display":0
				},
				/*TxtQuery*/"#1HMHJRIJ50":{
					"display":0
				},
				"#1HMHJURJE0":{
					"display":0
				}
			}
		},
		OnCreate:function(){
			self=this;
			btnUse=self.BtnUse;btnNodeLine=self.BtnNodeLine;boxItems=self.BoxItems;btnUseTag=self.BtnUseTag;boxAttrs=self.BoxAttrs;txtQuery=self.TxtQuery;btnQueryIdx=self.BtnQueryIdx;edQueryIdx=self.EdQueryIdx;txtQueryNum=self.TxtQueryNum;
			/*#{1HMHJ4NAT1Create*/
			self.showFace("!use");
			self.init();
			/*}#1HMHJ4NAT1Create*/
		},
		/*#{1HMHJ4NAT1EndCSS*/
		/*}#1HMHJ4NAT1EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.init=async function(){
		/*#{1HMHM2OLG0Start*/
		let attrs,key,value,css,line;
		attrs=await page.getNodeAttributes(node);
		for(key in attrs){
			if(key!=="aaeid"){
				value=attrs[key];
				css=BoxQueryLine({key,value},self);
				line=boxAttrs.appendNewChild(css);
			}
		}
		self.buildQuery();
		/*}#1HMHM2OLG0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.isInQuery=async function(){
		/*#{1HMK6V4O30Start*/
		return btnUse.checked;
		/*}#1HMK6V4O30Start*/
	};
	//------------------------------------------------------------------------
	cssVO.updateBlock=async function(){
		/*#{1HMK70OQ30Start*/
		/*}#1HMK70OQ30Start*/
	};
	//------------------------------------------------------------------------
	cssVO.buildQuery=async function(queryList){
		/*#{1HN91SGEL0Start*/
		let query,list,i,n,line,attr,cnt,attrQuery,idx=0;
		query=""
		if(btnUseTag.checked){
			query+=node.tagName;
		}else{
			query+="*";
		}
		list=boxAttrs.children;
		n=list.length;
		cnt=0;
		attrQuery="";
		for(i=0;i<n;i++){
			line=list[i];
			if(line.checked){
				attr=line.attr;
				if(cnt>0){
					attrQuery+=` and `;
				}
				switch(line.mode){
					case "equal":
						attrQuery+=`@${attr.key}="${line.value}"`;
						break;
					case "starts":
						attrQuery+=`starts-with(@${attr.key},"${line.value}")`;
						break;
					case "contains":
						attrQuery+=`contains(@${attr.key},"${line.value}")`;
						break;
				}
				cnt+=1;
			}
		}
		if(cnt>0){
			query+=`[${attrQuery}]`;
		}
		if(queryList){
			if(self.useQueryIdx){
				idx=parseInt(edQueryIdx.text);
			}
			queryList.push({query,idx});
		}
		state.queryString=query;
		/*}#1HN91SGEL0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.setQueryIndex=async function(idx,num){
		/*#{1HN9JJSHC0Start*/
		edQueryIdx.text=idx+1;
		txtQueryNum.text="/"+num;
		/*}#1HN9JJSHC0Start*/
	};
	/*#{1HMHJ4NAT1PostCSSVO*/
	/*}#1HMHJ4NAT1PostCSSVO*/
	return cssVO;
};
/*#{1HMHJ4NAT1ExCodes*/
/*}#1HMHJ4NAT1ExCodes*/


/*#{1HMHJ4NAT0EndDoc*/
/*}#1HMHJ4NAT0EndDoc*/

export default BoxQueryBlock;
export{BoxQueryBlock};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearBox",
//	"jaxId": "1HMHJ4NAT0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1HMHJ4NAU0",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1HMHJ4NAU1",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1HMHJ4NAU2",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1HMHJ4NAU3",
//			"attrs": {
//				"page": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"node": {
//					"type": "auto",
//					"valText": "#{tagName:\"INPUT\"}"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1HMHJ4NAU4",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1HMHJ4NAU5",
//			"attrs": {
//				"queryString": {
//					"type": "string",
//					"valText": ""
//				},
//				"tagName": {
//					"type": "string",
//					"valText": "#node.tagName"
//				}
//			}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HMHM2OLG0",
//					"attrs": {
//						"id": "init",
//						"label": "New AI Seg",
//						"x": "90",
//						"y": "90",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HMHM3BTF0",
//							"attrs": {}
//						},
//						"async": "true",
//						"localVars": {
//							"jaxId": "1HMHM3BTF1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1HMHM3BTF2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						}
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HMK6V4O30",
//					"attrs": {
//						"id": "isInQuery",
//						"label": "New AI Seg",
//						"x": "90",
//						"y": "170",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HMK6V4O60",
//							"attrs": {}
//						},
//						"async": "true",
//						"localVars": {
//							"jaxId": "1HMK6V4O61",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1HMK6V4O62",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						}
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HMK70OQ30",
//					"attrs": {
//						"id": "updateBlock",
//						"label": "New AI Seg",
//						"x": "90",
//						"y": "260",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HMK70OQ70",
//							"attrs": {}
//						},
//						"async": "true",
//						"localVars": {
//							"jaxId": "1HMK70OQ71",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1HMK70OQ72",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						}
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HN91SGEL0",
//					"attrs": {
//						"id": "buildQuery",
//						"label": "New AI Seg",
//						"x": "90",
//						"y": "350",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HN91SGER0",
//							"attrs": {
//								"queryList": {
//									"type": "string",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"localVars": {
//							"jaxId": "1HN91SGER1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1HN91SGER2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						}
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HN9JJSHC0",
//					"attrs": {
//						"id": "setQueryIndex",
//						"label": "New AI Seg",
//						"x": "90",
//						"y": "440",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HN9JJSHL0",
//							"attrs": {
//								"idx": {
//									"type": "int",
//									"valText": "0"
//								},
//								"num": {
//									"type": "int",
//									"valText": "0"
//								}
//							}
//						},
//						"async": "true",
//						"localVars": {
//							"jaxId": "1HN9JJSHL1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1HN9JJSHL2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						}
//					}
//				}
//			]
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1HMHJ4NAU6",
//			"attrs": {
//				"use": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HNBBA1NA0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HNBBD8F50",
//							"attrs": {}
//						}
//					}
//				},
//				"!use": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HNBB6BR60",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HNBBD8F51",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1HMHJ4NAU7",
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "box",
//			"jaxId": "1HMHJ4NAT1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1HMHJ4NAU8",
//					"attrs": {
//						"type": "box",
//						"id": "",
//						"position": "Relative",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "[0,0,10,0]",
//						"padding": "10",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"background": "[255,255,255,1.00]",
//						"border": "2",
//						"borderStyle": "Solid",
//						"borderColor": "[0,0,0,1.00]",
//						"corner": "8",
//						"shadow": "false",
//						"shadowX": "2",
//						"shadowY": "2",
//						"shadowBlur": "3",
//						"shadowSpread": "0",
//						"shadowColor": "[0,0,0,0.50]",
//						"contentLayout": "Flex Y"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "Gear/@StdUI/ui/BtnCheck.js",
//							"jaxId": "1HMHJDU1S0",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1HMHJDU1S1",
//									"attrs": {
//										"size": "20",
//										"text": "Use in query",
//										"checked": "false",
//										"radio": "false"
//									}
//								},
//								"properties": {
//									"jaxId": "1HMHJDU1S2",
//									"attrs": {
//										"type": "#null#>BtnCheck(20,\"Use in query\",false,false)",
//										"id": "BtnUse",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"display": "On",
//										"face": "",
//										"margin": "[0,0,5,0]"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HMHJDU1S3",
//									"attrs": {
//										"1HNBB6BR60": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HNBBD8F52",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HNBBD8F53",
//													"attrs": {
//														"checked": {
//															"type": "bool",
//															"valText": "false"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HNBB6BR60",
//											"faceTagName": "!use"
//										},
//										"1HNBBA1NA0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HNBBD8F54",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HNBBD8F55",
//													"attrs": {
//														"checked": {
//															"type": "bool",
//															"valText": "true"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HNBBA1NA0",
//											"faceTagName": "use"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HMHJDU1S4",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HMHJDU1S5",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "true",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true",
//								"containerSlots": {
//									"jaxId": "1HMHJDU1S6",
//									"attrs": {}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear1HL27BS8G0",
//							"jaxId": "1HMHJJBH60",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1HMHJJBH61",
//									"attrs": {
//										"client": "#page",
//										"node": "#node",
//										"inTree": "false"
//									}
//								},
//								"properties": {
//									"jaxId": "1HMHJJBH62",
//									"attrs": {
//										"type": "#null#>BtnNodeLine(page,node,false)",
//										"id": "BtnNodeLine",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"display": "On",
//										"face": ""
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HMHJJBH63",
//									"attrs": {
//										"1HNBB6BR60": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HNBBD8F56",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HNBBD8F57",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HNBB6BR60",
//											"faceTagName": "!use"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HMHJJBH64",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HMHJJBH65",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true",
//								"containerSlots": {
//									"jaxId": "1HMHJJBH66",
//									"attrs": {}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1HMHJE6TE0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HMHJE6TE1",
//									"attrs": {
//										"type": "box",
//										"id": "Line",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "1",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,5,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"fontBodyLit\"]",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HMHJE6TE2",
//									"attrs": {
//										"1HNBB6BR60": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HNBBD8F58",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HNBBD8F59",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HNBB6BR60",
//											"faceTagName": "!use"
//										},
//										"1HNBBA1NA0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HNBBD8F510",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HNBBD8F511",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HNBBA1NA0",
//											"faceTagName": "use"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HMHJE6TE3",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HMHJE6TE4",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1HMHJG6QB0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HMHJM0TC0",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxItems",
//										"position": "relative",
//										"x": "10",
//										"y": "0",
//										"w": "100%-10",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[5,0,10,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex Y"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnCheck.js",
//											"jaxId": "1HMHJHFN80",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1HMHJHFN81",
//													"attrs": {
//														"size": "20",
//														"text": "#`HTML Tag: ${state.tagName}`",
//														"checked": "true",
//														"radio": "false"
//													}
//												},
//												"properties": {
//													"jaxId": "1HMHJHFN82",
//													"attrs": {
//														"type": "#null#>BtnCheck(20,`HTML Tag: ${state.tagName}`,true,false)",
//														"id": "BtnUseTag",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"fontSize": "12",
//														"margin": "[0,0,5,0]"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HMHJHFN83",
//													"attrs": {
//														"1HNBB6BR60": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HNBBD8F512",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HNBBD8F513",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HNBB6BR60",
//															"faceTagName": "!use"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HMHJHFN84",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HMHJHFN85",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1HMHJHFN86",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1HN91U22A0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HN91UMM20",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxAttrs",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex Y"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HN91UMM21",
//													"attrs": {
//														"1HNBB6BR60": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HNBBD8F514",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HNBBD8F515",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HNBB6BR60",
//															"faceTagName": "!use"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HN91UMM22",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HN91UMM23",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "true",
//												"exposeContainer": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1HMHJM0TC1",
//									"attrs": {
//										"1HNBB6BR60": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HNBBD8F516",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HNBBD8F517",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HNBB6BR60",
//											"faceTagName": "!use"
//										},
//										"1HNBBA1NA0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HNBBD8F518",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HNBBD8F519",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HNBBA1NA0",
//											"faceTagName": "use"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HMHJM0TC2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HMHJM0TC3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1HMHJRR4A0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HMHJRR4A1",
//									"attrs": {
//										"type": "box",
//										"id": "Line",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "1",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,5,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"fontBodyLit\"]",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HMHJRR4A2",
//									"attrs": {
//										"1HNBB6BR60": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HNBBD8F520",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HNBBD8F521",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HNBB6BR60",
//											"faceTagName": "!use"
//										},
//										"1HNBBA1NA0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HNBBD8F522",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HNBBD8F523",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HNBBA1NA0",
//											"faceTagName": "use"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HMHJRR4A3",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HMHJRR4A4",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1HMHJRIJ50",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HMHJSIKB0",
//									"attrs": {
//										"type": "text",
//										"id": "TxtQuery",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,5,0]",
//										"padding": "0",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "[0,0,0]",
//										"text": "${`Query string: ${state.queryString}`},state",
//										"font": "",
//										"fontSize": "#txtSize.smallPlus",
//										"bold": "false",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Top",
//										"wrap": "true",
//										"ellipsis": "false",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HMHJSIKB1",
//									"attrs": {
//										"1HNBB6BR60": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HNBBD8F524",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HNBBD8F525",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HNBB6BR60",
//											"faceTagName": "!use"
//										},
//										"1HNBBA1NA0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HNBBD8F526",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HNBBD8F527",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HNBBA1NA0",
//											"faceTagName": "use"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HMHJSIKB2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HMHJSIKB3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1HMHJURJE0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HMHKAPD90",
//									"attrs": {
//										"type": "hud",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "20",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "[0,5,0,0]",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex X",
//										"itemsAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnCheck.js",
//											"jaxId": "1HMHKFT520",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1HMHKI9VJ0",
//													"attrs": {
//														"size": "16",
//														"text": "Pick index:",
//														"checked": "false",
//														"radio": "false"
//													}
//												},
//												"properties": {
//													"jaxId": "1HMHKI9VJ1",
//													"attrs": {
//														"type": "#null#>BtnCheck(16,\"Pick index:\",false,false)",
//														"id": "BtnQueryIdx",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"fontSize": "#txtSize.smallPlus",
//														"margin": "[0,3,0,0]"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HMHKI9VJ2",
//													"attrs": {
//														"1HNBB6BR60": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HNBBD8F60",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HNBBD8F61",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HNBB6BR60",
//															"faceTagName": "!use"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HMHKI9VJ3",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HMHKI9VJ4",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1HMHKI9VJ5",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "edit",
//											"jaxId": "1HMHK132Q0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HMHKAPD95",
//													"attrs": {
//														"type": "edit",
//														"id": "EdQueryIdx",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "30",
//														"h": "20",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "30",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"inputType": "Text",
//														"text": "-",
//														"placeHolder": "",
//														"color": "[0,0,0]",
//														"bgColor": "[255,255,255,1.00]",
//														"font": "",
//														"fontSize": "16",
//														"outline": "0",
//														"border": "[0,0,1,0]",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"selectOnFocus": "false",
//														"spellCheck": "false",
//														"traceSize": "false",
//														"flex": "false"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HMHKAPD96",
//													"attrs": {
//														"1HNBB6BR60": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HNBBD8F62",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HNBBD8F63",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HNBB6BR60",
//															"faceTagName": "!use"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HMHKAPD97",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HMHKAPD98",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1HN9JLR0E0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HN9JO5L50",
//													"attrs": {
//														"type": "text",
//														"id": "TxtQueryNum",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "[0,0,0]",
//														"text": "/?",
//														"font": "",
//														"fontSize": "#txtSize.smallPlus",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Center",
//														"wrap": "false",
//														"ellipsis": "false",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HN9JO5L51",
//													"attrs": {
//														"1HNBB6BR60": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HNBBD8F64",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HNBBD8F65",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HNBB6BR60",
//															"faceTagName": "!use"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HN9JO5L52",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HN9JO5L53",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1HMHKAPD99",
//									"attrs": {
//										"1HNBB6BR60": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HNBBD8F66",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HNBBD8F67",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HNBB6BR60",
//											"faceTagName": "!use"
//										},
//										"1HNBBA1NA0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HNBBD8F68",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HNBBD8F69",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HNBBA1NA0",
//											"faceTagName": "use"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HMHKAPD910",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HMHKAPD911",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1HMHJ4NAU9",
//					"attrs": {
//						"1HNBB6BR60": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HNBBD8F610",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HNBBD8F611",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HNBB6BR60",
//							"faceTagName": "!use"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1HMHJ4NAU10",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1HMHJ4NAU11",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1HMHJ4NAU12",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"background": "false",
//				"color": "false",
//				"gradient": "false",
//				"border": "false",
//				"borders": "false",
//				"borderStyle": "false",
//				"borderColor": "false",
//				"borderColors": "false",
//				"corner": "false",
//				"coner": "false",
//				"coners": "false",
//				"shadow": "false",
//				"shadowX": "false",
//				"shadowY": "false",
//				"shadowBlur": "false",
//				"shadowSpread": "false",
//				"shadowColor": "false",
//				"maskImage": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}