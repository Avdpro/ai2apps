//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
/*#{1HL2BLTCM0StartDoc*/
/*}#1HL2BLTCM0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BoxAttrLine=function(key,value,icon,action){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1HL2BLTCM1LocalVals*/
	/*}#1HL2BLTCM1LocalVals*/
	
	/*#{1HL2BLTCM1PreState*/
	/*}#1HL2BLTCM1PreState*/
	/*#{1HL2BLTCM1PostState*/
	/*}#1HL2BLTCM1PostState*/
	cssVO={
		"hash":"1HL2BLTCM1",nameHost:true,
		"type":"hud","x":0,"y":0,"w":"100%","h":20,"padding":[0,5,0,5],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x","itemsAlign":1,
		children:[
			{
				"hash":"1HL3C2V110",
				"type":"box","id":"BoxIcon","position":"relative","x":0,"y":0,"w":18,"h":18,"styleClass":"","background":cfgColor["fontBodySub"],"attached":!!icon,
				"maskImage":icon,
			},
			{
				"hash":"1HL2BN7FD0",
				"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","margin":[0,5,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":[0,0,0],
				"text":key+"=","fontSize":txtSize.smallPlus,"fontWeight":"bold","fontStyle":"normal","textDecoration":"","selectable":true,
			},
			{
				"hash":"1HL2BPEVF0",
				"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":[0,0,0],"text":`"${value}"`,
				"fontSize":txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","selectable":true,"flex":true,
			},
			{
				"hash":"1HL3C5J3C0",
				"type":BtnIcon("front",20,0,appCfg.sharedAssets+"/fat_right.svg",null),"id":"BtnAction","x":">calc(100% - 25px)","y":0,"attached":!!action,
				"OnClick":function(event){
					/*#{1HL3C973G0FunctionBody*/
					action(key,value);
					/*}#1HL3C973G0FunctionBody*/
				},
			}
		],
		/*#{1HL2BLTCM1ExtraCSS*/
		/*}#1HL2BLTCM1ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			self=this;
			
			/*#{1HL2BLTCM1Create*/
			/*}#1HL2BLTCM1Create*/
		},
		/*#{1HL2BLTCM1EndCSS*/
		/*}#1HL2BLTCM1EndCSS*/
	};
	/*#{1HL2BLTCM1PostCSSVO*/
	/*}#1HL2BLTCM1PostCSSVO*/
	return cssVO;
};
/*#{1HL2BLTCM1ExCodes*/
/*}#1HL2BLTCM1ExCodes*/

BoxAttrLine.gearExport={
	framework: "jax",
	hudType: "hud",
	"showName":"",icon:"gears.svg",previewImg:false,
	fixPose:false,initW:100,initH:100,
	catalog:"",
	args: {
		"key": {
			"name": "key", "showName": "key", "type": "string", "key": true, "fixed": true, "initVal": "id"
		}, 
		"value": {
			"name": "value", "showName": "value", "type": "string", "key": true, "fixed": true, "initVal": "Chat-Messages"
		}, 
		"icon": {
			"name": "icon", "showName": "icon", "type": "string", "key": true, "fixed": true, "initVal": ""
		}, 
		"action": {
			"name": "action", "showName": "action", "type": "auto", "key": true, "fixed": true, 
			"initVal": null
		}
	},
	state:{
	},
	properties:["id","position","x","y","display"],
	faces:[],
	subContainers:{
	},
	/*#{1HL2BLTCM0ExGearInfo*/
	/*}#1HL2BLTCM0ExGearInfo*/
};
export default BoxAttrLine;
export{BoxAttrLine};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1HL2BLTCM0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1HL2BLTCM2",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1HL2BLTCM3",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1HL2BLTCM4",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1HL2BLTCM5",
//			"attrs": {
//				"key": {
//					"type": "string",
//					"valText": "id"
//				},
//				"value": {
//					"type": "string",
//					"valText": "Chat-Messages"
//				},
//				"icon": {
//					"type": "string",
//					"valText": ""
//				},
//				"action": {
//					"type": "auto",
//					"valText": "null"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1HL2BLTCM6",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1HL2BLTCM7",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1HL2BLTCM8",
//			"attrs": {}
//		},
//		"mockupStates": {
//			"jaxId": "1HL2BLTCM9",
//			"attrs": {
//				"Icon&Action": {
//					"type": "mockState",
//					"def": "MockState",
//					"jaxId": "1HL3CDB4D0",
//					"attrs": {
//						"createArgs": {
//							"jaxId": "1HL2BLTCM5",
//							"attrs": {
//								"key": {
//									"type": "string",
//									"valText": "id"
//								},
//								"value": {
//									"type": "string",
//									"valText": "Chat-Messages"
//								},
//								"icon": {
//									"type": "string",
//									"valText": "#appCfg.sharedAssets+\"/object.svg\""
//								},
//								"action": {
//									"type": "auto",
//									"valText": "\"go\""
//								}
//							}
//						},
//						"stateObj": {
//							"jaxId": "1HL2BLTCM7",
//							"attrs": {}
//						}
//					}
//				},
//				"min": {
//					"type": "mockState",
//					"def": "MockState",
//					"jaxId": "1HL3CDB4D1",
//					"attrs": {
//						"createArgs": {
//							"jaxId": "1HL2BLTCM5",
//							"attrs": {
//								"key": {
//									"type": "string",
//									"valText": "id"
//								},
//								"value": {
//									"type": "string",
//									"valText": "Chat-Messages"
//								},
//								"icon": {
//									"type": "string",
//									"valText": ""
//								},
//								"action": {
//									"type": "auto",
//									"valText": "null"
//								}
//							}
//						},
//						"stateObj": {
//							"jaxId": "1HL2BLTCM7",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1HL2BLTCM1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1HL2BLTCM10",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "20",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "[0,5,0,5]",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Flex X",
//						"itemsAlign": "Center"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1HL3C2V110",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HL3C82TC0",
//									"attrs": {
//										"type": "box",
//										"id": "BoxIcon",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "18",
//										"h": "18",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"fontBodySub\"]",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"attach": "#!!icon",
//										"maskImage": "#icon"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HL3C82TC1",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1HL3C82TC2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HL3C82TC3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1HL2BN7FD0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HL2BS6KR0",
//									"attrs": {
//										"type": "text",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,5,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "[0,0,0]",
//										"text": "#key+\"=\"",
//										"font": "",
//										"fontSize": "#txtSize.smallPlus",
//										"bold": "true",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Top",
//										"wrap": "false",
//										"ellipsis": "false",
//										"select": "true",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HL2BS6KR1",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1HL2BS6KR2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HL2BS6KR3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1HL2BPEVF0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HL2BS6KR4",
//									"attrs": {
//										"type": "text",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "[0,0,0]",
//										"text": "#`\"${value}\"`",
//										"font": "",
//										"fontSize": "#txtSize.smallPlus",
//										"bold": "false",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Top",
//										"wrap": "false",
//										"ellipsis": "false",
//										"select": "true",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0",
//										"flex": "true"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HL2BS6KR5",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1HL2BS6KR6",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HL2BS6KR7",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear/@StdUI/ui/BtnIcon.js",
//							"jaxId": "1HL3C5J3C0",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1HL3C82TD0",
//									"attrs": {
//										"style": "\"front\"",
//										"w": "20",
//										"h": "0",
//										"icon": "#appCfg.sharedAssets+\"/fat_right.svg\"",
//										"colorBG": "null"
//									}
//								},
//								"properties": {
//									"jaxId": "1HL3C82TD1",
//									"attrs": {
//										"type": "#null#>BtnIcon(\"front\",20,0,appCfg.sharedAssets+\"/fat_right.svg\",null)",
//										"id": "BtnAction",
//										"position": "Absolute",
//										"x": "100%-25",
//										"y": "0",
//										"display": "On",
//										"face": "",
//										"attach": "#!!action"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HL3C82TD2",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1HL3C82TD3",
//									"attrs": {
//										"OnClick": {
//											"type": "fixedFunc",
//											"jaxId": "1HL3C973G0",
//											"attrs": {
//												"callArgs": {
//													"jaxId": "1HL3CA1KT0",
//													"attrs": {
//														"event": ""
//													}
//												},
//												"seg": ""
//											}
//										}
//									}
//								},
//								"extraPpts": {
//									"jaxId": "1HL3C82TD4",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false",
//								"containerSlots": {
//									"jaxId": "1HL3C82TD5",
//									"attrs": {}
//								}
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1HL2BLTCM11",
//					"attrs": {}
//				},
//				"functions": {
//					"jaxId": "1HL2BLTCM12",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1HL2BLTCM13",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1HL2BLTCM14",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}