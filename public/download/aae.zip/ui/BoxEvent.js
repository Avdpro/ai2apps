//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnEvent} from "./BtnEvent.js";
import {BoxDomNode} from "./BoxDomNode.js";
/*#{1HL3PMAUS0StartDoc*/
/*}#1HL3PMAUS0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BoxEvent=function(client,event,uiView){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1HL3PMAUS1LocalVals*/
	let isOpen=false;
	let dataEvent=event;
	/*}#1HL3PMAUS1LocalVals*/
	
	/*#{1HL3PMAUS1PreState*/
	/*}#1HL3PMAUS1PreState*/
	/*#{1HL3PMAUS1PostState*/
	/*}#1HL3PMAUS1PostState*/
	cssVO={
		"hash":"1HL3PMAUS1",nameHost:true,
		"type":"box","x":0,"y":0,"w":"100%","h":"","overflow":1,"margin":[0,0,5,0],"padding":5,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":[255,255,255,1],
		"border":1,"corner":6,"contentLayout":"flex-y",
		children:[
			{
				"hash":"1HL3QHGH50",
				"type":BtnEvent(client,event),"id":"BtnEvent","position":"relative","x":0,"y":0,
				"OnClick":function(event){
					self.OnBtnClick(this,event);
				},
			},
			{
				"hash":"1HL3QT7DA0",
				"type":BoxDomNode(client,event.target,uiView,false),"id":"BoxTarget","position":"relative","x":0,"y":0,"display":0,
				"attached":!!event.target,
				/*#{1HL3QT7DA0Codes*/
				focusNode(){
					this.parent.focusNode();
				}
				/*}#1HL3QT7DA0Codes*/
			}
		],
		/*#{1HL3PMAUS1ExtraCSS*/
		/*}#1HL3PMAUS1ExtraCSS*/
		faces:{
			"focus":{
				"#self":{
					"border":3
				},
				/*BtnEvent*/"#1HL3QHGH50":{
					"face":"focus"
				},
				/*#{1HL3R635T0Code*/
				$(){
					isOpen=true;
				}
				/*}#1HL3R635T0Code*/
			},"blur":{
				"#self":{
					"border":1
				},
				/*BtnEvent*/"#1HL3QHGH50":{
					"face":"blur"
				},
				/*BoxTarget*/"#1HL3QT7DA0":{
					"display":0
				},
				/*#{1HL3R6H6R0Code*/
				$(){
					isOpen=false;
				}
				/*}#1HL3R6H6R0Code*/
			}
		},
		OnCreate:function(){
			self=this;
			
			/*#{1HL3PMAUS1Create*/
			event.hud=self;
			/*}#1HL3PMAUS1Create*/
		},
		/*#{1HL3PMAUS1EndCSS*/
		/*}#1HL3PMAUS1EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.OnBtnClick=async function(sender,event){
		/*#{1HLBOFQAB0Start*/
		/*}#1HLBOFQAB0Start*/
	};
	/*#{1HL3PMAUS1PostCSSVO*/
	/*}#1HL3PMAUS1PostCSSVO*/
	return cssVO;
};
/*#{1HL3PMAUS1ExCodes*/
/*}#1HL3PMAUS1ExCodes*/


/*#{1HL3PMAUS0EndDoc*/
/*}#1HL3PMAUS0EndDoc*/

export default BoxEvent;
export{BoxEvent};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearBox",
//	"jaxId": "1HL3PMAUS0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1HL3PMAUS2",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1HL3PMAUS3",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1HL3PMAUS4",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1HL3PMAUS5",
//			"attrs": {
//				"client": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"event": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"uiView": {
//					"type": "auto",
//					"valText": "null"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1HL3PMAUS6",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1HL3PMAUT0",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HLBOFQAB0",
//					"attrs": {
//						"id": "OnBtnClick",
//						"label": "New AI Seg",
//						"x": "90",
//						"y": "100",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HLBOGGLG0",
//							"attrs": {
//								"sender": {
//									"valText": "null"
//								},
//								"event": {
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"localVars": {
//							"jaxId": "1HLBOGGLG1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1HLBOGGLG2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						}
//					}
//				}
//			]
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1HL3PMAUT1",
//			"attrs": {
//				"focus": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HL3R635T0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HL3R87GB0",
//							"attrs": {}
//						}
//					}
//				},
//				"blur": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HL3R6H6R0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HL3R87GB1",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1HL3PMAUT2",
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "box",
//			"jaxId": "1HL3PMAUS1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1HL3PMAUT3",
//					"attrs": {
//						"type": "box",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "On",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "[0,0,5,0]",
//						"padding": "5",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"background": "[255,255,255,1.00]",
//						"border": "1",
//						"borderStyle": "Solid",
//						"borderColor": "[0,0,0,1.00]",
//						"corner": "6",
//						"shadow": "false",
//						"shadowX": "2",
//						"shadowY": "2",
//						"shadowBlur": "3",
//						"shadowSpread": "0",
//						"shadowColor": "[0,0,0,0.50]",
//						"contentLayout": "Flex Y",
//						"attach": "true"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "Gear1HL3PO1FK0",
//							"jaxId": "1HL3QHGH50",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1HL3QKDSQ0",
//									"attrs": {
//										"client": "#client",
//										"event": "#event"
//									}
//								},
//								"properties": {
//									"jaxId": "1HL3QKDSQ1",
//									"attrs": {
//										"type": "#null#>BtnEvent(client,event)",
//										"id": "BtnEvent",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"display": "On",
//										"face": ""
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HL3QKDSQ2",
//									"attrs": {
//										"1HL3R635T0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HU6CM3PJ0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HU6CM3PJ1",
//													"attrs": {
//														"face": "\"focus\""
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HL3R635T0",
//											"faceTagName": "focus"
//										},
//										"1HL3R6H6R0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HU6CM3PJ2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HU6CM3PJ3",
//													"attrs": {
//														"face": "\"blur\""
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HL3R6H6R0",
//											"faceTagName": "blur"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HL3QKDSQ3",
//									"attrs": {
//										"OnClick": {
//											"type": "fixedFunc",
//											"jaxId": "1HLBOGGLG3",
//											"attrs": {
//												"callArgs": {
//													"jaxId": "1HLBOGGLG4",
//													"attrs": {
//														"event": ""
//													}
//												},
//												"seg": "1HLBOFQAB0"
//											}
//										}
//									}
//								},
//								"extraPpts": {
//									"jaxId": "1HL3QKDSQ4",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false",
//								"containerSlots": {
//									"jaxId": "1HL3QKDSR0",
//									"attrs": {}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear1HL274FKA0",
//							"jaxId": "1HL3QT7DA0",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1HL3QUBIF0",
//									"attrs": {
//										"client": "#client",
//										"node": "#event.target",
//										"uiView": "#uiView",
//										"inTree": "false"
//									}
//								},
//								"properties": {
//									"jaxId": "1HL3QUBIF1",
//									"attrs": {
//										"type": "#null#>BoxDomNode(client,event.target,uiView,false)",
//										"id": "BoxTarget",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"display": "Off",
//										"face": ""
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HL3QUBIF2",
//									"attrs": {
//										"1HL3R6H6R0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HL3R87GC0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HL3R87GC1",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HL3R6H6R0",
//											"faceTagName": "blur"
//										},
//										"1HL3R635T0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HU6CM3PJ4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HU6CM3PJ5",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HL3R635T0",
//											"faceTagName": "focus"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HL3QUBIF3",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HL3QUBIF4",
//									"attrs": {
//										"attached": {
//											"type": "bool",
//											"valText": "#!!event.target"
//										}
//									}
//								},
//								"mockup": "false",
//								"codes": "true",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false",
//								"containerSlots": {
//									"jaxId": "1HL3QUBIF5",
//									"attrs": {}
//								}
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1HL3PMAUT4",
//					"attrs": {
//						"1HL3R6H6R0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HU6CM3PJ6",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HU6CM3PJ7",
//									"attrs": {
//										"border": "1"
//									}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HL3R6H6R0",
//							"faceTagName": "blur"
//						},
//						"1HL3R635T0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HU6CM3PJ8",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HU6CM3PJ9",
//									"attrs": {
//										"border": "3"
//									}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HL3R635T0",
//							"faceTagName": "focus"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1HL3PMAUT5",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1HL3PMAUT6",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1HL3PMAUT7",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"background": "false",
//				"color": "false",
//				"gradient": "false",
//				"border": "false",
//				"borders": "false",
//				"borderStyle": "false",
//				"borderColor": "false",
//				"borderColors": "false",
//				"corner": "false",
//				"coner": "false",
//				"coners": "false",
//				"shadow": "false",
//				"shadowX": "false",
//				"shadowY": "false",
//				"shadowBlur": "false",
//				"shadowSpread": "false",
//				"shadowColor": "false",
//				"maskImage": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}