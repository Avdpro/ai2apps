//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {NaviToolBar} from "/@StdUI/ui/NaviToolBar.js";
import {BtnNaviItem} from "/@StdUI/ui/BtnNaviItem.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
/*#{1I4OO0SN10StartDoc*/
import tabEnv from "/@tabos/tabos_env.js";
import {} from "../data/AppData.js";
import {AAFarm} from "../aafarm.js";
import {AABotNode} from "../AABotNode.js";
import {BoxBot} from "./BoxBot.js";
import {getCloudPkgInfo,getLocalPkgInfo,installPkg} from "/@pkg/pkgUtil.js";
import {Botwork} from "./Botwork.js";
/*}#1I4OO0SN10StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BotNodeUI=function(){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let txtTitle,boxNavi,naviBar,dkUI,subUIBots,boxBots;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let docker=false;
	let appBotNode=AABotNode.getAppBotNode(true);
	
	/*#{1I4OO0SN11LocalVals*/
	const app=VFACT.app;
	const botUIs=new Map();
	docker=false;
	/*}#1I4OO0SN11LocalVals*/
	
	/*#{1I4OO0SN11PreState*/
	/*}#1I4OO0SN11PreState*/
	/*#{1I4OO0SN11PostState*/
	/*}#1I4OO0SN11PostState*/
	cssVO={
		"hash":"1I4OO0SN11",nameHost:true,
		"type":"view","x":0,"y":0,"w":"100%","h":"100%","padding":[0,0,0,docker?50:0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
		children:[
			{
				"hash":"1I4OO2PNM0",
				"type":"hud","id":"BoxHeader","position":"relative","x":0,"y":0,"w":"100%","h":40,"padding":[5,10,5,10],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"contentLayout":"flex-x",
				children:[
					{
						"hash":"1I4OPRCUK0",
						"type":"text","id":"TxtTitle","position":"relative","x":0,"y":0,"w":"","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":[0,0,0],
						"text":"AI2Apps BotNode","fontWeight":"bold","fontStyle":"normal","textDecoration":"","alignV":1,
					}
				],
			},
			{
				"hash":"1I4OPNR530",
				"type":"box","id":"BoxNavi","position":"relative","x":0,"y":0,"w":"100%","h":30,"padding":[0,5,0,5],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"background":[255,255,255,1],"border":[0,0,1,0],"contentLayout":"flex-x",
				children:[
					{
						"hash":"1I4OPPGAS0",
						"type":NaviToolBar(),"id":"NaviBar","position":"relative","x":0,"y":1,"face":"top",
						subContainers:{
							"1HL4P0I9P0":[
								{
									"hash":"1I54U4HL40",
									"type":BtnNaviItem("Home","Home",[0,0,0,1],appCfg.sharedAssets+"/home.svg",undefined,14,false),"position":"relative","x":0,"y":0,"margin":[0,10,0,0],
									"OnClick":function(event){
										/*#{1I55Q8E0M0FunctionBody*/
										dkUI.showUI(subUIBots);
										/*}#1I55Q8E0M0FunctionBody*/
									},
								}
							]
						},
					}
				],
			},
			{
				"hash":"1I4T8G3TD0",
				"type":"dock","id":"DkUI","position":"relative","x":0,"y":0,"w":"100%","h":">calc(100% - 90px)","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"coverAction":1,"ui":0,
				children:[
					{
						"hash":"1I4TA0C690",
						"type":"hud","id":"SubUIBots","x":0,"y":0,"w":"100%","h":"100%","overflow":"auto-y","padding":10,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						"contentLayout":"flex-y","itemsAlign":1,
						children:[
							{
								"hash":"1I5516EAC0",
								"type":"hud","id":"BoxBotsHeader","position":"relative","x":0,"y":0,"w":"100%","h":40,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
								"contentLayout":"flex-x","itemsAlign":1,
								children:[
									{
										"hash":"1I5517IJ70",
										"type":BtnIcon("secondary",30,0,appCfg.sharedAssets+"/undo.svg",null),"position":"relative","x":0,"y":0,
									},
									{
										"hash":"1I5518UAS0",
										"type":"text","position":"relative","x":0,"y":0,"w":"","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":[0,0,0],"text":"Bots in Node",
										"fontSize":txtSize.midPlus,"fontWeight":"bold","fontStyle":"normal","textDecoration":"","alignH":1,"alignV":1,
									}
								],
							},
							{
								"hash":"1I551BDEK0",
								"type":"hud","id":"BoxBots","position":"relative","x":0,"y":0,"w":"100%","h":"","minW":"","minH":100,"maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
							}
						],
					}
				],
			},
			{
				"hash":"1I4T8H7F30",
				"type":"box","position":"relative","x":0,"y":0,"w":"100%","h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["secondary"],
			}
		],
		/*#{1I4OO0SN11ExtraCSS*/
		/*}#1I4OO0SN11ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			self=this;
			txtTitle=self.TxtTitle;boxNavi=self.BoxNavi;naviBar=self.NaviBar;dkUI=self.DkUI;subUIBots=self.SubUIBots;boxBots=self.BoxBots;
			/*#{1I4OO0SN11Create*/
			self.syncNodeInfo();
			//self.syncBots();
			/*}#1I4OO0SN11Create*/
		},
		/*#{1I4OO0SN11EndCSS*/
		/*}#1I4OO0SN11EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.syncNodeInfo=async function(){
		/*#{1I5535BB60Start*/
		let info,alias;
		subUIBots.display=false;
		alias=await AAFarm.getLocalAlias();
		info=await appBotNode.getNodeInfo();
		//TODO: Check and install packages.
		await self.ensurePackages(info.packages);
		await self.syncBots();
		subUIBots.display=true;
		txtTitle.text=`Node: ${info.id}, browser: ${alias||"not managed"}`;
		/*}#1I5535BB60Start*/
	};
	//------------------------------------------------------------------------
	cssVO.syncBots=async function(){
		/*#{1I50PJG3I0Start*/
		let bot,bots,css;
		boxBots.clearChildren();
		bots=await appBotNode.syncBots();
		console.log(bots);
		for(bot of bots){
			css={
				type:BoxBot(bot),position:"relative",bot:bot,
				OnClick(){
				},
				startBot(bot){
					self.startBot(bot);
				}
			};
			boxBots.appendNewChild(css);
		}
		/*}#1I50PJG3I0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.ensurePackages=async function(pkgList){
		/*#{1I55GPA0I0Start*/
		let needUpdate,cldInfo,locInfo,pkgName,tag,tagVO,pkgVsn;
		txtTitle.text=`Checking packages...`;
		needUpdate=false;
		for(pkgName of pkgList){
			cldInfo=await getCloudPkgInfo(pkgName);
			if(!cldInfo){
				continue;
			}
			tag=cldInfo.tag;
			tagVO=cldInfo.tags.find(item=>item.tag===tag);
			if(!tagVO){
				continue;
			}
			pkgVsn=tagVO.versionIdx;
			
			locInfo=await getLocalPkgInfo(pkgName);
			if(!locInfo){
				needUpdate=true;
				continue;
			}
			if(locInfo.versionIdx<pkgVsn){
				needUpdate=true;
			}
		}
		if(!needUpdate){
			return;
		}
		txtTitle.text=`Update packages...`;
		//Update all packages:
		await app.modalDlg("/@homekit/ui/DlgCloud.js",{
			mode:"Work",
			title:"Update system",
			workingText:"Update Tab-OS packages...",
			work:async function(tty){
				let list,pkgName,options;
				list=pkgList;
				options={
					mode:"install",
					noMerge:false,
					upgrade:true,
					sysDisk:"coke",
					tree:true,
					tty:tty
				};
				for(pkgName of list){
					tabEnv.chdir("/");
					await installPkg(tabEnv,pkgName,options);
				}
			}				
		});
		location.reload();
		/*}#1I55GPA0I0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.startBot=async function(bot){
		/*#{1I50R2QMF0Start*/
		let box,tab;
		box=botUIs.get(bot.id);
		if(box){
			tab=box.tab;
			naviBar.focusOn(tab);
			dkUI.showUI(box);
			return;
		}
		box=dkUI.showNewUI(Botwork(bot),{});
		box.hold();
		tab=naviBar.addItem({
			type:BtnNaviItem(bot.name,bot.name,cfgColor.fontBody,appCfg.sharedAssets+"/agent.svg",null,txtSize.mid,false),
			"margin":[0,10,0,0],
			OnClick(evt){
				dkUI.showUI(box);
			}
		});
		box.tab=tab;
		naviBar.focusOn(tab);
		botUIs.set(bot.id,box);
		/*}#1I50R2QMF0Start*/
	};
	/*#{1I4OO0SN11PostCSSVO*/
	/*}#1I4OO0SN11PostCSSVO*/
	return cssVO;
};
/*#{1I4OO0SN11ExCodes*/
/*}#1I4OO0SN11ExCodes*/


/*#{1I4OO0SN10EndDoc*/
/*}#1I4OO0SN10EndDoc*/

export default BotNodeUI;
export{BotNodeUI};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "UIView",
//	"jaxId": "1I4OO0SN10",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1I4OO0SN12",
//			"attrs": {
//				"device": "Desktop 800x600",
//				"screenW": "800",
//				"screenH": "600",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1I4OO0SN13",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1I4OO0SN14",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1I4OO0SN15",
//			"attrs": {}
//		},
//		"localVars": {
//			"jaxId": "1I4OO0SN16",
//			"attrs": {
//				"docker": {
//					"type": "auto",
//					"valText": "false"
//				},
//				"appBotNode": {
//					"type": "auto",
//					"valText": "#AABotNode.getAppBotNode(true)"
//				}
//			}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1I4OO0SN17",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I5535BB60",
//					"attrs": {
//						"id": "syncNodeInfo",
//						"label": "New AI Seg",
//						"x": "80",
//						"y": "70",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I5535QGH0",
//							"attrs": {}
//						},
//						"async": "true",
//						"localVars": {
//							"jaxId": "1I5535QGH1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I5535QGH2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						}
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I50PJG3I0",
//					"attrs": {
//						"id": "syncBots",
//						"label": "New AI Seg",
//						"x": "80",
//						"y": "150",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I50PJPEB0",
//							"attrs": {}
//						},
//						"async": "true",
//						"localVars": {
//							"jaxId": "1I50PJPEB1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I50PJPEB2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						}
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I55GPA0I0",
//					"attrs": {
//						"id": "ensurePackages",
//						"label": "New AI Seg",
//						"x": "80",
//						"y": "245",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I55GPVN20",
//							"attrs": {
//								"pkgList": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"localVars": {
//							"jaxId": "1I55GPVN21",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I55GPVN22",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						}
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I50R2QMF0",
//					"attrs": {
//						"id": "startBot",
//						"label": "New AI Seg",
//						"x": "80",
//						"y": "320",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I50R3JUS0",
//							"attrs": {
//								"bot": {
//									"type": "auto",
//									"valText": "null"
//								}
//							}
//						},
//						"async": "true",
//						"localVars": {
//							"jaxId": "1I50R3JUS1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I50R3JUS2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						}
//					}
//				}
//			]
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1I4OO0SN18",
//			"attrs": {}
//		},
//		"mockupStates": {
//			"jaxId": "1I4OO0SN19",
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "view",
//			"jaxId": "1I4OO0SN11",
//			"attrs": {
//				"properties": {
//					"jaxId": "1I4OO0SN110",
//					"attrs": {
//						"type": "view",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "100%",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "#[0,0,0,docker?50:0]",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Flex Y"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1I4OO2PNM0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I4OO7I5V0",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxHeader",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "40",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "[5,10,5,10]",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex X"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1I4OPRCUK0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I4OQ05DV0",
//													"attrs": {
//														"type": "text",
//														"id": "TxtTitle",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "[0,0,0]",
//														"text": "AI2Apps BotNode",
//														"font": "",
//														"fontSize": "16",
//														"bold": "true",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Center",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I4OQ05DV1",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1I4OQ05DV2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I4OQ05DV3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1I4OO7I5V1",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1I4OO7I5V2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1I4OO7I5V3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1I4OPNR530",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I4OPP0R00",
//									"attrs": {
//										"type": "box",
//										"id": "BoxNavi",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "[0,5,0,5]",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "[255,255,255,1.00]",
//										"border": "[0,0,1,0]",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"contentLayout": "Flex X"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/NaviToolBar.js",
//											"jaxId": "1I4OPPGAS0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1I4OQ05DV4",
//													"attrs": {}
//												},
//												"properties": {
//													"jaxId": "1I4OQ05DV5",
//													"attrs": {
//														"type": "#null#>NaviToolBar()",
//														"id": "NaviBar",
//														"position": "Relative",
//														"x": "0",
//														"y": "1",
//														"display": "On",
//														"face": "\"top\""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I4OQ05DV6",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1I4OQ05DV7",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I4OQ05DV8",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1I4OQ05DV9",
//													"attrs": {
//														"Slot1HL4P0I9P0": {
//															"jaxId": "1I4OQ05DV10",
//															"attrs": {
//																"subHuds": {
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "Gear/@StdUI/ui/BtnNaviItem.js",
//																			"jaxId": "1I54U4HL40",
//																			"attrs": {
//																				"createArgs": {
//																					"jaxId": "1I54U7PL20",
//																					"attrs": {
//																						"code": "Home",
//																						"text": "Home",
//																						"color": "[0,0,0,1.00]",
//																						"icon": "#appCfg.sharedAssets+\"/home.svg\"",
//																						"items": "",
//																						"fontSize": "14",
//																						"hasClose": "false"
//																					}
//																				},
//																				"properties": {
//																					"jaxId": "1I54U7PL21",
//																					"attrs": {
//																						"type": "#null#>BtnNaviItem(\"Home\",\"Home\",[0,0,0,1],appCfg.sharedAssets+\"/home.svg\",undefined,14,false)",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"display": "On",
//																						"face": "",
//																						"margin": "[0,10,0,0]"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1I54U7PL22",
//																					"attrs": {}
//																				},
//																				"functions": {
//																					"jaxId": "1I54U7PL23",
//																					"attrs": {
//																						"OnClick": {
//																							"type": "fixedFunc",
//																							"jaxId": "1I55Q8E0M0",
//																							"attrs": {
//																								"callArgs": {
//																									"jaxId": "1I55Q8KLD0",
//																									"attrs": {
//																										"event": ""
//																									}
//																								},
//																								"seg": ""
//																							}
//																						}
//																					}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1I54U7PL24",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false",
//																				"containerSlots": {
//																					"jaxId": "1I54U7PL25",
//																					"attrs": {}
//																				}
//																			}
//																		}
//																	]
//																},
//																"container": "true"
//															}
//														}
//													}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1I4OPP0R01",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1I4OPP0R02",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1I4OPP0R03",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "dock",
//							"jaxId": "1I4T8G3TD0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I4T8HLQN0",
//									"attrs": {
//										"type": "dock",
//										"id": "DkUI",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%-90",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"coverAction": "Dispose",
//										"ui": "0"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1I4TA0C690",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I4TA1UIA0",
//													"attrs": {
//														"type": "hud",
//														"id": "SubUIBots",
//														"position": "Absolute",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Auto Scroll Y",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "10",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex Y",
//														"itemsAlign": "Center"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1I5516EAC0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I551AM9M0",
//																	"attrs": {
//																		"type": "hud",
//																		"id": "BoxBotsHeader",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "40",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"contentLayout": "Flex X",
//																		"itemsAlign": "Center"
//																	}
//																},
//																"subHuds": {
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "Gear/@StdUI/ui/BtnIcon.js",
//																			"jaxId": "1I5517IJ70",
//																			"attrs": {
//																				"createArgs": {
//																					"jaxId": "1I551AM9M1",
//																					"attrs": {
//																						"style": "\"secondary\"",
//																						"w": "30",
//																						"h": "0",
//																						"icon": "#appCfg.sharedAssets+\"/undo.svg\"",
//																						"colorBG": "null"
//																					}
//																				},
//																				"properties": {
//																					"jaxId": "1I551AM9M2",
//																					"attrs": {
//																						"type": "#null#>BtnIcon(\"secondary\",30,0,appCfg.sharedAssets+\"/undo.svg\",null)",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"display": "On",
//																						"face": ""
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1I551AM9M3",
//																					"attrs": {}
//																				},
//																				"functions": {
//																					"jaxId": "1I551AM9M4",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1I551AM9M5",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false",
//																				"containerSlots": {
//																					"jaxId": "1I551AM9M6",
//																					"attrs": {}
//																				}
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "text",
//																			"jaxId": "1I5518UAS0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I551AM9M7",
//																					"attrs": {
//																						"type": "text",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "",
//																						"h": "100%",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"color": "[0,0,0]",
//																						"text": "Bots in Node",
//																						"font": "",
//																						"fontSize": "#txtSize.midPlus",
//																						"bold": "true",
//																						"italic": "false",
//																						"underline": "false",
//																						"alignH": "Center",
//																						"alignV": "Center",
//																						"wrap": "false",
//																						"ellipsis": "false",
//																						"lineClamp": "0",
//																						"select": "false",
//																						"shadow": "false",
//																						"shadowX": "0",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowColor": "[0,0,0,1.00]",
//																						"shadowEx": "",
//																						"maxTextW": "0"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1I551AM9M8",
//																					"attrs": {}
//																				},
//																				"functions": {
//																					"jaxId": "1I551AM9M9",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1I551AM9M10",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false"
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"jaxId": "1I551AM9M11",
//																	"attrs": {}
//																},
//																"functions": {
//																	"jaxId": "1I551AM9M12",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1I551AM9M13",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false",
//																"exposeContainer": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1I551BDEK0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I551BTUS0",
//																	"attrs": {
//																		"type": "hud",
//																		"id": "BoxBots",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "100",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"contentLayout": "Flex Y"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1I551BTUS1",
//																	"attrs": {}
//																},
//																"functions": {
//																	"jaxId": "1I551BTUS2",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1I551BTUS3",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "true",
//																"exposeContainer": "false"
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1I4TA1UIA1",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1I4TA1UIA2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I4TA1UIA3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "true",
//												"exposeContainer": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1I4T8HLQN1",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1I4T8HLQN2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1I4T8HLQN3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1I4T8H7F30",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I4T8HLQN4",
//									"attrs": {
//										"type": "box",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "20",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"secondary\"]",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1I4T8HLQO0",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1I4T8HLQO1",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1I4T8HLQO2",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1I4OO0SN111",
//					"attrs": {}
//				},
//				"functions": {
//					"jaxId": "1I4OO0SN112",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1I4OO0SN113",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1I4OO0SN114",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}