//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
import {BtnState} from "./BtnState.js";
/*#{1IV16MNG10StartDoc*/
import pathLib from "/@path";
import {tabOS,tabFS,tabNT} from "/@tabos";
import {AATools} from "/@tabos/AATools.js";
import {AgentHub} from "../AgentHub.js";
import {runAgent,showChatThread} from "/@AgentBuilder/ai/RunAgent.js";
import Base64 from "/@tabos/utils/base64.js";
import {AppFrame} from "/@homekit/ui/AppFrame.js";
import {BtnChatSession} from "./BtnChatSession.js";
import {AaChatClient} from "/@aichat/chatclient.js";
/*}#1IV16MNG10StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let UIShadowApp=function(app,appFrame){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let boxMainUI,boxMenuNotify,btnNewChat,boxChats,boxHome,edCommand,txtInputTip,btnSendCmd,boxAssets,btnChatEntry,txtChatEntry,boxSideBarFrame,boxSideBar,txtToken,txtGas,boxChatList,txtWait;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1IV16MNG11LocalVals*/
	let isUpdatingTokenGas=false;
	let waitVersion=1;
	let chatFrames=[];
	let hotChatFrame=null;
	
	let chatEntryTool=null;
	
	let chatClient=new AaChatClient();
	/*}#1IV16MNG11LocalVals*/
	
	/*#{1IV16MNG11PreState*/
	/*}#1IV16MNG11PreState*/
	/*#{1IV16MNG11PostState*/
	/*}#1IV16MNG11PostState*/
	cssVO={
		"hash":"1IV16MNG11",nameHost:true,
		"type":"view","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
		children:[
			{
				"hash":"1IV1EFE300",
				"type":"hud","id":"BoxMainUI","x":0,"y":0,"w":"100%","h":"100%","styleClass":"",
				children:[
					{
						"hash":"1IV16O6PS0",
						"type":"box","id":"BoxHeader","x":0,"y":0,"w":"100%","h":40,"padding":[0,5,0,5],"styleClass":"","background":[255,255,255,1],"border":[0,0,1,0],
						"contentLayout":"flex-x","itemsAlign":1,
						children:[
							{
								"hash":"1IVBLA5DJ0",
								"type":"hud","position":"relative","x":0,"y":0,"w":30,"h":30,"styleClass":"",
								children:[
									{
										"hash":"1IV16PTRN0",
										"type":BtnIcon("front",30,0,appCfg.sharedAssets+"/menu.svg",null),"id":"BtnMenu","position":"relative","x":0,"y":0,
										"OnClick":function(event){
											self.showSideBar(this,event);
										},
									},
									{
										"hash":"1IVBLATNU0",
										"type":"box","id":"BoxMenuNotify","x":">calc(100% - 8px)","y":2,"w":10,"h":10,"display":0,"styleClass":"","background":cfgColor["error"],"corner":10,
									}
								],
							},
							{
								"hash":"1IV16V6GC0",
								"type":"text","id":"TxtTitle","position":"relative","x":0,"y":0,"w":"","h":"","padding":[0,0,0,10],"styleClass":"","color":cfgColor["fontBody"],
								"text":"AI2Apps","fontSize":txtSize.midPlus,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","flex":true,
							},
							{
								"hash":"1IV170TEB0",
								"type":BtnIcon("front",30,0,appCfg.sharedAssets+"/chat_add.svg",null),"id":"BtnNewChat","position":"relative","x":0,"y":0,
								"OnClick":function(event){
									self.showHome(this,event);
								},
							}
						],
					},
					{
						"hash":"1IV1739RE0",
						"type":"hud","id":"BoxChats","x":0,"y":40,"w":"100%","h":">calc(100% - 40px)","styleClass":"",
					},
					{
						"hash":"1IV19P27I0",
						"type":"hud","id":"BoxHome","x":0,"y":40,"w":"100%","h":">calc(100% - 40px)","padding":[20,0,50,0],"styleClass":"","contentLayout":"flex-y","itemsAlign":1,
						children:[
							{
								"hash":"1IV19QL640",
								"type":"box","id":"BoxAALogo","position":"relative","x":0,"y":0,"w":100,"h":100,"margin":20,"styleClass":"","background":cfgColor["fontBody"],
								"maskImage":appCfg.sharedAssets+"/aalogo.svg",
							},
							{
								"hash":"1IV19VC8U0",
								"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":100,"styleClass":"","flex":true,
							},
							{
								"hash":"1IV19TGAS0",
								"type":"box","id":"BoxInput","position":"relative","x":0,"y":0,"w":"90%","h":"","margin":[20,0,0,0],"padding":[8,10,5,10],"minW":"","minH":40,
								"maxW":800,"maxH":"","styleClass":"","background":cfgColor["chatInputBG"],"border":1,"borderColor":cfgColor["fontBodyLit"],"corner":16,"shadowX":0,
								"shadowColor":[0,0,0,0.2],"contentLayout":"flex-y","itemsAlign":1,"subAlign":1,"itemsWrap":1,
								children:[
									{
										"hash":"1IV19TGAT0",
										"type":"hud","id":"BoxInputLine","position":"relative","x":0,"y":0,"w":"100%","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
										"contentLayout":"flex-x","itemsAlign":2,"subAlign":1,
										children:[
											{
												"hash":"1IV19TGAT2",
												"type":"memo","id":"EdCommand","position":"relative","x":0,"y":0,"w":">calc(100% - 40px)","h":"","minW":"","minH":30,"maxW":"","maxH":200,
												"styleClass":"","color":cfgColor["fontBody"],"background":[255,255,255,0],"outline":0,"border":[0,0,1,0],"borderColor":cfgColor["fontBodyLit"],
												"OnInput":function(){
													/*#{1IV19TGAU11FunctionBody*/
													txtInputTip.display=!this.text;
													btnSendCmd.enable=!!this.text;
													/*}#1IV19TGAU11FunctionBody*/
												},
												"OnKeyDown":function(event){
													/*#{1IV19TGAU13FunctionBody*/
													if(event.code==="Enter"){
														if(appCfg.isMobile){
															//Accept enter as new-line
														}else{
															if((!event.isComposing) &&(!event.shiftKey)){
																event.stopPropagation();
																event.preventDefault();
																self.runCommand();
															}
														}
													}
													/*}#1IV19TGAU13FunctionBody*/
												},
											},
											{
												"hash":"1IV19TGAU16",
												"type":"text","id":"TxtInputTip","x":10,"y":0,"w":"","h":"100%","uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodyLit"],
												"text":(($ln==="CN")?("给出你的指令..."):("Make your command...")),"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,
											},
											{
												"hash":"1IV19TGAV4",
												"type":BtnIcon("front",30,0,appCfg.sharedAssets+"/send.svg",null),"id":"BtnSendCmd","position":"relative","x":0,"y":0,"padding":3,"margin":[0,0,0,3],
												"enable":false,
												"OnClick":function(event){
													self.runCommand(this,event);
												},
											}
										],
										"OnClick":function(event){
											/*#{1IV19TGAV35FunctionBody*/
											/*}#1IV19TGAV35FunctionBody*/
										},
									},
									{
										"hash":"1IV19TGB00",
										"type":"hud","id":"BoxAssets","position":"relative","x":0,"y":0,"w":">calc(100% - 60px)","h":"","padding":0,"minW":"","minH":"","maxW":"","maxH":"",
										"styleClass":"","contentLayout":"flex-y",
									},
									{
										"hash":"1IV19TGB015",
										"type":"hud","id":"BoxToolBtns","position":"relative","x":0,"y":0,"w":"100%","h":"","margin":[10,0,0,0],"padding":[0,5,5,5],"minW":"","minH":"",
										"maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x","itemsWrap":1,"itemsAlign":1,
										children:[
											{
												"hash":"1IV19TGB017",
												"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/asset.svg",null),"id":"BtnAddAssets","position":"relative","x":0,"y":0,"margin":[0,5,0,5],
												"tip":(($ln==="CN")?("附加内容"):("Add assets")),
												"OnClick":function(event){
													/*#{1IV19TGB112FunctionBody*/
													/*}#1IV19TGB112FunctionBody*/
												},
											},
											{
												"hash":"1IV19TGB116",
												"type":"hud","id":"SegChatEntry","position":"relative","x":0,"y":0,"w":"","h":"100%","cursor":"pointer","margin":[0,5,0,5],"minW":"","minH":"",
												"maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x","itemsAlign":1,
												children:[
													{
														"hash":"1IV19TGB118",
														"type":"box","id":"BoxChatEntryBG","x":-2,"y":-2,"w":">calc(100% + 4px)","h":">calc(100% + 4px)","display":0,"uiEvent":-1,"minW":"","minH":"",
														"maxW":"","maxH":"","styleClass":"","background":cfgColor["hot"],"border":1,"borderColor":cfgColor["fontBodySub"],"corner":6,
													},
													{
														"hash":"1IV19TGB212",
														"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/appdata.svg",null),"id":"BtnChatEntry","position":"relative","x":0,"y":0,
														"tip":(($ln==="CN")?("选择对话智能体"):("Choose chat AI Agent")),
														"OnClick":function(event){
															/*#{1IV19TGB30FunctionBody*/
															/*}#1IV19TGB30FunctionBody*/
														},
													},
													{
														"hash":"1IV19TGB34",
														"type":"text","id":"TxtChatEntry","position":"relative","x":0,"y":0,"w":"","h":"","display":0,"uiEvent":-1,"margin":[0,3,0,3],"minW":"",
														"minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],"text":"Web Search","fontSize":txtSize.small,"fontWeight":"normal",
														"fontStyle":"normal","textDecoration":"",
													}
												],
												"OnClick":function(event){
													/*#{1IV19TGB331FunctionBody*/
													/*}#1IV19TGB331FunctionBody*/
												},
											},
											{
												"hash":"1IV19TGB334",
												"type":"box","position":"relative","x":0,"y":0,"w":1,"h":16,"display":0,"margin":[0,0,0,5],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
												"background":cfgColor["fontBodyLit"],
											},
											{
												"hash":"1IV19TGB513",
												"type":"hud","position":"relative","x":0,"y":0,"w":1,"h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","flex":true,
											},
											{
												"hash":"1IV1BU1L90",
												"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/menu.svg",null),"position":"relative","x":0,"y":0,
											}
										],
									}
								],
							}
						],
					}
				],
			},
			{
				"hash":"1IV1848C50",
				"type":"box","id":"BoxSideBarFrame","x":0,"y":0,"w":"100%","h":"100%","styleClass":"","background":[cfgColor["fontBodyLit"][0],cfgColor["fontBodyLit"][1],cfgColor["fontBodyLit"][2],0.5],
				children:[
					{
						"hash":"1IV1896KM0",
						"type":"box","id":"BoxSideBar","x":0,"y":0,"w":"80%","h":"100%","padding":10,"styleClass":"","background":[255,255,255,1],"border":[0,1,0,0],"borderColor":cfgColor["fontBodyLit"],
						"contentLayout":"flex-y","itemsAlign":1,
						children:[
							{
								"hash":"1IV18OGH00",
								"type":"hud","id":"BoxSideBarHeader","position":"relative","x":0,"y":0,"w":"100%","h":30,"margin":[0,0,10,0],"styleClass":"","contentLayout":"flex-x",
								"itemsAlign":1,
								children:[
									{
										"hash":"1IV18Q9F30",
										"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/token.svg",null),"id":"BtnToken","position":"relative","x":1,"y":0,"padding":2,
									},
									{
										"hash":"1IV18SP7N0",
										"type":"text","id":"TxtToken","position":"relative","x":0,"y":0,"w":"","h":"","minW":20,"styleClass":"","color":[0,0,0],"text":"-","fontWeight":"normal",
										"fontStyle":"normal","textDecoration":"",
									},
									{
										"hash":"1IV18TL8V0",
										"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/gas.svg",null),"id":"BtnToken","position":"relative","x":1,"y":0,"padding":2,
									},
									{
										"hash":"1IV18TV7Q0",
										"type":"text","id":"TxtGas","position":"relative","x":0,"y":0,"w":"","h":"","minW":20,"minH":"","maxW":"","maxH":"","styleClass":"","color":[0,0,0],
										"text":"-","fontWeight":"normal","fontStyle":"normal","textDecoration":"",
									}
								],
							},
							{
								"hash":"1IV50K5S90",
								"type":"text","position":"relative","x":0,"y":0,"w":"100%","h":"","styleClass":"","color":cfgColor["fontBodySub"],"text":(($ln==="CN")?("与智能体的对话:"):("Agent conversations:")),
								"fontSize":txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
							},
							{
								"hash":"1IV192N0G0",
								"type":"box","position":"relative","x":0,"y":0,"w":"100%","h":1,"margin":[3,0,0,0],"styleClass":"","background":cfgColor["fontBodyLit"],
							},
							{
								"hash":"1IV1915JK0",
								"type":"hud","id":"BoxChatList","position":"relative","x":0,"y":0,"w":"100%","h":100,"overflow":"auto-y","styleClass":"","flex":true,"contentLayout":"flex-y",
							},
							{
								"hash":"1IV18IRCP0",
								"type":BtnState("folder.svg",null,(($ln==="CN")?("已归档对话"):("Archived")),16,"run.svg"),"position":"relative","x":0,"y":0,"enable":false,
							},
							{
								"hash":"1IV18LFE00",
								"type":BtnState("store.svg",null,(($ln==="CN")?("智能体市场"):("Agent Mart")),16,"run.svg"),"position":"relative","x":0,"y":0,"enable":false,
							}
						],
					}
				],
				"OnClick":function(event){
					self.closeSideBar(this,event);
				},
			},
			{
				"hash":"1IV2KV6QS0",
				"type":"box","id":"BoxWaitBG","x":0,"y":0,"w":"100%","h":"100%","display":0,"styleClass":"","background":cfgColor["body"],
				children:[
					{
						"hash":"1IV2L1LPF0",
						"type":"text","id":"TxtWait","x":0,"y":"40%","w":"100%","h":"","padding":[0,20,0,20],"styleClass":"","color":cfgColor["fontBody"],"text":"Connecting to your AI2Apps client...",
						"fontSize":txtSize.midPlus,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","wrap":true,
					}
				],
			}
		],
		/*#{1IV16MNG11ExtraCSS*/
		/*}#1IV16MNG11ExtraCSS*/
		faces:{
			"start":{
				/*BoxMainUI*/"#1IV1EFE300":{
					"display":0
				},
				/*BtnMenu*/"#1IV16PTRN0":{
					"enable":false
				},
				/*BtnNewChat*/"#1IV170TEB0":{
					"enable":false,"display":0
				},
				/*BoxAALogo*/"#1IV19QL640":{
					"alpha":0.5
				},
				/*BoxInput*/"#1IV19TGAS0":{
					"display":0
				},
				/*BoxSideBarFrame*/"#1IV1848C50":{
					"display":0
				},
				/*BoxWaitBG*/"#1IV2KV6QS0":{
					"display":1
				}
			},"ready":{
				/*BoxMainUI*/"#1IV1EFE300":{
					"display":1
				},
				/*BtnMenu*/"#1IV16PTRN0":{
					"enable":true
				},
				/*BtnNewChat*/"#1IV170TEB0":{
					"enable":true
				},
				/*BoxAALogo*/"#1IV19QL640":{
					"alpha":1
				},
				/*BoxInput*/"#1IV19TGAS0":{
					"display":1
				},
				/*BoxSideBarFrame*/"#1IV1848C50":{
					"display":0
				},
				/*BoxWaitBG*/"#1IV2KV6QS0":{
					"display":0
				}
			},"home":{
				/*BtnNewChat*/"#1IV170TEB0":{
					"display":0
				},
				/*BoxChats*/"#1IV1739RE0":{
					"display":0
				},
				/*BoxHome*/"#1IV19P27I0":{
					"display":1
				}
			},"chat":{
				/*BtnNewChat*/"#1IV170TEB0":{
					"display":1
				},
				/*BoxChats*/"#1IV1739RE0":{
					"display":1
				},
				/*BoxHome*/"#1IV19P27I0":{
					"display":0
				}
			},"wait":{
				/*BoxWaitBG*/"#1IV2KV6QS0":{
					"display":1
				}
			},"!wait":{
				/*BoxWaitBG*/"#1IV2KV6QS0":{
					"display":0
				}
			}
		},
		OnCreate:function(){
			self=this;
			boxMainUI=self.BoxMainUI;boxMenuNotify=self.BoxMenuNotify;btnNewChat=self.BtnNewChat;boxChats=self.BoxChats;boxHome=self.BoxHome;edCommand=self.EdCommand;txtInputTip=self.TxtInputTip;btnSendCmd=self.BtnSendCmd;boxAssets=self.BoxAssets;btnChatEntry=self.BtnChatEntry;txtChatEntry=self.TxtChatEntry;boxSideBarFrame=self.BoxSideBarFrame;boxSideBar=self.BoxSideBar;txtToken=self.TxtToken;txtGas=self.TxtGas;boxChatList=self.BoxChatList;txtWait=self.TxtWait;
			/*#{1IV16MNG11Create*/
			let orgGetFrame=window.getAppFrame;
			window.getAppFrame=function(win){
				let frame;
				if(orgGetFrame){
					frame=orgGetFrame(win);
					if(frame){
						return frame;
					}
				}
				for(frame of chatFrames){
					let ifm;
					ifm=frame.getPageFrame();
					if(ifm && ifm.contentWindow===win){
						return frame;
					}
				}
			};
			
			self.startClient();
			
			chatClient.onNotify("Offline",()=>{
				window.alert((($ln==="CN")?("与AI2Apps服务器的连接丢失。"):/*EN*/("Lost connection to AI2Apps server.")));
				location.reload();
				//self.startClient();
			});
			
			chatClient.onNotify("HostClientOffline",()=>{
				window.alert((($ln==="CN")?("失去与AI2Apps主机客户端的连接。"):/*EN*/("Lost connection to AI2Apps host-client.")));
				location.reload();
			});
			
			chatClient.onNotify("ThreadsSynced",()=>{
				self.showThreads(chatClient.threads);
				self.hideWait();
			});
			
			chatClient.on("NewThread",async (thread)=>{
				let btn=await self.addSession(null,thread.title,thread);
				if(thread.showOnReady){
					self.showSession(btn);
				}else{
					btn.showFace("blur");
				}
			});
			
			chatClient.on("NewMessage",async (thread,message)=>{
				let btn=thread.sessionBtn;
				if(btn){
					boxChatList.insertBefore(btn,boxChatList.firstChild);
					if(!btn.isFocused() && !boxSideBarFrame.display){
						boxMenuNotify.display=true;
					}
				}
			});
			
			chatClient.on("ArchiveThread",async (thread)=>{
				let btn=thread.sessionBtn;
				let frame=btn.frame;
				if(frame && frame===hotChatFrame){
					return;
				}
				boxChatList.removeChild(btn);
			});
			
			chatClient.on("DeleteThread",async (thread)=>{
				let btn=thread.sessionBtn;
				let frame=btn.frame;
				if(frame && frame===hotChatFrame){
					return;
				}
				boxChatList.removeChild(btn);
			});
			/*}#1IV16MNG11Create*/
		},
		/*#{1IV16MNG11EndCSS*/
		/*}#1IV16MNG11EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.startClient=async function(){
		/*#{1IV1BV5D40Start*/
		self.showFace("start");
		self.checkLogin(async ()=>{
			let code;
			txtWait.text=(($ln==="CN")?("正在连接到AI2Apps客户端..."):/*EN*/("Connecting to AI2Apps client..."));
			do{
				code=await chatClient.connect({shadow:true});
				if(code===404){
					window.alert((($ln==="CN")?("找不到可以连接的本地主机客户端。"):/*EN*/("Unable to find a local host client to connect to.")));
				}else if(code===0){
					window.alert((($ln==="CN")?("网络错误"):/*EN*/("Network error.")));
				}else if(code!==200){
					window.alert((($ln==="CN")?("连接到本地主机客户端遇到错误。"):/*EN*/("Can't connect to local host client.")));
				}
			}while(code!==200);
			self.showFace("ready");
			self.showFace("newchat");
			callAfter(()=>{edCommand.focus();});
		});
		/*}#1IV1BV5D40Start*/
	};
	//------------------------------------------------------------------------
	cssVO.syncChats=async function(){
		/*#{1IV1BVERF0Start*/
		/*}#1IV1BVERF0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.showHome=async function(){
		/*#{1IV1C2VQO0Start*/
		self.showFace("home");
		await self.showSession(null);
		boxHome.animate({
			type:"in",alpha:0,dx:-50,
			OnFinish(){
				edCommand.focus();
			}
		});
		/*}#1IV1C2VQO0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.runCommand=async function(){
		/*#{1IV1C4J0O0Start*/
		let text,assets,frame,thread,args;
		text=edCommand.text;
		if(!text){
			return;
		}
		assets=[];
		{
			let list,i,n,line,url;
			list=boxAssets.children;
			n=list.length;
			for(i=0;i<n;i++){
				line=list[i];
				url=line.assetUrl;
				if(url){
					assets.push(url);
				}
			}
			assets=assets.length?assets:null;
		}
		if(assets){
			args={prompt:text,assets:assets};
		}else{
			args=text;
		}
		if(chatEntryTool){
			thread=await chatClient.newThreadOnHost({args:args,entryTool:chatEntryTool});
		}else{
			thread=await chatClient.newThreadOnHost({args:args});
			if(thread){
				self.showFace("chat");
				self.showChatThread(thread);
			}else{
				//TODO: Code this:
			}
		}
		edCommand.text="";
		txtInputTip.display=true;
		boxAssets.clearChildren();
		return;
		/*}#1IV1C4J0O0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.showSideBar=async function(){
		/*#{1IV1C8L440Start*/
		let tgtx;
		tgtx=self.w*0.8-5;
		boxMainUI.animate({type:"pose",x:tgtx,time:100});
		boxSideBarFrame.display=true;
		boxSideBar.x=-tgtx;
		boxSideBar.animate({type:"pose",x:0,time:100});
		boxMenuNotify.display=false;
		/*}#1IV1C8L440Start*/
	};
	//------------------------------------------------------------------------
	cssVO.closeSideBar=async function(){
		/*#{1IV1C94NR0Start*/
		boxMainUI.x=0;
		boxSideBarFrame.display=false;
		/*}#1IV1C94NR0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.showChatThread=async function(thread){
		/*#{1IV1CA7300Start*/
		let btn;
		btn=thread.sessionBtn;
		if(!btn){
			thread.showOnReady=true;
			return;
		}
		self.showSession(btn);
		/*}#1IV1CA7300Start*/
	};
	//------------------------------------------------------------------------
	cssVO.checkLogin=async function(callback){
		/*#{1IV1DVRFR0Start*/
		let res;
		txtWait.text=(($ln==="CN")?("正在登录AI2Apps账号..."):/*EN*/("Logging into AI2Apps account..."));
		res=await tabNT.makeCall("getKeyPackages",{});
		if(res.code===200){
			if(!(await tabNT.checkLogin(true,true))){
				if(!(await app.modalDlg("/@homekit/ui/DlgLogin.js",{x:app.width/2,y:100,alignH:1}))){
					self.checkLogin(callback);
				}else{
					self.updateTokenGas();
					callback();
				}
			}else{
				self.updateTokenGas();
				callback();
			}
		}else{
			window.alert((($ln==="CN")?("网络错误，请检查您的连接，并重试。"):/*EN*/("Network error, please check your connection and try again.")));	
			self.checkLogin(callback);
		}
		/*}#1IV1DVRFR0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.updateTokenGas=async function(){
		/*#{1IV1IEA6L0Start*/
		let res,userTokens,userGas;
		if(isUpdatingTokenGas){
			return;
		}
		isUpdatingTokenGas=true;
		function numText(num){
			if(num<0){
				return "-";
			}
			num=Math.floor(num);
			if(num>=100){
				return ""+num;
			}
			if(num>=10){
				return "0"+num;
			}
			return "00"+num;
		}
		if(!(await tabNT.checkLogin(false))){
			if(!(await tabNT.maybePreview())){
				userTokens=-1;
				userGas=-1;
				txtToken.text=numText(userTokens);
				txtGas.text=numText(userGas);
				isUpdatingTokenGas=false;
				return;
			}
		}
		try{
			res=await tabNT.makeCall("userCurrency",{});
			if(res.code===200){
				userTokens=res.coins||0;
				userGas=res.points||0;
			}else{
				userTokens=-1;
				userGas=-1;
			}
		}catch(err){
			userTokens=-1;
			userGas=-1;
		}
		txtToken.text=numText(userTokens);
		txtGas.text=numText(userGas);
		isUpdatingTokenGas=false;
		/*}#1IV1IEA6L0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.showWait=async function(text){
		/*#{1IV2L6T140Start*/
		let v;
		txtWait.text=text;
		v=++waitVersion;
		self.showFace("wait");
		return v;
		/*}#1IV2L6T140Start*/
	};
	//------------------------------------------------------------------------
	cssVO.hideWait=async function(version){
		/*#{1IV2L7D180Start*/
		if(!version || version===waitVersion){
			self.showFace("!wait");
		}
		/*}#1IV2L7D180Start*/
	};
	//------------------------------------------------------------------------
	cssVO.showThreads=async function(list){
		/*#{1IV2RNLPH0Start*/
		let thread,btn,n,i;
		n=list.length;
		for(i=n-1;i>=0;i--){
			thread=list[i];
			btn=thread.sessionBtn;
			if(!btn){
				btn=await self.addSession(null,thread.title,thread,false);
				btn.showFace("blur");
			}
			boxChatList.insertBefore(btn,boxChatList.firstChild);
		}
		let btns=boxChatList.children;
		n=btns.length;
		for(i=list.length;i<n;i++){
			btn=btns[i];
			boxChatList.removeChild(btn);
		}
		/*}#1IV2RNLPH0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.addSession=async function(frame,prompt,thread){
		/*#{1IV2S37K90Start*/
		let btn;
		btn=boxChatList.appendNewChild({
			type:BtnChatSession(frame,prompt,thread),position:"relative",
			OnClick(event){
				if(event.button===2){
					self.showThreadMenu(this);
				}else{
					self.showSession(this);
				}
			},
			showMenu(){
				self.showThreadMenu(this);
			}
		});
		if(thread){
			thread.sessionBtn=btn;
		}
		if(frame){
			frame.sessionBtn=btn;
			frame.sessionName=prompt.prompt||prompt;
			chatFrames.push(frame);
			self.showSession(btn);
		}
		return btn;
		/*}#1IV2S37K90Start*/
	};
	//------------------------------------------------------------------------
	cssVO.showSession=async function(btn){
		/*#{1IV2T3P740Start*/
		let orgBtn;
		let frame=null;
		if(btn){
			frame=btn.frame;
		}
		if(hotChatFrame && hotChatFrame!==frame){
			orgBtn=hotChatFrame.sessionBtn;
			//orgBtn.uiEvent=1;
			orgBtn.showFace("blur");
			hotChatFrame.display=false;
			hotChatFrame=null;
		}
		hotChatFrame=frame;
		if(btn){
			//btn.uiEvent=-1;
			btn.showFace("focus");
			if(orgBtn){
				if(frame){
					setTimeout(()=>{
						frame.animate({type:"in",alpha:0,dx:20,time:100});
					},200);
				}else if(btn.chatThread){
					frame=await showChatThread({chatThread:btn.chatThread,embed:boxChats});
					if(frame){
						frame.sessionBtn=btn;
						frame.sessionName=btn.chatThread.title;
						chatFrames.push(frame);
						hotChatFrame=frame;
						frame.display=true;
						btn.frame=frame;
					}
				}
			}else{
				if(frame){
					frame.display=true;
				}else if(btn.chatThread){
					frame=await showChatThread({chatThread:btn.chatThread,embed:boxChats});
					if(frame){
						frame.sessionBtn=btn;
						frame.sessionName=btn.chatThread.title;
						chatFrames.push(frame);
						hotChatFrame=frame;
						frame.display=true;
						btn.frame=frame;
					}
				}
			}
			self.showFace("chat");
			self.closeSideBar();
		}
		/*}#1IV2T3P740Start*/
	};
	//------------------------------------------------------------------------
	cssVO.showThreadMenu=async function(btn){
		/*#{1IV2T41HF0Start*/
		let items,item,frame,chatThread,orgName;
		frame=btn.frame;
		chatThread=btn.chatThread;
		orgName=frame?frame.sessionName:(chatThread?chatThread.title:(($ln==="CN")?("AI 对话"):/*EN*/("AI Chat")));
		items=[
			{text:(($ln==="CN")?("重命名会话"):/*EN*/("Rename session")),code:"Rename"},
			{text:(($ln==="CN")?("归档回话"):/*EN*/("Archive session")),code:"Archive"},
			{text:(($ln==="CN")?("分享回话"):/*EN*/("Share session")),code:"Share",enable:false},
			"_",
			{text:(($ln==="CN")?("删除会话"):/*EN*/("Delete session")),code:"Delete"},
		];
		item=await app.modalDlg("/@StdUI/ui/DlgMenu.js",{hud:btn,items:items});
		if(item){
			if(item.code==="Rename"){
				let name=await app.modalDlg("/@StdUI/ui/DlgPrompt.js",{title:(($ln==="CN")?("输入新会话名称"):/*EN*/("Input new session name")),text:orgName});
				if(name){
					if(chatClient && chatThread){
						chatClient.callServer("RenameThread",{thread:chatThread.id,name:name});
					}
					if(frame){
						frame.sessionName=name;
					}
					btn.setName(name);
				}
			}else if(item.code="Archive"){
				if(frame===hotChatFrame){
					await self.showHome();
				}
				if(chatClient && chatThread){
					chatClient.callServer("ArchiveThread",{thread:chatThread.id});
				}
			}else if(item.code="Delete"){
				if(frame===hotChatFrame){
					await self.showHome();
				}
				if(chatClient && chatThread){
					chatClient.callServer("DeleteThread",{thread:chatThread.id});
				}
				//self.closeSession(btn);
			}
		}
		/*}#1IV2T41HF0Start*/
	};
	/*#{1IV16MNG11PostCSSVO*/
	/*}#1IV16MNG11PostCSSVO*/
	cssVO.constructor=UIShadowApp;
	return cssVO;
};
/*#{1IV16MNG11ExCodes*/
/*}#1IV16MNG11ExCodes*/

//----------------------------------------------------------------------------
UIShadowApp.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1IV16MNG11PreAISpot*/
	/*}#1IV16MNG11PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1IV16MNG11PostAISpot*/
	/*}#1IV16MNG11PostAISpot*/
	return exposeVO;
};

/*#{1IV16MNG10EndDoc*/
/*}#1IV16MNG10EndDoc*/

export default UIShadowApp;
export{UIShadowApp};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "UIView",
//	"jaxId": "1IV16MNG10",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1IV16MNG20",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1IV16MNG21",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1IV16MNG22",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1IV16MNG23",
//			"attrs": {
//				"app": {
//					"type": "auto",
//					"valText": ""
//				},
//				"appFrame": {
//					"type": "auto",
//					"valText": ""
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1IV16MNG24",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1IV16MNG25",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IV1BV5D40",
//					"attrs": {
//						"id": "startClient",
//						"label": "New AI Seg",
//						"x": "75",
//						"y": "70",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IV1C36KO0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IV1C36KO1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IV1C36KO2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IV1BVERF0",
//					"attrs": {
//						"id": "syncChats",
//						"label": "New AI Seg",
//						"x": "325",
//						"y": "70",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IV1C36KO3",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IV1C36KO4",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IV1C36KO5",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IV1C2VQO0",
//					"attrs": {
//						"id": "showHome",
//						"label": "New AI Seg",
//						"x": "75",
//						"y": "155",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IV1C36KO6",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IV1C36KO7",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IV1C36KO8",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IV1C4J0O0",
//					"attrs": {
//						"id": "runCommand",
//						"label": "New AI Seg",
//						"x": "75",
//						"y": "245",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IV1C4P9Q0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IV1C4P9Q1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IV1C4P9Q2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IV1C8L440",
//					"attrs": {
//						"id": "showSideBar",
//						"label": "New AI Seg",
//						"x": "325",
//						"y": "155",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IV1C92O00",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IV1C92O01",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IV1C92O02",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IV1C94NR0",
//					"attrs": {
//						"id": "closeSideBar",
//						"label": "New AI Seg",
//						"x": "560",
//						"y": "155",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IV1CAO7P0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IV1CAO7P1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IV1CAO7P2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IV1CA7300",
//					"attrs": {
//						"id": "showChatThread",
//						"label": "New AI Seg",
//						"x": "325",
//						"y": "245",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IV1CAO7P3",
//							"attrs": {
//								"thread": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IV1CAO7P4",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IV1CAO7P5",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IV1DVRFR0",
//					"attrs": {
//						"id": "checkLogin",
//						"label": "New AI Seg",
//						"x": "75",
//						"y": "345",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IV1E14070",
//							"attrs": {
//								"callback": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IV1E14071",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IV1E14072",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IV1IEA6L0",
//					"attrs": {
//						"id": "updateTokenGas",
//						"label": "New AI Seg",
//						"x": "325",
//						"y": "345",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IV1IEJ660",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IV1IEJ661",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IV1IEJ662",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IV2L6T140",
//					"attrs": {
//						"id": "showWait",
//						"label": "New AI Seg",
//						"x": "560",
//						"y": "70",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IV2L7LS10",
//							"attrs": {
//								"text": {
//									"type": "string",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IV2L7LS11",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IV2L7LS12",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IV2L7D180",
//					"attrs": {
//						"id": "hideWait",
//						"label": "New AI Seg",
//						"x": "795",
//						"y": "70",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IV2L7LS13",
//							"attrs": {
//								"version": {
//									"type": "int",
//									"valText": "0"
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IV2L7LS14",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IV2L7LS15",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IV2RNLPH0",
//					"attrs": {
//						"id": "showThreads",
//						"label": "New AI Seg",
//						"x": "75",
//						"y": "435",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IV2RPC3E0",
//							"attrs": {
//								"list": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IV2RPC3E1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IV2RPC3E2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IV2S37K90",
//					"attrs": {
//						"id": "addSession",
//						"label": "New AI Seg",
//						"x": "325",
//						"y": "435",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IV2S3DQO0",
//							"attrs": {
//								"frame": {
//									"type": "auto",
//									"valText": ""
//								},
//								"prompt": {
//									"type": "auto",
//									"valText": ""
//								},
//								"thread": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IV2S3DQO1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IV2S3DQO2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IV2T3P740",
//					"attrs": {
//						"id": "showSession",
//						"label": "New AI Seg",
//						"x": "75",
//						"y": "535",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IV2T52KH0",
//							"attrs": {
//								"btn": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IV2T52KH1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IV2T52KH2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IV2T41HF0",
//					"attrs": {
//						"id": "showThreadMenu",
//						"label": "New AI Seg",
//						"x": "325",
//						"y": "535",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IV2T52KH3",
//							"attrs": {
//								"btn": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IV2T52KH4",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IV2T52KH5",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				}
//			]
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1IV16MNG26",
//			"attrs": {
//				"start": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IV1F4GGO0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IV1F8HS80",
//							"attrs": {}
//						}
//					}
//				},
//				"ready": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IV1F71C40",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IV1F8HS81",
//							"attrs": {}
//						}
//					}
//				},
//				"home": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IV1BQG4S0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IV1BTJ3F0",
//							"attrs": {}
//						}
//					}
//				},
//				"chat": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IV1D2HS60",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IV1D3CLQ0",
//							"attrs": {}
//						}
//					}
//				},
//				"wait": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IV2LI1OC0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IV2LJJJC0",
//							"attrs": {}
//						}
//					}
//				},
//				"!wait": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IV2LICTI0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IV2LJJJC1",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1IV16MNG27",
//			"attrs": {}
//		},
//		"exposeToAI": "true",
//		"descAI": "",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "view",
//			"jaxId": "1IV16MNG11",
//			"attrs": {
//				"properties": {
//					"jaxId": "1IV16MNG28",
//					"attrs": {
//						"type": "view",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "100%",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": ""
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1IV1EFE300",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IV1EGOTQ0",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxMainUI",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": ""
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1IV16O6PS0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IV16OLID0",
//													"attrs": {
//														"type": "box",
//														"id": "BoxHeader",
//														"position": "Absolute",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "40",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "[0,5,0,5]",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "[255,255,255,1.00]",
//														"border": "[0,0,1,0]",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]",
//														"attach": "true",
//														"contentLayout": "Flex X",
//														"subAlign": "Start",
//														"itemsAlign": "Center"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1IVBLA5DJ0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVBLCU680",
//																	"attrs": {
//																		"type": "hud",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "30",
//																		"h": "30",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "Gear/@StdUI/ui/BtnIcon.js",
//																			"jaxId": "1IV16PTRN0",
//																			"attrs": {
//																				"createArgs": {
//																					"jaxId": "1IV170RUQ0",
//																					"attrs": {
//																						"style": "\"front\"",
//																						"w": "30",
//																						"h": "0",
//																						"icon": "#appCfg.sharedAssets+\"/menu.svg\"",
//																						"colorBG": "null"
//																					}
//																				},
//																				"properties": {
//																					"jaxId": "1IV170RUQ1",
//																					"attrs": {
//																						"type": "#null#>BtnIcon(\"front\",30,0,appCfg.sharedAssets+\"/menu.svg\",null)",
//																						"id": "BtnMenu",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"display": "On",
//																						"face": ""
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1IV170RUQ2",
//																					"attrs": {
//																						"1IV1F4GGO0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IV1F8HS82",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IV1F8HS83",
//																									"attrs": {
//																										"enable": "false"
//																									}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IV1F4GGO0",
//																							"faceTagName": "start"
//																						},
//																						"1IV1F71C40": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IV1F8HS84",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IV1F8HS85",
//																									"attrs": {
//																										"enable": "true"
//																									}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IV1F71C40",
//																							"faceTagName": "ready"
//																						},
//																						"1IV2LI1OC0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IV2LJJJC4",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IV2LJJJC5",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IV2LI1OC0",
//																							"faceTagName": "wait"
//																						},
//																						"1IV1D2HS60": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IV2TBAF80",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IV2TBAF81",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IV1D2HS60",
//																							"faceTagName": "chat"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1IV170RUQ3",
//																					"attrs": {
//																						"OnClick": {
//																							"type": "fixedFunc",
//																							"jaxId": "1IV1EIU8H0",
//																							"attrs": {
//																								"callArgs": {
//																									"jaxId": "1IV1EIU8H1",
//																									"attrs": {
//																										"event": ""
//																									}
//																								},
//																								"seg": "1IV1C8L440"
//																							}
//																						}
//																					}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1IV170RUQ4",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false",
//																				"containerSlots": {
//																					"jaxId": "1IV170RUQ5",
//																					"attrs": {}
//																				}
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "box",
//																			"jaxId": "1IVBLATNU0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVBLCU681",
//																					"attrs": {
//																						"type": "box",
//																						"id": "BoxMenuNotify",
//																						"position": "Absolute",
//																						"x": "100%-8",
//																						"y": "2",
//																						"w": "10",
//																						"h": "10",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "Off",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"background": "#cfgColor[\"error\"]",
//																						"border": "0",
//																						"borderStyle": "Solid",
//																						"borderColor": "[0,0,0,1.00]",
//																						"corner": "10",
//																						"shadow": "false",
//																						"shadowX": "2",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowSpread": "0",
//																						"shadowColor": "[0,0,0,0.50]"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1IVBLCU682",
//																					"attrs": {}
//																				},
//																				"functions": {
//																					"jaxId": "1IVBLCU683",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1IVBLCU684",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "true"
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"jaxId": "1IVBLCU685",
//																	"attrs": {}
//																},
//																"functions": {
//																	"jaxId": "1IVBLCU686",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1IVBLCU687",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false",
//																"exposeContainer": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1IV16V6GC0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IV172KDR0",
//																	"attrs": {
//																		"type": "text",
//																		"id": "TxtTitle",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "[0,0,0,10]",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontBody\"]",
//																		"text": "AI2Apps",
//																		"font": "",
//																		"fontSize": "#txtSize.midPlus",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Top",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"lineClamp": "0",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0",
//																		"flex": "true"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IV172KDR1",
//																	"attrs": {
//																		"1IV2LI1OC0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IV2LJJJC8",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IV2LJJJC9",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IV2LI1OC0",
//																			"faceTagName": "wait"
//																		},
//																		"1IV1D2HS60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IV2TBAF84",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IV2TBAF85",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IV1D2HS60",
//																			"faceTagName": "chat"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1IV172KDR2",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1IV172KDR3",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1IV170TEB0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1IV170TEB1",
//																	"attrs": {
//																		"style": "\"front\"",
//																		"w": "30",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/chat_add.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1IV170TEC0",
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"front\",30,0,appCfg.sharedAssets+\"/chat_add.svg\",null)",
//																		"id": "BtnNewChat",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IV170TEC1",
//																	"attrs": {
//																		"1IV1BQG4S0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IV1BTJ3G0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IV1BTJ3G1",
//																					"attrs": {
//																						"display": "Off"
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IV1BQG4S0",
//																			"faceTagName": "home"
//																		},
//																		"1IV1F4GGO0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IV1F8HS88",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IV1F8HS89",
//																					"attrs": {
//																						"enable": "false",
//																						"display": "Off"
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IV1F4GGO0",
//																			"faceTagName": "start"
//																		},
//																		"1IV2LI1OC0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IV2LJJJC12",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IV2LJJJC13",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IV2LI1OC0",
//																			"faceTagName": "wait"
//																		},
//																		"1IV1D2HS60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IV2TBAF88",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IV2TBAF89",
//																					"attrs": {
//																						"display": "On"
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IV1D2HS60",
//																			"faceTagName": "chat"
//																		},
//																		"1IV1F71C40": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IV3NOVE34",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IV3NOVE35",
//																					"attrs": {
//																						"enable": "true"
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IV1F71C40",
//																			"faceTagName": "ready"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1IV170TEC2",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1IV3NTNQE0",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1IV3NTNQU0",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": "1IV1C2VQO0"
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1IV170TEC3",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1IV170TEC4",
//																	"attrs": {}
//																}
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1IV16OLID1",
//													"attrs": {
//														"1IV2LI1OC0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IV2LJJJC16",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IV2LJJJC17",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IV2LI1OC0",
//															"faceTagName": "wait"
//														},
//														"1IV1D2HS60": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IV2TBAF810",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IV2TBAF811",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IV1D2HS60",
//															"faceTagName": "chat"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IV16OLID2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IV16OLID3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1IV1739RE0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IV17442K0",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxChats",
//														"position": "Absolute",
//														"x": "0",
//														"y": "40",
//														"w": "100%",
//														"h": "100%-40",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": ""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IV17442K1",
//													"attrs": {
//														"1IV2LI1OC0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IV2LJJJC20",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IV2LJJJC21",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IV2LI1OC0",
//															"faceTagName": "wait"
//														},
//														"1IV1D2HS60": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IV2TBAF814",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IV2TBAF815",
//																	"attrs": {
//																		"display": "On"
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IV1D2HS60",
//															"faceTagName": "chat"
//														},
//														"1IV1BQG4S0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IV2TBAF816",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IV2TBAF817",
//																	"attrs": {
//																		"display": "Off"
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IV1BQG4S0",
//															"faceTagName": "home"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IV17442K2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IV17442K3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "true",
//												"container": "true",
//												"nameVal": "true",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1IV19P27I0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IV19Q6BR0",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxHome",
//														"position": "Absolute",
//														"x": "0",
//														"y": "40",
//														"w": "100%",
//														"h": "100%-40",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "[20,0,50,0]",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex Y",
//														"subAlign": "Start",
//														"itemsAlign": "Center"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "box",
//															"jaxId": "1IV19QL640",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IV1A0T630",
//																	"attrs": {
//																		"type": "box",
//																		"id": "BoxAALogo",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100",
//																		"h": "100",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "20",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"background": "#cfgColor[\"fontBody\"]",
//																		"border": "0",
//																		"borderStyle": "Solid",
//																		"borderColor": "[0,0,0,1.00]",
//																		"corner": "0",
//																		"shadow": "false",
//																		"shadowX": "2",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowSpread": "0",
//																		"shadowColor": "[0,0,0,0.50]",
//																		"maskImage": "#appCfg.sharedAssets+\"/aalogo.svg\""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IV1A0T631",
//																	"attrs": {
//																		"1IV1F4GGO0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IV1F8HS814",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IV1F8HS815",
//																					"attrs": {
//																						"alpha": "0.50"
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IV1F4GGO0",
//																			"faceTagName": "start"
//																		},
//																		"1IV1F71C40": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IV1F8HS816",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IV1F8HS817",
//																					"attrs": {
//																						"alpha": "1"
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IV1F71C40",
//																			"faceTagName": "ready"
//																		},
//																		"1IV2LI1OC0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IV2LJJJC24",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IV2LJJJC25",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IV2LI1OC0",
//																			"faceTagName": "wait"
//																		},
//																		"1IV1D2HS60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IV2TBAF818",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IV2TBAF819",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IV1D2HS60",
//																			"faceTagName": "chat"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1IV1A0T632",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1IV1A0T633",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1IV19VC8U0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IV1A0T634",
//																	"attrs": {
//																		"type": "hud",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "100",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"flex": "true"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IV1A0T635",
//																	"attrs": {
//																		"1IV2LI1OC0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IV2LJJJC28",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IV2LJJJC29",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IV2LI1OC0",
//																			"faceTagName": "wait"
//																		},
//																		"1IV1D2HS60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IV2TBAF822",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IV2TBAF823",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IV1D2HS60",
//																			"faceTagName": "chat"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1IV1A0T636",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1IV1A0T637",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false",
//																"exposeContainer": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "box",
//															"jaxId": "1IV19TGAS0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IV19TGAS1",
//																	"attrs": {
//																		"type": "box",
//																		"id": "BoxInput",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "90%",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[20,0,0,0]",
//																		"padding": "[8,10,5,10]",
//																		"minW": "",
//																		"minH": "40",
//																		"maxW": "800",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"background": "#cfgColor[\"chatInputBG\"]",
//																		"border": "1",
//																		"borderStyle": "Solid",
//																		"borderColor": "#cfgColor[\"fontBodyLit\"]",
//																		"corner": "16",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowSpread": "0",
//																		"shadowColor": "[0,0,0,0.20]",
//																		"contentLayout": "Flex Y",
//																		"itemsAlign": "Center",
//																		"subAlign": "Center",
//																		"itemsWrap": "Wrap"
//																	}
//																},
//																"subHuds": {
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "hud",
//																			"jaxId": "1IV19TGAT0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IV19TGAT1",
//																					"attrs": {
//																						"type": "hud",
//																						"id": "BoxInputLine",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "100%",
//																						"h": "",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"contentLayout": "Flex X",
//																						"itemsAlign": "End",
//																						"subAlign": "Center"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": [
//																						{
//																							"type": "hudobj",
//																							"def": "memo",
//																							"jaxId": "1IV19TGAT2",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IV19TGAT3",
//																									"attrs": {
//																										"type": "memo",
//																										"id": "EdCommand",
//																										"position": "relative",
//																										"x": "0",
//																										"y": "0",
//																										"w": "100%-40",
//																										"h": "",
//																										"anchorH": "Left",
//																										"anchorV": "Top",
//																										"autoLayout": "false",
//																										"display": "On",
//																										"uiEvent": "On",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "",
//																										"zIndex": "0",
//																										"margin": "",
//																										"padding": "",
//																										"minW": "",
//																										"minH": "30",
//																										"maxW": "",
//																										"maxH": "200",
//																										"face": "",
//																										"styleClass": "",
//																										"text": "",
//																										"color": "#cfgColor[\"fontBody\"]",
//																										"bgColor": "[255,255,255,0.00]",
//																										"font": "",
//																										"fontSize": "16",
//																										"outline": "0",
//																										"border": "[0,0,1,0]",
//																										"borderStyle": "Solid",
//																										"borderColor": "#cfgColor[\"fontBodyLit\"]",
//																										"corner": "0",
//																										"readOnly": "false",
//																										"selectOnFocus": "true",
//																										"spellCheck": "true"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1IV19TGAT4",
//																									"attrs": {
//																										"1IV2LI1OC0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IV2LJJJC32",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IV2LJJJC33",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IV2LI1OC0",
//																											"faceTagName": "wait"
//																										},
//																										"1IV1D2HS60": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IV2TBAF90",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IV2TBAF91",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IV1D2HS60",
//																											"faceTagName": "chat"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1IV19TGAU10",
//																									"attrs": {
//																										"OnInput": {
//																											"type": "fixedFunc",
//																											"jaxId": "1IV19TGAU11",
//																											"attrs": {
//																												"callArgs": {
//																													"jaxId": "1IV19TGAU12",
//																													"attrs": {}
//																												},
//																												"seg": ""
//																											}
//																										},
//																										"OnKeyDown": {
//																											"type": "fixedFunc",
//																											"jaxId": "1IV19TGAU13",
//																											"attrs": {
//																												"callArgs": {
//																													"jaxId": "1IV19TGAU14",
//																													"attrs": {
//																														"event": ""
//																													}
//																												},
//																												"seg": ""
//																											}
//																										}
//																									}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1IV19TGAU15",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "true"
//																							}
//																						},
//																						{
//																							"type": "hudobj",
//																							"def": "text",
//																							"jaxId": "1IV19TGAU16",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IV19TGAU17",
//																									"attrs": {
//																										"type": "text",
//																										"id": "TxtInputTip",
//																										"position": "Absolute",
//																										"x": "10",
//																										"y": "0",
//																										"w": "",
//																										"h": "100%",
//																										"anchorH": "Left",
//																										"anchorV": "Top",
//																										"autoLayout": "false",
//																										"display": "On",
//																										"clip": "Off",
//																										"uiEvent": "Tree Off",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "",
//																										"zIndex": "0",
//																										"margin": "",
//																										"padding": "",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": "",
//																										"color": "#cfgColor[\"fontBodyLit\"]",
//																										"text": {
//																											"type": "string",
//																											"valText": "Make your command...",
//																											"localize": {
//																												"EN": "Make your command...",
//																												"CN": "给出你的指令..."
//																											},
//																											"localizable": true
//																										},
//																										"font": "",
//																										"fontSize": "16",
//																										"bold": "false",
//																										"italic": "false",
//																										"underline": "false",
//																										"alignH": "Left",
//																										"alignV": "Center",
//																										"wrap": "false",
//																										"ellipsis": "false",
//																										"lineClamp": "0",
//																										"select": "false",
//																										"shadow": "false",
//																										"shadowX": "0",
//																										"shadowY": "2",
//																										"shadowBlur": "3",
//																										"shadowColor": "[0,0,0,1.00]",
//																										"shadowEx": "",
//																										"maxTextW": "0"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1IV19TGAU18",
//																									"attrs": {
//																										"1IV2LI1OC0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IV2LJJJC36",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IV2LJJJC37",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IV2LI1OC0",
//																											"faceTagName": "wait"
//																										},
//																										"1IV1D2HS60": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IV2TBAF94",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IV2TBAF95",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IV1D2HS60",
//																											"faceTagName": "chat"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1IV19TGAV2",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1IV19TGAV3",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "true"
//																							}
//																						},
//																						{
//																							"type": "hudobj",
//																							"def": "Gear/@StdUI/ui/BtnIcon.js",
//																							"jaxId": "1IV19TGAV4",
//																							"attrs": {
//																								"createArgs": {
//																									"jaxId": "1IV19TGAV5",
//																									"attrs": {
//																										"style": "\"front\"",
//																										"w": "30",
//																										"h": "0",
//																										"icon": "#appCfg.sharedAssets+\"/send.svg\"",
//																										"colorBG": "null"
//																									}
//																								},
//																								"properties": {
//																									"jaxId": "1IV19TGAV6",
//																									"attrs": {
//																										"type": "#null#>BtnIcon(\"front\",30,0,appCfg.sharedAssets+\"/send.svg\",null)",
//																										"id": "BtnSendCmd",
//																										"position": "relative",
//																										"x": "0",
//																										"y": "0",
//																										"display": "On",
//																										"face": "",
//																										"padding": "3",
//																										"margin": "[0,0,0,3]",
//																										"enable": "false"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1IV19TGAV7",
//																									"attrs": {
//																										"1IV2LI1OC0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IV2LJJJC40",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IV2LJJJC41",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IV2LI1OC0",
//																											"faceTagName": "wait"
//																										},
//																										"1IV1D2HS60": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IV2TBAF98",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IV2TBAF99",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IV1D2HS60",
//																											"faceTagName": "chat"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1IV19TGAV18",
//																									"attrs": {
//																										"OnClick": {
//																											"type": "fixedFunc",
//																											"jaxId": "1IV19TGAV19",
//																											"attrs": {
//																												"callArgs": {
//																													"jaxId": "1IV19TGAV20",
//																													"attrs": {
//																														"event": ""
//																													}
//																												},
//																												"seg": "1IV1C4J0O0"
//																											}
//																										}
//																									}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1IV19TGAV21",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "true",
//																								"containerSlots": {
//																									"jaxId": "1IV19TGAV22",
//																									"attrs": {}
//																								}
//																							}
//																						}
//																					]
//																				},
//																				"faces": {
//																					"jaxId": "1IV19TGAV23",
//																					"attrs": {
//																						"1IV2LI1OC0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IV2LJJJC44",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IV2LJJJC45",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IV2LI1OC0",
//																							"faceTagName": "wait"
//																						},
//																						"1IV1D2HS60": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IV2TBAF912",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IV2TBAF913",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IV1D2HS60",
//																							"faceTagName": "chat"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1IV19TGAV34",
//																					"attrs": {
//																						"OnClick": {
//																							"type": "fixedFunc",
//																							"jaxId": "1IV19TGAV35",
//																							"attrs": {
//																								"callArgs": {
//																									"jaxId": "1IV19TGAV36",
//																									"attrs": {
//																										"event": ""
//																									}
//																								},
//																								"seg": ""
//																							}
//																						}
//																					}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1IV19TGAV37",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "false",
//																				"exposeContainer": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "hud",
//																			"jaxId": "1IV19TGB00",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IV19TGB01",
//																					"attrs": {
//																						"type": "hud",
//																						"id": "BoxAssets",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "100%-60",
//																						"h": "",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "0",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"contentLayout": "Flex Y"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1IV19TGB02",
//																					"attrs": {
//																						"1IV2LI1OC0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IV2LJJJC48",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IV2LJJJC49",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IV2LI1OC0",
//																							"faceTagName": "wait"
//																						},
//																						"1IV1D2HS60": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IV2TBAF916",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IV2TBAF917",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IV1D2HS60",
//																							"faceTagName": "chat"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1IV19TGB013",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1IV19TGB014",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "true",
//																				"exposeContainer": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "hud",
//																			"jaxId": "1IV19TGB015",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IV19TGB016",
//																					"attrs": {
//																						"type": "hud",
//																						"id": "BoxToolBtns",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "100%",
//																						"h": "",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "[10,0,0,0]",
//																						"padding": "[0,5,5,5]",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"contentLayout": "Flex X",
//																						"itemsWrap": "Wrap",
//																						"itemsAlign": "Center",
//																						"subAlign": "Start"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": [
//																						{
//																							"type": "hudobj",
//																							"def": "Gear/@StdUI/ui/BtnIcon.js",
//																							"jaxId": "1IV19TGB017",
//																							"attrs": {
//																								"createArgs": {
//																									"jaxId": "1IV19TGB018",
//																									"attrs": {
//																										"style": "\"front\"",
//																										"w": "24",
//																										"h": "0",
//																										"icon": "#appCfg.sharedAssets+\"/asset.svg\"",
//																										"colorBG": "null"
//																									}
//																								},
//																								"properties": {
//																									"jaxId": "1IV19TGB019",
//																									"attrs": {
//																										"type": "#null#>BtnIcon(\"front\",24,0,appCfg.sharedAssets+\"/asset.svg\",null)",
//																										"id": "BtnAddAssets",
//																										"position": "relative",
//																										"x": "0",
//																										"y": "0",
//																										"display": "On",
//																										"face": "",
//																										"margin": "[0,5,0,5]"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1IV19TGB10",
//																									"attrs": {
//																										"1IV2LI1OC0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IV2LJJJC52",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IV2LJJJC53",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IV2LI1OC0",
//																											"faceTagName": "wait"
//																										},
//																										"1IV1D2HS60": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IV2TBAF920",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IV2TBAF921",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IV1D2HS60",
//																											"faceTagName": "chat"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1IV19TGB111",
//																									"attrs": {
//																										"OnClick": {
//																											"type": "fixedFunc",
//																											"jaxId": "1IV19TGB112",
//																											"attrs": {
//																												"callArgs": {
//																													"jaxId": "1IV19TGB113",
//																													"attrs": {
//																														"event": ""
//																													}
//																												},
//																												"seg": "1ILIGIPH20"
//																											}
//																										}
//																									}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1IV19TGB114",
//																									"attrs": {
//																										"tip": {
//																											"type": "string",
//																											"valText": "Add assets",
//																											"localize": {
//																												"EN": "Add assets",
//																												"CN": "附加内容"
//																											},
//																											"localizable": true
//																										}
//																									}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "false",
//																								"containerSlots": {
//																									"jaxId": "1IV19TGB115",
//																									"attrs": {}
//																								}
//																							}
//																						},
//																						{
//																							"type": "hudobj",
//																							"def": "hud",
//																							"jaxId": "1IV19TGB116",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IV19TGB117",
//																									"attrs": {
//																										"type": "hud",
//																										"id": "SegChatEntry",
//																										"position": "relative",
//																										"x": "0",
//																										"y": "0",
//																										"w": "",
//																										"h": "100%",
//																										"anchorH": "Left",
//																										"anchorV": "Top",
//																										"autoLayout": "false",
//																										"display": "On",
//																										"clip": "Off",
//																										"uiEvent": "On",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "pointer",
//																										"zIndex": "0",
//																										"margin": "[0,5,0,5]",
//																										"padding": "",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": "",
//																										"contentLayout": "Flex X",
//																										"itemsAlign": "Center"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": [
//																										{
//																											"type": "hudobj",
//																											"def": "box",
//																											"jaxId": "1IV19TGB118",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IV19TGB119",
//																													"attrs": {
//																														"type": "box",
//																														"id": "BoxChatEntryBG",
//																														"position": "Absolute",
//																														"x": "-2",
//																														"y": "-2",
//																														"w": "100%+4",
//																														"h": "100%+4",
//																														"anchorH": "Left",
//																														"anchorV": "Top",
//																														"autoLayout": "false",
//																														"display": "Off",
//																														"clip": "Off",
//																														"uiEvent": "Tree Off",
//																														"alpha": "1",
//																														"rotate": "0",
//																														"scale": "",
//																														"filter": "",
//																														"cursor": "",
//																														"zIndex": "0",
//																														"margin": "",
//																														"padding": "",
//																														"minW": "",
//																														"minH": "",
//																														"maxW": "",
//																														"maxH": "",
//																														"face": "",
//																														"styleClass": "",
//																														"background": "#cfgColor[\"hot\"]",
//																														"border": "1",
//																														"borderStyle": "Solid",
//																														"borderColor": "#cfgColor[\"fontBodySub\"]",
//																														"corner": "6",
//																														"shadow": "false",
//																														"shadowX": "2",
//																														"shadowY": "2",
//																														"shadowBlur": "3",
//																														"shadowSpread": "0",
//																														"shadowColor": "[0,0,0,0.50]"
//																													}
//																												},
//																												"subHuds": {
//																													"attrs": []
//																												},
//																												"faces": {
//																													"jaxId": "1IV19TGB120",
//																													"attrs": {
//																														"1IV2LI1OC0": {
//																															"type": "hudface",
//																															"def": "HudFace",
//																															"jaxId": "1IV2LJJJC56",
//																															"attrs": {
//																																"properties": {
//																																	"jaxId": "1IV2LJJJC57",
//																																	"attrs": {}
//																																},
//																																"anis": {
//																																	"attrs": []
//																																}
//																															},
//																															"faceTagId": "1IV2LI1OC0",
//																															"faceTagName": "wait"
//																														},
//																														"1IV1D2HS60": {
//																															"type": "hudface",
//																															"def": "HudFace",
//																															"jaxId": "1IV2TBAF924",
//																															"attrs": {
//																																"properties": {
//																																	"jaxId": "1IV2TBAF925",
//																																	"attrs": {}
//																																},
//																																"anis": {
//																																	"attrs": []
//																																}
//																															},
//																															"faceTagId": "1IV1D2HS60",
//																															"faceTagName": "chat"
//																														}
//																													}
//																												},
//																												"functions": {
//																													"jaxId": "1IV19TGB210",
//																													"attrs": {}
//																												},
//																												"extraPpts": {
//																													"jaxId": "1IV19TGB211",
//																													"attrs": {}
//																												},
//																												"mockup": "false",
//																												"codes": "false",
//																												"locked": "false",
//																												"container": "true",
//																												"nameVal": "false"
//																											}
//																										},
//																										{
//																											"type": "hudobj",
//																											"def": "Gear/@StdUI/ui/BtnIcon.js",
//																											"jaxId": "1IV19TGB212",
//																											"attrs": {
//																												"createArgs": {
//																													"jaxId": "1IV19TGB213",
//																													"attrs": {
//																														"style": "\"front\"",
//																														"w": "24",
//																														"h": "0",
//																														"icon": "#appCfg.sharedAssets+\"/appdata.svg\"",
//																														"colorBG": "null"
//																													}
//																												},
//																												"properties": {
//																													"jaxId": "1IV19TGB214",
//																													"attrs": {
//																														"type": "#null#>BtnIcon(\"front\",24,0,appCfg.sharedAssets+\"/appdata.svg\",null)",
//																														"id": "BtnChatEntry",
//																														"position": "relative",
//																														"x": "0",
//																														"y": "0",
//																														"display": "On",
//																														"face": "",
//																														"margin": "0",
//																														"enable": "true"
//																													}
//																												},
//																												"subHuds": {
//																													"attrs": []
//																												},
//																												"faces": {
//																													"jaxId": "1IV19TGB215",
//																													"attrs": {
//																														"1IV2LI1OC0": {
//																															"type": "hudface",
//																															"def": "HudFace",
//																															"jaxId": "1IV2LJJJC60",
//																															"attrs": {
//																																"properties": {
//																																	"jaxId": "1IV2LJJJC61",
//																																	"attrs": {}
//																																},
//																																"anis": {
//																																	"attrs": []
//																																}
//																															},
//																															"faceTagId": "1IV2LI1OC0",
//																															"faceTagName": "wait"
//																														},
//																														"1IV1D2HS60": {
//																															"type": "hudface",
//																															"def": "HudFace",
//																															"jaxId": "1IV2TBAF928",
//																															"attrs": {
//																																"properties": {
//																																	"jaxId": "1IV2TBAF929",
//																																	"attrs": {}
//																																},
//																																"anis": {
//																																	"attrs": []
//																																}
//																															},
//																															"faceTagId": "1IV1D2HS60",
//																															"faceTagName": "chat"
//																														}
//																													}
//																												},
//																												"functions": {
//																													"jaxId": "1IV19TGB226",
//																													"attrs": {
//																														"OnClick": {
//																															"type": "fixedFunc",
//																															"jaxId": "1IV19TGB30",
//																															"attrs": {
//																																"callArgs": {
//																																	"jaxId": "1IV19TGB31",
//																																	"attrs": {
//																																		"event": ""
//																																	}
//																																},
//																																"seg": "1IMR949GQ0"
//																															}
//																														}
//																													}
//																												},
//																												"extraPpts": {
//																													"jaxId": "1IV19TGB32",
//																													"attrs": {
//																														"tip": {
//																															"type": "string",
//																															"valText": "Choose chat AI Agent",
//																															"localize": {
//																																"EN": "Choose chat AI Agent",
//																																"CN": "选择对话智能体"
//																															},
//																															"localizable": true
//																														}
//																													}
//																												},
//																												"mockup": "false",
//																												"codes": "false",
//																												"locked": "false",
//																												"container": "false",
//																												"nameVal": "true",
//																												"containerSlots": {
//																													"jaxId": "1IV19TGB33",
//																													"attrs": {}
//																												}
//																											}
//																										},
//																										{
//																											"type": "hudobj",
//																											"def": "text",
//																											"jaxId": "1IV19TGB34",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IV19TGB35",
//																													"attrs": {
//																														"type": "text",
//																														"id": "TxtChatEntry",
//																														"position": "relative",
//																														"x": "0",
//																														"y": "0",
//																														"w": "",
//																														"h": "",
//																														"anchorH": "Left",
//																														"anchorV": "Top",
//																														"autoLayout": "false",
//																														"display": "Off",
//																														"clip": "Off",
//																														"uiEvent": "Tree Off",
//																														"alpha": "1",
//																														"rotate": "0",
//																														"scale": "",
//																														"filter": "",
//																														"cursor": "",
//																														"zIndex": "0",
//																														"margin": "[0,3,0,3]",
//																														"padding": "",
//																														"minW": "",
//																														"minH": "",
//																														"maxW": "",
//																														"maxH": "",
//																														"face": "",
//																														"styleClass": "",
//																														"color": "#cfgColor[\"fontBody\"]",
//																														"text": "Web Search",
//																														"font": "",
//																														"fontSize": "#txtSize.small",
//																														"bold": "false",
//																														"italic": "false",
//																														"underline": "false",
//																														"alignH": "Left",
//																														"alignV": "Top",
//																														"wrap": "false",
//																														"ellipsis": "false",
//																														"lineClamp": "0",
//																														"select": "false",
//																														"shadow": "false",
//																														"shadowX": "0",
//																														"shadowY": "2",
//																														"shadowBlur": "3",
//																														"shadowColor": "[0,0,0,1.00]",
//																														"shadowEx": "",
//																														"maxTextW": "0"
//																													}
//																												},
//																												"subHuds": {
//																													"attrs": []
//																												},
//																												"faces": {
//																													"jaxId": "1IV19TGB36",
//																													"attrs": {
//																														"1IV2LI1OC0": {
//																															"type": "hudface",
//																															"def": "HudFace",
//																															"jaxId": "1IV2LJJJC64",
//																															"attrs": {
//																																"properties": {
//																																	"jaxId": "1IV2LJJJC65",
//																																	"attrs": {}
//																																},
//																																"anis": {
//																																	"attrs": []
//																																}
//																															},
//																															"faceTagId": "1IV2LI1OC0",
//																															"faceTagName": "wait"
//																														},
//																														"1IV1D2HS60": {
//																															"type": "hudface",
//																															"def": "HudFace",
//																															"jaxId": "1IV2TBAF932",
//																															"attrs": {
//																																"properties": {
//																																	"jaxId": "1IV2TBAF933",
//																																	"attrs": {}
//																																},
//																																"anis": {
//																																	"attrs": []
//																																}
//																															},
//																															"faceTagId": "1IV1D2HS60",
//																															"faceTagName": "chat"
//																														}
//																													}
//																												},
//																												"functions": {
//																													"jaxId": "1IV19TGB317",
//																													"attrs": {}
//																												},
//																												"extraPpts": {
//																													"jaxId": "1IV19TGB318",
//																													"attrs": {}
//																												},
//																												"mockup": "false",
//																												"codes": "false",
//																												"locked": "false",
//																												"container": "false",
//																												"nameVal": "true"
//																											}
//																										}
//																									]
//																								},
//																								"faces": {
//																									"jaxId": "1IV19TGB319",
//																									"attrs": {
//																										"1IV2LI1OC0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IV2LJJJC68",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IV2LJJJC69",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IV2LI1OC0",
//																											"faceTagName": "wait"
//																										},
//																										"1IV1D2HS60": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IV2TBAF936",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IV2TBAF937",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IV1D2HS60",
//																											"faceTagName": "chat"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1IV19TGB330",
//																									"attrs": {
//																										"OnClick": {
//																											"type": "fixedFunc",
//																											"jaxId": "1IV19TGB331",
//																											"attrs": {
//																												"callArgs": {
//																													"jaxId": "1IV19TGB332",
//																													"attrs": {
//																														"event": ""
//																													}
//																												},
//																												"seg": "1IMR949GQ0"
//																											}
//																										}
//																									}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1IV19TGB333",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "true",
//																								"nameVal": "false",
//																								"exposeContainer": "false"
//																							}
//																						},
//																						{
//																							"type": "hudobj",
//																							"def": "box",
//																							"jaxId": "1IV19TGB334",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IV19TGB335",
//																									"attrs": {
//																										"type": "box",
//																										"id": "",
//																										"position": "relative",
//																										"x": "0",
//																										"y": "0",
//																										"w": "1",
//																										"h": "16",
//																										"anchorH": "Left",
//																										"anchorV": "Top",
//																										"autoLayout": "false",
//																										"display": "Off",
//																										"clip": "Off",
//																										"uiEvent": "On",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "",
//																										"zIndex": "0",
//																										"margin": "[0,0,0,5]",
//																										"padding": "",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": "",
//																										"background": "#cfgColor[\"fontBodyLit\"]",
//																										"border": "0",
//																										"borderStyle": "Solid",
//																										"borderColor": "[0,0,0,1.00]",
//																										"corner": "0",
//																										"shadow": "false",
//																										"shadowX": "2",
//																										"shadowY": "2",
//																										"shadowBlur": "3",
//																										"shadowSpread": "0",
//																										"shadowColor": "[0,0,0,0.50]"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1IV19TGB40",
//																									"attrs": {
//																										"1IV2LI1OC0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IV2LJJJC72",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IV2LJJJC73",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IV2LI1OC0",
//																											"faceTagName": "wait"
//																										},
//																										"1IV1D2HS60": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IV2TBAF940",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IV2TBAF941",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IV1D2HS60",
//																											"faceTagName": "chat"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1IV19TGB411",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1IV19TGB412",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "true",
//																								"nameVal": "false"
//																							}
//																						},
//																						{
//																							"type": "hudobj",
//																							"def": "hud",
//																							"jaxId": "1IV19TGB513",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IV19TGB514",
//																									"attrs": {
//																										"type": "hud",
//																										"id": "",
//																										"position": "relative",
//																										"x": "0",
//																										"y": "0",
//																										"w": "1",
//																										"h": "100%",
//																										"anchorH": "Left",
//																										"anchorV": "Top",
//																										"autoLayout": "false",
//																										"display": "On",
//																										"clip": "Off",
//																										"uiEvent": "On",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "",
//																										"zIndex": "0",
//																										"margin": "",
//																										"padding": "",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": "",
//																										"flex": "true"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1IV19TGB515",
//																									"attrs": {
//																										"1IV2LI1OC0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IV2LJJJC76",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IV2LJJJC77",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IV2LI1OC0",
//																											"faceTagName": "wait"
//																										},
//																										"1IV1D2HS60": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IV2TBAF944",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IV2TBAF945",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IV1D2HS60",
//																											"faceTagName": "chat"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1IV19TGB526",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1IV19TGB527",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "true",
//																								"nameVal": "false",
//																								"exposeContainer": "false"
//																							}
//																						},
//																						{
//																							"type": "hudobj",
//																							"def": "Gear/@StdUI/ui/BtnIcon.js",
//																							"jaxId": "1IV1BU1L90",
//																							"attrs": {
//																								"createArgs": {
//																									"jaxId": "1IV1BUSM20",
//																									"attrs": {
//																										"style": "\"front\"",
//																										"w": "24",
//																										"h": "0",
//																										"icon": "#appCfg.sharedAssets+\"/menu.svg\"",
//																										"colorBG": "null"
//																									}
//																								},
//																								"properties": {
//																									"jaxId": "1IV1BUSM21",
//																									"attrs": {
//																										"type": "#null#>BtnIcon(\"front\",24,0,appCfg.sharedAssets+\"/menu.svg\",null)",
//																										"id": "",
//																										"position": "relative",
//																										"x": "0",
//																										"y": "0",
//																										"display": "On",
//																										"face": ""
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1IV1BUSM22",
//																									"attrs": {
//																										"1IV2LI1OC0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IV2LJJJC80",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IV2LJJJC81",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IV2LI1OC0",
//																											"faceTagName": "wait"
//																										},
//																										"1IV1D2HS60": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IV2TBAF948",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IV2TBAF949",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IV1D2HS60",
//																											"faceTagName": "chat"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1IV1BUSM23",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1IV1BUSM24",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "false",
//																								"containerSlots": {
//																									"jaxId": "1IV1BUSM25",
//																									"attrs": {}
//																								}
//																							}
//																						}
//																					]
//																				},
//																				"faces": {
//																					"jaxId": "1IV19TGB547",
//																					"attrs": {
//																						"1IV2LI1OC0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IV2LJJJC84",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IV2LJJJC85",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IV2LI1OC0",
//																							"faceTagName": "wait"
//																						},
//																						"1IV1D2HS60": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IV2TBAF952",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IV2TBAF953",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IV1D2HS60",
//																							"faceTagName": "chat"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1IV19TGB610",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1IV19TGB611",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "false",
//																				"exposeContainer": "false"
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"jaxId": "1IV19TGB612",
//																	"attrs": {
//																		"1IV1F4GGO0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IV1F8HS848",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IV1F8HS849",
//																					"attrs": {
//																						"display": "Off"
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IV1F4GGO0",
//																			"faceTagName": "start"
//																		},
//																		"1IV1F71C40": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IV1F8HS850",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IV1F8HS851",
//																					"attrs": {
//																						"display": "On"
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IV1F71C40",
//																			"faceTagName": "ready"
//																		},
//																		"1IV2LI1OC0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IV2LJJJD2",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IV2LJJJD3",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IV2LI1OC0",
//																			"faceTagName": "wait"
//																		},
//																		"1IV1D2HS60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IV2TBAF956",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IV2TBAF957",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IV1D2HS60",
//																			"faceTagName": "chat"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1IV19TGB623",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1IV19TGB624",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false"
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1IV19Q6BR1",
//													"attrs": {
//														"1IV2LI1OC0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IV2LJJJD6",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IV2LJJJD7",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IV2LI1OC0",
//															"faceTagName": "wait"
//														},
//														"1IV1D2HS60": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IV2TBAF960",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IV2TBAF961",
//																	"attrs": {
//																		"display": "Off"
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IV1D2HS60",
//															"faceTagName": "chat"
//														},
//														"1IV1BQG4S0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IV2TBAF962",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IV2TBAF963",
//																	"attrs": {
//																		"display": "On"
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IV1BQG4S0",
//															"faceTagName": "home"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IV19Q6BR2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IV19Q6BR3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "true",
//												"exposeContainer": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1IV1EGOTQ1",
//									"attrs": {
//										"1IV1F4GGO0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IV1F8HS854",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IV1F8HS855",
//													"attrs": {
//														"display": "Off"
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IV1F4GGO0",
//											"faceTagName": "start"
//										},
//										"1IV1F71C40": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IV1F8HS856",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IV1F8HS857",
//													"attrs": {
//														"display": "On"
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IV1F71C40",
//											"faceTagName": "ready"
//										},
//										"1IV2LI1OC0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IV2LJJJD10",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IV2LJJJD11",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IV2LI1OC0",
//											"faceTagName": "wait"
//										},
//										"1IV1D2HS60": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IV2TBAF964",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IV2TBAF965",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IV1D2HS60",
//											"faceTagName": "chat"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1IV1EGOTQ2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IV1EGOTQ3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "true",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1IV1848C50",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IV188PLC0",
//									"attrs": {
//										"type": "box",
//										"id": "BoxSideBarFrame",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#[cfgColor[\"fontBodyLit\"][0],cfgColor[\"fontBodyLit\"][1],cfgColor[\"fontBodyLit\"][2],0.5]",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1IV1896KM0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IV18ARDG0",
//													"attrs": {
//														"type": "box",
//														"id": "BoxSideBar",
//														"position": "Absolute",
//														"x": "0",
//														"y": "0",
//														"w": "80%",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "10",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "[255,255,255,1.00]",
//														"border": "[0,1,0,0]",
//														"borderStyle": "Solid",
//														"borderColor": "#cfgColor[\"fontBodyLit\"]",
//														"corner": "0",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]",
//														"contentLayout": "Flex Y",
//														"subAlign": "Start",
//														"itemsAlign": "Center"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1IV18OGH00",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IV18PB0C0",
//																	"attrs": {
//																		"type": "hud",
//																		"id": "BoxSideBarHeader",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "30",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[0,0,10,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"contentLayout": "Flex X",
//																		"itemsAlign": "Center"
//																	}
//																},
//																"subHuds": {
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "Gear/@StdUI/ui/BtnIcon.js",
//																			"jaxId": "1IV18Q9F30",
//																			"attrs": {
//																				"createArgs": {
//																					"jaxId": "1IV18TKJ00",
//																					"attrs": {
//																						"style": "\"front\"",
//																						"w": "24",
//																						"h": "0",
//																						"icon": "#appCfg.sharedAssets+\"/token.svg\"",
//																						"colorBG": "null"
//																					}
//																				},
//																				"properties": {
//																					"jaxId": "1IV18TKJ01",
//																					"attrs": {
//																						"type": "#null#>BtnIcon(\"front\",24,0,appCfg.sharedAssets+\"/token.svg\",null)",
//																						"id": "BtnToken",
//																						"position": "Relative",
//																						"x": "1",
//																						"y": "0",
//																						"display": "On",
//																						"face": "",
//																						"padding": "2"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1IV18TKJ02",
//																					"attrs": {
//																						"1IV2LI1OC0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IV2LJJJD14",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IV2LJJJD15",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IV2LI1OC0",
//																							"faceTagName": "wait"
//																						},
//																						"1IV1D2HS60": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IV2TBAF968",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IV2TBAF969",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IV1D2HS60",
//																							"faceTagName": "chat"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1IV18TKJ03",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1IV18TKJ04",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false",
//																				"containerSlots": {
//																					"jaxId": "1IV18TKJ05",
//																					"attrs": {}
//																				}
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "text",
//																			"jaxId": "1IV18SP7N0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IV18TUEF0",
//																					"attrs": {
//																						"type": "text",
//																						"id": "TxtToken",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "",
//																						"h": "",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "20",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"color": "[0,0,0]",
//																						"text": "-",
//																						"font": "",
//																						"fontSize": "16",
//																						"bold": "false",
//																						"italic": "false",
//																						"underline": "false",
//																						"alignH": "Left",
//																						"alignV": "Top",
//																						"wrap": "false",
//																						"ellipsis": "false",
//																						"lineClamp": "0",
//																						"select": "false",
//																						"shadow": "false",
//																						"shadowX": "0",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowColor": "[0,0,0,1.00]",
//																						"shadowEx": "",
//																						"maxTextW": "0"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1IV18TUEF1",
//																					"attrs": {
//																						"1IV2LI1OC0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IV2LJJJD18",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IV2LJJJD19",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IV2LI1OC0",
//																							"faceTagName": "wait"
//																						},
//																						"1IV1D2HS60": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IV2TBAF972",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IV2TBAF973",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IV1D2HS60",
//																							"faceTagName": "chat"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1IV18TUEF2",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1IV18TUEF3",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "true"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "Gear/@StdUI/ui/BtnIcon.js",
//																			"jaxId": "1IV18TL8V0",
//																			"attrs": {
//																				"createArgs": {
//																					"jaxId": "1IV18TL8V1",
//																					"attrs": {
//																						"style": "\"front\"",
//																						"w": "24",
//																						"h": "0",
//																						"icon": "#appCfg.sharedAssets+\"/gas.svg\"",
//																						"colorBG": "null"
//																					}
//																				},
//																				"properties": {
//																					"jaxId": "1IV18TL8V2",
//																					"attrs": {
//																						"type": "#null#>BtnIcon(\"front\",24,0,appCfg.sharedAssets+\"/gas.svg\",null)",
//																						"id": "BtnToken",
//																						"position": "Relative",
//																						"x": "1",
//																						"y": "0",
//																						"display": "On",
//																						"face": "",
//																						"padding": "2"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1IV18TL8V3",
//																					"attrs": {
//																						"1IV2LI1OC0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IV2LJJJD22",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IV2LJJJD23",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IV2LI1OC0",
//																							"faceTagName": "wait"
//																						},
//																						"1IV1D2HS60": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IV2TBAF976",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IV2TBAF977",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IV1D2HS60",
//																							"faceTagName": "chat"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1IV18TL8V4",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1IV18TL8V5",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false",
//																				"containerSlots": {
//																					"jaxId": "1IV18TL8V6",
//																					"attrs": {}
//																				}
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "text",
//																			"jaxId": "1IV18TV7Q0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IV18TV7Q1",
//																					"attrs": {
//																						"type": "text",
//																						"id": "TxtGas",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "",
//																						"h": "",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "20",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"color": "[0,0,0]",
//																						"text": "-",
//																						"font": "",
//																						"fontSize": "16",
//																						"bold": "false",
//																						"italic": "false",
//																						"underline": "false",
//																						"alignH": "Left",
//																						"alignV": "Top",
//																						"wrap": "false",
//																						"ellipsis": "false",
//																						"lineClamp": "0",
//																						"select": "false",
//																						"shadow": "false",
//																						"shadowX": "0",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowColor": "[0,0,0,1.00]",
//																						"shadowEx": "",
//																						"maxTextW": "0"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1IV18TV7R0",
//																					"attrs": {
//																						"1IV2LI1OC0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IV2LJJJD26",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IV2LJJJD27",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IV2LI1OC0",
//																							"faceTagName": "wait"
//																						},
//																						"1IV1D2HS60": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IV2TBAF980",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IV2TBAF981",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IV1D2HS60",
//																							"faceTagName": "chat"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1IV18TV7R1",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1IV18TV7R2",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "true"
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"jaxId": "1IV18PB0C1",
//																	"attrs": {
//																		"1IV2LI1OC0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IV2LJJJD30",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IV2LJJJD31",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IV2LI1OC0",
//																			"faceTagName": "wait"
//																		},
//																		"1IV1D2HS60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IV2TBAF984",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IV2TBAF985",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IV1D2HS60",
//																			"faceTagName": "chat"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1IV18PB0C2",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1IV18PB0C3",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false",
//																"exposeContainer": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1IV50K5S90",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IV50OAEF0",
//																	"attrs": {
//																		"type": "text",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontBodySub\"]",
//																		"text": {
//																			"type": "string",
//																			"valText": "Agent conversations:",
//																			"localize": {
//																				"EN": "Agent conversations:",
//																				"CN": "与智能体的对话:"
//																			},
//																			"localizable": true
//																		},
//																		"font": "",
//																		"fontSize": "#txtSize.smallPlus",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Top",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"lineClamp": "0",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IV50OAEG0",
//																	"attrs": {}
//																},
//																"functions": {
//																	"jaxId": "1IV50OAEG1",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1IV50OAEG2",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "box",
//															"jaxId": "1IV192N0G0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IV193RCL0",
//																	"attrs": {
//																		"type": "box",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "1",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[3,0,0,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"background": "#cfgColor[\"fontBodyLit\"]",
//																		"border": "0",
//																		"borderStyle": "Solid",
//																		"borderColor": "[0,0,0,1.00]",
//																		"corner": "0",
//																		"shadow": "false",
//																		"shadowX": "2",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowSpread": "0",
//																		"shadowColor": "[0,0,0,0.50]"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IV193RCL1",
//																	"attrs": {
//																		"1IV2LI1OC0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IV2LJJJD42",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IV2LJJJD43",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IV2LI1OC0",
//																			"faceTagName": "wait"
//																		},
//																		"1IV1D2HS60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IV2TBAF996",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IV2TBAF997",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IV1D2HS60",
//																			"faceTagName": "chat"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1IV193RCL2",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1IV193RCL3",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1IV1915JK0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IV193RCL4",
//																	"attrs": {
//																		"type": "hud",
//																		"id": "BoxChatList",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "100",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Auto Scroll Y",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "0",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"flex": "true",
//																		"contentLayout": "Flex Y",
//																		"subAlign": "Start"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IV193RCL5",
//																	"attrs": {
//																		"1IV2LI1OC0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IV2LJJJD46",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IV2LJJJD47",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IV2LI1OC0",
//																			"faceTagName": "wait"
//																		},
//																		"1IV1D2HS60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IV2TBAF9100",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IV2TBAF9101",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IV1D2HS60",
//																			"faceTagName": "chat"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1IV193RCL6",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1IV193RCL7",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "true",
//																"exposeContainer": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear1I1UT4SUC0",
//															"jaxId": "1IV18IRCP0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1IV18KT680",
//																	"attrs": {
//																		"icon": "folder.svg",
//																		"text": "#null",
//																		"tip": {
//																			"type": "string",
//																			"valText": "Archived",
//																			"localize": {
//																				"EN": "Archived",
//																				"CN": "已归档对话"
//																			},
//																			"localizable": true
//																		},
//																		"tipSize": "16",
//																		"tipIcon": "run.svg"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1IV18KT681",
//																	"attrs": {
//																		"type": "#null#>BtnState(\"folder.svg\",null,(($ln===\"CN\")?(\"已归档对话\"):(\"Archived\")),16,\"run.svg\")",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"enable": "false"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IV18KT682",
//																	"attrs": {
//																		"1IV2LI1OC0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IV2LJJJD34",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IV2LJJJD35",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IV2LI1OC0",
//																			"faceTagName": "wait"
//																		},
//																		"1IV1D2HS60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IV2TBAF988",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IV2TBAF989",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IV1D2HS60",
//																			"faceTagName": "chat"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1IV18KT683",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1IV18KT684",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1IV18KT685",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear1I1UT4SUC0",
//															"jaxId": "1IV18LFE00",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1IV18LFE01",
//																	"attrs": {
//																		"icon": "store.svg",
//																		"text": "#null",
//																		"tip": {
//																			"type": "string",
//																			"valText": "Agent Mart",
//																			"localize": {
//																				"EN": "Agent Mart",
//																				"CN": "智能体市场"
//																			},
//																			"localizable": true
//																		},
//																		"tipSize": "16",
//																		"tipIcon": "run.svg"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1IV18LFE02",
//																	"attrs": {
//																		"type": "#null#>BtnState(\"store.svg\",null,(($ln===\"CN\")?(\"智能体市场\"):(\"Agent Mart\")),16,\"run.svg\")",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"enable": "false"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IV18LFE03",
//																	"attrs": {
//																		"1IV2LI1OC0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IV2LJJJD38",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IV2LJJJD39",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IV2LI1OC0",
//																			"faceTagName": "wait"
//																		},
//																		"1IV1D2HS60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IV2TBAF992",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IV2TBAF993",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IV1D2HS60",
//																			"faceTagName": "chat"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1IV18LFE04",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1IV18LFE05",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1IV18LFE06",
//																	"attrs": {}
//																}
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1IV18ARDG1",
//													"attrs": {
//														"1IV2LI1OC0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IV2LJJJD50",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IV2LJJJD51",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IV2LI1OC0",
//															"faceTagName": "wait"
//														},
//														"1IV1D2HS60": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IV2TBAF9104",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IV2TBAF9105",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IV1D2HS60",
//															"faceTagName": "chat"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IV18ARDG2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IV18ARDG3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "true"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1IV188PLC1",
//									"attrs": {
//										"1IV1F4GGO0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IV1F8HS95",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IV1F8HS96",
//													"attrs": {
//														"display": "Off"
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IV1F4GGO0",
//											"faceTagName": "start"
//										},
//										"1IV1F71C40": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IV1F8HS97",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IV1F8HS98",
//													"attrs": {
//														"display": "Off"
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IV1F71C40",
//											"faceTagName": "ready"
//										},
//										"1IV2LI1OC0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IV2LJJJD54",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IV2LJJJD55",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IV2LI1OC0",
//											"faceTagName": "wait"
//										},
//										"1IV1D2HS60": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IV2TBAF9108",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IV2TBAF9109",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IV1D2HS60",
//											"faceTagName": "chat"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1IV188PLC2",
//									"attrs": {
//										"OnClick": {
//											"type": "fixedFunc",
//											"jaxId": "1IV1EKD3A0",
//											"attrs": {
//												"callArgs": {
//													"jaxId": "1IV1EKD3A1",
//													"attrs": {
//														"event": ""
//													}
//												},
//												"seg": "1IV1C94NR0"
//											}
//										}
//									}
//								},
//								"extraPpts": {
//									"jaxId": "1IV188PLC3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1IV2KV6QS0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IV2L103O0",
//									"attrs": {
//										"type": "box",
//										"id": "BoxWaitBG",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "Off",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"body\"]",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1IV2L1LPF0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IV2L34GE0",
//													"attrs": {
//														"type": "text",
//														"id": "TxtWait",
//														"position": "Absolute",
//														"x": "0",
//														"y": "40%",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "[0,20,0,20]",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBody\"]",
//														"text": "Connecting to your AI2Apps client...",
//														"font": "",
//														"fontSize": "#txtSize.midPlus",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "true",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IV2L34GE1",
//													"attrs": {
//														"1IV2LI1OC0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IV2LJJJD58",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IV2LJJJD59",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IV2LI1OC0",
//															"faceTagName": "wait"
//														},
//														"1IV1D2HS60": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IV2TBAF9112",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IV2TBAF9113",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IV1D2HS60",
//															"faceTagName": "chat"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IV2L34GE2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IV2L34GE3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1IV2L103P0",
//									"attrs": {
//										"1IV1F4GGO0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IV2L103P1",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IV2L103P2",
//													"attrs": {
//														"display": "On"
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IV1F4GGO0",
//											"faceTagName": "start"
//										},
//										"1IV1F71C40": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IV2L3QO725",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IV2L3QO726",
//													"attrs": {
//														"display": "Off"
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IV1F71C40",
//											"faceTagName": "ready"
//										},
//										"1IV2LICTI0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IV2LJJJD60",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IV2LJJJD61",
//													"attrs": {
//														"display": "Off"
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IV2LICTI0",
//											"faceTagName": "!wait"
//										},
//										"1IV2LI1OC0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IV2LJJJD62",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IV2LJJJD63",
//													"attrs": {
//														"display": "On"
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IV2LI1OC0",
//											"faceTagName": "wait"
//										},
//										"1IV1D2HS60": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IV2TBAFA0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IV2TBAFA1",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IV1D2HS60",
//											"faceTagName": "chat"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1IV2L103P3",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IV2L103P4",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1IV16MNG29",
//					"attrs": {
//						"1IV2LI1OC0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1IV2LJJJD66",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IV2LJJJD67",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1IV2LI1OC0",
//							"faceTagName": "wait"
//						},
//						"1IV1D2HS60": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1IV2TBAFA4",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IV2TBAFA5",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1IV1D2HS60",
//							"faceTagName": "chat"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1IV16MNG210",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1IV16MNG211",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1IV16MNG212",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}