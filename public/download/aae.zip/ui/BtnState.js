//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1I1UT4SUC0StartDoc*/
/*}#1I1UT4SUC0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BtnState=function(icon,text,tip,tipSize,tipIcon){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1I1UT4SUC1LocalVals*/
	const app=VFACT.app;
	if(icon[0]!=="/"){
		icon=appCfg.sharedAssets+"/"+icon;
	}
	if(tipIcon && tipIcon[0]!=="/"){
		tipIcon=appCfg.sharedAssets+"/"+tipIcon;
	}
	/*}#1I1UT4SUC1LocalVals*/
	
	/*#{1I1UT4SUC1PreState*/
	/*}#1I1UT4SUC1PreState*/
	state={
		"text":text,
		/*#{1I1UT4SUC7ExState*/
		/*}#1I1UT4SUC7ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1I1UT4SUC1PostState*/
	/*}#1I1UT4SUC1PostState*/
	cssVO={
		"hash":"1I1UT4SUC1",nameHost:true,
		"type":"button","x":0,"y":0,"w":200,"h":36,"cursor":"pointer","margin":[5,0,5,0],"padding":[10,20,10,20],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
		"contentLayout":"flex-x","itemsAlign":1,"subAlign":1,
		children:[
			{
				"hash":"1I1UT5HJ10",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":[0,0,0,0],
				"border":1,"borderColor":cfgColor["fontBodyLit"],"corner":20,
			},
			{
				"hash":"1ILNTQJ070",
				"type":"hud","position":"relative","x":0,"y":0,"w":24,"h":24,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				children:[
					{
						"hash":"1I1UT9NOO0",
						"type":"box","id":"BoxIcon","position":"relative","x":12,"y":12,"w":24,"h":24,"anchorX":1,"anchorY":1,"uiEvent":-1,"minW":"","minH":"","maxW":"",
						"maxH":"","styleClass":"","background":cfgColor["fontBodyLit"],"maskImage":icon,
					}
				],
			},
			{
				"hash":"1ILN4B3LR0",
				"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","margin":[0,0,0,5],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodySub"],
				"text":tip,"fontSize":txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
			},
			{
				"hash":"1IUV8EUIT0",
				"type":"hud","position":"relative","x":0,"y":0,"w":24,"h":24,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","flex":true,
			},
			{
				"hash":"1I1UTFLSS0",
				"type":"text","position":"relative","x":0,"y":0,"w":"","h":"100%","display":text!==null,"uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"color":cfgColor["fontBodyLit"],"text":$P(()=>(state.text),state),"fontSize":tipSize||txtSize.midPlus,"fontWeight":"bold","fontStyle":"normal","textDecoration":"",
				"alignH":1,"alignV":1,
			},
			{
				"hash":"1IV55GB0S0",
				"type":"box","id":"BoxTipIcon","position":"relative","x":0,"y":0,"w":16,"h":16,"margin":[0,0,0,5],"styleClass":"","background":cfgColor["fontBodySub"],
				"maskImage":tipIcon,"attached":!!tipIcon,
			}
		],
		get $$text(){return state["text"]},
		set $$text(v){
			state["text"]=v;
			/*#{1I1UT4SUC1Settext*/
			/*}#1I1UT4SUC1Settext*/
		},
		/*#{1I1UT4SUC1ExtraCSS*/
		/*}#1I1UT4SUC1ExtraCSS*/
		faces:{
			"up":{
				/*BoxBG*/"#1I1UT5HJ10":{
					"background":[0,0,0,0],"border":1,"borderColor":cfgColor["fontBodySub"]
				},
				/*BoxIcon*/"#1I1UT9NOO0":{
					"background":cfgColor["fontBodySub"],"w":24,"h":24
				},
				"#1ILN4B3LR0":{
					"color":cfgColor["fontBodySub"]
				},
				"#1I1UTFLSS0":{
					"color":cfgColor["fontBodyLit"]
				},
				/*BoxTipIcon*/"#1IV55GB0S0":{
					"background":cfgColor["fontBodySub"]
				}
			},"down":{
				/*BoxBG*/"#1I1UT5HJ10":{
					"border":2,"borderColor":cfgColor["fontBody"],"background":cfgColor["itemDown"]
				},
				/*BoxIcon*/"#1I1UT9NOO0":{
					"background":cfgColor["fontBody"],"w":28,"h":28
				},
				/*BoxTipIcon*/"#1IV55GB0S0":{
					"background":cfgColor["fontBody"]
				}
			},"over":{
				/*BoxBG*/"#1I1UT5HJ10":{
					"background":[0,0,0,0],"borderColor":cfgColor["fontBody"],"border":2
				},
				/*BoxIcon*/"#1I1UT9NOO0":{
					"background":cfgColor["fontBody"],"w":28,"h":28
				},
				"#1ILN4B3LR0":{
					"color":cfgColor["fontBody"]
				},
				"#1I1UTFLSS0":{
					"color":cfgColor["fontBodySub"]
				},
				/*BoxTipIcon*/"#1IV55GB0S0":{
					"background":cfgColor["fontBody"]
				}
			},"gray":{
				/*BoxIcon*/"#1I1UT9NOO0":{
					"background":cfgColor["fontBodyLit"],"w":24,"h":24
				},
				"#1ILN4B3LR0":{
					"color":cfgColor["fontBodyLit"]
				},
				/*BoxTipIcon*/"#1IV55GB0S0":{
					"background":cfgColor["fontBodyLit"]
				}
			},"nonumber":{
				"#1IUV8EUIT0":{
					"display":0
				},
				"#1I1UTFLSS0":{
					"display":0
				}
			}
		},
		OnCreate:function(){
			self=this;
			
			/*#{1I1UT4SUC1Create*/
			/*}#1I1UT4SUC1Create*/
		},
		/*#{1I1UT4SUC1EndCSS*/
		OnButtonDown:function(){
			if(tip && app.showTip){
				app.abortTip(self);
			}		
		},
		OnMouseInOut:function(isIn){
			return;
			if(tip && app.showTip){
				if(isIn){
					let x,y,ax,ay;
					switch(self.tipDir){
						case 0:
						case "up":
						case "u":
							x=self.w/2;y=-5;ax=1;ay=2;
							break;
						case 1:
						case "right":
						case "r":
							x=self.w+5;y=self.h/2;ax=0;ay=1;
							break;
						case 2:
						case "bottom":
						case "b":
						default:
							x=self.w/2;y=self.h+5;ax=1;ay=0;
							break;
						case 3:
						case "left":
						case "l":
							x=-5;y=self.h/2;ax=2;ay=1;
							break;
					}
					app.showTip(self,tip,x,y,ax,ay);
				}else{
					app.abortTip(self);
				}
			}
		}
		/*}#1I1UT4SUC1EndCSS*/
	};
	/*#{1I1UT4SUC1PostCSSVO*/
	/*}#1I1UT4SUC1PostCSSVO*/
	cssVO.constructor=BtnState;
	return cssVO;
};
/*#{1I1UT4SUC1ExCodes*/
/*}#1I1UT4SUC1ExCodes*/

//----------------------------------------------------------------------------
BtnState.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1I1UT4SUC1PreAISpot*/
	/*}#1I1UT4SUC1PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1I1UT4SUC1PostAISpot*/
	/*}#1I1UT4SUC1PostAISpot*/
	return exposeVO;
};

//----------------------------------------------------------------------------
BtnState.gearExport={
	framework: "jax",
	hudType: "button",
	"showName":"",icon:"gears.svg",previewImg:false,
	fixPose:false,initW:100,initH:100,
	catalog:"",
	args: {
		"icon": {
			"name": "icon", "showName": "icon", "type": "string", "key": true, "fixed": true, "initVal": "\"gas.svg\""
		}, 
		"text": {
			"name": "text", "showName": "text", "type": "string", "key": true, "fixed": true, "initVal": "12"
		}, 
		"tip": {
			"name": "tip", "showName": "tip", "type": "string", "key": true, "fixed": true, "initVal": "Skill", "localizable": true
		}, 
		"tipSize": {
			"name": "tipSize", "showName": "tipSize", "type": "int", "key": true, "fixed": true, "initVal": 16
		}, 
		"tipIcon": {
			"name": "tipIcon", "showName": "tipIcon", "type": "string", "key": true, "fixed": true, "initVal": ""
		}
	},
	state:{
		text:{name:"text",type:"string",initVal:"12"}
	},
	properties:["id","position","x","y","w","anchorH","anchorV","display","uiEvent","enable"],
	faces:["up","down","over","gray","nonumber"],
	subContainers:{
	},
	/*#{1I1UT4SUC0ExGearInfo*/
	/*}#1I1UT4SUC0ExGearInfo*/
};
/*#{1I1UT4SUC0EndDoc*/
/*}#1I1UT4SUC0EndDoc*/

export default BtnState;
export{BtnState};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearButton",
//	"jaxId": "1I1UT4SUC0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1I1UT4SUC2",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1I1UT4SUC3",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1I1UT4SUC4",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1I1UT4SUC5",
//			"attrs": {
//				"icon": {
//					"type": "string",
//					"valText": "\"gas.svg\""
//				},
//				"text": {
//					"type": "string",
//					"valText": "12"
//				},
//				"tip": {
//					"type": "string",
//					"valText": "Skill",
//					"localizable": true
//				},
//				"tipSize": {
//					"type": "int",
//					"valText": "16"
//				},
//				"tipIcon": {
//					"type": "string",
//					"valText": ""
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1I1UT4SUC6",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1I1UT4SUC7",
//			"attrs": {
//				"text": {
//					"type": "string",
//					"valText": "#text"
//				}
//			}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1I1UT4SUC8",
//			"attrs": {
//				"up": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1I1UTN20H0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1I1UTO2VI0",
//							"attrs": {}
//						}
//					}
//				},
//				"down": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1I1UTN6NH0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1I1UTO2VI1",
//							"attrs": {}
//						}
//					}
//				},
//				"over": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1I1UTNAHT0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1I1UTO2VI2",
//							"attrs": {}
//						}
//					}
//				},
//				"gray": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1ILN525UK0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1ILN532IS0",
//							"attrs": {}
//						}
//					}
//				},
//				"nonumber": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IUV8IR3R0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IUV8K6HL0",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1I1UT4SUC9",
//			"attrs": {}
//		},
//		"exposeToAI": "true",
//		"descAI": "",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "button",
//			"jaxId": "1I1UT4SUC1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1I1UT4SUC10",
//					"attrs": {
//						"type": "button",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "200",
//						"h": "36",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "pointer",
//						"zIndex": "0",
//						"margin": "[5,0,5,0]",
//						"padding": "[10,20,10,20]",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"enable": "true",
//						"drag": "NA",
//						"contentLayout": "Flex X",
//						"itemsAlign": "Center",
//						"subAlign": "Center"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1I1UT5HJ10",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I1UTKUVO0",
//									"attrs": {
//										"type": "box",
//										"id": "BoxBG",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "[0,0,0,0]",
//										"border": "1",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor[\"fontBodyLit\"]",
//										"corner": "20",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"contentLayout": "Block"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1I1UTKUVO1",
//									"attrs": {
//										"1I1UTN20H0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I1UTO2VI3",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I1UTO2VI4",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "[0,0,0,0]"
//														},
//														"border": {
//															"type": "auto",
//															"valText": "1",
//															"editMode": "edges"
//														},
//														"borderColor": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor[\"fontBodySub\"]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I1UTN20H0",
//											"faceTagName": "up"
//										},
//										"1I1UTN6NH0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I1UTS9KM0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I1UTS9KN0",
//													"attrs": {
//														"border": {
//															"type": "auto",
//															"valText": "2",
//															"editMode": "edges"
//														},
//														"borderColor": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor[\"fontBody\"]"
//														},
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor[\"itemDown\"]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I1UTN6NH0",
//											"faceTagName": "down"
//										},
//										"1I1UTNAHT0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I1UTS9KN1",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I1UTS9KN2",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "[0,0,0,0]"
//														},
//														"borderColor": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor[\"fontBody\"]"
//														},
//														"border": {
//															"type": "auto",
//															"valText": "2",
//															"editMode": "edges"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I1UTNAHT0",
//											"faceTagName": "over"
//										},
//										"1ILN525UK0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IV596P9M0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IV596P9M1",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1ILN525UK0",
//											"faceTagName": "gray"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1I1UTKUVO2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1I1UTKUVO3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1ILNTQJ070",
//							"attrs": {
//								"properties": {
//									"jaxId": "1ILNTR2ET0",
//									"attrs": {
//										"type": "hud",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "24",
//										"h": "24",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": ""
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1I1UT9NOO0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I1UTKUVO4",
//													"attrs": {
//														"type": "box",
//														"id": "BoxIcon",
//														"position": "relative",
//														"x": "12",
//														"y": "12",
//														"w": "24",
//														"h": "24",
//														"anchorH": "Center",
//														"anchorV": "Center",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "Tree Off",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "#cfgColor[\"fontBodyLit\"]",
//														"border": "0",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]",
//														"maskImage": "#icon"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I1UTKUVO5",
//													"attrs": {
//														"1I1UTN20H0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I1UTO2VI5",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I1UTO2VI6",
//																	"attrs": {
//																		"background": {
//																			"type": "colorRGBA",
//																			"valText": "#cfgColor[\"fontBodySub\"]"
//																		},
//																		"w": {
//																			"type": "length",
//																			"valText": "24"
//																		},
//																		"h": {
//																			"type": "length",
//																			"valText": "24"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I1UTN20H0",
//															"faceTagName": "up"
//														},
//														"1I1UTNAHT0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I1UTS9KN5",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I1UTS9KN6",
//																	"attrs": {
//																		"background": {
//																			"type": "colorRGBA",
//																			"valText": "#cfgColor[\"fontBody\"]"
//																		},
//																		"w": {
//																			"type": "length",
//																			"valText": "28"
//																		},
//																		"h": {
//																			"type": "length",
//																			"valText": "28"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I1UTNAHT0",
//															"faceTagName": "over"
//														},
//														"1I1UTN6NH0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I1UTT3GE0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I1UTT3GE1",
//																	"attrs": {
//																		"background": {
//																			"type": "colorRGBA",
//																			"valText": "#cfgColor[\"fontBody\"]"
//																		},
//																		"w": {
//																			"type": "length",
//																			"valText": "28"
//																		},
//																		"h": {
//																			"type": "length",
//																			"valText": "28"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I1UTN6NH0",
//															"faceTagName": "down"
//														},
//														"1ILN525UK0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1ILN532IT2",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1ILN532IT3",
//																	"attrs": {
//																		"background": {
//																			"type": "colorRGBA",
//																			"valText": "#cfgColor[\"fontBodyLit\"]"
//																		},
//																		"w": {
//																			"type": "length",
//																			"valText": "24"
//																		},
//																		"h": {
//																			"type": "length",
//																			"valText": "24"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1ILN525UK0",
//															"faceTagName": "gray"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I1UTKUVO6",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I1UTKUVO7",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1ILNTR2EU0",
//									"attrs": {
//										"1I1UTN20H0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1ILNTSENB2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1ILNTSENB3",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I1UTN20H0",
//											"faceTagName": "up"
//										},
//										"1I1UTN6NH0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1ILNTSENB4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1ILNTSENB5",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I1UTN6NH0",
//											"faceTagName": "down"
//										},
//										"1ILN525UK0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IV596P9M2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IV596P9M3",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1ILN525UK0",
//											"faceTagName": "gray"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1ILNTR2EU1",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1ILNTR2EU2",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1ILN4B3LR0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1ILN4DR590",
//									"attrs": {
//										"type": "text",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,5]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#cfgColor[\"fontBodySub\"]",
//										"text": "#tip",
//										"font": "",
//										"fontSize": "#txtSize.smallPlus",
//										"bold": "false",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Top",
//										"wrap": "false",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0",
//										"flex": "false"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1ILN4DR591",
//									"attrs": {
//										"1ILN525UK0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1ILN532IT4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1ILN532IT5",
//													"attrs": {
//														"color": {
//															"type": "colorRGB",
//															"valText": "#cfgColor[\"fontBodyLit\"]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1ILN525UK0",
//											"faceTagName": "gray"
//										},
//										"1I1UTN20H0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1ILN532IT6",
//											"attrs": {
//												"properties": {
//													"jaxId": "1ILN532IT7",
//													"attrs": {
//														"color": {
//															"type": "colorRGB",
//															"valText": "#cfgColor[\"fontBodySub\"]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I1UTN20H0",
//											"faceTagName": "up"
//										},
//										"1I1UTNAHT0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1ILN532IT8",
//											"attrs": {
//												"properties": {
//													"jaxId": "1ILN532IT9",
//													"attrs": {
//														"color": {
//															"type": "colorRGB",
//															"valText": "#cfgColor[\"fontBody\"]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I1UTNAHT0",
//											"faceTagName": "over"
//										},
//										"1I1UTN6NH0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1ILN577RF0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1ILN577RF1",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I1UTN6NH0",
//											"faceTagName": "down"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1ILN4DR592",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1ILN4DR593",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1IUV8EUIT0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IUV8EUIT1",
//									"attrs": {
//										"type": "hud",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "24",
//										"h": "24",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"flex": "true"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1IUV8EUIT15",
//									"attrs": {
//										"1I1UTN20H0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IUV8EUIT18",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IUV8EUIT19",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I1UTN20H0",
//											"faceTagName": "up"
//										},
//										"1I1UTN6NH0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IUV8EUIT20",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IUV8EUIT21",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I1UTN6NH0",
//											"faceTagName": "down"
//										},
//										"1IUV8IR3R0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IUV8K6HL1",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IUV8K6HL2",
//													"attrs": {
//														"display": "Off"
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IUV8IR3R0",
//											"faceTagName": "nonumber"
//										},
//										"1ILN525UK0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IV596P9M4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IV596P9M5",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1ILN525UK0",
//											"faceTagName": "gray"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1IUV8EUIT22",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IUV8EUIT23",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1I1UTFLSS0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I1UTKUVO8",
//									"attrs": {
//										"type": "text",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "#text!==null",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "0",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#cfgColor[\"fontBodyLit\"]",
//										"text": "${state.text},state",
//										"font": "",
//										"fontSize": "#tipSize||txtSize.midPlus",
//										"bold": "true",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Center",
//										"alignV": "Center",
//										"wrap": "false",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0",
//										"flex": "false"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1I1UTKUVO9",
//									"attrs": {
//										"1I1UTN20H0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I1UTO2VI7",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I1UTO2VI8",
//													"attrs": {
//														"color": {
//															"type": "colorRGB",
//															"valText": "#cfgColor[\"fontBodyLit\"]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I1UTN20H0",
//											"faceTagName": "up"
//										},
//										"1I1UTNAHT0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I1UTS9KN9",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I1UTS9KN10",
//													"attrs": {
//														"color": {
//															"type": "colorRGB",
//															"valText": "#cfgColor[\"fontBodySub\"]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I1UTNAHT0",
//											"faceTagName": "over"
//										},
//										"1I1UTN6NH0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I1UTT3GE2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I1UTT3GE3",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I1UTN6NH0",
//											"faceTagName": "down"
//										},
//										"1IUV8IR3R0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IUV8K6HL3",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IUV8K6HL4",
//													"attrs": {
//														"display": "Off"
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IUV8IR3R0",
//											"faceTagName": "nonumber"
//										},
//										"1ILN525UK0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IV596P9M6",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IV596P9M7",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1ILN525UK0",
//											"faceTagName": "gray"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1I1UTKUVO10",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1I1UTKUVO11",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1IV55GB0S0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IV560V2D0",
//									"attrs": {
//										"type": "box",
//										"id": "BoxTipIcon",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "16",
//										"h": "16",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,5]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"fontBodySub\"]",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"maskImage": "#tipIcon",
//										"attach": "#!!tipIcon"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1IV560V2D1",
//									"attrs": {
//										"1ILN525UK0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IV596P9M8",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IV596P9M9",
//													"attrs": {
//														"background": "#cfgColor[\"fontBodyLit\"]"
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1ILN525UK0",
//											"faceTagName": "gray"
//										},
//										"1I1UTN20H0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IV5986GN0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IV5986GN1",
//													"attrs": {
//														"background": "#cfgColor[\"fontBodySub\"]"
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I1UTN20H0",
//											"faceTagName": "up"
//										},
//										"1I1UTN6NH0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IV5986GN2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IV5986GN3",
//													"attrs": {
//														"background": "#cfgColor[\"fontBody\"]"
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I1UTN6NH0",
//											"faceTagName": "down"
//										},
//										"1I1UTNAHT0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IV5986GN4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IV5986GN5",
//													"attrs": {
//														"background": "#cfgColor[\"fontBody\"]"
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I1UTNAHT0",
//											"faceTagName": "over"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1IV560V2D2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IV560V2D3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1I1UT4SUC11",
//					"attrs": {
//						"1I1UTN6NH0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1I1UTT3GE4",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I1UTT3GE5",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1I1UTN6NH0",
//							"faceTagName": "down"
//						},
//						"1I1UTN20H0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1ILNTSENB8",
//							"attrs": {
//								"properties": {
//									"jaxId": "1ILNTSENB9",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1I1UTN20H0",
//							"faceTagName": "up"
//						},
//						"1ILN525UK0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1IV596P9M10",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IV596P9M11",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1ILN525UK0",
//							"faceTagName": "gray"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1I1UT4SUC12",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1I1UT4SUC13",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1I1UT4SUC14",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "true",
//				"h": "false",
//				"anchorH": "true",
//				"anchorV": "true",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "true",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false",
//				"enable": "true",
//				"drag": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": [
//				{
//					"type": "string",
//					"valText": "text"
//				}
//			]
//		}
//	}
//}