//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1I1UT4SUC0StartDoc*/
/*}#1I1UT4SUC0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BtnState=function(icon,text,tip){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1I1UT4SUC1LocalVals*/
	const app=VFACT.app;
	if(icon[0]!=="/"){
		icon=appCfg.sharedAssets+"/"+icon;
	}
	/*}#1I1UT4SUC1LocalVals*/
	
	/*#{1I1UT4SUC1PreState*/
	/*}#1I1UT4SUC1PreState*/
	state={
		"text":text,
		/*#{1I1UT4SUC7ExState*/
		/*}#1I1UT4SUC7ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1I1UT4SUC1PostState*/
	/*}#1I1UT4SUC1PostState*/
	cssVO={
		"hash":"1I1UT4SUC1",nameHost:true,
		"type":"button","x":0,"y":0,"w":100,"h":36,"cursor":"pointer","margin":[5,0,5,0],"padding":[10,20,10,20],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
		"contentLayout":"flex-x","itemsAlign":1,
		children:[
			{
				"hash":"1I1UT5HJ10",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["body"],
				"border":1,"borderColor":cfgColor["fontBodyLit"],"corner":20,
			},
			{
				"hash":"1I1UT9NOO0",
				"type":"box","position":"relative","x":0,"y":0,"w":24,"h":24,"uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["fontBodyLit"],
				"maskImage":icon,
			},
			{
				"hash":"1I1UTFLSS0",
				"type":"text","position":"relative","x":0,"y":0,"w":"","h":"100%","uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodyLit"],
				"text":$P(()=>(state.text),state),"fontSize":txtSize.big,"fontWeight":"bold","fontStyle":"normal","textDecoration":"","alignH":1,"alignV":1,"flex":true,
			}
		],
		get $$text(){return state["text"]},
		set $$text(v){
			state["text"]=v;
			/*#{1I1UT4SUC1Settext*/
			/*}#1I1UT4SUC1Settext*/
		},
		/*#{1I1UT4SUC1ExtraCSS*/
		/*}#1I1UT4SUC1ExtraCSS*/
		faces:{
			"up":{
				/*BoxBG*/"#1I1UT5HJ10":{
					"background":cfgColor["body"],"border":1,"borderColor":cfgColor["fontBodyLit"]
				},
				"#1I1UT9NOO0":{
					"background":cfgColor["fontBodyLit"]
				},
				"#1I1UTFLSS0":{
					"color":cfgColor["fontBodyLit"]
				}
			},"down":{
				/*BoxBG*/"#1I1UT5HJ10":{
					"border":1,"borderColor":cfgColor["fontBodyLit"],"background":cfgColor["body"]
				}
			},"over":{
				/*BoxBG*/"#1I1UT5HJ10":{
					"background":cfgColor["itemOver"],"borderColor":cfgColor["fontBody"],"border":2
				},
				"#1I1UT9NOO0":{
					"background":cfgColor["fontBodySub"]
				},
				"#1I1UTFLSS0":{
					"color":cfgColor["fontBodySub"]
				}
			}
		},
		OnCreate:function(){
			self=this;
			
			/*#{1I1UT4SUC1Create*/
			/*}#1I1UT4SUC1Create*/
		},
		/*#{1I1UT4SUC1EndCSS*/
		OnButtonDown:function(){
			if(tip && app.showTip){
				app.abortTip(self);
			}		
		},
		OnMouseInOut:function(isIn){
			if(tip && app.showTip){
				if(isIn){
					let x,y,ax,ay;
					switch(self.tipDir){
						case 0:
						case "up":
						case "u":
							x=self.w/2;y=-5;ax=1;ay=2;
							break;
						case 1:
						case "right":
						case "r":
							x=self.w+5;y=self.h/2;ax=0;ay=1;
							break;
						case 2:
						case "bottom":
						case "b":
						default:
							x=self.w/2;y=self.h+5;ax=1;ay=0;
							break;
						case 3:
						case "left":
						case "l":
							x=-5;y=self.h/2;ax=2;ay=1;
							break;
					}
					app.showTip(self,tip,x,y,ax,ay);
				}else{
					app.abortTip(self);
				}
			}
		}
		/*}#1I1UT4SUC1EndCSS*/
	};
	/*#{1I1UT4SUC1PostCSSVO*/
	/*}#1I1UT4SUC1PostCSSVO*/
	return cssVO;
};
/*#{1I1UT4SUC1ExCodes*/
/*}#1I1UT4SUC1ExCodes*/

BtnState.gearExport={
	framework: "jax",
	hudType: "button",
	"showName":"",icon:"gears.svg",previewImg:false,
	fixPose:false,initW:100,initH:100,
	catalog:"",
	args: {
		"icon": {
			"name": "icon", "showName": "icon", "type": "string", "key": true, "fixed": true, "initVal": "\"gas.svg\""
		}, 
		"text": {
			"name": "text", "showName": "text", "type": "string", "key": true, "fixed": true, "initVal": "12"
		}, 
		"tip": {
			"name": "tip", "showName": "tip", "type": "string", "key": true, "fixed": true, "initVal": "Skill", "localizable": true
		}
	},
	state:{
		text:{name:"text",type:"string",initVal:"12"}
	},
	properties:["id","position","x","y","w","anchorH","anchorV","display"],
	faces:["up","down","over"],
	subContainers:{
	},
	/*#{1I1UT4SUC0ExGearInfo*/
	/*}#1I1UT4SUC0ExGearInfo*/
};
/*#{1I1UT4SUC0EndDoc*/
/*}#1I1UT4SUC0EndDoc*/

export default BtnState;
export{BtnState};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearButton",
//	"jaxId": "1I1UT4SUC0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1I1UT4SUC2",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1I1UT4SUC3",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1I1UT4SUC4",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1I1UT4SUC5",
//			"attrs": {
//				"icon": {
//					"type": "string",
//					"valText": "\"gas.svg\""
//				},
//				"text": {
//					"type": "string",
//					"valText": "12"
//				},
//				"tip": {
//					"type": "string",
//					"valText": "Skill",
//					"localizable": true
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1I1UT4SUC6",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1I1UT4SUC7",
//			"attrs": {
//				"text": {
//					"type": "string",
//					"valText": "#text"
//				}
//			}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1I1UT4SUC8",
//			"attrs": {
//				"up": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1I1UTN20H0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1I1UTO2VI0",
//							"attrs": {}
//						}
//					}
//				},
//				"down": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1I1UTN6NH0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1I1UTO2VI1",
//							"attrs": {}
//						}
//					}
//				},
//				"over": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1I1UTNAHT0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1I1UTO2VI2",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1I1UT4SUC9",
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "button",
//			"jaxId": "1I1UT4SUC1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1I1UT4SUC10",
//					"attrs": {
//						"type": "button",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "100",
//						"h": "36",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "pointer",
//						"zIndex": "0",
//						"margin": "[5,0,5,0]",
//						"padding": "[10,20,10,20]",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"enable": "true",
//						"drag": "NA",
//						"contentLayout": "Flex X",
//						"itemsAlign": "Center"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1I1UT5HJ10",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I1UTKUVO0",
//									"attrs": {
//										"type": "box",
//										"id": "BoxBG",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"body\"]",
//										"border": "1",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor[\"fontBodyLit\"]",
//										"corner": "20",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"contentLayout": "Block"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1I1UTKUVO1",
//									"attrs": {
//										"1I1UTN20H0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I1UTO2VI3",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I1UTO2VI4",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor[\"body\"]"
//														},
//														"border": {
//															"type": "auto",
//															"valText": "1",
//															"editMode": "edges"
//														},
//														"borderColor": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor[\"fontBodyLit\"]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I1UTN20H0",
//											"faceTagName": "up"
//										},
//										"1I1UTN6NH0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I1UTS9KM0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I1UTS9KN0",
//													"attrs": {
//														"border": {
//															"type": "auto",
//															"valText": "1",
//															"editMode": "edges"
//														},
//														"borderColor": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor[\"fontBodyLit\"]"
//														},
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor[\"body\"]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I1UTN6NH0",
//											"faceTagName": "down"
//										},
//										"1I1UTNAHT0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I1UTS9KN1",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I1UTS9KN2",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor[\"itemOver\"]"
//														},
//														"borderColor": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor[\"fontBody\"]"
//														},
//														"border": {
//															"type": "auto",
//															"valText": "2",
//															"editMode": "edges"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I1UTNAHT0",
//											"faceTagName": "over"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1I1UTKUVO2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1I1UTKUVO3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1I1UT9NOO0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I1UTKUVO4",
//									"attrs": {
//										"type": "box",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "24",
//										"h": "24",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"fontBodyLit\"]",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"maskImage": "#icon"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1I1UTKUVO5",
//									"attrs": {
//										"1I1UTN20H0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I1UTO2VI5",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I1UTO2VI6",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor[\"fontBodyLit\"]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I1UTN20H0",
//											"faceTagName": "up"
//										},
//										"1I1UTNAHT0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I1UTS9KN5",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I1UTS9KN6",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor[\"fontBodySub\"]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I1UTNAHT0",
//											"faceTagName": "over"
//										},
//										"1I1UTN6NH0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I1UTT3GE0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I1UTT3GE1",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I1UTN6NH0",
//											"faceTagName": "down"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1I1UTKUVO6",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1I1UTKUVO7",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1I1UTFLSS0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I1UTKUVO8",
//									"attrs": {
//										"type": "text",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "0",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#cfgColor[\"fontBodyLit\"]",
//										"text": "${state.text},state",
//										"font": "",
//										"fontSize": "#txtSize.big",
//										"bold": "true",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Center",
//										"alignV": "Center",
//										"wrap": "false",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0",
//										"flex": "true"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1I1UTKUVO9",
//									"attrs": {
//										"1I1UTN20H0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I1UTO2VI7",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I1UTO2VI8",
//													"attrs": {
//														"color": {
//															"type": "colorRGB",
//															"valText": "#cfgColor[\"fontBodyLit\"]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I1UTN20H0",
//											"faceTagName": "up"
//										},
//										"1I1UTNAHT0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I1UTS9KN9",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I1UTS9KN10",
//													"attrs": {
//														"color": {
//															"type": "colorRGB",
//															"valText": "#cfgColor[\"fontBodySub\"]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I1UTNAHT0",
//											"faceTagName": "over"
//										},
//										"1I1UTN6NH0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I1UTT3GE2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I1UTT3GE3",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I1UTN6NH0",
//											"faceTagName": "down"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1I1UTKUVO10",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1I1UTKUVO11",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1I1UT4SUC11",
//					"attrs": {
//						"1I1UTNAHT0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1I1UTS9KN15",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I1UTS9KN16",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1I1UTNAHT0",
//							"faceTagName": "over"
//						},
//						"1I1UTN6NH0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1I1UTT3GE4",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I1UTT3GE5",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1I1UTN6NH0",
//							"faceTagName": "down"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1I1UT4SUC12",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1I1UT4SUC13",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1I1UT4SUC14",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "true",
//				"h": "false",
//				"anchorH": "true",
//				"anchorV": "true",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"enable": "false",
//				"drag": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": [
//				{
//					"type": "string",
//					"valText": "text"
//				}
//			]
//		}
//	}
//}