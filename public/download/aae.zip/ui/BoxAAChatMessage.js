//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1I5LRDMNM0StartDoc*/
import {BoxAAChatAsset} from "./BoxAAChatAsset.js";
import markdownit from "/@markdownit";


function formatDate(date) {
const year = date.getFullYear();
const month = String(date.getMonth() + 1).padStart(2, '0');
const day = String(date.getDate()).padStart(2, '0');
const hours = String(date.getHours()).padStart(2, '0');
const minutes = String(date.getMinutes()).padStart(2, '0');

return `${year}-${month}-${day}/${hours}:${minutes}`;
}
/*}#1I5LRDMNM0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BoxAAChatMessage=function(session,user,chatMsg,showFlow){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let txtMsg,boxMD,boxAssets;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let side="left";
	let bgColor=cfgColor["fontSecondarySub"];
	let assets=null;
	let chatText=chatMsg.content.text||chatMsg.content.result||chatMsg.content;
	let time="2024-7-8 22:10";
	
	/*#{1I5LRDMNM1LocalVals*/
	time=new Date(chatMsg.time);
	time=formatDate(time);
	side=chatMsg.from===user.id?"right":"left";
	assets=null;
	if(chatMsg.content.assets){
		assets=chatMsg.content.assets;
		if(!assets.length){
			assets=null;
		}
	}
	/*}#1I5LRDMNM1LocalVals*/
	
	/*#{1I5LRDMNM1PreState*/
	/*}#1I5LRDMNM1PreState*/
	/*#{1I5LRDMNM1PostState*/
	/*}#1I5LRDMNM1PostState*/
	cssVO={
		"hash":"1I5LRDMNM1",nameHost:true,
		"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":"","padding":side==="left"?[5,50,5,10]:[5,10,5,50],"minW":"","minH":50,"maxW":"","maxH":"",
		"styleClass":"","contentLayout":"flex-x",
		children:[
			{
				"hash":"1I5LRRA5F0",
				"type":"box","id":"BoxAvatar","position":"relative","x":0,"y":0,"w":32,"h":32,"overflow":1,"padding":3,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"background":[255,255,255,1],"border":1,"borderColor":cfgColor["fontBodyLit"],"corner":25,"contentLayout":"flex-x","attached":side==="left",
				children:[
					{
						"hash":"1I5LS413R0",
						"type":"box","id":"IconAvatar","position":"relative","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["fontBodySub"],
						"border":1,"maskImage":appCfg.sharedAssets+"/agent.svg",
					}
				],
			},
			{
				"hash":"1I5LS77JG0",
				"type":"hud","id":"BoxMsg","position":"relative","x":0,"y":0,"w":80,"h":"","padding":[0,5,0,5],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"contentLayout":"flex-y","flex":true,
				children:[
					{
						"hash":"1I5LVNR2R0",
						"type":"text","id":"TxtFlow","position":"relative","x":0,"y":0,"w":"","h":"","scale":1,"cursor":"pointer","margin":[0,0,3,0],"minW":"","minH":"",
						"maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodySub"],"text":`Chat flow: ${chatMsg.chatFlow}`,"fontSize":txtSize.small,"fontWeight":"normal",
						"fontStyle":"normal","textDecoration":"underline","alignH":side==="left"?0:2,"attached":showFlow&&chatMsg.chatFlow,
						"OnClick":function(event){
							self.OnChatFlowClick(this,event);
						},
					},
					{
						"hash":"1I5LS9AA70",
						"type":"text","id":"TxtId","position":"relative","x":0,"y":0,"w":"","h":"","scale":1,"margin":[0,0,3,0],"minW":"","minH":"","maxW":"","maxH":"",
						"styleClass":"","color":cfgColor["fontBodySub"],"text":chatMsg.from+":","fontSize":txtSize.small,"fontWeight":"bold","fontStyle":"normal","textDecoration":"",
						"attached":side==="left",
					},
					{
						"hash":"1I5LUUH7P0",
						"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
						"subAlign":side==="left"?0:2,
						children:[
							{
								"hash":"1I5LUV5TC0",
								"type":"box","id":"BoxText","position":"relative","x":0,"y":0,"w":"","h":"","padding":10,"minW":50,"minH":30,"maxW":"100%","maxH":"","styleClass":"",
								"background":bgColor,"corner":side==="left"?[0,16,16,16]:[16,0,16,16],"contentLayout":"flex-y","itemsAlign":1,
								children:[
									{
										"hash":"1I5LUV5TD0",
										"type":"text","id":"TxtMsg","position":"relative","x":0,"y":0,"w":"","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":[0,0,0],
										"text":chatText,"fontSize":txtSize.mid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","wrap":true,"selectable":true,
									},
									{
										"hash":"1I5LV5E8V0",
										"type":"hud","id":"BoxMD","position":"relative","x":0,"y":0,"w":"","h":"","display":0,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
									}
								],
							}
						],
					},
					{
						"hash":"1I5LT1CTL0",
						"type":"text","id":"TxtAssets","position":"relative","x":0,"y":0,"w":"","h":"","scale":1,"margin":[5,0,3,0],"minW":"","minH":"","maxW":"","maxH":"",
						"styleClass":"","color":cfgColor["fontBodySub"],"text":"Assets:","fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
						"alignH":side==="left"?0:2,"attached":!!assets,
					},
					{
						"hash":"1I5LT66HN0",
						"type":"hud","id":"BoxAssets","position":"relative","x":0,"y":0,"w":"100%","h":"","minW":"","minH":10,"maxW":"","maxH":"","styleClass":"","attached":!!assets,
					},
					{
						"hash":"1I5M0GPCH0",
						"type":"text","id":"TxtTime","position":"relative","x":0,"y":0,"w":"100%","h":"","scale":1,"margin":[5,0,3,0],"minW":"","minH":"","maxW":"","maxH":"",
						"styleClass":"","color":cfgColor["fontBodySub"],"text":time,"fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
						"alignH":side==="left"?0:2,
					}
				],
			}
		],
		/*#{1I5LRDMNM1ExtraCSS*/
		/*}#1I5LRDMNM1ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			self=this;
			txtMsg=self.TxtMsg;boxMD=self.BoxMD;boxAssets=self.BoxAssets;
			/*#{1I5LRDMNM1Create*/
			if(assets){
				self.showAssets();
			}
			/*}#1I5LRDMNM1Create*/
		},
		/*#{1I5LRDMNM1EndCSS*/
		/*}#1I5LRDMNM1EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.renderMD=async function(){
		/*#{1I5LVDPDC0Start*/
		let content,htmlCode,webObj,list,i,n,blks,blk,upperElement,tagType,blkBox,code,mode,pos;
		boxMD.display=true;
		txtMsg.display=false;
		content=""+chatText;
		htmlCode=markdownit().render(content);
		webObj=boxMD.webObj;
		webObj.style.fontSize="14px";
		webObj.innerHTML=htmlCode;
		//First, fix tab-border
		list=webObj.querySelectorAll("table");
		n=list.length;
		for(i=0;i<n;i++){
			blk=list[i];
			blk.style.border="1px solid black";
			blk.style.borderSpacing="0px";
		}
		//First, fix tab-border
		list=webObj.querySelectorAll("table");
		n=list.length;
		for(i=0;i<n;i++){
			blk=list[i];
			blk.style.border="1px solid black";
		}
		list=webObj.querySelectorAll("th");
		n=list.length;
		for(i=0;i<n;i++){
			blk=list[i];
			blk.style.border="1px solid black";
		}
		list=webObj.querySelectorAll("td");
		n=list.length;
		for(i=0;i<n;i++){
			blk=list[i];
			blk.style.border="1px solid gray";
		}
		list=webObj.querySelectorAll("img");
		n=list.length;
		for(i=0;i<n;i++){
			blk=list[i];
			blk.style.maxWidth="100%";
		}
		list=webObj.children;
		blks=[];
		n=list.length;
		for(i=0;i<n;i++){
			blks.push(list[i]);
		}
		for(i=0;i<n;i++){
			blk=blks[i];
			blkBox=boxMD.appendNewChild({
				type:"hud",width:"100%",height:"",position:"relative",
			});
			tagType=blk.tagName.toLowerCase();
			if(tagType==="pre"){
				list=blk.childNodes;
				if(list.length===1 && list[0].tagName.toLowerCase()==="code"){
					mode=list[0].className||"";
					pos=mode.indexOf("-");
					if(pos>0){
						mode=mode.substring(pos+1);
					}else{
						mode="";
					}
					code=list[0].innerText;
					boxMD.webObj.removeChild(blk);
					blkBox.appendNewChild(BoxCodeSeg(code,mode));
				}else{
					blkBox.webObj.appendChild(blk);
				}
			}else{
				if(i===0){
					blk.style.marginBlockStart="0px";
				}
				blkBox.webObj.appendChild(blk);
			}
		}
		/*}#1I5LVDPDC0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.showAssets=async function(){
		/*#{1I5LVV67M0Start*/
		let asset,def,data;
		for(asset of assets){
			if(asset.startsWith("hub://")){
				data=await session.globalContext.fileLib.readDataURL(asset);
			}else{
				data=asset;
			}
			boxAssets.appendNewChild(BoxAAChatAsset(session,asset,data));
		}
		/*}#1I5LVV67M0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.OnChatFlowClick=async function(sender,event){
		/*#{1I5N76E1O0Start*/
		/*}#1I5N76E1O0Start*/
	};
	/*#{1I5LRDMNM1PostCSSVO*/
	/*}#1I5LRDMNM1PostCSSVO*/
	return cssVO;
};
/*#{1I5LRDMNM1ExCodes*/
/*}#1I5LRDMNM1ExCodes*/


/*#{1I5LRDMNM0EndDoc*/
/*}#1I5LRDMNM0EndDoc*/

export default BoxAAChatMessage;
export{BoxAAChatMessage};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1I5LRDMNM0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1I5LRDMNN0",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1I5LRDMNN1",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1I5LRDMNN2",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1I5LRDMNN3",
//			"attrs": {
//				"session": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"user": {
//					"type": "auto",
//					"valText": "#{id:\"admin\",name:\"Admin\"}"
//				},
//				"chatMsg": {
//					"type": "auto",
//					"valText": "#{type:\"chat\",id:\"99\",time:100,from:\"BOT_MASTER\",to:\"admin\",chatFlow:\"99\",content:{text:\"Hello Hello Hello Hello Hello Hello Hello Hello Hello Hello Hello Hello\",assets:[\"hub://image.png\"]}}"
//				},
//				"showFlow": {
//					"type": "bool",
//					"valText": "true"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1I5LRDMNN4",
//			"attrs": {
//				"side": {
//					"type": "string",
//					"valText": "left"
//				},
//				"bgColor": {
//					"type": "colorRGBA",
//					"valText": "#cfgColor[\"fontSecondarySub\"]"
//				},
//				"assets": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"chatText": {
//					"type": "string",
//					"valText": "#chatMsg.content.text||chatMsg.content.result||chatMsg.content"
//				},
//				"time": {
//					"type": "string",
//					"valText": "2024-7-8 22:10"
//				}
//			}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1I5LRDMNN5",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I5LVDPDC0",
//					"attrs": {
//						"id": "renderMD",
//						"label": "New AI Seg",
//						"x": "65",
//						"y": "55",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I5LVE64J0",
//							"attrs": {}
//						},
//						"async": "true",
//						"localVars": {
//							"jaxId": "1I5LVE64J1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I5LVE64J2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						}
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I5LVV67M0",
//					"attrs": {
//						"id": "showAssets",
//						"label": "New AI Seg",
//						"x": "65",
//						"y": "135",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I5LVVHFG0",
//							"attrs": {}
//						},
//						"async": "true",
//						"localVars": {
//							"jaxId": "1I5LVVHFG1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I5LVVHFG2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						}
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I5N76E1O0",
//					"attrs": {
//						"id": "OnChatFlowClick",
//						"label": "New AI Seg",
//						"x": "110",
//						"y": "225",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I5N783OO0",
//							"attrs": {
//								"sender": {
//									"valText": "null"
//								},
//								"event": {
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"localVars": {
//							"jaxId": "1I5N783OO1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I5N783OO2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						}
//					}
//				}
//			]
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1I5LRDMNN6",
//			"attrs": {}
//		},
//		"mockupStates": {
//			"jaxId": "1I5LRDMNN7",
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1I5LRDMNM1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1I5LRDMNN8",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Relative",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "[0,0,0,0]",
//						"padding": "#side===\"left\"?[5,50,5,10]:[5,10,5,50]",
//						"minW": "",
//						"minH": "50",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Flex X"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1I5LRRA5F0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I5LS6ITD0",
//									"attrs": {
//										"type": "box",
//										"id": "BoxAvatar",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "32",
//										"h": "32",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "On",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "3",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "[255,255,255,1.00]",
//										"border": "1",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor[\"fontBodyLit\"]",
//										"corner": "25",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"contentLayout": "Flex X",
//										"attach": "#side===\"left\""
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1I5LS413R0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I5LS6ITD1",
//													"attrs": {
//														"type": "box",
//														"id": "IconAvatar",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "#cfgColor[\"fontBodySub\"]",
//														"border": "1",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]",
//														"maskImage": "#appCfg.sharedAssets+\"/agent.svg\""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I5LS6ITD2",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1I5LS6ITD3",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I5LS6ITD4",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1I5LS6ITD5",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1I5LS6ITE0",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1I5LS6ITE1",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1I5LS77JG0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I5LSQNS30",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxMsg",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "80",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "[0,5,0,5]",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex Y",
//										"flex": "true"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1I5LVNR2R0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I5LVNR2R1",
//													"attrs": {
//														"type": "text",
//														"id": "TxtFlow",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "1",
//														"filter": "",
//														"cursor": "pointer",
//														"zIndex": "0",
//														"margin": "[0,0,3,0]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBodySub\"]",
//														"text": "#`Chat flow: ${chatMsg.chatFlow}`",
//														"font": "",
//														"fontSize": "#txtSize.small",
//														"bold": "false",
//														"italic": "false",
//														"underline": "true",
//														"alignH": "#side===\"left\"?0:2",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0",
//														"attach": "#showFlow&&chatMsg.chatFlow"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I5LVNR2S0",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1I5LVNR2S1",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1I5N783OO3",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1I5N783OO4",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": "1I5N76E1O0"
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1I5LVNR2S2",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1I5LS9AA70",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I5LSQNS31",
//													"attrs": {
//														"type": "text",
//														"id": "TxtId",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "1",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[0,0,3,0]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBodySub\"]",
//														"text": "#chatMsg.from+\":\"",
//														"font": "",
//														"fontSize": "#txtSize.small",
//														"bold": "true",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0",
//														"attach": "#side===\"left\""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I5LSQNS40",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1I5LSQNS41",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I5LSQNS42",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1I5LUUH7P0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I5LV0NSE0",
//													"attrs": {
//														"type": "hud",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex X",
//														"subAlign": "#side===\"left\"?0:2"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "box",
//															"jaxId": "1I5LUV5TC0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I5LUV5TC1",
//																	"attrs": {
//																		"type": "box",
//																		"id": "BoxText",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "10",
//																		"minW": "50",
//																		"minH": "30",
//																		"maxW": "100%",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"background": "#bgColor",
//																		"border": "0",
//																		"borderStyle": "Solid",
//																		"borderColor": "[0,0,0,1.00]",
//																		"corner": "#side===\"left\"?[0,16,16,16]:[16,0,16,16]",
//																		"shadow": "false",
//																		"shadowX": "2",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowSpread": "0",
//																		"shadowColor": "[0,0,0,0.50]",
//																		"contentLayout": "Flex Y",
//																		"flex": "false",
//																		"itemsAlign": "Center"
//																	}
//																},
//																"subHuds": {
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "text",
//																			"jaxId": "1I5LUV5TD0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I5LUV5TD1",
//																					"attrs": {
//																						"type": "text",
//																						"id": "TxtMsg",
//																						"position": "Relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "",
//																						"h": "",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"color": "[0,0,0]",
//																						"text": "#chatText",
//																						"font": "",
//																						"fontSize": "#txtSize.mid",
//																						"bold": "false",
//																						"italic": "false",
//																						"underline": "false",
//																						"alignH": "Left",
//																						"alignV": "Top",
//																						"wrap": "true",
//																						"ellipsis": "false",
//																						"lineClamp": "0",
//																						"select": "true",
//																						"shadow": "false",
//																						"shadowX": "0",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowColor": "[0,0,0,1.00]",
//																						"shadowEx": "",
//																						"maxTextW": "0"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1I5LUV5TE0",
//																					"attrs": {}
//																				},
//																				"functions": {
//																					"jaxId": "1I5LUV5TE1",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1I5LUV5TE2",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "true"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "hud",
//																			"jaxId": "1I5LV5E8V0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I5LV69U80",
//																					"attrs": {
//																						"type": "hud",
//																						"id": "BoxMD",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "",
//																						"h": "",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "Off",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": ""
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1I5LV69U81",
//																					"attrs": {}
//																				},
//																				"functions": {
//																					"jaxId": "1I5LV69U82",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1I5LV69U83",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "true",
//																				"exposeContainer": "false"
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"jaxId": "1I5LUV5TE3",
//																	"attrs": {}
//																},
//																"functions": {
//																	"jaxId": "1I5LUV5TE4",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1I5LUV5TE5",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false"
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1I5LV0NSE1",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1I5LV0NSE2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I5LV0NSE3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1I5LT1CTL0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I5LT1CTL1",
//													"attrs": {
//														"type": "text",
//														"id": "TxtAssets",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "1",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[5,0,3,0]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBodySub\"]",
//														"text": "Assets:",
//														"font": "",
//														"fontSize": "#txtSize.small",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "#side===\"left\"?0:2",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0",
//														"attach": "#!!assets"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I5LT1CTM0",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1I5LT1CTM1",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I5LT1CTM2",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1I5LT66HN0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I5LT6Q430",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxAssets",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "10",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"attach": "#!!assets"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I5LT6Q431",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1I5LT6Q432",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I5LT6Q433",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "true",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1I5M0GPCH0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I5M0GPCH1",
//													"attrs": {
//														"type": "text",
//														"id": "TxtTime",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "1",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[5,0,3,0]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBodySub\"]",
//														"text": "#time",
//														"font": "",
//														"fontSize": "#txtSize.small",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "#side===\"left\"?0:2",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0",
//														"attach": "true"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I5M0GPCI0",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1I5M0GPCI1",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I5M0GPCI2",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1I5LSQNS47",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1I5LSQNS48",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1I5LSQNS49",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1I5LRDMNN9",
//					"attrs": {}
//				},
//				"functions": {
//					"jaxId": "1I5LRDMNN10",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1I5LRDMNN11",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1I5LRDMNN12",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}