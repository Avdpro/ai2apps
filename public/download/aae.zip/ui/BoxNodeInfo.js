//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BoxAttrLine} from "./BoxAttrLine.js";
/*#{1HL2BCKSE0StartDoc*/
import AAE from "../aae.js";
/*}#1HL2BCKSE0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BoxNodeInfo=function(){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1HL2BCKSE1LocalVals*/
	/*}#1HL2BCKSE1LocalVals*/
	
	/*#{1HL2BCKSE1PreState*/
	/*}#1HL2BCKSE1PreState*/
	/*#{1HL2BCKSE1PostState*/
	function attrLine(attr){
		return {type:BoxAttrLine(attr.key,attr.value,attr.icon,attr.action),position:"relative"};
	}
	/*}#1HL2BCKSE1PostState*/
	cssVO={
		"hash":"1HL2BCKSE1",nameHost:true,
		"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":"","padding":[0,0,0,5],"minW":"","minH":50,"maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
		children:[
		],
		/*#{1HL2BCKSE1ExtraCSS*/
		/*}#1HL2BCKSE1ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			self=this;
			
			/*#{1HL2BCKSE1Create*/
			/*}#1HL2BCKSE1Create*/
		},
		/*#{1HL2BCKSE1EndCSS*/
		/*}#1HL2BCKSE1EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.showInfo=async function(page,node){
		/*#{1HL3B2HCR0Start*/
		let attrs,key,value,rect;
		let lines=[];
		/*}#1HL3B2HCR0Start*/
		
		//GetAttrs
		/*#{1HL3B885R0*/
		if(!node){
			self.clearChildren();
			return;
		}
		if(node.tagName){
			lines.push({key:"tagName",value:node.tagName});
		}
		lines.push({key:"nodeType",value:node.nodeType});
		if(node.deep>=0){
			lines.push({key:"deep",value:node.deep});
		}
		rect=node.rect;
		if(rect){
			lines.push({key:"pose",value:`x=${rect.x};y=${rect.y};w=${rect.width};h=${rect.height}`,icon:null,action:()=>{
				//TODO: openPoseDialog
			}});
		}
		attrs=await page.getNodeAttributes(node.AAEId);
		for(key in attrs){
			value=attrs[key];
			lines.push({key:key,value:value});
		}
		if(node.text){
			lines.push({key:"text",value:JSON.stringify(node.text),icon:null,action:()=>{
				//TODO: openTextDialog
			}});
		}
		/*}#1HL3B885R0*/
		VFACT.syncDataList2View(self,lines,attrLine,true);
	};
	//------------------------------------------------------------------------
	cssVO.showEvent=async function(event){
		/*#{1HLC522DN0Start*/
		let key,value;
		let lines=[];
		/*}#1HLC522DN0Start*/
		
		//GenLines
		/*#{1HLC550F70*/
		for(key in event){
			value=event[key];
			if(typeof(value)!=="object"){
				lines.push({key:key,value:value,icon:null});
			}
		}
		/*}#1HLC550F70*/
		VFACT.syncDataList2View(self,lines,attrLine,true);
	};
	/*#{1HL2BCKSE1PostCSSVO*/
	/*}#1HL2BCKSE1PostCSSVO*/
	return cssVO;
};
/*#{1HL2BCKSE1ExCodes*/
/*}#1HL2BCKSE1ExCodes*/

BoxNodeInfo.gearExport={
	framework: "jax",
	hudType: "hud",
	"showName":"",icon:"gears.svg",previewImg:false,
	fixPose:false,initW:100,initH:100,
	catalog:"",
	args: {},
	state:{
	},
	properties:["id","position","x","y","display"],
	faces:[],
	subContainers:{
	},
	/*#{1HL2BCKSE0ExGearInfo*/
	/*}#1HL2BCKSE0ExGearInfo*/
};
/*#{1HL2BCKSE0EndDoc*/
/*}#1HL2BCKSE0EndDoc*/

export default BoxNodeInfo;
export{BoxNodeInfo};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1HL2BCKSE0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1HL2BCKSE2",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1HL2BCKSE3",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1HL2BCKSE4",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1HL2BCKSE5",
//			"attrs": {}
//		},
//		"localVars": {
//			"jaxId": "1HL2BCKSE6",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1HL2BCKSE7",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HL3B2HCR0",
//					"attrs": {
//						"id": "showInfo",
//						"label": "New AI Seg",
//						"x": "100",
//						"y": "80",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HL3B2HCV0",
//							"attrs": {
//								"page": {
//									"type": "auto",
//									"valText": "null"
//								},
//								"node": {
//									"type": "auto",
//									"valText": "null"
//								}
//							}
//						},
//						"async": "true",
//						"localVars": {
//							"jaxId": "1HL3B2HCV1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": [
//								{
//									"type": "flowseg",
//									"def": "Code",
//									"jaxId": "1HL3B885R0",
//									"attrs": {
//										"id": "GetAttrs",
//										"label": "New AI Seg",
//										"x": "310",
//										"y": "80",
//										"desc": "",
//										"codes": "false",
//										"outlet": {
//											"jaxId": "1HL3B885S0",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											},
//											"linkedSeg": "1HL3B885S1"
//										}
//									}
//								},
//								{
//									"type": "flowseg",
//									"def": "RenderData",
//									"jaxId": "1HL3B885S1",
//									"attrs": {
//										"id": "ShowAttrs",
//										"label": "New AI Seg",
//										"x": "520",
//										"y": "80",
//										"desc": "",
//										"codes": "false",
//										"view": "self",
//										"data": "lines",
//										"uiDef": "attrLine",
//										"clear": "true",
//										"assign": "",
//										"outlet": {
//											"jaxId": "1HL3B885S2",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											}
//										}
//									}
//								}
//							]
//						},
//						"outlet": {
//							"jaxId": "1HL3B2HCV2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1HL3B885R0"
//						}
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HLC522DN0",
//					"attrs": {
//						"id": "showEvent",
//						"label": "New AI Seg",
//						"x": "100",
//						"y": "180",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HLC522DT0",
//							"attrs": {
//								"event": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"localVars": {
//							"jaxId": "1HLC522DT1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": [
//								{
//									"type": "flowseg",
//									"def": "Code",
//									"jaxId": "1HLC550F70",
//									"attrs": {
//										"id": "GenLines",
//										"label": "New AI Seg",
//										"x": "310",
//										"y": "180",
//										"desc": "",
//										"codes": "false",
//										"outlet": {
//											"jaxId": "1HLC550FE0",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											},
//											"linkedSeg": "1HLC550FE1"
//										}
//									}
//								},
//								{
//									"type": "flowseg",
//									"def": "RenderData",
//									"jaxId": "1HLC550FE1",
//									"attrs": {
//										"id": "ShowLines",
//										"label": "New AI Seg",
//										"x": "520",
//										"y": "180",
//										"desc": "",
//										"codes": "false",
//										"view": "self",
//										"data": "lines",
//										"uiDef": "attrLine",
//										"clear": "true",
//										"assign": "",
//										"outlet": {
//											"jaxId": "1HLC550FE2",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											}
//										}
//									}
//								}
//							]
//						},
//						"outlet": {
//							"jaxId": "1HLC522DT2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1HLC550F70"
//						}
//					}
//				}
//			]
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1HL2BCKSE8",
//			"attrs": {}
//		},
//		"mockupStates": {
//			"jaxId": "1HL2BCKSE9",
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1HL2BCKSE1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1HL2BCKSE10",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Relative",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "[0,0,0,5]",
//						"minW": "",
//						"minH": "50",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Flex Y",
//						"itemsAlign": "Start"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "Gear1HL2BLTCM0",
//							"jaxId": "1HL2BUIHK0",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1HL2BVEJG0",
//									"attrs": {
//										"key": "id",
//										"value": "Chat-Messages",
//										"icon": "/~/-tabos/shared/assets/object.svg",
//										"action": "\"go\""
//									}
//								},
//								"properties": {
//									"jaxId": "1HL2BVEJG1",
//									"attrs": {
//										"type": "#null#>BoxAttrLine(\"id\",\"Chat-Messages\",\"/~/-tabos/shared/assets/object.svg\",\"go\")",
//										"id": "",
//										"position": "Relative",
//										"x": "0",
//										"y": "0",
//										"display": "On",
//										"face": ""
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HL2BVEJG2",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1HL2BVEJG3",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HL2BVEJG4",
//									"attrs": {}
//								},
//								"mockup": "true",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false",
//								"containerSlots": {
//									"jaxId": "1HL2BVEJG5",
//									"attrs": {}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear1HL2BLTCM0",
//							"jaxId": "1HL2BVFDB0",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1HL2BVFDB1",
//									"attrs": {
//										"key": "editable",
//										"value": "true",
//										"icon": "/~/-tabos/shared/assets/object.svg",
//										"action": "\"go\""
//									}
//								},
//								"properties": {
//									"jaxId": "1HL2BVFDB2",
//									"attrs": {
//										"type": "#null#>BoxAttrLine(\"editable\",\"true\",\"/~/-tabos/shared/assets/object.svg\",\"go\")",
//										"id": "",
//										"position": "Relative",
//										"x": "0",
//										"y": "0",
//										"display": "On",
//										"face": ""
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HL2BVFDB3",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1HL2BVFDB4",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HL2BVFDB5",
//									"attrs": {}
//								},
//								"mockup": "true",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false",
//								"containerSlots": {
//									"jaxId": "1HL2BVFDB6",
//									"attrs": {}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear1HL2BLTCM0",
//							"jaxId": "1HL2C0O0N0",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1HL2C0O0N1",
//									"attrs": {
//										"key": "edit-id",
//										"value": "user-chat",
//										"icon": "/~/-tabos/shared/assets/object.svg",
//										"action": "\"go\""
//									}
//								},
//								"properties": {
//									"jaxId": "1HL2C0O0N2",
//									"attrs": {
//										"type": "#null#>BoxAttrLine(\"edit-id\",\"user-chat\",\"/~/-tabos/shared/assets/object.svg\",\"go\")",
//										"id": "",
//										"position": "Relative",
//										"x": "0",
//										"y": "0",
//										"display": "On",
//										"face": ""
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HL2C0O0O0",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1HL2C0O0O1",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HL2C0O0O2",
//									"attrs": {}
//								},
//								"mockup": "true",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false",
//								"containerSlots": {
//									"jaxId": "1HL2C0O0O3",
//									"attrs": {}
//								}
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1HL2BCKSE11",
//					"attrs": {}
//				},
//				"functions": {
//					"jaxId": "1HL2BCKSE12",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1HL2BCKSE13",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1HL2BCKSE14",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}