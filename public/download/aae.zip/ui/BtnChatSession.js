//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
/*#{1ILN5P53N0StartDoc*/
/*}#1ILN5P53N0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BtnChatSession=function(frame,prompt,thread){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let boxNotify,boxIcon,txtName,btnMenu;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1ILN5P53N1LocalVals*/
	let isFocused=false;
	/*}#1ILN5P53N1LocalVals*/
	
	/*#{1ILN5P53N1PreState*/
	/*}#1ILN5P53N1PreState*/
	state={
		"icon":appCfg.sharedAssets+"/aichat.svg",
		/*#{1ILN5P53N7ExState*/
		/*}#1ILN5P53N7ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1ILN5P53N1PostState*/
	/*}#1ILN5P53N1PostState*/
	cssVO={
		"hash":"1ILN5P53N1",nameHost:true,
		"type":"button","x":0,"y":0,"w":"100%","h":50,"padding":5,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x","itemsAlign":1,
		"frame":frame,"chatThread":thread,
		children:[
			{
				"hash":"1ILN5Q0MB0",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":[255,255,255,0],"borderColor":cfgColor["fontBodySub"],
			},
			{
				"hash":"1IVBKC56C0",
				"type":"box","id":"BoxNotify","position":"relative","x":0,"y":0,"w":10,"h":10,"display":0,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"background":cfgColor["fontBodyLit"],"corner":10,
			},
			{
				"hash":"1IVBIADKA0",
				"type":"hud","position":"relative","x":0,"y":0,"w":32,"h":32,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				children:[
					{
						"hash":"1ILNCC2H60",
						"type":"box","id":"BoxIcon","position":"relative","x":0,"y":0,"w":32,"h":32,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["fontBody"],
						"maskImage":$P(()=>(state.icon),state),
					}
				],
			},
			{
				"hash":"1ILNCEEK60",
				"type":"hud","position":"relative","x":0,"y":0,"w":100,"h":"100%","padding":5,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","flex":true,
				children:[
					{
						"hash":"1ILNCF5QU0",
						"type":"text","id":"TxtName","position":"relative","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
						"text":prompt,"fontSize":txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,"lineClamp":2,
					}
				],
			},
			{
				"hash":"1IV2SOHEV0",
				"type":BtnIcon("front",30,0,appCfg.sharedAssets+"/menu.svg",null),"id":"BtnMenu","position":"relative","x":0,"y":0,"padding":3,"attached":appCfg.isTouchDevice,
				"OnClick":function(event){
					/*#{1IV54B7CK0FunctionBody*/
					if(self.showMenu){
						self.showMenu(this,event);
					}
					/*}#1IV54B7CK0FunctionBody*/
				},
			}
		],
		/*#{1ILN5P53N1ExtraCSS*/
		isFocused(){
			return isFocused;
		},
		/*}#1ILN5P53N1ExtraCSS*/
		faces:{
			"up":{
				/*#{1ILNCK7CF0PreCode*/
				$(){
					if(isFocused){
						return false;
					}
				},
				/*}#1ILNCK7CF0PreCode*/
				/*BoxBG*/"#1ILN5Q0MB0":{
					"background":[0,0,0,0]
				}
			},"down":{
				/*#{1ILNCKCTO0PreCode*/
				$(){
					if(isFocused){
						return false;
					}
				},
				/*}#1ILNCKCTO0PreCode*/
				/*BoxBG*/"#1ILN5Q0MB0":{
					"background":cfgColor["itemDown"]
				}
			},"over":{
				/*#{1ILNCKKFO0PreCode*/
				$(){
					if(isFocused){
						return false;
					}
				},
				/*}#1ILNCKKFO0PreCode*/
				/*BoxBG*/"#1ILN5Q0MB0":{
					"background":cfgColor["itemOver"]
				}
			},"gray":{
				/*#{1ILNCKO8A0PreCode*/
				$(){
					if(isFocused){
						return false;
					}
				},
				/*}#1ILNCKO8A0PreCode*/
			},"focus":{
				/*BoxBG*/"#1ILN5Q0MB0":{
					"background":cfgColor["hot"],"border":[1,0,1,0]
				},
				/*#{1ILNCKU3B0Code*/
				$(){
					isFocused=true;
					boxNotify.display=false;
					boxNotify.background=cfgColor.fontBodyLit;
				}
				/*}#1ILNCKU3B0Code*/
			},"blur":{
				/*BoxBG*/"#1ILN5Q0MB0":{
					"background":[0,0,0,0],"border":0
				},
				/*#{1ILNCL1HP0Code*/
				$(){
					isFocused=false;
				}
				/*}#1ILNCL1HP0Code*/
			}
		},
		OnCreate:function(){
			self=this;
			boxNotify=self.BoxNotify;boxIcon=self.BoxIcon;txtName=self.TxtName;btnMenu=self.BtnMenu;
			/*#{1ILN5P53N1Create*/
			self.webObj.addEventListener('contextmenu', e => {
				e.preventDefault();
			});
			if(thread){
				if(thread){
					if(thread.state==="shadow"){
						state.icon=appCfg.sharedAssets+"/chat_shadow.svg";
					}else if(thread.state==="host"){
						state.icon=appCfg.sharedAssets+"/aichat.svg";
					}else{
						state.icon=appCfg.sharedAssets+"/chat_sleep.svg";
					}
				}
				
				thread.on("Rename",()=>{
					txtName.text=thread.title;
				});
				
				const OnNewMessage=()=>{
					if(isFocused){
						boxNotify.display=false;
					}else{
						boxNotify.display=true;
					}
				};
				thread.on("NewMessage",OnNewMessage);
				thread.on("PostNewMessage",OnNewMessage);
			
				/*
				thread.on("AskUser",()=>{
					if(!isFocused){
						boxNotify.background=cfgColor.error;
					}
				});*/
				
				thread.on("Offline",()=>{
					state.icon=appCfg.sharedAssets+"/chat_sleep.svg";
				});
			}
			/*}#1ILN5P53N1Create*/
		},
		/*#{1ILN5P53N1EndCSS*/
		/*}#1ILN5P53N1EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.buildFrame=async function(){
		/*#{1IUK5OQ670Start*/
		/*}#1IUK5OQ670Start*/
	};
	/*#{1ILN5P53N1PostCSSVO*/
	cssVO.setName=function(name){
		txtName.text=name;
	}
	/*}#1ILN5P53N1PostCSSVO*/
	cssVO.constructor=BtnChatSession;
	return cssVO;
};
/*#{1ILN5P53N1ExCodes*/
/*}#1ILN5P53N1ExCodes*/

//----------------------------------------------------------------------------
BtnChatSession.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1ILN5P53N1PreAISpot*/
	/*}#1ILN5P53N1PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1ILN5P53N1PostAISpot*/
	/*}#1ILN5P53N1PostAISpot*/
	return exposeVO;
};

/*#{1ILN5P53N0EndDoc*/
/*}#1ILN5P53N0EndDoc*/

export default BtnChatSession;
export{BtnChatSession};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearButton",
//	"jaxId": "1ILN5P53N0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1ILN5P53N2",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1ILN5P53N3",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1ILN5P53N4",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1ILN5P53N5",
//			"attrs": {
//				"frame": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"prompt": {
//					"type": "string",
//					"valText": "Hello!"
//				},
//				"thread": {
//					"type": "auto",
//					"valText": "null"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1ILN5P53N6",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1ILN5P53N7",
//			"attrs": {
//				"icon": {
//					"type": "string",
//					"valText": "#appCfg.sharedAssets+\"/aichat.svg\""
//				}
//			}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IUK5OQ670",
//					"attrs": {
//						"id": "buildFrame",
//						"label": "New AI Seg",
//						"x": "75",
//						"y": "75",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IUK5PLT20",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IUK5PLT21",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IUK5PLT22",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				}
//			]
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1ILN5P53N8",
//			"attrs": {
//				"up": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1ILNCK7CF0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "true",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1ILND0VMG0",
//							"attrs": {}
//						}
//					}
//				},
//				"down": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1ILNCKCTO0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "true",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1ILND0VMG1",
//							"attrs": {}
//						}
//					}
//				},
//				"over": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1ILNCKKFO0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "true",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1ILND0VMG2",
//							"attrs": {}
//						}
//					}
//				},
//				"gray": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1ILNCKO8A0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "true",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1ILND0VMG3",
//							"attrs": {}
//						}
//					}
//				},
//				"focus": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1ILNCKU3B0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1ILND0VMG4",
//							"attrs": {}
//						}
//					}
//				},
//				"blur": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1ILNCL1HP0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1ILND0VMG5",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1ILN5P53N9",
//			"attrs": {
//				"thread": {
//					"type": "mockState",
//					"def": "MockState",
//					"jaxId": "1IUKJAMPE0",
//					"attrs": {
//						"createArgs": {
//							"jaxId": "1ILN5P53N5",
//							"attrs": {
//								"frame": {
//									"type": "auto",
//									"valText": "null"
//								},
//								"prompt": {
//									"type": "string",
//									"valText": "Hello!"
//								}
//							}
//						},
//						"stateObj": {
//							"jaxId": "1ILN5P53N7",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"exposeToAI": "true",
//		"descAI": "",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "button",
//			"jaxId": "1ILN5P53N1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1ILN5P53N10",
//					"attrs": {
//						"type": "button",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "50",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "5",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"enable": "true",
//						"drag": "NA",
//						"contentLayout": "Flex X",
//						"itemsAlign": "Center"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1ILN5Q0MB0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1ILN5QC1N0",
//									"attrs": {
//										"type": "box",
//										"id": "BoxBG",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "[255,255,255,0.00]",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor[\"fontBodySub\"]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1ILN5QC1N1",
//									"attrs": {
//										"1ILNCL1HP0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1ILND0VMG6",
//											"attrs": {
//												"properties": {
//													"jaxId": "1ILND0VMG7",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "[0,0,0,0]"
//														},
//														"border": {
//															"type": "auto",
//															"valText": "0",
//															"editMode": "edges"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1ILNCL1HP0",
//											"faceTagName": "blur"
//										},
//										"1ILNCKCTO0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1ILND0VMG10",
//											"attrs": {
//												"properties": {
//													"jaxId": "1ILND0VMG11",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor[\"itemDown\"]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1ILNCKCTO0",
//											"faceTagName": "down"
//										},
//										"1ILNCK7CF0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1ILND0VMG12",
//											"attrs": {
//												"properties": {
//													"jaxId": "1ILND0VMG13",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "[0,0,0,0]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1ILNCK7CF0",
//											"faceTagName": "up"
//										},
//										"1ILNCKKFO0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1ILND0VMG14",
//											"attrs": {
//												"properties": {
//													"jaxId": "1ILND0VMG15",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor[\"itemOver\"]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1ILNCKKFO0",
//											"faceTagName": "over"
//										},
//										"1ILNCKU3B0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1ILND0VMG16",
//											"attrs": {
//												"properties": {
//													"jaxId": "1ILND0VMG17",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor[\"hot\"]"
//														},
//														"border": {
//															"type": "auto",
//															"valText": "[1,0,1,0]",
//															"editMode": "edges"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1ILNCKU3B0",
//											"faceTagName": "focus"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1ILN5QC1N2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1ILN5QC1N3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1IVBKC56C0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IVBKC56C1",
//									"attrs": {
//										"type": "box",
//										"id": "BoxNotify",
//										"position": "Relative",
//										"x": "0",
//										"y": "0",
//										"w": "10",
//										"h": "10",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "Off",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"fontBodyLit\"]",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "10",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1IVBKC56C2",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1IVBKC56D0",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IVBKC56D1",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1IVBIADKA0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IVBIANBD0",
//									"attrs": {
//										"type": "hud",
//										"id": "",
//										"position": "Relative",
//										"x": "0",
//										"y": "0",
//										"w": "32",
//										"h": "32",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": ""
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1ILNCC2H60",
//											"attrs": {
//												"properties": {
//													"jaxId": "1ILND0VMG18",
//													"attrs": {
//														"type": "box",
//														"id": "BoxIcon",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "32",
//														"h": "32",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "#cfgColor[\"fontBody\"]",
//														"border": "0",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]",
//														"maskImage": "${state.icon},state"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1ILND0VMG19",
//													"attrs": {
//														"1ILNCKCTO0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1ILND0VMG22",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1ILND0VMG23",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1ILNCKCTO0",
//															"faceTagName": "down"
//														},
//														"1ILNCK7CF0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1ILND0VMG24",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1ILND0VMG25",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1ILNCK7CF0",
//															"faceTagName": "up"
//														},
//														"1ILNCKKFO0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1ILND0VMG26",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1ILND0VMG27",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1ILNCKKFO0",
//															"faceTagName": "over"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1ILND0VMG30",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1ILND0VMG31",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "true"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1IVBIANBD1",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1IVBIANBD2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IVBIANBD3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1ILNCEEK60",
//							"attrs": {
//								"properties": {
//									"jaxId": "1ILND0VMG32",
//									"attrs": {
//										"type": "hud",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "5",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"flex": "true"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1ILNCF5QU0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1ILND0VMG33",
//													"attrs": {
//														"type": "text",
//														"id": "TxtName",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBody\"]",
//														"text": "#prompt",
//														"font": "",
//														"fontSize": "#txtSize.smallPlus",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Center",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "2",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1ILND0VMG34",
//													"attrs": {
//														"1ILNCKCTO0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1ILND0VMG37",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1ILND0VMG38",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1ILNCKCTO0",
//															"faceTagName": "down"
//														},
//														"1ILNCK7CF0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1ILND0VMG39",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1ILND0VMG40",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1ILNCK7CF0",
//															"faceTagName": "up"
//														},
//														"1ILNCKKFO0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1ILND0VMG41",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1ILND0VMG42",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1ILNCKKFO0",
//															"faceTagName": "over"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1ILND0VMG45",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1ILND0VMG46",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1ILND0VMG47",
//									"attrs": {
//										"1ILNCKCTO0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1ILND0VMG50",
//											"attrs": {
//												"properties": {
//													"jaxId": "1ILND0VMG51",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1ILNCKCTO0",
//											"faceTagName": "down"
//										},
//										"1ILNCK7CF0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1ILND0VMG52",
//											"attrs": {
//												"properties": {
//													"jaxId": "1ILND0VMG53",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1ILNCK7CF0",
//											"faceTagName": "up"
//										},
//										"1ILNCKKFO0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1ILND0VMG54",
//											"attrs": {
//												"properties": {
//													"jaxId": "1ILND0VMG55",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1ILNCKKFO0",
//											"faceTagName": "over"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1ILND0VMG58",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1ILND0VMG59",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear/@StdUI/ui/BtnIcon.js",
//							"jaxId": "1IV2SOHEV0",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1IV2SP0K30",
//									"attrs": {
//										"style": "\"front\"",
//										"w": "30",
//										"h": "0",
//										"icon": "#appCfg.sharedAssets+\"/menu.svg\"",
//										"colorBG": "null"
//									}
//								},
//								"properties": {
//									"jaxId": "1IV2SP0K31",
//									"attrs": {
//										"type": "#null#>BtnIcon(\"front\",30,0,appCfg.sharedAssets+\"/menu.svg\",null)",
//										"id": "BtnMenu",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"display": "On",
//										"face": "",
//										"padding": "3",
//										"attach": "#appCfg.isTouchDevice"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1IV2SP0K32",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1IV2SP0K33",
//									"attrs": {
//										"OnClick": {
//											"type": "fixedFunc",
//											"jaxId": "1IV54B7CK0",
//											"attrs": {
//												"callArgs": {
//													"jaxId": "1IV54BOQN0",
//													"attrs": {
//														"event": ""
//													}
//												},
//												"seg": ""
//											}
//										}
//									}
//								},
//								"extraPpts": {
//									"jaxId": "1IV2SP0K34",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true",
//								"containerSlots": {
//									"jaxId": "1IV2SP0K35",
//									"attrs": {}
//								}
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1ILN5P53N11",
//					"attrs": {
//						"1ILNCKCTO0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1ILND0VMG62",
//							"attrs": {
//								"properties": {
//									"jaxId": "1ILND0VMG63",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1ILNCKCTO0",
//							"faceTagName": "down"
//						},
//						"1ILNCK7CF0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1ILND0VMG64",
//							"attrs": {
//								"properties": {
//									"jaxId": "1ILND0VMG65",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1ILNCK7CF0",
//							"faceTagName": "up"
//						},
//						"1ILNCKKFO0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1ILND0VMG66",
//							"attrs": {
//								"properties": {
//									"jaxId": "1ILND0VMG67",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1ILNCKKFO0",
//							"faceTagName": "over"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1ILN5P53N12",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1ILN5P53N13",
//					"attrs": {
//						"frame": {
//							"type": "auto",
//							"valText": "#frame"
//						},
//						"chatThread": {
//							"type": "auto",
//							"valText": "#thread"
//						}
//					}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "true",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1ILN5P53N14",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false",
//				"enable": "false",
//				"drag": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}