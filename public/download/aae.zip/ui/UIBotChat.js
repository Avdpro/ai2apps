//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BoxAIChat} from "/@aichat/ui/BoxAIChat.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
import {BtnText} from "/@StdUI/ui/BtnText.js";
/*#{1I7H9JKNH0StartDoc*/
import pathLib from "/@path";
import {tabFS} from "/@tabos";
import {tabNT} from "/@tabos/tabos_nt.js";
import {DlgLogin} from "/@homekit/ui/DlgLogin.js";
import {DlgMenu} from "/@StdUI/ui/DlgMenu.js";
import {DlgFile} from "/@homekit/ui/DlgFile.js";
import {AAFileLib} from "../AAFileLib.js";
import {BoxAIChatBlock} from "/@aichat/ui/BoxAIChatBlock.js";
import {BoxAskUser} from "/@aichat/ui/BoxAskUser.js";
import {BoxChatBubble} from "/@aichat/ui/BoxChatBubble.js";
import {BoxAAChatMessage} from "../ui/BoxAAChatMessage.js";
/*}#1I7H9JKNH0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let UIBotChat=function(user,chatFlow,opts){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let boxChatFrame,boxChats,boxUser,btnAsset,edUserInput,txtInputHint;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1HAMRK4MB1LocalVals*/
	const app=VFACT.app;
	opts=opts||{};
	let chatCallback=null;
	let initVO=null;
	let allowEmptyChat=false;
	let fileLib=new AAFileLib();
	
	const chatIconFix={
		topLine:false,
		iconBorderSize:1,
		iconBorderColor:cfgColor["fontBodyLit"],
		iconBG:cfgColor.body,
		iconColor:cfgColor.fontBodySub,
		iconCorner:100,
		icon:appCfg.sharedAssets+"/agent.svg"
	};
	/*}#1HAMRK4MB1LocalVals*/
	
	/*#{1HAMRK4MB1PreState*/
	//------------------------------------------------------------------------
	async function showPic(path){
	}
	
	//------------------------------------------------------------------------
	async function showChatMsg(msg){
		let msgType,from,role,msgText,assets,text,chatFlow;
		console.log("[UIBotChat.js] Get message:");
		console.log(msg);
		msgType=msg.type;
		chatFlow=msg.chatFlow;
		from=msg.from;
		role=msg.from===user.id?"user":"assistant";
		if(msgType==="Ask"){
			let askType,askVO,func,result,prompt;
			askVO=msg.askVO;
			askType=msg.askType;
			if(true){
				if(boxChats[askType]){
					let replyVO;
					prompt=askVO.prompt||askVO.text;
					/*if(chatFlow){
						askVO.prompt=`[${chatFlow}?${msg.askId}]:\n${prompt}`;
					}else{
						askVO.prompt=`[?${msg.askId}]:\n${prompt}`;
					}*/
					askVO.prompt=`${msg.from}:\n${prompt}`;
					Object.assign(askVO,chatIconFix);
					result=await boxChats[askType](askVO);
					console.log("Ask result:");
					console.log(result);
					replyVO={
						type:"ReplyAsk",
						to:msg.from,
						askId:msg.askId,
						askReq:msg.askReq,
						chatFlow:chatFlow,
						result:result
					};
					await user.sendMessage(replyVO);
				}else{
					console.log("Ask error:");
					console.Error(`Missing askType: ${askType}`);
				}
				//TODO: reply ask:
			}
		}else if(msgType==="ReplyAsk"){
			//TODO: Code this:
		}else{
			let def;
			msgText=msg.content;
			msgText=msgText.text||msgText.result||msgText;
			assets=msg.content.assets;
			if(msgText){
				if(chatFlow && msg.from!==user.id){
					if(msg.chatFlowFinish){
						text=`[ChatFlow: ${chatFlow}, finished]  \n`;
					}else if(chatFlow===msg.id){
						text=`[ChatFlow: ${chatFlow}, created]  \n`;
					}else{
						text=`[ChatFlow: ${chatFlow}, continue]  \n`;
					}
					text+=msgText;
				}else{
					if(chatFlow){
						if(msg.chatFlowFinish){
							text=`[ChatFlow: ${chatFlow}, finished]  \n`;
						}else if(chatFlow===msg.id){
							text=`[ChatFlow: ${chatFlow}, created]  \n`;
						}else{
							text=`[ChatFlow: ${chatFlow}, continue]  \n`;
						}
						text+=msgText;
					}else{
						text=msgText;
					}
				}
				if(text instanceof Object){
				}
				switch(msg.type){
					case "User":
					case "Chat":{
						let def;
						def=BoxAAChatMessage(null,user,msg,false);
						boxChats.appendChatBlock(msg,def);
						break;
					}
					default:{
						let def;
						def=BoxAAChatMessage(null,user,msg,false);
						boxChats.appendChatBlock(msg,def);
					}
				}
			}
		}
	}
	
	/*}#1HAMRK4MB1PreState*/
	state={
		"defAssistant":{
			"colorBG":cfgColor["success"]
		},
		/*#{1HAMRK4MB7ExState*/
		/*}#1HAMRK4MB7ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1HAMRK4MB1PostState*/
	/*}#1HAMRK4MB1PostState*/
	cssVO={
		"hash":"1HAMRK4MB1",nameHost:true,
		"type":"hud","x":"50%","y":0,"w":"100%","h":"100%","anchorX":1,"minW":"","minH":"","maxW":1000,"maxH":"","styleClass":"",
		"chatFlow":chatFlow,
		children:[
			{
				"hash":"1HAMRQ87E0",
				"type":"hud","id":"BoxChatFrame","x":0,"y":0,"w":"100%","h":"100%","overflow":"auto-y","padding":[5,0,60,0],"minW":"","minH":"","maxW":"","maxH":">calc(100% - 30px)",
				"styleClass":"","contentLayout":"flex-y",
				children:[
					{
						"hash":"1I7JT1J570",
						"type":BoxAIChat(),"id":"BoxChats","position":"relative","x":0,"y":0,"w":"100%","h":"",
					}
				],
			},
			{
				"hash":"1HAMROHSE0",
				"type":"box","id":"BoxUser","x":"50%","y":">calc(100% - 10px)","w":">calc(100% - 80px)","h":"","anchorX":1,"anchorY":2,"minW":"","minH":30,"maxW":600,
				"maxH":"","styleClass":"","background":cfgColor["chatInputBG"],"corner":3,"shadow":true,"shadowX":0,"shadowY":1,"shadowBlur":4,"shadowColor":[0,0,0,0.3],
				"contentLayout":"flex-y",
				children:[
					{
						"hash":"1I7IKLE6B0",
						"type":"hud","id":"BoxAssets","position":"relative","x":0,"y":0,"w":"100%","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
					},
					{
						"hash":"1HAMROHSE2",
						"type":"hud","id":"BoxInput","position":"relative","x":0,"y":0,"w":"100%","h":"","padding":[5,10,5,10],"minW":"","minH":20,"maxW":"","maxH":"","styleClass":"",
						"contentLayout":"flex-x","traceSize":true,"itemsAlign":1,
						children:[
							{
								"hash":"1HBHSL4O70",
								"type":"hud","id":"BoxFileBtnsFrame","position":"relative","x":0,"y":0,"w":25,"h":25,"overflow":1,"margin":[0,5,0,0],"minW":"","minH":"","maxW":"",
								"maxH":"","styleClass":"",
								children:[
									{
										"hash":"1HBHSOUU60",
										"type":"hud","id":"BoxButtons","x":0,"y":0,"w":25,"h":25,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
										children:[
											{
												"hash":"1HBHSPMP80",
												"type":BtnIcon("front",25,0,appCfg.sharedAssets+"/asset.svg",null),"id":"BtnAsset","x":"50%","y":"50%","margin":[0,5,0,0],"padding":0,"anchorY":1,
												"autoLayout":true,"anchorX":1,
												"tip":(($ln==="CN")?("添加资料文件"):("Add asset file")),
												"OnClick":function(event){
													/*#{1HBHSPMP94FunctionBody*/
													self.useNativeFile();
													/*}#1HBHSPMP94FunctionBody*/
												},
											}
										],
									}
								],
								"OnMouseInOut":function(isIn,event){
									/*#{1HBHU0P700FunctionBody*/
									if(isIn){
										self.showFace("filemenu");
									}else{
										self.showFace("!filemenu");
									}
									/*}#1HBHU0P700FunctionBody*/
								},
							},
							{
								"hash":"1HAMROHSG7",
								"type":"memo","id":"EdUserInput","position":"relative","x":0,"y":0,"w":">calc(100% - 100px)","h":"","minW":"","minH":20,"maxW":"","maxH":200,"styleClass":"",
								"color":cfgColor["fontBody"],"background":cfgColor["chatInputBG"],"fontSize":txtSize.mid,"outline":0,"border":[0,0,1,0],"borderColor":[0,0,0,0.5],
								"flex":true,
								"OnInput":function(){
									/*#{1HAMROHSG15FunctionBody*/
									txtInputHint.display=!this.text;
									/*}#1HAMROHSG15FunctionBody*/
								},
								"OnKeyDown":function(event){
									/*#{1HAMROHSG17FunctionBody*/
									if(event.code==="Enter"){
										if((!event.isComposing) &&(!event.shiftKey)){
											event.stopPropagation();
											event.preventDefault();
											self.sendChat();
										}
									}
									/*}#1HAMROHSG17FunctionBody*/
								},
							},
							{
								"hash":"1HAMROHSH0",
								"type":BtnIcon("front",30,0,appCfg.sharedAssets+"/arrowup.svg",null),"id":"BtnSend","position":"relative","x":0,"y":0,"margin":[0,0,0,10],"padding":2,
								"autoLayout":true,
								"OnClick":function(event){
									/*#{1HAMROHSH9FunctionBody*/
									self.sendChat();
									/*}#1HAMROHSH9FunctionBody*/
								},
							},
							{
								"hash":"1HAMROHSH13",
								"type":"text","id":"TxtInputHint","x":46,"y":0,"w":100,"h":"100%","uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodyLit"],
								"text":"Input chat message...","fontSize":txtSize.mid,"fontWeight":"normal","fontStyle":"italic","textDecoration":"","alignV":1,
							}
						],
					},
					{
						"hash":"1HAMROHSI11",
						"type":"hud","id":"BoxWait","position":"relative","x":0,"y":0,"w":"100%","h":50,"display":0,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						children:[
							{
								"hash":"1HAMROHSI13",
								"type":"text","x":0,"y":0,"w":"100%","h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodyLit"],"text":"AI is thinking...",
								"fontSize":txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignH":1,"alignV":1,
							},
							{
								"hash":"1HAMROHSJ6",
								"type":BtnText("primary",100,25,"Abort",false,""),"id":"BtnAbort","x":"50%","y":20,"anchorX":1,
								"OnClick":function(event){
									/*#{1HAMROHSJ15FunctionBody*/
									self.abortChat();
									/*}#1HAMROHSJ15FunctionBody*/
								},
							}
						],
					}
				],
			}
		],
		get $$defAssistant(){return state["defAssistant"]},
		set $$defAssistant(v){
			state["defAssistant"]=v;
			/*#{1HAMRK4MB1SetdefAssistant*/
			/*}#1HAMRK4MB1SetdefAssistant*/
		},
		/*#{1HAMRK4MB1ExtraCSS*/
		/*}#1HAMRK4MB1ExtraCSS*/
		faces:{
			"start":{
				/*BoxInput*/"#1HAMROHSE2":{
					"display":0
				},
				/*BoxWait*/"#1HAMROHSI11":{
					"display":0
				}
			},"input":{
				/*BoxInput*/"#1HAMROHSE2":{
					"display":1
				},
				/*BoxWait*/"#1HAMROHSI11":{
					"display":0
				}
			},"wait":{
				/*BoxInput*/"#1HAMROHSE2":{
					"display":0
				},
				/*BoxWait*/"#1HAMROHSI11":{
					"display":1
				}
			},"allowfile":{
				/*BoxFileBtnsFrame*/"#1HBHSL4O70":{
					"display":1
				},
				/*TxtInputHint*/"#1HAMROHSH13":{
					"x":40
				}
			},"!allowfile":{
				/*BoxFileBtnsFrame*/"#1HBHSL4O70":{
					"display":0
				},
				/*TxtInputHint*/"#1HAMROHSH13":{
					"x":18
				}
			}
		},
		OnCreate:function(){
			self=this;
			boxChatFrame=self.BoxChatFrame;boxChats=self.BoxChats;boxUser=self.BoxUser;btnAsset=self.BtnAsset;edUserInput=self.EdUserInput;txtInputHint=self.TxtInputHint;
			/*#{1HAMRK4MB1Create*/
			let blockDef;
			app.boxChats=boxChats;
			edUserInput.text="";
			txtInputHint.display=true;
			self.showFace("start");
			
			if(opts.bubble){
				blockDef=BoxChatBubble;
			}else{
				blockDef=BoxAIChatBlock;
			}
			//Init blocks:
			boxChats.initBlockDef({
				"user":(session,blockVO)=>{
					return blockDef({
						...opts.user,
						//side:"right",icon:appCfg.sharedAssets+"/user.svg",iconBG:cfgColor.success,iconColor:cfgColor.fontPrimary,bgColor:cfgColor.body,textColor:cfgColor.fontBody,
						text:blockVO.text||blockVO.content,buttons:false,top:blockVO.top,image:blockVO.image,audio:blockVO.audio
					},session);
				},
				"greeting":(session,blockVO)=>{
					return blockDef({
						...opts.ai,
						//side:"left",icon:appCfg.sharedAssets+"/faces.svg",iconBG:cfgColor.warning,iconColor:cfgColor.fontPrimary,bgColor:cfgColor.body,textColor:cfgColor.fontBody,
						text:blockVO.text||blockVO.content,buttons:false,top:blockVO.top,image:blockVO.image,audio:blockVO.audio
					},session);
				},
				"assistant":(session,blockVO)=>{
					return blockDef({
						...opts.ai,
						text:blockVO.text||blockVO.content,buttons:true,top:blockVO.top,render:true,image:blockVO.image,audio:blockVO.audio
					},session);
				},
				"wait":(session,blockVO)=>{
					return blockDef({
						...opts.wait,
						text:blockVO.text||blockVO.content,buttons:false,top:blockVO.top,image:blockVO.image,audio:blockVO.audio
					},session);
				},
				"event":(session,blockVO)=>{
					return blockDef({
						...opts.event,
						text:blockVO.text||blockVO.content,buttons:false,top:blockVO.top,image:blockVO.image,audio:blockVO.audio
					},session);
				},
				"system":(session,blockVO)=>{
					return blockDef({
						...opts.event,
						text:blockVO.text||blockVO.content,buttons:false,top:blockVO.top,image:blockVO.image,audio:blockVO.audio
					},session);
				},
				"error":(session,blockVO)=>{
					return blockDef({
						...opts.error,
						text:blockVO.text||blockVO.content,buttons:false,top:blockVO.top,image:blockVO.image,audio:blockVO.audio
					},session);
				},
			},{
				"input":(session,blockVO)=>{
					return BoxAskUser({
						...opts.ask,
						...blockVO
					},session);
				},
				"confirm":(session,blockVO)=>{
					return BoxAskUser({
						...opts.ask,
						...blockVO
					},session);
				},
				"menu":(session,blockVO)=>{
					return BoxAskUser({
						...opts.ask,
						...blockVO
					},session);
				},
				"block":(session,blockVO)=>{
					//TODO: Support role:
					return BoxAskUser({
						...opts.ask,
						...blockVO
					},session);
				},
				"range":(session,blockVO)=>{
					return null;
				},
				"file":(session,blockVO)=>{
					return null;
				},
				"photo":(session,blockVO)=>{
					return null;
				},
				"chatInput":self.chatInput,
				"cancelChatInput":self.cancelChatInput,
			});
			
			self.startChat();
			/*}#1HAMRK4MB1Create*/
		},
		/*#{1HAMRK4MB1EndCSS*/
		/*}#1HAMRK4MB1EndCSS*/
	};
	/*#{1HAMRK4MB1PostCSSVO*/
	
	//------------------------------------------------------------------------
	cssVO.showUI=function(vo){
	};
	
	//------------------------------------------------------------------------
	cssVO.startChat=async function(vo){
		chatFlow.chatUI=self;
		chatFlow.on("NewMessage",(msg)=>{
			showChatMsg(msg);
		});
		self.showFace("input");
		callAfter(()=>{
			edUserInput.focus();
			app.emit("NewChatFlow",chatFlow);
		},200);
	};
	
	//------------------------------------------------------------------------
	cssVO.sendChat=async function(){
		let text,botInfo,botId,msgVO;
		text=edUserInput.text;
		if(!text){
			return;
		}
		botInfo=user.curChatBot;
		botId=botInfo?botInfo.id:"BOT_MASTER";
		//TODO: Add assets?
		msgVO={
			from:user.id,to:botId,type:"Chat",content:text,chatFlow:chatFlow.id
		};
		user.sendMessage(msgVO);		
		edUserInput.text="";
		txtInputHint.display=true;
	};
	
	//------------------------------------------------------------------------
	cssVO.useLocalFile=async function(){
		let path,item;
		path=pathLib.dirname(this.session.entryBot.url);
		if(path.startsWith("/~/")){
			path=path.substring(2);
		}else if(path.startsWith("//")){
			path=path.substring(1);
		}
		item=await app.modalDlg(DlgMenu,{
			hud:self.BtnLocalFile,
			items:[
				{text:(($ln==="CN")?("使用文件路径"):/*EN*/("Use file path")),code:"path"},
				{text:(($ln==="CN")?("使用文件内容"):/*EN*/("Use file content")),code:"content"},
			]
		});
		if(!item){
			return;
		}
	
		path=await app.modalDlg(DlgFile,{
			mode:"open",
			path:path,
			options:{preview:1},
		});
		if(!path){
			return;
		}
		//TODO: Upload file into fileLib, then add file line.
		if(item.code==="path"){
			edUserInput.text+=`\$\{\{file:${path}\}\}`;
		}else{
			let text;
			try{
				text=await tabFS.readFile(path,"utf8");
				edUserInput.text+="\n```\n"+text+"\n```\n";
			}catch(err){
			}
		}
		edUserInput.OnInput();
	};
	
	async function arrayBuffer(file){
		if(file.arrayBuffer){
			return file.arrayBuffer();
		}
		return new Promise((onDone,onError)=>{
			let reader=new FileReader();
			reader.onload=function(event) {
				let arrayBuffer = event.target.result;
				onDone(arrayBuffer);
			};
			reader.readAsArrayBuffer(file);
		})
	}
	
	//------------------------------------------------------------------------
	cssVO.useNativeFile=async function(file){
		let buf,byteAry,text;
		if(!file){
			return;
		}
		try{
			buf=await arrayBuffer(file);
			byteAry = new Uint8Array(buf);
			let enc = new TextDecoder("utf-8");
			text=enc.decode(byteAry);
			//TODO: Upload file into fileLib, then add file line.
			edUserInput.text+="\n```\n"+text+"\n```\n";
			edUserInput.OnInput();
		}catch(err){
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.chatInput=function(vo){
		let pms,text,orgText;
		self.showFace("input");
		orgText=edUserInput.text;
		if(vo.maybeText){
			text=orgText||vo.maybeText;				
		}else{
			text=vo.text;
		}
		edUserInput.text=text||"";
		if(text){
			txtInputHint.display=false;
		}
		allowEmptyChat=vo.allowEmpty||false;
		if(vo.waitInput===false){
			if(text!==orgText){
				edUserInput.focus();
			}
			return;
		}
		edUserInput.focus();
		pms=new Promise((resolve,reject)=>{
			chatCallback=resolve;
		});
		return pms;
	};
	
	//------------------------------------------------------------------------
	cssVO.cancelChatInput=function(){
		let callback;
		callback=chatCallback;
		if(callback){
			chatCallback=null;
			callback(null);
			self.showFace("start");
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.resetChat=async function(){
		//TODO: Code this:
	};
	
	//------------------------------------------------------------------------
	cssVO.clearChats=async function(){
		//TODO: Code this:
	};
	
	//------------------------------------------------------------------------
	cssVO.abortChat=async function(){
		await boxChats.abortChat((($ln==="CN")?("用户终止"):/*EN*/("User abort")));
	};
	/*}#1HAMRK4MB1PostCSSVO*/
	return cssVO;
};
/*#{1HAMRK4MB1ExCodes*/
/*}#1HAMRK4MB1ExCodes*/

UIBotChat.gearExport={
	framework: "jax",
	hudType: "hud",
	"showName":"UIChat",icon:"gears.svg",previewImg:false,
	fixPose:false,initW:500,initH:300,
	catalog:"Views",
	args: {
		"user": {
			"name": "user", "showName": "user", "type": "auto", "key": true, "fixed": true, 
			"initVal": null
		}, 
		"chatFlow": {
			"name": "chatFlow", "showName": "chatFlow", "type": "auto", "key": true, "fixed": true, "initVal": undefined
		}, 
		"opts": {
			"type": "object", "name": "opts", "showName": "opts", "icon": undefined, 
			"def": {
				"attrs": {
					"bubble": {
						"name": "bubble", "showName": "bubble", "type": "bool", "key": true, "fixed": true, "initVal": false
					}, 
					"ai": {
						"type": "object", "name": "ai", "showName": "ai", "icon": undefined, 
						"def": {
							"attrs": {
								"blkColor": {
									"name": "blkColor", "showName": "blkColor", "type": "colorRGBA", "key": true, "fixed": true, 
									"initVal": [0,0,0,0]
								}, 
								"bgColor": {
									"name": "bgColor", "showName": "bgColor", "type": "colorRGBA", "key": true, "fixed": true, 
									"initVal": [0,128,0,1], "initValText": "#cfgColor[\"success\"]"
								}, 
								"icon": {
									"name": "icon", "showName": "icon", "type": "url", "key": true, "fixed": true, "initVal": "/~/-tabos/shared/assets/faces.svg", "initValText": "#appCfg.sharedAssets+\"/faces.svg\""
								}, 
								"pic": {
									"name": "pic", "showName": "pic", "type": "url", "key": true, "fixed": true, "initVal": ""
								}, 
								"textColor": {
									"name": "textColor", "showName": "textColor", "type": "colorRGBA", "key": true, "fixed": true, 
									"initVal": [0,0,0,1], "initValText": "#cfgColor[\"fontBody\"]"
								}, 
								"iconColor": {
									"name": "iconColor", "showName": "iconColor", "type": "colorRGBA", "key": true, "fixed": true, 
									"initVal": [255,255,255,1], "initValText": "#cfgColor[\"fontSuccess\"]"
								}, 
								"side": {
									"name": "side", "showName": "side", "type": "string", "key": true, "fixed": true, "initVal": "left"
								}
							}
						}, 
						"key": true, "fixed": true
					}, 
					"user": {
						"type": "object", "name": "user", "showName": "user", "icon": undefined, 
						"def": {
							"attrs": {
								"blkColor": {
									"name": "blkColor", "showName": "blkColor", "type": "colorRGBA", "key": true, "fixed": true, 
									"initVal": [0,0,0,0]
								}, 
								"bgColor": {
									"name": "bgColor", "showName": "bgColor", "type": "colorRGBA", "key": true, "fixed": true, 
									"initVal": [13,110,253,1], "initValText": "#cfgColor.primary"
								}, 
								"icon": {
									"name": "icon", "showName": "icon", "type": "url", "key": true, "fixed": true, "initVal": "/~/-tabos/shared/assets/user.svg", "initValText": "#appCfg.sharedAssets+\"/user.svg\""
								}, 
								"pic": {
									"name": "pic", "showName": "pic", "type": "url", "key": true, "fixed": true, "initVal": ""
								}, 
								"textColor": {
									"name": "textColor", "showName": "textColor", "type": "colorRGBA", "key": true, "fixed": true, 
									"initVal": [0,0,0,1], "initValText": "#cfgColor[\"fontBody\"]"
								}, 
								"iconColor": {
									"name": "iconColor", "showName": "iconColor", "type": "colorRGBA", "key": true, "fixed": true, 
									"initVal": [255,255,255,1], "initValText": "#cfgColor[\"fontPrimary\"]"
								}, 
								"side": {
									"name": "side", "showName": "side", "type": "string", "key": true, "fixed": true, "initVal": "right"
								}
							}
						}, 
						"key": true, "fixed": true
					}, 
					"wait": {
						"type": "object", "name": "wait", "showName": "wait", "icon": undefined, 
						"def": {
							"attrs": {
								"blkColor": {
									"name": "blkColor", "showName": "blkColor", "type": "colorRGBA", "key": true, "fixed": true, 
									"initVal": [0,0,0,0]
								}, 
								"bgColor": {
									"name": "bgColor", "showName": "bgColor", "type": "colorRGBA", "key": true, "fixed": true, 
									"initVal": [108,117,125,1], "initValText": "#cfgColor[\"secondary\"]"
								}, 
								"icon": {
									"name": "icon", "showName": "icon", "type": "url", "key": true, "fixed": true, "initVal": "/~/-tabos/shared/assets/faces.svg", "initValText": "#appCfg.sharedAssets+\"/faces.svg\""
								}, 
								"pic": {
									"name": "pic", "showName": "pic", "type": "url", "key": true, "fixed": true, "initVal": ""
								}, 
								"textColor": {
									"name": "textColor", "showName": "textColor", "type": "colorRGBA", "key": true, "fixed": true, 
									"initVal": [0,0,0,1], "initValText": "#cfgColor[\"fontBody\"]"
								}, 
								"iconColor": {
									"name": "iconColor", "showName": "iconColor", "type": "colorRGBA", "key": true, "fixed": true, 
									"initVal": [255,255,255,1], "initValText": "#cfgColor[\"fontSecondary\"]"
								}, 
								"side": {
									"name": "side", "showName": "side", "type": "string", "key": true, "fixed": true, "initVal": "left"
								}
							}
						}, 
						"key": true, "fixed": true
					}, 
					"event": {
						"type": "object", "name": "event", "showName": "event", "icon": undefined, 
						"def": {
							"attrs": {
								"blkColor": {
									"name": "blkColor", "showName": "blkColor", "type": "colorRGBA", "key": true, "fixed": true, 
									"initVal": [0,0,0,0]
								}, 
								"bgColor": {
									"name": "bgColor", "showName": "bgColor", "type": "colorRGBA", "key": true, "fixed": true, 
									"initVal": [255,128,12,1], "initValText": "#cfgColor[\"warning\"]"
								}, 
								"icon": {
									"name": "icon", "showName": "icon", "type": "url", "key": true, "fixed": true, "initVal": "/~/-tabos/shared/assets/event.svg", "initValText": "#appCfg.sharedAssets+\"/event.svg\""
								}, 
								"pic": {
									"name": "pic", "showName": "pic", "type": "url", "key": true, "fixed": true, "initVal": ""
								}, 
								"textColor": {
									"name": "textColor", "showName": "textColor", "type": "colorRGBA", "key": true, "fixed": true, 
									"initVal": [0,0,0,1], "initValText": "#cfgColor[\"fontBody\"]"
								}, 
								"iconColor": {
									"name": "iconColor", "showName": "iconColor", "type": "colorRGBA", "key": true, "fixed": true, 
									"initVal": [255,255,255,1], "initValText": "#cfgColor[\"fontWarning\"]"
								}, 
								"side": {
									"name": "side", "showName": "side", "type": "string", "key": true, "fixed": true, "initVal": "left"
								}
							}
						}, 
						"key": true, "fixed": true
					}, 
					"error": {
						"type": "object", "name": "error", "showName": "error", "icon": undefined, 
						"def": {
							"attrs": {
								"blkColor": {
									"name": "blkColor", "showName": "blkColor", "type": "colorRGBA", "key": true, "fixed": true, 
									"initVal": [0,0,0,0]
								}, 
								"bgColor": {
									"name": "bgColor", "showName": "bgColor", "type": "colorRGBA", "key": true, "fixed": true, 
									"initVal": [240,0,0,1], "initValText": "#cfgColor[\"error\"]"
								}, 
								"icon": {
									"name": "icon", "showName": "icon", "type": "url", "key": true, "fixed": true, "initVal": "/~/-tabos/shared/assets/fat_right.svg", "initValText": "#appCfg.sharedAssets+\"/fat_right.svg\""
								}, 
								"pic": {
									"name": "pic", "showName": "pic", "type": "url", "key": true, "fixed": true, "initVal": ""
								}, 
								"textColor": {
									"name": "textColor", "showName": "textColor", "type": "colorRGBA", "key": true, "fixed": true, 
									"initVal": [155,0,0,1]
								}, 
								"iconColor": {
									"name": "iconColor", "showName": "iconColor", "type": "colorRGB", "key": true, "fixed": true, 
									"initVal": [255,255,255,1], "initValText": "#cfgColor[\"fontError\"]"
								}, 
								"side": {
									"name": "side", "showName": "side", "type": "string", "key": true, "fixed": true, "initVal": "left"
								}
							}
						}, 
						"key": true, "fixed": true
					}, 
					"ask": {
						"type": "object", "name": "ask", "showName": "ask", "icon": undefined, 
						"def": {
							"attrs": {
								"blkColor": {
									"name": "blkColor", "showName": "blkColor", "type": "colorRGBA", "key": true, "fixed": true, 
									"initVal": [0,0,0,0]
								}, 
								"bgColor": {
									"name": "bgColor", "showName": "bgColor", "type": "colorRGBA", "key": true, "fixed": true, 
									"initVal": [0,128,0,1], "initValText": "#cfgColor[\"success\"]"
								}, 
								"icon": {
									"name": "icon", "showName": "icon", "type": "url", "key": true, "fixed": true, "initVal": "/~/-tabos/shared/assets/help.svg", "initValText": "#appCfg.sharedAssets+\"/help.svg\""
								}, 
								"pic": {
									"name": "pic", "showName": "pic", "type": "url", "key": true, "fixed": true, "initVal": ""
								}, 
								"textColor": {
									"name": "textColor", "showName": "textColor", "type": "colorRGBA", "key": true, "fixed": true, 
									"initVal": [0,0,0,1], "initValText": "#cfgColor[\"fontBody\"]"
								}, 
								"iconColor": {
									"name": "iconColor", "showName": "iconColor", "type": "colorRGBA", "key": true, "fixed": true, 
									"initVal": [255,255,255,1], "initValText": "#cfgColor[\"fontSuccess\"]"
								}, 
								"side": {
									"name": "side", "showName": "side", "type": "string", "key": true, "fixed": true, "initVal": "left"
								}
							}
						}, 
						"key": true, "fixed": true
					}
				}
			}, 
			"key": true, "fixed": true
		}
	},
	state:{
		defAssistant:{name:"defAssistant",type:"object",initVal:undefined}
	},
	properties:["id","position","x","y","w","h","anchorH","anchorV","autoLayout","display","clip","uiEvent","alpha","rotate","scale","cursor","zIndex","flex","margin","traceSize","padding","minW","minH","maxW","maxH"],
	faces:["start","input","wait","allowfile","!allowfile"],
	subContainers:{
	},
	/*#{1I7H9JKNH0ExGearInfo*/
	/*}#1I7H9JKNH0ExGearInfo*/
};
/*#{1I7H9JKNH0EndDoc*/
/*}#1I7H9JKNH0EndDoc*/

export default UIBotChat;
export{UIBotChat};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1I7H9JKNH0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1HAMRK4MB2",
//			"attrs": {
//				"device": "Desktop 800x600",
//				"screenW": "800",
//				"screenH": "600",
//				"bgColor": "#cfgColor[\"chatBG\"]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1HAMRK4MB3",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1HAMRK4MB4",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1HAMRK4MB5",
//			"attrs": {
//				"user": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"chatFlow": {
//					"type": "auto",
//					"valText": ""
//				},
//				"opts": {
//					"type": "object",
//					"def": "FlatObj",
//					"jaxId": "1HB2CA95A0",
//					"attrs": {
//						"bubble": {
//							"type": "bool",
//							"valText": "false"
//						},
//						"ai": {
//							"type": "object",
//							"def": "FlatObj",
//							"jaxId": "1HB2CA95A1",
//							"attrs": {
//								"blkColor": {
//									"type": "colorRGBA",
//									"valText": "[0,0,0,0.00]"
//								},
//								"bgColor": {
//									"type": "colorRGBA",
//									"valText": "#cfgColor[\"success\"]"
//								},
//								"icon": {
//									"type": "url",
//									"valText": "#appCfg.sharedAssets+\"/faces.svg\""
//								},
//								"pic": {
//									"type": "url",
//									"valText": ""
//								},
//								"textColor": {
//									"type": "colorRGBA",
//									"valText": "#cfgColor[\"fontBody\"]"
//								},
//								"iconColor": {
//									"type": "colorRGBA",
//									"valText": "#cfgColor[\"fontSuccess\"]"
//								},
//								"side": {
//									"type": "string",
//									"valText": "left"
//								}
//							}
//						},
//						"user": {
//							"type": "object",
//							"def": "FlatObj",
//							"jaxId": "1HB2CA95A2",
//							"attrs": {
//								"blkColor": {
//									"type": "colorRGBA",
//									"valText": "[0,0,0,0.00]"
//								},
//								"bgColor": {
//									"type": "colorRGBA",
//									"valText": "#cfgColor.primary"
//								},
//								"icon": {
//									"type": "url",
//									"valText": "#appCfg.sharedAssets+\"/user.svg\""
//								},
//								"pic": {
//									"type": "url",
//									"valText": ""
//								},
//								"textColor": {
//									"type": "colorRGBA",
//									"valText": "#cfgColor[\"fontBody\"]"
//								},
//								"iconColor": {
//									"type": "colorRGBA",
//									"valText": "#cfgColor[\"fontPrimary\"]"
//								},
//								"side": {
//									"type": "string",
//									"valText": "right"
//								}
//							}
//						},
//						"wait": {
//							"type": "object",
//							"def": "FlatObj",
//							"jaxId": "1HB2J3M5P0",
//							"attrs": {
//								"blkColor": {
//									"type": "colorRGBA",
//									"valText": "[0,0,0,0.00]"
//								},
//								"bgColor": {
//									"type": "colorRGBA",
//									"valText": "#cfgColor[\"secondary\"]"
//								},
//								"icon": {
//									"type": "url",
//									"valText": "#appCfg.sharedAssets+\"/faces.svg\""
//								},
//								"pic": {
//									"type": "url",
//									"valText": ""
//								},
//								"textColor": {
//									"type": "colorRGBA",
//									"valText": "#cfgColor[\"fontBody\"]"
//								},
//								"iconColor": {
//									"type": "colorRGBA",
//									"valText": "#cfgColor[\"fontSecondary\"]"
//								},
//								"side": {
//									"type": "string",
//									"valText": "left"
//								}
//							}
//						},
//						"event": {
//							"type": "object",
//							"def": "FlatObj",
//							"jaxId": "1HB2KQCVB0",
//							"attrs": {
//								"blkColor": {
//									"type": "colorRGBA",
//									"valText": "[0,0,0,0.00]"
//								},
//								"bgColor": {
//									"type": "colorRGBA",
//									"valText": "#cfgColor[\"warning\"]"
//								},
//								"icon": {
//									"type": "url",
//									"valText": "#appCfg.sharedAssets+\"/event.svg\""
//								},
//								"pic": {
//									"type": "url",
//									"valText": ""
//								},
//								"textColor": {
//									"type": "colorRGBA",
//									"valText": "#cfgColor[\"fontBody\"]"
//								},
//								"iconColor": {
//									"type": "colorRGBA",
//									"valText": "#cfgColor[\"fontWarning\"]"
//								},
//								"side": {
//									"type": "string",
//									"valText": "left"
//								}
//							}
//						},
//						"error": {
//							"type": "object",
//							"def": "FlatObj",
//							"jaxId": "1HB2KQCVB1",
//							"attrs": {
//								"blkColor": {
//									"type": "colorRGBA",
//									"valText": "[0,0,0,0.00]"
//								},
//								"bgColor": {
//									"type": "colorRGBA",
//									"valText": "#cfgColor[\"error\"]"
//								},
//								"icon": {
//									"type": "url",
//									"valText": "#appCfg.sharedAssets+\"/fat_right.svg\""
//								},
//								"pic": {
//									"type": "url",
//									"valText": ""
//								},
//								"textColor": {
//									"type": "colorRGBA",
//									"valText": "[155,0,0,1.00]"
//								},
//								"iconColor": {
//									"type": "colorRGB",
//									"valText": "#cfgColor[\"fontError\"]"
//								},
//								"side": {
//									"type": "string",
//									"valText": "left"
//								}
//							}
//						},
//						"ask": {
//							"type": "object",
//							"def": "FlatObj",
//							"jaxId": "1HB2KQCVB2",
//							"attrs": {
//								"blkColor": {
//									"type": "colorRGBA",
//									"valText": "[0,0,0,0.00]"
//								},
//								"bgColor": {
//									"type": "colorRGBA",
//									"valText": "#cfgColor[\"success\"]"
//								},
//								"icon": {
//									"type": "url",
//									"valText": "#appCfg.sharedAssets+\"/help.svg\""
//								},
//								"pic": {
//									"type": "url",
//									"valText": ""
//								},
//								"textColor": {
//									"type": "colorRGBA",
//									"valText": "#cfgColor[\"fontBody\"]"
//								},
//								"iconColor": {
//									"type": "colorRGBA",
//									"valText": "#cfgColor[\"fontSuccess\"]"
//								},
//								"side": {
//									"type": "string",
//									"valText": "left"
//								}
//							}
//						}
//					}
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1HAMRK4MB6",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1HAMRK4MB7",
//			"attrs": {
//				"defAssistant": {
//					"type": "object",
//					"def": "Object",
//					"jaxId": "1HAVQG08H0",
//					"attrs": {
//						"colorBG": {
//							"type": "colorRGBA",
//							"valText": "#cfgColor[\"success\"]"
//						}
//					}
//				}
//			}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "UIChat",
//		"gearIcon": "gears.svg",
//		"gearW": "500",
//		"gearH": "300",
//		"gearCatalog": "Views",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1HAMRK4MB8",
//			"attrs": {
//				"start": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HAMS3KJL0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HAMS4K160",
//							"attrs": {}
//						}
//					}
//				},
//				"input": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HAMS4K161",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HAMS4K162",
//							"attrs": {}
//						}
//					}
//				},
//				"wait": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HAMS4K163",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HAMS4K164",
//							"attrs": {}
//						}
//					}
//				},
//				"allowfile": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HBHUAT3S0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HBHUC9450",
//							"attrs": {}
//						}
//					}
//				},
//				"!allowfile": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HBHUBGFH0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HBHUC9451",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1HAMRK4MB9",
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1HAMRK4MB1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1HAMRK4MB10",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "50%",
//						"y": "0",
//						"w": "100%",
//						"h": "100%",
//						"anchorH": "Center",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "1000",
//						"maxH": "",
//						"face": "",
//						"styleClass": ""
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1HAMRQ87E0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HAMRSPCM0",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxChatFrame",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Auto Scroll Y",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "[5,0,60,0]",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "100%-30",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex Y"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "Gear/@aichat/ui/BoxAIChat.js",
//											"jaxId": "1I7JT1J570",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1I7JT2LBV0",
//													"attrs": {}
//												},
//												"properties": {
//													"jaxId": "1I7JT2LBV1",
//													"attrs": {
//														"type": "#null#>BoxAIChat()",
//														"id": "BoxChats",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"w": "100%",
//														"h": ""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I7JT2LBV2",
//													"attrs": {
//														"1HAMS3KJL0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I7M2MP6Q0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I7M2MP6Q1",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAMS3KJL0",
//															"faceTagName": "start"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I7JT2LBV3",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I7JT2LBV4",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1I7JT2LBV5",
//													"attrs": {}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1HAMRSPCM1",
//									"attrs": {
//										"1HAMS4K163": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HCKNT1KN2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HCKNT1KN3",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HAMS4K163",
//											"faceTagName": "wait"
//										},
//										"1HAMS3KJL0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HJQHBT0M2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HJQHBT0M3",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HAMS3KJL0",
//											"faceTagName": "start"
//										},
//										"1HBHUBGFH0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I7JSL4C62",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I7JSL4C63",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HBHUBGFH0",
//											"faceTagName": "!allowfile"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HAMRSPCM2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HAMRSPCM3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1HAMROHSE0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HAMROHSE1",
//									"attrs": {
//										"type": "box",
//										"id": "BoxUser",
//										"position": "Absolute",
//										"x": "50%",
//										"y": "100%-10",
//										"w": "100%-80",
//										"h": "",
//										"anchorH": "Center",
//										"anchorV": "Bottom",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "30",
//										"maxW": "600",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"chatInputBG\"]",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "3",
//										"shadow": "true",
//										"shadowX": "0",
//										"shadowY": "1",
//										"shadowBlur": "4",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.30]",
//										"contentLayout": "Flex Y"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1I7IKLE6B0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I7IKNHNO2",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxAssets",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": ""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I7IKNHNO3",
//													"attrs": {
//														"1HBHUBGFH0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I7JSL4C68",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I7JSL4C69",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HBHUBGFH0",
//															"faceTagName": "!allowfile"
//														},
//														"1HAMS3KJL0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I7M2MP6Q2",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I7M2MP6Q3",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAMS3KJL0",
//															"faceTagName": "start"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I7IKNHNO4",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I7IKNHNO5",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1HAMROHSE2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HAMROHSE3",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxInput",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "[5,10,5,10]",
//														"minW": "",
//														"minH": "20",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex X",
//														"traceSize": "true",
//														"itemsAlign": "Center"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1HBHSL4O70",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HBHT2USB0",
//																	"attrs": {
//																		"type": "hud",
//																		"id": "BoxFileBtnsFrame",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "25",
//																		"h": "25",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "On",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[0,5,0,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "hud",
//																			"jaxId": "1HBHSOUU60",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HBHT2USB1",
//																					"attrs": {
//																						"type": "hud",
//																						"id": "BoxButtons",
//																						"position": "Absolute",
//																						"x": "0",
//																						"y": "0",
//																						"w": "25",
//																						"h": "25",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": ""
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": [
//																						{
//																							"type": "hudobj",
//																							"def": "Gear/@StdUI/ui/BtnIcon.js",
//																							"jaxId": "1HBHSPMP80",
//																							"attrs": {
//																								"createArgs": {
//																									"jaxId": "1HBHSPMP81",
//																									"attrs": {
//																										"style": "\"front\"",
//																										"w": "25",
//																										"h": "0",
//																										"icon": "#appCfg.sharedAssets+\"/asset.svg\"",
//																										"colorBG": "null"
//																									}
//																								},
//																								"properties": {
//																									"jaxId": "1HBHSPMP82",
//																									"attrs": {
//																										"type": "#null#>BtnIcon(\"front\",25,0,appCfg.sharedAssets+\"/asset.svg\",null)",
//																										"id": "BtnAsset",
//																										"position": "Absolute",
//																										"x": "50%",
//																										"y": "50%",
//																										"display": "On",
//																										"face": "",
//																										"margin": "[0,5,0,0]",
//																										"padding": "0",
//																										"anchorV": "Center",
//																										"autoLayout": "true",
//																										"anchorH": "Center"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1HBHSPMP90",
//																									"attrs": {
//																										"1HAMS4K163": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HCKNT1KN8",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HCKNT1KN9",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HAMS4K163",
//																											"faceTagName": "wait"
//																										},
//																										"1HAMS3KJL0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HJQHBT0M6",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HJQHBT0M7",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HAMS3KJL0",
//																											"faceTagName": "start"
//																										},
//																										"1HBHUBGFH0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1I7JSL4C610",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1I7JSL4C611",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HBHUBGFH0",
//																											"faceTagName": "!allowfile"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1HBHSPMP93",
//																									"attrs": {
//																										"OnClick": {
//																											"type": "fixedFunc",
//																											"jaxId": "1HBHSPMP94",
//																											"attrs": {
//																												"callArgs": {
//																													"jaxId": "1HBHSPMP95",
//																													"attrs": {
//																														"event": ""
//																													}
//																												},
//																												"seg": ""
//																											}
//																										}
//																									}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1HBHSPMP96",
//																									"attrs": {
//																										"tip": {
//																											"type": "string",
//																											"valText": "Add asset file",
//																											"localize": {
//																												"EN": "Add asset file",
//																												"CN": "添加资料文件"
//																											},
//																											"localizable": true
//																										}
//																									}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "true",
//																								"containerSlots": {
//																									"jaxId": "1HBHSPMP97",
//																									"attrs": {}
//																								}
//																							}
//																						}
//																					]
//																				},
//																				"faces": {
//																					"jaxId": "1HBHT2USB6",
//																					"attrs": {
//																						"1HAMS4K163": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HCKNT1KN14",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HCKNT1KN15",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAMS4K163",
//																							"faceTagName": "wait"
//																						},
//																						"1HAMS3KJL0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HJQHBT0M10",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HJQHBT0M11",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAMS3KJL0",
//																							"faceTagName": "start"
//																						},
//																						"1HBHUBGFH0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1I7JSL4C614",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1I7JSL4C615",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HBHUBGFH0",
//																							"faceTagName": "!allowfile"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1HBHT2USB7",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1HBHT2USB8",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "false",
//																				"exposeContainer": "false"
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"jaxId": "1HBHT2USB9",
//																	"attrs": {
//																		"1HBHUAT3S0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HBHUC94616",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HBHUC94617",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HBHUAT3S0",
//																			"faceTagName": "allowfile"
//																		},
//																		"1HBHUBGFH0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HBHUC94618",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HBHUC94619",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HBHUBGFH0",
//																			"faceTagName": "!allowfile"
//																		},
//																		"1HAMS4K163": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HCKNT1KN18",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HCKNT1KN19",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAMS4K163",
//																			"faceTagName": "wait"
//																		},
//																		"1HAMS3KJL0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HJQHBT0M12",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HJQHBT0M13",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAMS3KJL0",
//																			"faceTagName": "start"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HBHT2USB10",
//																	"attrs": {
//																		"OnMouseInOut": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HBHU0P700",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1HBHU19670",
//																					"attrs": {
//																						"isIn": "",
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1HBHT2USB11",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false",
//																"exposeContainer": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "memo",
//															"jaxId": "1HAMROHSG7",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAMROHSG8",
//																	"attrs": {
//																		"type": "memo",
//																		"id": "EdUserInput",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%-100",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "20",
//																		"maxW": "",
//																		"maxH": "200",
//																		"face": "",
//																		"styleClass": "",
//																		"text": "",
//																		"color": "#cfgColor[\"fontBody\"]",
//																		"bgColor": "#cfgColor[\"chatInputBG\"]",
//																		"font": "",
//																		"fontSize": "#txtSize.mid",
//																		"outline": "0",
//																		"border": "[0,0,1,0]",
//																		"borderStyle": "Solid",
//																		"borderColor": "[0,0,0,0.5]",
//																		"corner": "0",
//																		"readOnly": "false",
//																		"selectOnFocus": "true",
//																		"spellCheck": "true",
//																		"flex": "true"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HAMROHSG9",
//																	"attrs": {
//																		"1HAMS4K163": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HCKNT1KN20",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HCKNT1KN21",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAMS4K163",
//																			"faceTagName": "wait"
//																		},
//																		"1HAMS3KJL0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HJQHBT0M14",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HJQHBT0M15",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAMS3KJL0",
//																			"faceTagName": "start"
//																		},
//																		"1HBHUBGFH0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I7JSL4C72",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I7JSL4C73",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HBHUBGFH0",
//																			"faceTagName": "!allowfile"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HAMROHSG14",
//																	"attrs": {
//																		"OnInput": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HAMROHSG15",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1HAMROHSG16",
//																					"attrs": {}
//																				},
//																				"seg": ""
//																			}
//																		},
//																		"OnKeyDown": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HAMROHSG17",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1HAMROHSG18",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1HAMROHSG19",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1HAMROHSH0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1HAMROHSH1",
//																	"attrs": {
//																		"style": "\"front\"",
//																		"w": "30",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/arrowup.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1HAMROHSH2",
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"front\",30,0,appCfg.sharedAssets+\"/arrowup.svg\",null)",
//																		"id": "BtnSend",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"margin": "[0,0,0,10]",
//																		"padding": "2",
//																		"anchorV": "Top",
//																		"autoLayout": "true"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HAMROHSH3",
//																	"attrs": {
//																		"1HAMS4K163": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HCKNT1KN22",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HCKNT1KN23",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAMS4K163",
//																			"faceTagName": "wait"
//																		},
//																		"1HAMS3KJL0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HJQHBT0M16",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HJQHBT0M17",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAMS3KJL0",
//																			"faceTagName": "start"
//																		},
//																		"1HBHUBGFH0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I7JSL4C76",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I7JSL4C77",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HBHUBGFH0",
//																			"faceTagName": "!allowfile"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HAMROHSH8",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HAMROHSH9",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1HAMROHSH10",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1HAMROHSH11",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1HAMROHSH12",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1HAMROHSH13",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAMROHSH14",
//																	"attrs": {
//																		"type": "text",
//																		"id": "TxtInputHint",
//																		"position": "Absolute",
//																		"x": "46",
//																		"y": "0",
//																		"w": "100",
//																		"h": "100%",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "Tree Off",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontBodyLit\"]",
//																		"text": "Input chat message...",
//																		"font": "",
//																		"fontSize": "#txtSize.mid",
//																		"bold": "false",
//																		"italic": "true",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Center",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"lineClamp": "0",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HAMROHSH15",
//																	"attrs": {
//																		"1HBHUAT3S0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HBHUC94632",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HBHUC94633",
//																					"attrs": {
//																						"x": {
//																							"type": "length",
//																							"valText": "40"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HBHUAT3S0",
//																			"faceTagName": "allowfile"
//																		},
//																		"1HBHUBGFH0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HBHUC94634",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HBHUC94635",
//																					"attrs": {
//																						"x": {
//																							"type": "length",
//																							"valText": "18"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HBHUBGFH0",
//																			"faceTagName": "!allowfile"
//																		},
//																		"1HAMS4K163": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HCKNT1KN24",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HCKNT1KN25",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAMS4K163",
//																			"faceTagName": "wait"
//																		},
//																		"1HAMS3KJL0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HJQHBT0M18",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HJQHBT0M19",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAMS3KJL0",
//																			"faceTagName": "start"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HAMROHSH20",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HAMROHSH21",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true"
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1HAMROHSI0",
//													"attrs": {
//														"1HAMS3KJL0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAMSKQ1D12",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAMSKQ1D13",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAMS3KJL0",
//															"faceTagName": "start"
//														},
//														"1HAMS4K161": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAMSMGCQ1",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAMSMGCQ2",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAMS4K161",
//															"faceTagName": "input"
//														},
//														"1HAMS4K163": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAMSMS7V12",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAMSMS7V13",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAMS4K163",
//															"faceTagName": "wait"
//														},
//														"1HBHUBGFH0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I7JSL4C712",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I7JSL4C713",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HBHUBGFH0",
//															"faceTagName": "!allowfile"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HAMROHSI9",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HAMROHSI10",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1HAMROHSI11",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HAMROHSI12",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxWait",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "50",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "Off",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": ""
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1HAMROHSI13",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAMROHSI14",
//																	"attrs": {
//																		"type": "text",
//																		"id": "",
//																		"position": "Absolute",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "20",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontBodyLit\"]",
//																		"text": "AI is thinking...",
//																		"font": "",
//																		"fontSize": "#txtSize.smallPlus",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Center",
//																		"alignV": "Center",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"lineClamp": "0",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HAMROHSI15",
//																	"attrs": {
//																		"1HAMS4K163": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HCKNT1KN26",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HCKNT1KN27",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAMS4K163",
//																			"faceTagName": "wait"
//																		},
//																		"1HAMS3KJL0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HJQHBT0M20",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HJQHBT0M21",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAMS3KJL0",
//																			"faceTagName": "start"
//																		},
//																		"1HBHUBGFH0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I7JSL4C716",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I7JSL4C717",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HBHUBGFH0",
//																			"faceTagName": "!allowfile"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HAMROHSJ4",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HAMROHSJ5",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnText.js",
//															"jaxId": "1HAMROHSJ6",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1HAMROHSJ7",
//																	"attrs": {
//																		"style": "primary",
//																		"w": "100",
//																		"h": "25",
//																		"text": "Abort",
//																		"outlined": "false",
//																		"icon": ""
//																	}
//																},
//																"properties": {
//																	"jaxId": "1HAMROHSJ8",
//																	"attrs": {
//																		"type": "#null#>BtnText(\"primary\",100,25,\"Abort\",false,\"\")",
//																		"id": "BtnAbort",
//																		"position": "Absolute",
//																		"x": "50%",
//																		"y": "20",
//																		"display": "On",
//																		"face": "",
//																		"anchorH": "Center"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HAMROHSJ9",
//																	"attrs": {
//																		"1HAMS4K163": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HCKNT1KN28",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HCKNT1KN29",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAMS4K163",
//																			"faceTagName": "wait"
//																		},
//																		"1HAMS3KJL0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HJQHBT0M22",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HJQHBT0M23",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAMS3KJL0",
//																			"faceTagName": "start"
//																		},
//																		"1HBHUBGFH0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I7JSL4C720",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I7JSL4C721",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HBHUBGFH0",
//																			"faceTagName": "!allowfile"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HAMROHSJ14",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HAMROHSJ15",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1HAMROHSJ16",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1HAMROHSJ17",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1HAMROHSJ18",
//																	"attrs": {
//																		"Slot1H2F6U36O0": {
//																			"jaxId": "1HAMROHSJ19",
//																			"attrs": {
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"container": "true"
//																			}
//																		}
//																	}
//																}
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1HAMROHSJ20",
//													"attrs": {
//														"1HAMS3KJL0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAMSKQ1D18",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAMSKQ1D19",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAMS3KJL0",
//															"faceTagName": "start"
//														},
//														"1HAMS4K161": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAMSMGCQ7",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAMSMGCQ8",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAMS4K161",
//															"faceTagName": "input"
//														},
//														"1HAMS4K163": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAMSMS7V18",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAMSMS7V19",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAMS4K163",
//															"faceTagName": "wait"
//														},
//														"1HBHUBGFH0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I7JSL4C724",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I7JSL4C725",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HBHUBGFH0",
//															"faceTagName": "!allowfile"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HAMROHSJ29",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HAMROHSJ30",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1HAMROHSJ31",
//									"attrs": {
//										"1HAMS4K163": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HCKNT1KO0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HCKNT1KO1",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HAMS4K163",
//											"faceTagName": "wait"
//										},
//										"1HAMS3KJL0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HJQHBT0M24",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HJQHBT0M25",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HAMS3KJL0",
//											"faceTagName": "start"
//										},
//										"1HBHUBGFH0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I7JSL4C728",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I7JSL4C729",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HBHUBGFH0",
//											"faceTagName": "!allowfile"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HAMROHSJ36",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HAMROHSJ37",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1HAMRK4MB11",
//					"attrs": {
//						"1HAMS4K163": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HCKNT1KO2",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HCKNT1KO3",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HAMS4K163",
//							"faceTagName": "wait"
//						},
//						"1HAMS3KJL0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HJQHBT0M26",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HJQHBT0M27",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HAMS3KJL0",
//							"faceTagName": "start"
//						},
//						"1HBHUBGFH0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1I7JSL4C732",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I7JSL4C733",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HBHUBGFH0",
//							"faceTagName": "!allowfile"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1HAMRK4MB12",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1HAMRK4MB13",
//					"attrs": {
//						"chatFlow": {
//							"type": "auto",
//							"valText": "#chatFlow"
//						}
//					}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "true",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1HAMRK4MB14",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "true",
//				"h": "true",
//				"anchorH": "true",
//				"anchorV": "true",
//				"autoLayout": "true",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "true",
//				"uiEvent": "true",
//				"alpha": "true",
//				"rotate": "true",
//				"scale": "true",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "true",
//				"zIndex": "true",
//				"flex": "true",
//				"margin": "true",
//				"traceSize": "true",
//				"padding": "true",
//				"minW": "true",
//				"minH": "true",
//				"maxW": "true",
//				"maxH": "true",
//				"styleClass": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": [
//				{
//					"type": "string",
//					"valText": "defAssistant"
//				}
//			]
//		}
//	}
//}