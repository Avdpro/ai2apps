//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnText} from "/@StdUI/ui/BtnText.js";
import {DataView} from "/@StdUI/ui/DataView.js";
/*#{1I2ENG3KV0StartDoc*/
/*}#1I2ENG3KV0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BoxBot=function(bot){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let boxInfo,dvInfo,btnChat,btnConfig,btnStartBot,btnStopBot;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1I2ENG3KV1LocalVals*/
	const app=VFACT.app;
	/*}#1I2ENG3KV1LocalVals*/
	
	/*#{1I2ENG3KV1PreState*/
	/*}#1I2ENG3KV1PreState*/
	state={
		"name":"Bot","alias":"ALICE","active":false,
		/*#{1I2ENG3L05ExState*/
		/*}#1I2ENG3L05ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1I2ENG3KV1PostState*/
	/*}#1I2ENG3KV1PostState*/
	cssVO={
		"hash":"1I2ENG3KV1",nameHost:true,
		"type":"hud","x":0,"y":0,"w":"100%","h":"","margin":[0,0,10,0],"padding":[10,10,10,20],"minW":"","minH":"","maxW":500,"maxH":"","styleClass":"","contentLayout":"flex-y",
		"itemsAlign":1,
		children:[
			{
				"hash":"1I2ENH0050",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["body"],
				"border":1,"borderColor":cfgColor["fontBodySub"],"corner":12,"contentLayout":"flex-x",
			},
			{
				"hash":"1I2ENRF130",
				"type":"hud","id":"BoxInfo","position":"relative","x":0,"y":0,"w":"100%","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
				"itemsAlign":1,
				children:[
					{
						"hash":"1I2ES6C850",
						"type":"hud","id":"BoxIcon","position":"relative","x":0,"y":0,"w":60,"h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
						"itemsAlign":1,"subAlign":1,
						children:[
							{
								"hash":"1I2ES6M290",
								"type":"box","id":"BoxIcon","position":"relative","x":0,"y":0,"w":60,"h":60,"margin":[0,0,5,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
								"background":cfgColor["fontBodySub"],"maskImage":appCfg.sharedAssets+"/agent.svg",
							},
							{
								"hash":"1I2ES86880",
								"type":BtnText("front",60,20,(($ln==="CN")?("刷新状态"):("Refresh")),true,""),"id":"BtnRefresh","position":"relative","x":0,"y":0,
								"OnClick":function(event){
									self.updateState(this,event);
								},
							}
						],
					},
					{
						"hash":"1I2ENS6BE0",
						"type":"hud","id":"BoxState","position":"relative","x":0,"y":0,"w":">calc(100% - 180px)","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						"contentLayout":"flex-y",
						children:[
							{
								"hash":"1I2EO0KJS0",
								"type":DataView(null,null,null,"",{"titleHeight":30,"titleSize":18,"titleColor":cfgColor["fontBody"],"titleBold":true,"lineHeight":20,"lineGap":5,"labelSize":12,"labelColor":cfgColor["fontBodySub"],"labelBold":true,"labelLine":false,"valueSize":14,"valueColor":cfgColor["fontBody"],"valueBold":true,"segHeight":20,"segSize":14,"segBold":true,"segColor":cfgColor["fontBody"],"trace":false,"edit":false,"noteSize":12,"autoCollapse":false,"hideCollapse":false,"valueRightAlign":false,"gridLine":false},""),
								"id":"DvInfo","position":"relative","x":0,"y":0,
							}
						],
					},
					{
						"hash":"1I2EROP020",
						"type":"hud","id":"BoxButtons","position":"relative","x":0,"y":0,"w":120,"h":"100%","minW":"","minH":80,"maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
						"subAlign":1,"itemsAlign":1,
						children:[
							{
								"hash":"1IDUGSEBN0",
								"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":100,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
								"itemsAlign":1,"subAlign":1,
								children:[
									{
										"hash":"1IDUGSJLO0",
										"type":BtnText("primary",100,24,(($ln==="CN")?("与节点对话"):("Chat with Node")),false,""),"id":"BtnChat","position":"relative","x":0,"y":0,"margin":[0,0,10,0],
										"OnClick":function(event){
											self.startChat(this,event);
										},
									},
									{
										"hash":"1IDUGT2LA0",
										"type":BtnText("secondary",100,24,(($ln==="CN")?("配置节点"):("Configure Node")),false,""),"id":"BtnConfig","position":"relative","x":0,"y":0,"margin":[0,0,10,0],
										"enable":false,
									},
									{
										"hash":"1IDUGT6H10",
										"type":BtnText("success",100,24,(($ln==="CN")?("启动节点"):("Start Node")),false,""),"id":"BtnStartBot","position":"relative","x":0,"y":0,
										"OnClick":function(event){
											self.startNode(this,event);
										},
									},
									{
										"hash":"1IDUGT8UT0",
										"type":BtnText("warning",100,24,(($ln==="CN")?("停止节点"):("Stop Node")),false,""),"id":"BtnStopBot","position":"relative","x":0,"y":0,"display":0,
										"OnClick":function(event){
											self.stopNode(this,event);
										},
									}
								],
							},
							{
								"hash":"1IDUGQ32O0",
								"type":"text","position":"relative","x":0,"y":0,"w":"100%","h":"","display":0,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodySub"],
								"text":(($ln==="CN")?("操作中..."):("Working...")),"fontSize":txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignH":1,
							}
						],
					}
				],
			},
			{
				"hash":"1I2EPLLSK0",
				"type":"hud","id":"BoxState","position":"relative","x":0,"y":0,"w":"100%","h":"","display":0,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"contentLayout":"flex-y",
				children:[
					{
						"hash":"1I2EPND3O0",
						"type":DataView(null,"1I2C843JD0",null,"",{"titleHeight":30,"titleSize":18,"titleColor":cfgColor["fontBody"],"titleBold":true,"lineHeight":20,"lineGap":5,"labelSize":12,"labelColor":cfgColor["fontBody"],"labelBold":true,"labelLine":false,"valueSize":14,"valueColor":cfgColor["fontBody"],"valueBold":true,"segHeight":20,"segSize":14,"segBold":true,"segColor":cfgColor["fontBody"],"trace":false,"edit":false,"noteSize":12,"autoCollapse":false,"hideCollapse":false,"valueRightAlign":false,"gridLine":false},""),
						"id":"DvState","position":"relative","x":0,"y":0,
					}
				],
			}
		],
		/*#{1I2ENG3KV1ExtraCSS*/
		/*}#1I2ENG3KV1ExtraCSS*/
		faces:{
			"info":{
				/*BoxState*/"#1I2EPLLSK0":{
					"display":0
				}
			},"state":{
				/*#{1I2ENO5H80PreCode*/
				/*}#1I2ENO5H80PreCode*/
				/*BoxState*/"#1I2EPLLSK0":{
					"display":1
				}
			},"over":{
				/*BoxBG*/"#1I2ENH0050":{
					"border":2
				}
			},"!over":{
				/*BoxBG*/"#1I2ENH0050":{
					"border":1
				}
			},"working":{
				"#1IDUGSEBN0":{
					"display":0
				},
				"#1IDUGQ32O0":{
					"display":1
				}
			},"!working":{
				"#1IDUGSEBN0":{
					"display":1
				},
				"#1IDUGQ32O0":{
					"display":0
				}
			}
		},
		OnCreate:function(){
			self=this;
			boxInfo=self.BoxInfo;dvInfo=self.DvInfo;btnChat=self.BtnChat;btnConfig=self.BtnConfig;btnStartBot=self.BtnStartBot;btnStopBot=self.BtnStopBot;
			/*#{1I2ENG3KV1Create*/
			self.showState();
			/*}#1I2ENG3KV1Create*/
		},
		/*#{1I2ENG3KV1EndCSS*/
		/*}#1I2ENG3KV1EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.showState=async function(){
		/*#{1IDUDF41G0Start*/
		dvInfo.setObject("BotInfo",bot);
		if(bot.state.chatEntry){
			btnChat.enable=true;
		}else{
			btnChat.enable=false;
		}
		if(bot.active){
			btnStopBot.display=true;
			btnStartBot.display=false;
		}else{
			btnStartBot.display=true;
			btnStopBot.display=false;
		}
		if(bot.external){
			btnStartBot.enable=false;
		}else{
			btnStartBot.enable=true;
		}
		/*}#1IDUDF41G0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.updateState=async function(sender,event){
		/*#{1IDUHUQ6I0Start*/
		self.showFace("working");
		await bot.updateState();
		self.showState();
		self.showFace("!working");
		/*}#1IDUHUQ6I0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.startNode=async function(){
		/*#{1IDUHV9EG0Start*/
		self.showFace("working");
		await bot.startNode({});
		await sleep(2000);
		await bot.updateState();
		self.showState();
		self.showFace("!working");
		/*}#1IDUHV9EG0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.stopNode=async function(){
		/*#{1IDUHVHV00Start*/
		self.showFace("working");
		await bot.stopNode({});
		await sleep(2000);
		await bot.updateState();
		self.showState();
		self.showFace("!working");
		/*}#1IDUHVHV00Start*/
	};
	//------------------------------------------------------------------------
	cssVO.startChat=async function(){
		/*#{1IDUHVPFI0Start*/
		bot.startChat(app);
		/*}#1IDUHVPFI0Start*/
	};
	/*#{1I2ENG3KV1PostCSSVO*/
	/*}#1I2ENG3KV1PostCSSVO*/
	cssVO.constructor=BoxBot;
	return cssVO;
};
/*#{1I2ENG3KV1ExCodes*/
/*}#1I2ENG3KV1ExCodes*/

//----------------------------------------------------------------------------
BoxBot.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1I2ENG3KV1PreAISpot*/
	/*}#1I2ENG3KV1PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1I2ENG3KV1PostAISpot*/
	/*}#1I2ENG3KV1PostAISpot*/
	return exposeVO;
};

/*#{1I2ENG3KV0EndDoc*/
/*}#1I2ENG3KV0EndDoc*/

export default BoxBot;
export{BoxBot};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1I2ENG3KV0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1I2ENG3L00",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "600",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1I2ENG3L01",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1I2ENG3L02",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1I2ENG3L03",
//			"attrs": {
//				"bot": {
//					"type": "auto",
//					"valText": "null"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1I2ENG3L04",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1I2ENG3L05",
//			"attrs": {
//				"name": {
//					"type": "string",
//					"valText": "Bot"
//				},
//				"alias": {
//					"type": "string",
//					"valText": "ALICE"
//				},
//				"active": {
//					"type": "bool",
//					"valText": "false"
//				}
//			}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IDUDF41G0",
//					"attrs": {
//						"id": "showState",
//						"label": "New AI Seg",
//						"x": "80",
//						"y": "85",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IDUDGJAO0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IDUDGJAO1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IDUDGJAO2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IDUHUQ6I0",
//					"attrs": {
//						"id": "updateState",
//						"label": "New AI Seg",
//						"x": "80",
//						"y": "170",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IDUI0QT50",
//							"attrs": {
//								"sender": {
//									"valText": "null"
//								},
//								"event": {
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IDUI0QT51",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IDUI0QT52",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IDUHV9EG0",
//					"attrs": {
//						"id": "startNode",
//						"label": "New AI Seg",
//						"x": "80",
//						"y": "255",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IDUI0QT53",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IDUI0QT54",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IDUI0QT55",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IDUHVHV00",
//					"attrs": {
//						"id": "stopNode",
//						"label": "New AI Seg",
//						"x": "80",
//						"y": "345",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IDUI0QT56",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IDUI0QT57",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IDUI0QT58",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IDUHVPFI0",
//					"attrs": {
//						"id": "startChat",
//						"label": "New AI Seg",
//						"x": "80",
//						"y": "435",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IDUI0QT59",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IDUI0QT510",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IDUI0QT511",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					}
//				}
//			]
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1I2ENG3L06",
//			"attrs": {
//				"info": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1I2ENNOI00",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1I2ENTD7U0",
//							"attrs": {}
//						}
//					}
//				},
//				"state": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1I2ENO5H80",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "true",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1I2ENTD7U1",
//							"attrs": {}
//						}
//					}
//				},
//				"over": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1I2EOPDKQ0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1I2EOVIA80",
//							"attrs": {}
//						}
//					}
//				},
//				"!over": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1I2EOTJ050",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1I2EOVIA90",
//							"attrs": {}
//						}
//					}
//				},
//				"working": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IDUGUVL30",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IDUGVOVQ0",
//							"attrs": {}
//						}
//					}
//				},
//				"!working": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IDUGV3TH0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IDUGVOVQ1",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1I2ENG3L07",
//			"attrs": {}
//		},
//		"exposeToAI": "true",
//		"descAI": "",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1I2ENG3KV1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1I2ENG3L08",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "[0,0,10,0]",
//						"padding": "[10,10,10,20]",
//						"minW": "",
//						"minH": "",
//						"maxW": "500",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Flex Y",
//						"itemsAlign": "Center"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1I2ENH0050",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I2ENH46J0",
//									"attrs": {
//										"type": "box",
//										"id": "BoxBG",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"body\"]",
//										"border": "1",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor[\"fontBodySub\"]",
//										"corner": "12",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"contentLayout": "Flex X"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1I2ENH46J1",
//									"attrs": {
//										"1I2EOTJ050": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I2EOVIA91",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I2EOVIA92",
//													"attrs": {
//														"border": {
//															"type": "auto",
//															"valText": "1",
//															"editMode": "edges"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I2EOTJ050",
//											"faceTagName": "!over"
//										},
//										"1I2EOPDKQ0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I2EOVIA93",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I2EOVIA94",
//													"attrs": {
//														"border": {
//															"type": "auto",
//															"valText": "2",
//															"editMode": "edges"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I2EOPDKQ0",
//											"faceTagName": "over"
//										},
//										"1I2ENO5H80": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IDUDGJAO3",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IDUDGJAO4",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I2ENO5H80",
//											"faceTagName": "state"
//										},
//										"1IDUGUVL30": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IDUGVOVQ4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IDUGVOVQ5",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IDUGUVL30",
//											"faceTagName": "working"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1I2ENH46J2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1I2ENH46J3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1I2ENRF130",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I2ENTD7U2",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxInfo",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex X",
//										"itemsWrap": "No Wrap",
//										"itemsAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1I2ES6C850",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I2ES6C851",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxIcon",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "60",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex Y",
//														"itemsAlign": "Center",
//														"subAlign": "Center"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "box",
//															"jaxId": "1I2ES6M290",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I2ES6M291",
//																	"attrs": {
//																		"type": "box",
//																		"id": "BoxIcon",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "60",
//																		"h": "60",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[0,0,5,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"background": "#cfgColor[\"fontBodySub\"]",
//																		"border": "0",
//																		"borderStyle": "Solid",
//																		"borderColor": "[0,0,0,1.00]",
//																		"corner": "0",
//																		"shadow": "false",
//																		"shadowX": "2",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowSpread": "0",
//																		"shadowColor": "[0,0,0,0.50]",
//																		"maskImage": "#appCfg.sharedAssets+\"/agent.svg\""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1I2ES6M2A0",
//																	"attrs": {
//																		"1I2EOPDKQ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I2ES6M2A1",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I2ES6M2A2",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I2EOPDKQ0",
//																			"faceTagName": "over"
//																		},
//																		"1I2ENO5H80": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IDUDGJAP0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IDUDGJAP1",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I2ENO5H80",
//																			"faceTagName": "state"
//																		},
//																		"1I2EOTJ050": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IDUDGJAP2",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IDUDGJAP3",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I2EOTJ050",
//																			"faceTagName": "!over"
//																		},
//																		"1IDUGUVL30": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IDUGVOVR2",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IDUGVOVR3",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IDUGUVL30",
//																			"faceTagName": "working"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1I2ES6M2A5",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1I2ES6M2A6",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnText.js",
//															"jaxId": "1I2ES86880",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1I2ES86881",
//																	"attrs": {
//																		"style": "front",
//																		"w": "60",
//																		"h": "20",
//																		"text": {
//																			"type": "string",
//																			"valText": "Refresh",
//																			"localize": {
//																				"EN": "Refresh",
//																				"CN": "刷新状态"
//																			},
//																			"localizable": true
//																		},
//																		"outlined": "true",
//																		"icon": ""
//																	}
//																},
//																"properties": {
//																	"jaxId": "1I2ES86882",
//																	"attrs": {
//																		"type": "#null#>BtnText(\"front\",60,20,(($ln===\"CN\")?(\"刷新状态\"):(\"Refresh\")),true,\"\")",
//																		"id": "BtnRefresh",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1I2ES86883",
//																	"attrs": {
//																		"1I2ENO5H80": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IDUDGJAP4",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IDUDGJAP5",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I2ENO5H80",
//																			"faceTagName": "state"
//																		},
//																		"1I2EOPDKQ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IDUDGJAP6",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IDUDGJAP7",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I2EOPDKQ0",
//																			"faceTagName": "over"
//																		},
//																		"1I2EOTJ050": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IDUDGJAP8",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IDUDGJAP9",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I2EOTJ050",
//																			"faceTagName": "!over"
//																		},
//																		"1IDUGUVL30": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IDUGVOVR6",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IDUGVOVR7",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IDUGUVL30",
//																			"faceTagName": "working"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1I2ES86884",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1IDUI0QT512",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1IDUI0QT513",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": "1IDUHUQ6I0"
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1I2ES86885",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1I2ES86886",
//																	"attrs": {
//																		"Slot1H2F6U36O0": {
//																			"jaxId": "1I2ES86887",
//																			"attrs": {
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"container": "true"
//																			}
//																		}
//																	}
//																}
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1I2ES6C860",
//													"attrs": {
//														"1I2ENO5H80": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IDUDGJAP10",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IDUDGJAP11",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I2ENO5H80",
//															"faceTagName": "state"
//														},
//														"1I2EOPDKQ0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IDUDGJAP12",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IDUDGJAP13",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I2EOPDKQ0",
//															"faceTagName": "over"
//														},
//														"1I2EOTJ050": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IDUDGJAP14",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IDUDGJAP15",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I2EOTJ050",
//															"faceTagName": "!over"
//														},
//														"1IDUGUVL30": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IDUGVOVR10",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IDUGVOVR11",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IDUGUVL30",
//															"faceTagName": "working"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I2ES6C861",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I2ES6C862",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1I2ENS6BE0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I2ENS6BE1",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxState",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%-180",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex Y"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/DataView.js",
//															"jaxId": "1I2EO0KJS0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1I2EO304E0",
//																	"attrs": {
//																		"box": "null",
//																		"template": "null",
//																		"dataObj": "null",
//																		"property": "",
//																		"options": {
//																			"jaxId": "1I2EO304E1",
//																			"attrs": {
//																				"titleHeight": "30",
//																				"titleSize": "18",
//																				"titleColor": "#cfgColor[\"fontBody\"]",
//																				"titleBold": "true",
//																				"lineHeight": "20",
//																				"lineGap": "5",
//																				"labelSize": "12",
//																				"labelColor": "#cfgColor[\"fontBodySub\"]",
//																				"labelBold": "true",
//																				"labelLine": "false",
//																				"valueSize": "14",
//																				"valueColor": "#cfgColor[\"fontBody\"]",
//																				"valueBold": "true",
//																				"segHeight": "20",
//																				"segSize": "14",
//																				"segBold": "true",
//																				"segColor": "#cfgColor[\"fontBody\"]",
//																				"trace": "false",
//																				"edit": "false",
//																				"noteSize": "12",
//																				"autoCollapse": "false",
//																				"hideCollapse": "false",
//																				"valueRightAlign": "false",
//																				"gridLine": "false"
//																			}
//																		},
//																		"title": ""
//																	}
//																},
//																"properties": {
//																	"jaxId": "1I2EO304E2",
//																	"attrs": {
//																		"type": "#null#>DataView(null,null,null,\"\",{\"titleHeight\":30,\"titleSize\":18,\"titleColor\":cfgColor[\"fontBody\"],\"titleBold\":true,\"lineHeight\":20,\"lineGap\":5,\"labelSize\":12,\"labelColor\":cfgColor[\"fontBodySub\"],\"labelBold\":true,\"labelLine\":false,\"valueSize\":14,\"valueColor\":cfgColor[\"fontBody\"],\"valueBold\":true,\"segHeight\":20,\"segSize\":14,\"segBold\":true,\"segColor\":cfgColor[\"fontBody\"],\"trace\":false,\"edit\":false,\"noteSize\":12,\"autoCollapse\":false,\"hideCollapse\":false,\"valueRightAlign\":false,\"gridLine\":false},\"\")",
//																		"id": "DvInfo",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1I2EO304E3",
//																	"attrs": {
//																		"1I2EOPDKQ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I2EOVIA97",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I2EOVIA98",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I2EOPDKQ0",
//																			"faceTagName": "over"
//																		},
//																		"1I2ENO5H80": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IDUDGJAP16",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IDUDGJAP17",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I2ENO5H80",
//																			"faceTagName": "state"
//																		},
//																		"1I2EOTJ050": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IDUDGJAP18",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IDUDGJAP19",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I2EOTJ050",
//																			"faceTagName": "!over"
//																		},
//																		"1IDUGUVL30": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IDUGVOVR14",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IDUGVOVR15",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IDUGUVL30",
//																			"faceTagName": "working"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1I2EO304E4",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1I2EO304E5",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1I2EO304E6",
//																	"attrs": {}
//																}
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1I2ENS6BF0",
//													"attrs": {
//														"1I2EOPDKQ0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I2EOVIA99",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I2EOVIA910",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I2EOPDKQ0",
//															"faceTagName": "over"
//														},
//														"1I2ENO5H80": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IDUDGJAP20",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IDUDGJAP21",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I2ENO5H80",
//															"faceTagName": "state"
//														},
//														"1I2EOTJ050": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IDUDGJAP22",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IDUDGJAP23",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I2EOTJ050",
//															"faceTagName": "!over"
//														},
//														"1IDUGUVL30": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IDUGVOVR18",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IDUGVOVR19",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IDUGUVL30",
//															"faceTagName": "working"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I2ENS6BF1",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I2ENS6BF2",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1I2EROP020",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I2ERP9BP0",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxButtons",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "120",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "80",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex Y",
//														"subAlign": "Center",
//														"itemsWrap": "No Wrap",
//														"itemsAlign": "Center"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1IDUGSEBN0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IDUGUHNS0",
//																	"attrs": {
//																		"type": "hud",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "100",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"contentLayout": "Flex Y",
//																		"itemsAlign": "Center",
//																		"subAlign": "Center"
//																	}
//																},
//																"subHuds": {
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "Gear/@StdUI/ui/BtnText.js",
//																			"jaxId": "1IDUGSJLO0",
//																			"attrs": {
//																				"createArgs": {
//																					"jaxId": "1IDUGSJLO1",
//																					"attrs": {
//																						"style": "primary",
//																						"w": "100",
//																						"h": "24",
//																						"text": {
//																							"type": "string",
//																							"valText": "Chat with Node",
//																							"localize": {
//																								"EN": "Chat with Node",
//																								"CN": "与节点对话"
//																							},
//																							"localizable": true
//																						},
//																						"outlined": "false",
//																						"icon": ""
//																					}
//																				},
//																				"properties": {
//																					"jaxId": "1IDUGSJLO2",
//																					"attrs": {
//																						"type": "#null#>BtnText(\"primary\",100,24,(($ln===\"CN\")?(\"与节点对话\"):(\"Chat with Node\")),false,\"\")",
//																						"id": "BtnChat",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"display": "On",
//																						"face": "",
//																						"margin": "[0,0,10,0]"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1IDUGSJLO3",
//																					"attrs": {
//																						"1I2ENO5H80": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IDUGSJLO4",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IDUGSJLO5",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1I2ENO5H80",
//																							"faceTagName": "state"
//																						},
//																						"1I2EOPDKQ0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IDUGSJLP0",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IDUGSJLP1",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1I2EOPDKQ0",
//																							"faceTagName": "over"
//																						},
//																						"1I2EOTJ050": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IDUGSJLP2",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IDUGSJLP3",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1I2EOTJ050",
//																							"faceTagName": "!over"
//																						},
//																						"1IDUGUVL30": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IDUGVOVR22",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IDUGVOVR23",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IDUGUVL30",
//																							"faceTagName": "working"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1IDUGSJLP4",
//																					"attrs": {
//																						"OnClick": {
//																							"type": "fixedFunc",
//																							"jaxId": "1IDUI4L0Q0",
//																							"attrs": {
//																								"callArgs": {
//																									"jaxId": "1IDUI4L0Q1",
//																									"attrs": {
//																										"event": ""
//																									}
//																								},
//																								"seg": "1IDUHVPFI0"
//																							}
//																						}
//																					}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1IDUGSJLP5",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "true",
//																				"containerSlots": {
//																					"jaxId": "1IDUGSJLP6",
//																					"attrs": {
//																						"Slot1H2F6U36O0": {
//																							"jaxId": "1IDUGSJLP7",
//																							"attrs": {
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"container": "true"
//																							}
//																						}
//																					}
//																				}
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "Gear/@StdUI/ui/BtnText.js",
//																			"jaxId": "1IDUGT2LA0",
//																			"attrs": {
//																				"createArgs": {
//																					"jaxId": "1IDUGT2LB0",
//																					"attrs": {
//																						"style": "secondary",
//																						"w": "100",
//																						"h": "24",
//																						"text": {
//																							"type": "string",
//																							"valText": "Configure Node",
//																							"localize": {
//																								"EN": "Configure Node",
//																								"CN": "配置节点"
//																							},
//																							"localizable": true
//																						},
//																						"outlined": "false",
//																						"icon": ""
//																					}
//																				},
//																				"properties": {
//																					"jaxId": "1IDUGT2LB1",
//																					"attrs": {
//																						"type": "#null#>BtnText(\"secondary\",100,24,(($ln===\"CN\")?(\"配置节点\"):(\"Configure Node\")),false,\"\")",
//																						"id": "BtnConfig",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"display": "On",
//																						"face": "",
//																						"margin": "[0,0,10,0]",
//																						"enable": "false"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1IDUGT2LB2",
//																					"attrs": {
//																						"1I2ENO5H80": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IDUGT2LB3",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IDUGT2LB4",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1I2ENO5H80",
//																							"faceTagName": "state"
//																						},
//																						"1I2EOPDKQ0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IDUGT2LB5",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IDUGT2LB6",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1I2EOPDKQ0",
//																							"faceTagName": "over"
//																						},
//																						"1I2EOTJ050": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IDUGT2LB7",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IDUGT2LB8",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1I2EOTJ050",
//																							"faceTagName": "!over"
//																						},
//																						"1IDUGUVL30": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IDUGVOVR26",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IDUGVOVR27",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IDUGUVL30",
//																							"faceTagName": "working"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1IDUGT2LB9",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1IDUGT2LB10",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "true",
//																				"containerSlots": {
//																					"jaxId": "1IDUGT2LB11",
//																					"attrs": {
//																						"Slot1H2F6U36O0": {
//																							"jaxId": "1IDUGT2LB12",
//																							"attrs": {
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"container": "true"
//																							}
//																						}
//																					}
//																				}
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "Gear/@StdUI/ui/BtnText.js",
//																			"jaxId": "1IDUGT6H10",
//																			"attrs": {
//																				"createArgs": {
//																					"jaxId": "1IDUGT6H11",
//																					"attrs": {
//																						"style": "success",
//																						"w": "100",
//																						"h": "24",
//																						"text": {
//																							"type": "string",
//																							"valText": "Start Node",
//																							"localize": {
//																								"EN": "Start Node",
//																								"CN": "启动节点"
//																							},
//																							"localizable": true
//																						},
//																						"outlined": "false",
//																						"icon": ""
//																					}
//																				},
//																				"properties": {
//																					"jaxId": "1IDUGT6H12",
//																					"attrs": {
//																						"type": "#null#>BtnText(\"success\",100,24,(($ln===\"CN\")?(\"启动节点\"):(\"Start Node\")),false,\"\")",
//																						"id": "BtnStartBot",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"display": "On",
//																						"face": ""
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1IDUGT6H20",
//																					"attrs": {
//																						"1I2ENO5H80": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IDUGT6H21",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IDUGT6H22",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1I2ENO5H80",
//																							"faceTagName": "state"
//																						},
//																						"1I2EOPDKQ0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IDUGT6H23",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IDUGT6H24",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1I2EOPDKQ0",
//																							"faceTagName": "over"
//																						},
//																						"1I2EOTJ050": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IDUGT6H25",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IDUGT6H26",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1I2EOTJ050",
//																							"faceTagName": "!over"
//																						},
//																						"1IDUGUVL30": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IDUGVOVR30",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IDUGVOVR31",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IDUGUVL30",
//																							"faceTagName": "working"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1IDUGT6H27",
//																					"attrs": {
//																						"OnClick": {
//																							"type": "fixedFunc",
//																							"jaxId": "1IDUGT6H28",
//																							"attrs": {
//																								"callArgs": {
//																									"jaxId": "1IDUGT6H29",
//																									"attrs": {
//																										"event": ""
//																									}
//																								},
//																								"seg": "1IDUHV9EG0"
//																							}
//																						}
//																					}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1IDUGT6H210",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "true",
//																				"containerSlots": {
//																					"jaxId": "1IDUGT6H211",
//																					"attrs": {
//																						"Slot1H2F6U36O0": {
//																							"jaxId": "1IDUGT6H212",
//																							"attrs": {
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"container": "true"
//																							}
//																						}
//																					}
//																				}
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "Gear/@StdUI/ui/BtnText.js",
//																			"jaxId": "1IDUGT8UT0",
//																			"attrs": {
//																				"createArgs": {
//																					"jaxId": "1IDUGT8UT1",
//																					"attrs": {
//																						"style": "warning",
//																						"w": "100",
//																						"h": "24",
//																						"text": {
//																							"type": "string",
//																							"valText": "Stop Node",
//																							"localize": {
//																								"EN": "Stop Node",
//																								"CN": "停止节点"
//																							},
//																							"localizable": true
//																						},
//																						"outlined": "false",
//																						"icon": ""
//																					}
//																				},
//																				"properties": {
//																					"jaxId": "1IDUGT8UU0",
//																					"attrs": {
//																						"type": "#null#>BtnText(\"warning\",100,24,(($ln===\"CN\")?(\"停止节点\"):(\"Stop Node\")),false,\"\")",
//																						"id": "BtnStopBot",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"display": "Off",
//																						"face": ""
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1IDUGT8UU1",
//																					"attrs": {
//																						"1I2ENO5H80": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IDUGT8UU2",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IDUGT8UU3",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1I2ENO5H80",
//																							"faceTagName": "state"
//																						},
//																						"1I2EOPDKQ0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IDUGT8UU4",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IDUGT8UU5",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1I2EOPDKQ0",
//																							"faceTagName": "over"
//																						},
//																						"1I2EOTJ050": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IDUGT8UU6",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IDUGT8UU7",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1I2EOTJ050",
//																							"faceTagName": "!over"
//																						},
//																						"1IDUGUVL30": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IDUGVOVR34",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IDUGVOVR35",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IDUGUVL30",
//																							"faceTagName": "working"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1IDUGT8UU8",
//																					"attrs": {
//																						"OnClick": {
//																							"type": "fixedFunc",
//																							"jaxId": "1IDUI4DMO0",
//																							"attrs": {
//																								"callArgs": {
//																									"jaxId": "1IDUI4DMO1",
//																									"attrs": {
//																										"event": ""
//																									}
//																								},
//																								"seg": "1IDUHVHV00"
//																							}
//																						}
//																					}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1IDUGT8UU9",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "true",
//																				"containerSlots": {
//																					"jaxId": "1IDUGT8UU10",
//																					"attrs": {
//																						"Slot1H2F6U36O0": {
//																							"jaxId": "1IDUGT8UU11",
//																							"attrs": {
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"container": "true"
//																							}
//																						}
//																					}
//																				}
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"jaxId": "1IDUGUHNS1",
//																	"attrs": {
//																		"1IDUGV3TH0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IDUGVOVR36",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IDUGVOVR37",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IDUGV3TH0",
//																			"faceTagName": "!working"
//																		},
//																		"1IDUGUVL30": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IDUGVOVR38",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IDUGVOVR39",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IDUGUVL30",
//																			"faceTagName": "working"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1IDUGUHNS2",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1IDUGUHNS3",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false",
//																"exposeContainer": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1IDUGQ32O0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IDUGUHNS4",
//																	"attrs": {
//																		"type": "text",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "Off",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontBodySub\"]",
//																		"text": {
//																			"type": "string",
//																			"valText": "Working...",
//																			"localize": {
//																				"EN": "Working...",
//																				"CN": "操作中..."
//																			},
//																			"localizable": true
//																		},
//																		"font": "",
//																		"fontSize": "#txtSize.smallPlus",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Center",
//																		"alignV": "Top",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"lineClamp": "0",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IDUGUHNS5",
//																	"attrs": {
//																		"1IDUGV3TH0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IDUGVOVR40",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IDUGVOVR41",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IDUGV3TH0",
//																			"faceTagName": "!working"
//																		},
//																		"1IDUGUVL30": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IDUGVOVR42",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IDUGVOVR43",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IDUGUVL30",
//																			"faceTagName": "working"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1IDUGUHNS6",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1IDUGUHNS7",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false"
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1I2ERP9BP1",
//													"attrs": {
//														"1I2ENO5H80": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IDUDGJAP48",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IDUDGJAP49",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I2ENO5H80",
//															"faceTagName": "state"
//														},
//														"1I2EOPDKQ0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IDUDGJAP50",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IDUDGJAP51",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I2EOPDKQ0",
//															"faceTagName": "over"
//														},
//														"1I2EOTJ050": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IDUDGJAP52",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IDUDGJAP53",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I2EOTJ050",
//															"faceTagName": "!over"
//														},
//														"1IDUGUVL30": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IDUGVOVR46",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IDUGVOVR47",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IDUGUVL30",
//															"faceTagName": "working"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I2ERP9BP2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I2ERP9BP3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1I2ENTD7U3",
//									"attrs": {
//										"1I2EOPDKQ0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I2EOVIA911",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I2EOVIA912",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I2EOPDKQ0",
//											"faceTagName": "over"
//										},
//										"1I2ENO5H80": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IDUDGJAP54",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IDUDGJAP55",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I2ENO5H80",
//											"faceTagName": "state"
//										},
//										"1I2EOTJ050": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IDUDGJAP56",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IDUDGJAP57",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I2EOTJ050",
//											"faceTagName": "!over"
//										},
//										"1IDUGUVL30": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IDUGVOVR50",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IDUGVOVR51",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IDUGUVL30",
//											"faceTagName": "working"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1I2ENTD7U4",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1I2ENTD7U5",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1I2EPLLSK0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I2EPP70V0",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxState",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "Off",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex Y"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/DataView.js",
//											"jaxId": "1I2EPND3O0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1I2EPP70V1",
//													"attrs": {
//														"box": "null",
//														"template": "\"1I2C843JD0\"",
//														"dataObj": "null",
//														"property": "",
//														"options": {
//															"jaxId": "1I2EPP70V2",
//															"attrs": {
//																"titleHeight": "30",
//																"titleSize": "18",
//																"titleColor": "#cfgColor[\"fontBody\"]",
//																"titleBold": "true",
//																"lineHeight": "20",
//																"lineGap": "5",
//																"labelSize": "12",
//																"labelColor": "#cfgColor[\"fontBody\"]",
//																"labelBold": "true",
//																"labelLine": "false",
//																"valueSize": "14",
//																"valueColor": "#cfgColor[\"fontBody\"]",
//																"valueBold": "true",
//																"segHeight": "20",
//																"segSize": "14",
//																"segBold": "true",
//																"segColor": "#cfgColor[\"fontBody\"]",
//																"trace": "false",
//																"edit": "false",
//																"noteSize": "12",
//																"autoCollapse": "false",
//																"hideCollapse": "false",
//																"valueRightAlign": "false",
//																"gridLine": "false"
//															}
//														},
//														"title": ""
//													}
//												},
//												"properties": {
//													"jaxId": "1I2EPP70V3",
//													"attrs": {
//														"type": "#null#>DataView(null,\"1I2C843JD0\",null,\"\",{\"titleHeight\":30,\"titleSize\":18,\"titleColor\":cfgColor[\"fontBody\"],\"titleBold\":true,\"lineHeight\":20,\"lineGap\":5,\"labelSize\":12,\"labelColor\":cfgColor[\"fontBody\"],\"labelBold\":true,\"labelLine\":false,\"valueSize\":14,\"valueColor\":cfgColor[\"fontBody\"],\"valueBold\":true,\"segHeight\":20,\"segSize\":14,\"segBold\":true,\"segColor\":cfgColor[\"fontBody\"],\"trace\":false,\"edit\":false,\"noteSize\":12,\"autoCollapse\":false,\"hideCollapse\":false,\"valueRightAlign\":false,\"gridLine\":false},\"\")",
//														"id": "DvState",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": ""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I2EPP70V4",
//													"attrs": {
//														"1I2ENO5H80": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IDUDGJAP58",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IDUDGJAP59",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I2ENO5H80",
//															"faceTagName": "state"
//														},
//														"1I2EOPDKQ0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IDUDGJAP60",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IDUDGJAP61",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I2EOPDKQ0",
//															"faceTagName": "over"
//														},
//														"1I2EOTJ050": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IDUDGJAP62",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IDUDGJAP63",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I2EOTJ050",
//															"faceTagName": "!over"
//														},
//														"1IDUGUVL30": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IDUGVOVR54",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IDUGVOVR55",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IDUGUVL30",
//															"faceTagName": "working"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I2EPP70V5",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I2EPP70V6",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1I2EPP70V7",
//													"attrs": {}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1I2EPP70V8",
//									"attrs": {
//										"1I2ENO5H80": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I2EQ4VVO10",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I2EQ4VVO11",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I2ENO5H80",
//											"faceTagName": "state"
//										},
//										"1I2ENNOI00": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I2EQ5NOK2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I2EQ5NOK3",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I2ENNOI00",
//											"faceTagName": "info"
//										},
//										"1I2EOPDKQ0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IDUDGJAP64",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IDUDGJAP65",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I2EOPDKQ0",
//											"faceTagName": "over"
//										},
//										"1I2EOTJ050": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IDUDGJAP66",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IDUDGJAP67",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I2EOTJ050",
//											"faceTagName": "!over"
//										},
//										"1IDUGUVL30": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IDUGVOVR58",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IDUGVOVR59",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IDUGUVL30",
//											"faceTagName": "working"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1I2EPP70V9",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1I2EPP70V10",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1I2ENG3L09",
//					"attrs": {
//						"1I2EOPDKQ0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1I2EOVIA913",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I2EOVIA914",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1I2EOPDKQ0",
//							"faceTagName": "over"
//						},
//						"1I2ENO5H80": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1IDUDGJAP68",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IDUDGJAP69",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1I2ENO5H80",
//							"faceTagName": "state"
//						},
//						"1I2EOTJ050": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1IDUDGJAP70",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IDUDGJAP71",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1I2EOTJ050",
//							"faceTagName": "!over"
//						},
//						"1IDUGUVL30": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1IDUGVOVR62",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IDUGVOVR63",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1IDUGUVL30",
//							"faceTagName": "working"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1I2ENG3L010",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1I2ENG3L011",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1I2ENG3L012",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}