//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnText} from "/@StdUI/ui/BtnText.js";
import {DataView} from "/@StdUI/ui/DataView.js";
/*#{1I2ENG3KV0StartDoc*/
/*}#1I2ENG3KV0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BoxBot=function(bot){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let boxInfo,dvInfo;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1I2ENG3KV1LocalVals*/
	/*}#1I2ENG3KV1LocalVals*/
	
	/*#{1I2ENG3KV1PreState*/
	/*}#1I2ENG3KV1PreState*/
	state={
		"name":"Bot","alias":"ALICE","active":false,
		/*#{1I2ENG3L05ExState*/
		/*}#1I2ENG3L05ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1I2ENG3KV1PostState*/
	/*}#1I2ENG3KV1PostState*/
	cssVO={
		"hash":"1I2ENG3KV1",nameHost:true,
		"type":"hud","x":0,"y":0,"w":"100%","h":"","margin":[0,0,10,0],"padding":[10,10,10,20],"minW":"","minH":"","maxW":500,"maxH":"","styleClass":"","contentLayout":"flex-y",
		"itemsAlign":1,
		children:[
			{
				"hash":"1I2ENH0050",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["body"],
				"border":1,"borderColor":cfgColor["fontBodySub"],"corner":12,"contentLayout":"flex-x",
			},
			{
				"hash":"1I2ENRF130",
				"type":"hud","id":"BoxInfo","position":"relative","x":0,"y":0,"w":"100%","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
				"itemsAlign":1,
				children:[
					{
						"hash":"1I2ES6C850",
						"type":"hud","position":"relative","x":0,"y":0,"w":60,"h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
						"itemsAlign":1,"subAlign":1,
						children:[
							{
								"hash":"1I2ES6M290",
								"type":"box","id":"BoxIcon","position":"relative","x":0,"y":0,"w":60,"h":60,"margin":[0,0,5,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
								"background":cfgColor["fontBodySub"],"maskImage":appCfg.sharedAssets+"/agent.svg",
							},
							{
								"hash":"1I2ES86880",
								"type":BtnText("front",60,20,"Refresh",true,""),"id":"BtnRefresh","position":"relative","x":0,"y":0,
							}
						],
					},
					{
						"hash":"1I2ENS6BE0",
						"type":"hud","position":"relative","x":0,"y":0,"w":">calc(100% - 180px)","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
						children:[
							{
								"hash":"1I2EO0KJS0",
								"type":DataView(null,"1I2B4INBE0",bot,"",{"titleHeight":30,"titleSize":18,"titleColor":cfgColor["fontBody"],"titleBold":true,"lineHeight":20,"lineGap":5,"labelSize":12,"labelColor":cfgColor["fontBodySub"],"labelBold":true,"labelLine":false,"valueSize":14,"valueColor":cfgColor["fontBody"],"valueBold":true,"segHeight":20,"segSize":14,"segBold":true,"segColor":cfgColor["fontBody"],"trace":false,"edit":false,"noteSize":12},""),
								"id":"DvInfo","position":"relative","x":0,"y":0,
							}
						],
					},
					{
						"hash":"1I2EROP020",
						"type":"hud","position":"relative","x":0,"y":0,"w":120,"h":"100%","minW":"","minH":80,"maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
						"subAlign":1,"itemsAlign":1,
						children:[
							{
								"hash":"1I2ERPBIK0",
								"type":BtnText("primary",100,24,"View State",false,""),"id":"BtnViewState","position":"relative","x":0,"y":0,"margin":[0,0,10,0],
							},
							{
								"hash":"1I2ERUMT50",
								"type":BtnText("secondary",100,24,"Configure Bot",false,""),"id":"BtnConfig","position":"relative","x":0,"y":0,"margin":[0,0,10,0],"enable":false,
							},
							{
								"hash":"1I2ERQNHQ0",
								"type":BtnText("success",100,24,"Start Bot",false,""),"id":"BtnStartBot","position":"relative","x":0,"y":0,
								"OnClick":function(event){
									/*#{1I55ON4B50FunctionBody*/
									self.startBot&&self.startBot(bot);
									/*}#1I55ON4B50FunctionBody*/
								},
							},
							{
								"hash":"1I2ERSGVE0",
								"type":BtnText("warning",100,24,"Stop Bot",false,""),"id":"BtnStopBot","position":"relative","x":0,"y":0,"display":0,
							}
						],
					}
				],
			},
			{
				"hash":"1I2EPLLSK0",
				"type":"hud","id":"BoxState","position":"relative","x":0,"y":0,"w":"100%","h":"","display":0,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"contentLayout":"flex-y",
				children:[
					{
						"hash":"1I2EPND3O0",
						"type":DataView(null,"1I2C843JD0",null,"",{"titleHeight":30,"titleSize":18,"titleColor":cfgColor["fontBody"],"titleBold":true,"lineHeight":20,"lineGap":5,"labelSize":12,"labelColor":cfgColor["fontBody"],"labelBold":true,"labelLine":false,"valueSize":14,"valueColor":cfgColor["fontBody"],"valueBold":true,"segHeight":20,"segSize":14,"segBold":true,"segColor":cfgColor["fontBody"],"trace":false,"edit":false,"noteSize":12},""),
						"id":"DvState","position":"relative","x":0,"y":0,
					}
				],
			}
		],
		/*#{1I2ENG3KV1ExtraCSS*/
		/*}#1I2ENG3KV1ExtraCSS*/
		faces:{
			"info":{
				/*BoxState*/"#1I2EPLLSK0":{
					"display":0
				}
			},"state":{
				/*#{1I2ENO5H80PreCode*/
				/*}#1I2ENO5H80PreCode*/
				/*BoxState*/"#1I2EPLLSK0":{
					"display":1
				}
			},"over":{
				/*BoxBG*/"#1I2ENH0050":{
					"border":2
				}
			},"!over":{
				/*BoxBG*/"#1I2ENH0050":{
					"border":1
				}
			}
		},
		OnCreate:function(){
			self=this;
			boxInfo=self.BoxInfo;dvInfo=self.DvInfo;
			/*#{1I2ENG3KV1Create*/
			/*}#1I2ENG3KV1Create*/
		},
		/*#{1I2ENG3KV1EndCSS*/
		/*}#1I2ENG3KV1EndCSS*/
	};
	/*#{1I2ENG3KV1PostCSSVO*/
	/*}#1I2ENG3KV1PostCSSVO*/
	return cssVO;
};
/*#{1I2ENG3KV1ExCodes*/
/*}#1I2ENG3KV1ExCodes*/


/*#{1I2ENG3KV0EndDoc*/
/*}#1I2ENG3KV0EndDoc*/

export default BoxBot;
export{BoxBot};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1I2ENG3KV0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1I2ENG3L00",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "600",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1I2ENG3L01",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1I2ENG3L02",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1I2ENG3L03",
//			"attrs": {
//				"bot": {
//					"type": "auto",
//					"valText": "null"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1I2ENG3L04",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1I2ENG3L05",
//			"attrs": {
//				"name": {
//					"type": "string",
//					"valText": "Bot"
//				},
//				"alias": {
//					"type": "string",
//					"valText": "ALICE"
//				},
//				"active": {
//					"type": "bool",
//					"valText": "false"
//				}
//			}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1I2ENG3L06",
//			"attrs": {
//				"info": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1I2ENNOI00",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1I2ENTD7U0",
//							"attrs": {}
//						}
//					}
//				},
//				"state": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1I2ENO5H80",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "true",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1I2ENTD7U1",
//							"attrs": {}
//						}
//					}
//				},
//				"over": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1I2EOPDKQ0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1I2EOVIA80",
//							"attrs": {}
//						}
//					}
//				},
//				"!over": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1I2EOTJ050",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1I2EOVIA90",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1I2ENG3L07",
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1I2ENG3KV1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1I2ENG3L08",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "[0,0,10,0]",
//						"padding": "[10,10,10,20]",
//						"minW": "",
//						"minH": "",
//						"maxW": "500",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Flex Y",
//						"itemsAlign": "Center"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1I2ENH0050",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I2ENH46J0",
//									"attrs": {
//										"type": "box",
//										"id": "BoxBG",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"body\"]",
//										"border": "1",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor[\"fontBodySub\"]",
//										"corner": "12",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"contentLayout": "Flex X"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1I2ENH46J1",
//									"attrs": {
//										"1I2EOTJ050": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I2EOVIA91",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I2EOVIA92",
//													"attrs": {
//														"border": {
//															"type": "auto",
//															"valText": "1",
//															"editMode": "edges"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I2EOTJ050",
//											"faceTagName": "!over"
//										},
//										"1I2EOPDKQ0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I2EOVIA93",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I2EOVIA94",
//													"attrs": {
//														"border": {
//															"type": "auto",
//															"valText": "2",
//															"editMode": "edges"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I2EOPDKQ0",
//											"faceTagName": "over"
//										},
//										"1I2ENNOI00": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I2EPBHJG0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I2EPBHJG1",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I2ENNOI00",
//											"faceTagName": "info"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1I2ENH46J2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1I2ENH46J3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1I2ENRF130",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I2ENTD7U2",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxInfo",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex X",
//										"itemsWrap": "No Wrap",
//										"itemsAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1I2ES6C850",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I2ES6C851",
//													"attrs": {
//														"type": "hud",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "60",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex Y",
//														"itemsAlign": "Center",
//														"subAlign": "Center"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "box",
//															"jaxId": "1I2ES6M290",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I2ES6M291",
//																	"attrs": {
//																		"type": "box",
//																		"id": "BoxIcon",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "60",
//																		"h": "60",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[0,0,5,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"background": "#cfgColor[\"fontBodySub\"]",
//																		"border": "0",
//																		"borderStyle": "Solid",
//																		"borderColor": "[0,0,0,1.00]",
//																		"corner": "0",
//																		"shadow": "false",
//																		"shadowX": "2",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowSpread": "0",
//																		"shadowColor": "[0,0,0,0.50]",
//																		"maskImage": "#appCfg.sharedAssets+\"/agent.svg\""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1I2ES6M2A0",
//																	"attrs": {
//																		"1I2EOPDKQ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I2ES6M2A1",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I2ES6M2A2",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I2EOPDKQ0",
//																			"faceTagName": "over"
//																		},
//																		"1I2ENNOI00": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I2ES6M2A3",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I2ES6M2A4",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I2ENNOI00",
//																			"faceTagName": "info"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1I2ES6M2A5",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1I2ES6M2A6",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnText.js",
//															"jaxId": "1I2ES86880",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1I2ES86881",
//																	"attrs": {
//																		"style": "front",
//																		"w": "60",
//																		"h": "20",
//																		"text": "Refresh",
//																		"outlined": "true",
//																		"icon": ""
//																	}
//																},
//																"properties": {
//																	"jaxId": "1I2ES86882",
//																	"attrs": {
//																		"type": "#null#>BtnText(\"front\",60,20,\"Refresh\",true,\"\")",
//																		"id": "BtnRefresh",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1I2ES86883",
//																	"attrs": {}
//																},
//																"functions": {
//																	"jaxId": "1I2ES86884",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1I2ES86885",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1I2ES86886",
//																	"attrs": {
//																		"Slot1H2F6U36O0": {
//																			"jaxId": "1I2ES86887",
//																			"attrs": {
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"container": "true"
//																			}
//																		}
//																	}
//																}
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1I2ES6C860",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1I2ES6C861",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I2ES6C862",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1I2ENS6BE0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I2ENS6BE1",
//													"attrs": {
//														"type": "hud",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%-180",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex Y"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/DataView.js",
//															"jaxId": "1I2EO0KJS0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1I2EO304E0",
//																	"attrs": {
//																		"box": "null",
//																		"template": "\"1I2B4INBE0\"",
//																		"dataObj": "#bot",
//																		"property": "",
//																		"options": {
//																			"jaxId": "1I2EO304E1",
//																			"attrs": {
//																				"titleHeight": "30",
//																				"titleSize": "18",
//																				"titleColor": "#cfgColor[\"fontBody\"]",
//																				"titleBold": "true",
//																				"lineHeight": "20",
//																				"lineGap": "5",
//																				"labelSize": "12",
//																				"labelColor": "#cfgColor[\"fontBodySub\"]",
//																				"labelBold": "true",
//																				"labelLine": "false",
//																				"valueSize": "14",
//																				"valueColor": "#cfgColor[\"fontBody\"]",
//																				"valueBold": "true",
//																				"segHeight": "20",
//																				"segSize": "14",
//																				"segBold": "true",
//																				"segColor": "#cfgColor[\"fontBody\"]",
//																				"trace": "false",
//																				"edit": "false",
//																				"noteSize": "12"
//																			}
//																		},
//																		"title": ""
//																	}
//																},
//																"properties": {
//																	"jaxId": "1I2EO304E2",
//																	"attrs": {
//																		"type": "#null#>DataView(null,\"1I2B4INBE0\",bot,\"\",{\"titleHeight\":30,\"titleSize\":18,\"titleColor\":cfgColor[\"fontBody\"],\"titleBold\":true,\"lineHeight\":20,\"lineGap\":5,\"labelSize\":12,\"labelColor\":cfgColor[\"fontBodySub\"],\"labelBold\":true,\"labelLine\":false,\"valueSize\":14,\"valueColor\":cfgColor[\"fontBody\"],\"valueBold\":true,\"segHeight\":20,\"segSize\":14,\"segBold\":true,\"segColor\":cfgColor[\"fontBody\"],\"trace\":false,\"edit\":false,\"noteSize\":12},\"\")",
//																		"id": "DvInfo",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1I2EO304E3",
//																	"attrs": {
//																		"1I2EOPDKQ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I2EOVIA97",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I2EOVIA98",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I2EOPDKQ0",
//																			"faceTagName": "over"
//																		},
//																		"1I2ENNOI00": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I2EPBHJH0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I2EPBHJH1",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I2ENNOI00",
//																			"faceTagName": "info"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1I2EO304E4",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1I2EO304E5",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1I2EO304E6",
//																	"attrs": {}
//																}
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1I2ENS6BF0",
//													"attrs": {
//														"1I2EOPDKQ0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I2EOVIA99",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I2EOVIA910",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I2EOPDKQ0",
//															"faceTagName": "over"
//														},
//														"1I2ENNOI00": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I2EPBHJH2",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I2EPBHJH3",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I2ENNOI00",
//															"faceTagName": "info"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I2ENS6BF1",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I2ENS6BF2",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1I2EROP020",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I2ERP9BP0",
//													"attrs": {
//														"type": "hud",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "120",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "80",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex Y",
//														"subAlign": "Center",
//														"itemsWrap": "No Wrap",
//														"itemsAlign": "Center"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnText.js",
//															"jaxId": "1I2ERPBIK0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1I2ERQM0F0",
//																	"attrs": {
//																		"style": "primary",
//																		"w": "100",
//																		"h": "24",
//																		"text": "View State",
//																		"outlined": "false",
//																		"icon": ""
//																	}
//																},
//																"properties": {
//																	"jaxId": "1I2ERQM0F1",
//																	"attrs": {
//																		"type": "#null#>BtnText(\"primary\",100,24,\"View State\",false,\"\")",
//																		"id": "BtnViewState",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"margin": "[0,0,10,0]"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1I2ERQM0F2",
//																	"attrs": {}
//																},
//																"functions": {
//																	"jaxId": "1I2ERQM0F3",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1I2ERQM0F4",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1I2ERQM0F5",
//																	"attrs": {
//																		"Slot1H2F6U36O0": {
//																			"jaxId": "1I2ERQM0F6",
//																			"attrs": {
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"container": "true"
//																			}
//																		}
//																	}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnText.js",
//															"jaxId": "1I2ERUMT50",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1I2ERUMT51",
//																	"attrs": {
//																		"style": "secondary",
//																		"w": "100",
//																		"h": "24",
//																		"text": "Configure Bot",
//																		"outlined": "false",
//																		"icon": ""
//																	}
//																},
//																"properties": {
//																	"jaxId": "1I2ERUMT52",
//																	"attrs": {
//																		"type": "#null#>BtnText(\"secondary\",100,24,\"Configure Bot\",false,\"\")",
//																		"id": "BtnConfig",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"margin": "[0,0,10,0]",
//																		"enable": "false"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1I2ERUMT53",
//																	"attrs": {}
//																},
//																"functions": {
//																	"jaxId": "1I2ERUMT54",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1I2ERUMT55",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1I2ERUMT56",
//																	"attrs": {
//																		"Slot1H2F6U36O0": {
//																			"jaxId": "1I2ERUMT57",
//																			"attrs": {
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"container": "true"
//																			}
//																		}
//																	}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnText.js",
//															"jaxId": "1I2ERQNHQ0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1I2ERQNHQ1",
//																	"attrs": {
//																		"style": "success",
//																		"w": "100",
//																		"h": "24",
//																		"text": "Start Bot",
//																		"outlined": "false",
//																		"icon": ""
//																	}
//																},
//																"properties": {
//																	"jaxId": "1I2ERQNHR0",
//																	"attrs": {
//																		"type": "#null#>BtnText(\"success\",100,24,\"Start Bot\",false,\"\")",
//																		"id": "BtnStartBot",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1I2ERQNHR1",
//																	"attrs": {}
//																},
//																"functions": {
//																	"jaxId": "1I2ERQNHR2",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1I55ON4B50",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1I55OTFAU0",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1I2ERQNHR3",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1I2ERQNHR4",
//																	"attrs": {
//																		"Slot1H2F6U36O0": {
//																			"jaxId": "1I2ERQNHR5",
//																			"attrs": {
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"container": "true"
//																			}
//																		}
//																	}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnText.js",
//															"jaxId": "1I2ERSGVE0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1I2ERSGVE1",
//																	"attrs": {
//																		"style": "warning",
//																		"w": "100",
//																		"h": "24",
//																		"text": "Stop Bot",
//																		"outlined": "false",
//																		"icon": ""
//																	}
//																},
//																"properties": {
//																	"jaxId": "1I2ERSGVE2",
//																	"attrs": {
//																		"type": "#null#>BtnText(\"warning\",100,24,\"Stop Bot\",false,\"\")",
//																		"id": "BtnStopBot",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "Off",
//																		"face": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1I2ERSGVE3",
//																	"attrs": {}
//																},
//																"functions": {
//																	"jaxId": "1I2ERSGVE4",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1I2ERSGVE5",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1I2ERSGVE6",
//																	"attrs": {
//																		"Slot1H2F6U36O0": {
//																			"jaxId": "1I2ERSGVE7",
//																			"attrs": {
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"container": "true"
//																			}
//																		}
//																	}
//																}
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1I2ERP9BP1",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1I2ERP9BP2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I2ERP9BP3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1I2ENTD7U3",
//									"attrs": {
//										"1I2EOPDKQ0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I2EOVIA911",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I2EOVIA912",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I2EOPDKQ0",
//											"faceTagName": "over"
//										},
//										"1I2ENNOI00": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I2EPBHJH4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I2EPBHJH5",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I2ENNOI00",
//											"faceTagName": "info"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1I2ENTD7U4",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1I2ENTD7U5",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1I2EPLLSK0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I2EPP70V0",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxState",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "Off",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex Y"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/DataView.js",
//											"jaxId": "1I2EPND3O0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1I2EPP70V1",
//													"attrs": {
//														"box": "null",
//														"template": "\"1I2C843JD0\"",
//														"dataObj": "null",
//														"property": "",
//														"options": {
//															"jaxId": "1I2EPP70V2",
//															"attrs": {
//																"titleHeight": "30",
//																"titleSize": "18",
//																"titleColor": "#cfgColor[\"fontBody\"]",
//																"titleBold": "true",
//																"lineHeight": "20",
//																"lineGap": "5",
//																"labelSize": "12",
//																"labelColor": "#cfgColor[\"fontBody\"]",
//																"labelBold": "true",
//																"labelLine": "false",
//																"valueSize": "14",
//																"valueColor": "#cfgColor[\"fontBody\"]",
//																"valueBold": "true",
//																"segHeight": "20",
//																"segSize": "14",
//																"segBold": "true",
//																"segColor": "#cfgColor[\"fontBody\"]",
//																"trace": "false",
//																"edit": "false",
//																"noteSize": "12"
//															}
//														},
//														"title": ""
//													}
//												},
//												"properties": {
//													"jaxId": "1I2EPP70V3",
//													"attrs": {
//														"type": "#null#>DataView(null,\"1I2C843JD0\",null,\"\",{\"titleHeight\":30,\"titleSize\":18,\"titleColor\":cfgColor[\"fontBody\"],\"titleBold\":true,\"lineHeight\":20,\"lineGap\":5,\"labelSize\":12,\"labelColor\":cfgColor[\"fontBody\"],\"labelBold\":true,\"labelLine\":false,\"valueSize\":14,\"valueColor\":cfgColor[\"fontBody\"],\"valueBold\":true,\"segHeight\":20,\"segSize\":14,\"segBold\":true,\"segColor\":cfgColor[\"fontBody\"],\"trace\":false,\"edit\":false,\"noteSize\":12},\"\")",
//														"id": "DvState",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": ""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I2EPP70V4",
//													"attrs": {
//														"1I2ENNOI00": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I2EQ5NOK0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I2EQ5NOK1",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I2ENNOI00",
//															"faceTagName": "info"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I2EPP70V5",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I2EPP70V6",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1I2EPP70V7",
//													"attrs": {}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1I2EPP70V8",
//									"attrs": {
//										"1I2ENO5H80": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I2EQ4VVO10",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I2EQ4VVO11",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I2ENO5H80",
//											"faceTagName": "state"
//										},
//										"1I2ENNOI00": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I2EQ5NOK2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I2EQ5NOK3",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I2ENNOI00",
//											"faceTagName": "info"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1I2EPP70V9",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1I2EPP70V10",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1I2ENG3L09",
//					"attrs": {
//						"1I2EOPDKQ0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1I2EOVIA913",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I2EOVIA914",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1I2EOPDKQ0",
//							"faceTagName": "over"
//						},
//						"1I2ENNOI00": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1I2EPBHJH6",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I2EPBHJH7",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1I2ENNOI00",
//							"faceTagName": "info"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1I2ENG3L010",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1I2ENG3L011",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1I2ENG3L012",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}