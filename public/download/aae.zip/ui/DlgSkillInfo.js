//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {DataView} from "/@StdUI/ui/DataView.js";
import {BtnText} from "/@StdUI/ui/BtnText.js";
/*#{1I286DL250StartDoc*/
/*
This is a template for standard dialog.
*/
/*}#1I286DL250StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let DlgSkillInfo=function(title,closeIcon){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let txtTitle,boxContent,dvData,boxButtons;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1H1T7ISV51LocalVals*/
	let app,dlgVO;
	app=window.tabOSApp;
	dlgVO=null;
	/*}#1H1T7ISV51LocalVals*/
	
	/*#{1H1T7ISV51PreState*/
	/*}#1H1T7ISV51PreState*/
	state={
		"title":title,
		/*#{1H1T7ISV56ExState*/
		/*}#1H1T7ISV56ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1H1T7ISV51PostState*/
	/*}#1H1T7ISV51PostState*/
	cssVO={
		"hash":"1H1T7ISV51",nameHost:true,
		"type":"hud","x":"50%","y":"10%","w":"90%","h":"","anchorX":1,"padding":10,"minW":"","minH":"","maxW":600,"maxH":"","styleClass":"","contentLayout":"flex-y",
		children:[
			{
				"hash":"1H1T7LGH40",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.body,"border":2,
				"borderColor":cfgColor["fontBodySub"],"corner":5,"shadow":true,"shadowX":3,"shadowY":6,"shadowBlur":5,"shadowColor":[0,0,0,0.3],
			},
			{
				"hash":"1H1T7O2SA0",
				"type":"text","id":"TxtTitle","position":"relative","x":0,"y":0,"w":"100%","h":"","uiEvent":-1,"margin":[0,0,10,0],"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","color":cfgColor.fontBodySub,"text":$P(()=>(state.title),state),"fontSize":txtSize.big,"fontWeight":"bold","fontStyle":"normal","textDecoration":"",
			},
			{
				"hash":"1H1T7S0BE0",
				"type":"hud","id":"BoxContent","position":"relative","x":0,"y":0,"w":"100%","h":"","overflow":"auto-y","minW":"","minH":30,"maxW":"","maxH":380,"styleClass":"",
				"contentLayout":"flex-y",
				children:[
					{
						"hash":"1I286IE710",
						"type":DataView(null,null,null,"",{"titleHeight":30,"titleSize":18,"titleColor":cfgColor["fontBody"],"titleBold":false,"lineHeight":30,"lineGap":8,"labelSize":15,"labelColor":cfgColor["fontBody"],"labelBold":true,"labelLine":true,"valueSize":16,"valueColor":cfgColor["fontBody"],"valueBold":false,"segHeight":20,"segSize":14,"segBold":true,"segColor":cfgColor["fontBody"],"trace":false,"edit":false,"noteSize":16},"Object View"),
						"id":"DvData","position":"relative","x":0,"y":0,
					}
				],
			},
			{
				"hash":"1H1T7UCES0",
				"type":"hud","id":"BoxButtons","position":"relative","x":0,"y":0,"w":"100%","h":30,"margin":[5,0,0,0],"padding":0,"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","contentLayout":"flex-x","subAlign":2,"itemsAlign":1,
				children:[
					{
						"hash":"1I286EKD00",
						"type":BtnText("primary",100,24,(($ln==="CN")?("关闭"):("Close")),false,""),"position":"relative","x":0,"y":0,
						"OnClick":function(event){
							/*#{1I288P9KH0FunctionBody*/
							app.closeDlg(self);
							/*}#1I288P9KH0FunctionBody*/
						},
					}
				],
			}
		],
		/*#{1H1T7ISV51ExtraCSS*/
		/*}#1H1T7ISV51ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			self=this;
			txtTitle=self.TxtTitle;boxContent=self.BoxContent;dvData=self.DvData;boxButtons=self.BoxButtons;
			/*#{1H1T7ISV51Create*/
			//Apply drag to move:
			VFACT.applyMoveDrag(self.BoxBG,self);
			/*}#1H1T7ISV51Create*/
		},
		/*#{1H1T7ISV51EndCSS*/
		/*}#1H1T7ISV51EndCSS*/
	};
	/*#{1H1T7ISV51PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.showDlg=function(vo){
		let skill;
		dlgVO=vo;
		skill=vo.skill;
		if(skill.guide){
			txtTitle.text=(($ln==="CN")?("技能链信息"):/*EN*/("Skill Chain Info"));
		}else{
			txtTitle.text=(($ln==="CN")?("技能信息"):/*EN*/("Skill Info"));
		}
		dvData.setObject("SkillInfo",skill,null);
		//TODO: init/update your dialog based on vo
		self.animate({type:"in",alpha:0,scale:0.9,time:100});
	};
	
	//------------------------------------------------------------------------
	cssVO.close=function(result){
		//Maybe animation:
		app.closeDlg(self,result);
		if(dlgVO){
			let next;
			next=dlgVO.next||dlgVO.callback;
			if(next){
				next(result);
			}
		}
	};
	/*}#1H1T7ISV51PostCSSVO*/
	return cssVO;
};
/*#{1H1T7ISV51ExCodes*/
/*}#1H1T7ISV51ExCodes*/

DlgSkillInfo.gearExport={
	framework: "jax",
	hudType: "hud",
	"showName":(($ln==="CN")?("标准对话框"):("Standard Dialog")),icon:"gears.svg",previewImg:false,
	fixPose:false,initW:360,initH:500,
	catalog:"",
	args: {
		"title": {
			"name": "title", "showName": "title", "type": "string", "key": true, "fixed": true, "initVal": "Dialog title", "localizable": true
		}, 
		"closeIcon": {
			"name": "closeIcon", "showName": "closeIcon", "type": "bool", "key": true, "fixed": true, "initVal": false
		}
	},
	state:{
	},
	properties:["id","position","x","y","w","h","display"],
	faces:[],
	subContainers:{
		"1H1T7S0BE0":{"showName":"BoxContent","contentLayout":"flex-y"}
	},
	/*#{1I286DL250ExGearInfo*/
	/*}#1I286DL250ExGearInfo*/
};
/*#{1I286DL250EndDoc*/
/*}#1I286DL250EndDoc*/

export default DlgSkillInfo;
export{DlgSkillInfo};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1I286DL250",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1H1T7ISV52",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1H1T7ISV53",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1H8H690AD0",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1H1T7ISV54",
//			"attrs": {
//				"title": {
//					"type": "string",
//					"valText": "Dialog title",
//					"localizable": true
//				},
//				"closeIcon": {
//					"type": "bool",
//					"valText": "false"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1H1T7ISV55",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1H1T7ISV56",
//			"attrs": {
//				"title": {
//					"type": "string",
//					"valText": "#title",
//					"localizable": true
//				}
//			}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": {
//			"type": "string",
//			"valText": "Standard Dialog",
//			"localize": {
//				"EN": "Standard Dialog",
//				"CN": "标准对话框"
//			},
//			"localizable": true
//		},
//		"gearIcon": "gears.svg",
//		"gearW": "360",
//		"gearH": "500",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1H1T7ISV57",
//			"attrs": {}
//		},
//		"mockupStates": {
//			"jaxId": "1I286DL2O0",
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1H1T7ISV51",
//			"attrs": {
//				"properties": {
//					"jaxId": "1H1T7ISV58",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "50%",
//						"y": "10%",
//						"w": "90%",
//						"h": "\"\"",
//						"anchorH": "Center",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "10",
//						"minW": "",
//						"minH": "",
//						"maxW": "600",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Flex Y"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1H1T7LGH40",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1T83E7O0",
//									"attrs": {
//										"type": "box",
//										"id": "BoxBG",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor.body",
//										"border": "2",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor[\"fontBodySub\"]",
//										"corner": "5",
//										"shadow": "true",
//										"shadowX": "3",
//										"shadowY": "6",
//										"shadowBlur": "5",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.30]"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H1T83E7O1",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1H1T83E7O2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H1T83E7O3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1H1T7O2SA0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1T83E7O4",
//									"attrs": {
//										"type": "text",
//										"id": "TxtTitle",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "\"\"",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,10,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#cfgColor.fontBodySub",
//										"text": "${state.title},state",
//										"font": "",
//										"fontSize": "#txtSize.big",
//										"bold": "true",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Top",
//										"wrap": "false",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0",
//										"autoSizeW": "false",
//										"autoSizeH": "false"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H1T83E7O5",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1H1T83E7O6",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H1T83E7O7",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1H1T7S0BE0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1T83E7O8",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxContent",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "\"\"",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Auto Scroll Y",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "30",
//										"maxW": "",
//										"maxH": "380",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex Y"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/DataView.js",
//											"jaxId": "1I286IE710",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1I286K9EM0",
//													"attrs": {
//														"box": "null",
//														"template": "null",
//														"dataObj": "null",
//														"property": "",
//														"options": {
//															"jaxId": "1I286K9EM1",
//															"attrs": {
//																"titleHeight": "30",
//																"titleSize": "18",
//																"titleColor": "#cfgColor[\"fontBody\"]",
//																"titleBold": "false",
//																"lineHeight": "30",
//																"lineGap": "8",
//																"labelSize": "15",
//																"labelColor": "#cfgColor[\"fontBody\"]",
//																"labelBold": "true",
//																"labelLine": "true",
//																"valueSize": "16",
//																"valueColor": "#cfgColor[\"fontBody\"]",
//																"valueBold": "false",
//																"segHeight": "20",
//																"segSize": "14",
//																"segBold": "true",
//																"segColor": "#cfgColor[\"fontBody\"]",
//																"trace": "false",
//																"edit": "false",
//																"noteSize": "16"
//															}
//														},
//														"title": "Object View"
//													}
//												},
//												"properties": {
//													"jaxId": "1I286K9EM2",
//													"attrs": {
//														"type": "#null#>DataView(null,null,null,\"\",{\"titleHeight\":30,\"titleSize\":18,\"titleColor\":cfgColor[\"fontBody\"],\"titleBold\":false,\"lineHeight\":30,\"lineGap\":8,\"labelSize\":15,\"labelColor\":cfgColor[\"fontBody\"],\"labelBold\":true,\"labelLine\":true,\"valueSize\":16,\"valueColor\":cfgColor[\"fontBody\"],\"valueBold\":false,\"segHeight\":20,\"segSize\":14,\"segBold\":true,\"segColor\":cfgColor[\"fontBody\"],\"trace\":false,\"edit\":false,\"noteSize\":16},\"Object View\")",
//														"id": "DvData",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": ""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I286K9EM3",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1I286K9EM4",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I286K9EM5",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1I286K9EM6",
//													"attrs": {}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1H1T83E7O9",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1H1T83E7O10",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H1T83E7O11",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1H1T7UCES0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1T83E7O12",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxButtons",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[5,0,0,0]",
//										"padding": "0",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex X",
//										"subAlign": "End",
//										"attach": "true",
//										"flex": "false",
//										"itemsAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnText.js",
//											"jaxId": "1I286EKD00",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1I286GFFB0",
//													"attrs": {
//														"style": "primary",
//														"w": "100",
//														"h": "24",
//														"text": {
//															"type": "string",
//															"valText": "Close",
//															"localize": {
//																"EN": "Close",
//																"CN": "关闭"
//															},
//															"localizable": true
//														},
//														"outlined": "false",
//														"icon": ""
//													}
//												},
//												"properties": {
//													"jaxId": "1I286GFFB1",
//													"attrs": {
//														"type": "#null#>BtnText(\"primary\",100,24,(($ln===\"CN\")?(\"关闭\"):(\"Close\")),false,\"\")",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": ""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I286GFFB2",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1I286GFFB3",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1I288P9KH0",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1I288PJ660",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1I286GFFB4",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1I286GFFB5",
//													"attrs": {
//														"Slot1H2F6U36O0": {
//															"jaxId": "1I286GFFB6",
//															"attrs": {
//																"subHuds": {
//																	"attrs": []
//																},
//																"container": "true"
//															}
//														}
//													}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1H1T83E7O13",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1H1T83E7O14",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H1T83E7O15",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1H1T7ISV59",
//					"attrs": {}
//				},
//				"functions": {
//					"jaxId": "1H1T7ISV510",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1H1T7ISV511",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "true",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1H1T7ISV512",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "true",
//				"h": "true",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"innerLayout": {
//					"valText": "false"
//				},
//				"marginL": {
//					"valText": "false"
//				},
//				"marginR": {
//					"valText": "false"
//				},
//				"marginT": {
//					"valText": "false"
//				},
//				"marginB": {
//					"valText": "false"
//				},
//				"paddingL": {
//					"valText": "false"
//				},
//				"paddingR": {
//					"valText": "false"
//				},
//				"paddingT": {
//					"valText": "false"
//				},
//				"paddingB": {
//					"valText": "false"
//				},
//				"attach": {
//					"valText": "false"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}