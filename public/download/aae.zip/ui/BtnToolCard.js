//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
/*#{1IVOTP04N0StartDoc*/
import {tabNT} from "/@tabos";
import {getLocalAppInfo} from "/@pkg/pkgUtil.js";
/*}#1IVOTP04N0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BtnToolCard=function(tool){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let txtTime,btnDownload,boxCheck,btnUpdate;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1IVOTP04N17LocalVals*/
	let action="";
	/*}#1IVOTP04N17LocalVals*/
	
	/*#{1IVOTP04N17PreState*/
	/*}#1IVOTP04N17PreState*/
	state={
		"icon":appCfg.sharedAssets+"/browser.svg","label":tool,"desc":(($ln==="CN")?("正在加载……"):("loading...")),"date":"---- / -- / --",
		/*#{1IVOTP04N6ExState*/
		/*}#1IVOTP04N6ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1IVOTP04N17PostState*/
	/*}#1IVOTP04N17PostState*/
	cssVO={
		"hash":"1IVOTP04N17",nameHost:true,
		"type":"box","position":"relative","x":125,"y":40,"w":250,"h":100,"anchorX":1,"anchorY":1,"cursor":"pointer","margin":10,"padding":[10,10,5,10],"minW":"",
		"minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["body"],"border":1,"borderColor":cfgColor["secondary"],"corner":12,"contentLayout":"flex-x",
		children:[
			{
				"hash":"1IVOTP04N19",
				"type":"hud","position":"relative","x":0,"y":0,"w":50,"h":"100%","uiEvent":-1,"padding":[0,0,20,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"contentLayout":"flex-y","subAlign":1,
				children:[
					{
						"hash":"1IVOTP04P0",
						"type":"image","position":"relative","x":"50%","y":0,"w":50,"h":50,"anchorX":1,"uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						"image":$P(()=>(state.icon),state),"fitSize":true,
					}
				],
			},
			{
				"hash":"1IVOTP04Q4",
				"type":"hud","position":"relative","x":0,"y":0,"w":100,"h":"","margin":[0,0,0,5],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","flex":true,
				"contentLayout":"flex-y",
				children:[
					{
						"hash":"1IVOTP04Q6",
						"type":"text","position":"relative","x":0,"y":0,"w":"100%","h":"","uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
						"text":$P(()=>(state.label),state),"fontSize":txtSize.mid,"fontWeight":"bold","fontStyle":"normal","textDecoration":"","ellipsis":true,
					},
					{
						"hash":"1IVOTP04Q15",
						"type":"text","position":"relative","x":0,"y":0,"w":"100%","h":30,"uiEvent":-1,"margin":[3,0,3,0],"padding":[3,0,3,0],"minW":"","minH":"","maxW":"",
						"maxH":"","styleClass":"","color":cfgColor["fontBody"],"text":$P(()=>(state.desc),state),"fontSize":txtSize.smallPlus-1,"fontWeight":"normal","fontStyle":"normal",
						"textDecoration":"","alignV":1,"wrap":true,"ellipsis":true,"lineClamp":2,"flex":true,
					},
					{
						"hash":"1IVOU2GUR0",
						"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":24,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
						"itemsAlign":1,
						children:[
							{
								"hash":"1IVOU7OLB0",
								"type":"box","position":"relative","x":0,"y":0,"w":20,"h":20,"uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["fontBodySub"],
								"maskImage":appCfg.sharedAssets+"/recent.svg",
							},
							{
								"hash":"1IVOUE8N00",
								"type":"text","id":"TxtTime","position":"relative","x":0,"y":0,"w":"","h":"","uiEvent":-1,"margin":[0,0,0,4],"minW":"","minH":"","maxW":"","maxH":"",
								"styleClass":"","color":cfgColor["secondary"],"text":$P(()=>(state.date),state),"fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal",
								"textDecoration":"","flex":true,
							},
							{
								"hash":"1IVOUMBNO0",
								"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/trash.svg",null),"id":"BtnRemove","position":"relative","x":0,"y":0,"display":0,
							},
							{
								"hash":"1IVOUGQ1V0",
								"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/download.svg",null),"id":"BtnDownload","position":"relative","x":0,"y":0,"display":0,
							},
							{
								"hash":"1IVOUSAPL0",
								"type":"box","id":"BoxCheck","position":"relative","x":0,"y":0,"w":24,"h":24,"display":0,"uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"",
								"styleClass":"","background":cfgColor["success"],"maskImage":appCfg.sharedAssets+"/check.svg",
							},
							{
								"hash":"1IVOV3E2F0",
								"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/update.svg",null),"id":"BtnUpdate","position":"relative","x":0,"y":0,"display":0,
							}
						],
					}
				],
			},
			{
				"hash":"1IVOTP04Q29",
				"type":"box","id":"BoxMenu","x":">calc(100% - 33px)","y":3,"w":30,"h":30,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":[255,255,255,1],
				"border":2,"corner":6,"attached":false,
				children:[
					{
						"hash":"1IVOTP04Q31",
						"type":BtnIcon("front",28,0,appCfg.sharedAssets+"/menu.svg",null),"x":"50%","y":"50%","anchorX":1,"anchorY":1,
						"OnClick":function(event){
							/*#{1IVOTP04Q38FunctionBody*/
							/*}#1IVOTP04Q38FunctionBody*/
						},
					}
				],
			}
		],
		/*#{1IVOTP04N17ExtraCSS*/
		/*}#1IVOTP04N17ExtraCSS*/
		faces:{
			"normal":{
				"#self":{
					"border":1,"padding":[10,10,5,10],"background":cfgColor["body"]
				},
				"#1IVOTP04P0":{
					"alpha":0.7,"w":50
				},
				"#1IVOTP04Q6":{
					"color":cfgColor["fontBodySub"]
				},
				"#1IVOTP04Q15":{
					"color":cfgColor["fontBodySub"]
				},
				/*BoxMenu*/"#1IVOTP04Q29":{
					"display":0
				}
			},"hover":{
				"#self":{
					"border":2,"padding":[9,9,4,9],"background":cfgColor["body"]
				},
				"#1IVOTP04P0":{
					"alpha":1,"scale":undefined,"w":54,"h":54
				},
				"#1IVOTP04Q6":{
					"color":cfgColor["fontBody"]
				},
				"#1IVOTP04Q15":{
					"color":cfgColor["fontBody"]
				},
				/*BoxMenu*/"#1IVOTP04Q29":{
					"display":1
				}
			},"install":{
				/*BtnRemove*/"#1IVOUMBNO0":{
					"display":0
				},
				/*BtnDownload*/"#1IVOUGQ1V0":{
					"display":1
				},
				/*BoxCheck*/"#1IVOUSAPL0":{
					"display":0
				},
				/*BtnUpdate*/"#1IVOV3E2F0":{
					"display":0
				}
			},"update":{
				/*BtnRemove*/"#1IVOUMBNO0":{
					"display":0
				},
				/*BtnDownload*/"#1IVOUGQ1V0":{
					"display":0
				},
				/*BoxCheck*/"#1IVOUSAPL0":{
					"display":0
				},
				/*BtnUpdate*/"#1IVOV3E2F0":{
					"display":1
				}
			},"check":{
				/*BtnRemove*/"#1IVOUMBNO0":{
					"display":0
				},
				/*BtnDownload*/"#1IVOUGQ1V0":{
					"display":0
				},
				/*BoxCheck*/"#1IVOUSAPL0":{
					"display":1
				},
				/*BtnUpdate*/"#1IVOV3E2F0":{
					"display":0
				}
			}
		},
		OnCreate:function(){
			self=this;
			txtTime=self.TxtTime;btnDownload=self.BtnDownload;boxCheck=self.BoxCheck;btnUpdate=self.BtnUpdate;
			/*#{1IVOTP04N17Create*/
			self.showFace("normal");
			self.loadInfo();
			self.aniShow();
			/*}#1IVOTP04N17Create*/
		},
		/*#{1IVOTP04N17EndCSS*/
		/*}#1IVOTP04N17EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.OnMouseInOut=function(isIn,event){
		/*#{1IVOTP04Q55FunctionBody*/
		if(action){
			if(isIn){
				self.showFace("hover");
			}else{
				self.showFace("normal");
			}
		}
		/*}#1IVOTP04Q55FunctionBody*/
	};
	
	//------------------------------------------------------------------------
	cssVO.OnClick=function(event){
		/*#{1IVPRFVN90FunctionBody*/
		console.log("Card click");
		switch(action){
			case "Start":
				//TODO: Code this:
				break;
			case "Install":
				//TODO: Code this:
				break;
		}
		/*}#1IVPRFVN90FunctionBody*/
	};
	//------------------------------------------------------------------------
	cssVO.aniShow=async function(){
		/*#{1IVOTP04N7Start*/
		self.animate({type:"in",scale:0.8,alpha:0.5,time:50+Math.floor(Math.random()*5)*50});
		/*}#1IVOTP04N7Start*/
	};
	//------------------------------------------------------------------------
	cssVO.loadInfo=async function(){
		/*#{1IVPMEB1B0Start*/
		let res,info,name;
		if(typeof(tool)==="string"){
			res=await tabNT.makeCall("GetAppInfo",{appId:tool});
			if(!res || res.code!==200){
				state.description=(($ln==="CN")?("获取信息失败。"):/*EN*/("Get info failed."));
				return;
			}
			info=res.info;
		}else{
			info=tool;
		}
		state.description=info.desc;
		name=info.name;
		name=name[$ln]||name["EN"]||name;
		state.name=name;
		state.date=new Intl.DateTimeFormat('en-CA').format(new Date(info.updateTime));
		state.icon=info.icon;
		
		//Check if local installed, or need upgrade?
		let localInfo=await getLocalAppInfo(info.appId);
		if(!localInfo){
			self.showFace("install");
			action="Install";
		}else if(localInfo.appVersionIdx<info.versionIdx){
			self.showFace("update");
			action="Start";
		}else{
			self.showFace("check");
			action="Start";
		}
		/*}#1IVPMEB1B0Start*/
	};
	/*#{1IVOTP04N17PostCSSVO*/
	/*}#1IVOTP04N17PostCSSVO*/
	cssVO.constructor=BtnToolCard;
	return cssVO;
};
/*#{1IVOTP04N17ExCodes*/
/*}#1IVOTP04N17ExCodes*/

//----------------------------------------------------------------------------
BtnToolCard.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1IVOTP04N17PreAISpot*/
	/*}#1IVOTP04N17PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1IVOTP04N17PostAISpot*/
	/*}#1IVOTP04N17PostAISpot*/
	return exposeVO;
};

//----------------------------------------------------------------------------
BtnToolCard.gearExport={
	framework: "jax",
	hudType: "box",
	"showName":"",icon:"gears.svg",previewImg:false,
	fixPose:false,initW:100,initH:100,
	catalog:"",
	args: {
		"tool": {
			"name": "tool", "showName": "tool", "type": "auto", "key": true, "fixed": true, "initVal": "Deepthink@avdpro@me.com"
		}
	},
	state:{
	},
	properties:["id","position","x","y","display"],
	faces:["normal","hover","install","update","check"],
	subContainers:{
	},
	/*#{1IVOTP04N0ExGearInfo*/
	/*}#1IVOTP04N0ExGearInfo*/
};
/*#{1IVOTP04N0EndDoc*/
/*}#1IVOTP04N0EndDoc*/

export default BtnToolCard;
export{BtnToolCard};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearBox",
//	"jaxId": "1IVOTP04N0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1IVOTP04N1",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1IVOTP04N2",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1IVOTP04N3",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1IVOTP04N4",
//			"attrs": {
//				"tool": {
//					"type": "auto",
//					"valText": "\"Deepthink@avdpro@me.com\""
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1IVOTP04N5",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1IVOTP04N6",
//			"attrs": {
//				"icon": {
//					"type": "string",
//					"valText": "#appCfg.sharedAssets+\"/browser.svg\""
//				},
//				"label": {
//					"type": "string",
//					"valText": "#tool"
//				},
//				"desc": {
//					"type": "string",
//					"valText": "loading...",
//					"localize": {
//						"EN": "loading...",
//						"CN": "正在加载……"
//					},
//					"localizable": true
//				},
//				"date": {
//					"type": "string",
//					"valText": "---- / -- / --"
//				}
//			}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IVOTP04N7",
//					"attrs": {
//						"id": "aniShow",
//						"label": "New AI Seg",
//						"x": "65",
//						"y": "70",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IVOTP04N8",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IVOTP04N9",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IVOTP04N10",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IVPMEB1B0",
//					"attrs": {
//						"id": "loadInfo",
//						"label": "New AI Seg",
//						"x": "65",
//						"y": "155",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IVPMEI8I0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IVPMEI8I1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IVPMEI8I2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				}
//			]
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1IVOTP04N11",
//			"attrs": {
//				"normal": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IVOTP04N12",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IVOTP04N13",
//							"attrs": {}
//						}
//					}
//				},
//				"hover": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IVOTP04N14",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IVOTP04N15",
//							"attrs": {}
//						}
//					}
//				},
//				"install": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IVPQF8VF0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IVPQGAIV0",
//							"attrs": {}
//						}
//					}
//				},
//				"update": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IVPQH93O0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IVPQOB8L0",
//							"attrs": {}
//						}
//					}
//				},
//				"check": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IVPQHCTP0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IVPQOB8L1",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1IVOTP04N16",
//			"attrs": {}
//		},
//		"exposeToAI": "true",
//		"descAI": "",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "box",
//			"jaxId": "1IVOTP04N17",
//			"attrs": {
//				"properties": {
//					"jaxId": "1IVOTP04N18",
//					"attrs": {
//						"type": "box",
//						"id": "",
//						"position": "Relative",
//						"x": "125",
//						"y": "40",
//						"w": "250",
//						"h": "100",
//						"anchorH": "Center",
//						"anchorV": "Center",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "pointer",
//						"zIndex": "0",
//						"margin": "10",
//						"padding": "[10,10,5,10]",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"background": "#cfgColor[\"body\"]",
//						"border": "1",
//						"borderStyle": "Solid",
//						"borderColor": "#cfgColor[\"secondary\"]",
//						"corner": "12",
//						"shadow": "false",
//						"shadowX": "2",
//						"shadowY": "2",
//						"shadowBlur": "3",
//						"shadowSpread": "0",
//						"shadowColor": "[0,0,0,0.50]",
//						"contentLayout": "Flex X"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1IVOTP04N19",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IVOTP04N20",
//									"attrs": {
//										"type": "hud",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "50",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "[0,0,20,0]",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex Y",
//										"subAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "image",
//											"jaxId": "1IVOTP04P0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IVOTP04P1",
//													"attrs": {
//														"type": "image",
//														"id": "",
//														"position": "relative",
//														"x": "50%",
//														"y": "0",
//														"w": "50",
//														"h": "50",
//														"anchorH": "Center",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "Tree Off",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"image": "${state.icon},state",
//														"autoSize": "false",
//														"fitSize": "Fit",
//														"repeat": "true",
//														"alignX": "Left",
//														"alignY": "Top"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IVOTP04P2",
//													"attrs": {
//														"1IVOTP04N14": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVOTP04P3",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVOTP04P4",
//																	"attrs": {
//																		"alpha": {
//																			"type": "number",
//																			"valText": "1",
//																			"editMode": "range",
//																			"editType": "range"
//																		},
//																		"scale": {
//																			"type": "auto",
//																			"valText": ""
//																		},
//																		"w": {
//																			"type": "length",
//																			"valText": "54"
//																		},
//																		"h": {
//																			"type": "length",
//																			"valText": "54"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IVOTP04N14",
//															"faceTagName": "hover"
//														},
//														"1IVOTP04N12": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVOTP04P5",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVOTP04P6",
//																	"attrs": {
//																		"alpha": {
//																			"type": "number",
//																			"valText": "0.7",
//																			"editMode": "range",
//																			"editType": "range"
//																		},
//																		"w": {
//																			"type": "length",
//																			"valText": "50"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IVOTP04N12",
//															"faceTagName": "normal"
//														},
//														"1IVPQF8VF0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVPQOB8L2",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVPQOB8L3",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IVPQF8VF0",
//															"faceTagName": "install"
//														},
//														"1IVPQH93O0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVPQOB8L4",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVPQOB8L5",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IVPQH93O0",
//															"faceTagName": "update"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IVOTP04P7",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IVOTP04P8",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1IVOTP04P23",
//									"attrs": {
//										"1IVOTP04N14": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IVPMDOKC0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IVPMDOKC1",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IVOTP04N14",
//											"faceTagName": "hover"
//										},
//										"1IVPQF8VF0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IVPQOB8L8",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IVPQOB8L9",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IVPQF8VF0",
//											"faceTagName": "install"
//										},
//										"1IVPQH93O0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IVPQOB8L10",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IVPQOB8L11",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IVPQH93O0",
//											"faceTagName": "update"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1IVOTP04Q2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IVOTP04Q3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1IVOTP04Q4",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IVOTP04Q5",
//									"attrs": {
//										"type": "hud",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,5]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"flex": "true",
//										"contentLayout": "Flex Y",
//										"subAlign": "Start"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1IVOTP04Q6",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IVOTP04Q7",
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "Tree Off",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBody\"]",
//														"text": "${state.label},state",
//														"font": "",
//														"fontSize": "#txtSize.mid",
//														"bold": "true",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "true",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IVOTP04Q8",
//													"attrs": {
//														"1IVOTP04N14": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVOTP04Q9",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVOTP04Q10",
//																	"attrs": {
//																		"color": {
//																			"type": "colorRGB",
//																			"valText": "#cfgColor[\"fontBody\"]"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IVOTP04N14",
//															"faceTagName": "hover"
//														},
//														"1IVOTP04N12": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVOTP04Q11",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVOTP04Q12",
//																	"attrs": {
//																		"color": {
//																			"type": "colorRGB",
//																			"valText": "#cfgColor[\"fontBodySub\"]"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IVOTP04N12",
//															"faceTagName": "normal"
//														},
//														"1IVPQF8VF0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVPQOB8L14",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVPQOB8L15",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IVPQF8VF0",
//															"faceTagName": "install"
//														},
//														"1IVPQH93O0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVPQOB8L16",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVPQOB8L17",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IVPQH93O0",
//															"faceTagName": "update"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IVOTP04Q13",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IVOTP04Q14",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1IVOTP04Q15",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IVOTP04Q16",
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "30",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "Tree Off",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[3,0,3,0]",
//														"padding": "[3,0,3,0]",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBody\"]",
//														"text": "${state.desc},state",
//														"font": "",
//														"fontSize": "#txtSize.smallPlus-1",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Center",
//														"wrap": "true",
//														"ellipsis": "true",
//														"lineClamp": "2",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0",
//														"flex": "true"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IVOTP04Q17",
//													"attrs": {
//														"1IVOTP04N14": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVOTP04Q18",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVOTP04Q19",
//																	"attrs": {
//																		"color": {
//																			"type": "colorRGB",
//																			"valText": "#cfgColor[\"fontBody\"]"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IVOTP04N14",
//															"faceTagName": "hover"
//														},
//														"1IVOTP04N12": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVOTP04Q20",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVOTP04Q21",
//																	"attrs": {
//																		"color": {
//																			"type": "colorRGB",
//																			"valText": "#cfgColor[\"fontBodySub\"]"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IVOTP04N12",
//															"faceTagName": "normal"
//														},
//														"1IVPQF8VF0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVPQOB8L20",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVPQOB8L21",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IVPQF8VF0",
//															"faceTagName": "install"
//														},
//														"1IVPQH93O0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVPQOB8L22",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVPQOB8L23",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IVPQH93O0",
//															"faceTagName": "update"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IVOTP04Q22",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IVOTP04Q23",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1IVOU2GUR0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IVOU2KDH0",
//													"attrs": {
//														"type": "hud",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "24",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex X",
//														"subAlign": "Start",
//														"itemsAlign": "Center"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "box",
//															"jaxId": "1IVOU7OLB0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVOU9JMP0",
//																	"attrs": {
//																		"type": "box",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "20",
//																		"h": "20",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "Tree Off",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"background": "#cfgColor[\"fontBodySub\"]",
//																		"border": "0",
//																		"borderStyle": "Solid",
//																		"borderColor": "[0,0,0,1.00]",
//																		"corner": "0",
//																		"shadow": "false",
//																		"shadowX": "2",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowSpread": "0",
//																		"shadowColor": "[0,0,0,0.50]",
//																		"maskImage": "#appCfg.sharedAssets+\"/recent.svg\""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IVOU9JMP1",
//																	"attrs": {
//																		"1IVOTP04N14": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVPMDOKC2",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVPMDOKD0",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IVOTP04N14",
//																			"faceTagName": "hover"
//																		},
//																		"1IVPQF8VF0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVPQOB8L26",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVPQOB8L27",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IVPQF8VF0",
//																			"faceTagName": "install"
//																		},
//																		"1IVPQH93O0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVPQOB8L28",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVPQOB8L29",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IVPQH93O0",
//																			"faceTagName": "update"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1IVOU9JMP2",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1IVOU9JMP3",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1IVOUE8N00",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVOUR0A50",
//																	"attrs": {
//																		"type": "text",
//																		"id": "TxtTime",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "Tree Off",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[0,0,0,4]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"secondary\"]",
//																		"text": "${state.date},state",
//																		"font": "",
//																		"fontSize": "#txtSize.small",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Top",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"lineClamp": "0",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0",
//																		"flex": "true"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IVOUR0A51",
//																	"attrs": {
//																		"1IVOTP04N14": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVPMDOKD1",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVPMDOKD2",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IVOTP04N14",
//																			"faceTagName": "hover"
//																		},
//																		"1IVPQF8VF0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVPQOB8L32",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVPQOB8L33",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IVPQF8VF0",
//																			"faceTagName": "install"
//																		},
//																		"1IVPQH93O0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVPQOB8L34",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVPQOB8L35",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IVPQH93O0",
//																			"faceTagName": "update"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1IVOUR0A52",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1IVOUR0A53",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1IVOUMBNO0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1IVOUMBNO1",
//																	"attrs": {
//																		"style": "\"front\"",
//																		"w": "24",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/trash.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1IVOUMBNO2",
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"front\",24,0,appCfg.sharedAssets+\"/trash.svg\",null)",
//																		"id": "BtnRemove",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "Off",
//																		"face": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IVOUMBNO3",
//																	"attrs": {
//																		"1IVOTP04N14": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVPMDOKD3",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVPMDOKD4",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IVOTP04N14",
//																			"faceTagName": "hover"
//																		},
//																		"1IVPQF8VF0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVPQGAIV13",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVPQGAIV14",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IVPQF8VF0",
//																			"faceTagName": "install"
//																		},
//																		"1IVPQH93O0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVPQOB8L38",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVPQOB8L39",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IVPQH93O0",
//																			"faceTagName": "update"
//																		},
//																		"1IVPQHCTP0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVPQOB8L40",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVPQOB8L41",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IVPQHCTP0",
//																			"faceTagName": "check"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1IVOUMBNO4",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1IVOUMBNO5",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1IVOUMBNO6",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1IVOUGQ1V0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1IVOUM8520",
//																	"attrs": {
//																		"style": "\"front\"",
//																		"w": "24",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/download.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1IVOUM8521",
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"front\",24,0,appCfg.sharedAssets+\"/download.svg\",null)",
//																		"id": "BtnDownload",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "Off",
//																		"face": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IVOUM8522",
//																	"attrs": {
//																		"1IVOTP04N14": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVPMDOKD5",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVPMDOKD6",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IVOTP04N14",
//																			"faceTagName": "hover"
//																		},
//																		"1IVPQF8VF0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVPQGAIV15",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVPQGAIV16",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IVPQF8VF0",
//																			"faceTagName": "install"
//																		},
//																		"1IVPQH93O0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVPQOB8L42",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVPQOB8L43",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IVPQH93O0",
//																			"faceTagName": "update"
//																		},
//																		"1IVPQHCTP0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVPQOB8L44",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVPQOB8L45",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IVPQHCTP0",
//																			"faceTagName": "check"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1IVOUM8523",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1IVOUM8524",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1IVOUM8525",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "box",
//															"jaxId": "1IVOUSAPL0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVOUSJBA0",
//																	"attrs": {
//																		"type": "box",
//																		"id": "BoxCheck",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "24",
//																		"h": "24",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "Off",
//																		"clip": "Off",
//																		"uiEvent": "Tree Off",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"background": "#cfgColor[\"success\"]",
//																		"border": "0",
//																		"borderStyle": "Solid",
//																		"borderColor": "[0,0,0,1.00]",
//																		"corner": "0",
//																		"shadow": "false",
//																		"shadowX": "2",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowSpread": "0",
//																		"shadowColor": "[0,0,0,0.50]",
//																		"maskImage": "#appCfg.sharedAssets+\"/check.svg\""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IVOUSJBA1",
//																	"attrs": {
//																		"1IVOTP04N14": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVPMDOKD7",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVPMDOKD8",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IVOTP04N14",
//																			"faceTagName": "hover"
//																		},
//																		"1IVPQF8VF0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVPQGAIV17",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVPQGAIV18",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IVPQF8VF0",
//																			"faceTagName": "install"
//																		},
//																		"1IVPQH93O0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVPQOB8L46",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVPQOB8L47",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IVPQH93O0",
//																			"faceTagName": "update"
//																		},
//																		"1IVPQHCTP0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVPQOB8L48",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVPQOB8L49",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IVPQHCTP0",
//																			"faceTagName": "check"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1IVOUSJBA2",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1IVOUSJBA3",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "true"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1IVOV3E2F0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1IVOV3E2F1",
//																	"attrs": {
//																		"style": "\"front\"",
//																		"w": "24",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/update.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1IVOV3E2F2",
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"front\",24,0,appCfg.sharedAssets+\"/update.svg\",null)",
//																		"id": "BtnUpdate",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "Off",
//																		"face": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IVOV3E2F3",
//																	"attrs": {
//																		"1IVOTP04N14": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVPMDOKD9",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVPMDOKD10",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IVOTP04N14",
//																			"faceTagName": "hover"
//																		},
//																		"1IVPQF8VF0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVPQGAIV19",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVPQGAIV20",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IVPQF8VF0",
//																			"faceTagName": "install"
//																		},
//																		"1IVPQH93O0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVPQOB8L50",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVPQOB8L51",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IVPQH93O0",
//																			"faceTagName": "update"
//																		},
//																		"1IVPQHCTP0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVPQOB8L52",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVPQOB8L53",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IVPQHCTP0",
//																			"faceTagName": "check"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1IVOV3E2F4",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1IVOV3E2F5",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1IVOV3E2F6",
//																	"attrs": {}
//																}
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1IVOU2KDH1",
//													"attrs": {
//														"1IVOTP04N14": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVPMDOKD11",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVPMDOKD12",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IVOTP04N14",
//															"faceTagName": "hover"
//														},
//														"1IVPQF8VF0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVPQOB8L54",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVPQOB8L55",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IVPQF8VF0",
//															"faceTagName": "install"
//														},
//														"1IVPQH93O0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVPQOB8L56",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVPQOB8L57",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IVPQH93O0",
//															"faceTagName": "update"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IVOU2KDH2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IVOU2KDH3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1IVOTP04Q24",
//									"attrs": {
//										"1IVOTP04N14": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IVPMDOKD13",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IVPMDOKD14",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IVOTP04N14",
//											"faceTagName": "hover"
//										},
//										"1IVPQF8VF0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IVPQOB8L60",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IVPQOB8L61",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IVPQF8VF0",
//											"faceTagName": "install"
//										},
//										"1IVPQH93O0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IVPQOB8L62",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IVPQOB8L63",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IVPQH93O0",
//											"faceTagName": "update"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1IVOTP04Q27",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IVOTP04Q28",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1IVOTP04Q29",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IVOTP04Q30",
//									"attrs": {
//										"type": "box",
//										"id": "BoxMenu",
//										"position": "Absolute",
//										"x": "100%-33",
//										"y": "3",
//										"w": "30",
//										"h": "30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "[255,255,255,1.00]",
//										"border": "2",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "6",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"attach": "false"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1IVOTP04Q31",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1IVOTP04Q32",
//													"attrs": {
//														"style": "\"front\"",
//														"w": "28",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/menu.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1IVOTP04Q33",
//													"attrs": {
//														"type": "#null#>BtnIcon(\"front\",28,0,appCfg.sharedAssets+\"/menu.svg\",null)",
//														"id": "",
//														"position": "Absolute",
//														"x": "50%",
//														"y": "50%",
//														"display": "On",
//														"face": "",
//														"anchorH": "Center",
//														"anchorV": "Center"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IVOTP04Q34",
//													"attrs": {
//														"1IVOTP04N14": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVPMDOKD15",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVPMDOKD16",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IVOTP04N14",
//															"faceTagName": "hover"
//														},
//														"1IVPQF8VF0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVPQOB8L66",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVPQOB8L67",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IVPQF8VF0",
//															"faceTagName": "install"
//														},
//														"1IVPQH93O0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVPQOB8L68",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVPQOB8L69",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IVPQH93O0",
//															"faceTagName": "update"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IVOTP04Q37",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1IVOTP04Q38",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1IVOTP04Q39",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1IVOTP04Q40",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1IVOTP04Q41",
//													"attrs": {}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1IVOTP04Q42",
//									"attrs": {
//										"1IVOTP04N14": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IVOTP04Q43",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IVOTP04Q44",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IVOTP04N14",
//											"faceTagName": "hover"
//										},
//										"1IVOTP04N12": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IVOTP04Q45",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IVOTP04Q46",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IVOTP04N12",
//											"faceTagName": "normal"
//										},
//										"1IVPQF8VF0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IVPQOB8L72",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IVPQOB8L73",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IVPQF8VF0",
//											"faceTagName": "install"
//										},
//										"1IVPQH93O0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IVPQOB8L74",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IVPQOB8L75",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IVPQH93O0",
//											"faceTagName": "update"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1IVOTP04Q47",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IVOTP04Q48",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1IVOTP04Q49",
//					"attrs": {
//						"1IVOTP04N14": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1IVOTP04Q50",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IVOTP04Q51",
//									"attrs": {
//										"border": {
//											"type": "auto",
//											"valText": "2",
//											"editMode": "edges"
//										},
//										"padding": {
//											"type": "auto",
//											"valText": "[9,9,4,9]",
//											"editMode": "edges"
//										},
//										"background": {
//											"type": "colorRGBA",
//											"valText": "#cfgColor[\"body\"]"
//										}
//									}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1IVOTP04N14",
//							"faceTagName": "hover"
//						},
//						"1IVOTP04N12": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1IVOTP04Q52",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IVOTP04Q53",
//									"attrs": {
//										"border": {
//											"type": "auto",
//											"valText": "1",
//											"editMode": "edges"
//										},
//										"padding": {
//											"type": "auto",
//											"valText": "[10,10,5,10]",
//											"editMode": "edges"
//										},
//										"background": {
//											"type": "colorRGBA",
//											"valText": "#cfgColor[\"body\"]"
//										}
//									}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1IVOTP04N12",
//							"faceTagName": "normal"
//						},
//						"1IVPQF8VF0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1IVPQOB8L78",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IVPQOB8L79",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1IVPQF8VF0",
//							"faceTagName": "install"
//						},
//						"1IVPQH93O0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1IVPQOB8L80",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IVPQOB8L81",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1IVPQH93O0",
//							"faceTagName": "update"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1IVOTP04Q54",
//					"attrs": {
//						"OnMouseInOut": {
//							"type": "fixedFunc",
//							"jaxId": "1IVOTP04Q55",
//							"attrs": {
//								"callArgs": {
//									"jaxId": "1IVOTP04Q56",
//									"attrs": {
//										"isIn": "",
//										"event": ""
//									}
//								},
//								"seg": ""
//							}
//						},
//						"OnClick": {
//							"type": "fixedFunc",
//							"jaxId": "1IVPRFVN90",
//							"attrs": {
//								"callArgs": {
//									"jaxId": "1IVPRHE9G0",
//									"attrs": {
//										"event": ""
//									}
//								},
//								"seg": ""
//							}
//						}
//					}
//				},
//				"extraPpts": {
//					"jaxId": "1IVOTP04Q57",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "true",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1IVOTP04R0",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false",
//				"background": "false",
//				"color": "false",
//				"gradient": "false",
//				"border": "false",
//				"borders": "false",
//				"borderStyle": "false",
//				"borderColor": "false",
//				"borderColors": "false",
//				"corner": "false",
//				"coner": "false",
//				"coners": "false",
//				"shadow": "false",
//				"shadowX": "false",
//				"shadowY": "false",
//				"shadowBlur": "false",
//				"shadowSpread": "false",
//				"shadowColor": "false",
//				"maskImage": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}