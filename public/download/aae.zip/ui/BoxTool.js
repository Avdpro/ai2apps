//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
/*#{1I1I7N5V30StartDoc*/
/*}#1I1I7N5V30StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BoxTool=function(tool,group){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1I1BV49TB1LocalVals*/
	/*}#1I1BV49TB1LocalVals*/
	
	/*#{1I1BV49TB1PreState*/
	/*}#1I1BV49TB1PreState*/
	state={
		"icon":appCfg.sharedAssets+"/browser.svg","label":tool.label||tool.name||tool.host,"desc":tool.description,"enable":!!tool.enable,
		/*#{1I1BV49TC3ExState*/
		/*}#1I1BV49TC3ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1I1BV49TB1PostState*/
	let icon=tool.icon;
	if(icon){
		if(icon[0]!=="/" && !icon.startsWith("data:")){
			icon=appCfg.sharedAssets+"/"+icon;
		}
		state.icon=icon;
	}
	if(tool.getNameText){
		state.label=tool.getNameText($ln);
		state.desc=tool.getDescText($ln);
	}
	/*}#1I1BV49TB1PostState*/
	cssVO={
		"hash":"1I1BV49TB1",nameHost:true,
		"type":"box","position":"relative","x":125,"y":50,"w":250,"h":100,"anchorX":1,"anchorY":1,"cursor":"pointer","margin":10,"padding":10,"minW":"","minH":"",
		"maxW":"","maxH":"","styleClass":"","background":cfgColor["body"],"border":1,"borderColor":cfgColor["secondary"],"corner":12,"contentLayout":"flex-x",
		children:[
			{
				"hash":"1I2778NGE0",
				"type":"hud","position":"relative","x":0,"y":0,"w":50,"h":"100%","uiEvent":-1,"padding":[0,0,20,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"contentLayout":"flex-y","itemsAlign":1,
				children:[
					{
						"hash":"1I27798NN0",
						"type":"image","position":"relative","x":25,"y":"50%","w":50,"h":50,"anchorX":1,"anchorY":1,"uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"",
						"styleClass":"","image":$P(()=>(state.icon),state),"fitSize":true,
					},
					{
						"hash":"1I277A2K60",
						"type":"box","x":"50%","y":">calc(100% - 25px)","w":60,"h":18,"anchorX":1,"display":$P(()=>(!state.enable&&tool.filePath),state),"margin":[5,0,0,0],
						"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["secondary"],"corner":10,
						children:[
							{
								"hash":"1I277A2K70",
								"type":"text","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontSecondary"],"text":"Disabled",
								"fontSize":txtSize.small,"fontWeight":"bold","fontStyle":"normal","textDecoration":"","alignH":1,"alignV":1,
							}
						],
					}
				],
			},
			{
				"hash":"1I1BVAH750",
				"type":"hud","position":"relative","x":0,"y":0,"w":100,"h":"","overflow":1,"uiEvent":-1,"margin":[0,0,0,5],"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","flex":true,"contentLayout":"flex-y","subAlign":1,
				children:[
					{
						"hash":"1I1BVE9S90",
						"type":"text","position":"relative","x":0,"y":0,"w":"100%","h":"","uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
						"text":$P(()=>(state.label),state),"fontWeight":"normal","fontStyle":"normal","textDecoration":"","ellipsis":true,
					},
					{
						"hash":"1I1BVI0RD0",
						"type":"text","position":"relative","x":0,"y":0,"w":"100%","h":"","uiEvent":-1,"margin":[5,0,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						"color":cfgColor["fontBody"],"text":$P(()=>(state.desc),state),"fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
						"alignV":1,"wrap":true,"ellipsis":true,"lineClamp":2,
					}
				],
			},
			{
				"hash":"1I1I9F1JD0",
				"type":"box","id":"BoxMenu","x":">calc(100% - 33px)","y":3,"w":30,"h":30,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":[255,255,255,1],
				"border":2,"corner":6,"attached":(tool.menu===false||group.allTools||group.allChains)?false:true,
				children:[
					{
						"hash":"1I1I9IGEQ0",
						"type":BtnIcon("front",28,0,appCfg.sharedAssets+"/menu.svg",null),"x":"50%","y":"50%","anchorX":1,"anchorY":1,
						"OnClick":function(event){
							/*#{1I1Q4R0DU0FunctionBody*/
							self.showMenu && self.showMenu(this);
							/*}#1I1Q4R0DU0FunctionBody*/
						},
					}
				],
			}
		],
		/*#{1I1BV49TB1ExtraCSS*/
		/*}#1I1BV49TB1ExtraCSS*/
		faces:{
			"normal":{
				"#self":{
					"border":1,"padding":10,"background":cfgColor["body"]
				},
				"#1I27798NN0":{
					"alpha":0.7,"w":50,"h":50,"x":25
				},
				"#1I1BVE9S90":{
					"color":cfgColor["fontBodySub"]
				},
				"#1I1BVI0RD0":{
					"color":cfgColor["fontBodySub"]
				},
				/*BoxMenu*/"#1I1I9F1JD0":{
					"display":0
				}
			},"hover":{
				"#self":{
					"border":2,"padding":9,"background":cfgColor["body"]
				},
				"#1I27798NN0":{
					"alpha":1,"scale":undefined,"w":54,"h":54,"x":27
				},
				"#1I1BVE9S90":{
					"color":cfgColor["fontBody"]
				},
				"#1I1BVI0RD0":{
					"color":cfgColor["fontBody"]
				},
				/*BoxMenu*/"#1I1I9F1JD0":{
					"display":1
				}
			}
		},
		OnCreate:function(){
			self=this;
			
			/*#{1I1BV49TB1Create*/
			self.showFace("normal");
			self.aniShow();
			if(tool.onNotify){
				tool.onNotify("Changed",self.OnToolChanged);
			}
			/*}#1I1BV49TB1Create*/
		},
		/*#{1I1BV49TB1EndCSS*/
		OnFree(){
			if(tool.onNotify){
				tool.offNotify("Changed",self.OnToolChanged);
			}
		}
		/*}#1I1BV49TB1EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.OnMouseInOut=function(isIn,event){
		/*#{1I1C0SC290FunctionBody*/
		if(isIn){
			self.showFace("hover");
		}else{
			self.showFace("normal");
		}
		/*}#1I1C0SC290FunctionBody*/
	};
	//------------------------------------------------------------------------
	cssVO.aniShow=async function(){
		/*#{1I1I5LB920Start*/
		self.animate({type:"in",scale:0.8,alpha:0.5,time:50+Math.floor(Math.random()*5)*50});
		/*}#1I1I5LB920Start*/
	};
	/*#{1I1BV49TB1PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.OnToolChanged=function(){
		state.enable=tool.enable;
	};
	/*}#1I1BV49TB1PostCSSVO*/
	cssVO.constructor=BoxTool;
	return cssVO;
};
/*#{1I1BV49TB1ExCodes*/
/*}#1I1BV49TB1ExCodes*/

//----------------------------------------------------------------------------
BoxTool.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1I1BV49TB1PreAISpot*/
	/*}#1I1BV49TB1PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1I1BV49TB1PostAISpot*/
	/*}#1I1BV49TB1PostAISpot*/
	return exposeVO;
};

//----------------------------------------------------------------------------
BoxTool.gearExport={
	framework: "jax",
	hudType: "box",
	"showName":"",icon:"gears.svg",previewImg:false,
	fixPose:false,initW:100,initH:100,
	catalog:"",
	args: {
		"tool": {
			"name": "tool", "showName": "tool", "type": "auto", "key": true, "fixed": true, 
			"initVal": {"label":"www.google.com","tools":[1,2,3,4,5]}, "initValText": "#{label:\"www.google.com\",tools:[1,2,3,4,5]}"
		}, 
		"group": {
			"name": "group", "showName": "group", "type": "auto", "key": true, "fixed": true, 
			"initVal": {}
		}
	},
	state:{
	},
	properties:["id","position","x","y","display"],
	faces:["normal","hover"],
	subContainers:{
	},
	/*#{1I1I7N5V30ExGearInfo*/
	/*}#1I1I7N5V30ExGearInfo*/
};
/*#{1I1I7N5V30EndDoc*/
/*}#1I1I7N5V30EndDoc*/

export default BoxTool;
export{BoxTool};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearBox",
//	"jaxId": "1I1I7N5V30",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1I1BV49TB2",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1I1BV49TB3",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1I1BV49TC0",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1I1BV49TC1",
//			"attrs": {
//				"tool": {
//					"type": "auto",
//					"valText": "#{label:\"www.google.com\",tools:[1,2,3,4,5]}"
//				},
//				"group": {
//					"type": "auto",
//					"valText": "{}"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1I1BV49TC2",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1I1BV49TC3",
//			"attrs": {
//				"icon": {
//					"type": "string",
//					"valText": "#appCfg.sharedAssets+\"/browser.svg\""
//				},
//				"label": {
//					"type": "string",
//					"valText": "#tool.label||tool.name||tool.host"
//				},
//				"desc": {
//					"type": "string",
//					"valText": "#tool.description"
//				},
//				"enable": {
//					"type": "bool",
//					"valText": "#!!tool.enable"
//				}
//			}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I1I5LB920",
//					"attrs": {
//						"id": "aniShow",
//						"label": "New AI Seg",
//						"x": "65",
//						"y": "70",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I1I5LMEB0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I1I5LMEB1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I1I5LMEB2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				}
//			]
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1I1BV49TC4",
//			"attrs": {
//				"normal": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1I1C0L4OK0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1I1C0MC0Q0",
//							"attrs": {}
//						}
//					}
//				},
//				"hover": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1I1C0LEE30",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1I1C0MC0Q1",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1I1BV49TC5",
//			"attrs": {}
//		},
//		"exposeToAI": "true",
//		"descAI": "",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "box",
//			"jaxId": "1I1BV49TB1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1I1BV49TC6",
//					"attrs": {
//						"type": "box",
//						"id": "",
//						"position": "Relative",
//						"x": "125",
//						"y": "50",
//						"w": "250",
//						"h": "100",
//						"anchorH": "Center",
//						"anchorV": "Center",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "pointer",
//						"zIndex": "0",
//						"margin": "10",
//						"padding": "10",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"background": "#cfgColor[\"body\"]",
//						"border": "1",
//						"borderStyle": "Solid",
//						"borderColor": "#cfgColor[\"secondary\"]",
//						"corner": "12",
//						"shadow": "false",
//						"shadowX": "2",
//						"shadowY": "2",
//						"shadowBlur": "3",
//						"shadowSpread": "0",
//						"shadowColor": "[0,0,0,0.50]",
//						"contentLayout": "Flex X"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1I2778NGE0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I277BOBA0",
//									"attrs": {
//										"type": "hud",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "50",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "[0,0,20,0]",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex Y",
//										"subAlign": "Start",
//										"itemsAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "image",
//											"jaxId": "1I27798NN0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I27798NN1",
//													"attrs": {
//														"type": "image",
//														"id": "",
//														"position": "relative",
//														"x": "25",
//														"y": "50%",
//														"w": "50",
//														"h": "50",
//														"anchorH": "Center",
//														"anchorV": "Center",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "Tree Off",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"image": "${state.icon},state",
//														"autoSize": "false",
//														"fitSize": "Fit",
//														"repeat": "true",
//														"alignX": "Left",
//														"alignY": "Top"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I27798NP8",
//													"attrs": {
//														"1I1C0LEE30": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I27798NP9",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I27798NP10",
//																	"attrs": {
//																		"alpha": {
//																			"type": "number",
//																			"valText": "1",
//																			"editMode": "range",
//																			"editType": "range"
//																		},
//																		"scale": {
//																			"type": "auto",
//																			"valText": ""
//																		},
//																		"w": {
//																			"type": "length",
//																			"valText": "54"
//																		},
//																		"h": {
//																			"type": "length",
//																			"valText": "54"
//																		},
//																		"x": {
//																			"type": "length",
//																			"valText": "27"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I1C0LEE30",
//															"faceTagName": "hover"
//														},
//														"1I1C0L4OK0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I27798NQ0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I27798NQ1",
//																	"attrs": {
//																		"alpha": {
//																			"type": "number",
//																			"valText": "0.7",
//																			"editMode": "range",
//																			"editType": "range"
//																		},
//																		"w": {
//																			"type": "length",
//																			"valText": "50"
//																		},
//																		"h": {
//																			"type": "length",
//																			"valText": "50"
//																		},
//																		"x": {
//																			"type": "length",
//																			"valText": "25"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I1C0L4OK0",
//															"faceTagName": "normal"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I27798NQ2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I27798NQ3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1I277A2K60",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I277A2K61",
//													"attrs": {
//														"type": "box",
//														"id": "",
//														"position": "Absolute",
//														"x": "50%",
//														"y": "100%-25",
//														"w": "60",
//														"h": "18",
//														"anchorH": "Center",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "${!state.enable&&tool.filePath},state",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[5,0,0,0]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "#cfgColor[\"secondary\"]",
//														"border": "0",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "10",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1I277A2K70",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I277A2K71",
//																	"attrs": {
//																		"type": "text",
//																		"id": "",
//																		"position": "Absolute",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "100%",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontSecondary\"]",
//																		"text": "Disabled",
//																		"font": "",
//																		"fontSize": "#txtSize.small",
//																		"bold": "true",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Center",
//																		"alignV": "Center",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"lineClamp": "0",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1I277A2K72",
//																	"attrs": {}
//																},
//																"functions": {
//																	"jaxId": "1I277A2K73",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1I277A2K74",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false"
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1I277A2K75",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1I277A2K76",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I277A2K77",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1I277BOBB0",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1I277BOBB1",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1I277BOBB2",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1I1BVAH750",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I1C00RP44",
//									"attrs": {
//										"type": "hud",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "On",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,5]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"flex": "true",
//										"contentLayout": "Flex Y",
//										"subAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1I1BVE9S90",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I1C00RP45",
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "Tree Off",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBody\"]",
//														"text": "${state.label},state",
//														"font": "",
//														"fontSize": "16",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "true",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I1C00RP46",
//													"attrs": {
//														"1I1C0LEE30": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I1C0MC0Q6",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I1C0MC0Q7",
//																	"attrs": {
//																		"color": {
//																			"type": "colorRGB",
//																			"valText": "#cfgColor[\"fontBody\"]"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I1C0LEE30",
//															"faceTagName": "hover"
//														},
//														"1I1C0L4OK0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I1C0MC0Q8",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I1C0MC0Q9",
//																	"attrs": {
//																		"color": {
//																			"type": "colorRGB",
//																			"valText": "#cfgColor[\"fontBodySub\"]"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I1C0L4OK0",
//															"faceTagName": "normal"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I1C00RP47",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I1C00RP48",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1I1BVI0RD0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I1C00RP49",
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "Tree Off",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[5,0,0,0]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBody\"]",
//														"text": "${state.desc},state",
//														"font": "",
//														"fontSize": "#txtSize.small",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Center",
//														"wrap": "true",
//														"ellipsis": "true",
//														"lineClamp": "2",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I1C00RP410",
//													"attrs": {
//														"1I1C0LEE30": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I1C0MC0Q10",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I1C0MC0Q11",
//																	"attrs": {
//																		"color": {
//																			"type": "colorRGB",
//																			"valText": "#cfgColor[\"fontBody\"]"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I1C0LEE30",
//															"faceTagName": "hover"
//														},
//														"1I1C0L4OK0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I1C0MC0Q12",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I1C0MC0Q13",
//																	"attrs": {
//																		"color": {
//																			"type": "colorRGB",
//																			"valText": "#cfgColor[\"fontBodySub\"]"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I1C0L4OK0",
//															"faceTagName": "normal"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I1C00RP411",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I1C00RP412",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1I1C00RP413",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1I1C00RP414",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1I1C00RP415",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1I1I9F1JD0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I1I9G57B0",
//									"attrs": {
//										"type": "box",
//										"id": "BoxMenu",
//										"position": "Absolute",
//										"x": "100%-33",
//										"y": "3",
//										"w": "30",
//										"h": "30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "[255,255,255,1.00]",
//										"border": "2",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "6",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"attach": "#(tool.menu===false||group.allTools||group.allChains)?false:true"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1I1I9IGEQ0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1I1I9KK530",
//													"attrs": {
//														"style": "\"front\"",
//														"w": "28",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/menu.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1I1I9KK531",
//													"attrs": {
//														"type": "#null#>BtnIcon(\"front\",28,0,appCfg.sharedAssets+\"/menu.svg\",null)",
//														"id": "",
//														"position": "Absolute",
//														"x": "50%",
//														"y": "50%",
//														"display": "On",
//														"face": "",
//														"anchorH": "Center",
//														"anchorV": "Center"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I1I9KK532",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1I1I9KK533",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1I1Q4R0DU0",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1I1Q4RH010",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1I1I9KK534",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1I1I9KK535",
//													"attrs": {}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1I1I9G57B1",
//									"attrs": {
//										"1I1C0LEE30": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I1I9H33Q2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I1I9H33Q3",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I1C0LEE30",
//											"faceTagName": "hover"
//										},
//										"1I1C0L4OK0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I1I9H33Q4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I1I9H33Q5",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I1C0L4OK0",
//											"faceTagName": "normal"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1I1I9G57B2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1I1I9G57B3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1I1BV49TC7",
//					"attrs": {
//						"1I1C0LEE30": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1I1C0MC0Q18",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I1C0MC0Q19",
//									"attrs": {
//										"border": {
//											"type": "auto",
//											"valText": "2",
//											"editMode": "edges"
//										},
//										"padding": {
//											"type": "auto",
//											"valText": "9",
//											"editMode": "edges"
//										},
//										"background": {
//											"type": "colorRGBA",
//											"valText": "#cfgColor[\"body\"]"
//										}
//									}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1I1C0LEE30",
//							"faceTagName": "hover"
//						},
//						"1I1C0L4OK0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1I1C0MC0Q20",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I1C0MC0Q21",
//									"attrs": {
//										"border": {
//											"type": "auto",
//											"valText": "1",
//											"editMode": "edges"
//										},
//										"padding": {
//											"type": "auto",
//											"valText": "10",
//											"editMode": "edges"
//										},
//										"background": {
//											"type": "colorRGBA",
//											"valText": "#cfgColor[\"body\"]"
//										}
//									}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1I1C0L4OK0",
//							"faceTagName": "normal"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1I1BV49TC8",
//					"attrs": {
//						"OnMouseInOut": {
//							"type": "fixedFunc",
//							"jaxId": "1I1C0SC290",
//							"attrs": {
//								"callArgs": {
//									"jaxId": "1I1C0T1J22",
//									"attrs": {
//										"isIn": "",
//										"event": ""
//									}
//								},
//								"seg": ""
//							}
//						}
//					}
//				},
//				"extraPpts": {
//					"jaxId": "1I1BV49TC9",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "true",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1I1BV49TC10",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false",
//				"background": "false",
//				"color": "false",
//				"gradient": "false",
//				"border": "false",
//				"borders": "false",
//				"borderStyle": "false",
//				"borderColor": "false",
//				"borderColors": "false",
//				"corner": "false",
//				"coner": "false",
//				"coners": "false",
//				"shadow": "false",
//				"shadowX": "false",
//				"shadowY": "false",
//				"shadowBlur": "false",
//				"shadowSpread": "false",
//				"shadowColor": "false",
//				"maskImage": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}