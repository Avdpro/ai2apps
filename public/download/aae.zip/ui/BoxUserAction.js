//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
import {DataView} from "/@StdUI/ui/DataView.js";
/*#{1HPFFBP7D0StartDoc*/
/*}#1HPFFBP7D0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BoxUserAction=function(actionVO){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let btnAction,txtAction,edQuery,edContent,edDX,edDY,edDelay;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1HPFFBP7D1LocalVals*/
	/*}#1HPFFBP7D1LocalVals*/
	
	/*#{1HPFFBP7D1PreState*/
	/*}#1HPFFBP7D1PreState*/
	state={
		"type":"click","query":"","dx":0,"dy":0,"content":"","delay":0,
		/*#{1HPFFBP7D7ExState*/
		/*}#1HPFFBP7D7ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1HPFFBP7D1PostState*/
	/*}#1HPFFBP7D1PostState*/
	cssVO={
		"hash":"1HPFFBP7D1",nameHost:true,
		"type":"box","x":0,"y":0,"w":"100%","h":"","margin":[0,0,10,0],"padding":[5,5,10,5],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":[255,255,255,1],
		"border":2,"corner":8,"contentLayout":"flex-y",
		children:[
			{
				"hash":"1HPFFE1HG0",
				"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":30,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
				"itemsAlign":1,
				children:[
					{
						"hash":"1HPFGH5M50",
						"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
						"text":"Action:","fontSize":txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
					},
					{
						"hash":"1HPFGIIB80",
						"type":BtnIcon("front",26,0,appCfg.sharedAssets+"/btncombo.svg",null),"id":"BtnAction","position":"relative","x":0,"y":0,"margin":[0,3,0,0],
						"OnClick":function(event){
							self.chooseAction(this,event);
						},
					},
					{
						"hash":"1HPFGJIKI0",
						"type":"text","id":"TxtAction","position":"relative","x":0,"y":0,"w":100,"h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
						"text":"Click","fontWeight":"normal","fontStyle":"normal","textDecoration":"","flex":true,
					},
					{
						"hash":"1HPFK4MVG0",
						"type":BtnIcon("front",26,0,appCfg.sharedAssets+"/run.svg",null),"position":"relative","x":0,"y":0,"margin":[0,3,0,0],
					}
				],
			},
			{
				"hash":"1HPFGPUHK0",
				"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":30,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
				"itemsAlign":1,
				children:[
					{
						"hash":"1HPFGPUHK2",
						"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
						"text":"Query:","fontSize":txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
					},
					{
						"hash":"1HPFGQVFF0",
						"type":"edit","id":"EdQuery","position":"relative","x":0,"y":0,"w":100,"h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":[0,0,0],
						"outline":0,"border":[0,0,1,0],"flex":true,
					}
				],
			},
			{
				"hash":"1HPFHUT4S0",
				"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":30,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
				"itemsAlign":1,
				children:[
					{
						"hash":"1HPFHUT4T0",
						"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
						"text":"Contents:","fontSize":txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
					},
					{
						"hash":"1HPFHUT4U2",
						"type":"edit","id":"EdContent","position":"relative","x":0,"y":0,"w":100,"h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":[0,0,0],
						"outline":0,"border":[0,0,1,0],"flex":true,
					}
				],
			},
			{
				"hash":"1HPFIBKV60",
				"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":30,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
				"itemsAlign":1,
				children:[
					{
						"hash":"1HPFIBKV62",
						"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
						"text":"Delta X:","fontSize":txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
					},
					{
						"hash":"1HPFIBKV73",
						"type":"edit","id":"EdDX","position":"relative","x":0,"y":0,"w":30,"h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":[0,0,0],
						"outline":0,"border":[0,0,1,0],"flex":true,
					},
					{
						"hash":"1HPFIC42F0",
						"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
						"text":"Delta Y:","fontSize":txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
					},
					{
						"hash":"1HPFICFEC0",
						"type":"edit","id":"EdDY","position":"relative","x":0,"y":0,"w":30,"h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":[0,0,0],
						"outline":0,"border":[0,0,1,0],"flex":true,
					}
				],
			},
			{
				"hash":"1HPFIKB8H0",
				"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":30,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
				"itemsAlign":1,
				children:[
					{
						"hash":"1HPFIKB8H2",
						"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
						"text":"Delay:","fontSize":txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
					},
					{
						"hash":"1HPFIKB8I3",
						"type":"edit","id":"EdDelay","position":"relative","x":0,"y":0,"w":100,"h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":[0,0,0],
						"outline":0,"border":[0,0,1,0],"flex":true,
					}
				],
			},
			{
				"hash":"1HRCGCOMO0",
				"type":DataView(null,"1HRCEVTGL0",{"action":"click","query":"[id=\"123\"]","content":"","dx":0,"dy":0,"waitBefore":500,"waitAfter":500},"",{"titleHeight":30,"titleSize":18,"titleColor":cfgColor["fontBody"],"titleBold":true,"lineHeight":30,"lineGap":5,"labelSize":12,"labelColor":cfgColor["fontBody"],"labelBold":true,"labelLine":false,"valueSize":14,"valueColor":cfgColor["fontBody"],"valueBold":false,"segHeight":20,"segSize":14,"segBold":true,"segColor":cfgColor["fontBody"],"trace":false,"edit":true,"noteSize":12},""),
				"position":"relative","x":0,"y":0,
			}
		],
		/*#{1HPFFBP7D1ExtraCSS*/
		/*}#1HPFFBP7D1ExtraCSS*/
		faces:{
			"click":{
				"#1HPFFE1HG0":{
					"display":1
				},
				"#1HPFGPUHK0":{
					"display":1
				},
				"#1HPFHUT4S0":{
					"display":0
				},
				"#1HPFIBKV60":{
					"display":1
				},
				"#1HPFIKB8H0":{
					"display":1
				}
			},"type":{
				"#1HPFFE1HG0":{
					"display":1
				},
				"#1HPFGPUHK0":{
					"display":1
				},
				"#1HPFHUT4S0":{
					"display":1
				},
				"#1HPFIBKV60":{
					"display":0
				},
				"#1HPFIKB8H0":{
					"display":1
				}
			},"wait":{
				"#1HPFFE1HG0":{
					"display":1
				},
				"#1HPFGPUHK0":{
					"display":1
				},
				"#1HPFHUT4S0":{
					"display":0
				},
				"#1HPFIBKV60":{
					"display":0
				},
				"#1HPFIKB8H0":{
					"display":1
				}
			},"waitLoad":{
				"#1HPFFE1HG0":{
					"display":1
				},
				"#1HPFGPUHK0":{
					"display":0
				},
				"#1HPFHUT4S0":{
					"display":0
				},
				"#1HPFIBKV60":{
					"display":0
				},
				"#1HPFIKB8H0":{
					"display":1
				}
			}
		},
		OnCreate:function(){
			self=this;
			btnAction=self.BtnAction;txtAction=self.TxtAction;edQuery=self.EdQuery;edContent=self.EdContent;edDX=self.EdDX;edDY=self.EdDY;edDelay=self.EdDelay;
			/*#{1HPFFBP7D1Create*/
			actionVO=actionVO||{
				type:"Click",query:"",dx:0,dy:0,delay:0
			};
			self.readAction(actionVO);
			/*}#1HPFFBP7D1Create*/
		},
		/*#{1HPFFBP7D1EndCSS*/
		/*}#1HPFFBP7D1EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.readAction=async function(vo){
		/*#{1HPFKD8VS0Start*/
		/*}#1HPFKD8VS0Start*/
		
		//Read
		/*#{1HPFKD8VS1*/
		state.type=vo.action;
		state.delay=vo.delay||0;
		state.dx=vo.dx||0;
		state.dy=vo.dy||0;
		state.content=vo.content||"";
		/*}#1HPFKD8VS1*/
		
		//CallUpdate
		/*#{1HPFREBBT0*/
		self.updateBox();
		/*}#1HPFREBBT0*/
	};
	//------------------------------------------------------------------------
	cssVO.updateBox=async function(){
		/*#{1HPFKD8VS2Start*/
		/*}#1HPFKD8VS2Start*/
		switch(state.type){
			case "Click":{
				self.showFace("click");
				break;
			}
			case "Type":{
				self.showFace("type");
				break;
			}
			case "Wait":{
				self.showFace("wait");
				break;
			}
			case "WaitLoad":{
				self.showFace("waitLoad");
				break;
			}
		}
		/*#{1HPFRJCGR0*/
		txtAction.text=state.type;
		edQuery.text=state.query;
		edDX.text=state.dx;
		edDY.text=state.dy;
		edDelay.text=state.delay;
		edContent.text=state.content;
		/*}#1HPFRJCGR0*/
	};
	//------------------------------------------------------------------------
	cssVO.getAction=async function(){
		/*#{1HPFKD8VS3Start*/
		let vo;
		vo={
			action:state.type,
		};
		switch(state.type){
			case "Click":
				vo.query=edQuery.text;
				vo.dx=edDX.text;
				vo.dy=edDY.text;
				vo.delay=edDelay.text;
				break;
			case "Type":
				vo.query=edQuery.text;
				vo.content=edContent.text;
				vo.delay=edDelay.text;
				break;
			case "Wait":
				vo.query=edQuery.text;
				vo.delay=edDelay.text;
				break;
			case "WaitLoad":
				vo.delay=edDelay.text;
				break;
		}
		return vo;
		/*}#1HPFKD8VS3Start*/
	};
	//------------------------------------------------------------------------
	cssVO.chooseAction=async function(sender,event){
		/*#{1HPFTL9PU0Start*/
		/*}#1HPFTL9PU0Start*/
		{
			let $items,$item;
			$items=[
				{id:"Click",text:"Click"},
				{id:"Type",text:"Type"},
				{id:"Wait",text:"Wait"},
				{id:"WaitLoad",text:"Wait page load"}
			];
			$item=await VFACT.app.modalDlg("/@StdUI/ui/DlgMenu.js",{hud:btnAction,items:$items});
			if($item){
				if($item.id==="Click"){
					/*#{1HPFTM8110*/
					state.type="Click";
					/*}#1HPFTM8110*/
				}else if($item.id==="Type"){
					/*#{1HPFTM8111*/
					state.type="Type";
					/*}#1HPFTM8111*/
				}else if($item.id==="Wait"){
					/*#{1HPFTM8112*/
					state.type="Wait";
					/*}#1HPFTM8112*/
				}else if($item.id==="WaitLoad"){
					/*#{1HPFTP8DA0*/
					state.type="WaitLoad";
					/*}#1HPFTP8DA0*/
				}
			}
		}
		/*#{1HPFTPFS50*/
		self.updateBox();
		/*}#1HPFTPFS50*/
	};
	/*#{1HPFFBP7D1PostCSSVO*/
	/*}#1HPFFBP7D1PostCSSVO*/
	return cssVO;
};
/*#{1HPFFBP7D1ExCodes*/
/*}#1HPFFBP7D1ExCodes*/


/*#{1HPFFBP7D0EndDoc*/
/*}#1HPFFBP7D0EndDoc*/

export default BoxUserAction;
export{BoxUserAction};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearBox",
//	"jaxId": "1HPFFBP7D0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1HPFFBP7D2",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1HPFFBP7D3",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1HPFFBP7D4",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1HPFFBP7D5",
//			"attrs": {
//				"actionVO": {
//					"type": "auto",
//					"valText": "null"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1HPFFBP7D6",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1HPFFBP7D7",
//			"attrs": {
//				"type": {
//					"type": "string",
//					"valText": "click"
//				},
//				"query": {
//					"type": "string",
//					"valText": ""
//				},
//				"dx": {
//					"type": "int",
//					"valText": "0"
//				},
//				"dy": {
//					"type": "int",
//					"valText": "0"
//				},
//				"content": {
//					"type": "string",
//					"valText": ""
//				},
//				"delay": {
//					"type": "int",
//					"valText": "0"
//				}
//			}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HPFKD8VS0",
//					"attrs": {
//						"id": "readAction",
//						"label": "New AI Seg",
//						"x": "110",
//						"y": "160",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HPFKD9000",
//							"attrs": {
//								"vo": {
//									"type": "auto",
//									"valText": "{}"
//								}
//							}
//						},
//						"async": "true",
//						"localVars": {
//							"jaxId": "1HPFKD9001",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": [
//								{
//									"type": "flowseg",
//									"def": "Code",
//									"jaxId": "1HPFKD8VS1",
//									"attrs": {
//										"id": "Read",
//										"label": "New AI Seg",
//										"x": "330",
//										"y": "160",
//										"desc": "",
//										"codes": "false",
//										"outlet": {
//											"jaxId": "1HPFKD9002",
//											"attrs": {
//												"id": "Next",
//												"desc": "Outlet."
//											},
//											"linkedSeg": "1HPFREBBT0"
//										}
//									}
//								},
//								{
//									"type": "flowseg",
//									"def": "Code",
//									"jaxId": "1HPFREBBT0",
//									"attrs": {
//										"id": "CallUpdate",
//										"label": "New AI Seg",
//										"x": "530",
//										"y": "160",
//										"desc": "",
//										"codes": "false",
//										"outlet": {
//											"jaxId": "1HPFREBC413",
//											"attrs": {
//												"id": "Next",
//												"desc": "Outlet."
//											}
//										}
//									}
//								}
//							]
//						},
//						"outlet": {
//							"jaxId": "1HPFKD9003",
//							"attrs": {
//								"id": "Next",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1HPFKD8VS1"
//						}
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HPFKD8VS2",
//					"attrs": {
//						"id": "updateBox",
//						"label": "New AI Seg",
//						"x": "110",
//						"y": "370",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HPFKD9004",
//							"attrs": {}
//						},
//						"async": "true",
//						"localVars": {
//							"jaxId": "1HPFKD9005",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": [
//								{
//									"type": "flowseg",
//									"def": "Switch",
//									"jaxId": "1HPFRFBAS1",
//									"attrs": {
//										"id": "",
//										"label": "New AI Seg",
//										"x": "340",
//										"y": "370",
//										"desc": "",
//										"codes": "false",
//										"expression": "state.type",
//										"outlets": {
//											"attrs": [
//												{
//													"type": "aioutlet",
//													"def": "SwitchOutlet",
//													"jaxId": "1HPFRFBAS2",
//													"attrs": {
//														"id": "Click",
//														"condition": "\"Click\"",
//														"merge": "false",
//														"codes": "false",
//														"break": "true",
//														"desc": ""
//													},
//													"linkedSeg": "1HPFRFKS80"
//												},
//												{
//													"type": "aioutlet",
//													"def": "SwitchOutlet",
//													"jaxId": "1HPFRFBAS3",
//													"attrs": {
//														"id": "Type",
//														"condition": "\"Type\"",
//														"merge": "false",
//														"codes": "false",
//														"break": "true",
//														"desc": ""
//													},
//													"linkedSeg": "1HPFRG1L50"
//												},
//												{
//													"type": "aioutlet",
//													"def": "SwitchOutlet",
//													"jaxId": "1HPFRFBAS4",
//													"attrs": {
//														"id": "Wait",
//														"condition": "\"Wait\"",
//														"merge": "false",
//														"codes": "false",
//														"break": "true",
//														"desc": ""
//													},
//													"linkedSeg": "1HPFRGAFS0"
//												},
//												{
//													"type": "aioutlet",
//													"def": "SwitchOutlet",
//													"jaxId": "1HPFRFBAS5",
//													"attrs": {
//														"id": "WaitLoad",
//														"condition": "\"WaitLoad\"",
//														"merge": "false",
//														"codes": "false",
//														"break": "true",
//														"desc": ""
//													},
//													"linkedSeg": "1HPFRGOFC0"
//												}
//											]
//										},
//										"outlet": {
//											"jaxId": "1HPFRFBAS6",
//											"attrs": {
//												"id": "Next",
//												"desc": "Outlet."
//											},
//											"linkedSeg": "1HPFRJCGR0"
//										}
//									}
//								},
//								{
//									"type": "flowseg",
//									"def": "SetFace",
//									"jaxId": "1HPFRFKS80",
//									"attrs": {
//										"id": "",
//										"label": "New AI Seg",
//										"x": "540",
//										"y": "250",
//										"desc": "",
//										"codes": "false",
//										"component": "self",
//										"face": "click",
//										"outlet": {
//											"jaxId": "1HPFRFKS81",
//											"attrs": {
//												"id": "Next",
//												"desc": "Outlet."
//											}
//										}
//									}
//								},
//								{
//									"type": "flowseg",
//									"def": "SetFace",
//									"jaxId": "1HPFRG1L50",
//									"attrs": {
//										"id": "",
//										"label": "New AI Seg",
//										"x": "540",
//										"y": "310",
//										"desc": "",
//										"codes": "false",
//										"component": "self",
//										"face": "type",
//										"outlet": {
//											"jaxId": "1HPFRG1L51",
//											"attrs": {
//												"id": "Next",
//												"desc": "Outlet."
//											}
//										}
//									}
//								},
//								{
//									"type": "flowseg",
//									"def": "SetFace",
//									"jaxId": "1HPFRGAFS0",
//									"attrs": {
//										"id": "",
//										"label": "New AI Seg",
//										"x": "540",
//										"y": "370",
//										"desc": "",
//										"codes": "false",
//										"component": "self",
//										"face": "wait",
//										"outlet": {
//											"jaxId": "1HPFRGAFS1",
//											"attrs": {
//												"id": "Next",
//												"desc": "Outlet."
//											}
//										}
//									}
//								},
//								{
//									"type": "flowseg",
//									"def": "SetFace",
//									"jaxId": "1HPFRGOFC0",
//									"attrs": {
//										"id": "",
//										"label": "New AI Seg",
//										"x": "540",
//										"y": "440",
//										"desc": "",
//										"codes": "false",
//										"component": "self",
//										"face": "waitLoad",
//										"outlet": {
//											"jaxId": "1HPFRGOFC1",
//											"attrs": {
//												"id": "Next",
//												"desc": "Outlet."
//											}
//										}
//									}
//								},
//								{
//									"type": "flowseg",
//									"def": "Code",
//									"jaxId": "1HPFRJCGR0",
//									"attrs": {
//										"id": "",
//										"label": "New AI Seg",
//										"x": "600",
//										"y": "550",
//										"desc": "",
//										"codes": "false",
//										"outlet": {
//											"jaxId": "1HPFRKALH0",
//											"attrs": {
//												"id": "Next",
//												"desc": "Outlet."
//											}
//										}
//									}
//								}
//							]
//						},
//						"outlet": {
//							"jaxId": "1HPFKD9006",
//							"attrs": {
//								"id": "Next",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1HPFRFBAS1"
//						}
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HPFKD8VS3",
//					"attrs": {
//						"id": "getAction",
//						"label": "New AI Seg",
//						"x": "110",
//						"y": "550",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HPFKD9007",
//							"attrs": {}
//						},
//						"async": "true",
//						"localVars": {
//							"jaxId": "1HPFKD9008",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1HPFKD9009",
//							"attrs": {
//								"id": "Next",
//								"desc": "Outlet."
//							}
//						}
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HPFTL9PU0",
//					"attrs": {
//						"id": "chooseAction",
//						"label": "New AI Seg",
//						"x": "110",
//						"y": "670",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HPFTLT5R0",
//							"attrs": {
//								"sender": {
//									"valText": "null"
//								},
//								"event": {
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"localVars": {
//							"jaxId": "1HPFTLT5R1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": [
//								{
//									"type": "flowseg",
//									"def": "Menu",
//									"jaxId": "1HPFTN0LN0",
//									"attrs": {
//										"id": "",
//										"label": "New AI Seg",
//										"x": "350",
//										"y": "670",
//										"desc": "",
//										"codes": "false",
//										"launcher": "btnAction",
//										"outlets": {
//											"attrs": [
//												{
//													"type": "aioutlet",
//													"def": "MenuItem",
//													"jaxId": "1HPFTM8110",
//													"attrs": {
//														"id": "Click",
//														"text": "Click",
//														"desc": ""
//													}
//												},
//												{
//													"type": "aioutlet",
//													"def": "MenuItem",
//													"jaxId": "1HPFTM8111",
//													"attrs": {
//														"id": "Type",
//														"text": "Type",
//														"desc": ""
//													}
//												},
//												{
//													"type": "aioutlet",
//													"def": "MenuItem",
//													"jaxId": "1HPFTM8112",
//													"attrs": {
//														"id": "Wait",
//														"text": "Wait",
//														"desc": ""
//													}
//												},
//												{
//													"type": "aioutlet",
//													"def": "MenuItem",
//													"jaxId": "1HPFTP8DA0",
//													"attrs": {
//														"id": "WaitLoad",
//														"text": "Wait page load",
//														"desc": ""
//													}
//												}
//											]
//										},
//										"outlet": {
//											"jaxId": "1HPFTN0LN1",
//											"attrs": {
//												"id": "Next",
//												"desc": "Outlet."
//											},
//											"linkedSeg": "1HPFTPFS50"
//										}
//									}
//								},
//								{
//									"type": "flowseg",
//									"def": "Code",
//									"jaxId": "1HPFTPFS50",
//									"attrs": {
//										"id": "",
//										"label": "New AI Seg",
//										"x": "580",
//										"y": "730",
//										"desc": "",
//										"codes": "false",
//										"outlet": {
//											"jaxId": "1HPFTPFSA0",
//											"attrs": {
//												"id": "Next",
//												"desc": "Outlet."
//											}
//										}
//									}
//								}
//							]
//						},
//						"outlet": {
//							"jaxId": "1HPFTLT5R2",
//							"attrs": {
//								"id": "Next",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1HPFTN0LN0"
//						}
//					}
//				}
//			]
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1HPFFBP7D8",
//			"attrs": {
//				"click": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HPFITSKP0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HPFJH9D60",
//							"attrs": {}
//						}
//					}
//				},
//				"type": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HPFJELG70",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HPFJH9D61",
//							"attrs": {}
//						}
//					}
//				},
//				"wait": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HPFJGN2R0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HPFJH9D62",
//							"attrs": {}
//						}
//					}
//				},
//				"waitLoad": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HPFJPR5R0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HPFK503D0",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1HPFFBP7D9",
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "box",
//			"jaxId": "1HPFFBP7D1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1HPFFBP7D10",
//					"attrs": {
//						"type": "box",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "[0,0,10,0]",
//						"padding": "[5,5,10,5]",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"background": "[255,255,255,1.00]",
//						"border": "2",
//						"borderStyle": "Solid",
//						"borderColor": "[0,0,0,1.00]",
//						"corner": "8",
//						"shadow": "false",
//						"shadowX": "2",
//						"shadowY": "2",
//						"shadowBlur": "3",
//						"shadowSpread": "0",
//						"shadowColor": "[0,0,0,0.50]",
//						"contentLayout": "Flex Y"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1HPFFE1HG0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HPFGPTCV0",
//									"attrs": {
//										"type": "hud",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex X",
//										"itemsAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1HPFGH5M50",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HPFGPTCV1",
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBody\"]",
//														"text": "Action:",
//														"font": "",
//														"fontSize": "#txtSize.smallPlus",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "false",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HPFGPTCV2",
//													"attrs": {
//														"1HPFITSKP0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HPFJH9D70",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HPFJH9D71",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HPFITSKP0",
//															"faceTagName": "click"
//														},
//														"1HPFJELG70": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HPFK503D1",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HPFK503D2",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HPFJELG70",
//															"faceTagName": "type"
//														},
//														"1HPFJGN2R0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HPFK503D3",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HPFK503D4",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HPFJGN2R0",
//															"faceTagName": "wait"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HPFGPTCV3",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HPFGPTCV4",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1HPFGIIB80",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1HPFGPTCV5",
//													"attrs": {
//														"style": "\"front\"",
//														"w": "26",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/btncombo.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1HPFGPTCV6",
//													"attrs": {
//														"type": "#null#>BtnIcon(\"front\",26,0,appCfg.sharedAssets+\"/btncombo.svg\",null)",
//														"id": "BtnAction",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"margin": "[0,3,0,0]"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HPFGPTCV7",
//													"attrs": {
//														"1HPFITSKP0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HPFJH9D74",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HPFJH9D75",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HPFITSKP0",
//															"faceTagName": "click"
//														},
//														"1HPFJELG70": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HPFK4H0L0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HPFK4H0L1",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HPFJELG70",
//															"faceTagName": "type"
//														},
//														"1HPFJGN2R0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HPFK4H0L2",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HPFK4H0L3",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HPFJGN2R0",
//															"faceTagName": "wait"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HPFGPTCV8",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1HPFTLT5S0",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1HPFTLT5S1",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": "1HPFTL9PU0"
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1HPFGPTCV9",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1HPFGPTCV10",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1HPFGJIKI0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HPFGPTD00",
//													"attrs": {
//														"type": "text",
//														"id": "TxtAction",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBody\"]",
//														"text": "Click",
//														"font": "",
//														"fontSize": "16",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "false",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0",
//														"flex": "true"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HPFGPTD01",
//													"attrs": {
//														"1HPFITSKP0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HPFJH9D78",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HPFJH9D79",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HPFITSKP0",
//															"faceTagName": "click"
//														},
//														"1HPFJELG70": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HPFK503D5",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HPFK503D6",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HPFJELG70",
//															"faceTagName": "type"
//														},
//														"1HPFJGN2R0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HPFK503D7",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HPFK503D8",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HPFJGN2R0",
//															"faceTagName": "wait"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HPFGPTD02",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HPFGPTD03",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1HPFK4MVG0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1HPFK4MVG1",
//													"attrs": {
//														"style": "\"front\"",
//														"w": "26",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/run.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1HPFK4MVG2",
//													"attrs": {
//														"type": "#null#>BtnIcon(\"front\",26,0,appCfg.sharedAssets+\"/run.svg\",null)",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"margin": "[0,3,0,0]"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HPFK4MVH0",
//													"attrs": {
//														"1HPFITSKP0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HPFK4MVH1",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HPFK4MVH2",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HPFITSKP0",
//															"faceTagName": "click"
//														},
//														"1HPFJELG70": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HPFK4MVH3",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HPFK4MVH4",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HPFJELG70",
//															"faceTagName": "type"
//														},
//														"1HPFJGN2R0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HPFK4MVH5",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HPFK4MVH6",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HPFJGN2R0",
//															"faceTagName": "wait"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HPFK4MVH7",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HPFK4MVH8",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1HPFK4MVH9",
//													"attrs": {}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1HPFGPTD04",
//									"attrs": {
//										"1HPFITSKP0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HPFJH9D712",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HPFJH9D713",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HPFITSKP0",
//											"faceTagName": "click"
//										},
//										"1HPFJPR5R0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HPFK503D9",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HPFK503D10",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HPFJPR5R0",
//											"faceTagName": "waitLoad"
//										},
//										"1HPFJELG70": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HPFK503D11",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HPFK503D12",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HPFJELG70",
//											"faceTagName": "type"
//										},
//										"1HPFJGN2R0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HPFK503D13",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HPFK503D14",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HPFJGN2R0",
//											"faceTagName": "wait"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HPFGPTD05",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HPFGPTD06",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1HPFGPUHK0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HPFGPUHK1",
//									"attrs": {
//										"type": "hud",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex X",
//										"itemsAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1HPFGPUHK2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HPFGPUHK3",
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBody\"]",
//														"text": "Query:",
//														"font": "",
//														"fontSize": "#txtSize.smallPlus",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "false",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HPFGPUHL0",
//													"attrs": {
//														"1HPFITSKP0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HPFJH9D716",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HPFJH9D717",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HPFITSKP0",
//															"faceTagName": "click"
//														},
//														"1HPFJELG70": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HPFK503D15",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HPFK503D16",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HPFJELG70",
//															"faceTagName": "type"
//														},
//														"1HPFJGN2R0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HPFK503D17",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HPFK503D18",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HPFJGN2R0",
//															"faceTagName": "wait"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HPFGPUHL1",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HPFGPUHL2",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "edit",
//											"jaxId": "1HPFGQVFF0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HPFHUS510",
//													"attrs": {
//														"type": "edit",
//														"id": "EdQuery",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100",
//														"h": "20",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"inputType": "Text",
//														"text": "",
//														"placeHolder": "",
//														"color": "[0,0,0]",
//														"bgColor": "[255,255,255,1.00]",
//														"font": "",
//														"fontSize": "16",
//														"outline": "0",
//														"border": "[0,0,1,0]",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"selectOnFocus": "true",
//														"spellCheck": "true",
//														"flex": "true"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HPFHUS511",
//													"attrs": {
//														"1HPFITSKP0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HPFJH9D720",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HPFJH9D721",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HPFITSKP0",
//															"faceTagName": "click"
//														},
//														"1HPFJELG70": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HPFK503D19",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HPFK503D20",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HPFJELG70",
//															"faceTagName": "type"
//														},
//														"1HPFJGN2R0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HPFK503D21",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HPFK503D22",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HPFJGN2R0",
//															"faceTagName": "wait"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HPFHUS512",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HPFHUS513",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1HPFGPUHM5",
//									"attrs": {
//										"1HPFITSKP0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HPFJH9D724",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HPFJH9D725",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HPFITSKP0",
//											"faceTagName": "click"
//										},
//										"1HPFJPR5R0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HPFK503D23",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HPFK503D24",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HPFJPR5R0",
//											"faceTagName": "waitLoad"
//										},
//										"1HPFJELG70": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HPFK503D25",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HPFK503D26",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HPFJELG70",
//											"faceTagName": "type"
//										},
//										"1HPFJGN2R0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HPFK503D27",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HPFK503D28",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HPFJGN2R0",
//											"faceTagName": "wait"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HPFGPUHM6",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HPFGPUHM7",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1HPFHUT4S0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HPFHUT4S1",
//									"attrs": {
//										"type": "hud",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex X",
//										"itemsAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1HPFHUT4T0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HPFHUT4T1",
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBody\"]",
//														"text": "Contents:",
//														"font": "",
//														"fontSize": "#txtSize.smallPlus",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "false",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HPFHUT4T2",
//													"attrs": {
//														"1HPFITSKP0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HPFJH9D728",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HPFJH9D729",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HPFITSKP0",
//															"faceTagName": "click"
//														},
//														"1HPFJELG70": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HPFK503D29",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HPFK503D30",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HPFJELG70",
//															"faceTagName": "type"
//														},
//														"1HPFJGN2R0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HPFK503D31",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HPFK503D32",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HPFJGN2R0",
//															"faceTagName": "wait"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HPFHUT4U0",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HPFHUT4U1",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "edit",
//											"jaxId": "1HPFHUT4U2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HPFHUT4U3",
//													"attrs": {
//														"type": "edit",
//														"id": "EdContent",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100",
//														"h": "20",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"inputType": "Text",
//														"text": "",
//														"placeHolder": "",
//														"color": "[0,0,0]",
//														"bgColor": "[255,255,255,1.00]",
//														"font": "",
//														"fontSize": "16",
//														"outline": "0",
//														"border": "[0,0,1,0]",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"selectOnFocus": "true",
//														"spellCheck": "true",
//														"flex": "true"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HPFHUT4U4",
//													"attrs": {
//														"1HPFITSKP0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HPFJH9D732",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HPFJH9D733",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HPFITSKP0",
//															"faceTagName": "click"
//														},
//														"1HPFJELG70": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HPFK503D33",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HPFK503D34",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HPFJELG70",
//															"faceTagName": "type"
//														},
//														"1HPFJGN2R0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HPFK503D35",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HPFK503D36",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HPFJGN2R0",
//															"faceTagName": "wait"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HPFHUT4U5",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HPFHUT4U6",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1HPFHUT4U7",
//									"attrs": {
//										"1HPFITSKP0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HPFJH9D736",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HPFJH9D737",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HPFITSKP0",
//											"faceTagName": "click"
//										},
//										"1HPFJELG70": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HPFJH9D738",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HPFJH9D739",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HPFJELG70",
//											"faceTagName": "type"
//										},
//										"1HPFJGN2R0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HPFJH9D740",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HPFJH9D741",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HPFJGN2R0",
//											"faceTagName": "wait"
//										},
//										"1HPFJPR5R0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HPFK503D37",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HPFK503D38",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HPFJPR5R0",
//											"faceTagName": "waitLoad"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HPFHUT4U8",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HPFHUT4U9",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1HPFIBKV60",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HPFIBKV61",
//									"attrs": {
//										"type": "hud",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex X",
//										"itemsAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1HPFIBKV62",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HPFIBKV63",
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBody\"]",
//														"text": "Delta X:",
//														"font": "",
//														"fontSize": "#txtSize.smallPlus",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "false",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HPFIBKV70",
//													"attrs": {
//														"1HPFITSKP0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HPFJH9D742",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HPFJH9D743",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HPFITSKP0",
//															"faceTagName": "click"
//														},
//														"1HPFJELG70": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HPFK503D39",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HPFK503D40",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HPFJELG70",
//															"faceTagName": "type"
//														},
//														"1HPFJGN2R0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HPFK503D41",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HPFK503D42",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HPFJGN2R0",
//															"faceTagName": "wait"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HPFIBKV71",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HPFIBKV72",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "edit",
//											"jaxId": "1HPFIBKV73",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HPFIBKV74",
//													"attrs": {
//														"type": "edit",
//														"id": "EdDX",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "30",
//														"h": "20",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"inputType": "Text",
//														"text": "",
//														"placeHolder": "",
//														"color": "[0,0,0]",
//														"bgColor": "[255,255,255,1.00]",
//														"font": "",
//														"fontSize": "16",
//														"outline": "0",
//														"border": "[0,0,1,0]",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"selectOnFocus": "true",
//														"spellCheck": "true",
//														"flex": "true"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HPFIBKV75",
//													"attrs": {
//														"1HPFITSKP0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HPFJH9D746",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HPFJH9D747",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HPFITSKP0",
//															"faceTagName": "click"
//														},
//														"1HPFJELG70": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HPFK503D43",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HPFK503D44",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HPFJELG70",
//															"faceTagName": "type"
//														},
//														"1HPFJGN2R0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HPFK503D45",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HPFK503D46",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HPFJGN2R0",
//															"faceTagName": "wait"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HPFIBKV76",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HPFIBKV77",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1HPFIC42F0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HPFIC42F1",
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBody\"]",
//														"text": "Delta Y:",
//														"font": "",
//														"fontSize": "#txtSize.smallPlus",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "false",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HPFIC42G0",
//													"attrs": {
//														"1HPFITSKP0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HPFJH9D750",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HPFJH9D751",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HPFITSKP0",
//															"faceTagName": "click"
//														},
//														"1HPFJELG70": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HPFK503D47",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HPFK503D48",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HPFJELG70",
//															"faceTagName": "type"
//														},
//														"1HPFJGN2R0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HPFK503D49",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HPFK503D50",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HPFJGN2R0",
//															"faceTagName": "wait"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HPFIC42G1",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HPFIC42G2",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "edit",
//											"jaxId": "1HPFICFEC0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HPFICFEC1",
//													"attrs": {
//														"type": "edit",
//														"id": "EdDY",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "30",
//														"h": "20",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"inputType": "Text",
//														"text": "",
//														"placeHolder": "",
//														"color": "[0,0,0]",
//														"bgColor": "[255,255,255,1.00]",
//														"font": "",
//														"fontSize": "16",
//														"outline": "0",
//														"border": "[0,0,1,0]",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"selectOnFocus": "true",
//														"spellCheck": "true",
//														"flex": "true"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HPFICFED0",
//													"attrs": {
//														"1HPFITSKP0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HPFJH9D754",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HPFJH9D755",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HPFITSKP0",
//															"faceTagName": "click"
//														},
//														"1HPFJELG70": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HPFK503D51",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HPFK503D52",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HPFJELG70",
//															"faceTagName": "type"
//														},
//														"1HPFJGN2R0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HPFK503D53",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HPFK503D54",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HPFJGN2R0",
//															"faceTagName": "wait"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HPFICFED1",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HPFICFED2",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1HPFIBKV78",
//									"attrs": {
//										"1HPFITSKP0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HPFJH9D80",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HPFJH9D81",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HPFITSKP0",
//											"faceTagName": "click"
//										},
//										"1HPFJELG70": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HPFJH9D82",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HPFJH9D83",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HPFJELG70",
//											"faceTagName": "type"
//										},
//										"1HPFJGN2R0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HPFJH9D84",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HPFJH9D85",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HPFJGN2R0",
//											"faceTagName": "wait"
//										},
//										"1HPFJPR5R0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HPFK503D55",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HPFK503D56",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HPFJPR5R0",
//											"faceTagName": "waitLoad"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HPFIBKV79",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HPFIBKV710",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1HPFIKB8H0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HPFIKB8H1",
//									"attrs": {
//										"type": "hud",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex X",
//										"itemsAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1HPFIKB8H2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HPFIKB8H3",
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBody\"]",
//														"text": "Delay:",
//														"font": "",
//														"fontSize": "#txtSize.smallPlus",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "false",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HPFIKB8I0",
//													"attrs": {
//														"1HPFITSKP0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HPFJH9D86",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HPFJH9D87",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HPFITSKP0",
//															"faceTagName": "click"
//														},
//														"1HPFJELG70": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HPFK503D57",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HPFK503D58",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HPFJELG70",
//															"faceTagName": "type"
//														},
//														"1HPFJGN2R0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HPFK503D59",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HPFK503D60",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HPFJGN2R0",
//															"faceTagName": "wait"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HPFIKB8I1",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HPFIKB8I2",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "edit",
//											"jaxId": "1HPFIKB8I3",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HPFIKB8I4",
//													"attrs": {
//														"type": "edit",
//														"id": "EdDelay",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100",
//														"h": "20",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"inputType": "Text",
//														"text": "",
//														"placeHolder": "",
//														"color": "[0,0,0]",
//														"bgColor": "[255,255,255,1.00]",
//														"font": "",
//														"fontSize": "16",
//														"outline": "0",
//														"border": "[0,0,1,0]",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"selectOnFocus": "true",
//														"spellCheck": "true",
//														"flex": "true"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HPFIKB8I5",
//													"attrs": {
//														"1HPFITSKP0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HPFJH9D810",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HPFJH9D811",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HPFITSKP0",
//															"faceTagName": "click"
//														},
//														"1HPFJELG70": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HPFK503E0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HPFK503E1",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HPFJELG70",
//															"faceTagName": "type"
//														},
//														"1HPFJGN2R0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HPFK503E2",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HPFK503E3",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HPFJGN2R0",
//															"faceTagName": "wait"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HPFIKB8I6",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HPFIKB8I7",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1HPFIKB8I8",
//									"attrs": {
//										"1HPFITSKP0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HPFJH9D814",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HPFJH9D815",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HPFITSKP0",
//											"faceTagName": "click"
//										},
//										"1HPFJPR5R0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HPFK503E4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HPFK503E5",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HPFJPR5R0",
//											"faceTagName": "waitLoad"
//										},
//										"1HPFJELG70": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HPFK503E6",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HPFK503E7",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HPFJELG70",
//											"faceTagName": "type"
//										},
//										"1HPFJGN2R0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HPFK503E8",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HPFK503E9",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HPFJGN2R0",
//											"faceTagName": "wait"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HPFIKB8I9",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HPFIKB8I10",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear/@StdUI/ui/DataView.js",
//							"jaxId": "1HRCGCOMO0",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1HRCGJMBC0",
//									"attrs": {
//										"box": "null",
//										"template": "\"1HRCEVTGL0\"",
//										"dataObj": "#{\"action\":\"click\",\"query\":\"[id=\\\"123\\\"]\",\"content\":\"\",\"dx\":0,\"dy\":0,\"waitBefore\":500,\"waitAfter\":500}",
//										"property": "",
//										"options": {
//											"jaxId": "1HRCGJMBC1",
//											"attrs": {
//												"titleHeight": "30",
//												"titleSize": "18",
//												"titleColor": "#cfgColor[\"fontBody\"]",
//												"titleBold": "true",
//												"lineHeight": "30",
//												"lineGap": "5",
//												"labelSize": "12",
//												"labelColor": "#cfgColor[\"fontBody\"]",
//												"labelBold": "true",
//												"labelLine": "false",
//												"valueSize": "14",
//												"valueColor": "#cfgColor[\"fontBody\"]",
//												"valueBold": "false",
//												"segHeight": "20",
//												"segSize": "14",
//												"segBold": "true",
//												"segColor": "#cfgColor[\"fontBody\"]",
//												"trace": "false",
//												"edit": "true",
//												"noteSize": "12"
//											}
//										},
//										"title": ""
//									}
//								},
//								"properties": {
//									"jaxId": "1HRCGJMBC2",
//									"attrs": {
//										"type": "#null#>DataView(null,\"1HRCEVTGL0\",{\"action\":\"click\",\"query\":\"[id=\\\"123\\\"]\",\"content\":\"\",\"dx\":0,\"dy\":0,\"waitBefore\":500,\"waitAfter\":500},\"\",{\"titleHeight\":30,\"titleSize\":18,\"titleColor\":cfgColor[\"fontBody\"],\"titleBold\":true,\"lineHeight\":30,\"lineGap\":5,\"labelSize\":12,\"labelColor\":cfgColor[\"fontBody\"],\"labelBold\":true,\"labelLine\":false,\"valueSize\":14,\"valueColor\":cfgColor[\"fontBody\"],\"valueBold\":false,\"segHeight\":20,\"segSize\":14,\"segBold\":true,\"segColor\":cfgColor[\"fontBody\"],\"trace\":false,\"edit\":true,\"noteSize\":12},\"\")",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"display": "On",
//										"face": ""
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HRCGJMBC3",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1HRCGJMBC4",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HRCGJMBC5",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false",
//								"containerSlots": {
//									"jaxId": "1HRCGJMBC6",
//									"attrs": {}
//								}
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1HPFFBP7D11",
//					"attrs": {
//						"1HPFITSKP0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HPFJH9D818",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HPFJH9D819",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HPFITSKP0",
//							"faceTagName": "click"
//						},
//						"1HPFJELG70": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HPFK503E10",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HPFK503E11",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HPFJELG70",
//							"faceTagName": "type"
//						},
//						"1HPFJGN2R0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HPFK503E12",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HPFK503E13",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HPFJGN2R0",
//							"faceTagName": "wait"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1HPFFBP7D12",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1HPFFBP7D13",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1HPFFBP7D14",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"background": "false",
//				"color": "false",
//				"gradient": "false",
//				"border": "false",
//				"borders": "false",
//				"borderStyle": "false",
//				"borderColor": "false",
//				"borderColors": "false",
//				"corner": "false",
//				"coner": "false",
//				"coners": "false",
//				"shadow": "false",
//				"shadowX": "false",
//				"shadowY": "false",
//				"shadowBlur": "false",
//				"shadowSpread": "false",
//				"shadowColor": "false",
//				"maskImage": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}