//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnSwitch} from "/@StdUI/ui/BtnSwitch.js";
import {BtnText} from "/@StdUI/ui/BtnText.js";
/*#{1IUV8TVST0StartDoc*/
import {tabNT} from "/@tabos";
import QRCode from "/@qrcode";
/*}#1IUV8TVST0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let DlgShare=function(title,closeIcon,buttons){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let txtTitle,boxContent,btnShare,boxQRCode,boxButtons;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1H1T7ISV51LocalVals*/
	let app,dlgVO;
	app=window.tabOSApp;
	dlgVO=null;
	/*}#1H1T7ISV51LocalVals*/
	
	/*#{1H1T7ISV51PreState*/
	/*}#1H1T7ISV51PreState*/
	state={
		"title":title,"buttons":buttons,
		/*#{1H1T7ISV56ExState*/
		/*}#1H1T7ISV56ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1H1T7ISV51PostState*/
	/*}#1H1T7ISV51PostState*/
	cssVO={
		"hash":"1H1T7ISV51",nameHost:true,
		"type":"hud","x":"50%","y":30,"w":500,"h":"","anchorX":1,"padding":10,"minW":"","minH":"","maxW":"90%","maxH":"","styleClass":"","contentLayout":"flex-y",
		children:[
			{
				"hash":"1H1T7LGH40",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.body,"border":2,
				"borderColor":cfgColor["fontBodySub"],"corner":5,"shadow":true,"shadowX":3,"shadowY":6,"shadowBlur":5,"shadowColor":[0,0,0,0.3],
			},
			{
				"hash":"1H1T7O2SA0",
				"type":"text","id":"TxtTitle","position":"relative","x":0,"y":0,"w":"100%","h":"","uiEvent":-1,"margin":[0,0,10,0],"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","color":cfgColor.fontBodySub,"text":(($ln==="CN")?("分享你的智能体系统"):("Share your agent sysatem")),"fontSize":txtSize.big,"fontWeight":"bold",
				"fontStyle":"normal","textDecoration":"",
			},
			{
				"hash":"1H1T7S0BE0",
				"type":"hud","id":"BoxContent","position":"relative","x":0,"y":0,"w":"100%","h":"","minW":"","minH":50,"maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
				children:[
					{
						"hash":"1IUV91BDV0",
						"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":30,"padding":[0,10,0,10],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
						"itemsAlign":1,
						children:[
							{
								"hash":"1IUV94LIT0",
								"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","margin":[0,5,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
								"text":(($ln==="CN")?("允许共享"):("Allow share")),"fontSize":txtSize.mid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
							},
							{
								"hash":"1IUV9356J0",
								"type":BtnSwitch(20,false),"id":"BtnShare","position":"relative","x":0,"y":0,
								/*#{1IUV9356J0Codes*/
								OnCheck(check){
									self.setShadowInfo(check);
								}
								/*}#1IUV9356J0Codes*/
							}
						],
					},
					{
						"hash":"1IUV975QP0",
						"type":"hud","id":"BoxQRCode","position":"relative","x":"50%","y":0,"w":256,"h":256,"anchorX":1,"display":0,"uiEvent":-1,"margin":[10,0,0,0],"minW":"",
						"minH":"","maxW":"","maxH":"","styleClass":"",
					},
					{
						"hash":"1IUV9EKS50",
						"type":"hud","id":"BoxNoQR","position":"relative","x":"50%","y":0,"w":256,"h":256,"anchorX":1,"margin":[10,0,0,0],"padding":20,"minW":"","minH":"",
						"maxW":"","maxH":"","styleClass":"",
						children:[
							{
								"hash":"1IUV9FCB40",
								"type":"box","position":"relative","x":0,"y":0,"w":"100%","h":"100%","alpha":0.5,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["fontBody"],
								"maskImage":appCfg.sharedAssets+"/share.svg",
							}
						],
					},
					{
						"hash":"1IUV9J1530",
						"type":"text","position":"relative","x":0,"y":0,"w":"100%","h":"","padding":10,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodySub"],
						"text":(($ln==="CN")?("🌎开启共享后，在手机上用系统相机App扫描二维码进入当前智能系统。\n\n⚠️注意：通过共享页面可以执行当前系统中的各种智能体，具有一定的安全风险。为了保护你的隐私和安全，请不要随意分享二维码。\n\n\n⚡️关闭共享后，旧的二维码会同时失效，再次开启后会生成新的二维码。"):("🌎After enabling sharing, scan the QR code with the system camera app on your phone to access the current agent system.\n\n⚠️Note: The shared client can execute agents in the current system, which poses a certain security risk. To protect your privacy and security, please protect your QR code.\n\n⚡️After turning off sharing, the old QR code will be invalidated at the same time, and a new QR code will be generated when re-enabled.")),
						"fontSize":txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","wrap":true,
					}
				],
			},
			{
				"hash":"1H1T7UCES0",
				"type":"hud","id":"BoxButtons","position":"relative","x":0,"y":0,"w":"100%","h":40,"margin":[5,0,0,0],"padding":0,"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","contentLayout":"flex-x","subAlign":1,"itemsAlign":1,
				children:[
					{
						"hash":"1IUVAJM890",
						"type":BtnText("primary",100,24,(($ln==="CN")?("关闭"):("Close")),false,""),"position":"relative","x":0,"y":0,
						"OnClick":function(event){
							/*#{1IUVB2QJR0FunctionBody*/
							self.close();
							/*}#1IUVB2QJR0FunctionBody*/
						},
					}
				],
			}
		],
		/*#{1H1T7ISV51ExtraCSS*/
		/*}#1H1T7ISV51ExtraCSS*/
		faces:{
			"showqr":{
				/*BoxQRCode*/"#1IUV975QP0":{
					"display":1
				},
				/*BoxNoQR*/"#1IUV9EKS50":{
					"display":0
				}
			},"hideqr":{
				/*BoxQRCode*/"#1IUV975QP0":{
					"display":0
				},
				/*BoxNoQR*/"#1IUV9EKS50":{
					"display":1
				}
			}
		},
		OnCreate:function(){
			self=this;
			txtTitle=self.TxtTitle;boxContent=self.BoxContent;btnShare=self.BtnShare;boxQRCode=self.BoxQRCode;boxButtons=self.BoxButtons;
			/*#{1H1T7ISV51Create*/
			//Apply drag to move:
			VFACT.applyMoveDrag(self.BoxBG,self);
			boxQRCode.webObj.style.userSelect="none";
			/*}#1H1T7ISV51Create*/
		},
		/*#{1H1T7ISV51EndCSS*/
		/*}#1H1T7ISV51EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.getShadowInfo=async function(){
		/*#{1IUVTDBM40Start*/
		let res;
		res=await tabNT.makeCall("shadowDomain",{action:"get"});
		if(!res || res.code!==200){
			return;
		}
		if(res.key && res.domain){
			let url
			url=`https://user-${res.domain}-${tabNT.loginVO.userId}.ai2apps.com`;
			btnShare.checked=true;
			boxQRCode.webObj.innerHTML="";
			const qrCode=new QRCode(boxQRCode.webObj,{text:url,width:256,height:256});			
			self.showFace("showqr");
		}else{
			btnShare.checked=false;
			self.showFace("hideqr");
		}
		btnShare.enable=true;
		/*}#1IUVTDBM40Start*/
	};
	//------------------------------------------------------------------------
	cssVO.setShadowInfo=async function(enable){
		/*#{1IUVU19IE0Start*/
		let res;
		if(enable){
			res=await tabNT.makeCall("shadowDomain",{action:"on"});
		}else{
			res=await tabNT.makeCall("shadowDomain",{action:"off"});
		}
		if(res && res.key && res.domain){
			let url
			url=`https://user-${res.domain}-${tabNT.loginVO.userId}.ai2apps.com`;
			boxQRCode.webObj.innerHTML="";
			const qrCode=new QRCode(boxQRCode.webObj,{text:url,width:256,height:256});			
			self.showFace("showqr");
			btnShare.checked=true;
			if(window.tabApi){
				window.tabApi.shadowDomain({userId:tabNT.loginVO.userId,key:res.key,domain:res.domain});
			}
		}else{
			self.showFace("hideqr");
			btnShare.checked=false;
			if(window.tabApi){
				window.tabApi.shadowDomain(null);
			}
		}
		/*}#1IUVU19IE0Start*/
	};
	/*#{1H1T7ISV51PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.showDlg=function(vo){
		dlgVO=vo;
		btnShare.checked=false;
		btnShare.enable=false;
		self.showFace("hideqr");
		self.getShadowInfo();
		self.animate({type:"in",alpha:0,scale:0.9,time:100});
	};
	
	//------------------------------------------------------------------------
	cssVO.close=function(result){
		//Maybe animation:
		app.closeDlg(self,result);
		if(dlgVO){
			let next;
			next=dlgVO.next||dlgVO.callback;
			if(next){
				next(result);
			}
		}
	};
	/*}#1H1T7ISV51PostCSSVO*/
	cssVO.constructor=DlgShare;
	return cssVO;
};
/*#{1H1T7ISV51ExCodes*/
/*}#1H1T7ISV51ExCodes*/

//----------------------------------------------------------------------------
DlgShare.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1H1T7ISV51PreAISpot*/
	/*}#1H1T7ISV51PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type=(($ln==="CN")?("标准对话框"):("Standard Dialog"));
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1H1T7ISV51PostAISpot*/
	/*}#1H1T7ISV51PostAISpot*/
	return exposeVO;
};

/*#{1IUV8TVST0EndDoc*/
/*}#1IUV8TVST0EndDoc*/

export default DlgShare;
export{DlgShare};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1IUV8TVST0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1H1T7ISV52",
//			"attrs": {
//				"device": "Desktop 800x600",
//				"screenW": "800",
//				"screenH": "600",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1H1T7ISV53",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1H8H690AD0",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1H1T7ISV54",
//			"attrs": {
//				"title": {
//					"type": "string",
//					"valText": "Dialog title",
//					"localizable": true
//				},
//				"closeIcon": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"buttons": {
//					"type": "auto",
//					"valText": "[]"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1H1T7ISV55",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1H1T7ISV56",
//			"attrs": {
//				"title": {
//					"type": "string",
//					"valText": "#title",
//					"localizable": true
//				},
//				"buttons": {
//					"type": "auto",
//					"valText": "#buttons"
//				}
//			}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IUVTDBM40",
//					"attrs": {
//						"id": "getShadowInfo",
//						"label": "New AI Seg",
//						"x": "75",
//						"y": "55",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IUVTDKSA0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IUVTDKSA1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IUVTDKSA2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IUVU19IE0",
//					"attrs": {
//						"id": "setShadowInfo",
//						"label": "New AI Seg",
//						"x": "75",
//						"y": "135",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IUVU1MBA0",
//							"attrs": {
//								"enable": {
//									"type": "bool",
//									"valText": "false"
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IUVU1MBA1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IUVU1MBA2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				}
//			]
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": {
//			"type": "string",
//			"valText": "Standard Dialog",
//			"localize": {
//				"EN": "Standard Dialog",
//				"CN": "标准对话框"
//			},
//			"localizable": true
//		},
//		"gearIcon": "gears.svg",
//		"gearW": "360",
//		"gearH": "500",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1H1T7ISV57",
//			"attrs": {
//				"showqr": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IUVA87G60",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IUVAET6I0",
//							"attrs": {}
//						}
//					}
//				},
//				"hideqr": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IUVA8ECE0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IUVAET6I1",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1I8OEIDG90",
//			"attrs": {}
//		},
//		"exposeToAI": "true",
//		"descAI": "",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1H1T7ISV51",
//			"attrs": {
//				"properties": {
//					"jaxId": "1H1T7ISV58",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "50%",
//						"y": "30",
//						"w": "500",
//						"h": "\"\"",
//						"anchorH": "Center",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "10",
//						"minW": "",
//						"minH": "",
//						"maxW": "90%",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Flex Y"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1H1T7LGH40",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1T83E7O0",
//									"attrs": {
//										"type": "box",
//										"id": "BoxBG",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor.body",
//										"border": "2",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor[\"fontBodySub\"]",
//										"corner": "5",
//										"shadow": "true",
//										"shadowX": "3",
//										"shadowY": "6",
//										"shadowBlur": "5",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.30]"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H1T83E7O1",
//									"attrs": {
//										"1IUVA87G60": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IUVAET6I2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IUVAET6I3",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IUVA87G60",
//											"faceTagName": "showqr"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1H1T83E7O2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H1T83E7O3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1H1T7O2SA0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1T83E7O4",
//									"attrs": {
//										"type": "text",
//										"id": "TxtTitle",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "\"\"",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,10,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#cfgColor.fontBodySub",
//										"text": {
//											"type": "string",
//											"valText": "Share your agent sysatem",
//											"localize": {
//												"EN": "Share your agent sysatem",
//												"CN": "分享你的智能体系统"
//											},
//											"localizable": true
//										},
//										"font": "",
//										"fontSize": "#txtSize.big",
//										"bold": "true",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Top",
//										"wrap": "false",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0",
//										"autoSizeW": "false",
//										"autoSizeH": "false"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H1T83E7O5",
//									"attrs": {
//										"1IUVA87G60": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IUVAET6I4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IUVAET6I5",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IUVA87G60",
//											"faceTagName": "showqr"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1H1T83E7O6",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H1T83E7O7",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1H1T7S0BE0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1T83E7O8",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxContent",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "\"\"",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "50",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex Y"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1IUV91BDV0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IUV96C0H0",
//													"attrs": {
//														"type": "hud",
//														"id": "",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "30",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "[0,10,0,10]",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex X",
//														"itemsAlign": "Center"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1IUV94LIT0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IUV96C0H1",
//																	"attrs": {
//																		"type": "text",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[0,5,0,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontBody\"]",
//																		"text": {
//																			"type": "string",
//																			"valText": "Allow share",
//																			"localize": {
//																				"EN": "Allow share",
//																				"CN": "允许共享"
//																			},
//																			"localizable": true
//																		},
//																		"font": "",
//																		"fontSize": "#txtSize.mid",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Top",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"lineClamp": "0",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IUV96C0H2",
//																	"attrs": {
//																		"1IUVA87G60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IUVAET6I6",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IUVAET6I7",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IUVA87G60",
//																			"faceTagName": "showqr"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1IUV96C0H3",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1IUV96C0H4",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnSwitch.js",
//															"jaxId": "1IUV9356J0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1IUV96C0H5",
//																	"attrs": {
//																		"size": "20",
//																		"check": "false"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1IUV96C0H6",
//																	"attrs": {
//																		"type": "#null#>BtnSwitch(20,false)",
//																		"id": "BtnShare",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IUV96C0H7",
//																	"attrs": {
//																		"1IUVA87G60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IUVAET6I8",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IUVAET6I9",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IUVA87G60",
//																			"faceTagName": "showqr"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1IUV96C0H8",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1IUV96C0H9",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "true",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1IUV96C0H10",
//																	"attrs": {}
//																}
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1IUV96C0H11",
//													"attrs": {
//														"1IUVA87G60": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IUVAET6I10",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IUVAET6I11",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IUVA87G60",
//															"faceTagName": "showqr"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IUV96C0H12",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IUV96C0H13",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1IUV975QP0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IUV9EJ100",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxQRCode",
//														"position": "relative",
//														"x": "50%",
//														"y": "0",
//														"w": "256",
//														"h": "256",
//														"anchorH": "Center",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "Off",
//														"clip": "Off",
//														"uiEvent": "Tree Off",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[10,0,0,0]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": ""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IUV9EJ101",
//													"attrs": {
//														"1IUVA8ECE0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IUVAET6I12",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IUVAET6I13",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IUVA8ECE0",
//															"faceTagName": "hideqr"
//														},
//														"1IUVA87G60": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IUVAET6I14",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IUVAET6I15",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IUVA87G60",
//															"faceTagName": "showqr"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IUV9EJ102",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IUV9EJ103",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "true",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1IUV9EKS50",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IUV9EKS51",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxNoQR",
//														"position": "relative",
//														"x": "50%",
//														"y": "0",
//														"w": "256",
//														"h": "256",
//														"anchorH": "Center",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[10,0,0,0]",
//														"padding": "20",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": ""
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "box",
//															"jaxId": "1IUV9FCB40",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IUVAET6I16",
//																	"attrs": {
//																		"type": "box",
//																		"id": "",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "100%",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "0.5",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"background": "#cfgColor[\"fontBody\"]",
//																		"border": "0",
//																		"borderStyle": "Solid",
//																		"borderColor": "[0,0,0,1.00]",
//																		"corner": "0",
//																		"shadow": "false",
//																		"shadowX": "2",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowSpread": "0",
//																		"shadowColor": "[0,0,0,0.50]",
//																		"maskImage": "#appCfg.sharedAssets+\"/share.svg\""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IUVAET6I17",
//																	"attrs": {
//																		"1IUVA87G60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IUVAET6I18",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IUVAET6I19",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IUVA87G60",
//																			"faceTagName": "showqr"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1IUVAET6I20",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1IUVAET6I21",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false"
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1IUV9EKS52",
//													"attrs": {
//														"1IUVA8ECE0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IUVAET6I22",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IUVAET6I23",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IUVA8ECE0",
//															"faceTagName": "hideqr"
//														},
//														"1IUVA87G60": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IUVAET6I24",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IUVAET6I25",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IUVA87G60",
//															"faceTagName": "showqr"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IUV9EKS53",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IUV9EKS54",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1IUV9J1530",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IUVAET6I26",
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "10",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBodySub\"]",
//														"text": {
//															"type": "string",
//															"valText": "🌎After enabling sharing, scan the QR code with the system camera app on your phone to access the current agent system.\n\n⚠️Note: The shared client can execute agents in the current system, which poses a certain security risk. To protect your privacy and security, please protect your QR code.\n\n⚡️After turning off sharing, the old QR code will be invalidated at the same time, and a new QR code will be generated when re-enabled.",
//															"localize": {
//																"EN": "🌎After enabling sharing, scan the QR code with the system camera app on your phone to access the current agent system.\n\n⚠️Note: The shared client can execute agents in the current system, which poses a certain security risk. To protect your privacy and security, please protect your QR code.\n\n⚡️After turning off sharing, the old QR code will be invalidated at the same time, and a new QR code will be generated when re-enabled.",
//																"CN": "🌎开启共享后，在手机上用系统相机App扫描二维码进入当前智能系统。\n\n⚠️注意：通过共享页面可以执行当前系统中的各种智能体，具有一定的安全风险。为了保护你的隐私和安全，请不要随意分享二维码。\n\n\n⚡️关闭共享后，旧的二维码会同时失效，再次开启后会生成新的二维码。"
//															},
//															"localizable": true
//														},
//														"font": "",
//														"fontSize": "#txtSize.smallPlus",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "true",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IUVAET6I27",
//													"attrs": {
//														"1IUVA87G60": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IUVAET6I28",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IUVAET6I29",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IUVA87G60",
//															"faceTagName": "showqr"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IUVAET6I30",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IUVAET6I31",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1H1T83E7O9",
//									"attrs": {
//										"1IUVA87G60": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IUVAET6I32",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IUVAET6I33",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IUVA87G60",
//											"faceTagName": "showqr"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1H1T83E7O10",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H1T83E7O11",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1H1T7UCES0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1T83E7O12",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxButtons",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "40",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[5,0,0,0]",
//										"padding": "0",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex X",
//										"subAlign": "Center",
//										"attach": "true",
//										"flex": "false",
//										"itemsAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnText.js",
//											"jaxId": "1IUVAJM890",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1IUVAL8GB0",
//													"attrs": {
//														"style": "primary",
//														"w": "100",
//														"h": "24",
//														"text": {
//															"type": "string",
//															"valText": "Close",
//															"localize": {
//																"EN": "Close",
//																"CN": "关闭"
//															},
//															"localizable": true
//														},
//														"outlined": "false",
//														"icon": ""
//													}
//												},
//												"properties": {
//													"jaxId": "1IUVAL8GB1",
//													"attrs": {
//														"type": "#null#>BtnText(\"primary\",100,24,(($ln===\"CN\")?(\"关闭\"):(\"Close\")),false,\"\")",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": ""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IUVAL8GB2",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1IUVAL8GB3",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1IUVB2QJR0",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1IUVB35280",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1IUVAL8GB4",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1IUVAL8GB5",
//													"attrs": {
//														"Slot1H2F6U36O0": {
//															"jaxId": "1IUVAL8GB6",
//															"attrs": {
//																"subHuds": {
//																	"attrs": []
//																},
//																"container": "true"
//															}
//														}
//													}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1H1T83E7O13",
//									"attrs": {
//										"1IUVA87G60": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IUVAET6I34",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IUVAET6I35",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IUVA87G60",
//											"faceTagName": "showqr"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1H1T83E7O14",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H1T83E7O15",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1H1T7ISV59",
//					"attrs": {
//						"1IUVA87G60": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1IUVAET6I36",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IUVAET6I37",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1IUVA87G60",
//							"faceTagName": "showqr"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1H1T7ISV510",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1H1T7ISV511",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "true",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1H1T7ISV512",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "true",
//				"h": "true",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false",
//				"innerLayout": {
//					"valText": "false"
//				},
//				"marginL": {
//					"valText": "false"
//				},
//				"marginR": {
//					"valText": "false"
//				},
//				"marginT": {
//					"valText": "false"
//				},
//				"marginB": {
//					"valText": "false"
//				},
//				"paddingL": {
//					"valText": "false"
//				},
//				"paddingR": {
//					"valText": "false"
//				},
//				"paddingT": {
//					"valText": "false"
//				},
//				"paddingB": {
//					"valText": "false"
//				},
//				"attach": {
//					"valText": "false"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}