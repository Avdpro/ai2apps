//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
/*#{1HL3PO1FK0StartDoc*/
/*}#1HL3PO1FK0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BtnEvent=function(event){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let name="Event";
	let icon=appCfg.sharedAssets+"/event.svg";
	let focused=false;
	let url="www.google.com";
	let target="DIV class=\"abc\"";
	
	/*#{1HL3PO1FK1LocalVals*/
	let eventObj=event;
	let node;
	node=event.target;
	if(node){
		if(node.nodeType===3){
			target=JSON.stringify(node.text);
		}else if(node.id){
			target=node.id;
		}else if(node.tagName){
			target=`[${node.tagName}]`
		}
		if(node.class){
			target+=`(${JSON.stringify(node.class)})`;
		}
	}else{
		target=null;
	}
	switch(event.event){
		case "click":
			icon=appCfg.sharedAssets+"/mouse.svg";
			url=null;
			break;
		case "dblclick":
			icon=appCfg.sharedAssets+"/mouse.svg";
			url=null;
			break;
		case "keydown":
			icon=appCfg.sharedAssets+"/keybtn.svg";
			url=null;
			break;
		case "input":
			icon=appCfg.sharedAssets+"/edit.svg";
			url=null;
			break;
		case "load":
			icon=appCfg.sharedAssets+"/web.svg";
			url=event.url;
			break;
		case "popup":
			icon=appCfg.sharedAssets+"/additem.svg";
			url=event.url;
			break;
		case "request":
			icon=appCfg.sharedAssets+"/link.svg";
			url=event.url;
			break;
		case "response":
			icon=appCfg.sharedAssets+"/checkout.svg";
			url=event.url;
			break;
	}
	name=event.event?event.event.toUpperCase():"EVENT";
	/*}#1HL3PO1FK1LocalVals*/
	
	/*#{1HL3PO1FK1PreState*/
	/*}#1HL3PO1FK1PreState*/
	/*#{1HL3PO1FK1PostState*/
	/*}#1HL3PO1FK1PostState*/
	cssVO={
		"hash":"1HL3PO1FK1",nameHost:true,
		"type":"button","x":0,"y":0,"w":"100%","h":"","overflow":1,"cursor":"pointer","padding":[3,0,3,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
		"contentLayout":"flex-y",
		children:[
			{
				"hash":"1HL3PR5GO0",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["body"],
			},
			{
				"hash":"1HU6DR6150",
				"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":30,"uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
				"itemsAlign":1,
				children:[
					{
						"hash":"1HU6DS8TI0",
						"type":"box","id":"BoxIcon","position":"relative","x":0,"y":0,"w":25,"h":25,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["fontBodySub"],
						"maskImage":icon,
					},
					{
						"hash":"1HU6DSJ1Q0",
						"type":"text","position":"relative","x":0,"y":0,"w":100,"h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":[0,0,0],"text":name,
						"fontSize":txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
					}
				],
			},
			{
				"hash":"1HU6DU9Q80",
				"type":"text","id":"TxtURL","position":"relative","x":0,"y":0,"w":"100%","h":"","padding":[0,0,0,25],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"color":[0,0,0],"text":url,"fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","ellipsis":true,"attached":!!url,
			},
			{
				"hash":"1HU6EECGM0",
				"type":"hud","id":"BoxTarget","position":"relative","x":25,"y":0,"w":">calc(100% - 25px)","h":30,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"contentLayout":"flex-x","itemsAlign":1,"attached":!!target,
				children:[
					{
						"hash":"1HU6EGINL0",
						"type":"box","position":"relative","x":0,"y":0,"w":28,"h":28,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["fontBodySub"],
						"maskImage":appCfg.sharedAssets+"/hudbox.svg",
					},
					{
						"hash":"1HU6EJ5ED0",
						"type":"text","position":"relative","x":0,"y":0,"w":">calc(100% - 60px)","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":[0,0,0],
						"text":target,"fontSize":txtSize.smallPlus,"fontWeight":"bold","fontStyle":"normal","textDecoration":"","alignV":1,"ellipsis":true,
					},
					{
						"hash":"1HU6EKNAJ0",
						"type":BtnIcon("front",26,0,appCfg.sharedAssets+"/spot.svg",null),"id":"BtnPinNode","position":"relative","x":0,"y":0,
						"tip":"Locate Element",
						"OnClick":function(event){
							/*#{1HU6FOHJB0FunctionBody*/
							self.showNode(eventObj.target);
							/*}#1HU6FOHJB0FunctionBody*/
						},
					}
				],
			}
		],
		/*#{1HL3PO1FK1ExtraCSS*/
		/*}#1HL3PO1FK1ExtraCSS*/
		faces:{
			"up":{
				/*#{1HL3PVAUQ0PreCode*/
				$(){
					if(focused){
						return false;
					}
				},
				/*}#1HL3PVAUQ0PreCode*/
				/*BoxBG*/"#1HL3PR5GO0":{
					"background":cfgColor["body"]
				}
			},"over":{
				/*#{1HL3PVAUQ2PreCode*/
				$(){
					if(focused){
						return false;
					}
				},
				/*}#1HL3PVAUQ2PreCode*/
				/*BoxBG*/"#1HL3PR5GO0":{
					"background":cfgColor["itemOver"]
				}
			},"down":{
				/*#{1HL3PVAUQ4PreCode*/
				$(){
					if(focused){
						return false;
					}
				},
				/*}#1HL3PVAUQ4PreCode*/
				/*BoxBG*/"#1HL3PR5GO0":{
					"background":cfgColor["itemDown"]
				}
			},"focus":{
				/*BoxBG*/"#1HL3PR5GO0":{
					"background":cfgColor["fontPrimarySub"]
				},
				/*#{1HL3PVAUQ6Code*/
				$(){
					focused=true;
				}
				/*}#1HL3PVAUQ6Code*/
			},"blur":{
				/*BoxBG*/"#1HL3PR5GO0":{
					"background":cfgColor["body"]
				},
				/*#{1HL3PVAUQ8Code*/
				$(){
					focused=false;
				}
				/*}#1HL3PVAUQ8Code*/
			}
		},
		OnCreate:function(){
			self=this;
			
			/*#{1HL3PO1FK1Create*/
			/*}#1HL3PO1FK1Create*/
		},
		/*#{1HL3PO1FK1EndCSS*/
		/*}#1HL3PO1FK1EndCSS*/
	};
	/*#{1HL3PO1FK1PostCSSVO*/
	/*}#1HL3PO1FK1PostCSSVO*/
	return cssVO;
};
/*#{1HL3PO1FK1ExCodes*/
/*}#1HL3PO1FK1ExCodes*/

BtnEvent.gearExport={
	framework: "jax",
	hudType: "button",
	"showName":"",icon:"gears.svg",previewImg:false,
	fixPose:false,initW:100,initH:100,
	catalog:"",
	args: {
		"event": {
			"name": "event", "showName": "event", "type": "auto", "key": true, "fixed": true, 
			"initVal": null
		}
	},
	state:{
	},
	properties:["id","position","x","y","display"],
	faces:["up","over","down","focus","blur"],
	subContainers:{
	},
	/*#{1HL3PO1FK0ExGearInfo*/
	/*}#1HL3PO1FK0ExGearInfo*/
};
/*#{1HL3PO1FK0EndDoc*/
/*}#1HL3PO1FK0EndDoc*/

export default BtnEvent;
export{BtnEvent};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearButton",
//	"jaxId": "1HL3PO1FK0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1HL3PO1FK2",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1HL3PO1FK3",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1HL3PO1FK4",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1HL3PO1FK5",
//			"attrs": {
//				"event": {
//					"type": "auto",
//					"valText": "null"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1HL3PO1FK6",
//			"attrs": {
//				"name": {
//					"type": "string",
//					"valText": "Event"
//				},
//				"icon": {
//					"type": "string",
//					"valText": "#appCfg.sharedAssets+\"/event.svg\""
//				},
//				"focused": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"url": {
//					"type": "string",
//					"valText": "www.google.com"
//				},
//				"target": {
//					"type": "string",
//					"valText": "DIV class=\"abc\""
//				}
//			}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1HL3PO1FK7",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1HL3PO1FK8",
//			"attrs": {
//				"up": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HL3PVAUQ0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "true",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HL3PVAUQ1",
//							"attrs": {}
//						}
//					}
//				},
//				"over": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HL3PVAUQ2",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "true",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HL3PVAUQ3",
//							"attrs": {}
//						}
//					}
//				},
//				"down": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HL3PVAUQ4",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "true",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HL3PVAUQ5",
//							"attrs": {}
//						}
//					}
//				},
//				"focus": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HL3PVAUQ6",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HL3PVAUQ7",
//							"attrs": {}
//						}
//					}
//				},
//				"blur": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HL3PVAUQ8",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HL3PVAUQ9",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1HL3PO1FK9",
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "button",
//			"jaxId": "1HL3PO1FK1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1HL3PO1FK10",
//					"attrs": {
//						"type": "button",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "On",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "pointer",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "[3,0,3,0]",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"enable": "true",
//						"drag": "NA",
//						"contentLayout": "Flex Y",
//						"itemsAlign": "Start"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1HL3PR5GO0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HL3PS0VH0",
//									"attrs": {
//										"type": "box",
//										"id": "BoxBG",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"body\"]",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HL3PS0VH1",
//									"attrs": {
//										"1HL3PVAUQ0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HL3Q51G20",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HL3Q51G21",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor[\"body\"]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HL3PVAUQ0",
//											"faceTagName": "up"
//										},
//										"1HL3PVAUQ2": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HL3Q51G22",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HL3Q51G23",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor[\"itemOver\"]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HL3PVAUQ2",
//											"faceTagName": "over"
//										},
//										"1HL3PVAUQ4": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HL3Q51G24",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HL3Q51G25",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor[\"itemDown\"]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HL3PVAUQ4",
//											"faceTagName": "down"
//										},
//										"1HL3PVAUQ6": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HL3Q51G26",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HL3Q51G27",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor[\"fontPrimarySub\"]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HL3PVAUQ6",
//											"faceTagName": "focus"
//										},
//										"1HL3PVAUQ8": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HL3Q51G28",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HL3Q51G29",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor[\"body\"]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HL3PVAUQ8",
//											"faceTagName": "blur"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HL3PS0VH2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HL3PS0VH3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "true",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1HU6DR6150",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HU6DVAMB0",
//									"attrs": {
//										"type": "hud",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex X",
//										"itemsAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1HU6DS8TI0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HU6DS8TI1",
//													"attrs": {
//														"type": "box",
//														"id": "BoxIcon",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "25",
//														"h": "25",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "#cfgColor[\"fontBodySub\"]",
//														"border": "0",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]",
//														"maskImage": "#icon"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HU6DS8TI2",
//													"attrs": {
//														"1HL3PVAUQ0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HU6DS8TJ2",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HU6DS8TJ3",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HL3PVAUQ0",
//															"faceTagName": "up"
//														},
//														"1HL3PVAUQ2": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HU6DS8TJ4",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HU6DS8TJ5",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HL3PVAUQ2",
//															"faceTagName": "over"
//														},
//														"1HL3PVAUQ4": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HU6DS8TJ6",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HU6DS8TJ7",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HL3PVAUQ4",
//															"faceTagName": "down"
//														},
//														"1HL3PVAUQ8": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HU6HJ5270",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HU6HJ5271",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HL3PVAUQ8",
//															"faceTagName": "blur"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HU6DS8TJ8",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HU6DS8TJ9",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1HU6DSJ1Q0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HU6DSJ1Q1",
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "[0,0,0]",
//														"text": "#name",
//														"font": "",
//														"fontSize": "#txtSize.smallPlus",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "false",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HU6DSJ1R0",
//													"attrs": {
//														"1HL3PVAUQ0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HU6DSJ1R3",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HU6DSJ1R4",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HL3PVAUQ0",
//															"faceTagName": "up"
//														},
//														"1HL3PVAUQ2": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HU6DSJ1R5",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HU6DSJ1R6",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HL3PVAUQ2",
//															"faceTagName": "over"
//														},
//														"1HL3PVAUQ4": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HU6DSJ1R7",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HU6DSJ1R8",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HL3PVAUQ4",
//															"faceTagName": "down"
//														},
//														"1HL3PVAUQ8": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HU6HJ5282",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HU6HJ5283",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HL3PVAUQ8",
//															"faceTagName": "blur"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HU6DSJ1R9",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HU6DSJ1R10",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1HU6DVAMB5",
//									"attrs": {
//										"1HL3PVAUQ0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HU6DVAMB6",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HU6DVAMB7",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HL3PVAUQ0",
//											"faceTagName": "up"
//										},
//										"1HL3PVAUQ2": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HU6DVAMB8",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HU6DVAMB9",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HL3PVAUQ2",
//											"faceTagName": "over"
//										},
//										"1HL3PVAUQ4": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HU6DVAMB10",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HU6DVAMB11",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HL3PVAUQ4",
//											"faceTagName": "down"
//										},
//										"1HL3PVAUQ8": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HU6HJ5286",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HU6HJ5287",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HL3PVAUQ8",
//											"faceTagName": "blur"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HU6DVAMB14",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HU6DVAMB15",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1HU6DU9Q80",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HU6DVAMC0",
//									"attrs": {
//										"type": "text",
//										"id": "TxtURL",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "[0,0,0,25]",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "[0,0,0]",
//										"text": "#url",
//										"font": "",
//										"fontSize": "#txtSize.small",
//										"bold": "false",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Top",
//										"wrap": "false",
//										"ellipsis": "true",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0",
//										"attach": "#!!url"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HU6DVAMC1",
//									"attrs": {
//										"1HL3PVAUQ0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HU6EUU5R6",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HU6EUU5R7",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HL3PVAUQ0",
//											"faceTagName": "up"
//										},
//										"1HL3PVAUQ2": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HU6EUU5R8",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HU6EUU5R9",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HL3PVAUQ2",
//											"faceTagName": "over"
//										},
//										"1HL3PVAUQ4": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HU6EUU5R10",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HU6EUU5R11",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HL3PVAUQ4",
//											"faceTagName": "down"
//										},
//										"1HL3PVAUQ8": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HU6HJ52810",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HU6HJ52811",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HL3PVAUQ8",
//											"faceTagName": "blur"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HU6DVAMC2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HU6DVAMC3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1HU6EECGM0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HU6EUU5R14",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxTarget",
//										"position": "relative",
//										"x": "25",
//										"y": "0",
//										"w": "100%-25",
//										"h": "30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex X",
//										"itemsAlign": "Center",
//										"attach": "#!!target"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1HU6EGINL0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HU6EUU5R15",
//													"attrs": {
//														"type": "box",
//														"id": "",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"w": "28",
//														"h": "28",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "#cfgColor[\"fontBodySub\"]",
//														"border": "0",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]",
//														"maskImage": "#appCfg.sharedAssets+\"/hudbox.svg\""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HU6EUU5R16",
//													"attrs": {
//														"1HL3PVAUQ0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HU6HD27O0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HU6HD27O1",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HL3PVAUQ0",
//															"faceTagName": "up"
//														},
//														"1HL3PVAUQ2": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HU6HD27O2",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HU6HD27O3",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HL3PVAUQ2",
//															"faceTagName": "over"
//														},
//														"1HL3PVAUQ4": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HU6HD27O4",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HU6HD27O5",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HL3PVAUQ4",
//															"faceTagName": "down"
//														},
//														"1HL3PVAUQ8": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HU6HJ52814",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HU6HJ52815",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HL3PVAUQ8",
//															"faceTagName": "blur"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HU6EUU5R19",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HU6EUU5R20",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1HU6EJ5ED0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HU6EUU5R21",
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%-60",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "[0,0,0]",
//														"text": "#target",
//														"font": "",
//														"fontSize": "#txtSize.smallPlus",
//														"bold": "true",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Center",
//														"wrap": "false",
//														"ellipsis": "true",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HU6EUU5R22",
//													"attrs": {
//														"1HL3PVAUQ0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HU6HD27O6",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HU6HD27O7",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HL3PVAUQ0",
//															"faceTagName": "up"
//														},
//														"1HL3PVAUQ2": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HU6HD27O8",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HU6HD27O9",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HL3PVAUQ2",
//															"faceTagName": "over"
//														},
//														"1HL3PVAUQ4": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HU6HD27O10",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HU6HD27O11",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HL3PVAUQ4",
//															"faceTagName": "down"
//														},
//														"1HL3PVAUQ8": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HU6HJ52818",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HU6HJ52819",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HL3PVAUQ8",
//															"faceTagName": "blur"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HU6EUU5R25",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HU6EUU5R26",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1HU6EKNAJ0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1HU6EUU5R27",
//													"attrs": {
//														"style": "\"front\"",
//														"w": "26",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/spot.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1HU6EUU5R28",
//													"attrs": {
//														"type": "#null#>BtnIcon(\"front\",26,0,appCfg.sharedAssets+\"/spot.svg\",null)",
//														"id": "BtnPinNode",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": ""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HU6EUU5R29",
//													"attrs": {
//														"1HL3PVAUQ0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HU6HD27O12",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HU6HD27O13",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HL3PVAUQ0",
//															"faceTagName": "up"
//														},
//														"1HL3PVAUQ2": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HU6HD27O14",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HU6HD27O15",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HL3PVAUQ2",
//															"faceTagName": "over"
//														},
//														"1HL3PVAUQ4": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HU6HD27O16",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HU6HD27O17",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HL3PVAUQ4",
//															"faceTagName": "down"
//														},
//														"1HL3PVAUQ8": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HU6HJ52822",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HU6HJ52823",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HL3PVAUQ8",
//															"faceTagName": "blur"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HU6EUU5R32",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1HU6FOHJB0",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1HU6FOV220",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1HU6EUU5R33",
//													"attrs": {
//														"tip": {
//															"type": "string",
//															"valText": "Locate Element",
//															"localizable": true
//														}
//													}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1HU6EUU5R34",
//													"attrs": {}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1HU6EUU5R35",
//									"attrs": {
//										"1HL3PVAUQ0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HU6HD27O18",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HU6HD27O19",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HL3PVAUQ0",
//											"faceTagName": "up"
//										},
//										"1HL3PVAUQ2": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HU6HD27O20",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HU6HD27O21",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HL3PVAUQ2",
//											"faceTagName": "over"
//										},
//										"1HL3PVAUQ4": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HU6HD27O22",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HU6HD27O23",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HL3PVAUQ4",
//											"faceTagName": "down"
//										},
//										"1HL3PVAUQ8": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HU6HJ52826",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HU6HJ52827",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HL3PVAUQ8",
//											"faceTagName": "blur"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HU6EUU5R38",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HU6EUU5R39",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1HL3PO1FK11",
//					"attrs": {
//						"1HL3PVAUQ2": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HL3Q51G30",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HL3Q51G31",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HL3PVAUQ2",
//							"faceTagName": "over"
//						},
//						"1HL3PVAUQ4": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HL3Q51G32",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HL3Q51G33",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HL3PVAUQ4",
//							"faceTagName": "down"
//						},
//						"1HL3PVAUQ0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HU6CNA6N16",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HU6CNA6N17",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HL3PVAUQ0",
//							"faceTagName": "up"
//						},
//						"1HL3PVAUQ8": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HU6EUU5R40",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HU6EUU5R41",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HL3PVAUQ8",
//							"faceTagName": "blur"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1HL3PO1FK12",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1HL3PO1FK13",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1HL3PO1FK14",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"enable": "false",
//				"drag": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}