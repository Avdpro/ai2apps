//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1HM3JQDHK0StartDoc*/
/*}#1HM3JQDHK0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let Cover=function(){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1HM3JQDHK1LocalVals*/
	/*}#1HM3JQDHK1LocalVals*/
	
	/*#{1HM3JQDHK1PreState*/
	/*}#1HM3JQDHK1PreState*/
	/*#{1HM3JQDHK1PostState*/
	/*}#1HM3JQDHK1PostState*/
	cssVO={
		"hash":"1HM3JQDHK1",nameHost:true,
		"type":"hud","x":0,"y":0,"w":100,"h":100,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
		children:[
			{
				"hash":"1HM3JQMLB0",
				"type":"image","x":152,"y":162,"w":100,"h":100,"styleClass":"","image":"assets/tab_add.svg","fitSize":true,
				children:[
					{
						"hash":"1HM3JRFK80",
						"type":"image","x":157,"y":0,"w":100,"h":100,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","image":"assets/wait_click.svg","fitSize":true,
						children:[
							{
								"hash":"1HM3JS57M0",
								"type":"image","x":157,"y":0,"w":100,"h":100,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","image":"assets/wait_event.svg","fitSize":true,
							}
						],
					}
				],
			},
			{
				"hash":"1HM3JT9MV0",
				"type":"image","x":152,"y":312,"w":100,"h":100,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","image":"assets/wait_start.svg","fitSize":true,
				children:[
					{
						"hash":"1HM3JT9N10",
						"type":"image","x":157,"y":0,"w":100,"h":100,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","image":"/~/-tabos/shared/assets/aalogo.svg",
						"fitSize":true,
						children:[
							{
								"hash":"1HM3JT9N12",
								"type":"image","x":157,"y":0,"w":100,"h":100,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","image":"/~/-tabos/shared/assets/hudstate.svg",
								"fitSize":true,
							}
						],
					}
				],
			}
		],
		/*#{1HM3JQDHK1ExtraCSS*/
		/*}#1HM3JQDHK1ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			self=this;
			
			/*#{1HM3JQDHK1Create*/
			/*}#1HM3JQDHK1Create*/
		},
		/*#{1HM3JQDHK1EndCSS*/
		/*}#1HM3JQDHK1EndCSS*/
	};
	/*#{1HM3JQDHK1PostCSSVO*/
	/*}#1HM3JQDHK1PostCSSVO*/
	return cssVO;
};
/*#{1HM3JQDHK1ExCodes*/
/*}#1HM3JQDHK1ExCodes*/


export default Cover;
export{Cover};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1HM3JQDHK0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1HM3JQDHL0",
//			"attrs": {
//				"device": "iPad 1024x768",
//				"screenW": "1024",
//				"screenH": "768",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1HM3JQDHL1",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1HM3JQDHL2",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1HM3JQDHL3",
//			"attrs": {}
//		},
//		"localVars": {
//			"jaxId": "1HM3JQDHL4",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1HM3JQDHL5",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1HM3JQDHL6",
//			"attrs": {}
//		},
//		"mockupStates": {
//			"jaxId": "1HM3JQDHL7",
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1HM3JQDHK1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1HM3JQDHL8",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "100",
//						"h": "100",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": ""
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "image",
//							"jaxId": "1HM3JQMLB0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HM3JREKD0",
//									"attrs": {
//										"type": "image",
//										"id": "",
//										"position": "Absolute",
//										"x": "152",
//										"y": "162",
//										"w": "100",
//										"h": "100",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"image": "assets/tab_add.svg",
//										"autoSize": "false",
//										"fitSize": "Fit",
//										"repeat": "true",
//										"alignX": "Left",
//										"alignY": "Top"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "image",
//											"jaxId": "1HM3JRFK80",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HM3JRFK81",
//													"attrs": {
//														"type": "image",
//														"id": "",
//														"position": "Absolute",
//														"x": "157",
//														"y": "0",
//														"w": "100",
//														"h": "100",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"image": "assets/wait_click.svg",
//														"autoSize": "false",
//														"fitSize": "Fit",
//														"repeat": "true",
//														"alignX": "Left",
//														"alignY": "Top"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "image",
//															"jaxId": "1HM3JS57M0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HM3JS57M1",
//																	"attrs": {
//																		"type": "image",
//																		"id": "",
//																		"position": "Absolute",
//																		"x": "157",
//																		"y": "0",
//																		"w": "100",
//																		"h": "100",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"image": "assets/wait_event.svg",
//																		"autoSize": "false",
//																		"fitSize": "Fit",
//																		"repeat": "true",
//																		"alignX": "Left",
//																		"alignY": "Top"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HM3JS57M2",
//																	"attrs": {}
//																},
//																"functions": {
//																	"jaxId": "1HM3JS57M3",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HM3JS57M4",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false"
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1HM3JRFK90",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1HM3JRFK91",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HM3JRFK92",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1HM3JREKD1",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1HM3JREKD2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HM3JREKD3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "image",
//							"jaxId": "1HM3JT9MV0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HM3JT9MV1",
//									"attrs": {
//										"type": "image",
//										"id": "",
//										"position": "Absolute",
//										"x": "152",
//										"y": "312",
//										"w": "100",
//										"h": "100",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"image": "assets/wait_start.svg",
//										"autoSize": "false",
//										"fitSize": "Fit",
//										"repeat": "true",
//										"alignX": "Left",
//										"alignY": "Top"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "image",
//											"jaxId": "1HM3JT9N10",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HM3JT9N11",
//													"attrs": {
//														"type": "image",
//														"id": "",
//														"position": "Absolute",
//														"x": "157",
//														"y": "0",
//														"w": "100",
//														"h": "100",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"image": "/-tabos/shared/assets/aalogo.svg",
//														"autoSize": "false",
//														"fitSize": "Fit",
//														"repeat": "true",
//														"alignX": "Left",
//														"alignY": "Top"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "image",
//															"jaxId": "1HM3JT9N12",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HM3JT9N13",
//																	"attrs": {
//																		"type": "image",
//																		"id": "",
//																		"position": "Absolute",
//																		"x": "157",
//																		"y": "0",
//																		"w": "100",
//																		"h": "100",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"image": "/-tabos/shared/assets/hudstate.svg",
//																		"autoSize": "false",
//																		"fitSize": "Fit",
//																		"repeat": "true",
//																		"alignX": "Left",
//																		"alignY": "Top"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HM3JT9N14",
//																	"attrs": {}
//																},
//																"functions": {
//																	"jaxId": "1HM3JT9N15",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HM3JT9N16",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false"
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1HM3JT9N17",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1HM3JT9N18",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HM3JT9N19",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1HM3JT9N110",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1HM3JT9N111",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HM3JT9N112",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1HM3JQDHL9",
//					"attrs": {}
//				},
//				"functions": {
//					"jaxId": "1HM3JQDHL10",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1HM3JQDHL11",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1HM3JQDHL12",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}