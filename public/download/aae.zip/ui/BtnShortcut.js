//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
/*#{1IVRGR7T80StartDoc*/
import pathLib from "/@path";
import {tabNT} from "/@tabos";
import {getLocalAppInfo} from "/@pkg/pkgUtil.js";
/*}#1IVRGR7T80StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BtnShortcut=function(tool){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let txtTime,btnDownload,boxCheck,btnUpdate;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1IVRGR7T81LocalVals*/
	let appStub=null;
	let action="";
	/*}#1IVRGR7T81LocalVals*/
	
	/*#{1IVRGR7T81PreState*/
	/*}#1IVRGR7T81PreState*/
	state={
		"icon":appCfg.sharedAssets+"/agent.svg","label":tool.appId||tool,"desc":"Think think","date":"---- / -- / --",
		/*#{1IVRGR7T87ExState*/
		/*}#1IVRGR7T87ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1IVRGR7T81PostState*/
	/*}#1IVRGR7T81PostState*/
	cssVO={
		"hash":"1IVRGR7T81",nameHost:true,
		"type":"button","position":"relative","x":125,"y":50,"w":250,"h":100,"anchorX":1,"anchorY":1,"cursor":"pointer","margin":10,"padding":[10,10,5,10],"minW":"",
		"minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
		children:[
			{
				"hash":"1IVRGSANU0",
				"type":"box","id":"BoxBG","x":"50%","y":"50%","w":"100%","h":"100%","anchorX":1,"anchorY":1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"background":[255,255,255,1],"border":1,"corner":12,
			},
			{
				"hash":"1IVRGVCQF0",
				"type":"hud","position":"relative","x":0,"y":0,"w":50,"h":"100%","uiEvent":-1,"padding":[0,0,20,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"contentLayout":"flex-y","subAlign":1,
				children:[
					{
						"hash":"1IVRGVCQF2",
						"type":"image","position":"relative","x":"50%","y":0,"w":50,"h":50,"anchorX":1,"uiEvent":-1,"alpha":0.7,"minW":"","minH":"","maxW":"","maxH":"",
						"styleClass":"","image":$P(()=>(state.icon),state),"fitSize":true,
					}
				],
			},
			{
				"hash":"1IVRGVCQG20",
				"type":"hud","position":"relative","x":0,"y":0,"w":100,"h":"","margin":[0,0,0,5],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","flex":true,
				"contentLayout":"flex-y",
				children:[
					{
						"hash":"1IVRGVCQH0",
						"type":"text","position":"relative","x":0,"y":0,"w":"100%","h":"","uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodySub"],
						"text":$P(()=>(state.label),state),"fontSize":txtSize.mid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","ellipsis":true,
					},
					{
						"hash":"1IVRGVCQH13",
						"type":"text","position":"relative","x":0,"y":0,"w":"100%","h":30,"uiEvent":-1,"margin":[3,0,3,0],"padding":[3,0,3,0],"minW":"","minH":"","maxW":"",
						"maxH":"","styleClass":"","color":cfgColor["fontBody"],"text":$P(()=>(state.desc),state),"fontSize":txtSize.smallPlus-1,"fontWeight":"normal","fontStyle":"normal",
						"textDecoration":"","alignV":1,"wrap":true,"ellipsis":true,"lineClamp":2,"flex":true,
					},
					{
						"hash":"1IVRGVCQH26",
						"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":24,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
						"itemsAlign":1,
						children:[
							{
								"hash":"1IVRGVCQI0",
								"type":"box","position":"relative","x":0,"y":0,"w":20,"h":20,"uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["fontBodySub"],
								"maskImage":appCfg.sharedAssets+"/recent.svg",
							},
							{
								"hash":"1IVRGVCQI11",
								"type":"text","id":"TxtTime","position":"relative","x":0,"y":0,"w":"","h":"","uiEvent":-1,"margin":[0,0,0,4],"minW":"","minH":"","maxW":"","maxH":"",
								"styleClass":"","color":cfgColor["secondary"],"text":$P(()=>(state.date),state),"fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal",
								"textDecoration":"","flex":true,
							},
							{
								"hash":"1IVRGVCQJ4",
								"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/trash.svg",null),"id":"BtnRemove","position":"relative","x":0,"y":0,"display":0,
							},
							{
								"hash":"1IVRGVCQJ19",
								"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/download.svg",null),"id":"BtnDownload","position":"relative","x":0,"y":0,"display":0,
								"OnClick":function(event){
									/*#{1IVS154H80FunctionBody*/
									self.downloadApp();
									/*}#1IVS154H80FunctionBody*/
								},
							},
							{
								"hash":"1IVRGVCQJ34",
								"type":"box","id":"BoxCheck","position":"relative","x":0,"y":0,"w":24,"h":24,"display":0,"uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"",
								"styleClass":"","background":cfgColor["success"],"maskImage":appCfg.sharedAssets+"/check.svg",
							},
							{
								"hash":"1IVRGVCQK11",
								"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/update.svg",null),"id":"BtnUpdate","position":"relative","x":0,"y":0,"display":0,
								"OnClick":function(event){
									/*#{1IVS18CHN0FunctionBody*/
									self.downloadApp();
									/*}#1IVS18CHN0FunctionBody*/
								},
							}
						],
					}
				],
			},
			{
				"hash":"1IVRGVCQK44",
				"type":"box","id":"BoxMenu","x":">calc(100% - 33px)","y":3,"w":30,"h":30,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":[255,255,255,1],
				"border":2,"corner":6,"attached":false,
				children:[
					{
						"hash":"1IVRGVCQK46",
						"type":BtnIcon("front",28,0,appCfg.sharedAssets+"/menu.svg",null),"x":"50%","y":"50%","anchorX":1,"anchorY":1,
						"OnClick":function(event){
							/*#{1IVRGVCQL8FunctionBody*/
							/*}#1IVRGVCQL8FunctionBody*/
						},
					}
				],
			}
		],
		/*#{1IVRGR7T81ExtraCSS*/
		/*}#1IVRGR7T81ExtraCSS*/
		faces:{
			"up":{
				/*BoxBG*/"#1IVRGSANU0":{
					"border":1,"w":"100%","h":"100%"
				},
				"#1IVRGVCQF2":{
					"w":50,"h":50,"alpha":0.7
				},
				"#1IVRGVCQH0":{
					"color":cfgColor["fontBodySub"]
				}
			},"over":{
				/*BoxBG*/"#1IVRGSANU0":{
					"border":2,"w":"100%","h":"100%"
				},
				"#1IVRGVCQF2":{
					"w":54,"h":54,"alpha":1
				},
				"#1IVRGVCQH0":{
					"color":cfgColor["fontBody"]
				}
			},"down":{
				/*BoxBG*/"#1IVRGSANU0":{
					"w":"100%","h":"100%"
				},
				"#1IVRGVCQF2":{
					"w":50,"h":50,"alpha":1
				},
				"#1IVRGVCQH0":{
					"color":cfgColor["fontBody"]
				}
			},"install":{
				/*BtnRemove*/"#1IVRGVCQJ4":{
					"display":0
				},
				/*BtnDownload*/"#1IVRGVCQJ19":{
					"display":1
				},
				/*BoxCheck*/"#1IVRGVCQJ34":{
					"display":0
				},
				/*BtnUpdate*/"#1IVRGVCQK11":{
					"display":0
				}
			},"update":{
				/*BtnRemove*/"#1IVRGVCQJ4":{
					"display":0
				},
				/*BtnDownload*/"#1IVRGVCQJ19":{
					"display":0
				},
				/*BoxCheck*/"#1IVRGVCQJ34":{
					"display":0
				},
				/*BtnUpdate*/"#1IVRGVCQK11":{
					"display":1
				}
			},"check":{
				/*BtnRemove*/"#1IVRGVCQJ4":{
					"display":0
				},
				/*BtnDownload*/"#1IVRGVCQJ19":{
					"display":0
				},
				/*BoxCheck*/"#1IVRGVCQJ34":{
					"display":1
				},
				/*BtnUpdate*/"#1IVRGVCQK11":{
					"display":0
				}
			}
		},
		OnCreate:function(){
			self=this;
			txtTime=self.TxtTime;btnDownload=self.BtnDownload;boxCheck=self.BoxCheck;btnUpdate=self.BtnUpdate;
			/*#{1IVRGR7T81Create*/
			self.loadInfo();
			self.aniShow();
			/*}#1IVRGR7T81Create*/
		},
		/*#{1IVRGR7T81EndCSS*/
		/*}#1IVRGR7T81EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.OnClick=function(event){
		/*#{1IVS29H8B0FunctionBody*/
		switch(action){
			case "Install":{
				self.downloadApp();
				break;
			}
			case "Start":{
				self.execShortcut();
			}
		}
		/*}#1IVS29H8B0FunctionBody*/
	};
	//------------------------------------------------------------------------
	cssVO.aniShow=async function(){
		/*#{1IVRHI09K0Start*/
		self.animate({type:"in",scale:0.8,alpha:0.5,time:50+Math.floor(Math.random()*5)*50});
		/*}#1IVRHI09K0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.loadInfo=async function(){
		/*#{1IVRHII5C0Start*/
		let res,info,name,desc;
		if(typeof(tool)==="string"){
			res=await tabNT.makeCall("GetAppInfo",{appId:tool});
			if(!res || res.code!==200){
				state.description=(($ln==="CN")?("获取信息失败。"):/*EN*/("Get info failed."));
				return;
			}
			appStub=info=res.info;
		}else{
			appStub=info=tool;
		}
		desc=info.desc;
		state.desc=desc[$ln]||desc["EN"]||desc;
		name=info.name;
		name=name[$ln]||name["EN"]||name;
		state.label=name;
		state.date=new Intl.DateTimeFormat('en-CA').format(new Date(info.updateTime));
		state.icon=info.icon;
		
		//Check if local installed, or need upgrade?
		let localInfo=await getLocalAppInfo(info.appId);
		if(!localInfo){
			self.showFace("install");
			action="Install";
		}else{
			let keyAgent;
			if(localInfo.appVersionIdx<info.versionIdx){
				self.showFace("update");
				action="Start";
			}else{
				self.showFace("check");
				action="Start";
			}
			keyAgent=localInfo.toolExport[0];
			if(keyAgent){
				self.agentInfo=localInfo.toolExport[0];
				self.agentPath=pathLib.join("/~"+localInfo.path,keyAgent.filePath);
			}
		}
		/*}#1IVRHII5C0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.downloadApp=async function(){
		/*#{1IVS1DHAH0Start*/
		let callAgent;
		if(appStub){
			callAgent=(await import("/@AgentBuilder/ai/RunAgent.js")).callAgent;
			await callAgent({agent:"/@AgentBuilder/ai/SysInstallApp.js",args:{appStub:appStub},title:(($ln==="CN")?("安装智能体/应用"):/*EN*/("Installing agent/application"))});
			self.loadInfo();
		}		
		/*}#1IVS1DHAH0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.startApp=async function(){
		/*#{1IVS1LRMJ0Start*/
		
		/*}#1IVS1LRMJ0Start*/
	};
	/*#{1IVRGR7T81PostCSSVO*/
	/*}#1IVRGR7T81PostCSSVO*/
	cssVO.constructor=BtnShortcut;
	return cssVO;
};
/*#{1IVRGR7T81ExCodes*/
/*}#1IVRGR7T81ExCodes*/

//----------------------------------------------------------------------------
BtnShortcut.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1IVRGR7T81PreAISpot*/
	/*}#1IVRGR7T81PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1IVRGR7T81PostAISpot*/
	/*}#1IVRGR7T81PostAISpot*/
	return exposeVO;
};

/*#{1IVRGR7T80EndDoc*/
/*}#1IVRGR7T80EndDoc*/

export default BtnShortcut;
export{BtnShortcut};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearButton",
//	"jaxId": "1IVRGR7T80",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1IVRGR7T82",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1IVRGR7T83",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1IVRGR7T84",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1IVRGR7T85",
//			"attrs": {
//				"tool": {
//					"type": "auto",
//					"valText": "\"Deepthink\""
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1IVRGR7T86",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1IVRGR7T87",
//			"attrs": {
//				"icon": {
//					"type": "string",
//					"valText": "#appCfg.sharedAssets+\"/agent.svg\""
//				},
//				"label": {
//					"type": "string",
//					"valText": "#tool.appId||tool"
//				},
//				"desc": {
//					"type": "string",
//					"valText": "Think think"
//				},
//				"date": {
//					"type": "string",
//					"valText": "---- / -- / --"
//				}
//			}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IVRHI09K0",
//					"attrs": {
//						"id": "aniShow",
//						"label": "New AI Seg",
//						"x": "70",
//						"y": "70",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IVRHILBV0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IVRHILBV1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IVRHILBV2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IVRHII5C0",
//					"attrs": {
//						"id": "loadInfo",
//						"label": "New AI Seg",
//						"x": "70",
//						"y": "165",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IVRHILBV3",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IVRHILBV4",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IVRHILBV5",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IVS1DHAH0",
//					"attrs": {
//						"id": "downloadApp",
//						"label": "New AI Seg",
//						"x": "70",
//						"y": "260",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IVS1E1S30",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IVS1E1S31",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IVS1E1S32",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IVS1LRMJ0",
//					"attrs": {
//						"id": "startApp",
//						"label": "New AI Seg",
//						"x": "310",
//						"y": "260",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IVS1M5AH0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IVS1M5AH1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IVS1M5AH2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				}
//			]
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1IVRGR7T88",
//			"attrs": {
//				"up": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IVRGTBJ80",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IVRGTMJQ0",
//							"attrs": {}
//						}
//					}
//				},
//				"over": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IVRGTL9S0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IVRGTMJQ2",
//							"attrs": {}
//						}
//					}
//				},
//				"down": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IVRGTF630",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IVRGTMJQ1",
//							"attrs": {}
//						}
//					}
//				},
//				"install": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IVRJEC850",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IVRJEVVT0",
//							"attrs": {}
//						}
//					}
//				},
//				"update": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IVRJEKIV0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IVRJEVVT1",
//							"attrs": {}
//						}
//					}
//				},
//				"check": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IVRJET5H0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IVRJEVVT2",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1IVRGR7T89",
//			"attrs": {}
//		},
//		"exposeToAI": "true",
//		"descAI": "",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "button",
//			"jaxId": "1IVRGR7T81",
//			"attrs": {
//				"properties": {
//					"jaxId": "1IVRGR7T810",
//					"attrs": {
//						"type": "button",
//						"id": "",
//						"position": "Relative",
//						"x": "125",
//						"y": "50",
//						"w": "250",
//						"h": "100",
//						"anchorH": "Center",
//						"anchorV": "Center",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "pointer",
//						"zIndex": "0",
//						"margin": "10",
//						"padding": "[10,10,5,10]",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"enable": "true",
//						"drag": "NA",
//						"contentLayout": "Flex X"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1IVRGSANU0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IVRGSNAV0",
//									"attrs": {
//										"type": "box",
//										"id": "BoxBG",
//										"position": "Absolute",
//										"x": "50%",
//										"y": "50%",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Center",
//										"anchorV": "Center",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "[255,255,255,1.00]",
//										"border": "1",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "12",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1IVRGSNAV1",
//									"attrs": {
//										"1IVRGTBJ80": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IVRHDM0K0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IVRHDM0L0",
//													"attrs": {
//														"border": {
//															"type": "auto",
//															"valText": "1",
//															"editMode": "edges"
//														},
//														"w": "100%",
//														"h": "100%"
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IVRGTBJ80",
//											"faceTagName": "up"
//										},
//										"1IVRGTL9S0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IVRHDM0L1",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IVRHDM0L2",
//													"attrs": {
//														"border": {
//															"type": "auto",
//															"valText": "2",
//															"editMode": "edges"
//														},
//														"w": "100%",
//														"h": "100%"
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IVRGTL9S0",
//											"faceTagName": "over"
//										},
//										"1IVRGTF630": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IVRHDM0L3",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IVRHDM0L4",
//													"attrs": {
//														"w": "100%",
//														"h": "100%"
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IVRGTF630",
//											"faceTagName": "down"
//										},
//										"1IVRJEC850": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IVRJHDL50",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IVRJHDL51",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IVRJEC850",
//											"faceTagName": "install"
//										},
//										"1IVRJEKIV0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IVRJHDL52",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IVRJHDL53",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IVRJEKIV0",
//											"faceTagName": "update"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1IVRGSNAV2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IVRGSNAV3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1IVRGVCQF0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IVRGVCQF1",
//									"attrs": {
//										"type": "hud",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "50",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "[0,0,20,0]",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex Y",
//										"subAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "image",
//											"jaxId": "1IVRGVCQF2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IVRGVCQF3",
//													"attrs": {
//														"type": "image",
//														"id": "",
//														"position": "relative",
//														"x": "50%",
//														"y": "0",
//														"w": "50",
//														"h": "50",
//														"anchorH": "Center",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "Tree Off",
//														"alpha": "0.7",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"image": "${state.icon},state",
//														"autoSize": "false",
//														"fitSize": "Fit",
//														"repeat": "true",
//														"alignX": "Left",
//														"alignY": "Top"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IVRGVCQG0",
//													"attrs": {
//														"1IVRGTBJ80": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVRHDM0L5",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVRHDM0L6",
//																	"attrs": {
//																		"w": {
//																			"type": "length",
//																			"valText": "50"
//																		},
//																		"h": {
//																			"type": "length",
//																			"valText": "50"
//																		},
//																		"alpha": {
//																			"type": "number",
//																			"valText": "0.7",
//																			"editMode": "range",
//																			"editType": "range"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IVRGTBJ80",
//															"faceTagName": "up"
//														},
//														"1IVRGTL9S0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVRHDM0L7",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVRHDM0L8",
//																	"attrs": {
//																		"w": {
//																			"type": "length",
//																			"valText": "54"
//																		},
//																		"h": {
//																			"type": "length",
//																			"valText": "54"
//																		},
//																		"alpha": {
//																			"type": "number",
//																			"valText": "1.00",
//																			"editMode": "range",
//																			"editType": "range"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IVRGTL9S0",
//															"faceTagName": "over"
//														},
//														"1IVRGTF630": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVRHDM0L9",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVRHDM0L10",
//																	"attrs": {
//																		"w": {
//																			"type": "length",
//																			"valText": "50"
//																		},
//																		"h": {
//																			"type": "length",
//																			"valText": "50"
//																		},
//																		"alpha": {
//																			"type": "number",
//																			"valText": "1.00",
//																			"editMode": "range",
//																			"editType": "range"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IVRGTF630",
//															"faceTagName": "down"
//														},
//														"1IVRJEC850": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVRJHDL56",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVRJHDL57",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IVRJEC850",
//															"faceTagName": "install"
//														},
//														"1IVRJEKIV0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVRJHDL58",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVRJHDL59",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IVRJEKIV0",
//															"faceTagName": "update"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IVRGVCQG9",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IVRGVCQG10",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1IVRGVCQG11",
//									"attrs": {
//										"1IVRGTF630": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IVRHDM0L13",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IVRHDM0L14",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IVRGTF630",
//											"faceTagName": "down"
//										},
//										"1IVRJEC850": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IVRJHDL512",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IVRJHDL513",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IVRJEC850",
//											"faceTagName": "install"
//										},
//										"1IVRJEKIV0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IVRJHDL514",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IVRJHDL515",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IVRJEKIV0",
//											"faceTagName": "update"
//										},
//										"1IVRGTBJ80": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IVU0RNF60",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IVU0RNF61",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IVRGTBJ80",
//											"faceTagName": "up"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1IVRGVCQG18",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IVRGVCQG19",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1IVRGVCQG20",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IVRGVCQG21",
//									"attrs": {
//										"type": "hud",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,5]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"flex": "true",
//										"contentLayout": "Flex Y",
//										"subAlign": "Start"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1IVRGVCQH0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IVRGVCQH1",
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "Tree Off",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBodySub\"]",
//														"text": "${state.label},state",
//														"font": "",
//														"fontSize": "#txtSize.mid",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "true",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IVRGVCQH2",
//													"attrs": {
//														"1IVRGTL9S0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVRHDM0L15",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVRHDM0L16",
//																	"attrs": {
//																		"color": {
//																			"type": "colorRGB",
//																			"valText": "#cfgColor[\"fontBody\"]"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IVRGTL9S0",
//															"faceTagName": "over"
//														},
//														"1IVRGTF630": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVRHDM0L17",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVRHDM0L18",
//																	"attrs": {
//																		"color": {
//																			"type": "colorRGB",
//																			"valText": "#cfgColor[\"fontBody\"]"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IVRGTF630",
//															"faceTagName": "down"
//														},
//														"1IVRGTBJ80": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVRHILBV6",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVRHILBV7",
//																	"attrs": {
//																		"color": {
//																			"type": "colorRGB",
//																			"valText": "#cfgColor[\"fontBodySub\"]"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IVRGTBJ80",
//															"faceTagName": "up"
//														},
//														"1IVRJEC850": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVRJHDL518",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVRJHDL519",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IVRJEC850",
//															"faceTagName": "install"
//														},
//														"1IVRJEKIV0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVRJHDL520",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVRJHDL521",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IVRJEKIV0",
//															"faceTagName": "update"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IVRGVCQH11",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IVRGVCQH12",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1IVRGVCQH13",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IVRGVCQH14",
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "30",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "Tree Off",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[3,0,3,0]",
//														"padding": "[3,0,3,0]",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBody\"]",
//														"text": "${state.desc},state",
//														"font": "",
//														"fontSize": "#txtSize.smallPlus-1",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Center",
//														"wrap": "true",
//														"ellipsis": "true",
//														"lineClamp": "2",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0",
//														"flex": "true"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IVRGVCQH15",
//													"attrs": {
//														"1IVRGTF630": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVRHDM0L21",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVRHDM0L22",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IVRGTF630",
//															"faceTagName": "down"
//														},
//														"1IVRJEC850": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVRJHDL524",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVRJHDL525",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IVRJEC850",
//															"faceTagName": "install"
//														},
//														"1IVRJEKIV0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVRJHDL526",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVRJHDL527",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IVRJEKIV0",
//															"faceTagName": "update"
//														},
//														"1IVRGTBJ80": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVU0RNF62",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVU0RNF63",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IVRGTBJ80",
//															"faceTagName": "up"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IVRGVCQH24",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IVRGVCQH25",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1IVRGVCQH26",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IVRGVCQH27",
//													"attrs": {
//														"type": "hud",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "24",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex X",
//														"subAlign": "Start",
//														"itemsAlign": "Center"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "box",
//															"jaxId": "1IVRGVCQI0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVRGVCQI1",
//																	"attrs": {
//																		"type": "box",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "20",
//																		"h": "20",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "Tree Off",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"background": "#cfgColor[\"fontBodySub\"]",
//																		"border": "0",
//																		"borderStyle": "Solid",
//																		"borderColor": "[0,0,0,1.00]",
//																		"corner": "0",
//																		"shadow": "false",
//																		"shadowX": "2",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowSpread": "0",
//																		"shadowColor": "[0,0,0,0.50]",
//																		"maskImage": "#appCfg.sharedAssets+\"/recent.svg\""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IVRGVCQI2",
//																	"attrs": {
//																		"1IVRGTF630": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVRHDM0L25",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVRHDM0L26",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IVRGTF630",
//																			"faceTagName": "down"
//																		},
//																		"1IVRJEC850": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVRJHDL530",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVRJHDL531",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IVRJEC850",
//																			"faceTagName": "install"
//																		},
//																		"1IVRJEKIV0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVRJHDL532",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVRJHDL533",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IVRJEKIV0",
//																			"faceTagName": "update"
//																		},
//																		"1IVRGTBJ80": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVU0RNF64",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVU0RNF65",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IVRGTBJ80",
//																			"faceTagName": "up"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1IVRGVCQI9",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1IVRGVCQI10",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1IVRGVCQI11",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVRGVCQI12",
//																	"attrs": {
//																		"type": "text",
//																		"id": "TxtTime",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "Tree Off",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[0,0,0,4]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"secondary\"]",
//																		"text": "${state.date},state",
//																		"font": "",
//																		"fontSize": "#txtSize.small",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Top",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"lineClamp": "0",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0",
//																		"flex": "true"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IVRGVCQI13",
//																	"attrs": {
//																		"1IVRGTF630": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVRHDM0L29",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVRHDM0L30",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IVRGTF630",
//																			"faceTagName": "down"
//																		},
//																		"1IVRJEC850": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVRJHDL536",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVRJHDL537",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IVRJEC850",
//																			"faceTagName": "install"
//																		},
//																		"1IVRJEKIV0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVRJHDL538",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVRJHDL539",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IVRJEKIV0",
//																			"faceTagName": "update"
//																		},
//																		"1IVRGTBJ80": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVU0RNF66",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVU0RNF67",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IVRGTBJ80",
//																			"faceTagName": "up"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1IVRGVCQJ2",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1IVRGVCQJ3",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1IVRGVCQJ4",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1IVRGVCQJ5",
//																	"attrs": {
//																		"style": "\"front\"",
//																		"w": "24",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/trash.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1IVRGVCQJ6",
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"front\",24,0,appCfg.sharedAssets+\"/trash.svg\",null)",
//																		"id": "BtnRemove",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "Off",
//																		"face": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IVRGVCQJ7",
//																	"attrs": {
//																		"1IVRGTF630": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVRHDM0L33",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVRHDM0L34",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IVRGTF630",
//																			"faceTagName": "down"
//																		},
//																		"1IVRJEC850": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVRJHDL542",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVRJHDL543",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IVRJEC850",
//																			"faceTagName": "install"
//																		},
//																		"1IVRJEKIV0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVRJHDL544",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVRJHDL545",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IVRJEKIV0",
//																			"faceTagName": "update"
//																		},
//																		"1IVRJET5H0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVRJHDL546",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVRJHDL547",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IVRJET5H0",
//																			"faceTagName": "check"
//																		},
//																		"1IVRGTBJ80": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVU0RNF68",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVU0RNF69",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IVRGTBJ80",
//																			"faceTagName": "up"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1IVRGVCQJ16",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1IVRGVCQJ17",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1IVRGVCQJ18",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1IVRGVCQJ19",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1IVRGVCQJ20",
//																	"attrs": {
//																		"style": "\"front\"",
//																		"w": "24",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/download.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1IVRGVCQJ21",
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"front\",24,0,appCfg.sharedAssets+\"/download.svg\",null)",
//																		"id": "BtnDownload",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "Off",
//																		"face": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IVRGVCQJ22",
//																	"attrs": {
//																		"1IVRGTF630": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVRHDM0L37",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVRHDM0L38",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IVRGTF630",
//																			"faceTagName": "down"
//																		},
//																		"1IVRJEC850": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVRJHDL548",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVRJHDL549",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IVRJEC850",
//																			"faceTagName": "install"
//																		},
//																		"1IVRJEKIV0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVRJHDL550",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVRJHDL551",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IVRJEKIV0",
//																			"faceTagName": "update"
//																		},
//																		"1IVRJET5H0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVRJHDL552",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVRJHDL553",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IVRJET5H0",
//																			"faceTagName": "check"
//																		},
//																		"1IVRGTBJ80": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVU0RNF610",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVU0RNF611",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IVRGTBJ80",
//																			"faceTagName": "up"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1IVRGVCQJ31",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1IVS154H80",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1IVS15L6D0",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1IVRGVCQJ32",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1IVRGVCQJ33",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "box",
//															"jaxId": "1IVRGVCQJ34",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVRGVCQJ35",
//																	"attrs": {
//																		"type": "box",
//																		"id": "BoxCheck",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "24",
//																		"h": "24",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "Off",
//																		"clip": "Off",
//																		"uiEvent": "Tree Off",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"background": "#cfgColor[\"success\"]",
//																		"border": "0",
//																		"borderStyle": "Solid",
//																		"borderColor": "[0,0,0,1.00]",
//																		"corner": "0",
//																		"shadow": "false",
//																		"shadowX": "2",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowSpread": "0",
//																		"shadowColor": "[0,0,0,0.50]",
//																		"maskImage": "#appCfg.sharedAssets+\"/check.svg\""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IVRGVCQK0",
//																	"attrs": {
//																		"1IVRGTF630": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVRHDM0L41",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVRHDM0L42",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IVRGTF630",
//																			"faceTagName": "down"
//																		},
//																		"1IVRJEC850": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVRJHDL554",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVRJHDL555",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IVRJEC850",
//																			"faceTagName": "install"
//																		},
//																		"1IVRJEKIV0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVRJHDL556",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVRJHDL557",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IVRJEKIV0",
//																			"faceTagName": "update"
//																		},
//																		"1IVRJET5H0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVRJHDL558",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVRJHDL559",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IVRJET5H0",
//																			"faceTagName": "check"
//																		},
//																		"1IVRGTBJ80": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVU0RNF612",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVU0RNF613",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IVRGTBJ80",
//																			"faceTagName": "up"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1IVRGVCQK9",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1IVRGVCQK10",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "true"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1IVRGVCQK11",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1IVRGVCQK12",
//																	"attrs": {
//																		"style": "\"front\"",
//																		"w": "24",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/update.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1IVRGVCQK13",
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"front\",24,0,appCfg.sharedAssets+\"/update.svg\",null)",
//																		"id": "BtnUpdate",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "Off",
//																		"face": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IVRGVCQK14",
//																	"attrs": {
//																		"1IVRGTF630": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVRHDM0L45",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVRHDM0L46",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IVRGTF630",
//																			"faceTagName": "down"
//																		},
//																		"1IVRJEC850": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVRJHDL560",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVRJHDL561",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IVRJEC850",
//																			"faceTagName": "install"
//																		},
//																		"1IVRJEKIV0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVRJHDL562",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVRJHDL563",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IVRJEKIV0",
//																			"faceTagName": "update"
//																		},
//																		"1IVRJET5H0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVRJHDL564",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVRJHDL565",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IVRJET5H0",
//																			"faceTagName": "check"
//																		},
//																		"1IVRGTBJ80": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IVU0RNF614",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IVU0RNF615",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IVRGTBJ80",
//																			"faceTagName": "up"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1IVRGVCQK23",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1IVS18CHN0",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1IVS18H450",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1IVRGVCQK24",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1IVRGVCQK25",
//																	"attrs": {}
//																}
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1IVRGVCQK26",
//													"attrs": {
//														"1IVRGTF630": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVRHDM0L49",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVRHDM0L50",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IVRGTF630",
//															"faceTagName": "down"
//														},
//														"1IVRJEC850": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVRJHDL566",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVRJHDL567",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IVRJEC850",
//															"faceTagName": "install"
//														},
//														"1IVRJEKIV0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVRJHDL568",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVRJHDL569",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IVRJEKIV0",
//															"faceTagName": "update"
//														},
//														"1IVRGTBJ80": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVU0RNF616",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVU0RNF617",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IVRGTBJ80",
//															"faceTagName": "up"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IVRGVCQK33",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IVRGVCQK34",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1IVRGVCQK35",
//									"attrs": {
//										"1IVRGTF630": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IVRHDM0L53",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IVRHDM0L54",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IVRGTF630",
//											"faceTagName": "down"
//										},
//										"1IVRJEC850": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IVRJHDL572",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IVRJHDL573",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IVRJEC850",
//											"faceTagName": "install"
//										},
//										"1IVRJEKIV0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IVRJHDL574",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IVRJHDL575",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IVRJEKIV0",
//											"faceTagName": "update"
//										},
//										"1IVRGTBJ80": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IVU0RNF618",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IVU0RNF619",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IVRGTBJ80",
//											"faceTagName": "up"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1IVRGVCQK42",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IVRGVCQK43",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1IVRGVCQK44",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IVRGVCQK45",
//									"attrs": {
//										"type": "box",
//										"id": "BoxMenu",
//										"position": "Absolute",
//										"x": "100%-33",
//										"y": "3",
//										"w": "30",
//										"h": "30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "[255,255,255,1.00]",
//										"border": "2",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "6",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"attach": "false"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1IVRGVCQK46",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1IVRGVCQK47",
//													"attrs": {
//														"style": "\"front\"",
//														"w": "28",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/menu.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1IVRGVCQK48",
//													"attrs": {
//														"type": "#null#>BtnIcon(\"front\",28,0,appCfg.sharedAssets+\"/menu.svg\",null)",
//														"id": "",
//														"position": "Absolute",
//														"x": "50%",
//														"y": "50%",
//														"display": "On",
//														"face": "",
//														"anchorH": "Center",
//														"anchorV": "Center"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IVRGVCQL0",
//													"attrs": {
//														"1IVRGTF630": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVRHDM0L57",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVRHDM0L58",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IVRGTF630",
//															"faceTagName": "down"
//														},
//														"1IVRJEC850": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVRJHDL578",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVRJHDL579",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IVRJEC850",
//															"faceTagName": "install"
//														},
//														"1IVRJEKIV0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVRJHDL580",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVRJHDL581",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IVRJEKIV0",
//															"faceTagName": "update"
//														},
//														"1IVRGTBJ80": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IVU0RNF620",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IVU0RNF621",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IVRGTBJ80",
//															"faceTagName": "up"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IVRGVCQL7",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1IVRGVCQL8",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1IVRGVCQL9",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1IVRGVCQL10",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1IVRGVCQL11",
//													"attrs": {}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1IVRGVCQL12",
//									"attrs": {
//										"1IVRGTF630": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IVRHDM0L61",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IVRHDM0L62",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IVRGTF630",
//											"faceTagName": "down"
//										},
//										"1IVRJEC850": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IVRJHDL60",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IVRJHDL61",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IVRJEC850",
//											"faceTagName": "install"
//										},
//										"1IVRJEKIV0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IVRJHDL62",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IVRJHDL63",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IVRJEKIV0",
//											"faceTagName": "update"
//										},
//										"1IVRGTBJ80": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IVU0RNF622",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IVU0RNF623",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IVRGTBJ80",
//											"faceTagName": "up"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1IVRGVCQL21",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IVRGVCQL22",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1IVRGR7T811",
//					"attrs": {
//						"1IVRGTF630": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1IVRHDM0L65",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IVRHDM0L66",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1IVRGTF630",
//							"faceTagName": "down"
//						},
//						"1IVRJEC850": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1IVRJHDL66",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IVRJHDL67",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1IVRJEC850",
//							"faceTagName": "install"
//						},
//						"1IVRJEKIV0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1IVRJHDL68",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IVRJHDL69",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1IVRJEKIV0",
//							"faceTagName": "update"
//						},
//						"1IVRGTBJ80": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1IVU0RNF624",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IVU0RNF625",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1IVRGTBJ80",
//							"faceTagName": "up"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1IVRGR7T812",
//					"attrs": {
//						"OnClick": {
//							"type": "fixedFunc",
//							"jaxId": "1IVS29H8B0",
//							"attrs": {
//								"callArgs": {
//									"jaxId": "1IVS29TQL0",
//									"attrs": {
//										"event": ""
//									}
//								},
//								"seg": ""
//							}
//						}
//					}
//				},
//				"extraPpts": {
//					"jaxId": "1IVRGR7T813",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1IVRGR7T814",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false",
//				"enable": "false",
//				"drag": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}