//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
import {BtnText} from "/@StdUI/ui/BtnText.js";
/*#{1I2G6JNL40StartDoc*/
import {tabNT} from "/@tabos/tabos_nt.js";
import {BoxAIChat} from "/@aichat/ui/BoxAIChat.js";
import {BoxAIChatBlock} from "/@aichat/ui/BoxAIChatBlock.js";
import {BoxAskUser} from "/@aichat/ui/BoxAskUser.js";
import {BoxAABotMessage} from "./BoxAABotMessage.js";
import {BoxTaskWork} from "./BoxTaskWork.js";
/*}#1I2G6JNL40StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let Botwork=function(botInfo){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let txtTitle,boxMessages,boxTask,boxRoutine;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1I2G6JNL41LocalVals*/
	let aiBoxMessage,aiBoxTask;
	let snMessage,snTask;
	let aiMessage,aiTask;
	let liveWorks=0;
	const MAX_LIVEWORKS=50;
	/*}#1I2G6JNL41LocalVals*/
	
	/*#{1I2G6JNL41PreState*/
	let orgAddChatBlock;
	/*}#1I2G6JNL41PreState*/
	/*#{1I2G6JNL41PostState*/
	/*}#1I2G6JNL41PostState*/
	cssVO={
		"hash":"1I2G6JNL41",nameHost:true,
		"type":"view","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":1600,"maxH":"","styleClass":"","contentLayout":"flex-y",
		children:[
			{
				"hash":"1I559DD3J0",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["body"],
			},
			{
				"hash":"1I2G6KQBH0",
				"type":"hud","id":"BoxHeader","position":"relative","x":0,"y":0,"w":"100%","h":30,"padding":[0,10,0,10],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"contentLayout":"flex-x","itemsAlign":1,
				children:[
					{
						"hash":"1I55980QO0",
						"type":"text","id":"TxtTitle","position":"relative","x":0,"y":0,"w":"","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":[0,0,0],
						"text":"Bot: Master","fontSize":txtSize.midPlus,"fontWeight":"bold","fontStyle":"normal","textDecoration":"","alignV":1,
					}
				],
			},
			{
				"hash":"1I2G6MAIK0",
				"type":"hud","id":"BoxFrame","position":"relative","x":0,"y":0,"w":"100%","h":">calc(100% - 30px)","padding":[0,0,0,10],"minW":"","minH":"","maxW":"",
				"maxH":"","styleClass":"","contentLayout":"flex-x",
				children:[
					{
						"hash":"1I2G6QDJA0",
						"type":"hud","id":"BoxMessages","position":"relative","x":0,"y":0,"w":">calc(50% - 100px)","h":"100%","padding":[0,5,5,5],"minW":"","minH":"","maxW":600,
						"maxH":"","styleClass":"",
						children:[
							{
								"hash":"1I559AAV60",
								"type":"box","id":"FrameMessages","position":"relative","x":0,"y":0,"w":"100%","h":"100%","padding":5,"minW":"","minH":"","maxW":"","maxH":"",
								"styleClass":"","background":[...cfgColor["body"],0],"border":1,"borderColor":cfgColor["fontBodyLit"],"corner":10,"contentLayout":"flex-y",
								children:[
									{
										"hash":"1I79CAM1Q0",
										"type":"hud","id":"BoxMsgHeader","position":"relative","x":0,"y":0,"w":"100%","h":25,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
										"contentLayout":"flex-x","itemsAlign":1,
										children:[
											{
												"hash":"1I79CE0G90",
												"type":"box","id":"Icon","position":"relative","x":0,"y":0,"w":25,"h":25,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["fontBodySub"],
												"border":1,"maskImage":appCfg.sharedAssets+"/mail.svg",
											},
											{
												"hash":"1I79CB7NJ0",
												"type":"text","position":"relative","x":0,"y":0,"w":"","h":"100%","padding":0,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":[0,0,0],
												"text":"Messages:","fontSize":txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,"flex":true,
											},
											{
												"hash":"1I79CDEPG0",
												"type":BtnIcon("front",25,0,appCfg.sharedAssets+"/trash.svg",null),"id":"BtnClear","position":"relative","x":0,"y":0,
												"OnClick":function(event){
													self.clearMessages(this,event);
												},
											}
										],
									},
									{
										"hash":"1I568596C0",
										"type":"box","position":"relative","x":0,"y":0,"w":"100%","h":1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["fontBodySub"],
									},
									{
										"hash":"1I5684KO20",
										"type":"hud","id":"BoxMessages","position":"relative","x":0,"y":0,"w":"100%","h":">calc(100% - 25px)","overflow":"auto-y","minW":"","minH":"",
										"maxW":"","maxH":"","styleClass":"",
									}
								],
							}
						],
					},
					{
						"hash":"1I56878PI0",
						"type":"hud","id":"BoxTask","position":"relative","x":0,"y":0,"w":">calc(50% - 100px)","h":"100%","padding":[0,5,5,5],"minW":"","minH":"","maxW":600,
						"maxH":"","styleClass":"",
						children:[
							{
								"hash":"1I56878PJ0",
								"type":"box","id":"FrameTasks","position":"relative","x":0,"y":0,"w":"100%","h":">calc(50% - 5px)","margin":[0,0,5,0],"padding":5,"minW":"","minH":"",
								"maxW":"","maxH":"","styleClass":"","background":[...cfgColor["body"],0],"border":1,"borderColor":cfgColor["fontBodyLit"],"corner":10,"contentLayout":"flex-y",
								children:[
									{
										"hash":"1I79CPGEQ0",
										"type":"hud","id":"BoxMsgHeader","position":"relative","x":0,"y":0,"w":"100%","h":25,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
										"contentLayout":"flex-x","itemsAlign":1,
										children:[
											{
												"hash":"1I79CPGER0",
												"type":"box","id":"Icon","position":"relative","x":0,"y":0,"w":25,"h":25,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["fontBodySub"],
												"border":1,"maskImage":appCfg.sharedAssets+"/run.svg",
											},
											{
												"hash":"1I79CPGER5",
												"type":"text","position":"relative","x":0,"y":0,"w":"","h":"100%","padding":0,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":[0,0,0],
												"text":"Handled Tasks","fontSize":txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,"flex":true,
											}
										],
									},
									{
										"hash":"1I56878PK0",
										"type":"box","position":"relative","x":0,"y":0,"w":"100%","h":1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["fontBodySub"],
									},
									{
										"hash":"1I56878PK5",
										"type":"hud","id":"BoxTask","position":"relative","x":0,"y":0,"w":"100%","h":">calc(100% - 30px)","overflow":"auto-y","padding":[5,0,0,0],"minW":"",
										"minH":"","maxW":"","maxH":"","styleClass":"",
									}
								],
							},
							{
								"hash":"1I79EI7AV0",
								"type":"box","id":"FrameRutain","position":"relative","x":0,"y":0,"w":"100%","h":"50%","padding":5,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
								"background":[...cfgColor["body"],0],"border":1,"borderColor":cfgColor["fontBodyLit"],"corner":10,"contentLayout":"flex-y",
								children:[
									{
										"hash":"1I79EI7B00",
										"type":"hud","id":"BoxMsgHeader","position":"relative","x":0,"y":0,"w":"100%","h":25,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
										"contentLayout":"flex-x","itemsAlign":1,
										children:[
											{
												"hash":"1I79EI7B02",
												"type":"box","id":"Icon","position":"relative","x":0,"y":0,"w":25,"h":25,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["fontBodySub"],
												"border":1,"maskImage":appCfg.sharedAssets+"/recent.svg",
											},
											{
												"hash":"1I79EI7B14",
												"type":"text","position":"relative","x":0,"y":0,"w":"","h":"100%","padding":0,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":[0,0,0],
												"text":"Routine Tasks","fontSize":txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,"flex":true,
											},
											{
												"hash":"1I79F03H20",
												"type":BtnIcon("front",25,0,appCfg.sharedAssets+"/inc.svg",null),"id":"BtnAddRoutine","position":"relative","x":0,"y":0,
											}
										],
									},
									{
										"hash":"1I79EI7B116",
										"type":"box","position":"relative","x":0,"y":0,"w":"100%","h":1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["fontBodySub"],
									},
									{
										"hash":"1I79EI7B20",
										"type":"hud","id":"BoxRoutine","position":"relative","x":0,"y":0,"w":"100%","h":">calc(100% - 30px)","overflow":"auto-y","minW":"","minH":"",
										"maxW":"","maxH":"","styleClass":"",
									}
								],
							}
						],
					},
					{
						"hash":"1I2G6NBMK0",
						"type":"hud","id":"BoxState","position":"relative","x":0,"y":0,"w":200,"h":"100%","padding":[5,5,5,5],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						"contentLayout":"flex-y","flex":true,
						children:[
							{
								"hash":"1I79DS1QV0",
								"type":BtnText("primary",120,25,"Pause Bot",false,""),"id":"BtnPauseBot","position":"relative","x":"50%","y":0,"anchorX":1,"margin":[0,0,5,0],
							},
							{
								"hash":"1I79DTF980",
								"type":BtnText("success",100,28,"Resume Bot",false,""),"id":"BtnResumeBot","position":"relative","x":"50%","y":0,"display":0,"anchorX":1,"margin":[0,0,10,0],
							},
							{
								"hash":"1I79DOVCU0",
								"type":BtnText("secondary",120,25,"Stop Bot",false,""),"id":"BtnStopBot","position":"relative","x":"50%","y":0,"anchorX":1,"margin":[0,0,5,0],
							},
							{
								"hash":"1I79DR35O0",
								"type":BtnText("error",120,25,"Kill Bot",false,""),"id":"BtnStopBot","position":"relative","x":"50%","y":0,"anchorX":1,"margin":[0,0,10,0],"enable":false,
							}
						],
					}
				],
			}
		],
		/*#{1I2G6JNL41ExtraCSS*/
		/*}#1I2G6JNL41ExtraCSS*/
		faces:{
			"running":{
				/*BtnPauseBot*/"#1I79DS1QV0":{
					"display":1
				},
				/*BtnResumeBot*/"#1I79DTF980":{
					"display":0
				}
			},"paused":{
				/*BtnPauseBot*/"#1I79DS1QV0":{
					"display":0
				},
				/*BtnResumeBot*/"#1I79DTF980":{
					"display":1
				}
			}
		},
		OnCreate:function(){
			self=this;
			txtTitle=self.TxtTitle;boxMessages=self.BoxMessages;boxTask=self.BoxTask;boxRoutine=self.BoxRoutine;
			/*#{1I2G6JNL41Create*/
			txtTitle.text=`Bot: ${botInfo.name} (${botInfo.id})`;
			self.startMessageLoop();
			/*}#1I2G6JNL41Create*/
		},
		/*#{1I2G6JNL41EndCSS*/
		/*}#1I2G6JNL41EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.startMessageLoop=async function(){
		/*#{1I568RL870Start*/
		let blockDef,opts,session;
		blockDef=BoxAIChatBlock;
		aiBoxMessage=boxMessages.appendNewChild({
			"type":BoxAIChat(),"id":"BoxChats","position":"relative","x":0,"y":0,"w":"100%","h":"",
			maxLines:200,
			addBotMessage(msg){
				let from,icon;
				from=msg.from;
				if(from===botInfo.id){
					from=msg.to;
					icon="fat_up.svg";
				}else{
					icon="fat_down.svg";
				}
				aiBoxMessage.appendChatBlock(null,BoxAABotMessage(msg,from,icon));
			},
			OnSessionInit(session){
				session.addChatText=function(role,msg){
					let agent;
					agent=this.curAgent;
					aiBoxMessage.appendChatBlock(null,BoxAABotMessage(msg,agent.url,"agent.svg"));
				};
				session.globalContext.on("NewTaskWork",(task)=>{
					//TODO: Add task obj:
					console.log("New task work");
					console.log(task);
					liveWorks++;
					boxTask.appendNewChild({
						type:BoxTaskWork(task),
						removeCard(){
							this.father.removeChild(this);
							liveWorks--;
						}
					});
					if(liveWorks>MAX_LIVEWORKS){
						let cards,i,n=liveWorks-MAX_LIVEWORKS;
						let cnt=0;
						let card;
						cards=boxTask.children;
						for(i=0;i<liveWorks && cnt<n;i++){
							card=cards[i];
							if(card && card.work && card.work.state==="FINISH"){
								boxTask.removeChild(card);
								cnt++;
							}
						}
					}
				});
			}
		});
		orgAddChatBlock=aiBoxMessage.appendChatBlock;
		aiBoxMessage.appendChatBlock=function (vo,def){
			if(vo && vo.text && !def){
				let agent;
				agent=this.session.curAgent;
				aiBoxMessage.appendChatBlock(null,BoxAABotMessage(vo.text,agent.url,"agent.svg"));
			}else{
				orgAddChatBlock.call(this,vo,def);
			}
		};
		
		//Config it:
		opts={};
		aiBoxMessage.initBlockDef({
			"user":(session,blockVO)=>{
				return blockDef({
					...opts.user,
					//side:"right",icon:appCfg.sharedAssets+"/user.svg",iconBG:cfgColor.success,iconColor:cfgColor.fontPrimary,bgColor:cfgColor.body,textColor:cfgColor.fontBody,
					text:blockVO.text||blockVO.content,buttons:false,top:blockVO.top,image:blockVO.image,audio:blockVO.audio
				},session);
			},
			"greeting":(session,blockVO)=>{
				return blockDef({
					...opts.ai,
					//side:"left",icon:appCfg.sharedAssets+"/faces.svg",iconBG:cfgColor.warning,iconColor:cfgColor.fontPrimary,bgColor:cfgColor.body,textColor:cfgColor.fontBody,
					text:blockVO.text||blockVO.content,buttons:false,top:blockVO.top,image:blockVO.image,audio:blockVO.audio
				},session);
			},
			"assistant":(session,blockVO)=>{
				return blockDef({
					...opts.ai,
					text:blockVO.text||blockVO.content,buttons:true,top:blockVO.top,render:true,image:blockVO.image,audio:blockVO.audio
				},session);
			},
			"wait":(session,blockVO)=>{
				return blockDef({
					...opts.wait,
					text:blockVO.text||blockVO.content,buttons:false,top:blockVO.top,image:blockVO.image,audio:blockVO.audio
				},session);
			},
			"event":(session,blockVO)=>{
				return blockDef({
					...opts.event,
					text:blockVO.text||blockVO.content,buttons:false,top:blockVO.top,image:blockVO.image,audio:blockVO.audio
				},session);
			},
			"system":(session,blockVO)=>{
				return blockDef({
					...opts.event,
					text:blockVO.text||blockVO.content,buttons:false,top:blockVO.top,image:blockVO.image,audio:blockVO.audio
				},session);
			},
			"error":(session,blockVO)=>{
				return blockDef({
					...opts.error,
					text:blockVO.text||blockVO.content,buttons:false,top:blockVO.top,image:blockVO.image,audio:blockVO.audio
				},session);
			},
		},{
			"input":(session,blockVO)=>{
				return BoxAskUser({
					...opts.ask,
					...blockVO
				},session);
			},
			"confirm":(session,blockVO)=>{
				return BoxAskUser({
					...opts.ask,
					...blockVO
				},session);
			},
			"menu":(session,blockVO)=>{
				return BoxAskUser({
					...opts.ask,
					...blockVO
				},session);
			},
			"block":(session,blockVO)=>{
				//TODO: Support role:
				return BoxAskUser({
					...opts.ask,
					...blockVO
				},session);
			},
			"range":(session,blockVO)=>{
				return null;
			},
			"file":(session,blockVO)=>{
				return null;
			},
			"photo":(session,blockVO)=>{
				return null;
			},
			"chatInput":self.chatInput,
			"cancelChatInput":self.cancelChatInput,
		});
		
		if(!(await tabNT.checkLogin(true,true))){
			aiBoxMessage.appendChatBlock({type:"error",text:(($ln==="CN")?("请先登录Tab-OS以使用与AI相关的API。"):/*EN*/("Please login Tab-OS first to use AI related APIs."))});
		}
		
		//Init session:
		snMessage=session=await aiBoxMessage.initSession("/@aae/ai/BotMessageLoop.js",true,false,{});
		aiMessage=session.entryBot;
		aiBoxMessage.execChat(aiMessage.url,{botId:botInfo.id});
		
		//Start task loop:
		//await self.startTaskLoop();
		/*}#1I568RL870Start*/
	};
	//------------------------------------------------------------------------
	cssVO.startTaskLoop=async function(){
		/*#{1I57AVMNJ0Start*/
		/*}#1I57AVMNJ0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.clearMessages=async function(sender,event){
		/*#{1I7ASR7RV0Start*/
		aiBoxMessage.clear();
		/*}#1I7ASR7RV0Start*/
	};
	/*#{1I2G6JNL41PostCSSVO*/
	/*}#1I2G6JNL41PostCSSVO*/
	return cssVO;
};
/*#{1I2G6JNL41ExCodes*/
/*}#1I2G6JNL41ExCodes*/


/*#{1I2G6JNL40EndDoc*/
/*}#1I2G6JNL40EndDoc*/

export default Botwork;
export{Botwork};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "UIView",
//	"jaxId": "1I2G6JNL40",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1I2G6JNL42",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "900",
//				"screenH": "600",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1I2G6JNL43",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1I2G6JNL44",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1I2G6JNL45",
//			"attrs": {
//				"botInfo": {
//					"type": "auto",
//					"valText": ""
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1I2G6JNL46",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1I2G6JNL47",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I568RL870",
//					"attrs": {
//						"id": "startMessageLoop",
//						"label": "New AI Seg",
//						"x": "55",
//						"y": "65",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I568S5TU0",
//							"attrs": {}
//						},
//						"async": "true",
//						"localVars": {
//							"jaxId": "1I568S5TU1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I568S5TU2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						}
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I57AVMNJ0",
//					"attrs": {
//						"id": "startTaskLoop",
//						"label": "New AI Seg",
//						"x": "55",
//						"y": "160",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I57B0B6E0",
//							"attrs": {}
//						},
//						"async": "true",
//						"localVars": {
//							"jaxId": "1I57B0B6E1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I57B0B6E2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						}
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I7ASR7RV0",
//					"attrs": {
//						"id": "clearMessages",
//						"label": "New AI Seg",
//						"x": "55",
//						"y": "265",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I7AT2F6U0",
//							"attrs": {
//								"sender": "null",
//								"event": ""
//							}
//						},
//						"async": "true",
//						"localVars": {
//							"jaxId": "1I7AT2F6U1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I7AT2F6U2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						}
//					}
//				}
//			]
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1I2G6JNL50",
//			"attrs": {
//				"running": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1I79DVAVT0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1I79E0OCH0",
//							"attrs": {}
//						}
//					}
//				},
//				"paused": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1I79DVGR90",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1I79E0OCH1",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1I2G6JNL51",
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "view",
//			"jaxId": "1I2G6JNL41",
//			"attrs": {
//				"properties": {
//					"jaxId": "1I2G6JNL52",
//					"attrs": {
//						"type": "view",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "100%",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "1600",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"flex": "false",
//						"contentLayout": "Flex Y"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1I559DD3J0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I559KG970",
//									"attrs": {
//										"type": "box",
//										"id": "BoxBG",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"body\"]",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1I559KG971",
//									"attrs": {
//										"1I79DVAVT0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I79E0OCH2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I79E0OCH3",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I79DVAVT0",
//											"faceTagName": "running"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1I559KG972",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1I559KG973",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1I2G6KQBH0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I2G6LR0I0",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxHeader",
//										"position": "Relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "[0,10,0,10]",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex X",
//										"itemsAlign": "Center",
//										"subAlign": "Start"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1I55980QO0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I5598K1R0",
//													"attrs": {
//														"type": "text",
//														"id": "TxtTitle",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "[0,0,0]",
//														"text": "Bot: Master",
//														"font": "",
//														"fontSize": "#txtSize.midPlus",
//														"bold": "true",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Center",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I5598K1R1",
//													"attrs": {
//														"1I79DVAVT0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I79E0OCH6",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I79E0OCH7",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I79DVAVT0",
//															"faceTagName": "running"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I5598K1R2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I5598K1R3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1I2G6LR0I1",
//									"attrs": {
//										"1I79DVAVT0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I79E0OCH10",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I79E0OCH11",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I79DVAVT0",
//											"faceTagName": "running"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1I2G6LR0I2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1I2G6LR0I3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1I2G6MAIK0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I2G6Q0VB0",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxFrame",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%-30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "[0,0,0,10]",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex X"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1I2G6QDJA0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I2G6TJVB0",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxMessages",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "50%-100",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "[0,5,5,5]",
//														"minW": "",
//														"minH": "",
//														"maxW": "600",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"flex": "false"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "box",
//															"jaxId": "1I559AAV60",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I559CHH50",
//																	"attrs": {
//																		"type": "box",
//																		"id": "FrameMessages",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "100%",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "5",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"background": "#[...cfgColor[\"body\"],0]",
//																		"border": "1",
//																		"borderStyle": "Solid",
//																		"borderColor": "#cfgColor[\"fontBodyLit\"]",
//																		"corner": "10",
//																		"shadow": "false",
//																		"shadowX": "2",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowSpread": "0",
//																		"shadowColor": "[0,0,0,0.50]",
//																		"contentLayout": "Flex Y"
//																	}
//																},
//																"subHuds": {
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "hud",
//																			"jaxId": "1I79CAM1Q0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I79CKLKI0",
//																					"attrs": {
//																						"type": "hud",
//																						"id": "BoxMsgHeader",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "100%",
//																						"h": "25",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"contentLayout": "Flex X",
//																						"itemsAlign": "Center"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": [
//																						{
//																							"type": "hudobj",
//																							"def": "box",
//																							"jaxId": "1I79CE0G90",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1I79CKLKI1",
//																									"attrs": {
//																										"type": "box",
//																										"id": "Icon",
//																										"position": "relative",
//																										"x": "0",
//																										"y": "0",
//																										"w": "25",
//																										"h": "25",
//																										"anchorH": "Left",
//																										"anchorV": "Top",
//																										"autoLayout": "false",
//																										"display": "On",
//																										"clip": "Off",
//																										"uiEvent": "On",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "",
//																										"zIndex": "0",
//																										"margin": "",
//																										"padding": "",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": "",
//																										"background": "#cfgColor[\"fontBodySub\"]",
//																										"border": "1",
//																										"borderStyle": "Solid",
//																										"borderColor": "[0,0,0,1.00]",
//																										"corner": "0",
//																										"shadow": "false",
//																										"shadowX": "2",
//																										"shadowY": "2",
//																										"shadowBlur": "3",
//																										"shadowSpread": "0",
//																										"shadowColor": "[0,0,0,0.50]",
//																										"maskImage": "#appCfg.sharedAssets+\"/mail.svg\""
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1I79CKLKI2",
//																									"attrs": {
//																										"1I79DVAVT0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1I79E0OCH14",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1I79E0OCH15",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1I79DVAVT0",
//																											"faceTagName": "running"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1I79CKLKI3",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1I79CKLKI4",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "true",
//																								"nameVal": "false"
//																							}
//																						},
//																						{
//																							"type": "hudobj",
//																							"def": "text",
//																							"jaxId": "1I79CB7NJ0",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1I79CB7NJ1",
//																									"attrs": {
//																										"type": "text",
//																										"id": "",
//																										"position": "Relative",
//																										"x": "0",
//																										"y": "0",
//																										"w": "",
//																										"h": "100%",
//																										"anchorH": "Left",
//																										"anchorV": "Top",
//																										"autoLayout": "false",
//																										"display": "On",
//																										"clip": "Off",
//																										"uiEvent": "On",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "",
//																										"zIndex": "0",
//																										"margin": "",
//																										"padding": "0",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": "",
//																										"color": "[0,0,0]",
//																										"text": "Messages:",
//																										"font": "",
//																										"fontSize": "#txtSize.smallPlus",
//																										"bold": "false",
//																										"italic": "false",
//																										"underline": "false",
//																										"alignH": "Left",
//																										"alignV": "Center",
//																										"wrap": "false",
//																										"ellipsis": "false",
//																										"lineClamp": "0",
//																										"select": "false",
//																										"shadow": "false",
//																										"shadowX": "0",
//																										"shadowY": "2",
//																										"shadowBlur": "3",
//																										"shadowColor": "[0,0,0,1.00]",
//																										"shadowEx": "",
//																										"maxTextW": "0",
//																										"flex": "true"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1I79CB7NK0",
//																									"attrs": {
//																										"1I79DVAVT0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1I79E0OCH18",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1I79E0OCH19",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1I79DVAVT0",
//																											"faceTagName": "running"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1I79CB7NK1",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1I79CB7NK2",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "false"
//																							}
//																						},
//																						{
//																							"type": "hudobj",
//																							"def": "Gear/@StdUI/ui/BtnIcon.js",
//																							"jaxId": "1I79CDEPG0",
//																							"attrs": {
//																								"createArgs": {
//																									"jaxId": "1I79CDR7I0",
//																									"attrs": {
//																										"style": "\"front\"",
//																										"w": "25",
//																										"h": "0",
//																										"icon": "#appCfg.sharedAssets+\"/trash.svg\"",
//																										"colorBG": "null"
//																									}
//																								},
//																								"properties": {
//																									"jaxId": "1I79CDR7I1",
//																									"attrs": {
//																										"type": "#null#>BtnIcon(\"front\",25,0,appCfg.sharedAssets+\"/trash.svg\",null)",
//																										"id": "BtnClear",
//																										"position": "relative",
//																										"x": "0",
//																										"y": "0",
//																										"display": "On",
//																										"face": ""
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1I79CDR7I2",
//																									"attrs": {
//																										"1I79DVAVT0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1I79E0OCH22",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1I79E0OCH23",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1I79DVAVT0",
//																											"faceTagName": "running"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1I79CDR7I3",
//																									"attrs": {
//																										"OnClick": {
//																											"type": "fixedFunc",
//																											"jaxId": "1I7AT2F6U3",
//																											"attrs": {
//																												"callArgs": {
//																													"jaxId": "1I7AT2F6U4",
//																													"attrs": {
//																														"event": ""
//																													}
//																												},
//																												"seg": "1I7ASR7RV0"
//																											}
//																										}
//																									}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1I79CDR7I4",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "false",
//																								"containerSlots": {
//																									"jaxId": "1I79CDR7I5",
//																									"attrs": {}
//																								}
//																							}
//																						}
//																					]
//																				},
//																				"faces": {
//																					"jaxId": "1I79CKLKI5",
//																					"attrs": {
//																						"1I79DVAVT0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1I79E0OCH26",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1I79E0OCH27",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1I79DVAVT0",
//																							"faceTagName": "running"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1I79CKLKI6",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1I79CKLKI7",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "false",
//																				"exposeContainer": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "box",
//																			"jaxId": "1I568596C0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I568779I0",
//																					"attrs": {
//																						"type": "box",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "100%",
//																						"h": "1",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"background": "#cfgColor[\"fontBodySub\"]",
//																						"border": "0",
//																						"borderStyle": "Solid",
//																						"borderColor": "[0,0,0,1.00]",
//																						"corner": "0",
//																						"shadow": "false",
//																						"shadowX": "2",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowSpread": "0",
//																						"shadowColor": "[0,0,0,0.50]"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1I568779I1",
//																					"attrs": {
//																						"1I79DVAVT0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1I79E0OCH30",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1I79E0OCH31",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1I79DVAVT0",
//																							"faceTagName": "running"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1I568779I2",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1I568779I3",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "hud",
//																			"jaxId": "1I5684KO20",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I568779I4",
//																					"attrs": {
//																						"type": "hud",
//																						"id": "BoxMessages",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "100%",
//																						"h": "100%-25",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Auto Scroll Y",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": ""
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1I568779I5",
//																					"attrs": {
//																						"1I79DVAVT0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1I79E0OCH34",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1I79E0OCH35",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1I79DVAVT0",
//																							"faceTagName": "running"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1I568779I6",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1I568779I7",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "true",
//																				"exposeContainer": "false"
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"jaxId": "1I559CHH51",
//																	"attrs": {
//																		"1I79DVAVT0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I79E0OCH38",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I79E0OCH39",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I79DVAVT0",
//																			"faceTagName": "running"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1I559CHH52",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1I559CHH53",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false"
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1I2G6TJVB1",
//													"attrs": {
//														"1I79DVAVT0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I79E0OCH42",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I79E0OCH43",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I79DVAVT0",
//															"faceTagName": "running"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I2G6TJVB2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I2G6TJVB3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1I56878PI0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I56878PI1",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxTask",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "50%-100",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "[0,5,5,5]",
//														"minW": "",
//														"minH": "",
//														"maxW": "600",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"flex": "false"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "box",
//															"jaxId": "1I56878PJ0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I56878PJ1",
//																	"attrs": {
//																		"type": "box",
//																		"id": "FrameTasks",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "50%-5",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[0,0,5,0]",
//																		"padding": "5",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"background": "#[...cfgColor[\"body\"],0]",
//																		"border": "1",
//																		"borderStyle": "Solid",
//																		"borderColor": "#cfgColor[\"fontBodyLit\"]",
//																		"corner": "10",
//																		"shadow": "false",
//																		"shadowX": "2",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowSpread": "0",
//																		"shadowColor": "[0,0,0,0.50]",
//																		"contentLayout": "Flex Y"
//																	}
//																},
//																"subHuds": {
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "hud",
//																			"jaxId": "1I79CPGEQ0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I79CPGEQ1",
//																					"attrs": {
//																						"type": "hud",
//																						"id": "BoxMsgHeader",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "100%",
//																						"h": "25",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"contentLayout": "Flex X",
//																						"itemsAlign": "Center"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": [
//																						{
//																							"type": "hudobj",
//																							"def": "box",
//																							"jaxId": "1I79CPGER0",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1I79CPGER1",
//																									"attrs": {
//																										"type": "box",
//																										"id": "Icon",
//																										"position": "relative",
//																										"x": "0",
//																										"y": "0",
//																										"w": "25",
//																										"h": "25",
//																										"anchorH": "Left",
//																										"anchorV": "Top",
//																										"autoLayout": "false",
//																										"display": "On",
//																										"clip": "Off",
//																										"uiEvent": "On",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "",
//																										"zIndex": "0",
//																										"margin": "",
//																										"padding": "",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": "",
//																										"background": "#cfgColor[\"fontBodySub\"]",
//																										"border": "1",
//																										"borderStyle": "Solid",
//																										"borderColor": "[0,0,0,1.00]",
//																										"corner": "0",
//																										"shadow": "false",
//																										"shadowX": "2",
//																										"shadowY": "2",
//																										"shadowBlur": "3",
//																										"shadowSpread": "0",
//																										"shadowColor": "[0,0,0,0.50]",
//																										"maskImage": "#appCfg.sharedAssets+\"/run.svg\""
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1I79CPGER2",
//																									"attrs": {
//																										"1I79DVAVT0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1I79E0OCH46",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1I79E0OCH47",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1I79DVAVT0",
//																											"faceTagName": "running"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1I79CPGER3",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1I79CPGER4",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "true",
//																								"nameVal": "false"
//																							}
//																						},
//																						{
//																							"type": "hudobj",
//																							"def": "text",
//																							"jaxId": "1I79CPGER5",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1I79CPGER6",
//																									"attrs": {
//																										"type": "text",
//																										"id": "",
//																										"position": "Relative",
//																										"x": "0",
//																										"y": "0",
//																										"w": "",
//																										"h": "100%",
//																										"anchorH": "Left",
//																										"anchorV": "Top",
//																										"autoLayout": "false",
//																										"display": "On",
//																										"clip": "Off",
//																										"uiEvent": "On",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "",
//																										"zIndex": "0",
//																										"margin": "",
//																										"padding": "0",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": "",
//																										"color": "[0,0,0]",
//																										"text": "Handled Tasks",
//																										"font": "",
//																										"fontSize": "#txtSize.smallPlus",
//																										"bold": "false",
//																										"italic": "false",
//																										"underline": "false",
//																										"alignH": "Left",
//																										"alignV": "Center",
//																										"wrap": "false",
//																										"ellipsis": "false",
//																										"lineClamp": "0",
//																										"select": "false",
//																										"shadow": "false",
//																										"shadowX": "0",
//																										"shadowY": "2",
//																										"shadowBlur": "3",
//																										"shadowColor": "[0,0,0,1.00]",
//																										"shadowEx": "",
//																										"maxTextW": "0",
//																										"flex": "true"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1I79CPGES0",
//																									"attrs": {
//																										"1I79DVAVT0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1I79E0OCI0",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1I79E0OCI1",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1I79DVAVT0",
//																											"faceTagName": "running"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1I79CPGES1",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1I79CPGES2",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "false"
//																							}
//																						}
//																					]
//																				},
//																				"faces": {
//																					"jaxId": "1I79CPGES10",
//																					"attrs": {
//																						"1I79DVAVT0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1I79E0OCI4",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1I79E0OCI5",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1I79DVAVT0",
//																							"faceTagName": "running"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1I79CPGES11",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1I79CPGES12",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "false",
//																				"exposeContainer": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "box",
//																			"jaxId": "1I56878PK0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I56878PK1",
//																					"attrs": {
//																						"type": "box",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "100%",
//																						"h": "1",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"background": "#cfgColor[\"fontBodySub\"]",
//																						"border": "0",
//																						"borderStyle": "Solid",
//																						"borderColor": "[0,0,0,1.00]",
//																						"corner": "0",
//																						"shadow": "false",
//																						"shadowX": "2",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowSpread": "0",
//																						"shadowColor": "[0,0,0,0.50]"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1I56878PK2",
//																					"attrs": {
//																						"1I79DVAVT0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1I79E0OCI8",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1I79E0OCI9",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1I79DVAVT0",
//																							"faceTagName": "running"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1I56878PK3",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1I56878PK4",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "hud",
//																			"jaxId": "1I56878PK5",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I56878PK6",
//																					"attrs": {
//																						"type": "hud",
//																						"id": "BoxTask",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "100%",
//																						"h": "100%-30",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Auto Scroll Y",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "[5,0,0,0]",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": ""
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1I56878PK7",
//																					"attrs": {
//																						"1I79DVAVT0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1I79E0OCI12",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1I79E0OCI13",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1I79DVAVT0",
//																							"faceTagName": "running"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1I56878PK8",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1I56878PK9",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "true",
//																				"exposeContainer": "false"
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"jaxId": "1I56878PK10",
//																	"attrs": {
//																		"1I79DVAVT0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I79E0OCI16",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I79E0OCI17",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I79DVAVT0",
//																			"faceTagName": "running"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1I56878PK11",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1I56878PK12",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "box",
//															"jaxId": "1I79EI7AV0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I79EI7AV1",
//																	"attrs": {
//																		"type": "box",
//																		"id": "FrameRutain",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "50%",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "5",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"background": "#[...cfgColor[\"body\"],0]",
//																		"border": "1",
//																		"borderStyle": "Solid",
//																		"borderColor": "#cfgColor[\"fontBodyLit\"]",
//																		"corner": "10",
//																		"shadow": "false",
//																		"shadowX": "2",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowSpread": "0",
//																		"shadowColor": "[0,0,0,0.50]",
//																		"contentLayout": "Flex Y"
//																	}
//																},
//																"subHuds": {
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "hud",
//																			"jaxId": "1I79EI7B00",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I79EI7B01",
//																					"attrs": {
//																						"type": "hud",
//																						"id": "BoxMsgHeader",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "100%",
//																						"h": "25",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"contentLayout": "Flex X",
//																						"itemsAlign": "Center"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": [
//																						{
//																							"type": "hudobj",
//																							"def": "box",
//																							"jaxId": "1I79EI7B02",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1I79EI7B03",
//																									"attrs": {
//																										"type": "box",
//																										"id": "Icon",
//																										"position": "relative",
//																										"x": "0",
//																										"y": "0",
//																										"w": "25",
//																										"h": "25",
//																										"anchorH": "Left",
//																										"anchorV": "Top",
//																										"autoLayout": "false",
//																										"display": "On",
//																										"clip": "Off",
//																										"uiEvent": "On",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "",
//																										"zIndex": "0",
//																										"margin": "",
//																										"padding": "",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": "",
//																										"background": "#cfgColor[\"fontBodySub\"]",
//																										"border": "1",
//																										"borderStyle": "Solid",
//																										"borderColor": "[0,0,0,1.00]",
//																										"corner": "0",
//																										"shadow": "false",
//																										"shadowX": "2",
//																										"shadowY": "2",
//																										"shadowBlur": "3",
//																										"shadowSpread": "0",
//																										"shadowColor": "[0,0,0,0.50]",
//																										"maskImage": "#appCfg.sharedAssets+\"/recent.svg\""
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1I79EI7B04",
//																									"attrs": {
//																										"1I79DVAVT0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1I79EI7B10",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1I79EI7B11",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1I79DVAVT0",
//																											"faceTagName": "running"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1I79EI7B12",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1I79EI7B13",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "true",
//																								"nameVal": "false"
//																							}
//																						},
//																						{
//																							"type": "hudobj",
//																							"def": "text",
//																							"jaxId": "1I79EI7B14",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1I79EI7B15",
//																									"attrs": {
//																										"type": "text",
//																										"id": "",
//																										"position": "Relative",
//																										"x": "0",
//																										"y": "0",
//																										"w": "",
//																										"h": "100%",
//																										"anchorH": "Left",
//																										"anchorV": "Top",
//																										"autoLayout": "false",
//																										"display": "On",
//																										"clip": "Off",
//																										"uiEvent": "On",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "",
//																										"zIndex": "0",
//																										"margin": "",
//																										"padding": "0",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": "",
//																										"color": "[0,0,0]",
//																										"text": "Routine Tasks",
//																										"font": "",
//																										"fontSize": "#txtSize.smallPlus",
//																										"bold": "false",
//																										"italic": "false",
//																										"underline": "false",
//																										"alignH": "Left",
//																										"alignV": "Center",
//																										"wrap": "false",
//																										"ellipsis": "false",
//																										"lineClamp": "0",
//																										"select": "false",
//																										"shadow": "false",
//																										"shadowX": "0",
//																										"shadowY": "2",
//																										"shadowBlur": "3",
//																										"shadowColor": "[0,0,0,1.00]",
//																										"shadowEx": "",
//																										"maxTextW": "0",
//																										"flex": "true"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1I79EI7B16",
//																									"attrs": {
//																										"1I79DVAVT0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1I79EI7B17",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1I79EI7B18",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1I79DVAVT0",
//																											"faceTagName": "running"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1I79EI7B19",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1I79EI7B110",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "false"
//																							}
//																						},
//																						{
//																							"type": "hudobj",
//																							"def": "Gear/@StdUI/ui/BtnIcon.js",
//																							"jaxId": "1I79F03H20",
//																							"attrs": {
//																								"createArgs": {
//																									"jaxId": "1I79F03H21",
//																									"attrs": {
//																										"style": "\"front\"",
//																										"w": "25",
//																										"h": "0",
//																										"icon": "#appCfg.sharedAssets+\"/inc.svg\"",
//																										"colorBG": "null"
//																									}
//																								},
//																								"properties": {
//																									"jaxId": "1I79F03H22",
//																									"attrs": {
//																										"type": "#null#>BtnIcon(\"front\",25,0,appCfg.sharedAssets+\"/inc.svg\",null)",
//																										"id": "BtnAddRoutine",
//																										"position": "relative",
//																										"x": "0",
//																										"y": "0",
//																										"display": "On",
//																										"face": ""
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1I79F03H23",
//																									"attrs": {
//																										"1I79DVAVT0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1I79F03H24",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1I79F03H25",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1I79DVAVT0",
//																											"faceTagName": "running"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1I79F03H26",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1I79F03H27",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "false",
//																								"containerSlots": {
//																									"jaxId": "1I79F03H28",
//																									"attrs": {}
//																								}
//																							}
//																						}
//																					]
//																				},
//																				"faces": {
//																					"jaxId": "1I79EI7B111",
//																					"attrs": {
//																						"1I79DVAVT0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1I79EI7B112",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1I79EI7B113",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1I79DVAVT0",
//																							"faceTagName": "running"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1I79EI7B114",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1I79EI7B115",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "false",
//																				"exposeContainer": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "box",
//																			"jaxId": "1I79EI7B116",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I79EI7B117",
//																					"attrs": {
//																						"type": "box",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "100%",
//																						"h": "1",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"background": "#cfgColor[\"fontBodySub\"]",
//																						"border": "0",
//																						"borderStyle": "Solid",
//																						"borderColor": "[0,0,0,1.00]",
//																						"corner": "0",
//																						"shadow": "false",
//																						"shadowX": "2",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowSpread": "0",
//																						"shadowColor": "[0,0,0,0.50]"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1I79EI7B118",
//																					"attrs": {
//																						"1I79DVAVT0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1I79EI7B119",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1I79EI7B120",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1I79DVAVT0",
//																							"faceTagName": "running"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1I79EI7B121",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1I79EI7B122",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "hud",
//																			"jaxId": "1I79EI7B20",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I79EI7B21",
//																					"attrs": {
//																						"type": "hud",
//																						"id": "BoxRoutine",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "100%",
//																						"h": "100%-30",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Auto Scroll Y",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": ""
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1I79EI7B22",
//																					"attrs": {
//																						"1I79DVAVT0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1I79EI7B23",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1I79EI7B24",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1I79DVAVT0",
//																							"faceTagName": "running"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1I79EI7B25",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1I79EI7B26",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "true",
//																				"exposeContainer": "false"
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"jaxId": "1I79EI7B27",
//																	"attrs": {
//																		"1I79DVAVT0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I79EI7B28",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I79EI7B29",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I79DVAVT0",
//																			"faceTagName": "running"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1I79EI7B210",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1I79EI7B211",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false"
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1I56878PK13",
//													"attrs": {
//														"1I79DVAVT0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I79E0OCI20",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I79E0OCI21",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I79DVAVT0",
//															"faceTagName": "running"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I56878PK14",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I56878PK15",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1I2G6NBMK0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I2G6Q0VB1",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxState",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "200",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "[5,5,5,5]",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex Y",
//														"flex": "true"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnText.js",
//															"jaxId": "1I79DS1QV0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1I79DS1QV1",
//																	"attrs": {
//																		"style": "primary",
//																		"w": "120",
//																		"h": "25",
//																		"text": "Pause Bot",
//																		"outlined": "false",
//																		"icon": ""
//																	}
//																},
//																"properties": {
//																	"jaxId": "1I79DS1QV2",
//																	"attrs": {
//																		"type": "#null#>BtnText(\"primary\",120,25,\"Pause Bot\",false,\"\")",
//																		"id": "BtnPauseBot",
//																		"position": "relative",
//																		"x": "50%",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"anchorH": "Center",
//																		"margin": "[0,0,5,0]"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1I79DS1R00",
//																	"attrs": {
//																		"1I79DVAVT0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I79E0OCI24",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I79E0OCI25",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I79DVAVT0",
//																			"faceTagName": "running"
//																		},
//																		"1I79DVGR90": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I79E0OCI26",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I79E0OCI27",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I79DVGR90",
//																			"faceTagName": "paused"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1I79DS1R01",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1I79DS1R02",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1I79DS1R03",
//																	"attrs": {
//																		"Slot1H2F6U36O0": {
//																			"jaxId": "1I79DS1R04",
//																			"attrs": {
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"container": "true"
//																			}
//																		}
//																	}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnText.js",
//															"jaxId": "1I79DTF980",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1I79DTF981",
//																	"attrs": {
//																		"style": "success",
//																		"w": "100",
//																		"h": "28",
//																		"text": "Resume Bot",
//																		"outlined": "false",
//																		"icon": ""
//																	}
//																},
//																"properties": {
//																	"jaxId": "1I79DTF982",
//																	"attrs": {
//																		"type": "#null#>BtnText(\"success\",100,28,\"Resume Bot\",false,\"\")",
//																		"id": "BtnResumeBot",
//																		"position": "relative",
//																		"x": "50%",
//																		"y": "0",
//																		"display": "Off",
//																		"face": "",
//																		"anchorH": "Center",
//																		"margin": "[0,0,10,0]"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1I79DTF983",
//																	"attrs": {
//																		"1I79DVAVT0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I79E0OCI28",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I79E0OCI29",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I79DVAVT0",
//																			"faceTagName": "running"
//																		},
//																		"1I79DVGR90": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I79E0OCI30",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I79E0OCI31",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I79DVGR90",
//																			"faceTagName": "paused"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1I79DTF984",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1I79DTF985",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1I79DTF986",
//																	"attrs": {
//																		"Slot1H2F6U36O0": {
//																			"jaxId": "1I79DTF987",
//																			"attrs": {
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"container": "true"
//																			}
//																		}
//																	}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnText.js",
//															"jaxId": "1I79DOVCU0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1I79DQPO10",
//																	"attrs": {
//																		"style": "secondary",
//																		"w": "120",
//																		"h": "25",
//																		"text": "Stop Bot",
//																		"outlined": "false",
//																		"icon": ""
//																	}
//																},
//																"properties": {
//																	"jaxId": "1I79DQPO11",
//																	"attrs": {
//																		"type": "#null#>BtnText(\"secondary\",120,25,\"Stop Bot\",false,\"\")",
//																		"id": "BtnStopBot",
//																		"position": "relative",
//																		"x": "50%",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"anchorH": "Center",
//																		"margin": "[0,0,5,0]"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1I79DQPO12",
//																	"attrs": {
//																		"1I79DVAVT0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I79E0OCI32",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I79E0OCI33",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I79DVAVT0",
//																			"faceTagName": "running"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1I79DQPO13",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1I79DQPO14",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1I79DQPO15",
//																	"attrs": {
//																		"Slot1H2F6U36O0": {
//																			"jaxId": "1I79DQPO16",
//																			"attrs": {
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"container": "true"
//																			}
//																		}
//																	}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnText.js",
//															"jaxId": "1I79DR35O0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1I79DR35O1",
//																	"attrs": {
//																		"style": "error",
//																		"w": "120",
//																		"h": "25",
//																		"text": "Kill Bot",
//																		"outlined": "false",
//																		"icon": ""
//																	}
//																},
//																"properties": {
//																	"jaxId": "1I79DR35O2",
//																	"attrs": {
//																		"type": "#null#>BtnText(\"error\",120,25,\"Kill Bot\",false,\"\")",
//																		"id": "BtnStopBot",
//																		"position": "relative",
//																		"x": "50%",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"anchorH": "Center",
//																		"margin": "[0,0,10,0]",
//																		"enable": "false"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1I79DR35O3",
//																	"attrs": {
//																		"1I79DVAVT0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I79E0OCI36",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I79E0OCI37",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I79DVAVT0",
//																			"faceTagName": "running"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1I79DR35O4",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1I79DR35O5",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1I79DR35O6",
//																	"attrs": {
//																		"Slot1H2F6U36O0": {
//																			"jaxId": "1I79DR35O7",
//																			"attrs": {
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"container": "true"
//																			}
//																		}
//																	}
//																}
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1I2G6Q0VB6",
//													"attrs": {
//														"1I79DVAVT0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I79E0OCI40",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I79E0OCI41",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I79DVAVT0",
//															"faceTagName": "running"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I2G6Q0VB7",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I2G6Q0VB8",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1I2G6Q0VB9",
//									"attrs": {
//										"1I79DVAVT0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I79E0OCI44",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I79E0OCI45",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I79DVAVT0",
//											"faceTagName": "running"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1I2G6Q0VB10",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1I2G6Q0VB11",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1I2G6JNL53",
//					"attrs": {
//						"1I79DVAVT0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1I79E0OCI48",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I79E0OCI49",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1I79DVAVT0",
//							"faceTagName": "running"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1I2G6JNL54",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1I2G6JNL55",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1I2G6JNL56",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}