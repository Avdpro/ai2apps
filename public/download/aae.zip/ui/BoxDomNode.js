//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnNodeLine} from "./BtnNodeLine.js";
/*#{1HL274FKA0StartDoc*/
import AAE from "../aae.js";
/*}#1HL274FKA0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BoxDomNode=function(client,node,uiView,inTree){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let btnLine,boxSubNodes;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1HL274FKA1LocalVals*/
	if(!client||!node){
		return null;
	}
	/*}#1HL274FKA1LocalVals*/
	
	/*#{1HL274FKA1PreState*/
	/*}#1HL274FKA1PreState*/
	/*#{1HL274FKA1PostState*/
	function nodeCSS(node){
		return {
			type:BoxDomNode(client,node,uiView,inTree),position:"relative",node:node,
			focusNode(){
				uiView.focusViewNode(this);
			}
		};
	}
	/*}#1HL274FKA1PostState*/
	cssVO={
		"hash":"1HL274FKA1",nameHost:true,
		"type":"hud","x":0,"y":0,"w":"","h":"","minW":300,"minH":30,"maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
		children:[
			{
				"hash":"1HL28F7390",
				"type":BtnNodeLine(client,node,inTree),"id":"BtnLine","position":"relative","x":0,"y":0,
			},
			{
				"hash":"1HL28LQ2O0",
				"type":"hud","id":"BoxSubNodes","position":"relative","x":15,"y":0,"w":">calc(100% - 15px)","h":"","display":0,"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"",
			}
		],
		/*#{1HL274FKA1ExtraCSS*/
		/*}#1HL274FKA1ExtraCSS*/
		faces:{
			"open":{
				/*BtnLine*/"#1HL28F7390":{
					"face":"open"
				},
				/*BoxSubNodes*/"#1HL28LQ2O0":{
					"display":1
				}
			},"close":{
				/*BtnLine*/"#1HL28F7390":{
					"face":"close"
				},
				/*BoxSubNodes*/"#1HL28LQ2O0":{
					"display":0
				}
			},"focus":{
				/*BtnLine*/"#1HL28F7390":{
					"face":"focus"
				},
				/*#{1HL290R7Q0Code*/
				/*}#1HL290R7Q0Code*/
			},"blur":{
				/*BtnLine*/"#1HL28F7390":{
					"face":"blur"
				}
			}
		},
		OnCreate:function(){
			self=this;
			btnLine=self.BtnLine;boxSubNodes=self.BoxSubNodes;
			/*#{1HL274FKA1Create*/
			if(inTree){
				node.hud=this;
				if(!node.children||!node.children.length){
					btnLine.showFace("noSub");
				}
			}
			/*}#1HL274FKA1Create*/
		},
		/*#{1HL274FKA1EndCSS*/
		/*}#1HL274FKA1EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.open=async function(){
		/*#{1HL3F43KU0Start*/
		let list=node.children;
		if(!list){
			//Read children:
			list=await AAE.getNodeChildren(client,node.AAEId);
			node.children=list;
		}
		if(!list || !list.length){
			btnLine.showFace("noSub");
			return;
		}
		if(boxSubNodes.children.length>0){
			self.showFace("open");
			return;		
		}
		/*}#1HL3F43KU0Start*/
		self.showFace("open");
		VFACT.syncDataList2View(boxSubNodes,list,nodeCSS,true);
	};
	//------------------------------------------------------------------------
	cssVO.close=async function(){
		/*#{1HL3F43KU1Start*/
		/*}#1HL3F43KU1Start*/
		self.showFace("close");
	};
	/*#{1HL274FKA1PostCSSVO*/
	/*}#1HL274FKA1PostCSSVO*/
	return cssVO;
};
/*#{1HL274FKA1ExCodes*/
/*}#1HL274FKA1ExCodes*/

BoxDomNode.gearExport={
	framework: "jax",
	hudType: "hud",
	"showName":"",icon:"gears.svg",previewImg:false,
	fixPose:false,initW:100,initH:100,
	catalog:"",
	args: {
		"client": {
			"name": "client", "showName": "client", "type": "auto", "key": true, "fixed": true, 
			"initVal": null
		}, 
		"node": {
			"name": "node", "showName": "node", "type": "auto", "key": true, "fixed": true, 
			"initVal": null
		}, 
		"uiView": {
			"name": "uiView", "showName": "uiView", "type": "auto", "key": true, "fixed": true, 
			"initVal": null
		}, 
		"inTree": {
			"name": "inTree", "showName": "inTree", "type": "bool", "key": true, "fixed": true, "initVal": true
		}
	},
	state:{
	},
	properties:["id","position","x","y","display"],
	faces:["open","close","focus","blur"],
	subContainers:{
	},
	/*#{1HL274FKA0ExGearInfo*/
	/*}#1HL274FKA0ExGearInfo*/
};
export default BoxDomNode;
export{BoxDomNode};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1HL274FKA0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1HL274FKA2",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1HL274FKA3",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1HL274FKA4",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1HL274FKA5",
//			"attrs": {
//				"client": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"node": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"uiView": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"inTree": {
//					"type": "bool",
//					"valText": "true"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1HL274FKA6",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1HL274FKA7",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HL3F43KU0",
//					"attrs": {
//						"id": "open",
//						"label": "New AI Seg",
//						"x": "110",
//						"y": "80",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HL3F43L50",
//							"attrs": {}
//						},
//						"async": "true",
//						"localVars": {
//							"jaxId": "1HL3F43L51",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": [
//								{
//									"type": "flowseg",
//									"def": "SetFace",
//									"jaxId": "1HL3F43L52",
//									"attrs": {
//										"id": "ShowOpen",
//										"label": "New AI Seg",
//										"x": "300",
//										"y": "80",
//										"desc": "",
//										"codes": "false",
//										"component": "self",
//										"face": "open",
//										"outlet": {
//											"jaxId": "1HL3F43L53",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											},
//											"linkedSeg": "1HL3F9HA70"
//										}
//									}
//								},
//								{
//									"type": "flowseg",
//									"def": "RenderData",
//									"jaxId": "1HL3F9HA70",
//									"attrs": {
//										"id": "ShowSubNodes",
//										"label": "New AI Seg",
//										"x": "530",
//										"y": "80",
//										"desc": "",
//										"codes": "false",
//										"view": "boxSubNodes",
//										"data": "list",
//										"uiDef": "nodeCSS",
//										"clear": "true",
//										"assign": "",
//										"outlet": {
//											"jaxId": "1HL3F9HA71",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											}
//										}
//									}
//								}
//							]
//						},
//						"outlet": {
//							"jaxId": "1HL3F43L54",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1HL3F43L52"
//						}
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HL3F43KU1",
//					"attrs": {
//						"id": "close",
//						"label": "New AI Seg",
//						"x": "110",
//						"y": "180",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HL3F43L55",
//							"attrs": {}
//						},
//						"async": "true",
//						"localVars": {
//							"jaxId": "1HL3F43L56",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": [
//								{
//									"type": "flowseg",
//									"def": "SetFace",
//									"jaxId": "1HL3F43L57",
//									"attrs": {
//										"id": "ShowClose",
//										"label": "New AI Seg",
//										"x": "290",
//										"y": "180",
//										"desc": "",
//										"codes": "false",
//										"component": "self",
//										"face": "close",
//										"outlet": {
//											"jaxId": "1HL3F43L58",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											}
//										}
//									}
//								}
//							]
//						},
//						"outlet": {
//							"jaxId": "1HL3F43L59",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1HL3F43L57"
//						}
//					}
//				}
//			]
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1HL274FKA8",
//			"attrs": {
//				"open": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HL291HV90",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HL2926KG0",
//							"attrs": {}
//						}
//					}
//				},
//				"close": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HL291UN20",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HL2926KG1",
//							"attrs": {}
//						}
//					}
//				},
//				"focus": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HL290R7Q0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HL2926KG2",
//							"attrs": {}
//						}
//					}
//				},
//				"blur": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HL2918B00",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HL2926KG3",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1HL274FKA9",
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1HL274FKA1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1HL274FKA10",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "",
//						"h": "",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "",
//						"minW": "300",
//						"minH": "30",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Flex Y"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "Gear1HL27BS8G0",
//							"jaxId": "1HL28F7390",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1HL28G1020",
//									"attrs": {
//										"client": "#client",
//										"node": "#node",
//										"inTree": "#inTree"
//									}
//								},
//								"properties": {
//									"jaxId": "1HL28G1021",
//									"attrs": {
//										"type": "#null#>BtnNodeLine(client,node,inTree)",
//										"id": "BtnLine",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"display": "On",
//										"face": ""
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HL28G1022",
//									"attrs": {
//										"1HL2918B00": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HL2926KG6",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HL2926KG7",
//													"attrs": {
//														"face": {
//															"type": "auto",
//															"valText": "\"blur\"",
//															"editType": "face"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HL2918B00",
//											"faceTagName": "blur"
//										},
//										"1HL291HV90": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HL2926KG8",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HL2926KG9",
//													"attrs": {
//														"face": {
//															"type": "auto",
//															"valText": "\"open\"",
//															"editType": "face"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HL291HV90",
//											"faceTagName": "open"
//										},
//										"1HL291UN20": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HL2926KG10",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HL2926KG11",
//													"attrs": {
//														"face": {
//															"type": "auto",
//															"valText": "\"close\"",
//															"editType": "face"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HL291UN20",
//											"faceTagName": "close"
//										},
//										"1HL290R7Q0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HL29M7SG0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HL29M7SG1",
//													"attrs": {
//														"face": {
//															"type": "auto",
//															"valText": "\"focus\"",
//															"editType": "face"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HL290R7Q0",
//											"faceTagName": "focus"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HL28G1023",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HL28G1024",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true",
//								"containerSlots": {
//									"jaxId": "1HL28G1025",
//									"attrs": {}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1HL28LQ2O0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HL2926KG24",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxSubNodes",
//										"position": "relative",
//										"x": "15",
//										"y": "0",
//										"w": "100%-15",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "Off",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": ""
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HL2926KG25",
//									"attrs": {
//										"1HL291HV90": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HL2926KG30",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HL2926KG31",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HL291HV90",
//											"faceTagName": "open"
//										},
//										"1HL291UN20": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HL2926KG32",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HL2926KG33",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HL291UN20",
//											"faceTagName": "close"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HL2926KG34",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HL2926KG35",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1HL274FKA11",
//					"attrs": {
//						"1HL291HV90": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HL2926KG40",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HL2926KG41",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HL291HV90",
//							"faceTagName": "open"
//						},
//						"1HL291UN20": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HL2926KG42",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HL2926KG43",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HL291UN20",
//							"faceTagName": "close"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1HL274FKA12",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1HL274FKA13",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1HL274FKA14",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}