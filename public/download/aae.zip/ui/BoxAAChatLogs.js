//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
/*#{1I69AG01I0StartDoc*/
import {BoxAAChatLogLine} from "./BoxAAChatLogLine.js";
/*}#1I69AG01I0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BoxAAChatLogs=function(initLog){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let boxLogs;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let logs=initLog?[initLog]:[];
	let isOpen=false;
	
	/*#{1I69AG01I1LocalVals*/
	/*}#1I69AG01I1LocalVals*/
	
	/*#{1I69AG01I1PreState*/
	/*}#1I69AG01I1PreState*/
	state={
		"num":1,
		/*#{1I69AG01I7ExState*/
		/*}#1I69AG01I7ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1I69AG01I1PostState*/
	/*}#1I69AG01I1PostState*/
	cssVO={
		"hash":"1I69AG01I1",nameHost:true,
		"type":"hud","position":"relative","x":10,"y":0,"w":">calc(100% - 20px)","h":"","cursor":"pointer","margin":[5,0,5,0],"padding":[5,0,5,0],"minW":"",
		"minH":20,"maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
		"isChatLogBlock":false,
		children:[
			{
				"hash":"1I69AGTS40",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","uiEvent":-1,"cursor":"pointer","padding":5,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"background":[cfgColor["fontBody"][0],cfgColor["fontBody"][1],cfgColor["fontBody"][2],0.05],"corner":10,"contentLayout":"flex-x","itemsAlign":1,
			},
			{
				"hash":"1I69BCIBB0",
				"type":"hud","id":"BoxHeader","position":"relative","x":0,"y":0,"w":"100%","h":"","padding":[0,5,0,5],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"contentLayout":"flex-x","itemsAlign":1,
				children:[
					{
						"hash":"1I69BCRIR0",
						"type":"box","position":"relative","x":0,"y":0,"w":"","h":16,"uiEvent":-1,"margin":[0,3,0,0],"padding":[0,3,0,3],"minW":16,"minH":"","maxW":"","maxH":"",
						"styleClass":"","background":cfgColor["fontBodyLit"],"corner":10,"contentLayout":"flex-x","subAlign":1,"itemsAlign":1,
						children:[
							{
								"hash":"1I69BCRIS0",
								"type":"text","position":"relative","x":0,"y":0,"w":"","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["body"],
								"text":$P(()=>(state.num),state),"fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,
							}
						],
					},
					{
						"hash":"1I69BE4FE0",
						"type":"text","position":"relative","x":0,"y":0,"w":"","h":"100%","uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodySub"],
						"text":$P(()=>(state.num>1?"Logs":"Log"),state),"fontSize":txtSize.small,"fontWeight":"bold","fontStyle":"normal","textDecoration":"underline",
					}
				],
				"OnClick":function(event){
					self.openBox(this,event);
				},
			},
			{
				"hash":"1I69BLQVT0",
				"type":"hud","id":"BoxLogs","position":"relative","x":0,"y":0,"w":"100%","h":"","display":0,"padding":[0,0,0,10],"minW":"","minH":30,"maxW":"","maxH":"",
				"styleClass":"",
			},
			{
				"hash":"1I69BJ44L0",
				"type":BtnIcon("front",20,0,appCfg.sharedAssets+"/close.svg",null),"id":"BoxClose","x":">calc(100% - 26px)","y":5,"display":0,
				"OnClick":function(event){
					self.closeBox(this,event);
				},
			}
		],
		/*#{1I69AG01I1ExtraCSS*/
		/*}#1I69AG01I1ExtraCSS*/
		faces:{
			"close":{
				/*BoxLogs*/"#1I69BLQVT0":{
					"display":0
				},
				/*BoxClose*/"#1I69BJ44L0":{
					"display":0
				}
			},"open":{
				/*BoxLogs*/"#1I69BLQVT0":{
					"display":1
				},
				/*BoxClose*/"#1I69BJ44L0":{
					"display":1
				}
			}
		},
		OnCreate:function(){
			self=this;
			boxLogs=self.BoxLogs;
			/*#{1I69AG01I1Create*/
			/*}#1I69AG01I1Create*/
		},
		/*#{1I69AG01I1EndCSS*/
		/*}#1I69AG01I1EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.openBox=async function(){
		/*#{1I69BSRQJ0Start*/
		if(isOpen){
			self.closeBox();
			return;
		}
		isOpen=true;
		/*}#1I69BSRQJ0Start*/
		
		//ShowLogs
		/*#{1I69BTSOH0*/
		let log,css;
		for(log of logs){
			boxLogs.appendNewChild(BoxAAChatLogLine(log));
		}
		/*}#1I69BTSOH0*/
		self.showFace("open");
	};
	//------------------------------------------------------------------------
	cssVO.closeBox=async function(){
		/*#{1I69BTVL50Start*/
		if(!isOpen)
			return;
		isOpen=false;
		/*}#1I69BTVL50Start*/
		
		//ClearLogs
		/*#{1I69BUSBQ0*/
		boxLogs.clearChildren();
		/*}#1I69BUSBQ0*/
		self.showFace("close");
	};
	//------------------------------------------------------------------------
	cssVO.addLog=async function(log){
		/*#{1I69BV0CK0Start*/
		state.num+=1;
		logs.push(log);
		/*}#1I69BV0CK0Start*/
	};
	/*#{1I69AG01I1PostCSSVO*/
	/*}#1I69AG01I1PostCSSVO*/
	return cssVO;
};
/*#{1I69AG01I1ExCodes*/
/*}#1I69AG01I1ExCodes*/


/*#{1I69AG01I0EndDoc*/
/*}#1I69AG01I0EndDoc*/

export default BoxAAChatLogs;
export{BoxAAChatLogs};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1I69AG01I0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1I69AG01I2",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1I69AG01I3",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1I69AG01I4",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1I69AG01I5",
//			"attrs": {
//				"initLog": {
//					"type": "auto",
//					"valText": "null"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1I69AG01I6",
//			"attrs": {
//				"logs": {
//					"type": "auto",
//					"valText": "#initLog?[initLog]:[]"
//				},
//				"isOpen": {
//					"type": "auto",
//					"valText": "false"
//				}
//			}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1I69AG01I7",
//			"attrs": {
//				"num": {
//					"type": "int",
//					"valText": "1"
//				}
//			}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I69BSRQJ0",
//					"attrs": {
//						"id": "openBox",
//						"label": "New AI Seg",
//						"x": "60",
//						"y": "65",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I69BTSOI0",
//							"attrs": {}
//						},
//						"async": "true",
//						"localVars": {
//							"jaxId": "1I69BTSOI1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": [
//								{
//									"type": "flowseg",
//									"def": "Code",
//									"jaxId": "1I69BTSOH0",
//									"attrs": {
//										"id": "ShowLogs",
//										"label": "New AI Seg",
//										"x": "265",
//										"y": "65",
//										"desc": "",
//										"codes": "false",
//										"outlet": {
//											"jaxId": "1I69BTSOI2",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											},
//											"linkedSeg": "1I69BTGAT0"
//										}
//									}
//								},
//								{
//									"type": "flowseg",
//									"def": "SetFace",
//									"jaxId": "1I69BTGAT0",
//									"attrs": {
//										"id": "Open",
//										"label": "New AI Seg",
//										"x": "485",
//										"y": "65",
//										"desc": "",
//										"codes": "false",
//										"component": "self",
//										"face": "open",
//										"outlet": {
//											"jaxId": "1I69BTSOI3",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											}
//										}
//									}
//								}
//							]
//						},
//						"outlet": {
//							"jaxId": "1I69BTSOI4",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I69BTSOH0"
//						}
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I69BTVL50",
//					"attrs": {
//						"id": "closeBox",
//						"label": "New AI Seg",
//						"x": "60",
//						"y": "165",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I69BUSBR0",
//							"attrs": {}
//						},
//						"async": "true",
//						"localVars": {
//							"jaxId": "1I69BUSBR1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": [
//								{
//									"type": "flowseg",
//									"def": "Code",
//									"jaxId": "1I69BUSBQ0",
//									"attrs": {
//										"id": "ClearLogs",
//										"label": "New AI Seg",
//										"x": "265",
//										"y": "165",
//										"desc": "",
//										"codes": "false",
//										"outlet": {
//											"jaxId": "1I69BUSBR2",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											},
//											"linkedSeg": "1I69BUJIB0"
//										}
//									}
//								},
//								{
//									"type": "flowseg",
//									"def": "SetFace",
//									"jaxId": "1I69BUJIB0",
//									"attrs": {
//										"id": "Close",
//										"label": "New AI Seg",
//										"x": "485",
//										"y": "165",
//										"desc": "",
//										"codes": "false",
//										"component": "self",
//										"face": "close",
//										"outlet": {
//											"jaxId": "1I69BUSBR3",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											}
//										}
//									}
//								}
//							]
//						},
//						"outlet": {
//							"jaxId": "1I69BUSBR4",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I69BUSBQ0"
//						}
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I69BV0CK0",
//					"attrs": {
//						"id": "addLog",
//						"label": "New AI Seg",
//						"x": "60",
//						"y": "260",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I69BVKOF0",
//							"attrs": {
//								"log": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"localVars": {
//							"jaxId": "1I69BVKOF1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I69BVKOF2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						}
//					}
//				}
//			]
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1I69AG01J0",
//			"attrs": {
//				"close": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1I69BMPHD0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1I69BPQHG0",
//							"attrs": {}
//						}
//					}
//				},
//				"open": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1I69BN1230",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1I69BPQHG1",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1I69AG01J1",
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1I69AG01I1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1I69AG01J2",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Relative",
//						"x": "10",
//						"y": "0",
//						"w": "100%-20",
//						"h": "",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "pointer",
//						"zIndex": "0",
//						"margin": "[5,0,5,0]",
//						"padding": "[5,0,5,0]",
//						"minW": "",
//						"minH": "20",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Flex Y"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1I69AGTS40",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I69B7F5G0",
//									"attrs": {
//										"type": "box",
//										"id": "BoxBG",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "pointer",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "5",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#[cfgColor[\"fontBody\"][0],cfgColor[\"fontBody\"][1],cfgColor[\"fontBody\"][2],0.05]",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "10",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"contentLayout": "Flex X",
//										"itemsAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1I69B7F5G13",
//									"attrs": {
//										"1I69BN1230": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I6BUPU6V0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I6BUPU6V1",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I69BN1230",
//											"faceTagName": "open"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1I69B7F5G14",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1I69B7F5G15",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1I69BCIBB0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I69BEE000",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxHeader",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "[0,5,0,5]",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex X",
//										"itemsAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1I69BCRIR0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I69BCRIR1",
//													"attrs": {
//														"type": "box",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "",
//														"h": "16",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "Tree Off",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[0,3,0,0]",
//														"padding": "[0,3,0,3]",
//														"minW": "16",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "#cfgColor[\"fontBodyLit\"]",
//														"border": "0",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "10",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]",
//														"contentLayout": "Flex X",
//														"subAlign": "Center",
//														"itemsAlign": "Center"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1I69BCRIS0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I69BCRIS1",
//																	"attrs": {
//																		"type": "text",
//																		"id": "",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "",
//																		"h": "100%",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"body\"]",
//																		"text": "${state.num},state",
//																		"font": "",
//																		"fontSize": "#txtSize.small",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Center",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"lineClamp": "0",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1I69BCRIS2",
//																	"attrs": {
//																		"1I69BN1230": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I6BUPU700",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I6BUPU701",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I69BN1230",
//																			"faceTagName": "open"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1I69BCRIS3",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1I69BCRIS4",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false"
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1I69BCRIS5",
//													"attrs": {
//														"1I69BN1230": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I6BUPU702",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I6BUPU703",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I69BN1230",
//															"faceTagName": "open"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I69BCRIS6",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I69BCRIS7",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1I69BE4FE0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I69BE4FE1",
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "Tree Off",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBodySub\"]",
//														"text": "${state.num>1?\"Logs\":\"Log\"},state",
//														"font": "",
//														"fontSize": "#txtSize.small",
//														"bold": "true",
//														"italic": "false",
//														"underline": "true",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I69BE4FE2",
//													"attrs": {
//														"1I69BN1230": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I6BUPU704",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I6BUPU705",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I69BN1230",
//															"faceTagName": "open"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I69BE4FE3",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I69BE4FE4",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1I69BEE010",
//									"attrs": {
//										"1I69BN1230": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I6BUPU706",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I6BUPU707",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I69BN1230",
//											"faceTagName": "open"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1I69BEE011",
//									"attrs": {
//										"OnClick": {
//											"type": "fixedFunc",
//											"jaxId": "1I69CEO3E0",
//											"attrs": {
//												"callArgs": {
//													"jaxId": "1I69CF4KL0",
//													"attrs": {
//														"event": ""
//													}
//												},
//												"seg": "1I69BSRQJ0"
//											}
//										}
//									}
//								},
//								"extraPpts": {
//									"jaxId": "1I69BEE012",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1I69BLQVT0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I69BMKPA0",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxLogs",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "Off",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "[0,0,0,10]",
//										"minW": "",
//										"minH": "30",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": ""
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1I69BMKPA1",
//									"attrs": {
//										"1I69BN1230": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I69BPQHH16",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I69BPQHH17",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I69BN1230",
//											"faceTagName": "open"
//										},
//										"1I69BMPHD0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I69BPQHH18",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I69BPQHH19",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I69BMPHD0",
//											"faceTagName": "close"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1I69BMKPA2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1I69BMKPA3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear/@StdUI/ui/BtnIcon.js",
//							"jaxId": "1I69BJ44L0",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1I69BL06V0",
//									"attrs": {
//										"style": "\"front\"",
//										"w": "20",
//										"h": "0",
//										"icon": "#appCfg.sharedAssets+\"/close.svg\"",
//										"colorBG": "null"
//									}
//								},
//								"properties": {
//									"jaxId": "1I69BL06V1",
//									"attrs": {
//										"type": "#null#>BtnIcon(\"front\",20,0,appCfg.sharedAssets+\"/close.svg\",null)",
//										"id": "BoxClose",
//										"position": "Absolute",
//										"x": "100%-26",
//										"y": "5",
//										"display": "Off",
//										"face": ""
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1I69BL06V2",
//									"attrs": {
//										"1I69BN1230": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I69BPQHH20",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I69BPQHH21",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I69BN1230",
//											"faceTagName": "open"
//										},
//										"1I69BMPHD0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I69BPQHH22",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I69BPQHH23",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I69BMPHD0",
//											"faceTagName": "close"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1I69BL0700",
//									"attrs": {
//										"OnClick": {
//											"type": "fixedFunc",
//											"jaxId": "1I69CFTJV0",
//											"attrs": {
//												"callArgs": {
//													"jaxId": "1I69CG0320",
//													"attrs": {
//														"event": ""
//													}
//												},
//												"seg": "1I69BTVL50"
//											}
//										}
//									}
//								},
//								"extraPpts": {
//									"jaxId": "1I69BL0701",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false",
//								"containerSlots": {
//									"jaxId": "1I69BL0702",
//									"attrs": {}
//								}
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1I69AG01J3",
//					"attrs": {
//						"1I69BN1230": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1I6BUPU708",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I6BUPU709",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1I69BN1230",
//							"faceTagName": "open"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1I69AG01J4",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1I69AG01J5",
//					"attrs": {
//						"isChatLogBlock": {
//							"type": "bool",
//							"valText": "false"
//						}
//					}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1I69AG01J6",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}