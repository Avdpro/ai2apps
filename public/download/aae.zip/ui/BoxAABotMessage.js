//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1I79M1QRH0StartDoc*/
/*}#1I79M1QRH0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BoxAABotMessage=function(msg,from,icon){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1I69CLE7F1LocalVals*/
	icon=icon||appCfg.sharedAssets+"/mail.svg";
	if(icon[0]!="/"){
		icon=appCfg.sharedAssets+"/"+icon;
	}
	/*}#1I69CLE7F1LocalVals*/
	
	/*#{1I69CLE7F1PreState*/
	/*}#1I69CLE7F1PreState*/
	/*#{1I69CLE7F1PostState*/
	/*}#1I69CLE7F1PostState*/
	cssVO={
		"hash":"1I69CLE7F1",nameHost:true,
		"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":"","margin":[3,0,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
		children:[
			{
				"hash":"1I79M447O0",
				"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
				"itemsAlign":1,
				children:[
					{
						"hash":"1I79M5LLU0",
						"type":"box","id":"Icon","position":"relative","x":0,"y":0,"w":20,"h":20,"margin":[0,3,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						"background":cfgColor["fontBodySub"],"border":1,"maskImage":icon,
					},
					{
						"hash":"1I79M4G9P0",
						"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodySub"],
						"text":""+(from||msg.from)+":","fontSize":txtSize.small,"fontWeight":"bold","fontStyle":"normal","textDecoration":"",
					}
				],
			},
			{
				"hash":"1I69CTDQ40",
				"type":"text","position":"relative","x":10,"y":0,"w":">calc(100% - 10px)","h":"","cursor":"text","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"color":[0,0,0],"text":JSON.stringify(msg),"font":"Courier New","fontSize":txtSize.small,"fontWeight":"bold","fontStyle":"normal","textDecoration":"",
				"wrap":true,"selectable":true,
			}
		],
		/*#{1I69CLE7F1ExtraCSS*/
		/*}#1I69CLE7F1ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			self=this;
			
			/*#{1I69CLE7F1Create*/
			/*}#1I69CLE7F1Create*/
		},
		/*#{1I69CLE7F1EndCSS*/
		/*}#1I69CLE7F1EndCSS*/
	};
	/*#{1I69CLE7F1PostCSSVO*/
	/*}#1I69CLE7F1PostCSSVO*/
	return cssVO;
};
/*#{1I69CLE7F1ExCodes*/
/*}#1I69CLE7F1ExCodes*/


/*#{1I79M1QRH0EndDoc*/
/*}#1I79M1QRH0EndDoc*/

export default BoxAABotMessage;
export{BoxAABotMessage};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1I79M1QRH0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1I69CLE7F2",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1I69CLE7F3",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1I69CLE7F4",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1I69CLE7F5",
//			"attrs": {
//				"msg": {
//					"type": "auto",
//					"valText": "#{from:\"BOT_MASTER\",fromType:\"BOT\",log:{text:\"Starting...\"}}"
//				},
//				"from": {
//					"type": "string",
//					"valText": "BOT_MASTER"
//				},
//				"icon": {
//					"type": "string",
//					"valText": "#appCfg.sharedAssets+\"/mail.svg\""
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1I69CLE7F6",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1I69CLE7F7",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1I69CLE7F8",
//			"attrs": {}
//		},
//		"mockupStates": {
//			"jaxId": "1I69CLE7F9",
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1I69CLE7F1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1I69CLE7F10",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Relative",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "[3,0,0,0]",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Flex Y"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1I79M447O0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I79M59940",
//									"attrs": {
//										"type": "hud",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "20",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex X",
//										"itemsAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1I79M5LLU0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I79M5LLU1",
//													"attrs": {
//														"type": "box",
//														"id": "Icon",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "20",
//														"h": "20",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[0,3,0,0]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "#cfgColor[\"fontBodySub\"]",
//														"border": "1",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]",
//														"maskImage": "#icon"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I79M5LLV0",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1I79M5LM00",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I79M5LM01",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1I79M4G9P0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I79M4G9P1",
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBodySub\"]",
//														"text": "#\"\"+(from||msg.from)+\":\"",
//														"font": "",
//														"fontSize": "#txtSize.small",
//														"bold": "true",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I79M4G9Q0",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1I79M4G9Q1",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I79M4G9Q2",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1I79M59941",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1I79M59942",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1I79M59943",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1I69CTDQ40",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I69CVQC00",
//									"attrs": {
//										"type": "text",
//										"id": "",
//										"position": "relative",
//										"x": "10",
//										"y": "0",
//										"w": "100%-10",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "text",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "[0,0,0]",
//										"text": "#JSON.stringify(msg)",
//										"font": "Courier New",
//										"fontSize": "#txtSize.small",
//										"bold": "true",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Top",
//										"wrap": "true",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "true",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1I69CVQC01",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1I69CVQC02",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1I69CVQC03",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1I69CLE7F11",
//					"attrs": {}
//				},
//				"functions": {
//					"jaxId": "1I69CLE7F12",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1I69CLE7F13",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "true",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1I69CLE7F14",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}