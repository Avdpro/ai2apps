//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnText} from "/@StdUI/ui/BtnText.js";
import {BtnChatFlow} from "./BtnChatFlow.js";
import {NaviToolBar} from "/@StdUI/ui/NaviToolBar.js";
import {BtnNaviItem} from "/@StdUI/ui/BtnNaviItem.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
/*#{1I7H5A7EO0StartDoc*/
import {AAUser} from "../AAUser.js";
import {AAChatFlow} from "../AAChatFlow.js";
import {UIBotChat} from "./UIBotChat.js";
/*}#1I7H5A7EO0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let UserClientUI=function(){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let edUser,edPassword,boxNVChats,boxNVSkills,boxFlowNavi,naviBar,dkChats,txtTitle,txtBotName,btnChooseBot,boxDragSize;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1I7H5A7EO1LocalVals*/
	let userId;
	let user=null;
	let app=VFACT.app;
	let hotChatFlowBtn=null;
	/*}#1I7H5A7EO1LocalVals*/
	
	/*#{1I7H5A7EO1PreState*/
	/*}#1I7H5A7EO1PreState*/
	state={
		"naviBoxW":240,
		/*#{1I7H5A7EP5ExState*/
		/*}#1I7H5A7EP5ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1I7H5A7EO1PostState*/
	/*}#1I7H5A7EO1PostState*/
	cssVO={
		"hash":"1I7H5A7EO1",nameHost:true,
		"type":"hud","x":0,"y":0,"w":"100%","h":"100%","overflow":1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
		children:[
			{
				"hash":"1I7H5J1LI0",
				"type":"hud","id":"BoxBody","x":0,"y":40,"w":"100%","h":">calc(100% - 40px)","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				children:[
					{
						"hash":"1I7H5K2CV0",
						"type":"hud","id":"BoxLogin","x":0,"y":0,"w":"100%","h":"60%","display":0,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
						"subAlign":1,"itemsAlign":1,
						children:[
							{
								"hash":"1I7H5VC540",
								"type":"hud","id":"BoxUser","position":"relative","x":0,"y":0,"w":200,"h":"","margin":[0,0,10,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
								"contentLayout":"flex-y",
								children:[
									{
										"hash":"1I7H62TNF0",
										"type":"text","position":"relative","x":-20,"y":0,"w":"100%","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
										"text":(($ln==="CN")?("用户帐号:"):("User account:")),"fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
									},
									{
										"hash":"1I7H607FS0",
										"type":"edit","id":"EdUser","position":"relative","x":0,"y":0,"w":200,"h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","text":"admin",
										"placeHolder":"User Account","color":[0,0,0],"outline":0,"border":[0,0,1,0],
									}
								],
							},
							{
								"hash":"1I7H65G320",
								"type":"hud","id":"BoxPassword","position":"relative","x":0,"y":0,"w":200,"h":"","margin":[0,0,16,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
								"contentLayout":"flex-y",
								children:[
									{
										"hash":"1I7H65G331",
										"type":"text","position":"relative","x":-20,"y":0,"w":"100%","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
										"text":(($ln==="CN")?("密码:"):("Password: ")),"fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
									},
									{
										"hash":"1I7H65G343",
										"type":"edit","id":"EdPassword","position":"relative","x":0,"y":0,"w":200,"h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","inputType":"password",
										"color":[0,0,0],"outline":0,"border":[0,0,1,0],
									}
								],
							},
							{
								"hash":"1I7H690I30",
								"type":BtnText("primary",100,25,(($ln==="CN")?("登录"):("Login")),false,""),"id":"BtnLogin","position":"relative","x":0,"y":0,
								"OnClick":function(event){
									self.login(this,event);
								},
							}
						],
					},
					{
						"hash":"1I7INS8MC0",
						"type":"hud","id":"BoxChatUI","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
						children:[
							{
								"hash":"1I7INU0C40",
								"type":"box","id":"BoxNavi","position":"relative","x":0,"y":0,"w":$P(()=>(state.naviBoxW),state),"h":"100%","minW":"","minH":"","maxW":"","maxH":"",
								"styleClass":"","background":cfgColor["toolBG"],"border":[0,0,0,0],
								children:[
									{
										"hash":"1I7JDET5M0",
										"type":"hud","id":"NaviViews","x":0,"y":32,"w":"100%","h":">calc(100% - 32px)","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
										children:[
											{
												"hash":"1I7LNVMIK0",
												"type":"hud","id":"BoxNVChats","x":0,"y":0,"w":"100%","h":"100%","overflow":"auto-y","padding":5,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
												"contentLayout":"flex-yr","subAlign":2,
												children:[
												],
											},
											{
												"hash":"1I7LO02O90",
												"type":"hud","id":"BoxNVSkills","x":0,"y":0,"w":"100%","h":"100%","display":0,"overflow":"auto-y","minW":"","minH":"","maxW":"","maxH":"",
												"styleClass":"","contentLayout":"flex-y",
											}
										],
									},
									{
										"hash":"1I7IOKBMD0",
										"type":"box","id":"BoxFlowNavi","x":0,"y":0,"w":"100%","h":32,"padding":0,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["toolBG"],
										"border":[0,0,0,0],"borderColor":[0,0,0,0.38],"shadow":true,"shadowX":0,"contentLayout":"flex-x",
										children:[
											{
												"hash":"1I7IOKBMD2",
												"type":NaviToolBar(false),"id":"NaviBar","position":"relative","x":0,"y":0,"face":"top",
												subContainers:{
													"1HL4P0I9P0":[
														{
															"hash":"1I7IOKBME5",
															"type":BtnNaviItem("Home","Dialogs",[0,0,0,1],appCfg.sharedAssets+"/chat.svg",undefined,12,false,24,false),"position":"relative","x":0,
															"y":0,"margin":[0,10,0,0],
															"OnClick":function(event){
																/*#{1I7IOKBME10FunctionBody*/
																/*}#1I7IOKBME10FunctionBody*/
															},
														},
														{
															"hash":"1I7JB9EIV0",
															"type":BtnNaviItem("Home","Skills",[0,0,0,1],appCfg.sharedAssets+"/gas_e.svg",undefined,12,false,24,false),"position":"relative","x":0,
															"y":0,"margin":[0,10,0,0],"enable":false,
															"OnClick":function(event){
																/*#{1I7JB9EJ02FunctionBody*/
																/*}#1I7JB9EJ02FunctionBody*/
															},
														}
													]
												},
											}
										],
									}
								],
							},
							{
								"hash":"1I7IO81R60",
								"type":"box","id":"BoxChatFlows","position":"relative","x":0,"y":0,"w":"","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["chatBG"],
								"shadow":true,"shadowX":0,"shadowY":0,"flex":true,
								children:[
									{
										"hash":"1I7IOJ3TJ0",
										"type":"dock","id":"DkChats","position":"relative","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
										"coverAction":0,"ui":0,
									}
								],
							}
						],
					}
				],
			},
			{
				"hash":"1I7H5BDI40",
				"type":"box","id":"BoxHeader","x":0,"y":0,"w":"100%","h":40,"padding":[0,10,0,10],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["secondary"],
				"contentLayout":"flex-x","itemsAlign":1,
				children:[
					{
						"hash":"1I7JQD7R20",
						"type":"hud","id":"BoxTitle","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
						"subAlign":1,"itemsAlign":1,
						children:[
							{
								"hash":"1I7JQEHS80",
								"type":"box","position":"relative","x":0,"y":0,"w":30,"h":30,"margin":[0,5,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["fontSecondary"],
								"maskImage":appCfg.sharedAssets+"/aalogo.svg",
							},
							{
								"hash":"1I7JQELOR0",
								"type":"text","id":"TxtTitle","position":"relative","x":0,"y":0,"w":"","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontSecondary"],
								"text":(($ln==="CN")?("AI2Apps 智能体团队"):("AI2Apps Teamwork")),"fontSize":txtSize.midPlus,"fontWeight":"bold","fontStyle":"normal","textDecoration":"",
							},
							{
								"hash":"1I7MV18UD0",
								"type":"box","position":"relative","x":0,"y":0,"w":30,"h":30,"display":0,"margin":[0,5,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
								"background":cfgColor["fontSecondary"],"maskImage":appCfg.sharedAssets+"/agent.svg",
							},
							{
								"hash":"1I7MV1PU80",
								"type":"text","id":"TxtBotName","position":"relative","x":0,"y":0,"w":"","h":"","display":0,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
								"color":cfgColor["fontSecondary"],"text":(($ln==="CN")?("与 BOT_MASTER 对话"):("Chat with: BOT_MASTER")),"fontSize":txtSize.midPlus,"fontWeight":"bold",
								"fontStyle":"normal","textDecoration":"",
							},
							{
								"hash":"1I7MV48LE0",
								"type":BtnIcon("fontSecondary",28,0,appCfg.sharedAssets+"/btncombo.svg",null),"id":"BtnChooseBot","position":"relative","x":0,"y":0,"display":0,
								"margin":[0,0,0,5],
								"OnClick":function(event){
									self.chooseBot(this,event);
								},
							}
						],
					},
					{
						"hash":"1I7JPUAI70",
						"type":BtnIcon("fontSecondary",30,0,appCfg.sharedAssets+"/hudedit.svg",null),"id":"BtnNewChat","position":"relative","x":0,"y":0,
						"tip":(($ln==="CN")?("新对话"):("New Chat")),
						"OnClick":function(event){
							self.newChat(this,event);
						},
					},
					{
						"hash":"1I7JQIVLA0",
						"type":BtnIcon("fontSecondary",30,0,appCfg.sharedAssets+"/menu.svg",null),"id":"BtnMenu","x":">calc(100% - 35px)","y":"50%","anchorY":1,
						"tip":(($ln==="CN")?("选项"):("Options")),
					}
				],
			},
			{
				"hash":"1I7JOTQAO0",
				"type":"hud","id":"BoxDragSize","x":state.naviBoxW-2,"y":0,"w":5,"h":"100%","cursor":"ew-resize","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
			}
		],
		/*#{1I7H5A7EO1ExtraCSS*/
		/*}#1I7H5A7EO1ExtraCSS*/
		faces:{
			"login":{
				/*BoxLogin*/"#1I7H5K2CV0":{
					"display":1
				},
				/*BoxChatUI*/"#1I7INS8MC0":{
					"display":0
				},
				"#1I7JQEHS80":{
					"display":1
				},
				/*TxtTitle*/"#1I7JQELOR0":{
					"display":1
				},
				"#1I7MV18UD0":{
					"display":0
				},
				/*TxtBotName*/"#1I7MV1PU80":{
					"display":0
				},
				/*BtnChooseBot*/"#1I7MV48LE0":{
					"display":0
				},
				/*BtnNewChat*/"#1I7JPUAI70":{
					"display":0
				},
				/*BtnMenu*/"#1I7JQIVLA0":{
					"display":0
				}
			},"chat":{
				/*BoxLogin*/"#1I7H5K2CV0":{
					"display":0
				},
				/*BoxChatUI*/"#1I7INS8MC0":{
					"display":1
				},
				"#1I7JQEHS80":{
					"display":0
				},
				/*TxtTitle*/"#1I7JQELOR0":{
					"display":0
				},
				"#1I7MV18UD0":{
					"display":1
				},
				/*TxtBotName*/"#1I7MV1PU80":{
					"display":1
				},
				/*BtnChooseBot*/"#1I7MV48LE0":{
					"display":1
				},
				/*BtnNewChat*/"#1I7JPUAI70":{
					"display":1
				},
				/*BtnMenu*/"#1I7JQIVLA0":{
					"display":1
				}
			},"nvChats":{
				/*BoxNVChats*/"#1I7LNVMIK0":{
					"display":1
				},
				/*BoxNVSkills*/"#1I7LO02O90":{
					"display":0
				}
			},"nvSkills":{
				/*BoxNVChats*/"#1I7LNVMIK0":{
					"display":0
				},
				/*BoxNVSkills*/"#1I7LO02O90":{
					"display":1
				}
			}
		},
		OnCreate:function(){
			self=this;
			edUser=self.EdUser;edPassword=self.EdPassword;boxNVChats=self.BoxNVChats;boxNVSkills=self.BoxNVSkills;boxFlowNavi=self.BoxFlowNavi;naviBar=self.NaviBar;dkChats=self.DkChats;txtTitle=self.TxtTitle;txtBotName=self.TxtBotName;btnChooseBot=self.BtnChooseBot;boxDragSize=self.BoxDragSize;
			/*#{1I7H5A7EO1Create*/
			self.showFace("login");
			//Enable drag:
			VFACT.applyMoveDrag(boxDragSize,boxDragSize,true,1,0).setCallbacks(null,null,()=>{
				boxDragSize.x=state.naviBoxW-2;
			},(evt,tgtPxy,pxy)=>{
				let w=boxDragSize.x+2;
				w=w<200?200:w;
				w=w>500?500:w;
				state.naviBoxW=w;
			});
			app.on("NewChatFlow",self.OnNewChatFlow);
			/*}#1I7H5A7EO1Create*/
		},
		/*#{1I7H5A7EO1EndCSS*/
		/*}#1I7H5A7EO1EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.login=async function(){
		/*#{1I7JR58470Start*/
		let pswd,bot,bots;
		userId=edUser.text;
		pswd=edPassword.text;
		user=new AAUser();
		try{
			await user.login(userId,pswd);
			await user.startMessageClient();
		}catch(err){
			window.alert(`Login team error: ${err}`);
			user=null;
			return;
		}
		bots=user.botScope;
		bot=user.curChatBot;
		if(bot){
			txtBotName.text=bot.name;
		}
		if(bots.length>1){
			btnChooseBot.display=true;
		}
		self.showFace("chat");
		self.newChat();
		/*}#1I7JR58470Start*/
	};
	//------------------------------------------------------------------------
	cssVO.newChat=async function(){
		/*#{1I7JR5JEH0Start*/
		let chatFlow,chatUI,def;
		chatFlow=AAChatFlow.emptyFlow;
		if(chatFlow){
			//TODO: Active it's UI
		}
		chatFlow=await AAChatFlow.newFlow(userId);
		//Add new UIBotChat into DKChats:
		def=UIBotChat(user,chatFlow,{});
		chatUI=dkChats.showNewUI(def);
		chatUI.hold();
		/*}#1I7JR5JEH0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.OnNewChatFlow=async function(chatFlow){
		/*#{1I7SOLM4T0Start*/
		let title,btn;
		title=chatFlow.getTitle();
		btn=boxNVChats.appendNewChild({
			type:BtnChatFlow(chatFlow.id,title,cfgColor.fontBody,null,null,txtSize.smallPlus,false,0,cfgColor.secondary),
			chatFlow:chatFlow,
			OnClick(evt){
				if(evt.button===0){
					self.OnChatBtnClick(this);
				}else{
					self.showChatFlowMenu(this);
				}
			}
		});
		btn.webObj.addEventListener('contextmenu', function(event) {
			event.preventDefault();
		});
		chatFlow.chatBtn=btn;
		if(dkChats.curUI===chatFlow.chatUI){
			self.OnChatBtnClick(btn);
		}
		/*}#1I7SOLM4T0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.OnChatBtnClick=async function(btn){
		/*#{1I7SSTAGQ0Start*/
		let chatFlow=btn.chatFlow;
		if(hotChatFlowBtn){
			hotChatFlowBtn.showFace("blur");
		}
		hotChatFlowBtn=btn;
		if(btn){
			btn.showFace("focus");
		}
		dkChats.showUI(chatFlow.chatUI);
		/*}#1I7SSTAGQ0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.chooseBot=async function(){
		/*#{1I7U0FJUB0Start*/
		let items,item,bots;
		items=user.botScope.map((item)=>{
			return {text:item.name,bot:item.id};
		});
		item=await app.modalDlg("/@StdUI/ui/DlgMenu.js",{
			hud:btnChooseBot,
			items:items,
		});
		if(item){
			user.setChatBot(item.bot);
			txtBotName.text=item.text;
		}
		/*}#1I7U0FJUB0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.showChatFlowMenu=async function(btn){
		/*#{1I7U631HV0Start*/
		/*}#1I7U631HV0Start*/
		{
			let $items,$item;
			$items=[
				{id:"rename",text:(($ln==="CN")?("重新命名"):("Rename")),icon:appCfg.sharedAssets+"/edit.svg"},
				{id:"delete",text:(($ln==="CN")?("删除"):("Delete")),icon:appCfg.sharedAssets+"/trash.svg"},
				{id:"skill",text:(($ln==="CN")?("用这个对话创建新技能"):("New skill based on this chat")),icon:appCfg.sharedAssets+"/gas_e.svg",enable:false}
			];
			$item=await VFACT.app.modalDlg("/@StdUI/ui/DlgMenu.js",{hud:btn,items:$items});
			if($item){
				if($item.id==="rename"){
					/*#{1I7U63VQB0*/
					self.renameChatFlow(btn.chatFlow);
					/*}#1I7U63VQB0*/
				}else if($item.id==="delete"){
					/*#{1I7U63VQC0*/
					self.deleteChatFlow(btn.chatFlow);
					/*}#1I7U63VQC0*/
				}else if($item.id==="skill"){
					/*#{1I7U63VQC1*/
					//TODO: Code this;
					/*}#1I7U63VQC1*/
				}
			}
		}
	};
	//------------------------------------------------------------------------
	cssVO.renameChatFlow=async function(chatFlow){
		/*#{1I7U74K1D0Start*/
		let newName,btn;
		//newName=window.prompt("Input new chat name",chatFlow.getTitle());
		newName=await app.modalDlg("/@StdUI/ui/DlgPrompt.js",{title:(($ln==="CN")?("输入新对话名称"):/*EN*/("Input new chat name")),text:chatFlow.getTitle()});
		if(newName){
			chatFlow.setTitle(newName);
		}
		/*}#1I7U74K1D0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.deleteChatFlow=async function(chatFlow){
		/*#{1I7U8NJUJ0Start*/
		if(!window.confirm((($ln==="CN")?("你确定要删除这个对话吗?"):/*EN*/("Are you sure to delete this chat?")))){
			return;
		}
		if(await AAChatFlow.deleteFlow(chatFlow.id)){
			let ui,btn;
			ui=chatFlow.chatUI;
			btn=chatFlow.chatBtn;
			if(ui){
				await dkChats.dismissUI(ui,true);
				ui.release();
			}
			if(btn){
				boxNVChats.removeChild(btn);
			}
			ui=dkChats.curUI;
			if(ui){
				chatFlow=ui.chatFlow;
				btn=chatFlow.chatBtn;
				self.OnChatBtnClick(btn);
			}else{
				self.newChat();
			}
		}
		/*}#1I7U8NJUJ0Start*/
	};
	/*#{1I7H5A7EO1PostCSSVO*/
	/*}#1I7H5A7EO1PostCSSVO*/
	cssVO.constructor=UserClientUI;
	return cssVO;
};
/*#{1I7H5A7EO1ExCodes*/
/*}#1I7H5A7EO1ExCodes*/

//----------------------------------------------------------------------------
UserClientUI.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1I7H5A7EO1PreAISpot*/
	/*}#1I7H5A7EO1PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1I7H5A7EO1PostAISpot*/
	/*}#1I7H5A7EO1PostAISpot*/
	return exposeVO;
};

/*#{1I7H5A7EO0EndDoc*/
/*}#1I7H5A7EO0EndDoc*/

export default UserClientUI;
export{UserClientUI};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1I7H5A7EO0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1I7H5A7EP0",
//			"attrs": {
//				"device": "Desktop 800x600",
//				"screenW": "800",
//				"screenH": "600",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1I7H5A7EP1",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1I7H5A7EP2",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1I7H5A7EP3",
//			"attrs": {}
//		},
//		"localVars": {
//			"jaxId": "1I7H5A7EP4",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1I7H5A7EP5",
//			"attrs": {
//				"naviBoxW": {
//					"type": "int",
//					"valText": "240"
//				}
//			}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I7JR58470",
//					"attrs": {
//						"id": "login",
//						"label": "New AI Seg",
//						"x": "70",
//						"y": "70",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I7JR5RC50",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I7JR5RC51",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I7JR5RC52",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I7JR5JEH0",
//					"attrs": {
//						"id": "newChat",
//						"label": "New AI Seg",
//						"x": "70",
//						"y": "160",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I7JR5RC53",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I7JR5RC54",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I7JR5RC55",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I7SOLM4T0",
//					"attrs": {
//						"id": "OnNewChatFlow",
//						"label": "New AI Seg",
//						"x": "70",
//						"y": "250",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I7SOM0UG0",
//							"attrs": {
//								"chatFlow": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I7SOM0UG1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I7SOM0UG2",
//							"attrs": {
//								"id": "Next",
//								"desc": "Outlet."
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I7SSTAGQ0",
//					"attrs": {
//						"id": "OnChatBtnClick",
//						"label": "New AI Seg",
//						"x": "70",
//						"y": "330",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I7SSTLJ40",
//							"attrs": {
//								"btn": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I7SSTLJ41",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I7SSTLJ42",
//							"attrs": {
//								"id": "Next",
//								"desc": "Outlet."
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I7U0FJUB0",
//					"attrs": {
//						"id": "chooseBot",
//						"label": "New AI Seg",
//						"x": "70",
//						"y": "420",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I7U0UR1J0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I7U0UR1J1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I7U0UR1J2",
//							"attrs": {
//								"id": "Next",
//								"desc": "Outlet."
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I7U631HV0",
//					"attrs": {
//						"id": "showChatFlowMenu",
//						"label": "New AI Seg",
//						"x": "70",
//						"y": "510",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I7U66PHQ0",
//							"attrs": {
//								"btn": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I7U66PHQ1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": [
//								{
//									"type": "flowseg",
//									"def": "Menu",
//									"jaxId": "1I7U66PHQ2",
//									"attrs": {
//										"id": "menu",
//										"label": "New AI Seg",
//										"x": "325",
//										"y": "510",
//										"desc": "",
//										"codes": "false",
//										"launcher": "btn",
//										"outlets": {
//											"attrs": [
//												{
//													"type": "aioutlet",
//													"def": "MenuItem",
//													"jaxId": "1I7U63VQB0",
//													"attrs": {
//														"id": "rename",
//														"text": {
//															"type": "string",
//															"valText": "Rename",
//															"localize": {
//																"EN": "Rename",
//																"CN": "重新命名"
//															},
//															"localizable": true
//														},
//														"desc": "",
//														"icon": "#appCfg.sharedAssets+\"/edit.svg\""
//													}
//												},
//												{
//													"type": "aioutlet",
//													"def": "MenuItem",
//													"jaxId": "1I7U63VQC0",
//													"attrs": {
//														"id": "delete",
//														"text": {
//															"type": "string",
//															"valText": "Delete",
//															"localize": {
//																"EN": "Delete",
//																"CN": "删除"
//															},
//															"localizable": true
//														},
//														"desc": "",
//														"icon": "#appCfg.sharedAssets+\"/trash.svg\""
//													}
//												},
//												{
//													"type": "aioutlet",
//													"def": "MenuItem",
//													"jaxId": "1I7U63VQC1",
//													"attrs": {
//														"id": "skill",
//														"text": {
//															"type": "string",
//															"valText": "New skill based on this chat",
//															"localize": {
//																"EN": "New skill based on this chat",
//																"CN": "用这个对话创建新技能"
//															},
//															"localizable": true
//														},
//														"desc": "",
//														"enable": "false",
//														"icon": "#appCfg.sharedAssets+\"/gas_e.svg\""
//													}
//												}
//											]
//										},
//										"outlet": {
//											"jaxId": "1I7U66PHQ3",
//											"attrs": {
//												"id": "Next",
//												"desc": "Outlet."
//											}
//										}
//									},
//									"icon": "menu.svg",
//									"reverseOutlets": true
//								}
//							]
//						},
//						"outlet": {
//							"jaxId": "1I7U66PHQ4",
//							"attrs": {
//								"id": "Next",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I7U66PHQ2"
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I7U74K1D0",
//					"attrs": {
//						"id": "renameChatFlow",
//						"label": "New AI Seg",
//						"x": "70",
//						"y": "610",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I7U75Q6N0",
//							"attrs": {
//								"chatFlow": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I7U75Q6N1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I7U75Q6N2",
//							"attrs": {
//								"id": "Next",
//								"desc": "Outlet."
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I7U8NJUJ0",
//					"attrs": {
//						"id": "deleteChatFlow",
//						"label": "New AI Seg",
//						"x": "70",
//						"y": "700",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I7U8OAG50",
//							"attrs": {
//								"chatFlow": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1I7U8OAG51",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I7U8OAG52",
//							"attrs": {
//								"id": "Next",
//								"desc": "Outlet."
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				}
//			]
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1I7H5A7EP6",
//			"attrs": {
//				"login": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1I7H6EMDG0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1I7H6G21G0",
//							"attrs": {}
//						}
//					}
//				},
//				"chat": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1I7H6ET9K0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1I7H6G21G1",
//							"attrs": {}
//						}
//					}
//				},
//				"nvChats": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1I7LO43L80",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1I7LO77KJ0",
//							"attrs": {}
//						}
//					}
//				},
//				"nvSkills": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1I7LO4AVC0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1I7LO77KJ1",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1I7H5A7EP7",
//			"attrs": {}
//		},
//		"exposeToAI": "true",
//		"descAI": "",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1I7H5A7EO1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1I7H5A7EP8",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "100%",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "On",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": ""
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1I7H5J1LI0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I7H5L8RV0",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxBody",
//										"position": "Absolute",
//										"x": "0",
//										"y": "40",
//										"w": "100%",
//										"h": "100%-40",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": ""
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1I7H5K2CV0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I7H5L8RV1",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxLogin",
//														"position": "Absolute",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "60%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "Off",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex Y",
//														"subAlign": "Center",
//														"itemsAlign": "Center"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1I7H5VC540",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I7H64JC30",
//																	"attrs": {
//																		"type": "hud",
//																		"id": "BoxUser",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "200",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[0,0,10,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"subAlign": "Start",
//																		"contentLayout": "Flex Y",
//																		"itemsAlign": "Start"
//																	}
//																},
//																"subHuds": {
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "text",
//																			"jaxId": "1I7H62TNF0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I7H64JC31",
//																					"attrs": {
//																						"type": "text",
//																						"id": "",
//																						"position": "relative",
//																						"x": "-20",
//																						"y": "0",
//																						"w": "100%",
//																						"h": "",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"color": "#cfgColor[\"fontBody\"]",
//																						"text": {
//																							"type": "string",
//																							"valText": "User account:",
//																							"localize": {
//																								"EN": "User account:",
//																								"CN": "用户帐号:"
//																							},
//																							"localizable": true
//																						},
//																						"font": "",
//																						"fontSize": "#txtSize.small",
//																						"bold": "false",
//																						"italic": "false",
//																						"underline": "false",
//																						"alignH": "Left",
//																						"alignV": "Top",
//																						"wrap": "false",
//																						"ellipsis": "false",
//																						"lineClamp": "0",
//																						"select": "false",
//																						"shadow": "false",
//																						"shadowX": "0",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowColor": "[0,0,0,1.00]",
//																						"shadowEx": "",
//																						"maxTextW": "0"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1I7H64JC32",
//																					"attrs": {
//																						"1I7LO43L80": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1I7LO77KK0",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1I7LO77KK1",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1I7LO43L80",
//																							"faceTagName": "nvChats"
//																						},
//																						"1I7H6ET9K0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1I7MV6TSE0",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1I7MV6TSE1",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1I7H6ET9K0",
//																							"faceTagName": "chat"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1I7H64JC33",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1I7H64JC34",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "edit",
//																			"jaxId": "1I7H607FS0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I7H607FS1",
//																					"attrs": {
//																						"type": "edit",
//																						"id": "EdUser",
//																						"position": "Relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "200",
//																						"h": "20",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"inputType": "Text",
//																						"text": "admin",
//																						"placeHolder": "User Account",
//																						"color": "[0,0,0]",
//																						"bgColor": "[255,255,255,1.00]",
//																						"font": "",
//																						"fontSize": "16",
//																						"outline": "0",
//																						"border": "[0,0,1,0]",
//																						"borderStyle": "Solid",
//																						"borderColor": "[0,0,0,1.00]",
//																						"corner": "0",
//																						"selectOnFocus": "true",
//																						"spellCheck": "true"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1I7H607FS2",
//																					"attrs": {
//																						"1I7LO43L80": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1I7LO77KK2",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1I7LO77KK3",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1I7LO43L80",
//																							"faceTagName": "nvChats"
//																						},
//																						"1I7H6ET9K0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1I7MV6TSE2",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1I7MV6TSE3",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1I7H6ET9K0",
//																							"faceTagName": "chat"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1I7H607FS3",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1I7H607FS4",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "true"
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"jaxId": "1I7H64JC35",
//																	"attrs": {
//																		"1I7LO43L80": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I7LO77KK4",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I7LO77KK5",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I7LO43L80",
//																			"faceTagName": "nvChats"
//																		},
//																		"1I7H6ET9K0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I7MV6TSE4",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I7MV6TSE5",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I7H6ET9K0",
//																			"faceTagName": "chat"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1I7H64JC36",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1I7H64JC37",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false",
//																"exposeContainer": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1I7H65G320",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I7H65G330",
//																	"attrs": {
//																		"type": "hud",
//																		"id": "BoxPassword",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "200",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[0,0,16,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"subAlign": "Start",
//																		"contentLayout": "Flex Y",
//																		"itemsAlign": "Start"
//																	}
//																},
//																"subHuds": {
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "text",
//																			"jaxId": "1I7H65G331",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I7H65G332",
//																					"attrs": {
//																						"type": "text",
//																						"id": "",
//																						"position": "relative",
//																						"x": "-20",
//																						"y": "0",
//																						"w": "100%",
//																						"h": "",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"color": "#cfgColor[\"fontBody\"]",
//																						"text": {
//																							"type": "string",
//																							"valText": "Password: ",
//																							"localize": {
//																								"EN": "Password: ",
//																								"CN": "密码:"
//																							},
//																							"localizable": true
//																						},
//																						"font": "",
//																						"fontSize": "#txtSize.small",
//																						"bold": "false",
//																						"italic": "false",
//																						"underline": "false",
//																						"alignH": "Left",
//																						"alignV": "Top",
//																						"wrap": "false",
//																						"ellipsis": "false",
//																						"lineClamp": "0",
//																						"select": "false",
//																						"shadow": "false",
//																						"shadowX": "0",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowColor": "[0,0,0,1.00]",
//																						"shadowEx": "",
//																						"maxTextW": "0"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1I7H65G340",
//																					"attrs": {
//																						"1I7LO43L80": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1I7LO77KK6",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1I7LO77KK7",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1I7LO43L80",
//																							"faceTagName": "nvChats"
//																						},
//																						"1I7H6ET9K0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1I7MV6TSE6",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1I7MV6TSE7",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1I7H6ET9K0",
//																							"faceTagName": "chat"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1I7H65G341",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1I7H65G342",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "edit",
//																			"jaxId": "1I7H65G343",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I7H65G344",
//																					"attrs": {
//																						"type": "edit",
//																						"id": "EdPassword",
//																						"position": "Relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "200",
//																						"h": "20",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"inputType": "Password",
//																						"text": "",
//																						"placeHolder": "",
//																						"color": "[0,0,0]",
//																						"bgColor": "[255,255,255,1.00]",
//																						"font": "",
//																						"fontSize": "16",
//																						"outline": "0",
//																						"border": "[0,0,1,0]",
//																						"borderStyle": "Solid",
//																						"borderColor": "[0,0,0,1.00]",
//																						"corner": "0",
//																						"selectOnFocus": "true",
//																						"spellCheck": "true",
//																						"pattern": ""
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1I7H65G345",
//																					"attrs": {
//																						"1I7LO43L80": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1I7LO77KK8",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1I7LO77KK9",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1I7LO43L80",
//																							"faceTagName": "nvChats"
//																						},
//																						"1I7H6ET9K0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1I7MV6TSE8",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1I7MV6TSE9",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1I7H6ET9K0",
//																							"faceTagName": "chat"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1I7H65G346",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1I7H65G347",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "true"
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"jaxId": "1I7H65G348",
//																	"attrs": {
//																		"1I7LO43L80": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I7LO77KK10",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I7LO77KK11",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I7LO43L80",
//																			"faceTagName": "nvChats"
//																		},
//																		"1I7H6ET9K0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I7MV6TSE10",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I7MV6TSE11",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I7H6ET9K0",
//																			"faceTagName": "chat"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1I7H65G349",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1I7H65G3410",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false",
//																"exposeContainer": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnText.js",
//															"jaxId": "1I7H690I30",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1I7H6BMDO0",
//																	"attrs": {
//																		"style": "primary",
//																		"w": "100",
//																		"h": "25",
//																		"text": {
//																			"type": "string",
//																			"valText": "Login",
//																			"localize": {
//																				"EN": "Login",
//																				"CN": "登录"
//																			},
//																			"localizable": true
//																		},
//																		"outlined": "false",
//																		"icon": ""
//																	}
//																},
//																"properties": {
//																	"jaxId": "1I7H6BMDO1",
//																	"attrs": {
//																		"type": "#null#>BtnText(\"primary\",100,25,(($ln===\"CN\")?(\"登录\"):(\"Login\")),false,\"\")",
//																		"id": "BtnLogin",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1I7H6BMDO2",
//																	"attrs": {
//																		"1I7LO43L80": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I7LO77KK12",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I7LO77KK13",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I7LO43L80",
//																			"faceTagName": "nvChats"
//																		},
//																		"1I7H6ET9K0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I7MV6TSE12",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I7MV6TSE13",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I7H6ET9K0",
//																			"faceTagName": "chat"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1I7H6BMDO3",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1I7LNAMTP0",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1I7LNAMTP1",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": "1I7JR58470"
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1I7H6BMDO4",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1I7H6BMDO5",
//																	"attrs": {
//																		"Slot1H2F6U36O0": {
//																			"jaxId": "1I7H6BMDO6",
//																			"attrs": {
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"container": "true"
//																			}
//																		}
//																	}
//																}
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1I7H5L8RV2",
//													"attrs": {
//														"1I7H6EMDG0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I7LN46QF28",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I7LN46QF29",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I7H6EMDG0",
//															"faceTagName": "login"
//														},
//														"1I7H6ET9K0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I7LN46QF30",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I7LN46QF31",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I7H6ET9K0",
//															"faceTagName": "chat"
//														},
//														"1I7LO43L80": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I7LO77KK14",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I7LO77KK15",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I7LO43L80",
//															"faceTagName": "nvChats"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I7H5L8RV3",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I7H5L8RV4",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1I7INS8MC0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I7IO89OE0",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxChatUI",
//														"position": "Absolute",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex X"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "box",
//															"jaxId": "1I7INU0C40",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I7IO89OE1",
//																	"attrs": {
//																		"type": "box",
//																		"id": "BoxNavi",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "${state.naviBoxW},state",
//																		"h": "100%",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"background": "#cfgColor[\"toolBG\"]",
//																		"border": "[0,0,0,0]",
//																		"borderStyle": "Solid",
//																		"borderColor": "[0,0,0,1.00]",
//																		"corner": "0",
//																		"shadow": "false",
//																		"shadowX": "2",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowSpread": "0",
//																		"shadowColor": "[0,0,0,0.50]"
//																	}
//																},
//																"subHuds": {
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "hud",
//																			"jaxId": "1I7JDET5M0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I7JDGC190",
//																					"attrs": {
//																						"type": "hud",
//																						"id": "NaviViews",
//																						"position": "Absolute",
//																						"x": "0",
//																						"y": "32",
//																						"w": "100%",
//																						"h": "100%-32",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": ""
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": [
//																						{
//																							"type": "hudobj",
//																							"def": "hud",
//																							"jaxId": "1I7LNVMIK0",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1I7LO01U70",
//																									"attrs": {
//																										"type": "hud",
//																										"id": "BoxNVChats",
//																										"position": "Absolute",
//																										"x": "0",
//																										"y": "0",
//																										"w": "100%",
//																										"h": "100%",
//																										"anchorH": "Left",
//																										"anchorV": "Top",
//																										"autoLayout": "false",
//																										"display": "On",
//																										"clip": "Auto Scroll Y",
//																										"uiEvent": "On",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "",
//																										"zIndex": "0",
//																										"margin": "",
//																										"padding": "5",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": "",
//																										"contentLayout": "Flex YR",
//																										"subAlign": "End"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": [
//																										{
//																											"type": "hudobj",
//																											"def": "Gear1I7PSN1M10",
//																											"jaxId": "1I7PT088P0",
//																											"attrs": {
//																												"createArgs": {
//																													"jaxId": "1I7PT0RA20",
//																													"attrs": {
//																														"code": "Home",
//																														"text": "Home",
//																														"color": "[0,0,0,1.00]",
//																														"icon": "",
//																														"items": "",
//																														"fontSize": "#txtSize.smallPlus",
//																														"hasClose": "false",
//																														"iconSize": "0",
//																														"mark": "#cfgColor.secondary"
//																													}
//																												},
//																												"properties": {
//																													"jaxId": "1I7PT0RA21",
//																													"attrs": {
//																														"type": "#null#>BtnChatFlow(\"Home\",\"Home\",[0,0,0,1],\"\",undefined,txtSize.smallPlus,false,0,cfgColor.secondary)",
//																														"id": "",
//																														"position": "relative",
//																														"x": "0",
//																														"y": "0",
//																														"display": "On",
//																														"face": "",
//																														"h": "30",
//																														"markNum": {
//																															"type": "int",
//																															"valText": "0"
//																														}
//																													}
//																												},
//																												"subHuds": {
//																													"attrs": []
//																												},
//																												"faces": {
//																													"jaxId": "1I7PT0RA22",
//																													"attrs": {}
//																												},
//																												"functions": {
//																													"jaxId": "1I7PT0RA23",
//																													"attrs": {}
//																												},
//																												"extraPpts": {
//																													"jaxId": "1I7PT0RA24",
//																													"attrs": {}
//																												},
//																												"mockup": "true",
//																												"codes": "false",
//																												"locked": "false",
//																												"container": "false",
//																												"nameVal": "false",
//																												"containerSlots": {
//																													"jaxId": "1I7PT0RA25",
//																													"attrs": {}
//																												}
//																											}
//																										}
//																									]
//																								},
//																								"faces": {
//																									"jaxId": "1I7LO01U71",
//																									"attrs": {
//																										"1I7LO4AVC0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1I7LO77KK16",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1I7LO77KK17",
//																													"attrs": {
//																														"display": {
//																															"type": "choice",
//																															"valText": "Off"
//																														}
//																													}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1I7LO4AVC0",
//																											"faceTagName": "nvSkills"
//																										},
//																										"1I7LO43L80": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1I7LO77KK18",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1I7LO77KK19",
//																													"attrs": {
//																														"display": {
//																															"type": "choice",
//																															"valText": "On"
//																														}
//																													}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1I7LO43L80",
//																											"faceTagName": "nvChats"
//																										},
//																										"1I7H6ET9K0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1I7MV6TSE14",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1I7MV6TSE15",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1I7H6ET9K0",
//																											"faceTagName": "chat"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1I7LO01U72",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1I7LO01U73",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "true",
//																								"nameVal": "true",
//																								"exposeContainer": "false"
//																							}
//																						},
//																						{
//																							"type": "hudobj",
//																							"def": "hud",
//																							"jaxId": "1I7LO02O90",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1I7LO02O91",
//																									"attrs": {
//																										"type": "hud",
//																										"id": "BoxNVSkills",
//																										"position": "Absolute",
//																										"x": "0",
//																										"y": "0",
//																										"w": "100%",
//																										"h": "100%",
//																										"anchorH": "Left",
//																										"anchorV": "Top",
//																										"autoLayout": "false",
//																										"display": "Off",
//																										"clip": "Auto Scroll Y",
//																										"uiEvent": "On",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "",
//																										"zIndex": "0",
//																										"margin": "",
//																										"padding": "",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": "",
//																										"contentLayout": "Flex Y"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1I7LO02O92",
//																									"attrs": {
//																										"1I7LO4AVC0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1I7LO77KK20",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1I7LO77KK21",
//																													"attrs": {
//																														"display": {
//																															"type": "choice",
//																															"valText": "On"
//																														}
//																													}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1I7LO4AVC0",
//																											"faceTagName": "nvSkills"
//																										},
//																										"1I7LO43L80": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1I7LO77KK22",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1I7LO77KK23",
//																													"attrs": {
//																														"display": {
//																															"type": "choice",
//																															"valText": "Off"
//																														}
//																													}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1I7LO43L80",
//																											"faceTagName": "nvChats"
//																										},
//																										"1I7H6ET9K0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1I7MV6TSE16",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1I7MV6TSE17",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1I7H6ET9K0",
//																											"faceTagName": "chat"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1I7LO02O93",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1I7LO02O94",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "true",
//																								"nameVal": "true",
//																								"exposeContainer": "false"
//																							}
//																						}
//																					]
//																				},
//																				"faces": {
//																					"jaxId": "1I7JDGC191",
//																					"attrs": {
//																						"1I7LO43L80": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1I7LO77KK24",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1I7LO77KK25",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1I7LO43L80",
//																							"faceTagName": "nvChats"
//																						},
//																						"1I7H6ET9K0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1I7MV6TSE18",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1I7MV6TSE19",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1I7H6ET9K0",
//																							"faceTagName": "chat"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1I7JDGC192",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1I7JDGC193",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "false",
//																				"exposeContainer": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "box",
//																			"jaxId": "1I7IOKBMD0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I7IOKBMD1",
//																					"attrs": {
//																						"type": "box",
//																						"id": "BoxFlowNavi",
//																						"position": "Absolute",
//																						"x": "0",
//																						"y": "0",
//																						"w": "100%",
//																						"h": "32",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "0",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"background": "#cfgColor[\"toolBG\"]",
//																						"border": "[0,0,0,0]",
//																						"borderStyle": "Solid",
//																						"borderColor": "[0,0,0,0.38]",
//																						"corner": "0",
//																						"shadow": "true",
//																						"shadowX": "0",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowSpread": "0",
//																						"shadowColor": "[0,0,0,0.50]",
//																						"contentLayout": "Flex X"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": [
//																						{
//																							"type": "hudobj",
//																							"def": "Gear/@StdUI/ui/NaviToolBar.js",
//																							"jaxId": "1I7IOKBMD2",
//																							"attrs": {
//																								"createArgs": {
//																									"jaxId": "1I7IOKBMD3",
//																									"attrs": {
//																										"tabBG": "false"
//																									}
//																								},
//																								"properties": {
//																									"jaxId": "1I7IOKBMD4",
//																									"attrs": {
//																										"type": "#null#>NaviToolBar(false)",
//																										"id": "NaviBar",
//																										"position": "Relative",
//																										"x": "0",
//																										"y": "0",
//																										"display": "On",
//																										"face": "\"top\""
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1I7IOKBME0",
//																									"attrs": {
//																										"1I7LO43L80": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1I7LO77KK26",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1I7LO77KK27",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1I7LO43L80",
//																											"faceTagName": "nvChats"
//																										},
//																										"1I7H6ET9K0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1I7MV6TSE20",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1I7MV6TSE21",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1I7H6ET9K0",
//																											"faceTagName": "chat"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1I7IOKBME1",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1I7IOKBME2",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "true",
//																								"containerSlots": {
//																									"jaxId": "1I7IOKBME3",
//																									"attrs": {
//																										"Slot1HL4P0I9P0": {
//																											"jaxId": "1I7IOKBME4",
//																											"attrs": {
//																												"subHuds": {
//																													"attrs": [
//																														{
//																															"type": "hudobj",
//																															"def": "Gear/@StdUI/ui/BtnNaviItem.js",
//																															"jaxId": "1I7IOKBME5",
//																															"attrs": {
//																																"createArgs": {
//																																	"jaxId": "1I7IOKBME6",
//																																	"attrs": {
//																																		"code": "Home",
//																																		"text": "Dialogs",
//																																		"color": "[0,0,0,1.00]",
//																																		"icon": "#appCfg.sharedAssets+\"/chat.svg\"",
//																																		"items": "",
//																																		"fontSize": "12",
//																																		"hasClose": "false",
//																																		"iconSize": "24",
//																																		"mark": "false"
//																																	}
//																																},
//																																"properties": {
//																																	"jaxId": "1I7IOKBME7",
//																																	"attrs": {
//																																		"type": "#null#>BtnNaviItem(\"Home\",\"Dialogs\",[0,0,0,1],appCfg.sharedAssets+\"/chat.svg\",undefined,12,false,24,false)",
//																																		"id": "",
//																																		"position": "relative",
//																																		"x": "0",
//																																		"y": "0",
//																																		"display": "On",
//																																		"face": "",
//																																		"margin": "[0,10,0,0]"
//																																	}
//																																},
//																																"subHuds": {
//																																	"attrs": []
//																																},
//																																"faces": {
//																																	"jaxId": "1I7IOKBME8",
//																																	"attrs": {
//																																		"1I7H6EMDG0": {
//																																			"type": "hudface",
//																																			"def": "HudFace",
//																																			"jaxId": "1I7LN46QF40",
//																																			"attrs": {
//																																				"properties": {
//																																					"jaxId": "1I7LN46QF41",
//																																					"attrs": {}
//																																				},
//																																				"anis": {
//																																					"attrs": []
//																																				}
//																																			},
//																																			"faceTagId": "1I7H6EMDG0",
//																																			"faceTagName": "login"
//																																		},
//																																		"1I7H6ET9K0": {
//																																			"type": "hudface",
//																																			"def": "HudFace",
//																																			"jaxId": "1I7LN46QF42",
//																																			"attrs": {
//																																				"properties": {
//																																					"jaxId": "1I7LN46QF43",
//																																					"attrs": {}
//																																				},
//																																				"anis": {
//																																					"attrs": []
//																																				}
//																																			},
//																																			"faceTagId": "1I7H6ET9K0",
//																																			"faceTagName": "chat"
//																																		},
//																																		"1I7LO43L80": {
//																																			"type": "hudface",
//																																			"def": "HudFace",
//																																			"jaxId": "1I7LO77KK28",
//																																			"attrs": {
//																																				"properties": {
//																																					"jaxId": "1I7LO77KK29",
//																																					"attrs": {}
//																																				},
//																																				"anis": {
//																																					"attrs": []
//																																				}
//																																			},
//																																			"faceTagId": "1I7LO43L80",
//																																			"faceTagName": "nvChats"
//																																		},
//																																		"1I7LO4AVC0": {
//																																			"type": "hudface",
//																																			"def": "HudFace",
//																																			"jaxId": "1I7LO77KK30",
//																																			"attrs": {
//																																				"properties": {
//																																					"jaxId": "1I7LO77KK31",
//																																					"attrs": {}
//																																				},
//																																				"anis": {
//																																					"attrs": []
//																																				}
//																																			},
//																																			"faceTagId": "1I7LO4AVC0",
//																																			"faceTagName": "nvSkills"
//																																		}
//																																	}
//																																},
//																																"functions": {
//																																	"jaxId": "1I7IOKBME9",
//																																	"attrs": {
//																																		"OnClick": {
//																																			"type": "fixedFunc",
//																																			"jaxId": "1I7IOKBME10",
//																																			"attrs": {
//																																				"callArgs": {
//																																					"jaxId": "1I7IOKBME11",
//																																					"attrs": {
//																																						"event": ""
//																																					}
//																																				},
//																																				"seg": ""
//																																			}
//																																		}
//																																	}
//																																},
//																																"extraPpts": {
//																																	"jaxId": "1I7IOKBME12",
//																																	"attrs": {}
//																																},
//																																"mockup": "false",
//																																"codes": "false",
//																																"locked": "false",
//																																"container": "false",
//																																"nameVal": "false",
//																																"containerSlots": {
//																																	"jaxId": "1I7IOKBME13",
//																																	"attrs": {}
//																																}
//																															}
//																														},
//																														{
//																															"type": "hudobj",
//																															"def": "Gear/@StdUI/ui/BtnNaviItem.js",
//																															"jaxId": "1I7JB9EIV0",
//																															"attrs": {
//																																"createArgs": {
//																																	"jaxId": "1I7JB9EIV1",
//																																	"attrs": {
//																																		"code": "Home",
//																																		"text": "Skills",
//																																		"color": "[0,0,0,1.00]",
//																																		"icon": "#appCfg.sharedAssets+\"/gas_e.svg\"",
//																																		"items": "",
//																																		"fontSize": "12",
//																																		"hasClose": "false",
//																																		"iconSize": "24",
//																																		"mark": "false"
//																																	}
//																																},
//																																"properties": {
//																																	"jaxId": "1I7JB9EIV2",
//																																	"attrs": {
//																																		"type": "#null#>BtnNaviItem(\"Home\",\"Skills\",[0,0,0,1],appCfg.sharedAssets+\"/gas_e.svg\",undefined,12,false,24,false)",
//																																		"id": "",
//																																		"position": "relative",
//																																		"x": "0",
//																																		"y": "0",
//																																		"display": "On",
//																																		"face": "",
//																																		"margin": "[0,10,0,0]",
//																																		"enable": "false"
//																																	}
//																																},
//																																"subHuds": {
//																																	"attrs": []
//																																},
//																																"faces": {
//																																	"jaxId": "1I7JB9EJ00",
//																																	"attrs": {
//																																		"1I7H6EMDG0": {
//																																			"type": "hudface",
//																																			"def": "HudFace",
//																																			"jaxId": "1I7LN46QF44",
//																																			"attrs": {
//																																				"properties": {
//																																					"jaxId": "1I7LN46QF45",
//																																					"attrs": {}
//																																				},
//																																				"anis": {
//																																					"attrs": []
//																																				}
//																																			},
//																																			"faceTagId": "1I7H6EMDG0",
//																																			"faceTagName": "login"
//																																		},
//																																		"1I7H6ET9K0": {
//																																			"type": "hudface",
//																																			"def": "HudFace",
//																																			"jaxId": "1I7LN46QF46",
//																																			"attrs": {
//																																				"properties": {
//																																					"jaxId": "1I7LN46QF47",
//																																					"attrs": {}
//																																				},
//																																				"anis": {
//																																					"attrs": []
//																																				}
//																																			},
//																																			"faceTagId": "1I7H6ET9K0",
//																																			"faceTagName": "chat"
//																																		},
//																																		"1I7LO43L80": {
//																																			"type": "hudface",
//																																			"def": "HudFace",
//																																			"jaxId": "1I7LO77KK32",
//																																			"attrs": {
//																																				"properties": {
//																																					"jaxId": "1I7LO77KK33",
//																																					"attrs": {}
//																																				},
//																																				"anis": {
//																																					"attrs": []
//																																				}
//																																			},
//																																			"faceTagId": "1I7LO43L80",
//																																			"faceTagName": "nvChats"
//																																		},
//																																		"1I7LO4AVC0": {
//																																			"type": "hudface",
//																																			"def": "HudFace",
//																																			"jaxId": "1I7LO77KK34",
//																																			"attrs": {
//																																				"properties": {
//																																					"jaxId": "1I7LO77KK35",
//																																					"attrs": {}
//																																				},
//																																				"anis": {
//																																					"attrs": []
//																																				}
//																																			},
//																																			"faceTagId": "1I7LO4AVC0",
//																																			"faceTagName": "nvSkills"
//																																		}
//																																	}
//																																},
//																																"functions": {
//																																	"jaxId": "1I7JB9EJ01",
//																																	"attrs": {
//																																		"OnClick": {
//																																			"type": "fixedFunc",
//																																			"jaxId": "1I7JB9EJ02",
//																																			"attrs": {
//																																				"callArgs": {
//																																					"jaxId": "1I7JB9EJ03",
//																																					"attrs": {
//																																						"event": ""
//																																					}
//																																				},
//																																				"seg": ""
//																																			}
//																																		}
//																																	}
//																																},
//																																"extraPpts": {
//																																	"jaxId": "1I7JB9EJ04",
//																																	"attrs": {}
//																																},
//																																"mockup": "false",
//																																"codes": "false",
//																																"locked": "false",
//																																"container": "false",
//																																"nameVal": "false",
//																																"containerSlots": {
//																																	"jaxId": "1I7JB9EJ05",
//																																	"attrs": {}
//																																}
//																															}
//																														}
//																													]
//																												},
//																												"container": "true"
//																											}
//																										}
//																									}
//																								}
//																							}
//																						}
//																					]
//																				},
//																				"faces": {
//																					"jaxId": "1I7IOKBME14",
//																					"attrs": {
//																						"1I7LO43L80": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1I7LO77KK36",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1I7LO77KK37",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1I7LO43L80",
//																							"faceTagName": "nvChats"
//																						},
//																						"1I7H6ET9K0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1I7MV6TSE22",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1I7MV6TSE23",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1I7H6ET9K0",
//																							"faceTagName": "chat"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1I7IOKBME15",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1I7IOKBME16",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "true"
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"jaxId": "1I7IO89OE2",
//																	"attrs": {
//																		"1I7LO43L80": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I7LO77KK38",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I7LO77KK39",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I7LO43L80",
//																			"faceTagName": "nvChats"
//																		},
//																		"1I7H6ET9K0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I7MV6TSE24",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I7MV6TSE25",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I7H6ET9K0",
//																			"faceTagName": "chat"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1I7IO89OE3",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1I7IO89OE4",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "box",
//															"jaxId": "1I7IO81R60",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I7IO89OE5",
//																	"attrs": {
//																		"type": "box",
//																		"id": "BoxChatFlows",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "",
//																		"h": "100%",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"background": "#cfgColor[\"chatBG\"]",
//																		"border": "0",
//																		"borderStyle": "Solid",
//																		"borderColor": "[0,0,0,1.00]",
//																		"corner": "0",
//																		"shadow": "true",
//																		"shadowX": "0",
//																		"shadowY": "0",
//																		"shadowBlur": "3",
//																		"shadowSpread": "0",
//																		"shadowColor": "[0,0,0,0.50]",
//																		"flex": "true"
//																	}
//																},
//																"subHuds": {
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "dock",
//																			"jaxId": "1I7IOJ3TJ0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I7IOJ3TJ1",
//																					"attrs": {
//																						"type": "dock",
//																						"id": "DkChats",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "100%",
//																						"h": "100%",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"coverAction": "Hide",
//																						"ui": "0"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1I7IOJ3TL7",
//																					"attrs": {
//																						"1I7LO43L80": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1I7LO77KK40",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1I7LO77KK41",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1I7LO43L80",
//																							"faceTagName": "nvChats"
//																						},
//																						"1I7H6ET9K0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1I7MV6TSE26",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1I7MV6TSE27",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1I7H6ET9K0",
//																							"faceTagName": "chat"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1I7IOJ3TL8",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1I7IOJ3TL9",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "true"
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"jaxId": "1I7IO89OE6",
//																	"attrs": {
//																		"1I7LO43L80": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I7LO77KK42",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I7LO77KK43",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I7LO43L80",
//																			"faceTagName": "nvChats"
//																		},
//																		"1I7H6ET9K0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I7MV6TSE28",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I7MV6TSE29",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I7H6ET9K0",
//																			"faceTagName": "chat"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1I7IO89OE7",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1I7IO89OE8",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false"
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1I7IO89OE9",
//													"attrs": {
//														"1I7H6EMDG0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I7LN46QF64",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I7LN46QF65",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I7H6EMDG0",
//															"faceTagName": "login"
//														},
//														"1I7H6ET9K0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I7LN46QF66",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I7LN46QF67",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I7H6ET9K0",
//															"faceTagName": "chat"
//														},
//														"1I7LO43L80": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I7LO77KK44",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I7LO77KK45",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I7LO43L80",
//															"faceTagName": "nvChats"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I7IO89OE10",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I7IO89OE11",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1I7H5L8RV5",
//									"attrs": {
//										"1I7LO43L80": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I7LO77KK46",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I7LO77KK47",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I7LO43L80",
//											"faceTagName": "nvChats"
//										},
//										"1I7H6ET9K0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I7MV6TSE30",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I7MV6TSE31",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I7H6ET9K0",
//											"faceTagName": "chat"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1I7H5L8RV6",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1I7H5L8RV7",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1I7H5BDI40",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I7H5CIQU0",
//									"attrs": {
//										"type": "box",
//										"id": "BoxHeader",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "40",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "[0,10,0,10]",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"secondary\"]",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"contentLayout": "Flex X",
//										"itemsAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1I7JQD7R20",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I7JQGADN0",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxTitle",
//														"position": "Absolute",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex X",
//														"subAlign": "Center",
//														"itemsAlign": "Center"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "box",
//															"jaxId": "1I7JQEHS80",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I7JQEHS81",
//																	"attrs": {
//																		"type": "box",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "30",
//																		"h": "30",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[0,5,0,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"background": "#cfgColor[\"fontSecondary\"]",
//																		"border": "0",
//																		"borderStyle": "Solid",
//																		"borderColor": "[0,0,0,1.00]",
//																		"corner": "0",
//																		"shadow": "false",
//																		"shadowX": "2",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowSpread": "0",
//																		"shadowColor": "[0,0,0,0.50]",
//																		"maskImage": "#appCfg.sharedAssets+\"/aalogo.svg\""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1I7JQEHS90",
//																	"attrs": {
//																		"1I7H6EMDG0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I7LN46QF72",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I7LN46QF73",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I7H6EMDG0",
//																			"faceTagName": "login"
//																		},
//																		"1I7H6ET9K0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I7LN46QF74",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I7LN46QF75",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I7H6ET9K0",
//																			"faceTagName": "chat"
//																		},
//																		"1I7LO43L80": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I7LO77KK48",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I7LO77KK49",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I7LO43L80",
//																			"faceTagName": "nvChats"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1I7JQEHS91",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1I7JQEHS92",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1I7JQELOR0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I7JQELOR1",
//																	"attrs": {
//																		"type": "text",
//																		"id": "TxtTitle",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontSecondary\"]",
//																		"text": {
//																			"type": "string",
//																			"valText": "AI2Apps Teamwork",
//																			"localize": {
//																				"EN": "AI2Apps Teamwork",
//																				"CN": "AI2Apps 智能体团队"
//																			},
//																			"localizable": true
//																		},
//																		"font": "",
//																		"fontSize": "#txtSize.midPlus",
//																		"bold": "true",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Top",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"lineClamp": "0",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0",
//																		"flex": "false"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1I7JQELOS0",
//																	"attrs": {
//																		"1I7H6EMDG0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I7LN46QF76",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I7LN46QF77",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I7H6EMDG0",
//																			"faceTagName": "login"
//																		},
//																		"1I7H6ET9K0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I7LN46QF78",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I7LN46QF79",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I7H6ET9K0",
//																			"faceTagName": "chat"
//																		},
//																		"1I7LO43L80": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I7LO77KK50",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I7LO77KK51",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I7LO43L80",
//																			"faceTagName": "nvChats"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1I7JQELOS1",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1I7JQELOS2",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "box",
//															"jaxId": "1I7MV18UD0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I7MV18UD1",
//																	"attrs": {
//																		"type": "box",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "30",
//																		"h": "30",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "Off",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[0,5,0,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"background": "#cfgColor[\"fontSecondary\"]",
//																		"border": "0",
//																		"borderStyle": "Solid",
//																		"borderColor": "[0,0,0,1.00]",
//																		"corner": "0",
//																		"shadow": "false",
//																		"shadowX": "2",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowSpread": "0",
//																		"shadowColor": "[0,0,0,0.50]",
//																		"maskImage": "#appCfg.sharedAssets+\"/agent.svg\""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1I7MV18UD2",
//																	"attrs": {
//																		"1I7H6EMDG0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I7MV18UE0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I7MV18UE1",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I7H6EMDG0",
//																			"faceTagName": "login"
//																		},
//																		"1I7H6ET9K0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I7MV18UE2",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I7MV18UE3",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I7H6ET9K0",
//																			"faceTagName": "chat"
//																		},
//																		"1I7LO43L80": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I7MV18UE4",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I7MV18UE5",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I7LO43L80",
//																			"faceTagName": "nvChats"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1I7MV18UE6",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1I7MV18UE7",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1I7MV1PU80",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I7MV1PU81",
//																	"attrs": {
//																		"type": "text",
//																		"id": "TxtBotName",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "Off",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontSecondary\"]",
//																		"text": {
//																			"type": "string",
//																			"valText": "Chat with: BOT_MASTER",
//																			"localize": {
//																				"EN": "Chat with: BOT_MASTER",
//																				"CN": "与 BOT_MASTER 对话"
//																			},
//																			"localizable": true
//																		},
//																		"font": "",
//																		"fontSize": "#txtSize.midPlus",
//																		"bold": "true",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Top",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"lineClamp": "0",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0",
//																		"flex": "false"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1I7MV1PU90",
//																	"attrs": {
//																		"1I7H6EMDG0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I7MV1PU91",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I7MV1PU92",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I7H6EMDG0",
//																			"faceTagName": "login"
//																		},
//																		"1I7H6ET9K0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I7MV1PU93",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I7MV1PU94",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I7H6ET9K0",
//																			"faceTagName": "chat"
//																		},
//																		"1I7LO43L80": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I7MV1PU95",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I7MV1PU96",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I7LO43L80",
//																			"faceTagName": "nvChats"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1I7MV1PU97",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1I7MV1PU98",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1I7MV48LE0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1I7MV6TSE32",
//																	"attrs": {
//																		"style": "\"fontSecondary\"",
//																		"w": "28",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/btncombo.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1I7MV6TSE33",
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"fontSecondary\",28,0,appCfg.sharedAssets+\"/btncombo.svg\",null)",
//																		"id": "BtnChooseBot",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "Off",
//																		"face": "",
//																		"margin": "[0,0,0,5]"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1I7MV6TSE34",
//																	"attrs": {
//																		"1I7H6ET9K0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I7MV6TSE35",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I7MV6TSE36",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I7H6ET9K0",
//																			"faceTagName": "chat"
//																		},
//																		"1I7H6EMDG0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I7MV6TSE37",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I7MV6TSE38",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1I7H6EMDG0",
//																			"faceTagName": "login"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1I7MV6TSE39",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1I7U1DFJ00",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1I7U1DFJ10",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": "1I7U0FJUB0"
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1I7MV6TSE40",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1I7MV6TSE41",
//																	"attrs": {}
//																}
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1I7JQGADN1",
//													"attrs": {
//														"1I7LO43L80": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I7LO77KK52",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I7LO77KK53",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I7LO43L80",
//															"faceTagName": "nvChats"
//														},
//														"1I7H6ET9K0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I7MV6TSE42",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I7MV6TSE43",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I7H6ET9K0",
//															"faceTagName": "chat"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I7JQGADN2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I7JQGADN3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1I7JPUAI70",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1I7JQ32F40",
//													"attrs": {
//														"style": "\"fontSecondary\"",
//														"w": "30",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/hudedit.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1I7JQ32F41",
//													"attrs": {
//														"type": "#null#>BtnIcon(\"fontSecondary\",30,0,appCfg.sharedAssets+\"/hudedit.svg\",null)",
//														"id": "BtnNewChat",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": ""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I7JQ32F42",
//													"attrs": {
//														"1I7H6EMDG0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I7LN46QF84",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I7LN46QF85",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I7H6EMDG0",
//															"faceTagName": "login"
//														},
//														"1I7H6ET9K0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I7LN46QF86",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I7LN46QF87",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I7H6ET9K0",
//															"faceTagName": "chat"
//														},
//														"1I7LO43L80": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I7LO77KK54",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I7LO77KK55",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I7LO43L80",
//															"faceTagName": "nvChats"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I7JQ32F43",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1I7T07CIO0",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1I7T07CIO1",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": "1I7JR5JEH0"
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1I7JQ32F44",
//													"attrs": {
//														"tip": {
//															"type": "string",
//															"valText": "New Chat",
//															"localize": {
//																"EN": "New Chat",
//																"CN": "新对话"
//															},
//															"localizable": true
//														}
//													}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1I7JQ32F45",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1I7JQIVLA0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1I7JQIVLA1",
//													"attrs": {
//														"style": "\"fontSecondary\"",
//														"w": "30",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/menu.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1I7JQIVLA2",
//													"attrs": {
//														"type": "#null#>BtnIcon(\"fontSecondary\",30,0,appCfg.sharedAssets+\"/menu.svg\",null)",
//														"id": "BtnMenu",
//														"position": "Absolute",
//														"x": "100%-35",
//														"y": "50%",
//														"display": "On",
//														"face": "",
//														"anchorV": "Center"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I7JQIVLA3",
//													"attrs": {
//														"1I7H6EMDG0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I7LN46QF88",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I7LN46QF89",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I7H6EMDG0",
//															"faceTagName": "login"
//														},
//														"1I7H6ET9K0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I7LN46QF90",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I7LN46QF91",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I7H6ET9K0",
//															"faceTagName": "chat"
//														},
//														"1I7LO43L80": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I7LO77KK56",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I7LO77KK57",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1I7LO43L80",
//															"faceTagName": "nvChats"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I7JQIVLA4",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I7JQIVLA5",
//													"attrs": {
//														"tip": {
//															"type": "string",
//															"valText": "Options",
//															"localize": {
//																"EN": "Options",
//																"CN": "选项"
//															},
//															"localizable": true
//														}
//													}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1I7JQIVLA6",
//													"attrs": {}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1I7H5CIQU1",
//									"attrs": {
//										"1I7LO43L80": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I7LO77KK58",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I7LO77KK59",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I7LO43L80",
//											"faceTagName": "nvChats"
//										},
//										"1I7H6ET9K0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I7MV6TSE44",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I7MV6TSE45",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I7H6ET9K0",
//											"faceTagName": "chat"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1I7H5CIQU2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1I7H5CIQU3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1I7JOTQAO0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I7JOVSAB0",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxDragSize",
//										"position": "Absolute",
//										"x": "#state.naviBoxW-2",
//										"y": "0",
//										"w": "5",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "ew-resize",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": ""
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1I7JOVSAB1",
//									"attrs": {
//										"1I7LO43L80": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I7LO77KK60",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I7LO77KK61",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I7LO43L80",
//											"faceTagName": "nvChats"
//										},
//										"1I7H6ET9K0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I7MV6TSE46",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I7MV6TSE47",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1I7H6ET9K0",
//											"faceTagName": "chat"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1I7JOVSAB2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1I7JOVSAB3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1I7H5A7EP9",
//					"attrs": {
//						"1I7LO43L80": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1I7LO77KK62",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I7LO77KK63",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1I7LO43L80",
//							"faceTagName": "nvChats"
//						},
//						"1I7H6ET9K0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1I7MV6TSE48",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I7MV6TSE49",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1I7H6ET9K0",
//							"faceTagName": "chat"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1I7H5A7EP10",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1I7H5A7EP11",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1I7H5A7EP12",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}