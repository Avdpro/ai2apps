//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1I7PSN1M10StartDoc*/
import DlgMenu from "/@StdUI/ui/DlgMenu.js";
/*}#1I7PSN1M10StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BtnChatFlow=function(code,text,color,icon,items,fontSize,hasClose,iconSize,mark){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let txtName;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let markColor=mark===true?cfgColor.error:mark;
	
	/*#{1H1TCNO8A1LocalVals*/
	let app=window.tabOSApp;
	let focused=false;
	let chatFlow=null;
	/*}#1H1TCNO8A1LocalVals*/
	
	/*#{1H1TCNO8A1PreState*/
	/*}#1H1TCNO8A1PreState*/
	state={
		"markNum":2,
		/*#{1H1TCNO8A6ExState*/
		/*}#1H1TCNO8A6ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1H1TCNO8A1PostState*/
	/*}#1H1TCNO8A1PostState*/
	cssVO={
		"hash":"1H1TCNO8A1",nameHost:true,
		"type":"button","position":"relative","x":0,"y":0,"w":"100%","h":40,"cursor":"pointer","padding":[5,5,5,5],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
		"contentLayout":"flex-x","traceSize":true,"itemsAlign":1,
		"code":code,
		children:[
			{
				"hash":"1I7PSP5A70",
				"type":"box","id":"BoxHotBG","x":0,"y":0,"w":"100%","h":"100%","display":0,"uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["hotChatBG"],
				"corner":6,
			},
			{
				"hash":"1H1TCV3O50",
				"type":"box","id":"BoxIcon","position":"relative","x":0,"y":0,"w":iconSize||(fontSize+6),"h":iconSize||(fontSize+6),"autoLayout":true,"uiEvent":-1,
				"alpha":0.5,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":color,"aspect":"1","attached":!!icon,"maskImage":icon,
			},
			{
				"hash":"1H1TCQ3130",
				"type":"text","id":"TxtName","position":"relative","x":0,"y":0,"w":100,"h":"","uiEvent":-1,"alpha":0.5,"padding":0,"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","color":color,"text":text,"fontSize":fontSize||txtSize.mid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,
				"ellipsis":true,"flex":true,
			},
			{
				"hash":"1H1TIOQU40",
				"type":"box","id":"MenuMark","position":"relative","x":0,"y":"50%","w":"","h":">calc(100% - 10px)","anchorY":1,"uiEvent":-1,"alpha":0.5,"minW":"",
				"minH":"","maxW":"","maxH":"","styleClass":"","background":color,"aspect":"1","maskImage":appCfg.sharedAssets+"/down.svg","attached":!!items,
			},
			{
				"hash":"1I7PO2OSM0",
				"type":"box","id":"BoxNewMark","x":">calc(100% - 18px)","y":"50%","w":"","h":16,"anchorY":1,"display":$P(()=>(state.markNum>0),state),"uiEvent":-1,
				"padding":2,"minW":16,"minH":"","maxW":"","maxH":"","styleClass":"","background":markColor,"corner":100,"attached":!!mark,
				children:[
					{
						"hash":"1I7PO8SHK0",
						"type":"text","id":"TxtMarkNum","position":"relative","x":"50%","y":0,"w":"","h":"100%","anchorX":1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						"color":cfgColor["fontError"],"text":$P(()=>(state.markNum>0?state.markNum:""),state),"fontSize":12,"fontWeight":"bold","fontStyle":"normal","textDecoration":"",
						"alignH":1,"alignV":1,
					}
				],
			}
		],
		get $$markNum(){return state["markNum"]},
		set $$markNum(v){
			state["markNum"]=v;
			/*#{1H1TCNO8A1SetmarkNum*/
			/*}#1H1TCNO8A1SetmarkNum*/
		},
		/*#{1H1TCNO8A1ExtraCSS*/
		/*}#1H1TCNO8A1ExtraCSS*/
		faces:{
			"up":{
				/*#{1H1TD2J6S0PreCode*/
				$(){
					if(focused){
						return false;
					}
				},
				/*}#1H1TD2J6S0PreCode*/
				/*BoxHotBG*/"#1I7PSP5A70":{
					"display":0
				},
				/*BoxIcon*/"#1H1TCV3O50":{
					"alpha":0.5
				},
				/*TxtName*/"#1H1TCQ3130":{
					"alpha":0.5
				},
				/*MenuMark*/"#1H1TIOQU40":{
					"alpha":0.5
				}
			},"over":{
				/*#{1H1TD45OB0PreCode*/
				$(){
					if(focused){
						return false;
					}
				},
				/*}#1H1TD45OB0PreCode*/
				/*BoxHotBG*/"#1I7PSP5A70":{
					"display":0
				},
				/*BoxIcon*/"#1H1TCV3O50":{
					"alpha":0.7
				},
				/*TxtName*/"#1H1TCQ3130":{
					"alpha":0.7
				},
				/*MenuMark*/"#1H1TIOQU40":{
					"alpha":0.7
				}
			},"down":{
				/*#{1H1TD2VV70PreCode*/
				$(){
					if(focused){
						return false;
					}
				},
				/*}#1H1TD2VV70PreCode*/
				/*BoxHotBG*/"#1I7PSP5A70":{
					"display":0
				},
				/*BoxIcon*/"#1H1TCV3O50":{
					"alpha":1
				},
				/*TxtName*/"#1H1TCQ3130":{
					"alpha":1
				},
				/*MenuMark*/"#1H1TIOQU40":{
					"alpha":1
				}
			},"gray":{
				/*#{1H1TLQVNS0PreCode*/
				$(){
					if(focused){
						return false;
					}
				},
				/*}#1H1TLQVNS0PreCode*/
				/*BoxIcon*/"#1H1TCV3O50":{
					"alpha":0.2
				},
				/*TxtName*/"#1H1TCQ3130":{
					"alpha":0.2
				},
				/*MenuMark*/"#1H1TIOQU40":{
					"alpha":0.2
				}
			},"focus":{
				/*BoxHotBG*/"#1I7PSP5A70":{
					"display":1
				},
				/*BoxIcon*/"#1H1TCV3O50":{
					"alpha":1
				},
				/*TxtName*/"#1H1TCQ3130":{
					"alpha":1
				},
				/*MenuMark*/"#1H1TIOQU40":{
					"alpha":1
				},
				/*#{1H1TD5GM90Code*/
				$(){
					focused=true;
					state.markNum=0;
				},
				/*}#1H1TD5GM90Code*/
			},"blur":{
				/*BoxHotBG*/"#1I7PSP5A70":{
					"display":0
				},
				/*BoxIcon*/"#1H1TCV3O50":{
					"alpha":0.5
				},
				/*TxtName*/"#1H1TCQ3130":{
					"alpha":0.5
				},
				/*MenuMark*/"#1H1TIOQU40":{
					"alpha":0.5
				},
				/*#{1H1TD5O2O0Code*/
				$(){
					focused=false;
					this.uiEvent=1;
				},
				/*}#1H1TD5O2O0Code*/
			}
		},
		OnCreate:function(){
			self=this;
			txtName=self.TxtName;
			/*#{1H1TCNO8A1Create*/
			chatFlow=this.chatFlow;
			chatFlow.on("NewMessage",self.OnNewMessage);
			chatFlow.on("SetTitle",self.OnSetTitle);
			/*}#1H1TCNO8A1Create*/
		},
		/*#{1H1TCNO8A1EndCSS*/
		/*}#1H1TCNO8A1EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.OnNewMessage=async function(msg){
		/*#{1I7SV3PAV0Start*/
		if(!focused){
			state.markNum+=1;
		}
		if(!chatFlow.title){
			txtName.text=chatFlow.getTitle();
		}
		/*}#1I7SV3PAV0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.OnSetTitle=async function(title){
		/*#{1I7U7H1580Start*/
		txtName.text=chatFlow.getTitle();
		/*}#1I7U7H1580Start*/
	};
	/*#{1H1TCNO8A1PostCSSVO*/
	/*}#1H1TCNO8A1PostCSSVO*/
	return cssVO;
};
/*#{1H1TCNO8A1ExCodes*/
/*}#1H1TCNO8A1ExCodes*/

BtnChatFlow.gearExport={
	framework: "jax",
	hudType: "button",
	"showName":(($ln==="CN")?("BtnChatFlow"):("BtnChatFlow")),icon:"gears.svg",previewImg:false,
	fixPose:true,initW:100,initH:40,
	"desc":"Navi bar item button, with text. Item can have an icon. If item has sub-items, click will popup a menu.",
	catalog:"Buttons",
	args: {
		"code": {
			"name": "code", "showName": "code", "type": "string", "key": true, "fixed": true, "initVal": "Home"
		}, 
		"text": {
			"name": "text", "showName": "text", "type": "string", "key": true, "fixed": true, "initVal": "Home", "localizable": true
		}, 
		"color": {
			"name": "color", "showName": "color", "type": "colorRGBA", "key": true, "fixed": true, 
			"initVal": [0,0,0,1]
		}, 
		"icon": {
			"name": "icon", "showName": "icon", "type": "url", "key": true, "fixed": true, "initVal": "/~/-tabos/shared/assets/home.svg", "initValText": "#appCfg.sharedAssets+\"/home.svg\""
		}, 
		"items": {"name":"items","showName":"items","type":"auto","key":true,"fixed":true}, 
		"fontSize": {
			"name": "fontSize", "showName": "fontSize", "type": "int", "key": true, "fixed": true, "initVal": 16, "initValText": "#txtSize.mid"
		}, 
		"hasClose": {
			"name": "hasClose", "showName": "hasClose", "type": "bool", "key": true, "fixed": true, "initVal": false
		}, 
		"iconSize": {
			"name": "iconSize", "showName": "iconSize", "type": "int", "key": true, "fixed": true, "initVal": 0
		}, 
		"mark": {
			"name": "mark", "showName": "mark", "type": "auto", "key": true, "fixed": true, "initVal": true
		}
	},
	state:{
		markNum:{name:"markNum",type:"int",initVal:2}
	},
	properties:["id","position","x","y","w","h","anchorH","anchorV","autoLayout","display","uiEvent","cursor","margin","enable","attach"],
	faces:["up","over","down","gray","focus","blur"],
	subContainers:{
	},
	/*#{1I7PSN1M10ExGearInfo*/
	/*}#1I7PSN1M10ExGearInfo*/
};
/*#{1I7PSN1M10EndDoc*/
/*}#1I7PSN1M10EndDoc*/

export default BtnChatFlow;
export{BtnChatFlow};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearButton",
//	"jaxId": "1I7PSN1M10",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1H1TCNO8A2",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "40",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1H1TCNO8A3",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1H5RF70O00",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1H1TCNO8A4",
//			"attrs": {
//				"code": {
//					"type": "string",
//					"valText": "Home"
//				},
//				"text": {
//					"type": "string",
//					"valText": "Home",
//					"localizable": true
//				},
//				"color": {
//					"type": "colorRGBA",
//					"valText": "[0,0,0,1.00]"
//				},
//				"icon": {
//					"type": "url",
//					"valText": "#appCfg.sharedAssets+\"/home.svg\""
//				},
//				"items": {
//					"type": "auto",
//					"valText": ""
//				},
//				"fontSize": {
//					"type": "int",
//					"valText": "#txtSize.mid"
//				},
//				"hasClose": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"iconSize": {
//					"type": "int",
//					"valText": "0"
//				},
//				"mark": {
//					"type": "auto",
//					"valText": "true"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1H1TCNO8A5",
//			"attrs": {
//				"markColor": {
//					"type": "auto",
//					"valText": "#mark===true?cfgColor.error:mark"
//				}
//			}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1H1TCNO8A6",
//			"attrs": {
//				"markNum": {
//					"type": "int",
//					"valText": "2"
//				}
//			}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I7SV3PAV0",
//					"attrs": {
//						"id": "OnNewMessage",
//						"label": "New AI Seg",
//						"x": "55",
//						"y": "55",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I7SV4H1S0",
//							"attrs": {
//								"msg": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"localVars": {
//							"jaxId": "1I7SV4H1S1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I7SV4H1S2",
//							"attrs": {
//								"id": "Next",
//								"desc": "Outlet."
//							}
//						}
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1I7U7H1580",
//					"attrs": {
//						"id": "OnSetTitle",
//						"label": "New AI Seg",
//						"x": "55",
//						"y": "145",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1I7U7HV5J0",
//							"attrs": {
//								"title": {
//									"type": "string",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"localVars": {
//							"jaxId": "1I7U7HV5J1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1I7U7HV5J2",
//							"attrs": {
//								"id": "Next",
//								"desc": "Outlet."
//							}
//						}
//					}
//				}
//			]
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": {
//			"type": "string",
//			"valText": "BtnChatFlow",
//			"localize": {
//				"EN": "BtnChatFlow",
//				"CN": "BtnChatFlow"
//			},
//			"localizable": true
//		},
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "40",
//		"gearCatalog": "Buttons",
//		"description": "Navi bar item button, with text. Item can have an icon. If item has sub-items, click will popup a menu.",
//		"fixPose": "true",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1H1TCNO8A7",
//			"attrs": {
//				"up": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H1TD2J6S0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "true",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H1TD5T390",
//							"attrs": {}
//						}
//					}
//				},
//				"over": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H1TD45OB0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "true",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H1TD5T391",
//							"attrs": {}
//						}
//					}
//				},
//				"down": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H1TD2VV70",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "true",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H1TD5T392",
//							"attrs": {}
//						}
//					}
//				},
//				"gray": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H1TLQVNS0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "true",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H1TLR73E0",
//							"attrs": {}
//						}
//					}
//				},
//				"focus": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H1TD5GM90",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H1TD5T393",
//							"attrs": {}
//						}
//					}
//				},
//				"blur": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H1TD5O2O0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H1TD5T394",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1HU3VJD1P0",
//			"attrs": {
//				"iconed": {
//					"type": "mockState",
//					"def": "MockState",
//					"jaxId": "1I4OP806T0",
//					"attrs": {
//						"createArgs": {
//							"jaxId": "1H1TCNO8A4",
//							"attrs": {
//								"code": {
//									"type": "string",
//									"valText": "Home"
//								},
//								"text": {
//									"type": "string",
//									"valText": "Home",
//									"localizable": true
//								},
//								"color": {
//									"type": "colorRGBA",
//									"valText": "[0,0,0,1.00]"
//								},
//								"icon": {
//									"type": "url",
//									"valText": "#appCfg.sharedAssets+\"/home.svg\""
//								},
//								"items": {
//									"type": "auto",
//									"valText": ""
//								},
//								"fontSize": {
//									"type": "int",
//									"valText": "#txtSize.mid"
//								},
//								"hasClose": {
//									"type": "bool",
//									"valText": "false"
//								},
//								"iconSize": {
//									"type": "int",
//									"valText": "0"
//								}
//							}
//						},
//						"stateObj": {
//							"jaxId": "1H1TCNO8A6",
//							"attrs": {}
//						}
//					}
//				},
//				"icon_only": {
//					"type": "mockState",
//					"def": "MockState",
//					"jaxId": "1I54T5QH10",
//					"attrs": {
//						"createArgs": {
//							"jaxId": "1H1TCNO8A4",
//							"attrs": {
//								"code": {
//									"type": "string",
//									"valText": "Home"
//								},
//								"text": {
//									"type": "string",
//									"valText": "",
//									"localizable": true
//								},
//								"color": {
//									"type": "colorRGBA",
//									"valText": "[0,0,0,1.00]"
//								},
//								"icon": {
//									"type": "url",
//									"valText": "#appCfg.sharedAssets+\"/home.svg\""
//								},
//								"items": {
//									"type": "auto",
//									"valText": ""
//								},
//								"fontSize": {
//									"type": "int",
//									"valText": "#txtSize.small"
//								},
//								"hasClose": {
//									"type": "bool",
//									"valText": "false"
//								}
//							}
//						},
//						"stateObj": {
//							"jaxId": "1H1TCNO8A6",
//							"attrs": {}
//						}
//					}
//				},
//				"text_only": {
//					"type": "mockState",
//					"def": "MockState",
//					"jaxId": "1I54T5QH11",
//					"attrs": {
//						"createArgs": {
//							"jaxId": "1H1TCNO8A4",
//							"attrs": {
//								"code": {
//									"type": "string",
//									"valText": "Home"
//								},
//								"text": {
//									"type": "string",
//									"valText": "Home",
//									"localizable": true
//								},
//								"color": {
//									"type": "colorRGBA",
//									"valText": "[0,0,0,1.00]"
//								},
//								"icon": {
//									"type": "url",
//									"valText": ""
//								},
//								"items": {
//									"type": "auto",
//									"valText": ""
//								},
//								"fontSize": {
//									"type": "int",
//									"valText": "#txtSize.small"
//								},
//								"hasClose": {
//									"type": "bool",
//									"valText": "false"
//								}
//							}
//						},
//						"stateObj": {
//							"jaxId": "1H1TCNO8A6",
//							"attrs": {}
//						}
//					}
//				},
//				"has_close": {
//					"type": "mockState",
//					"def": "MockState",
//					"jaxId": "1I54TV0KV0",
//					"attrs": {
//						"createArgs": {
//							"jaxId": "1H1TCNO8A4",
//							"attrs": {
//								"code": {
//									"type": "string",
//									"valText": "Home"
//								},
//								"text": {
//									"type": "string",
//									"valText": "Home",
//									"localizable": true
//								},
//								"color": {
//									"type": "colorRGBA",
//									"valText": "[0,0,0,1.00]"
//								},
//								"icon": {
//									"type": "url",
//									"valText": "#appCfg.sharedAssets+\"/home.svg\""
//								},
//								"items": {
//									"type": "auto",
//									"valText": ""
//								},
//								"fontSize": {
//									"type": "int",
//									"valText": "#txtSize.mid"
//								},
//								"hasClose": {
//									"type": "bool",
//									"valText": "true"
//								}
//							}
//						},
//						"stateObj": {
//							"jaxId": "1H1TCNO8A6",
//							"attrs": {}
//						}
//					}
//				},
//				"big_icon": {
//					"type": "mockState",
//					"def": "MockState",
//					"jaxId": "1I7JC858V0",
//					"attrs": {
//						"createArgs": {
//							"jaxId": "1H1TCNO8A4",
//							"attrs": {
//								"code": {
//									"type": "string",
//									"valText": "Home"
//								},
//								"text": {
//									"type": "string",
//									"valText": "Home",
//									"localizable": true
//								},
//								"color": {
//									"type": "colorRGBA",
//									"valText": "[0,0,0,1.00]"
//								},
//								"icon": {
//									"type": "url",
//									"valText": "#appCfg.sharedAssets+\"/home.svg\""
//								},
//								"items": {
//									"type": "auto",
//									"valText": ""
//								},
//								"fontSize": {
//									"type": "int",
//									"valText": "#txtSize.mid"
//								},
//								"hasClose": {
//									"type": "bool",
//									"valText": "false"
//								},
//								"iconSize": {
//									"type": "int",
//									"valText": "30"
//								}
//							}
//						},
//						"stateObj": {
//							"jaxId": "1H1TCNO8A6",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "button",
//			"jaxId": "1H1TCNO8A1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1H1TCNO8A8",
//					"attrs": {
//						"type": "button",
//						"id": "",
//						"position": "Relative",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "40",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "pointer",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "[5,5,5,5]",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"enable": "true",
//						"drag": "NA",
//						"contentLayout": "Flex X",
//						"attach": "true",
//						"traceSize": "true",
//						"itemsAlign": "Center"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1I7PSP5A70",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I7PSS3QV0",
//									"attrs": {
//										"type": "box",
//										"id": "BoxHotBG",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "Off",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"hotChatBG\"]",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "6",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1I7PSS3QV1",
//									"attrs": {
//										"1H1TD2J6S0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I7PST80V0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I7PST80V1",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TD2J6S0",
//											"faceTagName": "up"
//										},
//										"1H1TD45OB0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I7PST80V2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I7PST80V3",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TD45OB0",
//											"faceTagName": "over"
//										},
//										"1H1TD2VV70": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I7PST8100",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I7PST8101",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TD2VV70",
//											"faceTagName": "down"
//										},
//										"1H1TD5GM90": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I7PST8102",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I7PST8103",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TD5GM90",
//											"faceTagName": "focus"
//										},
//										"1H1TD5O2O0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I7PST8104",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I7PST8105",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TD5O2O0",
//											"faceTagName": "blur"
//										},
//										"1H1TLQVNS0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I7SV7DVE0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I7SV7DVE1",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TLQVNS0",
//											"faceTagName": "gray"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1I7PSS3QV2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1I7PSS3QV3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1H1TCV3O50",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1TD5T395",
//									"attrs": {
//										"type": "box",
//										"id": "BoxIcon",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "#iconSize||(fontSize+6)",
//										"h": "#iconSize||(fontSize+6)",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "true",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "0.5",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#color",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"aspect": "1",
//										"attach": "#!!icon",
//										"maskImage": "#icon"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H1TD5T396",
//									"attrs": {
//										"1H1TD2VV70": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1TD5T399",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1TD5T3910",
//													"attrs": {
//														"alpha": {
//															"type": "number",
//															"valText": "1",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TD2VV70",
//											"faceTagName": "down"
//										},
//										"1H1TD45OB0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1TD5T3911",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1TD5T3912",
//													"attrs": {
//														"alpha": {
//															"type": "number",
//															"valText": "0.7",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TD45OB0",
//											"faceTagName": "over"
//										},
//										"1H1TD5GM90": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I54T95V20",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I54T95V21",
//													"attrs": {
//														"alpha": {
//															"type": "number",
//															"valText": "1",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TD5GM90",
//											"faceTagName": "focus"
//										},
//										"1H1TLQVNS0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I54U1VQF2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I54U1VQF3",
//													"attrs": {
//														"alpha": {
//															"type": "number",
//															"valText": "0.2",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TLQVNS0",
//											"faceTagName": "gray"
//										},
//										"1H1TD2J6S0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I54UMBBJ0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I54UMBBJ1",
//													"attrs": {
//														"alpha": {
//															"type": "number",
//															"valText": "0.5",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TD2J6S0",
//											"faceTagName": "up"
//										},
//										"1H1TD5O2O0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I54V10LV0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I54V10LV1",
//													"attrs": {
//														"alpha": {
//															"type": "number",
//															"valText": "0.5",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TD5O2O0",
//											"faceTagName": "blur"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1H1TD5T3917",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H1TD5T3918",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1H1TCQ3130",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1TD5T3919",
//									"attrs": {
//										"type": "text",
//										"id": "TxtName",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "0.5",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "0",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#color",
//										"text": "#text",
//										"font": "",
//										"fontSize": "#fontSize||txtSize.mid",
//										"bold": "false",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Center",
//										"wrap": "false",
//										"ellipsis": "true",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0",
//										"autoSizeW": "false",
//										"autoSizeH": "false",
//										"flex": "true"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H1TD5T3920",
//									"attrs": {
//										"1H1TD2VV70": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1TD5T3923",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1TD5T3924",
//													"attrs": {
//														"alpha": {
//															"type": "number",
//															"valText": "1",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TD2VV70",
//											"faceTagName": "down"
//										},
//										"1H1TD45OB0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1TD5T3925",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1TD5T3926",
//													"attrs": {
//														"alpha": {
//															"type": "number",
//															"valText": "0.7",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TD45OB0",
//											"faceTagName": "over"
//										},
//										"1H1TD5GM90": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I54T95V24",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I54T95V25",
//													"attrs": {
//														"alpha": {
//															"type": "number",
//															"valText": "1",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TD5GM90",
//											"faceTagName": "focus"
//										},
//										"1H1TLQVNS0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I54U1VQF6",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I54U1VQF7",
//													"attrs": {
//														"alpha": {
//															"type": "number",
//															"valText": "0.2",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TLQVNS0",
//											"faceTagName": "gray"
//										},
//										"1H1TD2J6S0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I54UMBBJ2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I54UMBBJ3",
//													"attrs": {
//														"alpha": {
//															"type": "number",
//															"valText": "0.5",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TD2J6S0",
//											"faceTagName": "up"
//										},
//										"1H1TD5O2O0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I54V10LV2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I54V10LV3",
//													"attrs": {
//														"alpha": {
//															"type": "number",
//															"valText": "0.5",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TD5O2O0",
//											"faceTagName": "blur"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1H1TD5T3931",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H1TD5T3932",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1H1TIOQU40",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1TIT6SM0",
//									"attrs": {
//										"type": "box",
//										"id": "MenuMark",
//										"position": "relative",
//										"x": "0",
//										"y": "50%",
//										"w": "\"\"",
//										"h": "100%-10",
//										"anchorH": "Left",
//										"anchorV": "Center",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "0.5",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#color",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"aspect": "1",
//										"maskImage": "#appCfg.sharedAssets+\"/down.svg\"",
//										"attach": "#!!items"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H1TIT6SM1",
//									"attrs": {
//										"1H1TD45OB0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1TIUJ9A12",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1TIUJ9A13",
//													"attrs": {
//														"alpha": {
//															"type": "number",
//															"valText": "0.7",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TD45OB0",
//											"faceTagName": "over"
//										},
//										"1H1TD2VV70": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H1TIUJ9A14",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H1TIUJ9A15",
//													"attrs": {
//														"alpha": {
//															"type": "number",
//															"valText": "1",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TD2VV70",
//											"faceTagName": "down"
//										},
//										"1H1TD5GM90": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I54T95V28",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I54T95V29",
//													"attrs": {
//														"alpha": {
//															"type": "number",
//															"valText": "1",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TD5GM90",
//											"faceTagName": "focus"
//										},
//										"1H1TLQVNS0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I54U1VQF10",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I54U1VQF11",
//													"attrs": {
//														"alpha": {
//															"type": "number",
//															"valText": "0.2",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TLQVNS0",
//											"faceTagName": "gray"
//										},
//										"1H1TD2J6S0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I54UMBBJ4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I54UMBBJ5",
//													"attrs": {
//														"alpha": {
//															"type": "number",
//															"valText": "0.5",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TD2J6S0",
//											"faceTagName": "up"
//										},
//										"1H1TD5O2O0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I54V10M00",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I54V10M01",
//													"attrs": {
//														"alpha": {
//															"type": "number",
//															"valText": "0.5",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TD5O2O0",
//											"faceTagName": "blur"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1H1TIT6SM2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H1TIT6SM3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1I7PO2OSM0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I7PP3SMJ0",
//									"attrs": {
//										"type": "box",
//										"id": "BoxNewMark",
//										"position": "Absolute",
//										"x": "100%-18",
//										"y": "50%",
//										"w": "",
//										"h": "16",
//										"anchorH": "Left",
//										"anchorV": "Center",
//										"autoLayout": "false",
//										"display": "${state.markNum>0},state",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "2",
//										"minW": "16",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#markColor",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "100",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"attach": "#!!mark"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1I7PO8SHK0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I7PP3SMJ1",
//													"attrs": {
//														"type": "text",
//														"id": "TxtMarkNum",
//														"position": "Relative",
//														"x": "50%",
//														"y": "0",
//														"w": "",
//														"h": "100%",
//														"anchorH": "Center",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontError\"]",
//														"text": "${state.markNum>0?state.markNum:\"\"},state",
//														"font": "",
//														"fontSize": "12",
//														"bold": "true",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Center",
//														"alignV": "Center",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I7PP3SMJ2",
//													"attrs": {
//														"1H1TD45OB0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I7PST8108",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I7PST8109",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H1TD45OB0",
//															"faceTagName": "over"
//														},
//														"1H1TD2VV70": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I7PST81010",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I7PST81011",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H1TD2VV70",
//															"faceTagName": "down"
//														},
//														"1H1TD5GM90": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I7SV7DVE4",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I7SV7DVE5",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H1TD5GM90",
//															"faceTagName": "focus"
//														},
//														"1H1TLQVNS0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I7SV7DVE6",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I7SV7DVE7",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H1TLQVNS0",
//															"faceTagName": "gray"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I7PP3SMJ3",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I7PP3SMJ4",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1I7PP3SMJ5",
//									"attrs": {
//										"1H1TD45OB0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I7PST81018",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I7PST81019",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TD45OB0",
//											"faceTagName": "over"
//										},
//										"1H1TD2VV70": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I7PST81020",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I7PST81021",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TD2VV70",
//											"faceTagName": "down"
//										},
//										"1H1TD5GM90": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I7SV7DVE10",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I7SV7DVE11",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TD5GM90",
//											"faceTagName": "focus"
//										},
//										"1H1TLQVNS0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I7SV7DVE12",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I7SV7DVE13",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H1TLQVNS0",
//											"faceTagName": "gray"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1I7PP3SMJ6",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1I7PP3SMJ7",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1H1TCNO8A9",
//					"attrs": {
//						"1H1TD45OB0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H1TD5T3937",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H1TD5T3938",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H1TD45OB0",
//							"faceTagName": "over"
//						},
//						"1H1TD2VV70": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1I54V583S2",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I54V583S3",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H1TD2VV70",
//							"faceTagName": "down"
//						},
//						"1H1TLQVNS0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1I54V764A0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I54V764A1",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H1TLQVNS0",
//							"faceTagName": "gray"
//						},
//						"1H1TD5GM90": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1I7SV7DVE16",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I7SV7DVE17",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H1TD5GM90",
//							"faceTagName": "focus"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1H1TCNO8A10",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1H1TCNO8A11",
//					"attrs": {
//						"code": {
//							"type": "string",
//							"valText": "#code"
//						}
//					}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1H1TCNO8A12",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "true",
//				"h": "true",
//				"anchorH": "true",
//				"anchorV": "true",
//				"autoLayout": "true",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "true",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "true",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "true",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"enable": "true",
//				"drag": "false",
//				"innerLayout": {
//					"valText": "false"
//				},
//				"marginL": {
//					"valText": "false"
//				},
//				"marginR": {
//					"valText": "false"
//				},
//				"marginT": {
//					"valText": "false"
//				},
//				"marginB": {
//					"valText": "false"
//				},
//				"paddingL": {
//					"valText": "false"
//				},
//				"paddingR": {
//					"valText": "false"
//				},
//				"paddingT": {
//					"valText": "false"
//				},
//				"paddingB": {
//					"valText": "false"
//				},
//				"attach": {
//					"valText": "true"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": [
//				{
//					"type": "string",
//					"valText": "markNum"
//				}
//			]
//		}
//	}
//}