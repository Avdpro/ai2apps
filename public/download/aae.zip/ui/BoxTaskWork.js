//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {DataView} from "/@StdUI/ui/DataView.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
/*#{1I7E3F2MM0StartDoc*/
/*}#1I7E3F2MM0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BoxTaskWork=function(work){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1I7E3F2MM1LocalVals*/
	/*}#1I7E3F2MM1LocalVals*/
	
	/*#{1I7E3F2MM1PreState*/
	/*}#1I7E3F2MM1PreState*/
	/*#{1I7E3F2MM1PostState*/
	/*}#1I7E3F2MM1PostState*/
	cssVO={
		"hash":"1I7E3F2MM1",nameHost:true,
		"type":"box","position":"relative","x":0,"y":0,"w":"100%","h":"","margin":[0,0,5,0],"padding":0,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
		"background":[255,255,255,1],"border":1,"contentLayout":"flex-y",
		"work":work,
		children:[
			{
				"hash":"1I7E3IC8N0",
				"type":DataView(null,"1I7DCATBU0",work,"",{"titleHeight":30,"titleSize":18,"titleColor":cfgColor["fontBody"],"titleBold":true,"lineHeight":20,"lineGap":3,"labelSize":12,"labelColor":cfgColor["fontBody"],"labelBold":true,"labelLine":false,"valueSize":14,"valueColor":cfgColor["fontBody"],"valueBold":false,"segHeight":20,"segSize":14,"segBold":true,"segColor":cfgColor["fontBody"],"trace":true,"edit":false,"noteSize":12},""),
				"id":"DVTask","position":"relative","x":0,"y":0,
			},
			{
				"hash":"1I7E3QQAF0",
				"type":BtnIcon("front",25,0,appCfg.sharedAssets+"/close.svg",null),"x":">calc(100% - 30px)","y":5,
				"tip":"Hide",
				"OnClick":function(event){
					/*#{1I7EU1S270FunctionBody*/
					self.removeCard && self.removeCard();
					/*}#1I7EU1S270FunctionBody*/
				},
			},
			{
				"hash":"1I7EUDC8Q0",
				"type":BtnIcon("front",25,0,appCfg.sharedAssets+"/event.svg",null),"x":">calc(100% - 60px)","y":5,"enable":false,
				"tip":"Task logs",
				"OnClick":function(event){
					/*#{1I7EUDC8R4FunctionBody*/
					/*}#1I7EUDC8R4FunctionBody*/
				},
			}
		],
		/*#{1I7E3F2MM1ExtraCSS*/
		/*}#1I7E3F2MM1ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			self=this;
			
			/*#{1I7E3F2MM1Create*/
			/*}#1I7E3F2MM1Create*/
		},
		/*#{1I7E3F2MM1EndCSS*/
		/*}#1I7E3F2MM1EndCSS*/
	};
	/*#{1I7E3F2MM1PostCSSVO*/
	/*}#1I7E3F2MM1PostCSSVO*/
	return cssVO;
};
/*#{1I7E3F2MM1ExCodes*/
/*}#1I7E3F2MM1ExCodes*/


/*#{1I7E3F2MM0EndDoc*/
/*}#1I7E3F2MM0EndDoc*/

export default BoxTaskWork;
export{BoxTaskWork};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearBox",
//	"jaxId": "1I7E3F2MM0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1I7E3F2MM2",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1I7E3F2MM3",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1I7E3F2MM4",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1I7E3F2MM5",
//			"attrs": {
//				"work": {
//					"type": "auto",
//					"valText": "#{fromBot:\"Home\",prompt:\"Make a gift\",state:\"WORKING\",result:\"NA\"}"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1I7E3F2MM6",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1I7E3F2MM7",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1I7E3F2MM8",
//			"attrs": {}
//		},
//		"mockupStates": {
//			"jaxId": "1I7E3F2MM9",
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "box",
//			"jaxId": "1I7E3F2MM1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1I7E3F2MM10",
//					"attrs": {
//						"type": "box",
//						"id": "",
//						"position": "Relative",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "[0,0,5,0]",
//						"padding": "0",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"background": "[255,255,255,1.00]",
//						"border": "1",
//						"borderStyle": "Solid",
//						"borderColor": "[0,0,0,1.00]",
//						"corner": "0",
//						"shadow": "false",
//						"shadowX": "2",
//						"shadowY": "2",
//						"shadowBlur": "3",
//						"shadowSpread": "0",
//						"shadowColor": "[0,0,0,0.50]",
//						"contentLayout": "Flex Y"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "Gear/@StdUI/ui/DataView.js",
//							"jaxId": "1I7E3IC8N0",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1I7E3MK190",
//									"attrs": {
//										"box": "null",
//										"template": "\"1I7DCATBU0\"",
//										"dataObj": "#work",
//										"property": "",
//										"options": {
//											"jaxId": "1I7E3MK191",
//											"attrs": {
//												"titleHeight": "30",
//												"titleSize": "18",
//												"titleColor": "#cfgColor[\"fontBody\"]",
//												"titleBold": "true",
//												"lineHeight": "20",
//												"lineGap": "3",
//												"labelSize": "12",
//												"labelColor": "#cfgColor[\"fontBody\"]",
//												"labelBold": "true",
//												"labelLine": "false",
//												"valueSize": "14",
//												"valueColor": "#cfgColor[\"fontBody\"]",
//												"valueBold": "false",
//												"segHeight": "20",
//												"segSize": "14",
//												"segBold": "true",
//												"segColor": "#cfgColor[\"fontBody\"]",
//												"trace": "true",
//												"edit": "false",
//												"noteSize": "12"
//											}
//										},
//										"title": ""
//									}
//								},
//								"properties": {
//									"jaxId": "1I7E3MK192",
//									"attrs": {
//										"type": "#null#>DataView(null,\"1I7DCATBU0\",work,\"\",{\"titleHeight\":30,\"titleSize\":18,\"titleColor\":cfgColor[\"fontBody\"],\"titleBold\":true,\"lineHeight\":20,\"lineGap\":3,\"labelSize\":12,\"labelColor\":cfgColor[\"fontBody\"],\"labelBold\":true,\"labelLine\":false,\"valueSize\":14,\"valueColor\":cfgColor[\"fontBody\"],\"valueBold\":false,\"segHeight\":20,\"segSize\":14,\"segBold\":true,\"segColor\":cfgColor[\"fontBody\"],\"trace\":true,\"edit\":false,\"noteSize\":12},\"\")",
//										"id": "DVTask",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"display": "On",
//										"face": "",
//										"padding": ""
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1I7E3MK193",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1I7E3MK194",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1I7E3MK195",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false",
//								"containerSlots": {
//									"jaxId": "1I7E3MK196",
//									"attrs": {}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear/@StdUI/ui/BtnIcon.js",
//							"jaxId": "1I7E3QQAF0",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1I7E3RO210",
//									"attrs": {
//										"style": "\"front\"",
//										"w": "25",
//										"h": "0",
//										"icon": "#appCfg.sharedAssets+\"/close.svg\"",
//										"colorBG": "null"
//									}
//								},
//								"properties": {
//									"jaxId": "1I7E3RO211",
//									"attrs": {
//										"type": "#null#>BtnIcon(\"front\",25,0,appCfg.sharedAssets+\"/close.svg\",null)",
//										"id": "",
//										"position": "Absolute",
//										"x": "100%-30",
//										"y": "5",
//										"display": "On",
//										"face": ""
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1I7E3RO212",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1I7E3RO213",
//									"attrs": {
//										"OnClick": {
//											"type": "fixedFunc",
//											"jaxId": "1I7EU1S270",
//											"attrs": {
//												"callArgs": {
//													"jaxId": "1I7EU2AA50",
//													"attrs": {
//														"event": ""
//													}
//												},
//												"seg": ""
//											}
//										}
//									}
//								},
//								"extraPpts": {
//									"jaxId": "1I7E3RO214",
//									"attrs": {
//										"tip": {
//											"type": "string",
//											"valText": "Hide",
//											"localizable": true
//										}
//									}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false",
//								"containerSlots": {
//									"jaxId": "1I7E3RO215",
//									"attrs": {}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear/@StdUI/ui/BtnIcon.js",
//							"jaxId": "1I7EUDC8Q0",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1I7EUDC8R0",
//									"attrs": {
//										"style": "\"front\"",
//										"w": "25",
//										"h": "0",
//										"icon": "#appCfg.sharedAssets+\"/event.svg\"",
//										"colorBG": "null"
//									}
//								},
//								"properties": {
//									"jaxId": "1I7EUDC8R1",
//									"attrs": {
//										"type": "#null#>BtnIcon(\"front\",25,0,appCfg.sharedAssets+\"/event.svg\",null)",
//										"id": "",
//										"position": "Absolute",
//										"x": "100%-60",
//										"y": "5",
//										"display": "On",
//										"face": "",
//										"enable": "false"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1I7EUDC8R2",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1I7EUDC8R3",
//									"attrs": {
//										"OnClick": {
//											"type": "fixedFunc",
//											"jaxId": "1I7EUDC8R4",
//											"attrs": {
//												"callArgs": {
//													"jaxId": "1I7EUDC8R5",
//													"attrs": {
//														"event": ""
//													}
//												},
//												"seg": ""
//											}
//										}
//									}
//								},
//								"extraPpts": {
//									"jaxId": "1I7EUDC8R6",
//									"attrs": {
//										"tip": {
//											"type": "string",
//											"valText": "Task logs",
//											"localizable": true
//										}
//									}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false",
//								"containerSlots": {
//									"jaxId": "1I7EUDC8R7",
//									"attrs": {}
//								}
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1I7E3F2MM11",
//					"attrs": {}
//				},
//				"functions": {
//					"jaxId": "1I7E3F2MM12",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1I7E3F2MM13",
//					"attrs": {
//						"work": {
//							"type": "auto",
//							"valText": "#work"
//						}
//					}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1I7E3F2MM14",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"background": "false",
//				"color": "false",
//				"gradient": "false",
//				"border": "false",
//				"borders": "false",
//				"borderStyle": "false",
//				"borderColor": "false",
//				"borderColors": "false",
//				"corner": "false",
//				"coner": "false",
//				"coners": "false",
//				"shadow": "false",
//				"shadowX": "false",
//				"shadowY": "false",
//				"shadowBlur": "false",
//				"shadowSpread": "false",
//				"shadowColor": "false",
//				"maskImage": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}