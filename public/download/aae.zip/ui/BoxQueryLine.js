//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnCheck} from "/@StdUI/ui/BtnCheck.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
/*#{1HLEJUAD20StartDoc*/
/*}#1HLEJUAD20StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BoxQueryLine=function(item,block){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let btnCheck,btnMode,txtMode,edValue;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let name=item.key;
	let value=item.value;
	
	/*#{1HLEJUAD21LocalVals*/
	const app=VFACT.app;
	/*}#1HLEJUAD21LocalVals*/
	
	/*#{1HLEJUAD21PreState*/
	/*}#1HLEJUAD21PreState*/
	state={
		"checked":false,"mode":"equal",
		/*#{1HLEJUAD27ExState*/
		/*}#1HLEJUAD27ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1HLEJUAD21PostState*/
	/*}#1HLEJUAD21PostState*/
	cssVO={
		"hash":"1HLEJUAD21",nameHost:true,
		"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":20,"margin":[0,0,5,0],"padding":[0,5,0,5],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
		"contentLayout":"flex-x","itemsAlign":1,
		children:[
			{
				"hash":"1HLEK0F6P0",
				"type":BtnCheck(18,name,false,false),"id":"BtnCheck","position":"relative","x":0,"y":0,"fontSize":14,"margin":[0,3,0,0],
				/*#{1HLEK0F6P0Codes*/
				OnCheck(){
					block.buildQuery();
				}
				/*}#1HLEK0F6P0Codes*/
			},
			{
				"hash":"1HMHMAQ070",
				"type":BtnIcon("front",20,0,appCfg.sharedAssets+"/btncombo.svg",null),"id":"BtnMode","position":"relative","x":0,"y":0,
				"OnClick":function(event){
					self.showMenu(this,event);
				},
			},
			{
				"hash":"1HLEKADN10",
				"type":"text","id":"TxtMode","position":"relative","x":0,"y":0,"w":"","h":"","margin":[0,3,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"color":[0,0,0],"text":"=","fontSize":txtSize.mid,"fontWeight":"bold","fontStyle":"normal","textDecoration":"",
			},
			{
				"hash":"1HLEKC02C0",
				"type":"edit","id":"EdValue","position":"relative","x":0,"y":0,"w":30,"h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","text":value,
				"placeHolder":"Query string","color":[0,0,0],"outline":0,"border":[0,0,1,0],"flex":true,
				"OnKeyDown":function(event){
					/*#{1HNDB0EKF0FunctionBody*/
					if(event.code==="Enter"){
						if((!event.isComposing) &&(!event.shiftKey)){
							event.stopPropagation();
							event.preventDefault();
							block.buildQuery();
						}
					}
					/*}#1HNDB0EKF0FunctionBody*/
				},
			},
			{
				"hash":"1HMHM5QQB0",
				"type":BtnIcon("front",20,0,appCfg.sharedAssets+"/undo.svg",null),"id":"BtnReset","position":"relative","x":0,"y":0,
				"OnClick":function(event){
					self.reset(this,event);
				},
			}
		],
		/*#{1HLEJUAD21ExtraCSS*/
		attr:item,
		get $$checked(){return btnCheck.checked;},
		get $$mode(){return state.mode;},
		get $$value(){return edValue.text;},
		/*}#1HLEJUAD21ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			self=this;
			btnCheck=self.BtnCheck;btnMode=self.BtnMode;txtMode=self.TxtMode;edValue=self.EdValue;
			/*#{1HLEJUAD21Create*/
			btnCheck.checked=false;
			/*}#1HLEJUAD21Create*/
		},
		/*#{1HLEJUAD21EndCSS*/
		/*}#1HLEJUAD21EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.showMenu=async function(sender,event){
		/*#{1HNBL4ONI0Start*/
		/*}#1HNBL4ONI0Start*/
		{
			let $items,$item;
			$items=[
				{id:"equal",text:"equal"},
				{id:"starts",text:"starts-with"},
				{id:"contains",text:"contains"}
			];
			$item=await VFACT.app.modalDlg("/@StdUI/ui/DlgMenu.js",{hud:btnMode,items:$items});
			if($item){
				if($item.id==="equal"){
					/*#{1HNBLBL2M0*/
					state.mode=$item.id;
					txtMode.text="=";
					block.buildQuery();
					/*}#1HNBLBL2M0*/
				}else if($item.id==="starts"){
					/*#{1HNBLBL2M1*/
					state.mode=$item.id;
					txtMode.text="S";
					block.buildQuery();
					/*}#1HNBLBL2M1*/
				}else if($item.id==="contains"){
					/*#{1HNBLBL2M2*/
					state.mode=$item.id;
					txtMode.text="C";
					block.buildQuery();
					/*}#1HNBLBL2M2*/
				}
			}
		}
	};
	//------------------------------------------------------------------------
	cssVO.reset=async function(sender,event){
		/*#{1HNDAC2P80Start*/
		state.mode="equal";
		txtMode.text="=";
		edValue.text=value;
		/*}#1HNDAC2P80Start*/
	};
	/*#{1HLEJUAD21PostCSSVO*/
	/*}#1HLEJUAD21PostCSSVO*/
	return cssVO;
};
/*#{1HLEJUAD21ExCodes*/
/*}#1HLEJUAD21ExCodes*/

BoxQueryLine.gearExport={
	framework: "jax",
	hudType: "hud",
	"showName":"",icon:"gears.svg",previewImg:false,
	fixPose:false,initW:100,initH:100,
	catalog:"",
	args: {
		"item": {
			"name": "item", "showName": "item", "type": "auto", "key": true, "fixed": true, 
			"initVal": {"key":"id","value":"ABCD"}, "initValText": "#{\"key\":\"id\",\"value\":\"ABCD\"}"
		}, 
		"block": {
			"name": "block", "showName": "block", "type": "auto", "key": true, "fixed": true, 
			"initVal": null
		}
	},
	state:{
	},
	properties:["id","position","x","y","display"],
	faces:[],
	subContainers:{
	},
	/*#{1HLEJUAD20ExGearInfo*/
	/*}#1HLEJUAD20ExGearInfo*/
};
export default BoxQueryLine;
export{BoxQueryLine};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1HLEJUAD20",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1HLEJUAD22",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1HLEJUAD23",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1HLEJUAD24",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1HLEJUAD25",
//			"attrs": {
//				"item": {
//					"type": "auto",
//					"valText": "#{\"key\":\"id\",\"value\":\"ABCD\"}"
//				},
//				"block": {
//					"type": "auto",
//					"valText": "null"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1HLEJUAD26",
//			"attrs": {
//				"name": {
//					"type": "string",
//					"valText": "#item.key"
//				},
//				"value": {
//					"type": "int",
//					"valText": "#item.value"
//				}
//			}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1HLEJUAD27",
//			"attrs": {
//				"checked": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"mode": {
//					"type": "string",
//					"valText": "equal"
//				}
//			}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HNBL4ONI0",
//					"attrs": {
//						"id": "showMenu",
//						"label": "New AI Seg",
//						"x": "90",
//						"y": "130",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HNBLD6LU0",
//							"attrs": {
//								"sender": {
//									"valText": "null"
//								},
//								"event": {
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"localVars": {
//							"jaxId": "1HNBLD6LU1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": [
//								{
//									"type": "flowseg",
//									"def": "Menu",
//									"jaxId": "1HNBLC5IP0",
//									"attrs": {
//										"id": "menu",
//										"label": "New AI Seg",
//										"x": "330",
//										"y": "130",
//										"desc": "",
//										"codes": "false",
//										"launcher": "btnMode",
//										"outlets": {
//											"attrs": [
//												{
//													"type": "aioutlet",
//													"def": "MenuItem",
//													"jaxId": "1HNBLBL2M0",
//													"attrs": {
//														"id": "equal",
//														"text": "equal",
//														"desc": ""
//													}
//												},
//												{
//													"type": "aioutlet",
//													"def": "MenuItem",
//													"jaxId": "1HNBLBL2M1",
//													"attrs": {
//														"id": "starts",
//														"text": "starts-with",
//														"desc": ""
//													}
//												},
//												{
//													"type": "aioutlet",
//													"def": "MenuItem",
//													"jaxId": "1HNBLBL2M2",
//													"attrs": {
//														"id": "contains",
//														"text": "contains",
//														"desc": ""
//													}
//												}
//											]
//										},
//										"outlet": {
//											"jaxId": "1HNBLD6LU2",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											}
//										}
//									}
//								}
//							]
//						},
//						"outlet": {
//							"jaxId": "1HNBLD6LU3",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1HNBLC5IP0"
//						}
//					}
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1HNDAC2P80",
//					"attrs": {
//						"id": "reset",
//						"label": "New AI Seg",
//						"x": "100",
//						"y": "250",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1HNDADAPU0",
//							"attrs": {
//								"sender": "null",
//								"event": ""
//							}
//						},
//						"async": "true",
//						"localVars": {
//							"jaxId": "1HNDADAPU1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1HNDADAPU2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						}
//					}
//				}
//			]
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1HLEJUAD28",
//			"attrs": {}
//		},
//		"mockupStates": {
//			"jaxId": "1HLEJUAD29",
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1HLEJUAD21",
//			"attrs": {
//				"properties": {
//					"jaxId": "1HLEJUAD210",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Relative",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "20",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "[0,0,5,0]",
//						"padding": "[0,5,0,5]",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Flex X",
//						"itemsAlign": "Center"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "Gear/@StdUI/ui/BtnCheck.js",
//							"jaxId": "1HLEK0F6P0",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1HLEK1VIG0",
//									"attrs": {
//										"size": "18",
//										"text": "#name",
//										"checked": "false",
//										"radio": "false"
//									}
//								},
//								"properties": {
//									"jaxId": "1HLEK1VIG1",
//									"attrs": {
//										"type": "#null#>BtnCheck(18,name,false,false)",
//										"id": "BtnCheck",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"display": "On",
//										"face": "",
//										"fontSize": "14",
//										"margin": "[0,3,0,0]"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HLEK1VIG2",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1HLEK1VIG3",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HLEK1VIG4",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "true",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true",
//								"containerSlots": {
//									"jaxId": "1HLEK1VIG5",
//									"attrs": {}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear/@StdUI/ui/BtnIcon.js",
//							"jaxId": "1HMHMAQ070",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1HMHMAQ071",
//									"attrs": {
//										"style": "\"front\"",
//										"w": "20",
//										"h": "0",
//										"icon": "#appCfg.sharedAssets+\"/btncombo.svg\"",
//										"colorBG": "null"
//									}
//								},
//								"properties": {
//									"jaxId": "1HMHMAQ080",
//									"attrs": {
//										"type": "#null#>BtnIcon(\"front\",20,0,appCfg.sharedAssets+\"/btncombo.svg\",null)",
//										"id": "BtnMode",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"display": "On",
//										"face": ""
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HMHMAQ081",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1HMHMAQ082",
//									"attrs": {
//										"OnClick": {
//											"type": "fixedFunc",
//											"jaxId": "1HNBLD6LU4",
//											"attrs": {
//												"callArgs": {
//													"jaxId": "1HNBLD6LU5",
//													"attrs": {
//														"event": ""
//													}
//												},
//												"seg": "1HNBL4ONI0"
//											}
//										}
//									}
//								},
//								"extraPpts": {
//									"jaxId": "1HMHMAQ083",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true",
//								"containerSlots": {
//									"jaxId": "1HMHMAQ084",
//									"attrs": {}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1HLEKADN10",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HLEKD27L0",
//									"attrs": {
//										"type": "text",
//										"id": "TxtMode",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,3,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "[0,0,0]",
//										"text": "=",
//										"font": "",
//										"fontSize": "#txtSize.mid",
//										"bold": "true",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Top",
//										"wrap": "false",
//										"ellipsis": "false",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HLEKD27M0",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1HLEKD27M1",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HLEKD27M2",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "edit",
//							"jaxId": "1HLEKC02C0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HLEKD27M3",
//									"attrs": {
//										"type": "edit",
//										"id": "EdValue",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "30",
//										"h": "20",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"inputType": "Text",
//										"text": "#value",
//										"placeHolder": "Query string",
//										"color": "[0,0,0]",
//										"bgColor": "[255,255,255,1.00]",
//										"font": "",
//										"fontSize": "16",
//										"outline": "0",
//										"border": "[0,0,1,0]",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"selectOnFocus": "true",
//										"spellCheck": "true",
//										"flex": "true"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HLEKD27M4",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1HLEKD27M5",
//									"attrs": {
//										"OnKeyDown": {
//											"type": "fixedFunc",
//											"jaxId": "1HNDB0EKF0",
//											"attrs": {
//												"callArgs": {
//													"jaxId": "1HNDB0R0I0",
//													"attrs": {
//														"event": ""
//													}
//												},
//												"seg": ""
//											}
//										}
//									}
//								},
//								"extraPpts": {
//									"jaxId": "1HLEKD27M6",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear/@StdUI/ui/BtnIcon.js",
//							"jaxId": "1HMHM5QQB0",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1HMHM6MEJ0",
//									"attrs": {
//										"style": "\"front\"",
//										"w": "20",
//										"h": "0",
//										"icon": "#appCfg.sharedAssets+\"/undo.svg\"",
//										"colorBG": "null"
//									}
//								},
//								"properties": {
//									"jaxId": "1HMHM6MEJ1",
//									"attrs": {
//										"type": "#null#>BtnIcon(\"front\",20,0,appCfg.sharedAssets+\"/undo.svg\",null)",
//										"id": "BtnReset",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"display": "On",
//										"face": ""
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HMHM6MEJ2",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1HMHM6MEJ3",
//									"attrs": {
//										"OnClick": {
//											"type": "fixedFunc",
//											"jaxId": "1HNDADAPU3",
//											"attrs": {
//												"callArgs": {
//													"jaxId": "1HNDADAPU4",
//													"attrs": {
//														"event": ""
//													}
//												},
//												"seg": "1HNDAC2P80"
//											}
//										}
//									}
//								},
//								"extraPpts": {
//									"jaxId": "1HMHM6MEJ4",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false",
//								"containerSlots": {
//									"jaxId": "1HMHM6MEJ5",
//									"attrs": {}
//								}
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1HLEJUAD211",
//					"attrs": {}
//				},
//				"functions": {
//					"jaxId": "1HLEJUAD212",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1HLEJUAD213",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1HLEJUAD214",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}