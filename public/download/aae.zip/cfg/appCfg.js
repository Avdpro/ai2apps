//Auto genterated by Cody
import {VFACT} from "/@vfact";
/*#{Imports*/
/*}#Imports*/
var cfgURL=import.meta.url+"1GGJKJ2SR0;"
/*#{StartDoc*/
VFACT.loadConfig("TabOS-Config");
if(VFACT.lanCode===null){
	let userLanguages = navigator.languages || [navigator.language || navigator.userLanguage];
	let userLanguage = userLanguages[0];
	let languageCode = userLanguage.substring(0, 2).toUpperCase();
	switch(languageCode){
		case "ZH":
			languageCode="CN";
			break;
	}
	VFACT.lanCode=languageCode;
}
/*}#StartDoc*/
let darkMode=false;
let colors={
	"primary":[13,110,253,1],"secondary":[108,117,125,1],"success":[0,128,0,1],"warning":[255,128,12,1],"error":[240,0,0,1],"dark":[30,30,30,1],"light":[250,250,250,1]
};
darkMode=VFACT.darkMode===null?darkMode:VFACT.darkMode;
VFACT.darkMode=darkMode;
if(!window.codyAppCfgs){
	window.codyAppCfgs={};
}
/*#{StartObj*/
/*}#StartObj*/
//----------------------------------------------------------------------------
let appCfg=window.codyAppCfgs[cfgURL]||{//"jaxId":"1GGJKJ2SQ0"
	"darkMode":darkMode,"version":"0.0.1",
	"txtSize":{
		"small":12,"mid":16,"big":20,"smallPlus":14,"midPlus":18,"bigPlus":25,"large":30,"largePlus":35,"huge":40,"hugePlus":50,"smallMid":14,"smallBig":18,
		"smallLarge":24,"smallLarger":32,"larger":36,"smallHuge":42,"bigHuge":56,"smallHuger":64,"huger":72,"bigHuger":80
	},
	"size":{
		"menuLineH":24,"pathLineH":24,"dockerW":90,"dockerWMini":50,"dlgHeaderH":20,"headerH":30,"footerH":25
	},
	"color":{
		"body":darkMode?[55,55,55,1.00]:[255,255,255,1.00],"primary":colors.primary,"secondary":colors.secondary,"success":colors.success,"warning":colors.warning,
		"error":colors.error,"fontBody":darkMode?[255,255,255,1]:[0,0,0,1.00],"fontBodySub":darkMode?[240,240,240,1.00]:[80,80,80,1.00],"fontBodyLit":darkMode?[120,120,120,1]:[180,180,180,1.00],
		"fontPrimary":[255,255,255,1],"fontPrimarySub":[...colors.primary,80],"fontPrimaryLit":[...colors.primary,40],"fontSecondary":[255,255,255,1],"fontSecondarySub":[...colors.secondary,80.00],
		"fontSecondaryLit":[...colors.secondary,40.00],"fontSuccess":[255,255,255,1],"fontSuccessSub":[...colors.success,80.00],"fontSuccessLit":[...colors.success,40.00],
		"fontWarning":[255,255,255,1],"fontWarningSub":[...colors.warning,80],"fontWarningLit":[...colors.warning,40],"fontError":[255,255,255,1],"fontErrorSub":[...colors.error,80],
		"fontErrorLit":[...colors.error,40],"lineBody":darkMode?[255,255,255,1]:[0,0,0,1.00],"lineBodySub":darkMode?[240,240,240,1.00]:[80,80,80,1.00],"lineBodyLit":darkMode?[120,120,120,1]:[180,180,180,1.00],
		"front":[0,0,0,1],"fontFront":[255,255,255,1],"fontFrontSub":[240,240,240,1],"fontFrontLit":[80,80,80,1],"itemOver":darkMode?[255,255,255,0.1]:[0,0,0,0.1],
		"itemDown":darkMode?[255,255,255,0.4]:[0,0,0,0.2],"itemFocus":darkMode?[...colors.primary,-20]:[...colors.primary,80],"itemGray":darkMode?[80,80,80,1]:[200,200,200,1.00],
		"toolBG":[224,224,222,1],"chatBG":[243,243,242,1],"chatInputBG":[233,233,233,1],"hotChatBG":[212,212,210,1],"gntFocus":"linear-gradient(to right, rgba(190,220,2550,1), 50%, rgba(220,240,255,0.5))",
		"subFocus":"linear-gradient(to right, rgba(0,0,0,0.2), 50%, rgba(0,0,0,0.05))","menuBG":[243,243,242,1],"disable":[200,200,200,1],"fontDisable":[255,255,255,1],
		"fontDisableSub":[244,244,244,1],"fontDisableLit":[227.5,227.5,227.5,1],"iconBtnOver":[206.6,226,254.6,1],"iconBtnDown":[158.2,197,254.2,1],"iconBtnUp":[255,255,255,0],
		"hot":[220,240,255,1],"iconFace":[50,50,50,1],"tabTrack":[180,185,190,1],"gntSelected":"linear-gradient(to right, rgba(220,220,220,1), 50%, rgba(220,220,220,0.1))",
		"gntSelect":"linear-gradient(to right, rgba(220,220,220,1), 50%, rgba(220,220,220,0.1))","gntDlgHeader":"linear-gradient(to right, rgba(35,105,200,1), 60%, rgba(220,240,255,1.0), 95%, rgba(220,240,255,1.0))",
		"gntHotText":"linear-gradient(to right, rgba(190,220,255,0),rgba(190,220,255,1), rgba(190,220,255,1),rgba(220,240,255,0.0))","tool":[240,240,240,1],
		"fontTool":[240,240,240,1,-100],"fontToolSub":[240,240,240,1,-60],"fontToolLit":[240,240,240,1,-30],"head":[230,230,230,1],"footer":[220,220,220,1],
		"gntLineBreak":"linear-gradient(to right, rgba(0,0,0,1),rgba(0,0,0,1), rgba(0,0,0,0))"
	},
	"sharedAssets":"/~/-tabos/shared/assets","lanCode":"CN",
	/*#{ExAttrs*/
	/*}#ExAttrs*/
};
window.codyAppCfgs[cfgURL]=appCfg;
appCfg.lanCode=VFACT.lanCode===null?"EN":(VFACT.lanCode||"EN");
VFACT.lanCode=appCfg.lanCode;
if(!VFACT.appCfg){
	VFACT.appCfg=appCfg;
	window.jaxAppCfg=appCfg;
}
appCfg.applyCfg=function(){
	let majorCfg,attrName,cAttr,mAttr;
	majorCfg=VFACT.appCfg||window.jaxAppCfg;
	if(majorCfg && majorCfg!==appCfg){
		for(attrName in appCfg){
			if(attrName in majorCfg){
				cAttr=appCfg[attrName];
				mAttr=majorCfg[attrName];
				if(typeof(cAttr)==="object"){
					if(typeof(mAttr)==="object"){
						Object.assign(cAttr,mAttr);
					}
				}else if(attrName!=="applyCfg" && attrName!=="proxyCfg"){
					appCfg[attrName]=mAttr;
				}
			}
		}
	}
};
appCfg.proxyCfg=function(proxy){
	if(window.codyAppCfgs[cfgURL]===appCfg){
		window.codyAppCfgs[cfgURL]=proxy;
	}
	appCfg=proxy;
};

/*#{EndDoc*/
const hasFinePointer = window.matchMedia('(pointer: fine)').matches;
const isTouchDevice = 'ontouchstart' in window || navigator.maxTouchPoints > 0;
appCfg.isTouchDevice=isTouchDevice;
appCfg.hasFinePointer=hasFinePointer;
appCfg.isMobile=/Mobi|Android|iPhone|iPad|iPod|Phone/i.test(navigator.userAgent);
/*}#EndDoc*/

export{appCfg};
/*Cody Project Doc*/
//{
//	"jaxId": "1GGJKJ2SR0",
//	"attrs": {
//		"localVars": {
//			"jaxId": "1GGJKJ2SR1",
//			"attrs": {
//				"darkMode": "false",
//				"colors": {
//					"type": "object",
//					"def": "Object",
//					"jaxId": "1GGJM2JI80",
//					"attrs": {
//						"primary": {
//							"type": "colorRGBA",
//							"valText": "[13,110,253,1]"
//						},
//						"secondary": {
//							"type": "colorRGBA",
//							"valText": "[108,117,125,1]"
//						},
//						"success": {
//							"type": "colorRGBA",
//							"valText": "[0,128,0,1.00]"
//						},
//						"warning": {
//							"type": "colorRGBA",
//							"valText": "[255,128,12,1]"
//						},
//						"error": {
//							"type": "colorRGBA",
//							"valText": "[240,0,0,1.00]"
//						},
//						"dark": {
//							"type": "colorRGBA",
//							"valText": "[30,30,30,1.00]"
//						},
//						"light": {
//							"type": "colorRGBA",
//							"valText": "[250,250,250,1]"
//						}
//					}
//				}
//			}
//		},
//		"editObjs": {
//			"jaxId": "1GGJKJ2SR2",
//			"attrs": {
//				"appCfg": {
//					"jaxId": "1GGJKJ2SQ0",
//					"attrs": {
//						"darkMode": "#darkMode",
//						"version": "0.0.1",
//						"txtSize": {
//							"jaxId": "1GGJKJ2SR3",
//							"attrs": {
//								"small": "12",
//								"mid": "16",
//								"big": "20",
//								"smallPlus": {
//									"type": "int",
//									"valText": "14"
//								},
//								"midPlus": {
//									"type": "int",
//									"valText": "18"
//								},
//								"bigPlus": {
//									"type": "int",
//									"valText": "25"
//								},
//								"large": {
//									"type": "int",
//									"valText": "30"
//								},
//								"largePlus": {
//									"type": "int",
//									"valText": "35"
//								},
//								"huge": {
//									"type": "int",
//									"valText": "40"
//								},
//								"hugePlus": {
//									"type": "int",
//									"valText": "50"
//								},
//								"smallMid": {
//									"valText": "14"
//								},
//								"smallBig": {
//									"valText": "18"
//								},
//								"smallLarge": {
//									"valText": "24"
//								},
//								"smallLarger": {
//									"valText": "32"
//								},
//								"larger": {
//									"valText": "36"
//								},
//								"smallHuge": {
//									"valText": "42"
//								},
//								"bigHuge": {
//									"valText": "56"
//								},
//								"smallHuger": {
//									"valText": "64"
//								},
//								"huger": {
//									"valText": "72"
//								},
//								"bigHuger": {
//									"valText": "80"
//								}
//							}
//						},
//						"size": {
//							"jaxId": "1GGJKJ2SR4",
//							"attrs": {
//								"menuLineH": {
//									"valText": "24"
//								},
//								"pathLineH": {
//									"valText": "24"
//								},
//								"dockerW": {
//									"valText": "90"
//								},
//								"dockerWMini": {
//									"valText": "50"
//								},
//								"dlgHeaderH": {
//									"valText": "20"
//								},
//								"headerH": {
//									"valText": "30"
//								},
//								"footerH": {
//									"valText": "25"
//								}
//							}
//						},
//						"color": {
//							"jaxId": "1GGJKJ2SR5",
//							"attrs": {
//								"body": {
//									"type": "colorRGBA",
//									"valText": "#darkMode?[55,55,55,1.00]:[255,255,255,1.00]"
//								},
//								"primary": {
//									"type": "colorRGBA",
//									"valText": "#colors.primary"
//								},
//								"secondary": {
//									"type": "colorRGBA",
//									"valText": "#colors.secondary"
//								},
//								"success": {
//									"type": "colorRGBA",
//									"valText": "#colors.success"
//								},
//								"warning": {
//									"type": "colorRGBA",
//									"valText": "#colors.warning"
//								},
//								"error": {
//									"type": "colorRGBA",
//									"valText": "#colors.error"
//								},
//								"fontBody": {
//									"type": "colorRGBA",
//									"valText": "#darkMode?[255,255,255,1]:[0,0,0,1.00]"
//								},
//								"fontBodySub": {
//									"type": "colorRGBA",
//									"valText": "#darkMode?[240,240,240,1.00]:[80,80,80,1.00]"
//								},
//								"fontBodyLit": {
//									"type": "colorRGBA",
//									"valText": "#darkMode?[120,120,120,1]:[180,180,180,1.00]"
//								},
//								"fontPrimary": {
//									"type": "colorRGBA",
//									"valText": "[255,255,255,1.00]"
//								},
//								"fontPrimarySub": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.primary,80]"
//								},
//								"fontPrimaryLit": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.primary,40]"
//								},
//								"fontSecondary": {
//									"type": "colorRGBA",
//									"valText": "[255,255,255,1.00]"
//								},
//								"fontSecondarySub": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.secondary,80.00]"
//								},
//								"fontSecondaryLit": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.secondary,40.00]"
//								},
//								"fontSuccess": {
//									"type": "colorRGBA",
//									"valText": "[255,255,255,1.00]"
//								},
//								"fontSuccessSub": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.success,80.00]"
//								},
//								"fontSuccessLit": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.success,40.00]"
//								},
//								"fontWarning": {
//									"type": "colorRGBA",
//									"valText": "[255,255,255,1.00]"
//								},
//								"fontWarningSub": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.warning,80]"
//								},
//								"fontWarningLit": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.warning,40]"
//								},
//								"fontError": {
//									"type": "colorRGBA",
//									"valText": "[255,255,255,1.00]"
//								},
//								"fontErrorSub": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.error,80]"
//								},
//								"fontErrorLit": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.error,40]"
//								},
//								"lineBody": {
//									"type": "colorRGBA",
//									"valText": "#darkMode?[255,255,255,1]:[0,0,0,1.00]"
//								},
//								"lineBodySub": {
//									"type": "colorRGBA",
//									"valText": "#darkMode?[240,240,240,1.00]:[80,80,80,1.00]"
//								},
//								"lineBodyLit": {
//									"type": "colorRGBA",
//									"valText": "#darkMode?[120,120,120,1]:[180,180,180,1.00]"
//								},
//								"front": {
//									"valText": "[0,0,0,1]"
//								},
//								"fontFront": {
//									"valText": "[255,255,255,1]"
//								},
//								"fontFrontSub": {
//									"valText": "[240,240,240,1]"
//								},
//								"fontFrontLit": {
//									"valText": "[80,80,80,1]"
//								},
//								"itemOver": {
//									"type": "colorRGBA",
//									"valText": "#darkMode?[255,255,255,0.1]:[0,0,0,0.1]"
//								},
//								"itemDown": {
//									"type": "colorRGBA",
//									"valText": "#darkMode?[255,255,255,0.4]:[0,0,0,0.2]"
//								},
//								"itemFocus": {
//									"type": "colorRGBA",
//									"valText": "#darkMode?[...colors.primary,-20]:[...colors.primary,80]"
//								},
//								"itemGray": {
//									"type": "colorRGBA",
//									"valText": "#darkMode?[80,80,80,1]:[200,200,200,1.00]"
//								},
//								"toolBG": {
//									"type": "colorRGBA",
//									"valText": "[224,224,222,1.00]"
//								},
//								"chatBG": {
//									"type": "colorRGBA",
//									"valText": "[243,243,242,1.00]"
//								},
//								"chatInputBG": {
//									"type": "colorRGBA",
//									"valText": "[233,233,233,1]"
//								},
//								"hotChatBG": {
//									"type": "colorRGBA",
//									"valText": "[212,212,210,1.00]"
//								},
//								"gntFocus": {
//									"valText": "\"linear-gradient(to right, rgba(190,220,2550,1), 50%, rgba(220,240,255,0.5))\""
//								},
//								"subFocus": {
//									"valText": "\"linear-gradient(to right, rgba(0,0,0,0.2), 50%, rgba(0,0,0,0.05))\""
//								},
//								"menuBG": {
//									"valText": "[243,243,242,1]"
//								},
//								"disable": {
//									"valText": "[200,200,200,1]"
//								},
//								"fontDisable": {
//									"valText": "[255,255,255,1]"
//								},
//								"fontDisableSub": {
//									"valText": "[244,244,244,1]"
//								},
//								"fontDisableLit": {
//									"valText": "[227.5,227.5,227.5,1]"
//								},
//								"iconBtnOver": {
//									"valText": "[206.6,226,254.6,1]"
//								},
//								"iconBtnDown": {
//									"valText": "[158.2,197,254.2,1]"
//								},
//								"iconBtnUp": {
//									"valText": "[255,255,255,0]"
//								},
//								"hot": {
//									"valText": "[220,240,255,1]"
//								},
//								"iconFace": {
//									"valText": "[50,50,50,1]"
//								},
//								"tabTrack": {
//									"valText": "[180,185,190,1]"
//								},
//								"gntSelected": {
//									"valText": "\"linear-gradient(to right, rgba(220,220,220,1), 50%, rgba(220,220,220,0.1))\""
//								},
//								"gntSelect": {
//									"valText": "\"linear-gradient(to right, rgba(220,220,220,1), 50%, rgba(220,220,220,0.1))\""
//								},
//								"gntDlgHeader": {
//									"valText": "\"linear-gradient(to right, rgba(35,105,200,1), 60%, rgba(220,240,255,1.0), 95%, rgba(220,240,255,1.0))\""
//								},
//								"gntHotText": {
//									"valText": "\"linear-gradient(to right, rgba(190,220,255,0),rgba(190,220,255,1), rgba(190,220,255,1),rgba(220,240,255,0.0))\""
//								},
//								"tool": {
//									"valText": "[240,240,240,1]"
//								},
//								"fontTool": {
//									"valText": "[240,240,240,1,-100]"
//								},
//								"fontToolSub": {
//									"valText": "[240,240,240,1,-60]"
//								},
//								"fontToolLit": {
//									"valText": "[240,240,240,1,-30]"
//								},
//								"head": {
//									"valText": "[230,230,230,1]"
//								},
//								"footer": {
//									"valText": "[220,220,220,1]"
//								},
//								"gntLineBreak": {
//									"valText": "\"linear-gradient(to right, rgba(0,0,0,1),rgba(0,0,0,1), rgba(0,0,0,0))\""
//								}
//							}
//						},
//						"sharedAssets": {
//							"valText": "\"/~/-tabos/shared/assets\""
//						},
//						"lanCode": {
//							"valText": "\"CN\""
//						}
//					}
//				}
//			}
//		}
//	}
//}