import {AAChatFlow} from "../AAChatFlow.js";

//----------------------------------------------------------------------------
function setupWorkAsk(session,hostBot,taskWork){
	session.askUserRaw=async function(askVO){
		let funcDone,funcError,pms,chatFlow,flowObj,userId;
		let askMsg;
		pms=new Promise((resolve,reject)=>{
			funcDone=resolve;
			funcError=reject;
		});
		chatFlow=taskWork.chatFlow;
		flowObj=await AAChatFlow.getFlow(chatFlow);
		userId=flowObj.from;
		askMsg={
			type:"Ask",from:hostBot.id,to:userId,chatFlow:chatFlow,
			askVO:askVO
		};
		await hostBot.sendMessage();
				
	};
}

export {setupWorkAsk}