//Auto genterated by Cody
import VFACT from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1IT1SN0JL0StartDoc*/
let $ln=VFACT.lanCode;
/*}#1IT1SN0JL0StartDoc*/
let AppConfig={
	name:"AppConfig",//1IT1SN0JL2
	type:"object",
	label:undefined,
	properties:{
		APIROOT:{
			name:"APIROOT",type:"string",
			label:(($ln==="CN")?("API 源网址:"):("API source url:")),
		},
		PORT:{
			name:"PORT",type:"int",
			label:(($ln==="CN")?("本地服务端口号:"):("Local server port:")),
			defaultValue:3015,
			desc:(($ln==="CN")?("警告：不同的端口号会对应不同的Tab-OS实例，以及，不同的文件系统。"):("Warning: different port mapping to different Tab-OS instance, thus, different file-system.")),
		},
		OPENAI_API_KEY:{
			name:"OPENAI_API_KEY",type:"string",
			label:"OpenAI API key:",
		},
		CLAUDE_API_KEY:{
			name:"CLAUDE_API_KEY",type:"string",
			label:"ClaudeAI API key:",
		},
		GOOGLEAI_API_KEY:{
			name:"GOOGLEAI_API_KEY",type:"string",
			label:"GoogleAI API key:",
		},
		AAF_EXECUATABLE:{
			name:"AAF_EXECUATABLE",type:"string",
			label:"Chrome path:",
			defaultValue:"/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
		},
		/*#{1IT1SN0JL2MoreProperties*/
		/*}#1IT1SN0JL2MoreProperties*/
	},
	desc:undefined,
	newObject(){return VFACT.newUITemplateObj(this)},
	/*#{1IT1SN0JL2MoreFunctions*/
	/*}#1IT1SN0JL2MoreFunctions*/
};
VFACT.regUITemplate("1IT1SN0JL2",AppConfig);
VFACT.regUITemplate("AppConfig",AppConfig);
/*#{1IT1SN0JL2MoreCodes*/
/*}#1IT1SN0JL2MoreCodes*/

/*#{1IT1SN0JL0EndDoc*/
/*}#1IT1SN0JL0EndDoc*/

export{AppConfig};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DataDoc",
//	"jaxId": "1IT1SN0JL0",
//	"attrs": {
//		"editObjs": {
//			"jaxId": "1IT1SN0JL1",
//			"attrs": {
//				"AppConfig": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1IT1SN0JL2",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1IT1SN0JL3",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1IT1SN0JL4",
//							"attrs": {
//								"APIROOT": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1IT22CED10",
//									"attrs": {
//										"type": "string",
//										"label": {
//											"type": "string",
//											"valText": "API source url:",
//											"localize": {
//												"EN": "API source url:",
//												"CN": "API 源网址:"
//											},
//											"localizable": true
//										}
//									}
//								},
//								"PORT": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1IT1TFL5B0",
//									"attrs": {
//										"type": "int",
//										"label": {
//											"type": "string",
//											"valText": "Local server port:",
//											"localize": {
//												"EN": "Local server port:",
//												"CN": "本地服务端口号:"
//											},
//											"localizable": true
//										},
//										"defaultValue": "3015",
//										"desc": {
//											"type": "string",
//											"valText": "Warning: different port mapping to different Tab-OS instance, thus, different file-system.",
//											"localize": {
//												"EN": "Warning: different port mapping to different Tab-OS instance, thus, different file-system.",
//												"CN": "警告：不同的端口号会对应不同的Tab-OS实例，以及，不同的文件系统。"
//											},
//											"localizable": true
//										}
//									}
//								},
//								"OPENAI_API_KEY": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1IT1TB3150",
//									"attrs": {
//										"type": "string",
//										"label": "OpenAI API key:"
//									}
//								},
//								"CLAUDE_API_KEY": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1IT1TB3151",
//									"attrs": {
//										"type": "string",
//										"label": "ClaudeAI API key:"
//									}
//								},
//								"GOOGLEAI_API_KEY": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1IT1TB3152",
//									"attrs": {
//										"type": "string",
//										"label": "GoogleAI API key:"
//									}
//								},
//								"AAF_EXECUATABLE": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1IT1TB3153",
//									"attrs": {
//										"type": "string",
//										"label": "Chrome path:",
//										"defaultValue": "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
//									}
//								}
//							}
//						},
//						"functions": {
//							"jaxId": "1IT1SN0JL5",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false",
//						"exportClass": "false"
//					},
//					"mockups": {}
//				}
//			}
//		}
//	}
//}