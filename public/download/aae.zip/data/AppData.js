//Auto genterated by Cody
import VFACT from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1HRCEQ9730StartDoc*/
const $ln=VFACT.lanCode||"EN";
/*}#1HRCEQ9730StartDoc*/
//----------------------------------------------------------------------------
/*#{1HRCEQ9732Constructor+*/
let AppData=function(){
/*}#1HRCEQ9732Constructor+*/
	/*#{1HRCEQ9732PreConstruct*/
	/*}#1HRCEQ9732PreConstruct*/
	/*#{1HRCEQ9732Properties+*/
	/*}#1HRCEQ9732Properties+*/
	/*#{1HRCEQ9732PostConstruct*/
	/*}#1HRCEQ9732PostConstruct*/
};
AppData.prototype={};
let _AppData=AppData.prototype;
/*#{1HRCEQ9732ExCodes*/
/*}#1HRCEQ9732ExCodes*/

let Agrument={
	name:"Agrument",//1HRFSVGO50
	type:"object",
	properties:{
		name:{
			name:"name",type:"string",
		},
		value:{
			name:"value",type:"auto",
		},
		/*#{1HRFSVGO50MoreProperties*/
		/*}#1HRFSVGO50MoreProperties*/
	},
	newObject(){return VFACT.newUITemplateObj(this)},
	/*#{1HRFSVGO50MoreFunctions*/
	/*}#1HRFSVGO50MoreFunctions*/
};
VFACT.regUITemplate("1HRFSVGO50",Agrument);
VFACT.regUITemplate("Agrument",Agrument);
/*#{1HRFSVGO50MoreCodes*/
/*}#1HRFSVGO50MoreCodes*/
let UserAction={
	name:"UserAction",//1HRCEVTGL0
	type:"object",
	properties:{
		action:{
			name:"action",type:"string",
			label:"Action:",
			defaultValue:"clickOn",
			required:true,
			choices:[
				{text:"Click On Query",value:"clickOn"},{text:"Tap On Query",value:"tapOn"},{text:"Type On Query",value:"typeOn"},{text:"Hover On Query",value:"hoverOn"},{text:"Select On Query",value:"selectOn"},{text:"Reset Mouse",value:"mouseReset"},{text:"Mouse Move",value:"mouseMove"},{text:"Mouse Down",value:"mouseDown"},{text:"Mouse Up",value:"mouseUp"},{text:"Mouse Click",value:"mouseClick"},{text:"Key Down",value:"keyDown"},{text:"Key Up",value:"keyUp"},{text:"Key Press",value:"keyPress"},{text:"Key Type",value:"keyType"},{text:"Touch Tap",value:"touchTap"},{text:"Touch Start",value:"touchStart"},{text:"Touch Move",value:"touchMove"},{text:"Touch End",value:"touchEnd"},{text:"Navi Goto",value:"goto"},{text:"Await Signal",value:"await"},{text:"Wait Page Navi",value:"waitNavi"},{text:"Wait Network Idle",value:"waitNetworkIdle"},{text:"Wait File Chooser",value:"waitFileChooser"},{text:"Wait Device Prompt",value:"waitDevicePrompt"},{text:"Wait Query",value:"waitQuery"},{text:"Wait Function",value:"waitFunction"}
			],
			desc:"Action",
		},
		query:{
			name:"query",type:"string",
			label:"Query:",
		},
		content:{
			name:"content",type:"string",
			label:"Content",
		},
		x:{
			name:"x",type:"number",
			label:"Pos-X:",
		},
		y:{
			name:"y",type:"number",
			label:"Pos-Y:",
		},
		key:{
			name:"key",type:"string",
		},
		waitBefore:{
			name:"waitBefore",type:"int",
			label:"Before:",
		},
		waitAfter:{
			name:"waitAfter",type:"int",
			label:"After:",
		},
		options:{
			name:"options",type:"auto",
			label:"Options:",
			defaultValue:null,
		},
		/*#{1HRCEVTGL0MoreProperties*/
		/*}#1HRCEVTGL0MoreProperties*/
	},
	layout:[{"type":"actPpt","ppt":"action","action":"execute","icon":"/~/-tabos/shared/assets/run.svg","tip":"Run Action"},"query","content","key",["x","y"],{"type":"seg","text":"Wait time(ms):"},["waitBefore","waitAfter"],"options"],
	newObject(){return VFACT.newUITemplateObj(this)},
	/*#{1HRCEVTGL0MoreFunctions*/
	OnEdit(dvData){
		let missing,vo;
		vo=dvData.getEditedVO();
		switch(vo.action){
			case "clickOn":
				dvData.hidePptLine("content");
				dvData.hidePptLine("key");
				dvData.showPptLine("query");
				dvData.showPptLine("x");
				dvData.showPptLine("y");
				dvData.showPptLine("options");
				break;
			case "typeOn":
				dvData.showPptLine("content");
				dvData.hidePptLine("key");
				dvData.showPptLine("query");
				dvData.hidePptLine("x");
				dvData.hidePptLine("y");
				dvData.showPptLine("options");
				break;
			case "tapOn":
				dvData.hidePptLine("content");
				dvData.hidePptLine("key");
				dvData.showPptLine("query");
				dvData.showPptLine("x");
				dvData.showPptLine("y");
				dvData.showPptLine("options");
				break;
			case "hoverOn":
				dvData.hidePptLine("content");
				dvData.hidePptLine("key");
				dvData.showPptLine("query");
				dvData.hidePptLine("x");
				dvData.hidePptLine("y");
				dvData.showPptLine("options");
				break;
			case "selectOn":
				dvData.showPptLine("content");
				dvData.hidePptLine("key");
				dvData.showPptLine("query");
				dvData.hidePptLine("x");
				dvData.hidePptLine("y");
				dvData.showPptLine("options");
				break;
			case "mouseReset":
				dvData.hidePptLine("content");
				dvData.hidePptLine("key");
				dvData.hidePptLine("query");
				dvData.hidePptLine("x");
				dvData.hidePptLine("y");
				dvData.hidePptLine("options");
				break;
			case "mouseMove":
				dvData.hidePptLine("content");
				dvData.hidePptLine("key");
				dvData.hidePptLine("query");
				dvData.showPptLine("x");
				dvData.showPptLine("y");
				dvData.showPptLine("options");
				break;
			case "mouseDown":
				dvData.hidePptLine("content");
				dvData.hidePptLine("key");
				dvData.hidePptLine("query");
				dvData.hidePptLine("x");
				dvData.hidePptLine("y");
				dvData.showPptLine("options");
				break;
			case "mouseUp":
				dvData.hidePptLine("content");
				dvData.hidePptLine("key");
				dvData.hidePptLine("query");
				dvData.hidePptLine("x");
				dvData.hidePptLine("y");
				dvData.showPptLine("options");
				break;
			case "mouseClick":
				dvData.hidePptLine("content");
				dvData.hidePptLine("key");
				dvData.hidePptLine("query");
				dvData.showPptLine("x");
				dvData.showPptLine("y");
				dvData.showPptLine("options");
				break;
			case "keyDown":
			case "keyUp":
			case "keyPress":
				dvData.hidePptLine("content");
				dvData.showPptLine("key");
				dvData.hidePptLine("query");
				dvData.hidePptLine("x");
				dvData.hidePptLine("y");
				dvData.showPptLine("options");
				break;
			case "keyType":
				dvData.showPptLine("content");
				dvData.hidePptLine("key");
				dvData.hidePptLine("query");
				dvData.hidePptLine("x");
				dvData.hidePptLine("y");
				dvData.showPptLine("options");
				break;
			case "touchTap":
			case "touchStart":
			case "touchMove":
				dvData.hidePptLine("content");
				dvData.hidePptLine("key");
				dvData.hidePptLine("query");
				dvData.showPptLine("x");
				dvData.showPptLine("y");
				dvData.showPptLine("options");
				break;
			case "touchEnd":
				dvData.hidePptLine("content");
				dvData.hidePptLine("key");
				dvData.hidePptLine("query");
				dvData.hidePptLine("x");
				dvData.hidePptLine("y");
				dvData.showPptLine("options");
				break;
			case "goto":
				dvData.showPptLine("content");
				dvData.hidePptLine("key");
				dvData.hidePptLine("query");
				dvData.hidePptLine("x");
				dvData.hidePptLine("y");
				dvData.showPptLine("options");
				break;
			case "await":
				dvData.hidePptLine("content");
				dvData.showPptLine("key");
				dvData.hidePptLine("query");
				dvData.hidePptLine("x");
				dvData.hidePptLine("y");
				dvData.showPptLine("options");
				break;
			case "waitNavi":
			case "waitNetworkIdle":
			case "waitDialog":
			case "waitFileChooser":
			case "waitDevicePrompt":
				dvData.hidePptLine("content");
				dvData.showPptLine("key");
				dvData.hidePptLine("query");
				dvData.hidePptLine("x");
				dvData.hidePptLine("y");
				dvData.showPptLine("options");
				break;
			case "waitQuery":
				dvData.hidePptLine("content");
				dvData.showPptLine("key");
				dvData.showPptLine("query");
				dvData.hidePptLine("x");
				dvData.hidePptLine("y");
				dvData.showPptLine("options");
				break;
			case "waitFunction":
				dvData.showPptLine("content");
				dvData.showPptLine("key");
				dvData.hidePptLine("query");
				dvData.hidePptLine("x");
				dvData.hidePptLine("y");
				dvData.showPptLine("options");
				break;
		}
		dvData.clearErrorTips();
		return;
	}
	/*}#1HRCEVTGL0MoreFunctions*/
};
VFACT.regUITemplate("1HRCEVTGL0",UserAction);
VFACT.regUITemplate("UserAction",UserAction);
/*#{1HRCEVTGL0MoreCodes*/
/*}#1HRCEVTGL0MoreCodes*/
let Actions={
	name:"Actions",//1HRER99Q80
	type:"object",
	properties:{
		arguments:{
			name:"arguments",type:"array",
			label:"Arguments",
			initLength:0,
			element:{
				"type":"object","class":"1HRFSVGO50","label":'###:'
			},
		},
		actions:{
			name:"actions",type:"array",
			label:"Actions",
			initLength:0,
			element:{
				"type":"object","class":"1HRCEVTGL0","label":'###:'
			},
		},
		/*#{1HRER99Q80MoreProperties*/
		/*}#1HRER99Q80MoreProperties*/
	},
	newObject(){return VFACT.newUITemplateObj(this)},
	/*#{1HRER99Q80MoreFunctions*/
	/*}#1HRER99Q80MoreFunctions*/
};
VFACT.regUITemplate("1HRER99Q80",Actions);
VFACT.regUITemplate("Actions",Actions);
/*#{1HRER99Q80MoreCodes*/
//----------------------------------------------------------------------------
Actions.loadFromVO=function(vo){
	//TODO: Code this:
	return {...vo};
};

//----------------------------------------------------------------------------
Actions.genSaveVO=function(vo){
	//TODO: Code this:
	return {...vo};
};
/*}#1HRER99Q80MoreCodes*/
let ActionFilter={
	name:"ActionFilter",//1HU6OS1TL0
	type:"object",
	properties:{
		network:{
			name:"network",type:"bool",
			label:"Network Events:",
		},
		navigation:{
			name:"navigation",type:"bool",
			label:"Navigation Events:",
		},
		action:{
			name:"action",type:"bool",
			label:"User Actions:",
		},
		/*#{1HU6OS1TL0MoreProperties*/
		/*}#1HU6OS1TL0MoreProperties*/
	},
	newObject(){return VFACT.newUITemplateObj(this)},
	/*#{1HU6OS1TL0MoreFunctions*/
	label:"",
	/*}#1HU6OS1TL0MoreFunctions*/
};
VFACT.regUITemplate("1HU6OS1TL0",ActionFilter);
VFACT.regUITemplate("ActionFilter",ActionFilter);
/*#{1HU6OS1TL0MoreCodes*/
/*}#1HU6OS1TL0MoreCodes*/
let BrowserArgs={
	name:"BrowserArgs",//1HUND4UR70
	type:"object",
	properties:{
		alias:{
			name:"alias",type:"string",
			label:"Alias:",
			required:true,
		},
		dataDir:{
			name:"dataDir",type:"bool",
			defaultValue:false,
			desc:"When true, browser will use a data-dir by it's alias, so browsing state can be saved.",
		},
		/*#{1HUND4UR70MoreProperties*/
		/*}#1HUND4UR70MoreProperties*/
	},
	newObject(){return VFACT.newUITemplateObj(this)},
	/*#{1HUND4UR70MoreFunctions*/
	/*}#1HUND4UR70MoreFunctions*/
};
VFACT.regUITemplate("1HUND4UR70",BrowserArgs);
VFACT.regUITemplate("BrowserArgs",BrowserArgs);
/*#{1HUND4UR70MoreCodes*/
/*}#1HUND4UR70MoreCodes*/
let ToolEntry={
	name:"ToolEntry",//1I18I5LNG0
	type:"object",
	properties:{
		execData:{
			name:"execData",type:"string",
			defaultValue:{},
			required:true,
			desc:(($ln==="CN")?("用于执行技能的参数的JSON对象，例如：{\"search\":\"AI Agent\"}"):("JSON object for executing the Tool, for example: {\"search\":\"AI Agent\"}")),
		},
		command:{
			name:"command",type:"string",
			required:true,
			desc:(($ln==="CN")?("指示操作的指令，包括对execData内容的引用，例如：根据execData进行搜索"):("Instruction indicating the operation, including a reference to the execData content, for example: search based on execData")),
		},
		/*#{1I18I5LNG0MoreProperties*/
		/*}#1I18I5LNG0MoreProperties*/
	},
	newObject(){return VFACT.newUITemplateObj(this)},
	/*#{1I18I5LNG0MoreFunctions*/
	OnEdit(dvData){
		let error=false;;
		let vo=dvData.getEditedVO();
		if(!vo.command){
			error=true;
		}
		let execData=vo.execData;
		try{
			execData=JSON.parse(execData);
		}catch(err){
			error=true;
		}
		return error;
	}
	/*}#1I18I5LNG0MoreFunctions*/
};
VFACT.regUITemplate("1I18I5LNG0",ToolEntry);
VFACT.regUITemplate("ToolEntry",ToolEntry);
/*#{1I18I5LNG0MoreCodes*/
/*}#1I18I5LNG0MoreCodes*/
let ToolInfo={
	name:"ToolInfo",//1I27DP3TM0
	type:"object",
	properties:{
		name:{
			name:"name",type:"string",
			label:(($ln==="CN")?("名称:"):("Name:")),
		},
		type:{
			name:"type",type:"string",
			label:(($ln==="CN")?("类型:"):("Type:")),
		},
		filePath:{
			name:"filePath",type:"string",
			label:(($ln==="CN")?("文件路径:"):("File Path:")),
		},
		description:{
			name:"description",type:"string",
			label:(($ln==="CN")?("说明:"):("Description:")),
			uiMode:"Note",
		},
		isRPA:{
			name:"isRPA",type:"bool",
			label:(($ln==="CN")?("是否是RPA技能:"):("Is RPA Tool:")),
		},
		rpaHost:{
			name:"rpaHost",type:"string",
			label:"RPA Host:",
		},
		package:{
			name:"package",type:"string",
			label:(($ln==="CN")?("功能包:"):("Package:")),
		},
		reference:{
			name:"reference",type:"string",
			label:(($ln==="CN")?("引用状态:"):("Reference:")),
		},
		/*#{1I27DP3TM0MoreProperties*/
		/*}#1I27DP3TM0MoreProperties*/
	},
	newObject(){return VFACT.newUITemplateObj(this)},
	/*#{1I27DP3TM0MoreFunctions*/
	/*}#1I27DP3TM0MoreFunctions*/
};
VFACT.regUITemplate("1I27DP3TM0",ToolInfo);
VFACT.regUITemplate("ToolInfo",ToolInfo);
/*#{1I27DP3TM0MoreCodes*/
/*}#1I27DP3TM0MoreCodes*/
let ToolChainDef={
	name:"ToolChainDef",//1I27EOBVT0
	type:"object",
	properties:{
		name:{
			name:"name",type:"string",
		},
		desc:{
			name:"desc",type:"string",
		},
		guide:{
			name:"guide",type:"string",
		},
		tools:{
			name:"tools",type:"array",
			initLength:0,
			element:{
				"type":"string","label":'###:'
			},
		},
		/*#{1I27EOBVT0MoreProperties*/
		/*}#1I27EOBVT0MoreProperties*/
	},
	newObject(){return VFACT.newUITemplateObj(this)},
	/*#{1I27EOBVT0MoreFunctions*/
	/*}#1I27EOBVT0MoreFunctions*/
};
VFACT.regUITemplate("1I27EOBVT0",ToolChainDef);
VFACT.regUITemplate("ToolChainDef",ToolChainDef);
/*#{1I27EOBVT0MoreCodes*/
/*}#1I27EOBVT0MoreCodes*/
let BotInfo={
	name:"BotInfo",//1I2B4INBE0
	type:"object",
	properties:{
		name:{
			name:"name",type:"string",
			label:"Bot:",
			desc:"Bot name",
		},
		alias:{
			name:"alias",type:"string",
			label:"Browser Alias:",
			desc:"Browser alias.",
		},
		active:{
			name:"active",type:"bool",
			label:"Active:",
		},
		description:{
			name:"description",type:"string",
			label:"Description",
			uiMode:"Note",
		},
		/*#{1I2B4INBE0MoreProperties*/
		/*}#1I2B4INBE0MoreProperties*/
	},
	newObject(){return VFACT.newUITemplateObj(this)},
	/*#{1I2B4INBE0MoreFunctions*/
	/*}#1I2B4INBE0MoreFunctions*/
};
VFACT.regUITemplate("1I2B4INBE0",BotInfo);
VFACT.regUITemplate("BotInfo",BotInfo);
/*#{1I2B4INBE0MoreCodes*/
/*}#1I2B4INBE0MoreCodes*/
let EvntStat={
	name:"EvntStat",//1I2C8VFEN0
	type:"object",
	properties:{
		toolExec:{
			name:"toolExec",type:"int",
			readOnly:true,
		},
		chainExec:{
			name:"chainExec",type:"int",
			readOnly:true,
		},
		toolFail:{
			name:"toolFail",type:"int",
			readOnly:true,
		},
		chainFail:{
			name:"chainFail",type:"int",
			readOnly:true,
		},
		messageReceived:{
			name:"messageReceived",type:"int",
			readOnly:true,
		},
		messageSent:{
			name:"messageSent",type:"int",
			readOnly:true,
		},
		/*#{1I2C8VFEN0MoreProperties*/
		/*}#1I2C8VFEN0MoreProperties*/
	},
	newObject(){return VFACT.newUITemplateObj(this)},
	/*#{1I2C8VFEN0MoreFunctions*/
	/*}#1I2C8VFEN0MoreFunctions*/
};
VFACT.regUITemplate("1I2C8VFEN0",EvntStat);
VFACT.regUITemplate("EvntStat",EvntStat);
/*#{1I2C8VFEN0MoreCodes*/
/*}#1I2C8VFEN0MoreCodes*/
let BotState={
	name:"BotState",//1I2C843JD0
	type:"object",
	properties:{
		type:{
			name:"type",type:"string",
			label:"Type:",
		},
		headless:{
			name:"headless",type:"bool",
			label:"Headless:",
			defaultValue:false,
		},
		description:{
			name:"description",type:"string",
			label:"Description",
		},
		startTime:{
			name:"startTime",type:"int",
			label:(($ln==="CN")?("启动时间"):("Start Time")),
		},
		lastActive:{
			name:"lastActive",type:"int",
			label:(($ln==="CN")?("最近活跃时间"):("Recent activity time")),
		},
		pages:{
			name:"pages",type:"array",
			label:"Pages:",
			initLength:0,
			element:{
				"type":"auto","label":'###:'
			},
		},
		tools:{
			name:"tools",type:"int",
			label:(($ln==="CN")?("技能:"):("Tools:")),
		},
		chains:{
			name:"chains",type:"int",
			label:(($ln==="CN")?("技能链:"):("Chains:")),
		},
		stat30m:{
			name:"stat30m",type:"object",
			label:(($ln==="CN")?("最近30分钟:"):("Last 30M:")),
			class:"1I2C8VFEN0",
		},
		stat24h:{
			name:"stat24h",type:"object",
			label:(($ln==="CN")?("最近24小时:"):("Last 24H:")),
			class:"1I2C8VFEN0",
		},
		/*#{1I2C843JD0MoreProperties*/
		/*}#1I2C843JD0MoreProperties*/
	},
	newObject(){return VFACT.newUITemplateObj(this)},
	/*#{1I2C843JD0MoreFunctions*/
	/*}#1I2C843JD0MoreFunctions*/
};
VFACT.regUITemplate("1I2C843JD0",BotState);
VFACT.regUITemplate("BotState",BotState);
/*#{1I2C843JD0MoreCodes*/
/*}#1I2C843JD0MoreCodes*/
let TaskInfo={
	name:"TaskInfo",//1I7DCATBU0
	type:"object",
	properties:{
		fromBot:{
			name:"fromBot",type:"string",
			label:"From:",
		},
		prompt:{
			name:"prompt",type:"string",
			label:"Prompt:",
		},
		state:{
			name:"state",type:"string",
			label:"State:",
		},
		result:{
			name:"result",type:"string",
			label:"Result:",
		},
		/*#{1I7DCATBU0MoreProperties*/
		/*}#1I7DCATBU0MoreProperties*/
	},
	newObject(){return VFACT.newUITemplateObj(this)},
	/*#{1I7DCATBU0MoreFunctions*/
	/*}#1I7DCATBU0MoreFunctions*/
};
VFACT.regUITemplate("1I7DCATBU0",TaskInfo);
VFACT.regUITemplate("TaskInfo",TaskInfo);
/*#{1I7DCATBU0MoreCodes*/
/*}#1I7DCATBU0MoreCodes*/

/*#{1HRCEQ9730EndDoc*/
/*}#1HRCEQ9730EndDoc*/

export{AppData,Agrument,UserAction,Actions,ActionFilter,BrowserArgs,ToolEntry,ToolInfo,ToolChainDef,BotInfo,EvntStat,BotState,TaskInfo};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DataDoc",
//	"jaxId": "1HRCEQ9730",
//	"attrs": {
//		"editObjs": {
//			"jaxId": "1HRCEQ9731",
//			"attrs": {
//				"AppData": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1HRCEQ9732",
//					"attrs": {
//						"exportType": "Data Class",
//						"constructArgs": {
//							"jaxId": "1HRCEQ9740",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1HRCEQ9741",
//							"attrs": {}
//						},
//						"functions": {
//							"jaxId": "1HRCEQ9742",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false"
//					},
//					"mockups": {}
//				},
//				"Agrument": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1HRFSVGO50",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1HRFT0FU10",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1HRFT0FU11",
//							"attrs": {
//								"name": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1HRFT0FU12",
//									"attrs": {
//										"type": "string"
//									}
//								},
//								"value": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1HRFT0FU13",
//									"attrs": {
//										"type": "auto"
//									}
//								}
//							}
//						},
//						"functions": {
//							"jaxId": "1HRFT0FU14",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false"
//					},
//					"mockups": {}
//				},
//				"UserAction": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1HRCEVTGL0",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1HRCF4UH50",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1HRCF4UH51",
//							"attrs": {
//								"action": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1HRCF4UH52",
//									"attrs": {
//										"type": "string",
//										"label": "Action:",
//										"defaultValue": "\"clickOn\"",
//										"required": "true",
//										"choices": {
//											"type": "array",
//											"def": "Array",
//											"attrs": [
//												{
//													"type": "string",
//													"valText": "#{text:\"Click On Query\",value:\"clickOn\"}"
//												},
//												{
//													"type": "auto",
//													"valText": "#{text:\"Tap On Query\",value:\"tapOn\"}"
//												},
//												{
//													"type": "string",
//													"valText": "#{text:\"Type On Query\",value:\"typeOn\"}"
//												},
//												{
//													"type": "string",
//													"valText": "#{text:\"Hover On Query\",value:\"hoverOn\"}"
//												},
//												{
//													"type": "auto",
//													"valText": "#{text:\"Select On Query\",value:\"selectOn\"}"
//												},
//												{
//													"type": "auto",
//													"valText": "#{text:\"Reset Mouse\",value:\"mouseReset\"}"
//												},
//												{
//													"type": "auto",
//													"valText": "#{text:\"Mouse Move\",value:\"mouseMove\"}"
//												},
//												{
//													"type": "auto",
//													"valText": "#{text:\"Mouse Down\",value:\"mouseDown\"}"
//												},
//												{
//													"type": "auto",
//													"valText": "#{text:\"Mouse Up\",value:\"mouseUp\"}"
//												},
//												{
//													"type": "auto",
//													"valText": "#{text:\"Mouse Click\",value:\"mouseClick\"}"
//												},
//												{
//													"type": "auto",
//													"valText": "#{text:\"Key Down\",value:\"keyDown\"}"
//												},
//												{
//													"type": "auto",
//													"valText": "#{text:\"Key Up\",value:\"keyUp\"}"
//												},
//												{
//													"type": "auto",
//													"valText": "#{text:\"Key Press\",value:\"keyPress\"}"
//												},
//												{
//													"type": "auto",
//													"valText": "#{text:\"Key Type\",value:\"keyType\"}"
//												},
//												{
//													"type": "auto",
//													"valText": "#{text:\"Touch Tap\",value:\"touchTap\"}"
//												},
//												{
//													"type": "auto",
//													"valText": "#{text:\"Touch Start\",value:\"touchStart\"}"
//												},
//												{
//													"type": "auto",
//													"valText": "#{text:\"Touch Move\",value:\"touchMove\"}"
//												},
//												{
//													"type": "auto",
//													"valText": "#{text:\"Touch End\",value:\"touchEnd\"}"
//												},
//												{
//													"type": "auto",
//													"valText": "#{text:\"Navi Goto\",value:\"goto\"}"
//												},
//												{
//													"type": "auto",
//													"valText": "#{text:\"Await Signal\",value:\"await\"}"
//												},
//												{
//													"type": "auto",
//													"valText": "#{text:\"Wait Page Navi\",value:\"waitNavi\"}"
//												},
//												{
//													"type": "auto",
//													"valText": "#{text:\"Wait Network Idle\",value:\"waitNetworkIdle\"}"
//												},
//												{
//													"type": "auto",
//													"valText": "#{text:\"Wait File Chooser\",value:\"waitFileChooser\"}"
//												},
//												{
//													"type": "auto",
//													"valText": "#{text:\"Wait Device Prompt\",value:\"waitDevicePrompt\"}"
//												},
//												{
//													"type": "auto",
//													"valText": "#{text:\"Wait Query\",value:\"waitQuery\"}"
//												},
//												{
//													"type": "auto",
//													"valText": "#{text:\"Wait Function\",value:\"waitFunction\"}"
//												}
//											]
//										},
//										"desc": "Action"
//									}
//								},
//								"query": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1HRCFMS220",
//									"attrs": {
//										"type": "string",
//										"label": "Query:"
//									}
//								},
//								"content": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1HRCFMS221",
//									"attrs": {
//										"type": "string",
//										"label": "Content"
//									}
//								},
//								"x": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1HRCFMS222",
//									"attrs": {
//										"type": "number",
//										"label": "Pos-X:"
//									}
//								},
//								"y": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1HRCFMS223",
//									"attrs": {
//										"type": "number",
//										"label": "Pos-Y:"
//									}
//								},
//								"key": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1HSGBD7A20",
//									"attrs": {
//										"type": "string"
//									}
//								},
//								"waitBefore": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1HRCG8I410",
//									"attrs": {
//										"type": "int",
//										"label": "Before:"
//									}
//								},
//								"waitAfter": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1HRCG8I411",
//									"attrs": {
//										"type": "int",
//										"label": "After:"
//									}
//								},
//								"options": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1HSGAOT070",
//									"attrs": {
//										"type": "auto",
//										"label": "Options:",
//										"defaultValue": "null"
//									}
//								}
//							}
//						},
//						"functions": {
//							"jaxId": "1HRCF4UH53",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false",
//						"layout": {
//							"type": "array",
//							"def": "AutoArray",
//							"attrs": [
//								{
//									"type": "auto",
//									"valText": "#{type:\"actPpt\",ppt:\"action\",action:\"execute\",icon:appCfg.sharedAssets+\"/run.svg\",\"tip\":\"Run Action\"}"
//								},
//								{
//									"type": "auto",
//									"valText": "query"
//								},
//								{
//									"type": "auto",
//									"valText": "content"
//								},
//								{
//									"type": "auto",
//									"valText": "key"
//								},
//								{
//									"type": "auto",
//									"valText": "[\"x\",\"y\"]"
//								},
//								{
//									"type": "auto",
//									"valText": "#{type:\"seg\",text:\"Wait time(ms):\"}"
//								},
//								{
//									"type": "auto",
//									"valText": "[\"waitBefore\",\"waitAfter\"]"
//								},
//								{
//									"type": "auto",
//									"valText": "options"
//								}
//							]
//						}
//					},
//					"mockups": {
//						"click": {
//							"type": "object",
//							"jaxId": "1HRCGC2J50",
//							"attrs": {
//								"action": "click",
//								"query": "[id=\"123\"]",
//								"content": "",
//								"x": "0",
//								"y": "0",
//								"key": "",
//								"waitBefore": "500",
//								"waitAfter": "500",
//								"options": ""
//							}
//						},
//						"type": {
//							"type": "object",
//							"jaxId": "1HRCGC2J51",
//							"attrs": {
//								"action": "type",
//								"query": "[id=\"123\"]",
//								"content": "Hello world",
//								"x": "0",
//								"y": "0",
//								"key": "",
//								"waitBefore": "500",
//								"waitAfter": "500",
//								"options": ""
//							}
//						},
//						"waitload": {
//							"type": "object",
//							"jaxId": "1HRCGC2J52",
//							"attrs": {
//								"action": "waitload",
//								"query": "",
//								"content": "",
//								"x": "0",
//								"y": "0",
//								"key": "",
//								"waitBefore": "0",
//								"waitAfter": "0",
//								"options": ""
//							}
//						}
//					}
//				},
//				"Actions": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1HRER99Q80",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1HRERBVGL0",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1HRERBVGL1",
//							"attrs": {
//								"arguments": {
//									"type": "object",
//									"def": "EditClassAryPpt",
//									"jaxId": "1HRFT1NQP0",
//									"attrs": {
//										"type": "array",
//										"element": {
//											"jaxId": "1HRFT1NQP1",
//											"attrs": {
//												"type": "Object",
//												"class": "\"1HRFSVGO50\"",
//												"label": "#'###:'"
//											}
//										},
//										"label": "Arguments",
//										"initLength": "0"
//									}
//								},
//								"actions": {
//									"type": "object",
//									"def": "EditClassAryPpt",
//									"jaxId": "1HRERBVGL2",
//									"attrs": {
//										"type": "array",
//										"element": {
//											"jaxId": "1HRERBVGL3",
//											"attrs": {
//												"type": "Object",
//												"class": "\"1HRCEVTGL0\"",
//												"label": "#'###:'"
//											}
//										},
//										"label": "Actions",
//										"initLength": "0"
//									}
//								}
//							}
//						},
//						"functions": {
//							"jaxId": "1HRERBVGL4",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false"
//					},
//					"mockups": {}
//				},
//				"ActionFilter": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1HU6OS1TL0",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1HU6OTSVP0",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1HU6OTSVP1",
//							"attrs": {
//								"network": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1HU6OTSVP2",
//									"attrs": {
//										"type": "bool",
//										"label": "Network Events:"
//									}
//								},
//								"navigation": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1HU6OTSVP3",
//									"attrs": {
//										"type": "bool",
//										"label": "Navigation Events:"
//									}
//								},
//								"action": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1HU6OTSVP4",
//									"attrs": {
//										"type": "bool",
//										"label": "User Actions:"
//									}
//								}
//							}
//						},
//						"functions": {
//							"jaxId": "1HU6OTSVP5",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false",
//						"label": ""
//					},
//					"mockups": {}
//				},
//				"BrowserArgs": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1HUND4UR70",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1HUNDCC7O0",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1HUNDCC7O1",
//							"attrs": {
//								"alias": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1HUNDCC7O2",
//									"attrs": {
//										"type": "string",
//										"label": "Alias:",
//										"required": "true"
//									}
//								},
//								"dataDir": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1HUNDCC7O3",
//									"attrs": {
//										"type": "bool",
//										"defaultValue": "false",
//										"desc": "When true, browser will use a data-dir by it's alias, so browsing state can be saved."
//									}
//								}
//							}
//						},
//						"functions": {
//							"jaxId": "1HUNDCC7O4",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false"
//					},
//					"mockups": {}
//				},
//				"ToolEntry": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1I18I5LNG0",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1I18IAGMI0",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1I18IAGMI1",
//							"attrs": {
//								"execData": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1I18IAGMI2",
//									"attrs": {
//										"type": "string",
//										"desc": {
//											"type": "string",
//											"valText": "JSON object for executing the Tool, for example: {\"search\":\"AI Agent\"}",
//											"localize": {
//												"EN": "JSON object for executing the Tool, for example: {\"search\":\"AI Agent\"}",
//												"CN": "用于执行技能的参数的JSON对象，例如：{\"search\":\"AI Agent\"}"
//											},
//											"localizable": true
//										},
//										"defaultValue": "{}",
//										"required": "true"
//									}
//								},
//								"command": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1I18IAGMI3",
//									"attrs": {
//										"type": "string",
//										"desc": {
//											"type": "string",
//											"valText": "Instruction indicating the operation, including a reference to the execData content, for example: search based on execData",
//											"localize": {
//												"EN": "Instruction indicating the operation, including a reference to the execData content, for example: search based on execData",
//												"CN": "指示操作的指令，包括对execData内容的引用，例如：根据execData进行搜索"
//											},
//											"localizable": true
//										},
//										"required": "true"
//									}
//								}
//							}
//						},
//						"functions": {
//							"jaxId": "1I18IAGMI4",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false"
//					},
//					"mockups": {}
//				},
//				"ToolInfo": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1I27DP3TM0",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1I27DSIBH0",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1I27DSIBH1",
//							"attrs": {
//								"name": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1I27DSIBH2",
//									"attrs": {
//										"type": "string",
//										"label": {
//											"type": "string",
//											"valText": "Name:",
//											"localize": {
//												"EN": "Name:",
//												"CN": "名称:"
//											},
//											"localizable": true
//										}
//									}
//								},
//								"type": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1I28MNLFD0",
//									"attrs": {
//										"type": "string",
//										"label": {
//											"type": "string",
//											"valText": "Type:",
//											"localize": {
//												"EN": "Type:",
//												"CN": "类型:"
//											},
//											"localizable": true
//										}
//									}
//								},
//								"filePath": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1I27DSIBH6",
//									"attrs": {
//										"type": "string",
//										"label": {
//											"type": "string",
//											"valText": "File Path:",
//											"localize": {
//												"EN": "File Path:",
//												"CN": "文件路径:"
//											},
//											"localizable": true
//										}
//									}
//								},
//								"description": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1I27DSIBH3",
//									"attrs": {
//										"type": "string",
//										"uiMode": "Note",
//										"label": {
//											"type": "string",
//											"valText": "Description:",
//											"localize": {
//												"EN": "Description:",
//												"CN": "说明:"
//											},
//											"localizable": true
//										}
//									}
//								},
//								"isRPA": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1I27DSIBH4",
//									"attrs": {
//										"type": "Boolean",
//										"label": {
//											"type": "string",
//											"valText": "Is RPA Tool:",
//											"localize": {
//												"EN": "Is RPA Tool:",
//												"CN": "是否是RPA技能:"
//											},
//											"localizable": true
//										}
//									}
//								},
//								"rpaHost": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1I27DSIBH5",
//									"attrs": {
//										"type": "string",
//										"label": "RPA Host:"
//									}
//								},
//								"package": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1I27DSIBH7",
//									"attrs": {
//										"type": "string",
//										"label": {
//											"type": "string",
//											"valText": "Package:",
//											"localize": {
//												"EN": "Package:",
//												"CN": "功能包:"
//											},
//											"localizable": true
//										}
//									}
//								},
//								"reference": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1I27DSIBH8",
//									"attrs": {
//										"type": "string",
//										"label": {
//											"type": "string",
//											"valText": "Reference:",
//											"localize": {
//												"EN": "Reference:",
//												"CN": "引用状态:"
//											},
//											"localizable": true
//										}
//									}
//								}
//							}
//						},
//						"functions": {
//							"jaxId": "1I27DSIBH9",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false"
//					},
//					"mockups": {}
//				},
//				"ToolChainDef": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1I27EOBVT0",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1I27EOS870",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1I27EOS871",
//							"attrs": {
//								"name": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1I27EOS872",
//									"attrs": {
//										"type": "string"
//									}
//								},
//								"desc": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1I27EOS873",
//									"attrs": {
//										"type": "string"
//									}
//								},
//								"guide": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1I27EOS874",
//									"attrs": {
//										"type": "string"
//									}
//								},
//								"tools": {
//									"type": "object",
//									"def": "EditClassAryPpt",
//									"jaxId": "1I27EOS875",
//									"attrs": {
//										"type": "array",
//										"element": {
//											"jaxId": "1I27EOS876",
//											"attrs": {
//												"type": "String",
//												"label": "#'###:'"
//											}
//										},
//										"initLength": "0"
//									}
//								}
//							}
//						},
//						"functions": {
//							"jaxId": "1I27EOS877",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false"
//					},
//					"mockups": {}
//				},
//				"BotInfo": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1I2B4INBE0",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1I2B4NPGM0",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1I2B4NPGM1",
//							"attrs": {
//								"name": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1I2B4NPGM3",
//									"attrs": {
//										"type": "string",
//										"desc": "Bot name",
//										"label": "Bot:"
//									}
//								},
//								"alias": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1I2B4NPGM4",
//									"attrs": {
//										"type": "string",
//										"desc": "Browser alias.",
//										"label": "Browser Alias:"
//									}
//								},
//								"active": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1I2ENN0R40",
//									"attrs": {
//										"type": "bool",
//										"label": "Active:"
//									}
//								},
//								"description": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1I50S0TN80",
//									"attrs": {
//										"type": "string",
//										"label": "Description",
//										"uiMode": "Note"
//									}
//								}
//							}
//						},
//						"functions": {
//							"jaxId": "1I2B4NPGM5",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false"
//					},
//					"mockups": {}
//				},
//				"EvntStat": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1I2C8VFEN0",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1I2C98D9B0",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1I2C98D9B1",
//							"attrs": {
//								"toolExec": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1I2C98D9B2",
//									"attrs": {
//										"type": "int",
//										"readOnly": "true"
//									}
//								},
//								"chainExec": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1I2C98D9B3",
//									"attrs": {
//										"type": "int",
//										"readOnly": "true"
//									}
//								},
//								"toolFail": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1I2C98D9B4",
//									"attrs": {
//										"type": "int",
//										"readOnly": "true"
//									}
//								},
//								"chainFail": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1I2C98D9B5",
//									"attrs": {
//										"type": "int",
//										"readOnly": "true"
//									}
//								},
//								"messageReceived": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1I2C98D9B6",
//									"attrs": {
//										"type": "int",
//										"readOnly": "true"
//									}
//								},
//								"messageSent": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1I2C98D9B7",
//									"attrs": {
//										"type": "int",
//										"readOnly": "true"
//									}
//								}
//							}
//						},
//						"functions": {
//							"jaxId": "1I2C98D9B8",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false"
//					},
//					"mockups": {}
//				},
//				"BotState": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1I2C843JD0",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1I2C845NQ0",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1I2C845NQ1",
//							"attrs": {
//								"type": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1I2EO7C4L0",
//									"attrs": {
//										"type": "string",
//										"label": "Type:"
//									}
//								},
//								"headless": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1I2EO98KL0",
//									"attrs": {
//										"type": "bool",
//										"defaultValue": "false",
//										"label": "Headless:"
//									}
//								},
//								"description": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1I2EOKFCH0",
//									"attrs": {
//										"type": "string",
//										"label": "Description"
//									}
//								},
//								"startTime": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1I2C8CIU73",
//									"attrs": {
//										"type": "int",
//										"label": {
//											"type": "string",
//											"valText": "Start Time",
//											"localize": {
//												"EN": "Start Time",
//												"CN": "启动时间"
//											},
//											"localizable": true
//										}
//									}
//								},
//								"lastActive": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1I2C8CIU74",
//									"attrs": {
//										"type": "int",
//										"label": {
//											"type": "string",
//											"valText": "Recent activity time",
//											"localize": {
//												"EN": "Recent activity time",
//												"CN": "最近活跃时间"
//											},
//											"localizable": true
//										}
//									}
//								},
//								"pages": {
//									"type": "object",
//									"def": "EditClassAryPpt",
//									"jaxId": "1I2C8CIU71",
//									"attrs": {
//										"type": "array",
//										"element": {
//											"jaxId": "1I2C8CIU72",
//											"attrs": {
//												"type": "Auto",
//												"label": "#'###:'"
//											}
//										},
//										"initLength": "0",
//										"label": "Pages:"
//									}
//								},
//								"tools": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1I2C9LOG60",
//									"attrs": {
//										"type": "int",
//										"label": {
//											"type": "string",
//											"valText": "Tools:",
//											"localize": {
//												"EN": "Tools:",
//												"CN": "技能:"
//											},
//											"localizable": true
//										}
//									}
//								},
//								"chains": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1I2C9OTK60",
//									"attrs": {
//										"type": "int",
//										"label": {
//											"type": "string",
//											"valText": "Chains:",
//											"localize": {
//												"EN": "Chains:",
//												"CN": "技能链:"
//											},
//											"localizable": true
//										}
//									}
//								},
//								"stat30m": {
//									"type": "object",
//									"def": "EditClassObjPpt",
//									"jaxId": "1I2C9A48C0",
//									"attrs": {
//										"type": "object",
//										"class": "\"1I2C8VFEN0\"",
//										"desc": {
//											"type": "string",
//											"valText": "Statistics for the last 30 minutes",
//											"localize": {
//												"EN": "Statistics for the last 30 minutes",
//												"CN": "最近30分钟的统计数据"
//											},
//											"localizable": true
//										},
//										"label": {
//											"type": "string",
//											"valText": "Last 30M:",
//											"localize": {
//												"EN": "Last 30M:",
//												"CN": "最近30分钟:"
//											},
//											"localizable": true
//										}
//									}
//								},
//								"stat24h": {
//									"type": "object",
//									"def": "EditClassObjPpt",
//									"jaxId": "1I2C9A48C1",
//									"attrs": {
//										"type": "object",
//										"class": "\"1I2C8VFEN0\"",
//										"desc": {
//											"type": "string",
//											"valText": "Statistics of the last 24 hours",
//											"localize": {
//												"EN": "Statistics of the last 24 hours",
//												"CN": "最近24小时的统计数据"
//											},
//											"localizable": true
//										},
//										"label": {
//											"type": "string",
//											"valText": "Last 24H:",
//											"localize": {
//												"EN": "Last 24H:",
//												"CN": "最近24小时:"
//											},
//											"localizable": true
//										}
//									}
//								}
//							}
//						},
//						"functions": {
//							"jaxId": "1I2C845NQ2",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false"
//					},
//					"mockups": {}
//				},
//				"TaskInfo": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1I7DCATBU0",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1I7DIRDR70",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1I7DIRDR71",
//							"attrs": {
//								"fromBot": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1I7DIRDR72",
//									"attrs": {
//										"type": "string",
//										"label": "From:"
//									}
//								},
//								"prompt": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1I7DIRDR73",
//									"attrs": {
//										"type": "string",
//										"label": "Prompt:"
//									}
//								},
//								"state": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1I7DIRDR74",
//									"attrs": {
//										"type": "string",
//										"label": "State:"
//									}
//								},
//								"result": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1I7DIRDR75",
//									"attrs": {
//										"type": "string",
//										"label": "Result:"
//									}
//								}
//							}
//						},
//						"functions": {
//							"jaxId": "1I7DIRDR76",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false"
//					},
//					"mockups": {}
//				}
//			}
//		}
//	}
//}