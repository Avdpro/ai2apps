import {VFACT} from "/@vfact";
import {AAFarm} from "/@aae/aafarm.js";
import {BrowserArgs} from "./data/AppData.js";

const $ln=VFACT.lanCode;
const EditAttr=VFACT.classRegs.EditAttr;
const EditAISeg=VFACT.classRegs.EditAISeg;
const EditAISegOutlet=VFACT.classRegs.EditAISegOutlet;
const SegObjBaseAttr=EditAISeg.SegObjBaseAttr;
const SegObjShellAttr=EditAISeg.SegObjShellAttr;
const FlowOutletDef=EditAISegOutlet.FlowOutletDef;
const SegOutletDef=EditAISegOutlet.SegOutletDef;
const CodeOutletArrayDef=EditAISegOutlet.CodeOutletArrayDef;
const ButtonOutletDef=EditAISegOutlet.ButtonOutletDef;

const DocAIAgentExporter=VFACT.classRegs.DocAIAgentExporter;
const docAIAgentExporter=DocAIAgentExporter.prototype;
const varNameRegex = /^[a-zA-Z_$][a-zA-Z0-9_$]*$/;

const packExtraCodes=docAIAgentExporter.packExtraCodes;
const packResult=docAIAgentExporter.packResult;

async function pickBrowser(farm,sender){
	let app,liveBrowsers,items,browser,alias,homeLive,item,browserId;
	let openBrowserId,openBrowserAlias,openBrowserWithDir;
	app=VFACT.app;
	liveBrowsers=await farm.getBrowsers();
	items=[];
	homeLive=false;
	for(browser of liveBrowsers){
		alias=browser.alias;
		items.push({text:alias+`: ${browser.pages.length} pages`,alias:browser.alias,browserId:browser.id});
		if(alias==="RPAHOME"){
			homeLive=true;
		}
	}
	if(!homeLive){
		items.push({text:"RPAHOME",alias:"RPAHOME",browserId:null});
	}
	items.push({text:"New browser",alias:null,browserId:null});
	item=await app.modalDlg("/@StdUI/ui/DlgMenu.js",{
		items:items,hud:sender,
	});
	if(!item){
		return null;
	}

	browserId=item.browserId;
	alias=item.alias;
	if(browserId){
		openBrowserId=browserId;
		openBrowserAlias=alias;
		openBrowserWithDir=false;
	}else if(alias){
		openBrowserId=null;
		openBrowserAlias=alias;
		openBrowserWithDir=true;
	}else if(alias===null){
		//TODO: ask a new alias and if use data-dir:
		let cfg=await app.modalDlg("/@StdUI/ui/DlgDataView.js",{
			hud:sender,
			x:-380,y:0,
			template:BrowserArgs,object:null,
			title:"New browser"
		});
		if(!cfg){
			return null;
		}
		openBrowserAlias=cfg.alias;
		openBrowserWithDir=cfg.dataDir;
	}else if(alias===""){
		openBrowserId=null;
		openBrowserAlias="";
		openBrowserWithDir=false;
	}
	
	let opts;
	opts={headless:false,devtools:false};
	if(openBrowserAlias && openBrowserWithDir){
		opts.autoDataDir=true;
	}
	browser=await farm.openBrowser(openBrowserAlias,opts);
	openBrowserAlias=browser.alias;
	farm.editBrowser=browser;
	return browser;
}

async function pickPage(aaf,browser,sender,pageName){
	let pages,items,page,title,item;
	pages=await browser.getPages();
	if(!pages || !pages.length){
		return null;
	}
	items=[];
	for(page of pages){
		title=await page.getTitle();
		if(!title){
			title=await page.getUrl();
		}
		items.push({"text":title,page:page});
	}
	item=await VFACT.app.modalDlg("/@StdUI/ui/DlgMenu.js",{
		items:items,hud:sender,
	});
	if(!item){
		return null;
	}
	page=item.page;
	aaf.editPages[pageName]=page;
	return page;
}

async function confirmPage(attr,sender){
	let seg,doc,aaf,browser,pageName,page,query,title;
	let app=VFACT.app;
	let repick=false;
	seg=attr.owner;
	doc=seg.doc;
	aaf=doc.aaFarm;
	pageName=seg.getAttrVal("page");
	if(!aaf){
		aaf=doc.aaFarm=new AAFarm();
		aaf.editPages={};
	}
	page=null;
	browser=aaf.editBrowser;
	if(browser){
		page=aaf.editPages[pageName];
	}
	if(page){
		try{
			title=await page.getTitle();
			if(!title){
				page=null;
			}
		}catch(err){
			page=null;
		}
	}
	if(page){
		let items=[
			{text:`[${title}]`,page:page},
			{text:`Select a new page`,page:null}
		];
		let item=await app.modalDlg("/@StdUI/ui/DlgMenu.js",{
			items:items,hud:sender,
		});
		if(!item){
			VFACT.app.showTip(sender,"Canceled.");
			return null;
		}
		page=item.page;
	}
	if(!page){
		//First pick browser:
		browser=await pickBrowser(aaf,sender);
		if(!browser){
			VFACT.app.showTip(sender,"No browser.");
			return null;
		}
		page=await pickPage(aaf,browser,sender,pageName);
		if(!page){
			VFACT.app.showTip(sender,"No page.");
			return null;
		}
	}
	return page;
};

async function showQueryDlg(attr,sender,line,box){
	let seg,doc,aaf,browser,pageName,page,query;
	let repick=false;
	let app=VFACT.app;
	query=attr.val;
	seg=attr.owner;
	doc=seg.doc;
	aaf=doc.aaFarm;
	page=await confirmPage(attr,sender);
	if(!page){
		return;
	}
	query=await app.modalDlg("/@aae/ui/MainUI.js",{aaf:aaf,browser,page,query});
	if(query!==undefined){
		box.setAttrByText(attr,query);
	}
	return query;
}

EditAISeg.regCatalog({
	name:"WebRpa",showName:(($ln==="CN")?("网页RPA"):/*EN*/("Web-RPA"))
});

const QueryFindOutlets={
	...CodeOutletArrayDef,
	attrs:[
		{
			type:"aioutlet",key:1,fixed:1,
			def:{
				...SegOutletDef,
				attrs:{
					...SegOutletDef.attrs,
					"id":{name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"Missing"},
				}
			}
		}
	]	
};

const errorSeg={
	name:"errorSeg",showName:(($ln==="CN")?("错误处理"):/*EN*/("Error Handler")),type:"string",key:1,fixed:1,initVal:"",editType:"choice",
	icon:"flag.svg",rawEdit:false,
	getMenuItems:function(){
		let list,i,n,seg;
		let items=[];
		list=this.owner.doc.segsList;
		n=list.length;
		for(i=0;i<n;i++){
			seg=list[i];
			if(seg.idVal.val){
				items.push({text:seg.idVal.val,valText:seg.jaxId});
			}
		}
		return items;
	},
	val2ShowText:function(val){
		let list,i,n,seg;
		if(!val){
			return "NA";
		}
		list=this.owner.doc.segsList;
		n=list.length;
		for(i=0;i<n;i++){
			seg=list[i];
			if(seg.idVal.val===val){
				return val;
			}
			if(seg.jaxId===val){
				return seg.idVal.val;
			}
		}
		return "NA";
	}
};
const packErrorSegCode=docAIAgentExporter.packErrorSegCode;

/*
function packErrorSegCode(coder,seg,exportDebug){
	let editDoc=seg.doc;
	let jumpTarget=seg.getAttrVal("errorSeg");
	if(jumpTarget){
		let list=editDoc.segsList,i,n;
		n=list.length;
		FindSeg:{
			for(i=0;i<n;i++){
				let checkSeg=list[i];
				if(checkSeg.idVal.val===jumpTarget){
					break FindSeg;
				}
				if(checkSeg.jaxId===jumpTarget){
					jumpTarget=checkSeg.idVal.val;
					break FindSeg;
				}
			}
			jumpTarget=null;
		}
	}
	if(jumpTarget){
		packExtraCodes(coder,seg,"ErrorCode");
		if(exportDebug){
			coder.packText(`return {seg:${jumpTarget||null},result:error,preSeg:"${seg.jaxId}",outlet:null};`);
		}else{
			coder.packText(`return {seg:${jumpTarget||null},result:error};`);
		}
	}else{
		coder.packText(`throw error;`);coder.newLine();
	}
}
*/

//----------------------------------------------------------------------------
//:WebRpaStart: AISeg that start WebRPA:
{
	EditAISeg.regDef({
		name:"WebRpaStart",showName:(($ln==="CN")?("启动网页RPA"):/*EN*/("Init Web-RPA")),icon:"start.svg",catalog:["WebRpa"],
		attrs:{
			...SegObjShellAttr,
			"browser":{
				name:"browser",showName:"Browser Alias",type:"string",key:1,fixed:1,initVal:"RPAHOME"
			},
			"headless":{
				name:"headless",showName:"Headless",type:"bool",key:1,fixed:1,initVal:false
			},
			"devtools":{
				name:"devtools",showName:"Dev. Tools",type:"bool",key:1,fixed:1,initVal:false
			},
			"url":{
				name:"url",showName:"Open Page",type:"string",key:1,fixed:1,initVal:""
			},
			"ref":{
				name:"ref",showName:"Page Ref",type:"string",key:0,fixed:1,initVal:""
			},
			"valName":{
				name:"valName",showName:"Page Val",type:"string",key:1,fixed:1,initVal:"aaPage"
			},
			"waitBefore":{
				name:"waitBefore",showName:"Wait Before",type:"int",key:1,fixed:1,initVal:0
			},
			"waitAfter":{
				name:"waitAfter",showName:"Wait After",type:"int",key:1,fixed:1,initVal:0
			},
			"outlet":{name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc"},
			"catchlet":{
				name:"catchlet",showName:"Catch",type:"aioutlet",def:FlowOutletDef,key:1,fixed:1,edit:false,navi:"doc",
				attrs:{
					"id":{
						name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"NoAAE",
					},
				},
			},
			"aiQuery":{name:"aiQuery",showName:(($ln==="CN")?("启用AI查询"):/*EN*/("Enable AI search")),type:"bool",key:1,fixed:1,initVal:true},
			"autoCurrentPage":{name:"autoCurrentPage",showName:(($ln==="CN")?("自动切换当前页面"):/*EN*/("Auto switch current page")),type:"bool",key:1,fixed:1,initVal:true},
		},
		listHint:["id","browser","url","ref","valName","autoCurrentPage","headless","devtools","codes","aiQuery","waitBefore","waitAfter","desc"],
		importSource:{path:"../../rpa/WebRpa.mjs",name:["WebRpa","sleep"]},
	});

	DocAIAgentExporter.segTypeExporters["WebRpaStart"]=
	function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let exportDebug=this.isExportDebug();
		let editDoc=seg.doc;
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();
		coder.newLine();
		{
			coder.maybeNewLine();
			coder.packText(`let result=true;`);coder.newLine();
			coder.packText(`let aiQuery=`);this.genAttrStatement(seg.getAttr("aiQuery"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $alias=`);this.genAttrStatement(seg.getAttr("browser"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $url=`);this.genAttrStatement(seg.getAttr("url"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $ref=`);this.genAttrStatement(seg.getAttr("ref"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $waitBefore=`);this.genAttrStatement(seg.getAttr("waitBefore"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $waitAfter=`);this.genAttrStatement(seg.getAttr("waitAfter"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $webRpa=null;`);coder.newLine();
			packExtraCodes(coder,seg,"PreCodes");
			coder.packText(`try{`);
			coder.indentMore();coder.newLine();
			{
				coder.packText(`if($ref){`);coder.indentMore();coder.newLine();
				{
					coder.packText(`let $page,$browser;`);coder.newLine();
					coder.packText(`let $pageVal=`);this.genAttrStatement(seg.getAttr("valName"));coder.packText(`;`);coder.newLine();
					coder.packText(`$page=WebRpa.getPageByRef($ref);`);coder.newLine();
					coder.packText(`context.rpaBrowser=$browser=$page.webDrive;`);coder.newLine();
					coder.packText(`context.webRpa=$webRpa=$browser.aaWebRpa;`);coder.newLine();
					coder.packText(`Object.defineProperty(context, $pageVal, {enumerable:true,get(){return $webRpa.currentPage},set(v){$webRpa.setCurrentPage(v)}});`);coder.newLine();
					coder.packText(`context[$pageVal]=$page;`);coder.newLine();
				}
				coder.indentLess();coder.maybeNewLine();
				coder.packText(`}else{`);coder.indentMore();coder.newLine();
				{
					coder.packText(`let $pageVal=`);this.genAttrStatement(seg.getAttr("valName"));coder.packText(`;`);coder.newLine();
					coder.packText(`context.webRpa=$webRpa=session.webRpa || new WebRpa(session);`);coder.newLine();
					coder.packText(`session.webRpa=$webRpa;`);coder.newLine();
					coder.packText(`aiQuery && (await context.webRpa.setupAIQuery(session,context,basePath,"${seg.jaxId}"));`);coder.newLine();
					coder.packText(`if($alias){`);coder.indentMore();coder.newLine();
					{
						coder.packText(`let $headless=`);this.genAttrStatement(seg.getAttr("headless"));coder.packText(`;`);coder.newLine();
						coder.packText(`let $devtools=`);this.genAttrStatement(seg.getAttr("devtools"));coder.packText(`;`);coder.newLine();
						coder.packText(`let options={$headless:false,$devtools:false,autoDataDir:false};`);coder.newLine();
						coder.packText(`let $browser=null;`);coder.newLine();
						packExtraCodes(coder,seg,"PreBrowser");
						coder.packText(`context.rpaBrowser=$browser=await context.webRpa.openBrowser($alias,options);`);coder.newLine();
						coder.packText(`context.rpaHostPage=$browser.hostPage;`);coder.newLine();
						coder.packText(`Object.defineProperty(context, $pageVal, {enumerable:true,get(){return $webRpa.currentPage},set(v){$webRpa.setCurrentPage(v)}});`);coder.newLine();
						packExtraCodes(coder,seg,"PostBrowser");
						coder.packText(`if($url){`);
						coder.indentMore();coder.newLine();
						{
							coder.packText(`let $page=null;`);coder.newLine();
							coder.packText(`let $opts={};`);coder.newLine();
							packExtraCodes(coder,seg,"PrePage");
							coder.packText(`context[$pageVal]=$page=await $browser.newPage();`);coder.newLine();
							coder.packText(`await $page.goto($url,{});`);coder.newLine();
							packExtraCodes(coder,seg,"PostPage");
						}
						coder.indentLess();coder.maybeNewLine();
						coder.packText(`}`);coder.newLine();
					}
					coder.indentLess();coder.maybeNewLine();
					coder.packText(`}`);coder.newLine();
				}
				coder.indentLess();coder.maybeNewLine();
				coder.packText(`}`);coder.newLine();
				coder.packText(`$waitAfter && (await sleep($waitAfter));`);coder.newLine();
			}
			coder.indentLess();coder.maybeNewLine();
			coder.packText(`}catch(error){`);
			coder.indentMore();coder.newLine();
			{
				let catchlet,catchSeg;
				catchlet=seg.catchlet||null;
				if(catchlet){
					catchSeg=catchlet.getLinkedSeg();
					if(catchSeg){
						packExtraCodes(coder,catchlet,"Codes");
						this.packUpdateContext(coder,catchlet);
						this.packUpdateGlobal(coder,catchlet);
						packResult(coder,seg,catchlet,"error");
					}else{
						packExtraCodes(coder,catchlet,"Codes");
						this.packUpdateContext(coder,catchlet);
						this.packUpdateGlobal(coder,catchlet);
						coder.packText(`throw error;`);coder.newLine();
					}
				}else{
					coder.packText(`throw err;`);coder.newLine();
				}
			}
			coder.indentLess();coder.maybeNewLine();coder.packText(`}`);coder.newLine();
			packExtraCodes(coder,seg,"PostCodes");
			this.packUpdateContext(coder,seg);
			this.packUpdateGlobal(coder,seg);
			packResult(coder,seg,seg.outlet,"result",false);
		}
		coder.indentLess();
		coder.newLine();
		coder.packText(`};`);
		coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		coder.newLine();
	};
}

//----------------------------------------------------------------------------
//:WebRpaOpenBrowser: Open a browser:
{
	EditAISeg.regDef({
		name:"WebRpaOpenBrowser",showName:(($ln==="CN")?("打开浏览器"):/*EN*/("Open Browser")),icon:"web.svg",catalog:["WebRpa"],
		attrs:{
			...SegObjShellAttr,
			"alias":{
				name:"alias",showName:"Alias",type:"string",key:1,fixed:1,initVal:"RPAHOME"
			},
			"headless":{
				name:"headless",showName:"Headless",type:"bool",key:1,fixed:1,initVal:false
			},
			"devtools":{
				name:"devtools",showName:"Dev. Tools",type:"bool",key:1,fixed:1,initVal:false
			},
			"dataDir":{
				name:"dataDir",showName:"Data Dir",type:"bool",key:1,fixed:1,initVal:false
			},
			"outlet":{
				name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
			},
			"run":{
				name:"run",showName:"Run This Step",type:"auto",key:1,fixed:1,initVal:undefined,editType:"action",
				OnAction:async function(attrObj,sender,attrLine,editBox){
					let seg,doc,webRpa,alias,browser;
					seg=attrObj.owner;
					doc=seg.doc;
					webRpa=doc.webRpa;
					if(!webRpa){
						webRpa=doc.webRpa=new AAFarm();
						webRpa.editPages={};
					}
					alias=seg.getAttrVal("alias");
					browser=await webRpa.openBrowser(alias,{headless:false,devtools:true});
					webRpa.editBrowser=browser;
				}
			},
			"errorSeg": errorSeg,
		},
		listHint:[
			"id","alias","dataDir","headless","devtools","errorSeg","run","codes","desc",
		]
	});

	DocAIAgentExporter.segTypeExporters["WebRpaOpenBrowser"]=
	function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let exportDebug=this.isExportDebug();
		let editDoc=seg.doc;
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();
		coder.newLine();
		{
			coder.maybeNewLine();
			coder.packText(`let result=true;`);coder.newLine();
			coder.packText(`let browser=null;`);coder.newLine();
			coder.packText(`let headless=`);this.genAttrStatement(seg.getAttr("headless"));coder.packText(`;`);coder.newLine();
			coder.packText(`let devtools=`);this.genAttrStatement(seg.getAttr("devtools"));coder.packText(`;`);coder.newLine();
			coder.packText(`let dataDir=`);this.genAttrStatement(seg.getAttr("dataDir"));coder.packText(`;`);coder.newLine();
			coder.packText(`let alias=`);this.genAttrStatement(seg.getAttr("alias"));coder.packText(`;`);coder.newLine();
			coder.packText(`let options={headless,devtools,autoDataDir:dataDir};`);coder.newLine();
			packExtraCodes(coder,seg,"PreCodes");
			coder.packText(`try{`);coder.indentMore();coder.newLine();
			{
				coder.packText(`context.rpaBrowser=browser=await context.webRpa.openBrowser(alias,options);`);coder.newLine();
				coder.packText(`context.rpaHostPage=browser.hostPage;`);coder.newLine();
			}
			coder.indentLess();coder.newLine();
			coder.packText(`}catch(error){`);coder.indentMore();coder.newLine();
			{
				packErrorSegCode(coder,seg,exportDebug);
			}
			coder.indentLess();coder.maybeNewLine();coder.packText(`}`);coder.newLine();
			packExtraCodes(coder,seg,"PostCodes");
			packResult(coder,seg,seg.outlet,"result");
		}
		coder.indentLess();
		coder.newLine();
		coder.packText(`};`);
		coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		coder.newLine();
	};
}

//----------------------------------------------------------------------------
//:WebRPACloseBrowser: Close a browser:
{
	EditAISeg.regDef({
		name:"WebRpaCloseBrowser",showName:(($ln==="CN")?("关闭浏览器"):/*EN*/("Close Browser")),icon:"close.svg",catalog:["WebRpa"],
		attrs:{
			...SegObjShellAttr,
			"outlet":{
				name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
			},
			"errorSeg": errorSeg,
		},
		listHint:[
			"id","codes","desc","errorSeg",
		]
	});

	DocAIAgentExporter.segTypeExporters["WebRpaCloseBrowser"]=
	function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let exportDebug=this.isExportDebug();
		let editDoc=seg.doc;
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();
		coder.newLine();
		{
			coder.maybeNewLine();
			coder.packText(`let result=input;`);coder.newLine();
			coder.packText(`let browser=context.rpaBrowser;`);coder.newLine();
			packExtraCodes(coder,seg,"PreCodes");
			coder.packText(`try{`);coder.indentMore();coder.newLine();
			{
				coder.packText(`if(browser){`);coder.indentMore();coder.newLine();
				{
					coder.packText(`await context.webRpa.closeBrowser(browser);`);coder.newLine();
				}
				coder.indentLess();coder.maybeNewLine();
				coder.packText(`}`);coder.newLine();
				coder.packText(`context.rpaBrowser=null;`);coder.newLine();
				coder.packText(`context.rpaHostPage=null;`);coder.newLine();
			}
			coder.indentLess();coder.newLine();
			coder.packText(`}catch(error){`);coder.indentMore();coder.newLine();
			{
				packErrorSegCode(coder,seg,exportDebug);
			}
			coder.indentLess();coder.maybeNewLine();coder.packText(`}`);coder.newLine();
			packExtraCodes(coder,seg,"PostCodes");
			packResult(coder,seg,seg.outlet,"result");
		}
		coder.indentLess();
		coder.newLine();
		coder.packText(`};`);
		coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		coder.newLine();
	};
}

//----------------------------------------------------------------------------
//:AISeg that open a page with url and can also set it's viewpoert size and user-agent:
{
	EditAISeg.regDef({
		name:"WebRpaOpenPage",showName:(($ln==="CN")?("打开页面"):/*EN*/("Open Page")),icon:"/@aae/assets/tab_add.svg",catalog:["WebRpa"],
		attrs:{
			...SegObjShellAttr,
			"valName":{
				name:"valName",showName:"Page Val",type:"string",key:1,fixed:1,initVal:"aaPage"
			},
			"url":{
				name:"url",showName:"URL",type:"string",key:1,fixed:1,initVal:"https://www.google.com"
			},
			"vpWidth":{
				name:"vpWidth",showName:"Viewport Width",type:"int",key:1,fixed:1,initVal:800
			},
			"vpHeight":{
				name:"vpHeight",showName:"Viewport Height",type:"int",key:1,fixed:1,initVal:600
			},
			"timeout":{
				name:"timeout",showName:"Timeout",type:"int",key:0,fixed:1,initVal:0
			},
			"userAgent":{
				name:"userAgent",showName:"User Agent",type:"string",key:1,fixed:1,initVal:""
			},
			"waitBefore":{
				name:"waitBefore",showName:"Wait Before",type:"int",key:1,fixed:1,initVal:0
			},
			"waitAfter":{
				name:"waitAfter",showName:"Wait After",type:"int",key:1,fixed:1,initVal:0
			},
			"outlet":{
				name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
			},
			"run":{
				name:"run",showName:"Run This Step",type:"auto",key:1,fixed:1,initVal:undefined,editType:"action",
				OnAction:async function(attrObj,sender,attrLine,editBox){
					let seg,doc,webRpa,alias,browser,page,vw,vh,url,pageName;
					seg=attrObj.owner;
					doc=seg.doc;
					webRpa=doc.webRpa;
					if(!webRpa){
						webRpa=doc.webRpa=new AAFarm();
						webRpa.editPages={};
					}
					browser=webRpa.editBrowser;
					if(!browser){
						browser=await pickBrowser(webRpa,sender);
						if(!browser){
							VFACT.app.showTip(sender,"No browser.");
							return;
						}
					}
					pageName=seg.getAttrVal("valName");
					page=await browser.newPage();
					webRpa.editPages[pageName]=page;
					vw=seg.getAttrVal("vpWidth");
					vh=seg.getAttrVal("vpHeight");
					url=seg.getAttrVal("url");
					//await page.setViewport({width:vw,height:vh});
					if(url){
						await page.goto(url);
					}
				}
			},
			"errorSeg": errorSeg,
		},
		listHint:[
			"id","valName","url","vpWidth","vpHeight","timeout","userAgent","errorSeg","run","waitBefore","waitAfter","codes","desc",
		]
	});

	DocAIAgentExporter.segTypeExporters["WebRpaOpenPage"]=
	function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let exportDebug=this.isExportDebug();
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();
		coder.newLine();
		{
			coder.maybeNewLine();
			coder.packText(`let pageVal=`);this.genAttrStatement(seg.getAttr("valName"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $url=`);this.genAttrStatement(seg.getAttr("url"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $waitBefore=`);this.genAttrStatement(seg.getAttr("waitBefore"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $waitAfter=`);this.genAttrStatement(seg.getAttr("waitAfter"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $width=`);this.genAttrStatement(seg.getAttr("vpWidth"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $height=`);this.genAttrStatement(seg.getAttr("vpHeight"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $userAgent=`);this.genAttrStatement(seg.getAttr("userAgent"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $timeout=(`);this.genAttrStatement(seg.getAttr("timeout"));coder.packText(`)||0;`);coder.newLine();
			coder.packText(`let page=null;`);coder.newLine();
			coder.packText(`let $openOpts={timeout:$timeout};`);coder.newLine();
			coder.packText(`$waitBefore && (await sleep($waitBefore));`);coder.newLine();
			packExtraCodes(coder,seg,"PreCodes");
			coder.packText(`try{`);coder.indentMore();coder.newLine();
			{
				coder.packText(`context[pageVal]=page=await context.rpaBrowser.newPage();`);coder.newLine();
				coder.packText(`($width && $height) && (await page.setViewport({width:$width,height:$height}));`);coder.newLine();
				coder.packText(`$userAgent && (await page.setUserAgent($userAgent));`);coder.newLine();
				coder.packText(`await page.goto($url,$openOpts);`);coder.newLine();
				coder.packText(`$waitAfter && (await sleep($waitAfter));`);coder.newLine();
			}
			coder.indentLess();coder.maybeNewLine();
			coder.packText(`}catch(error){`);coder.indentMore();coder.newLine();
			{
				packErrorSegCode(coder,seg,exportDebug);
			}
			coder.indentLess();coder.maybeNewLine();coder.packText(`}`);coder.newLine();
			packExtraCodes(coder,seg,"PostCodes");
			packResult(coder,seg,seg.outlet,"true");
		}
		coder.indentLess();
		coder.newLine();
		coder.packText(`};`);
		coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		coder.newLine();
	};
}

//----------------------------------------------------------------------------
//:AISeg that close a page
{
	EditAISeg.regDef({
		name:"WebRpaClosePage",showName:(($ln==="CN")?("关闭页面"):/*EN*/("Close Page")),icon:"/@aae/assets/tab_close.svg",catalog:["WebRpa"],
		attrs:{
			...SegObjShellAttr,
			"page":{
				name:"page",showName:"Page",type:"string",key:1,fixed:1,initVal:"aaPage"
			},
			"waitBefore":{
				name:"waitBefore",showName:"Wait Before",type:"int",key:1,fixed:1,initVal:0
			},
			"waitAfter":{
				name:"waitAfter",showName:"Wait After",type:"int",key:1,fixed:1,initVal:0
			},
			"outlet":{
				name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
			},
			"errorSeg": errorSeg,
			"run":{
				name:"run",showName:"Run This Step",type:"auto",key:1,fixed:1,initVal:undefined,editType:"action",
				OnAction:async function(attrObj,sender,attrLine,editBox){
					let page,seg,doc,aaf,pageName;
					page=await confirmPage(attrObj,sender);
					if(page){
						seg=attrObj.owner;
						doc=seg.doc;
						aaf=doc.aaFarm;
						await page.close();
						pageName=seg.getAttrVal("page");
						aaf.editPages[pageName]=null;
						VFACT.app.showTip(sender,"Page closed.");
					}else{
						VFACT.app.showTip(sender,"No assigned page to close.");
					}
				}
			}
		},
		listHint:[
			"id","page","errorSeg","run","waitBefore","waitAfter","codes","desc",
		]
	});

	DocAIAgentExporter.segTypeExporters["WebRpaClosePage"]=
	function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let exportDebug=this.isExportDebug();
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();coder.newLine();
		{
			coder.maybeNewLine();
			coder.packText(`let result=input;`);coder.newLine();
			coder.packText(`let pageVal=`);this.genAttrStatement(seg.getAttr("page"));coder.packText(`;`);coder.newLine();
			coder.packText(`let waitBefore=`);this.genAttrStatement(seg.getAttr("waitBefore"));coder.packText(`;`);coder.newLine();
			coder.packText(`let waitAfter=`);this.genAttrStatement(seg.getAttr("waitAfter"));coder.packText(`;`);coder.newLine();
			coder.packText(`let page=context[pageVal];`);coder.newLine();
			coder.packText(`waitBefore && (await sleep(waitBefore));`);coder.newLine();
			packExtraCodes(coder,seg,"PreCodes");
			coder.packText(`try{`);coder.indentMore();coder.newLine();
			{
				coder.packText(`await page.close();`);coder.newLine();
				coder.packText(`context[pageVal]=null;`);coder.newLine();
				coder.packText(`waitAfter && (await sleep(waitAfter))`);coder.newLine();
			}
			coder.indentLess();coder.maybeNewLine();
			coder.packText(`}catch(error){`);coder.indentMore();coder.newLine();
			{
				packErrorSegCode(coder,seg,exportDebug);
			}
			coder.indentLess();coder.maybeNewLine();coder.packText(`}`);coder.newLine();
			packExtraCodes(coder,seg,"PostCodes");
			packResult(coder,seg,seg.outlet,"result");
		}
		coder.indentLess();coder.maybeNewLine();
		coder.packText(`};`);
		coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		coder.newLine();
	};
}

//----------------------------------------------------------------------------
//:AISeg that switch back to App:
{
	EditAISeg.regDef({
		name:"WebRpaBackToApp",showName:(($ln==="CN")?("返回App"):/*EN*/("Back to App")),icon:"/@tabos/shared/assets/aalogo.svg",catalog:["WebRpa"],
		attrs:{
			...SegObjShellAttr,
			"waitBefore":{
				name:"waitBefore",showName:"Wait Before",type:"int",key:1,fixed:1,initVal:0
			},
			"waitAfter":{
				name:"waitAfter",showName:"Wait After",type:"int",key:1,fixed:1,initVal:0
			},
			"errorSeg":errorSeg,
			"outlet":{
				name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
			},
		},
		listHint:[
			"id","errorSeg","waitBefore","waitAfter","codes","desc",
		]
	});

	DocAIAgentExporter.segTypeExporters["WebRpaBackToApp"]=
	function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let exportDebug=this.isExportDebug();
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();coder.newLine();
		{
			coder.maybeNewLine();
			coder.packText(`let result=input;`);coder.newLine();
			coder.packText(`let waitBefore=`);this.genAttrStatement(seg.getAttr("waitBefore"));coder.packText(`;`);coder.newLine();
			coder.packText(`let waitAfter=`);this.genAttrStatement(seg.getAttr("waitAfter"));coder.packText(`;`);coder.newLine();
			coder.packText(`let browser=context.rpaBrowser;`);coder.newLine();
			coder.packText(`waitBefore && (await sleep(waitBefore));`);coder.newLine();
			packExtraCodes(coder,seg,"PreCodes");
			coder.packText(`try{`);coder.indentMore();coder.newLine();
			{
				coder.packText(`if(browser){`);coder.indentMore();coder.newLine();
				{
					coder.packText(`await browser.backToApp();`);coder.newLine();
				}
				coder.indentLess();coder.maybeNewLine();
				coder.packText(`}`);coder.newLine();
				coder.packText(`waitAfter && (await sleep(waitAfter))`);coder.newLine();
			}
			coder.indentLess();coder.maybeNewLine();
			coder.packText(`}catch(error){`);coder.indentMore();coder.newLine();
			{
				packErrorSegCode(coder,seg,exportDebug);
			}
			coder.indentLess();coder.maybeNewLine();coder.packText(`}`);coder.newLine();
			packExtraCodes(coder,seg,"PostCodes");
			packResult(coder,seg,seg.outlet,"result");
		}
		coder.indentLess();coder.maybeNewLine();
		coder.packText(`};`);
		coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		coder.newLine();
	};
}

//----------------------------------------------------------------------------
//:AISeg that active a page
{
	EditAISeg.regDef({
		name:"WebRpaActivePage",showName:(($ln==="CN")?("激活页面"):/*EN*/("Active Page")),icon:"/@aae/assets/tab_tap.svg",catalog:["WebRpa"],
		attrs:{
			...SegObjShellAttr,
			"page":{
				name:"page",showName:"Page",type:"string",key:1,fixed:1,initVal:"aaPage"
			},
			"options":{
				name:"options",showName:"Options",type:"hyperObj",key:1,fixed:1,initVal:undefined,
				template:function(obj){
					return {
						title:"Active page options:",label:"",
						properties:{
							focusBrowser:{
								type:"bool",label:"Focus Browser:",initValue:false,
							},
							switchBack:{
								type:"bool",label:"Switch Back:",initValue:false,
							}
						},
						wrapObject(vo){
							if(!vo.button){delete vo.button;}
							return vo;
						}
					};
				}
			},
			"waitBefore":{
				name:"waitBefore",showName:"Wait Before",type:"int",key:1,fixed:1,initVal:0
			},
			"waitAfter":{
				name:"waitAfter",showName:"Wait After",type:"int",key:1,fixed:1,initVal:0
			},
			"outlet":{
				name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
			},
			"errorSeg":errorSeg,
			"run":{
				name:"run",showName:"Run This Step",type:"auto",key:1,fixed:1,initVal:undefined,editType:"action",
				OnAction:async function(attrObj,sender,attrLine,editBox){
					let page=await confirmPage(attrObj,sender);
					let seg=attrObj.owner;
					let options=seg.getAttrVal("options");
					if(page){
						page.active(options);
						VFACT.app.showTip(sender,"Page actived.");
					}else{
						VFACT.app.showTip(sender,"No page assigned.");
					}
				}
			}
		},
		listHint:[
			"id","page","options","errorSeg","run","waitBefore","waitAfter","codes","desc",
		]
	});

	DocAIAgentExporter.segTypeExporters["WebRpaActivePage"]=
	function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let exportDebug=this.isExportDebug();
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();coder.newLine();
		{
			coder.maybeNewLine();
			coder.packText(`let result=input;`);coder.newLine();
			coder.packText(`let pageVal=`);this.genAttrStatement(seg.getAttr("page"));coder.packText(`;`);coder.newLine();
			coder.packText(`let waitBefore=`);this.genAttrStatement(seg.getAttr("waitBefore"));coder.packText(`;`);coder.newLine();
			coder.packText(`let waitAfter=`);this.genAttrStatement(seg.getAttr("waitAfter"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $options=`);this.genAttrStatement(seg.getAttr("options"));coder.packText(`;`);coder.newLine();
			coder.packText(`let page=context[pageVal];`);coder.newLine();
			coder.packText(`waitBefore && (await sleep(waitBefore));`);coder.newLine();
			packExtraCodes(coder,seg,"PreCodes");
			coder.packText(`try{`);coder.indentMore();coder.newLine();
			{
				coder.packText(`await page.bringToFront($options);`);coder.newLine();
				coder.packText(`waitAfter && (await sleep(waitAfter))`);coder.newLine();
				coder.packText(`if($options.focusBrowser && $options.switchBack){`);coder.indentMore();coder.newLine();
				{
					coder.packText(`let $browser=context.rpaBrowser;`);coder.newLine();
					coder.packText(`if($browser){`);coder.indentMore();coder.newLine();
					{
						coder.packText(`await $browser.backToApp();`);coder.newLine();
					}
					coder.indentLess();coder.maybeNewLine();
					coder.packText(`}`);coder.newLine();
				}
				coder.indentLess();coder.maybeNewLine();
				coder.packText(`}`);coder.newLine();
			}
			coder.indentLess();coder.maybeNewLine();
			coder.packText(`}catch(error){`);coder.indentMore();coder.newLine();
			{
				packErrorSegCode(coder,seg,exportDebug);
			}
			coder.indentLess();coder.maybeNewLine();coder.packText(`}`);coder.newLine();
			packExtraCodes(coder,seg,"PostCodes");
			packResult(coder,seg,seg.outlet,"result");
		}
		coder.indentLess();coder.maybeNewLine();
		coder.packText(`};`);
		coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		coder.newLine();
	};
}

//----------------------------------------------------------------------------
//:AISeg that screenshot a page
{
	EditAISeg.regDef({
		name:"WebRpaCapturePage",showName:(($ln==="CN")?("页面截图"):/*EN*/("Screenshot")),icon:"/@aae/assets/tab_cam.svg",catalog:["WebRpa"],
		attrs:{
			...SegObjShellAttr,
			"page":{
				name:"page",showName:"Page",type:"string",key:1,fixed:1,initVal:"aaPage"
			},
			"fullPage":{
				name:"fullPage",showName:"Full Page",type:"bool",key:1,fixed:1,initVal:true
			},
			"format":{
				name:"format",showName:"Format",type:"choice",key:1,fixed:1,initVal:"png",
				vals:[
					["png","PNG","PNG Image"],
					["jpeg","JPEG","JPEG Image"],
				],
			},
			"quality":{
				name:"quality",showName:"JPEG Quality",type:"choice",key:1,fixed:1,initVal:0.5,
				vals:[
					[0.3,"0.3","30%"],
					[0.5,"0.5","50%"],
					[0.7,"0.7","70%"],
					[1.0,"1.0","100%"],
				],
			},
			"dataURL":{
				name:"dataURL",showName:"Result as Data-URL",type:"bool",key:1,fixed:1,initVal:true
			},
			"errorSeg":errorSeg,
			"waitBefore":{
				name:"waitBefore",showName:"Wait Before",type:"int",key:1,fixed:1,initVal:0
			},
			"waitAfter":{
				name:"waitAfter",showName:"Wait After",type:"int",key:1,fixed:1,initVal:0
			},
			"outlet":{
				name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
			},
		},
		listHint:[
			"id","page","fullPage","format","quality","dataURL","errorSeg","waitBefore","waitAfter","codes","desc",
		],
		attrOutlets:["input","result","data"],
		OnAttrEdit(box,attr,value){
			if(!attr || attr.name==="format"){
				let format=this.getAttrVal("format");
				switch(format){
					case "jpeg":
						box.showAttrLine(this.getAttr("quality"));
						break;
					default:
						box.hideAttrLine(this.getAttr("quality"));
						break;
				}
			}
		}
	});

	DocAIAgentExporter.segTypeExporters["WebRpaCapturePage"]=
	function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let exportDebug=this.isExportDebug();
		let useDataURL=seg.getAttrVal("dataURL");
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();coder.newLine();
		{
			coder.maybeNewLine();
			coder.packText(`let result=null;`);coder.newLine();
			coder.packText(`let data=null;`);coder.newLine();
			coder.packText(`let pageVal=`);this.genAttrStatement(seg.getAttr("page"));coder.packText(`;`);coder.newLine();
			coder.packText(`let fullPage=`);this.genAttrStatement(seg.getAttr("fullPage"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $format=`);this.genAttrStatement(seg.getAttr("format"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $quality=`);this.genAttrStatement(seg.getAttr("quality"));coder.packText(`;`);coder.newLine();
			coder.packText(`let waitBefore=`);this.genAttrStatement(seg.getAttr("waitBefore"));coder.packText(`;`);coder.newLine();
			coder.packText(`let waitAfter=`);this.genAttrStatement(seg.getAttr("waitAfter"));coder.packText(`;`);coder.newLine();
			coder.packText(`let page=context[pageVal];`);coder.newLine();
			coder.packText(`waitBefore && (await sleep(waitBefore));`);coder.newLine();
			packExtraCodes(coder,seg,"PreCodes");
			coder.packText(`try{`);coder.indentMore();coder.newLine();
			{
				coder.packText(`result=await page.screenshot({encoding: 'base64',type:$format,fullPage:fullPage,quality:$quality});`);coder.newLine();
				if(useDataURL){
					coder.packText(`result=\`data:image/\$\{$format};base64,\`+result;`);coder.newLine();
				}
				coder.packText(`waitAfter && (await sleep(waitAfter));`);coder.newLine();
			}
			coder.indentLess();coder.maybeNewLine();
			coder.packText(`}catch(error){`);coder.indentMore();coder.newLine();
			{
				packErrorSegCode(coder,seg,exportDebug);
			}
			coder.indentLess();coder.maybeNewLine();coder.packText(`}`);coder.newLine();
			packExtraCodes(coder,seg,"PostCodes");
			this.packUpdateContext(coder,seg);
			this.packUpdateGlobal(coder,seg);
			packResult(coder,seg,seg.outlet,"result");
		}
		coder.indentLess();coder.maybeNewLine();
		coder.packText(`};`);
		coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		coder.newLine();
	};
}

//----------------------------------------------------------------------------
//:AISeg that makes page goto an URL//Try
{
	EditAISeg.regDef({
		name:"WebRpaPageGoto",showName:(($ln==="CN")?("前往网址"):/*EN*/("Goto URL")),icon:"/@aae/assets/wait_goto.svg",catalog:["WebRpa"],
		attrs:{
			...SegObjShellAttr,
			"page":{
				name:"page",showName:"Page",type:"string",key:1,fixed:1,initVal:"aaPage"
			},
			"url":{
				name:"url",showName:"URL",type:"string",key:1,fixed:1,initVal:"https://www.google.com"
			},
			"timeout":{
				name:"timeout",showName:"Timeout",type:"int",key:0,fixed:1,initVal:0
			},
			"waitBefore":{
				name:"waitBefore",showName:"Wait Before",type:"int",key:1,fixed:1,initVal:0
			},
			"waitAfter":{
				name:"waitAfter",showName:"Wait After",type:"int",key:1,fixed:1,initVal:0
			},
			"outlet":{
				name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
			},
			"errorSeg":errorSeg,
			"run":{
				name:"run",showName:"Run This Step",type:"auto",key:1,fixed:1,initVal:undefined,editType:"action",
				OnAction:async function(attrObj,sender,attrLine,editBox){
					let page=await confirmPage(attrObj,sender);
					if(page){
						let seg,url;
						seg=attrObj.owner;
						url=seg.getAttrVal("url");
						await page.goto(url);
					}else{
						VFACT.app.showTip(sender,"No page assigned.");
					}
				}
			}
		},
		listHint:[
			"id","page","url","run","errorSeg","timeout","waitBefore","waitAfter","codes","desc",
		]
	});

	DocAIAgentExporter.segTypeExporters["WebRpaPageGoto"]=
	function(seg){
		let coder=this.coder;
		let editDoc=seg.doc;
		let segName=seg.idVal.val;
		let exportDebug=this.isExportDebug();
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();
		coder.newLine();
		{
			coder.maybeNewLine();
			coder.packText(`let result=true;`);coder.newLine();
			coder.packText(`let pageVal=`);this.genAttrStatement(seg.getAttr("page"));coder.packText(`;`);coder.newLine();
			coder.packText(`let waitBefore=`);this.genAttrStatement(seg.getAttr("waitBefore"));coder.packText(`;`);coder.newLine();
			coder.packText(`let waitAfter=`);this.genAttrStatement(seg.getAttr("waitAfter"));coder.packText(`;`);coder.newLine();
			coder.packText(`let timeout=(`);this.genAttrStatement(seg.getAttr("timeout"));coder.packText(`)||0;`);coder.newLine();
			coder.packText(`let url=`);this.genAttrStatement(seg.getAttr("url"));coder.packText(`;`);coder.newLine();
			coder.packText(`let page=context[pageVal];`);coder.newLine();
			coder.packText(`let opts={timeout:timeout};`);coder.newLine();
			coder.packText(`waitBefore && (await sleep(waitBefore));`);coder.newLine();
			packExtraCodes(coder,seg,"PreCodes");
			coder.packText(`try{`);coder.indentMore();coder.newLine();
			{
				coder.packText(`await page.goto(url,opts);`);coder.newLine();
				coder.packText(`waitAfter && (await sleep(waitAfter))`);coder.newLine();
			}
			coder.indentLess();coder.maybeNewLine();
			coder.packText(`}catch(error){`);coder.indentMore();coder.newLine();
			{
				packErrorSegCode(coder,seg,exportDebug);
			}
			coder.indentLess();coder.maybeNewLine();
			coder.packText(`}`);coder.newLine();
			packExtraCodes(coder,seg,"PostCodes");
			packResult(coder,seg,seg.outlet,"result");
		}
		coder.indentLess();
		coder.newLine();
		coder.packText(`};`);
		coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		coder.newLine();
	};
}

//----------------------------------------------------------------------------
//:AISeg that singal a wait flag for action
{
	EditAISeg.regDef({
		name:"WebRpaFlagWait",showName:(($ln==="CN")?("标记页面事件"):/*EN*/("Flag Event")),icon:"/@aae/assets/wait_flag.svg",catalog:["WebRpa"],
		attrs:{
			...SegObjShellAttr,
			"page":{
				name:"page",showName:"Page",type:"string",key:1,fixed:1,initVal:"aaPage"
			},
			"action":{
				name:"action",showName:"Wait Event",type:"choice",key:1,fixed:1,initVal:"navi",
				vals:[
					["navi","Navigate","Navigate"],
					["newPage","NewPage","New Page"],
					["query","Query","Query Selector"],
					["networkidle","NetworkIdle","Network Idle"],
					["dialog","Dialog","Dialog"],
					["filechooser","FileChooser","File Chooser"],
					["function","Function","Function"],
					["hostFunction","HostFunction","Host Function"],
					["downloadStart","DownloadStart","Download Start"],
					["downloadFinish","DownloadFinish","Download Finish"],
				],
			},
			"flag":{
				name:"flag",showName:"Flag",type:"string",key:1,fixed:1,initVal:"$WaitFlag"
			},
			"timeout":{
				name:"timeout",showName:"Timeout",type:"int",key:0,fixed:1,initVal:0
			},
			"query":{
				name:"query",showName:"Query/Function",type:"string",key:1,fixed:1,initVal:"",
				editType:"choice",vals:[],
				showMenu:async function(attr,sender,line,box){
					return await showQueryDlg(attr,sender,line,box);
				}
			},
			"queryHint":{
				name:"queryHint",showName:(($ln==="CN")?("查询提示"):/*EN*/("Query Hint")),type:"string",key:1,fixed:1,initVal:""
			},
			"waitBefore":{
				name:"waitBefore",showName:"Wait Before",type:"int",key:1,fixed:1,initVal:0
			},
			"waitAfter":{
				name:"waitAfter",showName:"Wait After",type:"int",key:1,fixed:1,initVal:0
			},
			"outlet":{
				name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
			}
		},
		listHint:[
			"id","page","action","flag","query","queryHint","timeout","waitBefore","waitAfter","codes","desc",
		]
	});

	DocAIAgentExporter.segTypeExporters["WebRpaFlagWait"]=
	function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let exportDebug=this.isExportDebug();
		let action=seg.getAttrVal("action");
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();coder.newLine();
		{
			coder.maybeNewLine();
			coder.packText(`let result=true;`);coder.newLine();
			coder.packText(`let pageVal=`);this.genAttrStatement(seg.getAttr("page"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $flag=`);this.genAttrStatement(seg.getAttr("flag"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $query=`);this.genAttrStatement(seg.getAttr("query"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $queryHint=`);this.genAttrStatement(seg.getAttr("queryHint"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $waitBefore=`);this.genAttrStatement(seg.getAttr("waitBefore"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $waitAfter=`);this.genAttrStatement(seg.getAttr("waitAfter"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $options={};`);coder.newLine();
			coder.packText(`let $timeout=`);this.genAttrStatement(seg.getAttr("timeout"));coder.packText(`;`);coder.newLine();
			coder.packText(`let page=context[pageVal];`);coder.newLine();
			coder.packText(`let $args=[];`);coder.newLine();
			coder.newLine();
			coder.packText(`if($timeout){$options.timeout=$timeout;}`);coder.newLine();
			coder.packText(`$waitBefore && (await sleep($waitBefore));`);coder.newLine();
			packExtraCodes(coder,seg,"PreCodes");
			switch(action){
				case "navi":
				case "navigation":
					coder.packText(`context[$flag]=page.waitForNavigation($options);`);coder.newLine();
					break;
				case "newPage":
					coder.packText(`context[$flag]=page.waitForNewPage($options);`);coder.newLine();
					break;
				case "networkidle":
					coder.packText(`context[$flag]=page.waitForNetworkIdle($options);`);coder.newLine();
					break;
				case "dialog":
					coder.packText(`context[$flag]=page.waitForDialog($options);`);coder.newLine();
					break;
				case "filechooser":
					coder.packText(`context[$flag]=page.waitForFileChooser($options);`);coder.newLine();
					break;
				case "query":
					coder.packText(`$query=$queryHint?(await page.confirmQuery($query,$queryHint,"${seg.jaxId}")):$query;`);coder.newLine();
					coder.packText(`if(!$query) throw Error("Missing query. Query hint: "+$queryHint);`);coder.newLine();
					coder.packText(`context[$flag]=context.webRpa.waitQuery(page,$query,$options);`);coder.newLine();
					break;
				case "function":
					coder.packText(`context[$flag]=page.waitForFunction($query,$options,...$args);`);coder.newLine();
					break;
				case "hostFunction":
					coder.packText(`context[$flag]=page.waitForHostFunction($query,$args,$options);`);coder.newLine();
					break;
				case "downloadStart":
					coder.packText(`context[$flag]=page.waitForDownloadBegin($options);`);coder.newLine();
					break;
				case "downloadFinish":
					coder.packText(`context[$flag]=page.waitForDownloadEnd($options);`);coder.newLine();
					break;
			}
			coder.packText(`$waitAfter && (await sleep($waitAfter))`);coder.newLine();
			packExtraCodes(coder,seg,"PostCodes");
			packResult(coder,seg,seg.outlet,"result");
		}
		coder.indentLess();coder.maybeNewLine();
		coder.packText(`};`);
		coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		coder.newLine();
	};
}

//----------------------------------------------------------------------------
//:AISeg that await a page flag
{
	EditAISeg.regDef({
		name:"WebRpaWaitFor",showName:(($ln==="CN")?("等待事件发生"):/*EN*/("Wait Flag")),icon:"/@aae/assets/wait_await.svg",catalog:["WebRpa"],
		attrs:{
			...SegObjShellAttr,
			"page":{
				name:"page",showName:"Page",type:"string",key:1,fixed:1,initVal:"aaPage"
			},
			"flag":{
				name:"flag",showName:"Flag",type:"string",key:1,fixed:1,initVal:"$WaitFlag"
			},
			"waitBefore":{
				name:"waitBefore",showName:"Wait Before",type:"int",key:1,fixed:1,initVal:0
			},
			"waitAfter":{
				name:"waitAfter",showName:"Wait After",type:"int",key:1,fixed:1,initVal:0
			},
			"outlet":{
				name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
			},
			"catchlet":{
				name:"catchlet",showName:"Error",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
				attrs:{
					"id":{
						name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"Error",
					},
				}
			}
		},
		listHint:[
			"id","page","flag","waitBefore","waitAfter","codes","desc",
		]
	});

	DocAIAgentExporter.segTypeExporters["WebRpaWaitFor"]=
	function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let exportDebug=this.isExportDebug();
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();coder.newLine();
		{
			coder.maybeNewLine();
			coder.packText(`let result=true;`);coder.newLine();
			coder.packText(`let pageVal=`);this.genAttrStatement(seg.getAttr("page"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $flag=`);this.genAttrStatement(seg.getAttr("flag"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $waitBefore=`);this.genAttrStatement(seg.getAttr("waitBefore"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $waitAfter=`);this.genAttrStatement(seg.getAttr("waitAfter"));coder.packText(`;`);coder.newLine();
			coder.packText(`let page=context[pageVal];`);coder.newLine();
			coder.packText(`$waitBefore && (await sleep($waitBefore));`);coder.newLine();
			packExtraCodes(coder,seg,"PreCodes");
			coder.packText(`try{`);coder.indentMore();coder.newLine();
			{
				coder.packText(`result=$flag?(await context[$flag]):input;`);coder.newLine();
			}
			coder.indentLess();coder.maybeNewLine();
			coder.packText(`}catch(error){`);coder.indentMore();coder.newLine();
			{
				packResult(coder,seg,seg.catchlet,"error",false);
			}
			coder.indentLess();coder.maybeNewLine();
			coder.packText(`}`);coder.newLine();
			
			coder.packText(`$waitAfter && (await sleep($waitAfter))`);coder.newLine();
			packExtraCodes(coder,seg,"PostCodes");
			packResult(coder,seg,seg.outlet,"result",false);
		}
		coder.indentLess();coder.maybeNewLine();
		coder.packText(`};`);
		coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		coder.newLine();
	};
}

//----------------------------------------------------------------------------
//:AISeg that send user-mouse/touch action to page
{
	EditAISeg.regDef({
		name:"WebRpaMouseAction",showName:(($ln==="CN")?("鼠标动作"):/*EN*/("Mouse Action")),icon:"mouse.svg",catalog:["WebRpa"],
		attrs:{
			...SegObjShellAttr,
			"page":{
				name:"page",showName:"Page",type:"string",key:1,fixed:1,initVal:"aaPage"
			},
			"action":{
				name:"action",showName:(($ln==="CN")?("动作"):/*EN*/("Action")),type:"choice",key:1,fixed:1,initVal:"Click",
				vals:[
					["Click","Click","Click"],
					["MouseDown","Mouse Down","Mouse Down"],
					["MouseUp","Mouse Up","Mouse Up"],
					["MouseMove","Mouse Move","Mouse Move"],
					["MouseReset","Mouse Reset","Reset Mouse"],
					["Wheel","Mouse Wheel","Mouse Wheel"],
					["ScrollToShow","Scroll To Show","Scroll To Show"],
					/*["Tap","Tap","Tap"],
					["TouchStart","Touch Start","Touch Start"],
					["TouchMove","Touch Move","Touch Move"],
					["TouchEnd","Touch End","Touch End"],*/
				],
			},
			"query":{
				name:"query",showName:"Query",type:"string",key:1,fixed:1,initVal:"",
				editType:"choice",vals:[],
				showMenu:async function(attr,sender,line,box){
					return await showQueryDlg(attr,sender,line,box);
				}
			},
			"queryHint":{
				name:"queryHint",showName:"Query Hint",type:"string",key:1,fixed:1,initVal:""
			},
			"dx":{
				name:"dx",showName:"X (Offset)",type:"int",key:1,fixed:1,initVal:0
			},
			"dy":{
				name:"dy",showName:"Y (Offset)",type:"int",key:1,fixed:1,initVal:0
			},
			"deltaX":{
				name:"deltaX",showName:"Wheel scroll X",type:"int",key:1,fixed:1,initVal:0
			},
			"deltaY":{
				name:"deltaY",showName:"Wheel scroll Y",type:"int",key:1,fixed:1,initVal:100
			},
			"async":{
				name:"async",showName:"Async action",type:"bool",key:1,fixed:1,initVal:false
			},
			"options":{
				name:"options",showName:"Options",type:"hyperObj",key:1,fixed:1,initVal:undefined,
				template:function(obj){
					let action;
					action=obj.getAttrVal("action");
					switch(action){
						default:
							return{
								title:"No options for this action",label:"",
								properties:{}
							};
						case "MouseDown":
						case "MouseUp":
							return {
								title:"Mouse action options:",label:"",
								properties:{
									button:{
										type:"auto",label:"Mouse button:",
										choices:[{text:"Left button",value:"left"},{text:"Right button",value:"right"},{text:"Middle button",value:"middle"}]
									},
								},
								wrapObject(vo){
									if(!vo.button){delete vo.button;}
									return vo;
								}
							};
						case "MouseMove":
							return {
								title:"Mouse move options:",label:"",
								properties:{
									steps:{
										type:"auto",label:"Move steps:",
										choices:[{text:"1 step",value:1},{text:"2 steps",value:2},{text:"5 steps",value:5},{text:"10 steps",value:10}]
									},
								},
								wrapObject(vo){
									if(!vo.steps){delete vo.steps;}
									return vo;
								}
							};
						case "Click":{
							return {
								title:"Mouse click options:",
								label:"",//"Mouse action options:",
								properties:{
									button:{
										type:"auto",label:"Mouse button:",
										choices:[{text:"Left button",value:"left"},{text:"Right button",value:"right"},{text:"Middle button",value:"middle"}]
									},
									count:{
										type:"auto",label:"Click count:",desc:"Used in Action: Click.",
										choices:[{text:"1 click",value:1},{text:"2 clicks",value:2},{text:"3 clicks",value:3}]
									},
									delay:{
										type:"auto",label:"Delay:",desc:"Gap time between clicks.",
										choices:[{text:"50ms",value:50},{text:"100ms",value:100},{text:"200ms",value:300},{text:"500ms",value:500}]
									},
									queryError:{
										type:"bool",label:"Throw querry error:",
									},
								},
								wrapObject(vo){
									if(!vo.button){delete vo.button;}
									if(!vo.count){delete vo.count;}
									if(!vo.delay){delete vo.delay;}
									return vo;
								}
							};
						}
						case "Wheel":{
							return {
								title:"Mouse wheel options:",label:"",
								properties:{
									steps:{
										type:"auto",label:"Move steps:",
										choices:[{text:"1 step",value:1},{text:"2 steps",value:2},{text:"5 steps",value:5},{text:"10 steps",value:10}]
									},
									mouseX:{
										type:"auto",label:"Mouse X:",initValue:undefined
									},
									mouseY:{
										type:"auto",label:"Mouse Y:",initValue:undefined
									},
									queryError:{
										type:"bool",label:"Throw querry error:",
									},
								},
								wrapObject(vo){
									if(!vo.steps){delete vo.steps;}
									if(!vo.mouseX && vo.mouseX!==0){delete vo.mouseX;}
									if(!vo.mouseY && vo.mouseY!==0){delete vo.mouseY;}
									return vo;
								}
							};
						}
					}
				}
			},
			"waitBefore":{
				name:"waitBefore",showName:"Wait Before",type:"int",key:1,fixed:1,initVal:0
			},
			"waitAfter":{
				name:"waitAfter",showName:"Wait After",type:"int",key:1,fixed:1,initVal:0
			},
			"outlet":{
				name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
			},
			"errorSeg":errorSeg,
			"run":{
				name:"run",showName:"Run This Step",type:"auto",key:1,fixed:1,initVal:undefined,editType:"action",
				OnAction:async function(attrObj,sender,attrLine,editBox){
					let seg,page,options,action,query,x,y;
					seg=attrObj.owner;
					action=seg.getAttrVal("action");
					options=seg.getAttrVal("options");
					query=seg.getAttrVal("query");
					x=seg.getAttrVal("dx");
					y=seg.getAttrVal("dy");
					page=await confirmPage(attrObj,sender);
					if(!page){
						VFACT.app.showTip(sender,"No page assigned.");
						return;
					}
					switch(action){
						case "Click":
							if(query){
								let opts={...options};
								if(x!==0 || y!==0){
									opts.offset={x,y};
								}
								await page.clickOn(query,{...options,offset:((!!x) || (!!y))?{x:x||0,y:y||0}:undefined});
							}else{
								await page.mouseClick(x,y,{...options});
							}
							break;
						case "MouseDown":
							await page.mouseDown({...options});
							break;
						case "MouseUp":
							await page.mouseUp({...options});
							break;
						case "MouseMove":
							await page.mouseMove(x,y,{...options});
							break;
						case "MouseReset":
							await page.mouseReset();
							break;
					}
				}
			}
		},
		listHint:[
			"id","page","action","query","queryHint","dx","dy","deltaX","deltaY","options","async","errorSeg","run","waitBefore","waitAfter","codes","desc",
		],
		OnAttrEdit(box,attr,value){
			if(!attr || attr.name==="action"){
				let action=this.getAttrVal("action");
				switch(action){
					case "Click":
					case "MouseMove":
					case "TouchStart":
					case "TouchMove":
						box.showAttrLine(this.getAttr("dx"));
						box.showAttrLine(this.getAttr("dy"));
						break;
					default:
						box.hideAttrLine(this.getAttr("dx"));
						box.hideAttrLine(this.getAttr("dy"));
						break;
				}
				if(action==="Wheel"){
					box.showAttrLine(this.getAttr("deltaX"));
					box.showAttrLine(this.getAttr("deltaY"));
				}else{
					box.hideAttrLine(this.getAttr("deltaX"));
					box.hideAttrLine(this.getAttr("deltaY"));
				}
				switch(action){
					case "Click":
					case "Tap":
						box.showAttrLine(this.getAttr("query"));
						break;
					default:
						box.hideAttrLine(this.getAttr("query"));
						break;
				}
			}
		}
	});

	DocAIAgentExporter.segTypeExporters["WebRpaMouseAction"]=
	function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let action=seg.getAttrVal("action");
		let exportDebug=this.isExportDebug();
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();coder.newLine();
		{
			coder.maybeNewLine();
			coder.packText(`let result=true;`);coder.newLine();
			coder.packText(`let pageVal=`);this.genAttrStatement(seg.getAttr("page"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $query=`);this.genAttrStatement(seg.getAttr("query"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $queryHint=`);this.genAttrStatement(seg.getAttr("queryHint"));coder.packText(`;`);coder.newLine();
			if(action==="Wheel"){
				coder.packText(`let $deltaX=`);this.genAttrStatement(seg.getAttr("deltaX"));coder.packText(`;`);coder.newLine();
				coder.packText(`let $deltaY=`);this.genAttrStatement(seg.getAttr("deltaY"));coder.packText(`;`);coder.newLine();
			}else{
				coder.packText(`let $x=`);this.genAttrStatement(seg.getAttr("dx"));coder.packText(`;`);coder.newLine();
				coder.packText(`let $y=`);this.genAttrStatement(seg.getAttr("dy"));coder.packText(`;`);coder.newLine();
			}
			coder.packText(`let $options=`);this.genAttrStatement(seg.getAttr("options"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $waitBefore=`);this.genAttrStatement(seg.getAttr("waitBefore"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $waitAfter=`);this.genAttrStatement(seg.getAttr("waitAfter"));coder.packText(`;`);coder.newLine();
			coder.packText(`let page=context[pageVal];`);coder.newLine();
			coder.packText(`let $async=`);this.genAttrStatement(seg.getAttr("async"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $pms=null;`);coder.newLine();
			coder.packText(`let $done=false;`);coder.newLine();
			coder.packText(`$waitBefore && (await sleep($waitBefore));`);coder.newLine();
			packExtraCodes(coder,seg,"PreCodes");
			coder.packText(`try{`);coder.indentMore();coder.newLine();
			{
				switch(action){
					case "Click":
					case "click":{
						coder.packText(`if($query||$queryHint){`);
						coder.indentMore();coder.newLine();
						{
							coder.packText(`$query=$queryHint?(await context.webRpa.confirmQuery(page,$query,$queryHint,"${seg.jaxId}")):$query;`);coder.newLine();
							coder.packText(`if(!$query) throw Error("Missing query. Query hint: "+$queryHint);`);coder.newLine();
							coder.packText(`$pms=page.click($query,{...$options,offset:((!!$x) || (!!$y))?{x:$x||0,y:$y||0}:undefined});`);coder.newLine();
						}
						coder.indentLess();coder.maybeNewLine();
						coder.packText(`}else{`);
						coder.indentMore();coder.newLine();
						{
							coder.packText(`$pms=page.mouse.click($x,$y,$options||{});`);coder.newLine();
						}
						coder.indentLess();coder.maybeNewLine();
						coder.packText(`}`);coder.maybeNewLine();
						break;
					}
					case "tap":
					case "Tap":{
						coder.packText(`if($query||$queryHint){`);
						coder.indentMore();coder.newLine();
						{
							coder.packText(`$query=$queryHint?(await context.webRpa.confirmQuery(page,$query,$queryHint,"${seg.jaxId}")):$query;`);coder.newLine();
							coder.packText(`if(!$query) throw Error("Missing query. Query hint: "+$queryHint);`);coder.newLine();
							coder.packText(`$pms=page.tap($query);`);coder.newLine();
						}
						coder.indentLess();coder.maybeNewLine();
						coder.packText(`}else{`);
						coder.indentMore();coder.newLine();
						{
							coder.packText(`$pms=page.touchscreen.tap($x,$y);`);coder.newLine();
						}
						coder.indentLess();coder.maybeNewLine();
						coder.packText(`}`);coder.maybeNewLine();
						break;
					}
					case "mousemove":
					case "MouseMove":{
						coder.packText(`if($query||$queryHint){`);
						coder.indentMore();coder.newLine();
						{
							coder.packText(`$query=$queryHint?(await context.webRpa.confirmQuery(page,$query,$queryHint,"${seg.jaxId}")):$query;`);coder.newLine();
							coder.packText(`if(!$query) throw Error("Missing query. Query hint: "+$queryHint);`);coder.newLine();
							coder.packText(`$pms=page.hover($query,{...$options,offset:((!!$x) || (!!$y))?{x:$x||0,y:$y||0}:undefined});`);coder.newLine();
						}
						coder.indentLess();coder.maybeNewLine();
						coder.packText(`}else{`);
						coder.indentMore();coder.newLine();
						{
							coder.packText(`$pms=page.mouse.move($x,$y,$options||{});`);coder.newLine();
						}
						coder.indentLess();coder.maybeNewLine();
						coder.packText(`}`);coder.maybeNewLine();
						break;
					}
					case "mousedown":
					case "MouseDown":{
						coder.packText(`$pms=page.mouse.down($options||{});`);coder.newLine();
						break;
					}
					case "mouseup":
					case "MouseUp":{
						coder.packText(`$pms=page.mouse.up($options||{});`);coder.newLine();
						break;
					}
					case "mousereset":
					case "MouseReset":{
						coder.packText(`$pms=page.mouse.reset();`);coder.newLine();
						break;
					}
					case "touchstart":
					case "TouchStart":{
						coder.packText(`$pms=page.touchscreen.touchStart($x,$y);`);coder.newLine();
						break;
					}
					case "touchmove":
					case "TouchMove":{
						coder.packText(`$pms=page.touchscreen.touchMove($x,$y);`);coder.newLine();
						break;
					}
					case "touchend":
					case "TouchEnd":{
						coder.packText(`$pms=page.touchscreen.touchEnd();`);coder.newLine();
						break;
					}
					case "ScrollToShow":{
						coder.packText(`if($query||$queryHint){`);
						coder.indentMore();coder.newLine();
						{
							coder.packText(`$query=$queryHint?(await context.webRpa.confirmQuery(page,$query,$queryHint,"${seg.jaxId}")):$query;`);coder.newLine();
							coder.packText(`if(!$query) throw Error("Missing query. Query hint: "+$queryHint);`);coder.newLine();
							coder.packText(`$pms=page.scrollIntoView($query);`);coder.newLine();
						}
						coder.indentLess();coder.maybeNewLine();
						coder.packText(`}`);coder.maybeNewLine();
					}
					case "Wheel":{
						coder.packText(`if($query||$queryHint){`);
						coder.indentMore();coder.newLine();
						{
							coder.packText(`$query=$queryHint?(await context.webRpa.confirmQuery(page,$query,$queryHint,"${seg.jaxId}")):$query;`);coder.newLine();
							coder.packText(`if(!$query) throw Error("Missing query. Query hint: "+$queryHint);`);coder.newLine();
							coder.packText(`$pms=page.mouseWheel($query,{...$options,deltaX:$deltaX||0,deltaY:$deltaY||100});`);coder.newLine();
						}
						coder.indentLess();coder.maybeNewLine();
						coder.packText(`}else{`);
						coder.indentMore();coder.newLine();
						{
							coder.packText(`$pms=page.mouseWheel(null,{...$options,deltaX:$deltaX||0,deltaY:$deltaY||100});`);coder.newLine();
						}
						coder.indentLess();coder.maybeNewLine();
						coder.packText(`}`);coder.maybeNewLine();
						break;
					}
				}
				coder.packText(`if($pms && (!$async)){$done=await $pms;}`);coder.newLine();
				coder.packText(`$waitAfter && (await sleep($waitAfter))`);coder.newLine();
			}
			coder.indentLess();coder.maybeNewLine();
			coder.packText(`}catch(error){`);coder.indentMore();coder.newLine();
			{
				packErrorSegCode(coder,seg,exportDebug);
			}
			coder.indentLess();coder.maybeNewLine();
			coder.packText(`}`);coder.newLine();
			packExtraCodes(coder,seg,"PostCodes");
			packResult(coder,seg,seg.outlet,"result");
		}
		coder.indentLess();coder.maybeNewLine();
		coder.packText(`};`);
		coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		coder.newLine();
	};
}

//----------------------------------------------------------------------------
//:AISeg that send keyboard action to page
{
	EditAISeg.regDef({
		name:"AAFKeyboardAction",showName:(($ln==="CN")?("键盘动作"):/*EN*/("K.B. Action")),icon:"keybtn.svg",catalog:["WebRpa"],
		attrs:{
			...SegObjShellAttr,
			"page":{
				name:"page",showName:"Page",type:"string",key:1,fixed:1,initVal:"aaPage"
			},
			"action":{
				name:"action",showName:(($ln==="CN")?("动作"):/*EN*/("Action")),type:"choice",key:1,fixed:1,initVal:"Type",
				vals:[
					["Type","Type","Type"],
					["KeyPress","Key Press","Key Press"],
					["KeyDown","Key Down","Key Down"],
					["KeyUp","Key Up","Key Up"],
					["Shortcut","Shortcut","Shortcut"],
					["Paste","Paste","Paste"],
				],
			},
			"query":{
				name:"query",showName:"Query",type:"string",key:1,fixed:1,initVal:"",
				editType:"choice",vals:[],
				showMenu:async function(attr,sender,line,box){
					return await showQueryDlg(attr,sender,line,box);
				}
			},
			"queryHint":{
				name:"queryHint",showName:"Query Hint",type:"string",key:1,fixed:1,initVal:""
			},
			"key":{
				name:"key",showName:"Key or content",type:"string",key:1,fixed:1,initVal:"Enter"
			},
			"async":{
				name:"async",showName:"Async action",type:"bool",key:1,fixed:1,initVal:false
			},
			"options":{
				name:"options",showName:"Options",type:"hyperObj",key:1,fixed:1,initVal:undefined,
				template:function(obj){
					let action;
					action=obj.getAttrVal("action");
					switch(action){
						default:
							return {
								title:"Keyboard options:",label:"",
								properties:{
									delay:{
										type:"auto",label:"Delay between keys:",
										choices:[{text:"50ms",value:50},{text:"100ms",value:100},{text:"200ms",value:300},{text:"500ms",value:500}]
									}
								},
								wrapObject(vo){
									if(!vo.delay){delete vo.delay;}
									return vo;
								}
							};
						case "Type":
							return {
								title:"Type string options:",label:"",
								properties:{
									delay:{
										type:"auto",label:"Delay between keys:",
										choices:[{text:"50ms",value:50},{text:"100ms",value:100},{text:"200ms",value:300},{text:"500ms",value:500}]
									},
									coverEnter:{
										type:"bool",label:"Cover enter:",initValue:false,
										desc:(($ln==="CN")?("用Shift+Enter替换文本里的Enter"):/*EN*/("Replace Enter with Shift+Enter in the text"))
									},
									postEnter:{
										type:"bool",label:"Post enter:",initValue:false,
										desc:(($ln==="CN")?("输入结束后，按Enter键"):/*EN*/("Press Enter after input"))
									},
									queryError:{
										type:"bool",label:"Throw querry error:",
									},
								},
								wrapObject(vo){
									if(!vo.delay){delete vo.delay;}
									return vo;
								}
							};
					}
				}
			},
			"waitBefore":{
				name:"waitBefore",showName:"Wait Before",type:"int",key:1,fixed:1,initVal:0
			},
			"waitAfter":{
				name:"waitAfter",showName:"Wait After",type:"int",key:1,fixed:1,initVal:0
			},
			"outlet":{
				name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
			},
			"errorSeg":errorSeg,
			"run":{
				name:"run",showName:"Run This Step",type:"auto",key:1,fixed:1,initVal:undefined,editType:"action",
				OnAction:async function(attrObj,sender,attrLine,editBox){
					let seg,page,options,action,query,key;
					seg=attrObj.owner;
					action=seg.getAttrVal("action");
					options=seg.getAttrVal("options");
					query=seg.getAttrVal("query");
					key=seg.getAttrVal("key");
					page=await confirmPage(attrObj,sender);
					if(!page){
						VFACT.app.showTip(sender,"No page assigned.");
						return;
					}
					switch(action){
						case "Type":
							if(query){
								await page.keyboardType(query,key,{...options});
							}else{
								await page.keyboardType(null,key,{...options});
							}
							break;
						case "KeyPress":
							await page.keyboardPress(key,{...options});
							break;
						case "KeyDown":
							await page.keyboardDown(key,{...options});
							break;
						case "KeyUp":
							await page.keyboardUp(key,{...options});
							break;
						case "Shortcut":
							await page.keyboardPressShortcut(key,{...options});
							break;
						case "Paste":
							await page.keyboardPaste(key,{...options});
							break;
					}
				}
			}
		},
		listHint:[
			"id","page","action","query","queryHint","key","options","async","errorSeg","run","waitBefore","waitAfter","codes","desc",
		]
	});

	DocAIAgentExporter.segTypeExporters["AAFKeyboardAction"]=
	function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let action=seg.getAttrVal("action");
		let exportDebug=this.isExportDebug();
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();coder.newLine();
		{
			coder.maybeNewLine();
			coder.packText(`let result=true;`);coder.newLine();
			coder.packText(`let pageVal=`);this.genAttrStatement(seg.getAttr("page"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $action=`);this.genAttrStatement(seg.getAttr("action"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $query=`);this.genAttrStatement(seg.getAttr("query"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $queryHint=`);this.genAttrStatement(seg.getAttr("queryHint"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $key=`);this.genAttrStatement(seg.getAttr("key"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $options=`);this.genAttrStatement(seg.getAttr("options"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $waitBefore=`);this.genAttrStatement(seg.getAttr("waitBefore"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $waitAfter=`);this.genAttrStatement(seg.getAttr("waitAfter"));coder.packText(`;`);coder.newLine();
			coder.packText(`let page=context[pageVal];`);coder.newLine();
			coder.packText(`let $async=`);this.genAttrStatement(seg.getAttr("async"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $pms=null;`);coder.newLine();
			coder.packText(`let $done=false;`);coder.newLine();
			coder.packText(`$waitBefore && (await sleep($waitBefore));`);coder.newLine();
			packExtraCodes(coder,seg,"PreCodes");
			coder.packText(`try{`);coder.indentMore();coder.newLine();
			{
				switch(action){
					case "type":
					case "Type":{
						coder.packText(`if($query||$queryHint){`);
						coder.indentMore();coder.newLine();
						{
							coder.packText(`$query=$queryHint?(await context.webRpa.confirmQuery(page,$query,$queryHint,"${seg.jaxId}")):$query;`);coder.newLine();
							coder.packText(`if(!$query) throw Error("Missing query. Query hint: "+$queryHint);`);coder.newLine();
							coder.packText(`$pms=page.type($query,$key,$options||{});`);coder.newLine();
						}
						coder.indentLess();coder.maybeNewLine();
						coder.packText(`}else{`);
						coder.indentMore();coder.newLine();
						{
							coder.packText(`$pms=page.keyboard.type($key,$options||{});`);coder.newLine();
						}
						coder.indentLess();coder.maybeNewLine();
						coder.packText(`}`);coder.maybeNewLine();
						break;
					}
					case "keypress":
					case "KeyPress":{
						coder.packText(`$pms=page.keyboard.press($key,$options||{});`);coder.newLine();
						break;
					}
					case "keydown":
					case "KeyDown":{
						coder.packText(`$pms=page.keyboard.down($key,$options||{});`);coder.newLine();
						break;
					}
					case "keyup":
					case "KeyUp":{
						coder.packText(`$pms=page.keyboard.up($key,$options||{});`);coder.newLine();
						break;
					}
					case "shortcut":
					case "Shortcut":{
						coder.packText(`$pms=page.pressShortcut($key,$options||{});`);coder.newLine();
						break;
					}
					case "Paste":
					case "paste":{
						coder.packText(`$pms=page.pasteText($key,$options||{});`);coder.newLine();
						break;
					}
				}
				coder.packText(`if($pms && (!$async)){$done=await $pms;}`);coder.newLine();
				coder.packText(`$waitAfter && (await sleep($waitAfter))`);coder.newLine();
			}
			coder.indentLess();coder.maybeNewLine();
			coder.packText(`}catch(error){`);coder.indentMore();coder.newLine();
			{
				packErrorSegCode(coder,seg,exportDebug);
			}
			coder.indentLess();coder.maybeNewLine();
			coder.packText(`}`);coder.newLine();
			packExtraCodes(coder,seg,"PostCodes");
			packResult(coder,seg,seg.outlet,"result");
		}
		coder.indentLess();coder.maybeNewLine();
		coder.packText(`};`);
		coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		coder.newLine();
	};
}

//----------------------------------------------------------------------------
//:AISeg that read page content
{
	EditAISeg.regDef({
		name:"WebRpaReadPage",showName:(($ln==="CN")?("读取页面"):/*EN*/("Read Page")),icon:"read.svg",catalog:["WebRpa"],
		attrs:{
			...SegObjShellAttr,
			"page":{
				name:"page",showName:"Page",type:"string",key:1,fixed:1,initVal:"aaPage"
			},
			"target":{
				name:"target",showName:"Read Target",type:"choice",key:1,fixed:1,initVal:"cleanHTML",
				vals:[
					["cleanHTML","CleanHTML","Cleaned HTML"],
					["html","HTML","Inner HTML"],
					["view","View","AAE Tagged Node View"],
					["text","Text","Inner Text"],
					["article","Article","Article"],
				],
			},
			"node":{
				name:"node",showName:"Read Node",type:"auto",key:1,fixed:1,initVal:null,
				editType:"choice",vals:[],
				showMenu:async function(attr,sender,line,box){
					return await showQueryDlg(attr,sender,line,box);
				}
			},
			"options":{
				name:"options",showName:"Options",type:"hyperObj",key:1,fixed:1,initVal:undefined,
				template:function(obj){
					let target;
					target=obj.getAttrVal("target");
					switch(target){
						case "cleanHTML":
							return {
								title:"Read page options:",label:"",
								properties:{
									compact:{
										type:"int",label:"Compact level:",initValue:undefined,
										choices:[
											{text:"0: None",value:"0"},
											{text:"1: Remove none render elements",value:1},
											{text:"2: Also remove hidden elements",value:2},
											{text:"3: Also remove helper AAE-atrributes",value:3},
											{text:"4: Also shorten text longer than 50 chars",value:4},
											{text:"5: Also merge isolated div element",value:5},
										]
									},
									cleanMarks:{
										type:"bool",label:"Clean all AAE-attributes: ",initValue:false,
									}
								}
							};
							break;
						case "html":
							return {
								title:"Read page options:",label:"",
								properties:{
									removeHidden:{
										type:"bool",label:"Remove hidden elements: ",initValue:true,
									},
									excludeNodeTags:{
										type:"auto",label:"Exclude node-tags:",initValue:true,
									},
									excludeNodeTypes:{
										type:"auto",label:"Exclude node-types:",initValue:false,
									},
									shortText:{
										type:"int",label:"Shorten text longer than: ",initValue:0,
										desc:"Set to zero to ignore."
									},
									cleanMarks:{
										type:"bool",label:"Clean all AAE-attributes: ",initValue:false,
									}
								},
								wrapObject(vo){
									return vo;
								}
							};
						default:
							return {
								title:"Read page options:",label:"",
								properties:{
									removeHidden:{
										type:"bool",label:"Remove hidden elements: ",initValue:true,
									},
									excludeNodeTags:{
										type:"bool",label:"Exclude node-tag-names:",initValue:true,
									},
									excludeNodeTypes:{
										type:"bool",label:"Exclude node-types:",initValue:true,
									}
								}
							};
					}
				}
			},
			"waitBefore":{
				name:"waitBefore",showName:"Wait Before",type:"int",key:1,fixed:1,initVal:0
			},
			"waitAfter":{
				name:"waitAfter",showName:"Wait After",type:"int",key:1,fixed:1,initVal:0
			},
			"outlet":{
				name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
			},
			"errorSeg":errorSeg,
			"run":{
				name:"run",showName:"Run This Step",type:"auto",key:1,fixed:1,initVal:undefined,editType:"action",
				OnAction:async function(attrObj,sender,attrLine,editBox){
					let seg,page,options,target,query,result;
					seg=attrObj.owner;
					target=seg.getAttrVal("target");
					options=seg.getAttrVal("options");
					query=seg.getAttrVal("query")||null;
					page=await confirmPage(attrObj,sender);
					if(!page){
						VFACT.app.showTip(sender,"No page assigned.");
						return;
					}
					switch(target){
						case "cleanHTML":
							result=await page.readInnerHTML(query,{compact:2});
							break;
						case "html":
							result=await page.getInnerHTML(query,null);
							break;
						case "view":
							result=await page.readView(query,null);
							break;
						case "text":
							result=await page.readInnerText(query,null);
							break;
						case "article":
							result=await page.readArticle(query,null);
							break;
					}
					if(result){
						console.log("Action result:");
						console.log(result);
						let app=VFACT.app;
						if(typeof(result)!=="string"){
							result=JSON.stringify(result);
						}
						await app.modalDlg("/@editkit/ui/DlgLongText.js",{
							text:result,
							title:(($ln==="CN")?(`抓取的内容:`):/*EN*/(`Snaped content:`)),
						});
					}
				}
			}
		},
		listHint:[
			"id","page","target","node","options","errorSeg","run","waitBefore","waitAfter","codes","desc",
		]
	});

	DocAIAgentExporter.segTypeExporters["WebRpaReadPage"]=
	function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let exportDebug=this.isExportDebug();
		let target=seg.getAttrVal("target");
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();coder.newLine();
		{
			coder.maybeNewLine();
			coder.packText(`let result=null;`);coder.newLine();
			coder.packText(`let pageVal=`);this.genAttrStatement(seg.getAttr("page"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $node=`);this.genAttrStatement(seg.getAttr("node"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $options=`);this.genAttrStatement(seg.getAttr("options"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $waitBefore=`);this.genAttrStatement(seg.getAttr("waitBefore"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $waitAfter=`);this.genAttrStatement(seg.getAttr("waitAfter"));coder.packText(`;`);coder.newLine();
			coder.packText(`let page=context[pageVal];`);coder.newLine();
			coder.packText(`let $target=`);this.genAttrStatement(seg.getAttr("target"));coder.packText(`;`);coder.newLine();
			coder.packText(`$waitBefore && (await sleep($waitBefore));`);coder.newLine();
			packExtraCodes(coder,seg,"PreCodes");
			coder.packText(`try{`);coder.indentMore();coder.newLine();
			{
				coder.packText(`switch($target){`);coder.indentMore();coder.newLine();
				{
					coder.packText(`case "cleanHTML":{`);coder.indentMore();coder.newLine();
					{
						coder.packText(`result=await context.webRpa.readInnerHTML(page,$node,{removeHidden:true,...$options});`);coder.newLine();
						coder.packText(`break;`);coder.newLine();
					}
					coder.indentLess();coder.maybeNewLine();
					coder.packText("}");coder.newLine();

					coder.packText(`case "html":{`);coder.indentMore();coder.newLine();
					{
						coder.packText(`result=await context.webRpa.getInnerHTML(page,$node);`);coder.newLine();
						coder.packText(`break;`);coder.newLine();
					}
					coder.indentLess();coder.maybeNewLine();
					coder.packText("}");coder.newLine();

					coder.packText(`case "view":{`);coder.indentMore();coder.newLine();
					{
						coder.packText(`result=await context.webRpa.readNodeView(page,$node,{removeHidden:false,...$options});`);coder.newLine();
						coder.packText(`break;`);coder.newLine();
					}
					coder.indentLess();coder.maybeNewLine();
					coder.packText("}");coder.newLine();

					coder.packText(`case "text":{`);coder.indentMore();coder.newLine();
					{
						coder.packText(`result=await context.webRpa.readNodeText(page,$node,{removeHidden:false,...$options});`);coder.newLine();
						coder.packText(`break;`);coder.newLine();
					}
					coder.indentLess();coder.maybeNewLine();
					coder.packText("}");coder.newLine();

					coder.packText(`case "article":{`);coder.indentMore();coder.newLine();
					{
						coder.packText(`result=await context.webRpa.readArticle(page,$node,{removeHidden:false,...$options});`);coder.newLine();
						coder.packText(`break;`);coder.newLine();
					}
					coder.indentLess();coder.maybeNewLine();
					coder.packText("}");coder.newLine();
				}
				coder.indentLess();coder.maybeNewLine();
				coder.packText("}");coder.newLine();
				coder.packText(`$waitAfter && (await sleep($waitAfter))`);coder.newLine();
			}
			coder.indentLess();coder.maybeNewLine();
			coder.packText(`}catch(error){`);coder.indentMore();coder.newLine();
			{
				packErrorSegCode(coder,seg,exportDebug);
			}
			coder.indentLess();coder.maybeNewLine();
			coder.packText(`}`);coder.newLine();
			packExtraCodes(coder,seg,"PostCodes");
			this.packUpdateContext(coder,seg);
			this.packUpdateGlobal(coder,seg);
			packResult(coder,seg,seg.outlet,"result");
		}
		coder.indentLess();coder.maybeNewLine();
		coder.packText(`};`);
		coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		coder.newLine();
	};
}

//----------------------------------------------------------------------------
//:AISeg that query node(s) in page
{
	EditAISeg.regDef({
		name:"WebRpaQuery",showName:(($ln==="CN")?("查询元素"):/*EN*/("Query Node(s)")),icon:"/@aae/assets/wait_find.svg",catalog:["WebRpa"],
		attrs:{
			...SegObjShellAttr,
			"page":{
				name:"page",showName:"Page",type:"string",key:1,fixed:1,initVal:"aaPage"
			},
			"node":{
				name:"node",showName:"From Node",type:"auto",key:1,fixed:1,initVal:undefined
			},
			"query":{
				name:"query",showName:"Query",type:"string",key:1,fixed:1,initVal:"",
				editType:"choice",vals:[],
				showMenu:async function(attr,sender,line,box){
					return await showQueryDlg(attr,sender,line,box);
				}
			},
			"queryHint":{
				name:"queryHint",showName:"Query Hint",type:"string",key:1,fixed:1,initVal:""
			},
			"multi":{
				name:"multi",showName:"Multiple",type:"bool",key:1,fixed:1,initVal:false
			},
			"options":{
				name:"options",showName:"Options",type:"auto",key:1,fixed:1,initVal:undefined
			},
			"errorSeg":errorSeg,
			"waitBefore":{
				name:"waitBefore",showName:"Wait Before",type:"int",key:1,fixed:1,initVal:0
			},
			"waitAfter":{
				name:"waitAfter",showName:"Wait After",type:"int",key:1,fixed:1,initVal:0
			},
			"outlet":{
				def:{
					...SegOutletDef,
					attrs:{
						...SegOutletDef.attrs,
						"id":{name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"Found"},
					}
				},
				name:"outlet",type:"aioutlet",key:1,fixed:1,edit:false,navi:"doc",
			},
			"outlets":{
				name:"outlets",showName:"Switches",type:"array",def:QueryFindOutlets,fixed:1,key:1,edit:false,navi:"doc",allowExtraAttr:"1",
			},
		},
		listHint:[
			"id","page","node","query","queryHint","multi","options","errorSeg","waitBefore","waitAfter","codes","desc",
		]
	});

	DocAIAgentExporter.segTypeExporters["WebRpaQuery"]=
	function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let exportDebug=this.isExportDebug();
		let outlets=seg.outletsList;
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();
		coder.newLine();
		{
			coder.maybeNewLine();
			coder.packText(`let result=true;`);coder.newLine();
			coder.packText(`let pageVal=`);this.genAttrStatement(seg.getAttr("page"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $node=`);this.genAttrStatement(seg.getAttr("node"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $query=`);this.genAttrStatement(seg.getAttr("query"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $multi=`);this.genAttrStatement(seg.getAttr("multi"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $options=`);this.genAttrStatement(seg.getAttr("options"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $waitBefore=`);this.genAttrStatement(seg.getAttr("waitBefore"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $waitAfter=`);this.genAttrStatement(seg.getAttr("waitAfter"));coder.packText(`;`);coder.newLine();
			coder.packText(`let page=context[pageVal];`);coder.newLine();
			coder.packText(`$waitBefore && (await sleep($waitBefore));`);coder.newLine();
			packExtraCodes(coder,seg,"PreCodes");
			coder.packText(`try{`);coder.indentMore();coder.newLine();
			{
				coder.packText(`if($multi){`);
				coder.indentMore();coder.newLine();
				{
					coder.packText(`result=await context.webRpa.queryNodes(page,$node,$query,$options);`);coder.newLine();
				}
				coder.indentLess();coder.maybeNewLine();
				coder.packText(`}else{`);
				coder.indentMore();coder.newLine();
				{
					coder.packText(`result=await context.webRpa.queryNode(page,$node,$query,$options);`);coder.newLine();
				}
				coder.indentLess();coder.maybeNewLine();
				coder.packText(`}`);coder.newLine();
				/*if(seg.getAttrVal("errorSeg"))*/{
					coder.packText(`if((!result)||($multi && !result.length)){`);coder.indentMore();coder.newLine();
					{
						coder.packText(`throw "Querry not found";`);
					}
					coder.indentLess();coder.maybeNewLine();
					coder.packText(`}`);coder.newLine();
				}
				packExtraCodes(coder,seg,"CheckItem");
				coder.packText(`$waitAfter && (await sleep($waitAfter))`);coder.newLine();
			}
			coder.indentLess();coder.maybeNewLine();
			coder.packText(`}catch(error){`);coder.indentMore();coder.newLine();
			{
				//Also apply missing outlet:
				let outlets=seg.outletsList||[];
				packErrorSegCode(coder,seg,exportDebug,outlets[0]);
			}
			coder.indentLess();coder.maybeNewLine();
			coder.packText(`}`);coder.newLine();
			packExtraCodes(coder,seg,"PostCodes");
			packResult(coder,seg,seg.outlet,"result");
		}
		coder.indentLess();
		coder.newLine();
		coder.packText(`};`);
		coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		coder.newLine();
	};
}

//----------------------------------------------------------------------------
//:AISeg start page trace:
{
	EditAISeg.regDef({
		name:"WebRpaTraceEvents",showName:(($ln==="CN")?("追踪事件"):/*EN*/("Trace Events")),icon:"/@aae/assets/wait_trace.svg",catalog:["WebRpa"],reverseOutlets:true,
		attrs:{
			...SegObjShellAttr,
			"page":{
				name:"page",showName:"Page",type:"string",key:1,fixed:1,initVal:"aaPage"
			},
			"async":{
				name:"async",showName:"Async",type:"bool",key:1,fixed:1,initVal:false
			},
			"outlet":{
				name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
				attrs:{
					"id":{
						name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"Done",
					},
				},
			},
			"catchlet":{
				name:"catchlet",showName:"Catch",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
				attrs:{
					"id":{
						name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"OnEvent",
					},
				},
			}
		},
		listHint:["id","page","async","codes","desc"],
	});

	DocAIAgentExporter.segTypeExporters["WebRpaTraceEvents"]=
	function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let exportDebug=this.isExportDebug();
		let asyncMode=seg.getAttrVal("async");
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();
		coder.newLine();
		{
			coder.maybeNewLine();
			coder.packText(`let result=true;`);coder.newLine();
			coder.packText(`let pageVal=`);this.genAttrStatement(seg.getAttr("page"));coder.packText(`;`);coder.newLine();
			coder.packText(`let page=context[pageVal];`);coder.newLine();
			coder.packText(`let callback,cr`);coder.newLine();
			packExtraCodes(coder,seg,"PreCodes");
			coder.packText(`callback=async function(event){`);
			coder.indentMore();coder.newLine();
			{
				let outlet=seg.catchlet||null;
				if(outlet){
					packExtraCodes(coder,seg,"PreEvent");
					coder.packText(`cr=`);this.packSegRun(coder,seg,outlet,"event",false);coder.newLine();
					packExtraCodes(coder,seg,"PostEvent");
					coder.packText(`if(cr===true){`);
					coder.indentMore();coder.newLine();
					{
						coder.packText(`context.webRpa.stopTrace(callback);`);
					}
					coder.indentLess();coder.maybeNewLine();
					coder.packText(`}`);coder.newLine();
				}
			}
			coder.indentLess();coder.maybeNewLine();
			coder.packText(`};`);coder.newLine();
			if(asyncMode){
				coder.packText(`context.webRpa.startTrace(page,callback);`);
			}else{
				coder.packText(`await context.webRpa.startTrace(page,callback);`);
			}
			packExtraCodes(coder,seg,"PostCodes");
			packResult(coder,seg,seg.outlet,"result",false);
		}
		coder.indentLess();
		coder.newLine();
		coder.packText(`};`);
		coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		coder.newLine();
	};
}

//----------------------------------------------------------------------------
//:AISeg that upload file to exchange-zone
{
	EditAISeg.regDef({
		name:"WebRpaUploadFile",showName:(($ln==="CN")?("准备文件"):/*EN*/("Push File")),icon:"/@aae/assets/wait_upload.svg",catalog:["WebRpa"],
		attrs:{
			...SegObjShellAttr,
			"fileName":{
				name:"fileName",showName:(($ln==="CN")?("文件名"):/*EN*/("File Name")),type:"string",key:1,fixed:1,initVal:""
			},
			"fileData":{
				name:"fileData",showName:(($ln==="CN")?("文件数据"):/*EN*/("File Data")),type:"auto",key:1,fixed:1,initVal:undefined
			},
			"waitBefore":{
				name:"waitBefore",showName:"Wait Before",type:"int",key:1,fixed:1,initVal:0
			},
			"waitAfter":{
				name:"waitAfter",showName:"Wait After",type:"int",key:1,fixed:1,initVal:0
			},
			"outlet":{
				name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
			},
		},
		listHint:[
			"id","fileName","fileData","waitBefore","waitAfter","codes","desc",
		]
	});

	DocAIAgentExporter.segTypeExporters["WebRpaUploadFile"]=
		function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let exportDebug=this.isExportDebug();
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();coder.newLine();
		{
			coder.maybeNewLine();
			coder.packText(`let result=true;`);coder.newLine();
			coder.packText(`let $fileName=`);this.genAttrStatement(seg.getAttr("fileName"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $fileData=`);this.genAttrStatement(seg.getAttr("fileData"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $waitBefore=`);this.genAttrStatement(seg.getAttr("waitBefore"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $waitAfter=`);this.genAttrStatement(seg.getAttr("waitAfter"));coder.packText(`;`);coder.newLine();
			coder.packText(`$waitBefore && (await sleep($waitBefore));`);coder.newLine();
			packExtraCodes(coder,seg,"PreCodes");
			coder.packText(`await context.webRpa.saveFile(aaBrowser,$fileName,$fileData);`);coder.newLine();
			coder.packText(`$waitAfter && (await sleep($waitAfter))`);coder.newLine();
			packExtraCodes(coder,seg,"PostCodes");
			packResult(coder,seg,seg.outlet,"result");
		}
		coder.indentLess();coder.maybeNewLine();
		coder.packText(`};`);
		coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		coder.newLine();
	};
}

//----------------------------------------------------------------------------
//:AISeg that handle (accept or dissmiss) dialog
{
	EditAISeg.regDef({
		name:"WebRapHandleDialog",showName:(($ln==="CN")?("处理对话框"):/*EN*/("Handle Dialog")),icon:"/@aae/assets/wait_dialog.svg",catalog:["WebRap"],
		attrs:{
			...SegObjShellAttr,
			"page":{
				name:"page",showName:"Page",type:"string",key:1,fixed:1,initVal:"aaPage"
			},
			"action":{
				name:"action",showName:(($ln==="CN")?("动作"):/*EN*/("Action")),type:"choice",key:1,fixed:1,initVal:"accept",
				vals:[
					["accept","Accept","Accept"],
					["dissmiss","Dissmiss","Dissmiss"],
				]
			},
			"text":{
				name:"text",showName:(($ln==="CN")?("文本"):/*EN*/("Text")),type:"string",key:1,fixed:1,initVal:""
			},
			"fileName":{
				name:"fileName",showName:(($ln==="CN")?("文件名"):/*EN*/("File Name")),type:"string",key:1,fixed:1,initVal:""
			},
			"errorSeg":errorSeg,
			"waitBefore":{
				name:"waitBefore",showName:"Wait Before",type:"int",key:1,fixed:1,initVal:0
			},
			"waitAfter":{
				name:"waitAfter",showName:"Wait After",type:"int",key:1,fixed:1,initVal:0
			},
			"outlet":{
				name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
			},
		},
		listHint:[
			"id","page","action","text","fileName","errorSeg","waitBefore","waitAfter","codes","desc",
		],
		OnAttrEdit(box,attr,value){
			if(!attr || attr.name==="action"){
				let action=this.getAttrVal("action");
				switch(action){
					case "accept":
						box.showAttrLine(this.getAttr("text"));
						box.showAttrLine(this.getAttr("fileName"));
						break;
					default:
						box.hideAttrLine(this.getAttr("text"));
						box.hideAttrLine(this.getAttr("fileName"));
						break;
				}
			}
		}
	});

	DocAIAgentExporter.segTypeExporters["WebRapHandleDialog"]=
	function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let exportDebug=this.isExportDebug();
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();coder.newLine();
		{
			coder.maybeNewLine();
			coder.packText(`let result=true;`);coder.newLine();
			coder.packText(`let $pageVal=`);this.genAttrStatement(seg.getAttr("page"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $action=`);this.genAttrStatement(seg.getAttr("action"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $text=`);this.genAttrStatement(seg.getAttr("text"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $fileName=`);this.genAttrStatement(seg.getAttr("fileName"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $waitBefore=`);this.genAttrStatement(seg.getAttr("waitBefore"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $waitAfter=`);this.genAttrStatement(seg.getAttr("waitAfter"));coder.packText(`;`);coder.newLine();
			coder.packText(`let $page=context[$pageVal];`);coder.newLine();
			coder.packText(`$waitBefore && (await sleep($waitBefore));`);coder.newLine();
			packExtraCodes(coder,seg,"PreCodes");
			coder.packText(`try{`);coder.indentMore();coder.newLine();
			{
				coder.packText(`if($action==="accept"){`);coder.indentMore();coder.newLine();
				{
					coder.packText(`await context.webRpa.acceptDialog($page,$text,$fileName?[$fileName]:null);`);coder.newLine();
				}
				coder.indentLess();coder.maybeNewLine();coder.packText(`}else{`);coder.indentMore();coder.newLine();
				{
					coder.packText(`awaitcontext.webRpa.dissmissDialog($page);`);coder.newLine();
				}
				coder.indentLess();coder.maybeNewLine();coder.packText(`}`);coder.newLine();
				coder.packText(`$waitAfter && (await sleep($waitAfter))`);coder.newLine();
			}
			coder.indentLess();coder.maybeNewLine();
			coder.packText(`}catch(error){`);coder.indentMore();coder.newLine();
			{
				packErrorSegCode(coder,seg,exportDebug);
			}
			coder.indentLess();coder.maybeNewLine();
			coder.packText(`}`);coder.newLine();
			packExtraCodes(coder,seg,"PostCodes");
			packResult(coder,seg,seg.outlet,"result");
		}
		coder.indentLess();coder.maybeNewLine();
		coder.packText(`};`);
		coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		coder.newLine();
	};
}



