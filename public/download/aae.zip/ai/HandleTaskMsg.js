//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import pathLib from "/@path";
import inherits from "/@inherits";
import Base64 from "/@tabos/utils/base64.js";
import {trimJSON} from "/@aichat/utils.js";
/*#{1I36A305L0MoreImports*/
import {AABots} from "../AABots.js";
/*}#1I36A305L0MoreImports*/
const agentURL=(new URL(import.meta.url)).pathname;
const basePath=pathLib.dirname(agentURL);
const $ln=VFACT.lanCode||"EN";
const argsTemplate={
	properties:{
		"hostBot":{
			"name":"hostBot","type":"auto",
			"defaultValue":"",
			"desc":"",
		},
		"taskMsg":{
			"name":"taskMsg","type":"auto",
			"defaultValue":"",
			"desc":"",
		}
	},
	/*#{1I36A305L0ArgsView*/
	/*}#1I36A305L0ArgsView*/
};

/*#{1I36A305L0StartDoc*/
/*}#1I36A305L0StartDoc*/
//----------------------------------------------------------------------------
let HandleTaskMsg=async function(session){
	let hostBot,taskMsg;
	let context,globalContext;
	let self;
	let SwitchMsg,CheckRequest,AccpetWork,HandleReject,HandleFinish,HandleFail,HandleGiveUp,ErrorAction,RejectWork,TipAccept,TipReject;
	let aaBots=AABots.getAppBots();
	
	/*#{1I36A305L0LocalVals*/
	/*}#1I36A305L0LocalVals*/
	
	function parseAgentArgs(input){
		if(typeof(input)=='object'){
			hostBot=input.hostBot;
			taskMsg=input.taskMsg;
		}else{
			hostBot=undefined;
			taskMsg=undefined;
		}
		/*#{1I36A305L0ParseArgs*/
		/*}#1I36A305L0ParseArgs*/
	}
	
	/*#{1I36A305L0PreContext*/
	/*}#1I36A305L0PreContext*/
	globalContext=session.globalContext;
	context={};
	context=VFACT.flexState(context);
	/*#{1I36A305L0PostContext*/
	/*}#1I36A305L0PostContext*/
	let agent,segs={};
	segs["SwitchMsg"]=SwitchMsg=async function(input){//:1I36A3VN00
		let result=input;
		if(taskMsg.content.action==="Request"){
			return {seg:CheckRequest,result:(input),preSeg:"1I36A3VN00",outlet:"1I36A5VB00"};
		}
		if(taskMsg.content.action==="Reject"){
			return {seg:HandleReject,result:(input),preSeg:"1I36A3VN00",outlet:"1I36A6MMC0"};
		}
		if(taskMsg.content.action==="Finish"){
			return {seg:HandleFinish,result:(input),preSeg:"1I36A3VN00",outlet:"1I36A8KP60"};
		}
		if(taskMsg.content.action==="Fail"){
			return {seg:HandleFail,result:(input),preSeg:"1I36A3VN00",outlet:"1I36AA7VL0"};
		}
		if(taskMsg.content.action==="GiveUp"){
			return {seg:HandleGiveUp,result:(input),preSeg:"1I36A3VN00",outlet:"1I36AB3ON0"};
		}
		return {seg:ErrorAction,result:(result),preSeg:"1I36A3VN00",outlet:"1I36A5VB20"};
	};
	SwitchMsg.jaxId="1I36A3VN00"
	SwitchMsg.url="SwitchMsg@"+agentURL
	
	segs["CheckRequest"]=CheckRequest=async function(input){//:1I37CSJLG0
		let result=input;
		/*#{1I37CSJLG0Start*/
		/*}#1I37CSJLG0Start*/
		if(0){
			return {seg:RejectWork,result:(input),preSeg:"1I37CSJLG0",outlet:"1I37CV4420"};
		}
		/*#{1I37CSJLG0Post*/
		/*}#1I37CSJLG0Post*/
		return {seg:AccpetWork,result:(result),preSeg:"1I37CSJLG0",outlet:"1I37CTDIK0"};
	};
	CheckRequest.jaxId="1I37CSJLG0"
	CheckRequest.url="CheckRequest@"+agentURL
	
	segs["AccpetWork"]=AccpetWork=async function(input){//:1I36AC50M0
		let result=input
		/*#{1I36AC50M0Code*/
		//TODO: Check if should reject:
		//Accept this work:
		await hostBot.acceptTaskWork(taskMsg.content.taskId,taskMsg.from,taskMsg.content.prompt);
		/*}#1I36AC50M0Code*/
		return {seg:TipAccept,result:(result),preSeg:"1I36AC50M0",outlet:"1I36AJ2B20"};
	};
	AccpetWork.jaxId="1I36AC50M0"
	AccpetWork.url="AccpetWork@"+agentURL
	
	segs["HandleReject"]=HandleReject=async function(input){//:1I36ACSGA0
		let result=input
		/*#{1I36ACSGA0Code*/
		/*}#1I36ACSGA0Code*/
		return {result:result};
	};
	HandleReject.jaxId="1I36ACSGA0"
	HandleReject.url="HandleReject@"+agentURL
	
	segs["HandleFinish"]=HandleFinish=async function(input){//:1I36ADR570
		let result=input
		/*#{1I36ADR570Code*/
		/*}#1I36ADR570Code*/
		return {result:result};
	};
	HandleFinish.jaxId="1I36ADR570"
	HandleFinish.url="HandleFinish@"+agentURL
	
	segs["HandleFail"]=HandleFail=async function(input){//:1I36AE69O0
		let result=input
		/*#{1I36AE69O0Code*/
		/*}#1I36AE69O0Code*/
		return {result:result};
	};
	HandleFail.jaxId="1I36AE69O0"
	HandleFail.url="HandleFail@"+agentURL
	
	segs["HandleGiveUp"]=HandleGiveUp=async function(input){//:1I36AF6IA0
		let result=input
		/*#{1I36AF6IA0Code*/
		/*}#1I36AF6IA0Code*/
		return {result:result};
	};
	HandleGiveUp.jaxId="1I36AF6IA0"
	HandleGiveUp.url="HandleGiveUp@"+agentURL
	
	segs["ErrorAction"]=ErrorAction=async function(input){//:1I36AFKPJ0
		let result=input
		/*#{1I36AFKPJ0Code*/
		/*}#1I36AFKPJ0Code*/
		return {result:result};
	};
	ErrorAction.jaxId="1I36AFKPJ0"
	ErrorAction.url="ErrorAction@"+agentURL
	
	segs["RejectWork"]=RejectWork=async function(input){//:1I37D12V30
		let result=input
		/*#{1I37D12V30Code*/
		/*}#1I37D12V30Code*/
		return {seg:TipReject,result:(result),preSeg:"1I37D12V30",outlet:"1I37D241D0"};
	};
	RejectWork.jaxId="1I37D12V30"
	RejectWork.url="RejectWork@"+agentURL
	
	segs["TipAccept"]=TipAccept=async function(input){//:1I37D1M900
		let result=input;
		let role="assistant";
		let content="Work accepted.";
		session.addChatText(role,content);
		return {result:result};
	};
	TipAccept.jaxId="1I37D1M900"
	TipAccept.url="TipAccept@"+agentURL
	
	segs["TipReject"]=TipReject=async function(input){//:1I37D27IN0
		let result=input;
		let role="assistant";
		let content="Work rejected";
		session.addChatText(role,content);
		return {result:result};
	};
	TipReject.jaxId="1I37D27IN0"
	TipReject.url="TipReject@"+agentURL
	
	agent={
		isAIAgent:true,
		session:session,
		name:"HandleTaskMsg",
		url:agentURL,
		autoStart:true,
		jaxId:"1I36A305L0",
		context:context,
		livingSeg:null,
		execChat:async function(input/*{hostBot,taskMsg}*/){
			let result;
			parseAgentArgs(input);
			/*#{1I36A305L0PreEntry*/
			/*}#1I36A305L0PreEntry*/
			result={seg:SwitchMsg,"input":input};
			/*#{1I36A305L0PostEntry*/
			/*}#1I36A305L0PostEntry*/
			return result;
		},
		/*#{1I36A305L0MoreAgentAttrs*/
		/*}#1I36A305L0MoreAgentAttrs*/
	};
	/*#{1I36A305L0PostAgent*/
	/*}#1I36A305L0PostAgent*/
	return agent;
};
/*#{1I36A305L0ExCodes*/
/*}#1I36A305L0ExCodes*/

export const ChatAPI=[{
	def:{
		name: "HandleTaskMsg",
		description: "这是一个AI智能体。",
		parameters:{
			type: "object",
			properties:{
				hostBot:{type:"auto",description:""},
				taskMsg:{type:"auto",description:""}
			}
		}
	},
	agent: HandleTaskMsg
}];

//:Export Edit-AddOn:
const DocAIAgentExporter=VFACT.classRegs.DocAIAgentExporter;
if(DocAIAgentExporter){
	const EditAttr=VFACT.classRegs.EditAttr;
	const EditAISeg=VFACT.classRegs.EditAISeg;
	const EditAISegOutlet=VFACT.classRegs.EditAISegOutlet;
	const SegObjShellAttr=EditAISeg.SegObjShellAttr;
	const SegOutletDef=EditAISegOutlet.SegOutletDef;
	const docAIAgentExporter=DocAIAgentExporter.prototype;
	const packExtraCodes=docAIAgentExporter.packExtraCodes;
	const packResult=docAIAgentExporter.packResult;
	const varNameRegex = /^[a-zA-Z_$][a-zA-Z0-9_$]*$/;
	
	EditAISeg.regDef({
		name:"HandleTaskMsg",showName:"HandleTaskMsg",icon:"agent.svg",catalog:["AI Call"],
		attrs:{
			...SegObjShellAttr,
			"hostBot":{name:"hostBot",type:"auto",key:1,fixed:1,initVal:""},
			"taskMsg":{name:"taskMsg",type:"auto",key:1,fixed:1,initVal:""},
			"outlet":{name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc"}
		},
		listHint:["id","hostBot","taskMsg","codes","desc"],
		desc:"这是一个AI智能体。"
	});
	
	DocAIAgentExporter.segTypeExporters["HandleTaskMsg"]=
	function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let exportDebug=this.isExportDebug();
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();coder.newLine();
		{
			coder.packText(`let result,args={};`);coder.newLine();
			coder.packText("args['hostBot']=");this.genAttrStatement(seg.getAttr("hostBot"));coder.packText(";");coder.newLine();
			coder.packText("args['taskMsg']=");this.genAttrStatement(seg.getAttr("taskMsg"));coder.packText(";");coder.newLine();
			this.packExtraCodes(coder,seg,"PreCodes");
			coder.packText(`result= await session.pipeChat("/~/aae/ai/HandleTaskMsg.js",args,false);`);coder.newLine();
			this.packExtraCodes(coder,seg,"PostCodes");
			this.packResult(coder,seg,seg.outlet);
		}
		coder.indentLess();coder.maybeNewLine();
		coder.packText(`};`);coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		coder.newLine();
	};
}
/*#{1I36A305L0PostDoc*/
/*}#1I36A305L0PostDoc*/


export default HandleTaskMsg;
export{HandleTaskMsg};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DocAIAgent",
//	"jaxId": "1I36A305L0",
//	"attrs": {
//		"editObjs": {
//			"jaxId": "1I36A305L1",
//			"attrs": {
//				"HandleTaskMsg": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1I36A305L7",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1I36A305M0",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1I36A305M1",
//							"attrs": {}
//						},
//						"functions": {
//							"jaxId": "1I36A305M2",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false"
//					},
//					"mockups": {}
//				}
//			}
//		},
//		"agent": {
//			"jaxId": "1I36A305L2",
//			"attrs": {}
//		},
//		"entry": "",
//		"autoStart": "true",
//		"debug": "true",
//		"apiArgs": {
//			"jaxId": "1I36A305L3",
//			"attrs": {
//				"hostBot": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I37C45KB0",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				},
//				"taskMsg": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I36A3L0I0",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1I36A305L4",
//			"attrs": {
//				"aaBots": {
//					"type": "auto",
//					"valText": "#AABots.getAppBots()"
//				}
//			}
//		},
//		"context": {
//			"jaxId": "1I36A305L5",
//			"attrs": {}
//		},
//		"globalMockup": {
//			"jaxId": "1I36A305L6",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "aiseg",
//					"def": "brunch",
//					"jaxId": "1I36A3VN00",
//					"attrs": {
//						"id": "SwitchMsg",
//						"label": "New AI Seg",
//						"x": "95",
//						"y": "465",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I36A5VB40",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I36A5VB41",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I36A5VB20",
//							"attrs": {
//								"id": "Default",
//								"desc": "输出节点。",
//								"output": ""
//							},
//							"linkedSeg": "1I36AFKPJ0"
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I36A5VB00",
//									"attrs": {
//										"id": "NewReq",
//										"desc": "输出节点。",
//										"output": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I36A5VB42",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I36A5VB43",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#taskMsg.content.action===\"Request\""
//									},
//									"linkedSeg": "1I37CSJLG0"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I36A6MMC0",
//									"attrs": {
//										"id": "RejectReq",
//										"desc": "输出节点。",
//										"output": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I36AC0LQ0",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I36AC0LQ1",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#taskMsg.content.action===\"Reject\""
//									},
//									"linkedSeg": "1I36ACSGA0"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I36A8KP60",
//									"attrs": {
//										"id": "FinishReq",
//										"desc": "输出节点。",
//										"output": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I36AC0LQ2",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I36AC0LQ3",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#taskMsg.content.action===\"Finish\""
//									},
//									"linkedSeg": "1I36ADR570"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I36AA7VL0",
//									"attrs": {
//										"id": "FailReq",
//										"desc": "输出节点。",
//										"output": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I36AC0LQ4",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I36AC0LS0",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#taskMsg.content.action===\"Fail\""
//									},
//									"linkedSeg": "1I36AE69O0"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I36AB3ON0",
//									"attrs": {
//										"id": "GiveUpReq",
//										"desc": "输出节点。",
//										"output": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I36AC0LS1",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I36AC0LS2",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#taskMsg.content.action===\"GiveUp\""
//									},
//									"linkedSeg": "1I36AF6IA0"
//								}
//							]
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "brunch",
//					"jaxId": "1I37CSJLG0",
//					"attrs": {
//						"id": "CheckRequest",
//						"label": "New AI Seg",
//						"x": "390",
//						"y": "235",
//						"desc": "这是一个AISeg。",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I37CV4470",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I37CV4471",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I37CTDIK0",
//							"attrs": {
//								"id": "Default",
//								"desc": "输出节点。",
//								"output": ""
//							},
//							"linkedSeg": "1I36AC50M0"
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I37CV4420",
//									"attrs": {
//										"id": "Reject",
//										"desc": "输出节点。",
//										"output": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I37CV4472",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I37CV4473",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#0"
//									},
//									"linkedSeg": "1I37D12V30"
//								}
//							]
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I36AC50M0",
//					"attrs": {
//						"id": "AccpetWork",
//						"label": "New AI Seg",
//						"x": "650",
//						"y": "250",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I36AJ2B50",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I36AJ2B51",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I36AJ2B20",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I37D1M900"
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I36ACSGA0",
//					"attrs": {
//						"id": "HandleReject",
//						"label": "New AI Seg",
//						"x": "390",
//						"y": "325",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I36AJ2B52",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I36AJ2B53",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I36AJ2B21",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							}
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I36ADR570",
//					"attrs": {
//						"id": "HandleFinish",
//						"label": "New AI Seg",
//						"x": "390",
//						"y": "415",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I36AJ2B54",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I36AJ2B55",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I36AJ2B22",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							}
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I36AE69O0",
//					"attrs": {
//						"id": "HandleFail",
//						"label": "New AI Seg",
//						"x": "390",
//						"y": "505",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I36AJ2B56",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I36AJ2B57",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I36AJ2B23",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							}
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I36AF6IA0",
//					"attrs": {
//						"id": "HandleGiveUp",
//						"label": "New AI Seg",
//						"x": "390",
//						"y": "595",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I36AJ2B58",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I36AJ2B59",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I36AJ2B24",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							}
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I36AFKPJ0",
//					"attrs": {
//						"id": "ErrorAction",
//						"label": "New AI Seg",
//						"x": "390",
//						"y": "700",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I36AJ2B510",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I36AJ2B511",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I36AJ2B25",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							}
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I37D12V30",
//					"attrs": {
//						"id": "RejectWork",
//						"label": "New AI Seg",
//						"x": "650",
//						"y": "155",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I37D241J0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I37D241J1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I37D241D0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I37D27IN0"
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1I37D1M900",
//					"attrs": {
//						"id": "TipAccept",
//						"label": "New AI Seg",
//						"x": "890",
//						"y": "250",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "flag.svg",
//						"context": {
//							"jaxId": "1I37D241J2",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I37D241J3",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "Assistant",
//						"text": "Work accepted.",
//						"outlet": {
//							"jaxId": "1I37D241D1",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							}
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1I37D27IN0",
//					"attrs": {
//						"id": "TipReject",
//						"label": "New AI Seg",
//						"x": "890",
//						"y": "155",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "flag.svg",
//						"context": {
//							"jaxId": "1I37D2V6T0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I37D2V6T1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "Assistant",
//						"text": "Work rejected",
//						"outlet": {
//							"jaxId": "1I37D2V6M0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							}
//						}
//					}
//				}
//			]
//		},
//		"desc": "这是一个AI智能体。",
//		"exportAPI": "true",
//		"exportAddOn": "true",
//		"addOnOpts": ""
//	}
//}