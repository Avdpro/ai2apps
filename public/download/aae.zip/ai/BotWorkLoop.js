//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import pathLib from "/@path";
import inherits from "/@inherits";
import Base64 from "/@tabos/utils/base64.js";
import {trimJSON} from "/@aichat/utils.js";
/*#{1I36C3GLQ0MoreImports*/
import {AABotNode} from "../AABotNode.js";
import {AAFileLib} from "../AAFileLib.js";
/*}#1I36C3GLQ0MoreImports*/
const agentURL=(new URL(import.meta.url)).pathname;
const basePath=pathLib.dirname(agentURL);
const $ln=VFACT.lanCode||"EN";
const argsTemplate={
	properties:{
		"botId":{
			"name":"botId","type":"auto",
			"defaultValue":"",
			"desc":"",
		}
	},
	/*#{1I36C3GLQ0ArgsView*/
	/*}#1I36C3GLQ0ArgsView*/
};

/*#{1I36C3GLQ0StartDoc*/
/*}#1I36C3GLQ0StartDoc*/
//----------------------------------------------------------------------------
let BotWorkLoop=async function(session){
	let botId;
	let context,globalContext;
	let self;
	let TipStart,Start,GetTask,Wait,StartWork,DoTask,WrapWork,FailTask;
	let aaBotNode=AABotNode.getAppBotNode(false);;
	let hostBot=null;
	let taskWork=null;
	
	/*#{1I36C3GLQ0LocalVals*/
	async function getNextWork(){
		let task;
		do{
			task=await hostBot.getNextTaskWork();
			if(task){
				console.log("Got task:");
				console.log(task);
				break;
			}
			await sleep(3000);
		}while(!task);
		return task;
	}
	/*}#1I36C3GLQ0LocalVals*/
	
	function parseAgentArgs(input){
		if(typeof(input)=='object'){
			botId=input.botId;
		}else{
			botId=undefined;
		}
		/*#{1I36C3GLQ0ParseArgs*/
		/*}#1I36C3GLQ0ParseArgs*/
	}
	
	/*#{1I36C3GLQ0PreContext*/
	/*}#1I36C3GLQ0PreContext*/
	globalContext=session.globalContext;
	context={};
	context=VFACT.flexState(context);
	/*#{1I36C3GLQ0PostContext*/
	/*}#1I36C3GLQ0PostContext*/
	let agent,segs={};
	segs["TipStart"]=TipStart=async function(input){//:1I36C3NCA0
		let result=input;
		let role="assistant";
		let content="BotWorkLoop";
		session.addChatText(role,content);
		return {seg:Start,result:(result),preSeg:"1I36C3NCA0",outlet:"1I36C7OS40"};
	};
	TipStart.jaxId="1I36C3NCA0"
	TipStart.url="TipStart@"+agentURL
	
	segs["Start"]=Start=async function(input){//:1I37OKQAI0
		let result=input
		/*#{1I37OKQAI0Code*/
		if(!globalContext.fileLib){
			globalContext.fileLib=new AAFileLib();
		}
		await aaBotNode.syncBots();
		hostBot=aaBotNode.getBot(botId);
		/*}#1I37OKQAI0Code*/
		return {seg:GetTask,result:(result),preSeg:"1I37OKQAI0",outlet:"1I37OLA700"};
	};
	Start.jaxId="1I37OKQAI0"
	Start.url="Start@"+agentURL
	
	segs["GetTask"]=GetTask=async function(input){//:1I36C4F4E0
		let result=input;
		/*#{1I36C4F4E0Start*/
		let task;
		task=await getNextWork();
		/*}#1I36C4F4E0Start*/
		if(task){
			let output=task;
			/*#{1I36C7OS41Codes*/
			taskWork=task;
			/*}#1I36C7OS41Codes*/
			return {seg:WrapWork,result:(output),preSeg:"1I36C4F4E0",outlet:"1I36C7OS41"};
		}
		/*#{1I36C4F4E0Post*/
		/*}#1I36C4F4E0Post*/
		return {seg:Wait,result:(result),preSeg:"1I36C4F4E0",outlet:"1I36C7OS42"};
	};
	GetTask.jaxId="1I36C4F4E0"
	GetTask.url="GetTask@"+agentURL
	
	segs["Wait"]=Wait=async function(input){//:1I36C5LLC0
		let result=input;
		let time=1000;
		await sleep(time);
		return {seg:GetTask,result:(result),preSeg:"1I36C5LLC0",outlet:"1I36C7OS43"};
	};
	Wait.jaxId="1I36C5LLC0"
	Wait.url="Wait@"+agentURL
	
	segs["StartWork"]=StartWork=async function(input){//:1I36C78MA0
		let result=input
		/*#{1I36C78MA0Code*/
		await taskWork.start();
		session.addChatText("event",`Start work: ${taskWork.prompt}`);
		/*}#1I36C78MA0Code*/
		return {seg:DoTask,result:(result),preSeg:"1I36C78MA0",outlet:"1I36C7OS44"};
	};
	StartWork.jaxId="1I36C78MA0"
	StartWork.url="StartWork@"+agentURL
	
	segs["DoTask"]=DoTask=async function(input){//:1I36C9A610
		let result;
		let sourcePath=pathLib.joinTabOSURL(basePath,"./WrappedTaskWork.js");
		let arg={"hostBot":hostBot,"taskWork":taskWork,"progress":null};
		/*#{1I36C9A610Input*/
		/*}#1I36C9A610Input*/
		result= await session.pipeChat(sourcePath,arg,false);
		/*#{1I36C9A610Output*/
		console.log("[BotWorkLoop.js]-DoTask result:");
		console.log(result);
		/*}#1I36C9A610Output*/
		return {seg:GetTask,result:(result),preSeg:"1I36C9A610",outlet:"1I36CDHHE0"};
	};
	DoTask.jaxId="1I36C9A610"
	DoTask.url="DoTask@"+agentURL
	
	segs["WrapWork"]=WrapWork=async function(input){//:1I36CAHOD0
		let result=input;
		/*#{1I36CAHOD0Code*/
		false
		/*}#1I36CAHOD0Code*/
		return {seg:StartWork,result:(result),preSeg:"1I36CAHOD0",outlet:"1I36CDHHF1",catchSeg:FailTask,catchlet:"1I36CDHHF2"};
	};
	WrapWork.jaxId="1I36CAHOD0"
	WrapWork.url="WrapWork@"+agentURL
	
	segs["FailTask"]=FailTask=async function(input){//:1I36CB9GR0
		let result=input
		/*#{1I36CB9GR0Code*/
		//Fail this task:
		await taskWork.fail(""+(input?(input.reason||input):"Task error."));
		/*}#1I36CB9GR0Code*/
		return {seg:GetTask,result:(result),preSeg:"1I36CB9GR0",outlet:"1I36CDHHF3"};
	};
	FailTask.jaxId="1I36CB9GR0"
	FailTask.url="FailTask@"+agentURL
	
	agent={
		isAIAgent:true,
		session:session,
		name:"BotWorkLoop",
		url:agentURL,
		autoStart:true,
		jaxId:"1I36C3GLQ0",
		context:context,
		livingSeg:null,
		execChat:async function(input/*{botId}*/){
			let result;
			parseAgentArgs(input);
			/*#{1I36C3GLQ0PreEntry*/
			/*}#1I36C3GLQ0PreEntry*/
			result={seg:TipStart,"input":input};
			/*#{1I36C3GLQ0PostEntry*/
			/*}#1I36C3GLQ0PostEntry*/
			return result;
		},
		/*#{1I36C3GLQ0MoreAgentAttrs*/
		/*}#1I36C3GLQ0MoreAgentAttrs*/
	};
	/*#{1I36C3GLQ0PostAgent*/
	/*}#1I36C3GLQ0PostAgent*/
	return agent;
};
/*#{1I36C3GLQ0ExCodes*/
/*}#1I36C3GLQ0ExCodes*/

/*#{1I36C3GLQ0PostDoc*/
/*}#1I36C3GLQ0PostDoc*/


export default BotWorkLoop;
export{BotWorkLoop};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DocAIAgent",
//	"jaxId": "1I36C3GLQ0",
//	"attrs": {
//		"editObjs": {
//			"jaxId": "1I36C3GLR0",
//			"attrs": {
//				"BotWorkLoop": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1I36C3GLR6",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1I36C3GLR7",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1I36C3GLR8",
//							"attrs": {}
//						},
//						"functions": {
//							"jaxId": "1I36C3GLR9",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false"
//					},
//					"mockups": {}
//				}
//			}
//		},
//		"agent": {
//			"jaxId": "1I36C3GLR1",
//			"attrs": {}
//		},
//		"entry": "TipStart",
//		"autoStart": "true",
//		"debug": "true",
//		"apiArgs": {
//			"jaxId": "1I36C3GLR2",
//			"attrs": {
//				"botId": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I37OISOJ0",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1I36C3GLR3",
//			"attrs": {
//				"aaBotNode": {
//					"type": "auto",
//					"valText": "#AABotNode.getAppBotNode(false);"
//				},
//				"hostBot": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"taskWork": {
//					"type": "auto",
//					"valText": "null"
//				}
//			}
//		},
//		"context": {
//			"jaxId": "1I36C3GLR4",
//			"attrs": {}
//		},
//		"globalMockup": {
//			"jaxId": "1I36C3GLR5",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1I36C3NCA0",
//					"attrs": {
//						"id": "TipStart",
//						"label": "New AI Seg",
//						"x": "65",
//						"y": "295",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I36C7OS70",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I36C7OS71",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "Assistant",
//						"text": "BotWorkLoop",
//						"outlet": {
//							"jaxId": "1I36C7OS40",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I37OKQAI0"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I37OKQAI0",
//					"attrs": {
//						"id": "Start",
//						"label": "New AI Seg",
//						"x": "275",
//						"y": "295",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I37OLA790",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I37OLA791",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I37OLA700",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I36C4F4E0"
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "brunch",
//					"jaxId": "1I36C4F4E0",
//					"attrs": {
//						"id": "GetTask",
//						"label": "New AI Seg",
//						"x": "495",
//						"y": "295",
//						"desc": "这是一个AISeg。",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I36C7OS72",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I36C7OS73",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I36C7OS42",
//							"attrs": {
//								"id": "Default",
//								"desc": "输出节点。",
//								"output": ""
//							},
//							"linkedSeg": "1I36C5LLC0"
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I36C7OS41",
//									"attrs": {
//										"id": "FindTask",
//										"desc": "输出节点。",
//										"output": "#task",
//										"codes": "true",
//										"context": {
//											"jaxId": "1I36C7OS74",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I36C7OS75",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#task"
//									},
//									"linkedSeg": "1I36CAHOD0"
//								}
//							]
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "sleep",
//					"jaxId": "1I36C5LLC0",
//					"attrs": {
//						"id": "Wait",
//						"label": "New AI Seg",
//						"x": "720",
//						"y": "365",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I36C7OS76",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I36C7OS77",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"time": "1000",
//						"outlet": {
//							"jaxId": "1I36C7OS43",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I36C66OK0"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I36C66OK0",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "825",
//						"y": "440",
//						"outlet": {
//							"jaxId": "1I36C7OS78",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I36C69N70"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I36C69N70",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "525",
//						"y": "440",
//						"outlet": {
//							"jaxId": "1I36C7OS79",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I36C4F4E0"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I36C78MA0",
//					"attrs": {
//						"id": "StartWork",
//						"label": "New AI Seg",
//						"x": "950",
//						"y": "265",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I36C7OS710",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I36C7OS711",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I36C7OS44",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I36C9A610"
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "aiBot",
//					"jaxId": "1I36C9A610",
//					"attrs": {
//						"id": "DoTask",
//						"label": "New AI Seg",
//						"x": "1175",
//						"y": "265",
//						"desc": "调用其它AI Agent，把调用的结果作为输出",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I36CDHHI0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I36CDHHI1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"source": "ai/WrappedTaskWork.js",
//						"argument": "{\"hostBot\":\"#hostBot\",\"taskWork\":\"#taskWork\",\"progress\":\"#null\"}",
//						"secret": "false",
//						"outlet": {
//							"jaxId": "1I36CDHHE0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I36CCASP0"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "tryCatch",
//					"jaxId": "1I36CAHOD0",
//					"attrs": {
//						"id": "WrapWork",
//						"label": "New AI Seg",
//						"x": "720",
//						"y": "280",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I36CDHHI4",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I36CDHHI5",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I36CDHHF1",
//							"attrs": {
//								"id": "Try",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I36C78MA0"
//						},
//						"catchlet": {
//							"jaxId": "1I36CDHHF2",
//							"attrs": {
//								"id": "Catch",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I36CB9GR0"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I36CB9GR0",
//					"attrs": {
//						"id": "FailTask",
//						"label": "New AI Seg",
//						"x": "955",
//						"y": "365",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I36CDHHI6",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I36CDHHI7",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I36CDHHF3",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I36CBLSU0"
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I36CBLSU0",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "1085",
//						"y": "440",
//						"outlet": {
//							"jaxId": "1I36CDHHI8",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I36C66OK0"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I36CCASP0",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "1300",
//						"y": "440",
//						"outlet": {
//							"jaxId": "1I36CDHHI9",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I36CBLSU0"
//						},
//						"dir": "R2L"
//					}
//				}
//			]
//		},
//		"desc": "这是一个AI智能体。",
//		"exportAPI": "false",
//		"exportAddOn": "false",
//		"addOnOpts": ""
//	}
//}