//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import pathLib from "/@path";
import inherits from "/@inherits";
import Base64 from "/@tabos/utils/base64.js";
import {trimJSON} from "/@aichat/utils.js";
/*#{1I2P4LDQJ0MoreImports*/
import {AAFileLib} from "../AAFileLib.js";
import {AABotNode} from "../AABotNode.js";
/*}#1I2P4LDQJ0MoreImports*/
const agentURL=(new URL(import.meta.url)).pathname;
const basePath=pathLib.dirname(agentURL);
const $ln=VFACT.lanCode||"EN";
const argsTemplate={
	properties:{
		"botId":{
			"name":"botId","type":"auto",
			"defaultValue":"",
			"desc":"",
		},
		"inDebug":{
			"name":"inDebug","type":"bool",
			"defaultValue":true,
			"desc":"",
		}
	},
	/*#{1I2P4LDQJ0ArgsView*/
	/*}#1I2P4LDQJ0ArgsView*/
};

/*#{1I2P4LDQJ0StartDoc*/
/*}#1I2P4LDQJ0StartDoc*/
//----------------------------------------------------------------------------
let BotMessageLoop=async function(session){
	let botId,inDebug;
	let context,globalContext;
	let self;
	let TipStart,Start,GetMessage,ShowMessage,MsgType,HandleTask,HandleMeeting,HandleCmd,TipNoType,HandleChat,MarkHandled,ShowPic,HandleReply,OpenFile;
	let aaBotNode=null;
	let hostBot=null;
	let msgLength=0;
	let newMessages=[];
	let orgChatMsg=null;
	
	/*#{1I2P4LDQJ0LocalVals*/
	async function getNewMessage(){
		let msg;
		while(!newMessages.length){
			await sleep(100);
		}
		return newMessages.shift();
	}
	/*}#1I2P4LDQJ0LocalVals*/
	
	function parseAgentArgs(input){
		if(typeof(input)=='object'){
			botId=input.botId;
			inDebug=input.inDebug;
		}else{
			botId=undefined;
			inDebug=undefined;
		}
		/*#{1I2P4LDQJ0ParseArgs*/
		botId=botId||"BOT_MASTER";
		/*}#1I2P4LDQJ0ParseArgs*/
	}
	
	/*#{1I2P4LDQJ0PreContext*/
	/*}#1I2P4LDQJ0PreContext*/
	globalContext=session.globalContext;
	context={
		botsIndex: null,
		curMessage: null,
		/*#{1I2P4LDQK4ExCtxAttrs*/
		/*}#1I2P4LDQK4ExCtxAttrs*/
	};
	context=VFACT.flexState(context);
	/*#{1I2P4LDQJ0PostContext*/
	/*}#1I2P4LDQJ0PostContext*/
	let agent,segs={};
	segs["TipStart"]=TipStart=async function(input){//:1I2P4LNOR0
		let result=input;
		let role="assistant";
		let content="Bot loop start";
		session.addChatText(role,content);
		return {seg:Start,result:(result),preSeg:"1I2P4LNOR0",outlet:"1I2P52DVQ0"};
	};
	TipStart.jaxId="1I2P4LNOR0"
	TipStart.url="TipStart@"+agentURL
	
	segs["Start"]=Start=async function(input){//:1I2P7JAQL0
		let result=input
		/*#{1I2P7JAQL0Code*/
		let num;
		if(!globalContext.fileLib){
			globalContext.fileLib=new AAFileLib();
		}
		aaBotNode=AABotNode.getAppBotNode(!!inDebug);
		await aaBotNode.syncBots();
		hostBot=await aaBotNode.getHostBot(botId);
		await hostBot.startBotClient(session);
		await hostBot.startMessageClient();
		context.botsIndex=await aaBotNode.getBotsIndex();
		/*}#1I2P7JAQL0Code*/
		return {seg:GetMessage,result:(result),preSeg:"1I2P7JAQL0",outlet:"1I2P7JVOT0"};
	};
	Start.jaxId="1I2P7JAQL0"
	Start.url="Start@"+agentURL
	
	segs["GetMessage"]=GetMessage=async function(input){//:1I2P4M9M90
		let result=input
		/*#{1I2P4M9M90Code*/
		let msgVO;
		context.curMessage=null;
		do{
			console.log("BotMessageLoop.js: Asking new message...");
			result=msgVO=await hostBot.getNewMessage();
			if(result){
				console.log("BotMessageLoop.js: Got new message:");
				console.log(msgVO);
				break;
			}
			console.log("BotMessageLoop.js: Got null message, will retry later.");
			await sleep(3000);
		}while(!result);
		context.curMessage=msgVO;
		console.log("[BotMessageLoop] Message: ");
		console.log(msgVO);
		/*}#1I2P4M9M90Code*/
		return {seg:ShowMessage,result:(result),preSeg:"1I2P4M9M90",outlet:"1I2P52DVQ1"};
	};
	GetMessage.jaxId="1I2P4M9M90"
	GetMessage.url="GetMessage@"+agentURL
	
	segs["ShowMessage"]=ShowMessage=async function(input){//:1I79MH7LM0
		let result=input
		/*#{1I79MH7LM0Code*/
		let ui;
		ui=session.ui;
		if(ui.addBotMessage){
			ui.addBotMessage(input);
		}else{
			let role="assistant";
			let content=`\`\`\`\n${JSON.stringify(input,null,"\t")}\n\`\`\``;
			session.addChatText(role,content);
		}
		/*}#1I79MH7LM0Code*/
		return {seg:MsgType,result:(result),preSeg:"1I79MH7LM0",outlet:"1I79MHJD80"};
	};
	ShowMessage.jaxId="1I79MH7LM0"
	ShowMessage.url="ShowMessage@"+agentURL
	
	segs["MsgType"]=MsgType=async function(input){//:1I2P4SVV00
		let result=input;
		if(input.from===botId && input.to!==botId){
			return {seg:GetMessage,result:(input),preSeg:"1I2P4SVV00",outlet:"1I2RJUC460"};
		}
		if(input.type==="COMMAND"){
			return {seg:HandleCmd,result:(input),preSeg:"1I2P4SVV00",outlet:"1I2P58G2J0"};
		}
		if((input.type==="User")||(input.type==="Chat")){
			let output=input.content;
			/*#{1I2P52DVR3Codes*/
			orgChatMsg=input;
			/*}#1I2P52DVR3Codes*/
			return {seg:HandleChat,result:(output),preSeg:"1I2P4SVV00",outlet:"1I2P52DVR3"};
		}
		if(input.type==="Task"){
			let output=input;
			return {seg:HandleTask,result:(output),preSeg:"1I2P4SVV00",outlet:"1I2P4TUOJ0"};
		}
		if(input.type==="MEETING"){
			return {seg:HandleMeeting,result:(input),preSeg:"1I2P4SVV00",outlet:"1I2P4U9AO0"};
		}
		if(input.type==="ReplyAsk"){
			return {seg:HandleReply,result:(input),preSeg:"1I2P4SVV00",outlet:"1I5T1NOE50"};
		}
		return {seg:TipNoType,result:(result),preSeg:"1I2P4SVV00",outlet:"1I2P52DVR4"};
	};
	MsgType.jaxId="1I2P4SVV00"
	MsgType.url="MsgType@"+agentURL
	
	segs["HandleTask"]=HandleTask=async function(input){//:1I2P54N450
		let result;
		let sourcePath=pathLib.joinTabOSURL(basePath,"./BotHandleTask.js");
		let arg={"hostBot":hostBot,"taskMsg":input};
		result= await session.pipeChat(sourcePath,arg,false);
		return {seg:MarkHandled,result:(result),preSeg:"1I2P54N450",outlet:"1I2P5I3CT1"};
	};
	HandleTask.jaxId="1I2P54N450"
	HandleTask.url="HandleTask@"+agentURL
	
	segs["HandleMeeting"]=HandleMeeting=async function(input){//:1I2P57DC80
		let result;
		let sourcePath=pathLib.joinTabOSURL(basePath,"");
		let arg={};
		result= await session.pipeChat(sourcePath,arg,false);
		return {seg:MarkHandled,result:(result),preSeg:"1I2P57DC80",outlet:"1I2P5I3CT3"};
	};
	HandleMeeting.jaxId="1I2P57DC80"
	HandleMeeting.url="HandleMeeting@"+agentURL
	
	segs["HandleCmd"]=HandleCmd=async function(input){//:1I2P5B0BN0
		let result;
		let sourcePath=pathLib.joinTabOSURL(basePath,"");
		let arg={};
		result= await session.pipeChat(sourcePath,arg,false);
		return {seg:MarkHandled,result:(result),preSeg:"1I2P5B0BN0",outlet:"1I2P5I3CT4"};
	};
	HandleCmd.jaxId="1I2P5B0BN0"
	HandleCmd.url="HandleCmd@"+agentURL
	
	segs["TipNoType"]=TipNoType=async function(input){//:1I2P5BK0A0
		let result=input;
		let role="assistant";
		let content=input;
		session.addChatText(role,content);
		return {seg:MarkHandled,result:(result),preSeg:"1I2P5BK0A0",outlet:"1I2P5I3CT5"};
	};
	TipNoType.jaxId="1I2P5BK0A0"
	TipNoType.url="TipNoType@"+agentURL
	
	segs["HandleChat"]=HandleChat=async function(input){//:1I3GCC2LH0
		let result;
		let sourcePath=pathLib.joinTabOSURL(basePath,"./WrappedChatWork.js");
		let arg={"botId":botId,"chatMsg":orgChatMsg};
		result= await session.pipeChat(sourcePath,arg,false);
		return {seg:MarkHandled,result:(result),preSeg:"1I3GCC2LH0",outlet:"1I3GCDC700"};
	};
	HandleChat.jaxId="1I3GCC2LH0"
	HandleChat.url="HandleChat@"+agentURL
	
	segs["MarkHandled"]=MarkHandled=async function(input){//:1I7GVQ7UV0
		let result=input
		/*#{1I7GVQ7UV0Code*/
		if(context.curMessage){
			await hostBot.handleMessage(context.curMessage.id);
		}
		/*}#1I7GVQ7UV0Code*/
		return {seg:GetMessage,result:(result),preSeg:"1I7GVQ7UV0",outlet:"1I7GVSU350"};
	};
	MarkHandled.jaxId="1I7GVQ7UV0"
	MarkHandled.url="MarkHandled@"+agentURL
	
	segs["ShowPic"]=ShowPic=async function(input){//:1I5LFRC6O0
		let result=input;
		let role="assistant";
		let content=input.path;
		session.addChatText(role,content,{image:input.url});
		return {result:result};
	};
	ShowPic.jaxId="1I5LFRC6O0"
	ShowPic.url="ShowPic@"+agentURL
	
	segs["HandleReply"]=HandleReply=async function(input){//:1I5UV2C7F0
		let result=input
		/*#{1I5UV2C7F0Code*/
		/*}#1I5UV2C7F0Code*/
		return {seg:MarkHandled,result:(result),preSeg:"1I5UV2C7F0",outlet:"1I5V3GLNA0"};
	};
	HandleReply.jaxId="1I5UV2C7F0"
	HandleReply.url="HandleReply@"+agentURL
	
	segs["OpenFile"]=OpenFile=async function(input){//:1I88Q5L0R0
		let prompt=("Please confirm")||input;
		let resultText="";
		let fileData=null;
		let enc=null;
		let ext=null;
		let fileSys="native";
		let result="";
		let path=("");
		let filter=("");
		[resultText,result]=await session.askUserRaw({type:"input",prompt:prompt,text:"",path:path,file:fileSys,filter:filter,});
		if(!result && resultText){
			result=resultText;
		}else if(resultText && result){
			result=session.arrayBufferToDataURL(resultText,result);
		}
		return {result:result};
	};
	OpenFile.jaxId="1I88Q5L0R0"
	OpenFile.url="OpenFile@"+agentURL
	
	agent={
		isAIAgent:true,
		session:session,
		name:"BotMessageLoop",
		url:agentURL,
		autoStart:true,
		jaxId:"1I2P4LDQJ0",
		context:context,
		livingSeg:null,
		execChat:async function(input/*{botId,inDebug}*/){
			let result;
			parseAgentArgs(input);
			/*#{1I2P4LDQJ0PreEntry*/
			/*}#1I2P4LDQJ0PreEntry*/
			result={seg:TipStart,"input":input};
			/*#{1I2P4LDQJ0PostEntry*/
			/*}#1I2P4LDQJ0PostEntry*/
			return result;
		},
		/*#{1I2P4LDQJ0MoreAgentAttrs*/
		/*}#1I2P4LDQJ0MoreAgentAttrs*/
	};
	/*#{1I2P4LDQJ0PostAgent*/
	/*}#1I2P4LDQJ0PostAgent*/
	return agent;
};
/*#{1I2P4LDQJ0ExCodes*/
/*}#1I2P4LDQJ0ExCodes*/

export const ChatAPI=[{
	def:{
		name: "BotMessageLoop",
		description: "这是一个AI智能体。",
		parameters:{
			type: "object",
			properties:{
				botId:{type:"auto",description:""},
				inDebug:{type:"bool",description:""}
			}
		}
	},
	agent: BotMessageLoop
}];

//:Export Edit-AddOn:
const DocAIAgentExporter=VFACT.classRegs.DocAIAgentExporter;
if(DocAIAgentExporter){
	const EditAttr=VFACT.classRegs.EditAttr;
	const EditAISeg=VFACT.classRegs.EditAISeg;
	const EditAISegOutlet=VFACT.classRegs.EditAISegOutlet;
	const SegObjShellAttr=EditAISeg.SegObjShellAttr;
	const SegOutletDef=EditAISegOutlet.SegOutletDef;
	const docAIAgentExporter=DocAIAgentExporter.prototype;
	const packExtraCodes=docAIAgentExporter.packExtraCodes;
	const packResult=docAIAgentExporter.packResult;
	const varNameRegex = /^[a-zA-Z_$][a-zA-Z0-9_$]*$/;
	
	EditAISeg.regDef({
		name:"BotMessageLoop",showName:"BotMessageLoop",icon:"agent.svg",catalog:["AI Call"],
		attrs:{
			...SegObjShellAttr,
			"botId":{name:"botId",type:"auto",key:1,fixed:1,initVal:""},
			"inDebug":{name:"inDebug",type:"bool",key:1,fixed:1,initVal:true},
			"outlet":{name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc"}
		},
		listHint:["id","botId","inDebug","codes","desc"],
		desc:"这是一个AI智能体。"
	});
	
	DocAIAgentExporter.segTypeExporters["BotMessageLoop"]=
	function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let exportDebug=this.isExportDebug();
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();coder.newLine();
		{
			coder.packText(`let result,args={};`);coder.newLine();
			coder.packText("args['botId']=");this.genAttrStatement(seg.getAttr("botId"));coder.packText(";");coder.newLine();
			coder.packText("args['inDebug']=");this.genAttrStatement(seg.getAttr("inDebug"));coder.packText(";");coder.newLine();
			this.packExtraCodes(coder,seg,"PreCodes");
			coder.packText(`result= await session.pipeChat("/~/aae/ai/BotMessageLoop.js",args,false);`);coder.newLine();
			this.packExtraCodes(coder,seg,"PostCodes");
			this.packResult(coder,seg,seg.outlet);
		}
		coder.indentLess();coder.maybeNewLine();
		coder.packText(`};`);coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		coder.newLine();
	};
}
/*#{1I2P4LDQJ0PostDoc*/
/*}#1I2P4LDQJ0PostDoc*/


export default BotMessageLoop;
export{BotMessageLoop};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DocAIAgent",
//	"jaxId": "1I2P4LDQJ0",
//	"attrs": {
//		"editObjs": {
//			"jaxId": "1I2P4LDQK0",
//			"attrs": {
//				"BotMessageLoop": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1I2P4LDQK6",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1I2P4LDQK7",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1I2P4LDQK8",
//							"attrs": {}
//						},
//						"functions": {
//							"jaxId": "1I2P4LDQK9",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false"
//					},
//					"mockups": {}
//				}
//			}
//		},
//		"agent": {
//			"jaxId": "1I2P4LDQK1",
//			"attrs": {}
//		},
//		"entry": "",
//		"autoStart": "true",
//		"debug": "true",
//		"apiArgs": {
//			"jaxId": "1I2P4LDQK2",
//			"attrs": {
//				"botId": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I2P7LJV90",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				},
//				"inDebug": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I5VQFTP50",
//					"attrs": {
//						"type": "Boolean",
//						"mockup": "true",
//						"desc": ""
//					}
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1I2P4LDQK3",
//			"attrs": {
//				"aaBotNode": {
//					"type": "auto",
//					"valText": "#null"
//				},
//				"hostBot": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"msgLength": {
//					"type": "int",
//					"valText": "0"
//				},
//				"newMessages": {
//					"type": "auto",
//					"valText": "#[]"
//				},
//				"orgChatMsg": {
//					"type": "auto",
//					"valText": "null"
//				}
//			}
//		},
//		"context": {
//			"jaxId": "1I2P4LDQK4",
//			"attrs": {
//				"botsIndex": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I339NAB90",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "null",
//						"desc": ""
//					}
//				},
//				"curMessage": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I7GVVBUQ0",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "#null",
//						"desc": ""
//					}
//				}
//			}
//		},
//		"globalMockup": {
//			"jaxId": "1I2P4LDQK5",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1I2P4LNOR0",
//					"attrs": {
//						"id": "TipStart",
//						"label": "New AI Seg",
//						"x": "75",
//						"y": "485",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I2P52DVV0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I2P52DVV1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "Assistant",
//						"text": "Bot loop start",
//						"outlet": {
//							"jaxId": "1I2P52DVQ0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I2P7JAQL0"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I2P7JAQL0",
//					"attrs": {
//						"id": "Start",
//						"label": "New AI Seg",
//						"x": "325",
//						"y": "485",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I2P7JVP20",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I2P7JVP21",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I2P7JVOT0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I2P4M9M90"
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I2P4M9M90",
//					"attrs": {
//						"id": "GetMessage",
//						"label": "New AI Seg",
//						"x": "555",
//						"y": "485",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I2P52DVV2",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I2P52DVV3",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I2P52DVQ1",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I79MH7LM0"
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I79MH7LM0",
//					"attrs": {
//						"id": "ShowMessage",
//						"label": "New AI Seg",
//						"x": "805",
//						"y": "540",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I79MHJDD0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I79MHJDD1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I79MHJD80",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I2P4SVV00"
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "brunch",
//					"jaxId": "1I2P4SVV00",
//					"attrs": {
//						"id": "MsgType",
//						"label": "New AI Seg",
//						"x": "1055",
//						"y": "540",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I2P52DVV12",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I2P52DVV13",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I2P52DVR4",
//							"attrs": {
//								"id": "Default",
//								"desc": "输出节点。",
//								"output": ""
//							},
//							"linkedSeg": "1I2P5BK0A0"
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I2RJUC460",
//									"attrs": {
//										"id": "Host",
//										"desc": "输出节点。",
//										"output": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I2RJUC4D0",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I2RJUC4D1",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#input.from===botId && input.to!==botId"
//									},
//									"linkedSeg": "1I2RJTUL40"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I2P58G2J0",
//									"attrs": {
//										"id": "Command",
//										"desc": "输出节点。",
//										"output": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I2P5I3D10",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I2P5I3D11",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#input.type===\"COMMAND\""
//									},
//									"linkedSeg": "1I2P5B0BN0"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I2P52DVR3",
//									"attrs": {
//										"id": "Chat",
//										"desc": "输出节点。",
//										"output": "#input.content",
//										"codes": "true",
//										"context": {
//											"jaxId": "1I2P52DVV14",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I2P52DVV15",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#(input.type===\"User\")||(input.type===\"Chat\")"
//									},
//									"linkedSeg": "1I3GCC2LH0"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I2P4TUOJ0",
//									"attrs": {
//										"id": "Task",
//										"desc": "输出节点。",
//										"output": "#input",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I2P52DVV16",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I2P52DVV17",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#input.type===\"Task\""
//									},
//									"linkedSeg": "1I2P54N450"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I2P4U9AO0",
//									"attrs": {
//										"id": "Meeting",
//										"desc": "输出节点。",
//										"output": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I2P52DVV18",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I2P52DVV19",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#input.type===\"MEETING\""
//									},
//									"linkedSeg": "1I2P57DC80"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I5T1NOE50",
//									"attrs": {
//										"id": "ReplyAsk",
//										"desc": "输出节点。",
//										"output": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I5T1R5CV0",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I5T1R5CV1",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#input.type===\"ReplyAsk\""
//									},
//									"linkedSeg": "1I5UV2C7F0"
//								}
//							]
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "aiBot",
//					"jaxId": "1I2P54N450",
//					"attrs": {
//						"id": "HandleTask",
//						"label": "New AI Seg",
//						"x": "1335",
//						"y": "560",
//						"desc": "调用其它AI Agent，把调用的结果作为输出",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I2P5I3D14",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I2P5I3D15",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"source": "ai/BotHandleTask.js",
//						"argument": "{\"hostBot\":\"#hostBot\",\"taskMsg\":\"#input\"}",
//						"secret": "false",
//						"outlet": {
//							"jaxId": "1I2P5I3CT1",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I7GVQ7UV0"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "aiBot",
//					"jaxId": "1I2P57DC80",
//					"attrs": {
//						"id": "HandleMeeting",
//						"label": "New AI Seg",
//						"x": "1330",
//						"y": "630",
//						"desc": "调用其它AI Agent，把调用的结果作为输出",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I2P5I3D18",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I2P5I3D19",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"source": "",
//						"argument": "#{}#>input",
//						"secret": "false",
//						"outlet": {
//							"jaxId": "1I2P5I3CT3",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I7GVQ7UV0"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "aiBot",
//					"jaxId": "1I2P5B0BN0",
//					"attrs": {
//						"id": "HandleCmd",
//						"label": "New AI Seg",
//						"x": "1335",
//						"y": "415",
//						"desc": "调用其它AI Agent，把调用的结果作为输出",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I2P5I3D110",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I2P5I3D111",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"source": "",
//						"argument": "#{}#>input",
//						"secret": "false",
//						"outlet": {
//							"jaxId": "1I2P5I3CT4",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I7GVQ7UV0"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1I2P5BK0A0",
//					"attrs": {
//						"id": "TipNoType",
//						"label": "New AI Seg",
//						"x": "1340",
//						"y": "770",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I2P5I3D112",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I2P5I3D113",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "Assistant",
//						"text": "#input",
//						"outlet": {
//							"jaxId": "1I2P5I3CT5",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I7GVQ7UV0"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I2P6PIO80",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "590",
//						"y": "335",
//						"outlet": {
//							"jaxId": "1I2P6SIH115",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I2P4M9M90"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I2RJTUL40",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "1210",
//						"y": "335",
//						"outlet": {
//							"jaxId": "1I2RJUC4D2",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I2P6PIO80"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "aiBot",
//					"jaxId": "1I3GCC2LH0",
//					"attrs": {
//						"id": "HandleChat",
//						"label": "New AI Seg",
//						"x": "1335",
//						"y": "485",
//						"desc": "调用其它AI Agent，把调用的结果作为输出",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I3GCDC730",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I3GCDC731",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"source": "ai/WrappedChatWork.js",
//						"argument": "{\"botId\":\"#botId\",\"chatMsg\":\"#orgChatMsg\"}",
//						"secret": "false",
//						"outlet": {
//							"jaxId": "1I3GCDC700",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I7GVQ7UV0"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I3GCNLQF0",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "1750",
//						"y": "330",
//						"outlet": {
//							"jaxId": "1I3GD19KO0",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I2RJTUL40"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I7GVQ7UV0",
//					"attrs": {
//						"id": "MarkHandled",
//						"label": "New AI Seg",
//						"x": "1590",
//						"y": "590",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I7GVSU3E0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I7GVSU3E1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I7GVSU350",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I3GCNLQF0"
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "image",
//					"jaxId": "1I5LFRC6O0",
//					"attrs": {
//						"id": "ShowPic",
//						"label": "New AI Seg",
//						"x": "325",
//						"y": "550",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I5LFSIA60",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I5LFSIA61",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"text": "#input.path",
//						"image": "#input.url",
//						"role": "Assistant",
//						"sizeLimit": "",
//						"format": "JEPG",
//						"outlet": {
//							"jaxId": "1I5LFSI9V0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							}
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I5UV2C7F0",
//					"attrs": {
//						"id": "HandleReply",
//						"label": "New AI Seg",
//						"x": "1335",
//						"y": "700",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I5V3GLNI0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I5V3GLNI1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I5V3GLNA0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I7GVQ7UV0"
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "askFile",
//					"jaxId": "1I88Q5L0R0",
//					"attrs": {
//						"id": "OpenFile",
//						"label": "New AI Seg",
//						"x": "325",
//						"y": "630",
//						"desc": "This is an AISeg.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I8B948S20",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I8B948S21",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"prompt": "Please confirm",
//						"path": "",
//						"fileSys": "naive",
//						"filter": "",
//						"read": "No",
//						"outlet": {
//							"jaxId": "1I88Q624A0",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							}
//						}
//					}
//				}
//			]
//		},
//		"desc": "这是一个AI智能体。",
//		"exportAPI": "true",
//		"exportAddOn": "true",
//		"addOnOpts": ""
//	}
//}