//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import pathLib from "/@path";
import inherits from "/@inherits";
import Base64 from "/@tabos/utils/base64.js";
import {trimJSON} from "/@aichat/utils.js";
/*#{1I1NRNU5U0MoreImports*/
/*}#1I1NRNU5U0MoreImports*/
const agentURL=(new URL(import.meta.url)).pathname;
const basePath=pathLib.dirname(agentURL);
const $ln=VFACT.lanCode||"EN";
/*#{1I1NRNU5U0StartDoc*/
/*}#1I1NRNU5U0StartDoc*/
//----------------------------------------------------------------------------
let DateTime=async function(session){
	let execInput;
	let context,globalContext;
	let self;
	let GetDate;
	/*#{1I1NRNU5U0LocalVals*/
	/*}#1I1NRNU5U0LocalVals*/
	
	/*#{1I1NRNU5U0PreContext*/
	/*}#1I1NRNU5U0PreContext*/
	globalContext=session.globalContext;
	context={};
	context=VFACT.flexState(context);
	/*#{1I1NRNU5U0PostContext*/
	/*}#1I1NRNU5U0PostContext*/
	let agent,segs={};
	segs["GetDate"]=GetDate=async function(input){//:1I1NRO2TA0
		let result=input
		/*#{1I1NRO2TA0Code*/
		result=(new Date()).toString();
		/*}#1I1NRO2TA0Code*/
		return {result:result};
	};
	GetDate.jaxId="1I1NRO2TA0"
	GetDate.url="GetDate@"+agentURL
	
	agent={
		isAIAgent:true,
		session:session,
		name:"DateTime",
		url:agentURL,
		autoStart:true,
		jaxId:"1I1NRNU5U0",
		context:context,
		livingSeg:null,
		execChat:async function(input){
			let result;
			execInput=input;
			/*#{1I1NRNU5U0PreEntry*/
			/*}#1I1NRNU5U0PreEntry*/
			result={seg:GetDate,"input":input};
			/*#{1I1NRNU5U0PostEntry*/
			/*}#1I1NRNU5U0PostEntry*/
			return result;
		},
		/*#{1I1NRNU5U0MoreAgentAttrs*/
		/*}#1I1NRNU5U0MoreAgentAttrs*/
	};
	/*#{1I1NRNU5U0PostAgent*/
	/*}#1I1NRNU5U0PostAgent*/
	return agent;
};
/*#{1I1NRNU5U0ExCodes*/
/*}#1I1NRNU5U0ExCodes*/

export const ChatAPI=[{
	def:{
		name: "AGT_DateTime",
		description: "这是获得当前时间和日期的API，调用后获得当前的日期/时间",
		parameters:{
			type: "object",
			properties:{
			}
		}
	},
	agent: DateTime
}];

//:Export Edit-AddOn:
const DocAIAgentExporter=VFACT.classRegs.DocAIAgentExporter;
if(DocAIAgentExporter){
	const EditAttr=VFACT.classRegs.EditAttr;
	const EditAISeg=VFACT.classRegs.EditAISeg;
	const EditAISegOutlet=VFACT.classRegs.EditAISegOutlet;
	const SegObjShellAttr=EditAISeg.SegObjShellAttr;
	const SegOutletDef=EditAISegOutlet.SegOutletDef;
	const docAIAgentExporter=DocAIAgentExporter.prototype;
	const packExtraCodes=docAIAgentExporter.packExtraCodes;
	const packResult=docAIAgentExporter.packResult;
	const varNameRegex = /^[a-zA-Z_$][a-zA-Z0-9_$]*$/;
	
	EditAISeg.regDef({
		name:"DateTime",showName:"DateTime",icon:"agent.svg",catalog:["AI Call"],
		attrs:{
			...SegObjShellAttr,
			"outlet":{name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc"}
		},
		listHint:["id","codes","desc"],
		desc:"这是获得当前时间和日期的API，调用后获得当前的日期/时间"
	});
	
	DocAIAgentExporter.segTypeExporters["DateTime"]=
	function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let exportDebug=this.isExportDebug();
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();coder.newLine();
		{
			coder.packText(`let result,args={};`);coder.newLine();
			this.packExtraCodes(coder,seg,"PreCodes");
			coder.packText(`result= await session.pipeChat("/~/aae/ai/DateTime.js",args,false);`);coder.newLine();
			this.packExtraCodes(coder,seg,"PostCodes");
			this.packResult(coder,seg,seg.outlet);
		}
		coder.indentLess();coder.maybeNewLine();
		coder.packText(`};`);coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		coder.newLine();
	};
}
/*#{1I1NRNU5U0PostDoc*/
/*}#1I1NRNU5U0PostDoc*/


export default DateTime;
export{DateTime};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DocAIAgent",
//	"jaxId": "1I1NRNU5U0",
//	"attrs": {
//		"editObjs": {
//			"jaxId": "1I1NRNU5U1",
//			"attrs": {
//				"DateTime": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1I1NRNU5V0",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1I1NRNU5V1",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1I1NRNU5V2",
//							"attrs": {}
//						},
//						"functions": {
//							"jaxId": "1I1NRNU5V3",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false"
//					},
//					"mockups": {}
//				}
//			}
//		},
//		"agent": {
//			"jaxId": "1I1NRNU5U2",
//			"attrs": {}
//		},
//		"entry": "",
//		"autoStart": "true",
//		"debug": "true",
//		"apiArgs": {
//			"jaxId": "1I1NRNU5U3",
//			"attrs": {}
//		},
//		"localVars": {
//			"jaxId": "1I1NRNU5U4",
//			"attrs": {}
//		},
//		"context": {
//			"jaxId": "1I1NRNU5U5",
//			"attrs": {}
//		},
//		"globalMockup": {
//			"jaxId": "1I1NRNU5U6",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I1NRO2TA0",
//					"attrs": {
//						"id": "GetDate",
//						"label": "New AI Seg",
//						"x": "130",
//						"y": "115",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I1NRPC3P0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1NRPC3P1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I1NRPC3O0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							}
//						},
//						"result": "#input"
//					}
//				}
//			]
//		},
//		"desc": "这是获得当前时间和日期的API，调用后获得当前的日期/时间",
//		"exportAPI": "true",
//		"exportAddOn": "true",
//		"addOnOpts": ""
//	}
//}