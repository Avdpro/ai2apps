//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import pathLib from "/@path";
import inherits from "/@inherits";
import Base64 from "/@tabos/utils/base64.js";
import {trimJSON} from "/@aichat/utils.js";
/*#{1I1U4I09F0MoreImports*/
import {tabFS} from "/@tabos";
import {AASkills,AASkillChain} from "/@aae/AASkills.js";
/*}#1I1U4I09F0MoreImports*/
const agentURL=(new URL(import.meta.url)).pathname;
const basePath=pathLib.dirname(agentURL);
const $ln=VFACT.lanCode||"EN";
const argsTemplate={
	properties:{
		"chainPath":{
			"name":"chainPath","type":"auto",
			"defaultValue":null,
			"desc":"",
		},
		"command":{
			"name":"command","type":"auto",
			"defaultValue":"",
			"desc":"",
		}
	},
	/*#{1I1U4I09F0ArgsView*/
	/*}#1I1U4I09F0ArgsView*/
};

/*#{1I1U4I09F0StartDoc*/
let topWindow;
topWindow=window;
while(topWindow && topWindow.parent && topWindow.parent!==topWindow){
	topWindow=topWindow.parent;
}
const topVFACT=topWindow.VFACT;
let tempDirPath;
//----------------------------------------------------------------------------
async function setupTempDir(){
	let baseName,dirPath,cnt;
	cnt=0;
	dirPath=baseName="/doc/Temp/TEMP_"+Date.now();
	do{
		if(!(await tabFS.isExist(dirPath))){
			break;
		}
		cnt+=1;
		dirPath=baseName+cnt;
	}while(1);
	await tabFS.newDir(dirPath);
	tempDirPath=dirPath;
	return dirPath;
};
async function clearTempDir(path){
	path=path||tempDirPath;
	await tabFS.del(path);
};
/*}#1I1U4I09F0StartDoc*/
//----------------------------------------------------------------------------
let RunSkillChain=async function(session){
	let chainPath,command;
	let context,globalContext;
	let self;
	let MakeEnv,RunStep,CheckStep,CallSkill,PickSkill,LogError,ShowSkill,RunSkill,ShowSkillResult,appendMessage,ShowFinish,ShowAbort,ShowReply,NextMenu,ResetMsg,AskNewCmd,AskMore,CloseChat,AskQuestion,StartTip,ShowError;
	/*#{1I1U4I09F0LocalVals*/
	/*}#1I1U4I09F0LocalVals*/
	
	function parseAgentArgs(input){
		if(typeof(input)=='object'){
			chainPath=input.chainPath;
			command=input.command;
		}else{
			chainPath=undefined;
			command=undefined;
		}
		/*#{1I1U4I09F0ParseArgs*/
		/*}#1I1U4I09F0ParseArgs*/
	}
	
	/*#{1I1U4I09F0PreContext*/
	/*}#1I1U4I09F0PreContext*/
	globalContext=session.globalContext;
	context={
		aaSkills: null,
		aaChain: null,
		skillIndex: "",
		curSkill: "",
		skillMap: "",
		/*#{1I1U4I09F5ExCtxAttrs*/
		/*}#1I1U4I09F5ExCtxAttrs*/
	};
	context=VFACT.flexState(context);
	/*#{1I1U4I09F0PostContext*/
	/*}#1I1U4I09F0PostContext*/
	let agent,segs={};
	segs["MakeEnv"]=MakeEnv=async function(input){//:1I1U5GI0N0
		let result=input
		/*#{1I1U5GI0N0Code*/
		let aaSkills,skills,chainVO,saveVO,indexVO,skillMap,name,skill,chain;
		aaSkills=context.aaSkills=new AASkills();
		chainVO=await AASkillChain.loadChainVO(chainPath);
		skills=chainVO.skills;
		saveVO={
			skills:Object.values(skills)
		};
		await aaSkills.loadFromVO(saveVO);
		chain=context.aaChain=await aaSkills.loadChain(chainPath);
		indexVO={};
		skillMap={};
		for(name in skills){
			skill=aaSkills.getSkill(skills[name]);
			indexVO[name]=skill.description;
			skillMap[name]=skill;
		}
		context.skillIndex=indexVO;
		context.skillMap=skillMap;
		console.log("Chain:");
		console.log(chain);
		console.log("Skills:");
		console.log(indexVO);
		result=`- 任务执行指引: ${JSON.stringify(chain.guide)}`;
		result+="\n";
		result+=`- 额外指令: ${command?command:"无"}`;
		/*}#1I1U5GI0N0Code*/
		return {seg:StartTip,result:(result),preSeg:"1I1U5GI0N0",outlet:"1I1U5GSKC0"};
	};
	MakeEnv.jaxId="1I1U5GI0N0"
	MakeEnv.url="MakeEnv@"+agentURL
	
	segs["RunStep"]=RunStep=async function(input){//:1I1U4IB8C0
		let prompt;
		let result=null;
		/*#{1I1U4IB8C0Input*/
		/*}#1I1U4IB8C0Input*/
		
		let opts={
			platform:"OpenAI",
			mode:"gpt-4o",
			maxToken:2000,
			temperature:0,
			topP:1,
			fqcP:0,
			prcP:0,
			secret:false,
			responseFormat:"json_object"
		};
		let chatMem=RunStep.messages
		let seed="";
		if(seed!==undefined){opts.seed=seed;}
		let messages=[
			{role:"system",content:`
你是一个根据执行指引和用户输入，选择适合的Skill或智能体运行，与用户对话，完成任务的AI。
当前的SKill/智能体有：
${JSON.stringify(context.skillIndex,null,"\t")}
- 第一轮对话时，用户输入的是“任务执行指引”，和额外的据用户的输入，你根据“任务执行指引”选择合适的Skill执行任务或与用户对话。

- 每一回合对话，跟根据“任务执行指引”和当前任务执行的情况，回复一个JSON对象。如果需要执行一个Skill，回复JSON中的"skill"属性是下一步要执行的SKill或智能体的名称; 回复JSON中的prompt属性是调用这个Skill的输入指令。例如：
{
	"skill":"Skill-3",
    "prompt":"Search for: Who is the winner of 2024 F1?"
}

- 执行Skill的结果会在对话中告知，你根据任务目标以及Skill的执行情况，选择新的Skill或与用户对话。

- 如果成功的完成了用户提出的任务，回复将JSON中的"finish"属性设置为true。并通过"result"属性总结汇报执行情况。例如
{
	"finish":true,
    "result":"论坛帖子已经成功发布。"
}

- 如果执行Skill出现错误，你认为无法完成用户的任务，设置回复JSON中的"abort"属性为true，并在"reason"属性中说明原因。例如:
{
	"abort":true,
    "reason":"没有登录脸书账号，无法发布新的内容。"
}

- 如果要完成任务需要一些额外的信息，这只回复中的question属性向用户提问，例如：
{
	"question":"请问你要发布的帖子内容是什么？"
}

- 如果完成任务不需要使用任何skill，用回复JSON中的"replay"属性回答用户，如果对话已结束，同时设置"finish"属性为true。例如：当用户询问："西瓜是一种水果么？"，你的回复：
{
	"finish":true,
	"reply":"是的，西瓜是一种水果。"
}
`
},
		];
		messages.push(...chatMem);
		/*#{1I1U4IB8C0PrePrompt*/
		/*}#1I1U4IB8C0PrePrompt*/
		prompt=input;
		if(prompt!==null){
			messages.push({role:"user",content:prompt});
		}
		/*#{1I1U4IB8C0PreCall*/
		/*}#1I1U4IB8C0PreCall*/
		result=(result===null)?(await session.callSegLLM("RunStep@"+agentURL,opts,messages,true)):result;
		/*#{1I1U4IB8C0PostLLM*/
		/*}#1I1U4IB8C0PostLLM*/
		chatMem.push({role:"user",content:prompt});
		chatMem.push({role:"assistant",content:result});
		if(chatMem.length>50){
			let removedMsgs=chatMem.splice(0,2);
			/*#{1I1U4IB8C0PostClear*/
			/*}#1I1U4IB8C0PostClear*/
		}
		result=trimJSON(result);
		/*#{1I1U4IB8C0PostCall*/
		console.log(result);
		/*}#1I1U4IB8C0PostCall*/
		return {seg:CheckStep,result:(result),preSeg:"1I1U4IB8C0",outlet:"1I1U4IL1R0"};
	};
	RunStep.jaxId="1I1U4IB8C0"
	RunStep.url="RunStep@"+agentURL
	RunStep.messages=[];
	
	segs["CheckStep"]=CheckStep=async function(input){//:1I1U4J5J80
		let result=input;
		if(input.skill){
			return {seg:CallSkill,result:(input),preSeg:"1I1U4J5J80",outlet:"1I1U4KJJT0"};
		}
		if(input.finish&&input.result){
			let output=input.result;
			return {seg:ShowFinish,result:(output),preSeg:"1I1U4J5J80",outlet:"1I1U4LSG90"};
		}
		if(input.abort){
			let output=input.reason;
			return {seg:ShowAbort,result:(output),preSeg:"1I1U4J5J80",outlet:"1I1U4LMPQ0"};
		}
		if(input.reply){
			let output=input.reply;
			return {seg:ShowReply,result:(output),preSeg:"1I1U4J5J80",outlet:"1I1U4MK000"};
		}
		if(input.question){
			let output=input;
			return {seg:AskQuestion,result:(output),preSeg:"1I1U4J5J80",outlet:"1I1U4O5FG0"};
		}
		return {result:result};
	};
	CheckStep.jaxId="1I1U4J5J80"
	CheckStep.url="CheckStep@"+agentURL
	
	segs["CallSkill"]=CallSkill=async function(input){//:1I1U4Q6O90
		let result=input;
		/*#{1I1U4Q6O90Code*/
		false
		/*}#1I1U4Q6O90Code*/
		return {seg:PickSkill,result:(result),preSeg:"1I1U4Q6O90",outlet:"1I1U4Q6OA1",catchSeg:LogError,catchlet:"1I1U4Q6OA2"};
	};
	CallSkill.jaxId="1I1U4Q6O90"
	CallSkill.url="CallSkill@"+agentURL
	
	segs["PickSkill"]=PickSkill=async function(input){//:1I1U4QSMF0
		let result=input
		/*#{1I1U4QSMF0Code*/
		context.curSkill=context.skillMap[input.skill];
		/*}#1I1U4QSMF0Code*/
		return {seg:ShowSkill,result:(result),preSeg:"1I1U4QSMF0",outlet:"1I1U4QSMG2"};
	};
	PickSkill.jaxId="1I1U4QSMF0"
	PickSkill.url="PickSkill@"+agentURL
	
	segs["LogError"]=LogError=async function(input){//:1I1U4R7NR0
		let result=input
		/*#{1I1U4R7NR0Code*/
		result=`执行SKill发生错误：${JSON.stringify(input)}`;
		/*}#1I1U4R7NR0Code*/
		return {seg:ShowError,result:(result),preSeg:"1I1U4R7NR0",outlet:"1I1U4R7NS2"};
	};
	LogError.jaxId="1I1U4R7NR0"
	LogError.url="LogError@"+agentURL
	
	segs["ShowSkill"]=ShowSkill=async function(input){//:1I1U4RRQR0
		let result=input;
		let role="assistant";
		let content=`- Skill: ${context.curSkill.getNameText()}
- Prompt: ${input.prompt}
`;
		session.addChatText(role,content);
		return {seg:RunSkill,result:(result),preSeg:"1I1U4RRQR0",outlet:"1I1U4RRQS0"};
	};
	ShowSkill.jaxId="1I1U4RRQR0"
	ShowSkill.url="ShowSkill@"+agentURL
	
	segs["RunSkill"]=RunSkill=async function(input){//:1I1U4S7NN0
		let result=input
		/*#{1I1U4S7NN0Code*/
		let skill=context.curSkill;
		result=await context.aaSkills.execSkill(topVFACT.app,skill,input.prompt?JSON.stringify(input.prompt):"",session);
		/*}#1I1U4S7NN0Code*/
		return {seg:ShowSkillResult,result:(result),preSeg:"1I1U4S7NN0",outlet:"1I1U4S7NO2"};
	};
	RunSkill.jaxId="1I1U4S7NN0"
	RunSkill.url="RunSkill@"+agentURL
	
	segs["ShowSkillResult"]=ShowSkillResult=async function(input){//:1I1U4STLQ0
		let result=input;
		let role="system";
		let content=input;
		session.addChatText(role,content);
		return {seg:appendMessage,result:(result),preSeg:"1I1U4STLQ0",outlet:"1I1U4STLQ3"};
	};
	ShowSkillResult.jaxId="1I1U4STLQ0"
	ShowSkillResult.url="ShowSkillResult@"+agentURL
	
	segs["appendMessage"]=appendMessage=async function(input){//:1I1U4T7KL0
		let result=input
		/*#{1I1U4T7KL0Code*/
		result=`Run skill result: ${JSON.stringify(input,null,"\t")}`;
		/*}#1I1U4T7KL0Code*/
		return {seg:RunStep,result:(result),preSeg:"1I1U4T7KL0",outlet:"1I1U4T7KL3"};
	};
	appendMessage.jaxId="1I1U4T7KL0"
	appendMessage.url="appendMessage@"+agentURL
	
	segs["ShowFinish"]=ShowFinish=async function(input){//:1I1U50BE50
		let result=input;
		let role="assistant";
		let content=input;
		session.addChatText(role,content);
		return {seg:NextMenu,result:(result),preSeg:"1I1U50BE50",outlet:"1I1U50BE62"};
	};
	ShowFinish.jaxId="1I1U50BE50"
	ShowFinish.url="ShowFinish@"+agentURL
	
	segs["ShowAbort"]=ShowAbort=async function(input){//:1I1U52CR00
		let result=input;
		let role="assistant";
		let content=input;
		session.addChatText(role,content);
		return {seg:NextMenu,result:(result),preSeg:"1I1U52CR00",outlet:"1I1U52CR03"};
	};
	ShowAbort.jaxId="1I1U52CR00"
	ShowAbort.url="ShowAbort@"+agentURL
	
	segs["ShowReply"]=ShowReply=async function(input){//:1I1U5301T0
		let result=input;
		let role="assistant";
		let content=input;
		session.addChatText(role,content);
		return {seg:NextMenu,result:(result),preSeg:"1I1U5301T0",outlet:"1I1U5301T3"};
	};
	ShowReply.jaxId="1I1U5301T0"
	ShowReply.url="ShowReply@"+agentURL
	
	segs["NextMenu"]=NextMenu=async function(input){//:1I1U53E7B3
		let prompt=("Please confirm")||input;
		let countdown=undefined;
		let silent=false;
		let items=[
			{icon:"/~/-tabos/shared/assets/hudbox.svg",text:"执行新的任务",code:0},
			{icon:"/~/-tabos/shared/assets/hudbox.svg",text:(($ln==="CN")?("继续当前任务"):("Continue current task")),code:1},
			{icon:"/~/-tabos/shared/assets/hudbox.svg",text:(($ln==="CN")?("退出对话"):("Exit conversation")),code:2},
		];
		let result="";
		let item=null;
		
		if(silent){
			result="";
			return {seg:ResetMsg,result:(result),preSeg:"1I1U53E7B3",outlet:"1I1U53E7B4"};
		}
		[result,item]=await session.askUserRaw({type:"menu",prompt:prompt,multiSelect:false,items:items,withChat:false,countdown:countdown});
		if(item.code===0){
			return {seg:ResetMsg,result:(result),preSeg:"1I1U53E7B3",outlet:"1I1U53E7B4"};
		}
		if(item.code===1){
			return {seg:AskMore,result:(result),preSeg:"1I1U53E7B3",outlet:"1I1U53E7B7"};
		}
		if(item.code===2){
			return {seg:CloseChat,result:(result),preSeg:"1I1U53E7B3",outlet:"1I1U53E7B10"};
		}
	};
	NextMenu.jaxId="1I1U53E7B3"
	NextMenu.url="NextMenu@"+agentURL
	
	segs["ResetMsg"]=ResetMsg=async function(input){//:1I1U54DHA0
		let result=input
		/*#{1I1U54DHA0Code*/
		/*}#1I1U54DHA0Code*/
		return {seg:AskNewCmd,result:(result),preSeg:"1I1U54DHA0",outlet:"1I1U54DHA3"};
	};
	ResetMsg.jaxId="1I1U54DHA0"
	ResetMsg.url="ResetMsg@"+agentURL
	
	segs["AskNewCmd"]=AskNewCmd=async function(input){//:1I1U55JV90
		let tip=("有什么新的指示么？");
		let tipRole=("assistant");
		let placeholder=("");
		let text=("");
		let result="";
		/*#{1I1U55JV90PreCodes*/
		/*}#1I1U55JV90PreCodes*/
		if(tip){
			session.addChatText(tipRole,tip);
		}
		result=await session.askChatInput({type:"input",placeholder:placeholder,text:text});
		session.addChatText("user",result);
		/*#{1I1U55JV90PostCodes*/
		/*}#1I1U55JV90PostCodes*/
		return {seg:RunStep,result:(result),preSeg:"1I1U55JV90",outlet:"1I1U55JVA2"};
	};
	AskNewCmd.jaxId="1I1U55JV90"
	AskNewCmd.url="AskNewCmd@"+agentURL
	
	segs["AskMore"]=AskMore=async function(input){//:1I1U569G70
		let tip=((($ln==="CN")?("请给出指示"):("Please give instructions")));
		let tipRole=("assistant");
		let placeholder=("");
		let text=("");
		let result="";
		if(tip){
			session.addChatText(tipRole,tip);
		}
		result=await session.askChatInput({type:"input",placeholder:placeholder,text:text});
		session.addChatText("user",result);
		return {seg:RunStep,result:(result),preSeg:"1I1U569G70",outlet:"1I1U569G73"};
	};
	AskMore.jaxId="1I1U569G70"
	AskMore.url="AskMore@"+agentURL
	
	segs["CloseChat"]=CloseChat=async function(input){//:1I1U56PCG0
		let result=input
		/*#{1I1U56PCG0Code*/
		if(VFACT.app && VFACT.app.closeApp){
			VFACT.app.closeApp();
		}
		/*}#1I1U56PCG0Code*/
		return {result:result};
	};
	CloseChat.jaxId="1I1U56PCG0"
	CloseChat.url="CloseChat@"+agentURL
	
	segs["AskQuestion"]=AskQuestion=async function(input){//:1I1U58CA70
		let tip=(input.question);
		let tipRole=("assistant");
		let placeholder=("");
		let text=("");
		let result="";
		if(tip){
			session.addChatText(tipRole,tip);
		}
		result=await session.askChatInput({type:"input",placeholder:placeholder,text:text});
		session.addChatText("user",result);
		return {seg:RunStep,result:(result),preSeg:"1I1U58CA70",outlet:"1I1U59G180"};
	};
	AskQuestion.jaxId="1I1U58CA70"
	AskQuestion.url="AskQuestion@"+agentURL
	
	segs["StartTip"]=StartTip=async function(input){//:1I1U9DAUJ0
		let result=input;
		let role="user";
		let content=`
- 任务链: ${chainPath}
- 额外指令：${command?command:"无"}
`;
		session.addChatText(role,content);
		return {seg:RunStep,result:(result),preSeg:"1I1U9DAUJ0",outlet:"1I1U9DAUK0"};
	};
	StartTip.jaxId="1I1U9DAUJ0"
	StartTip.url="StartTip@"+agentURL
	
	segs["ShowError"]=ShowError=async function(input){//:1I1UC0APN0
		let result=input;
		let role="assistant";
		let content=input;
		session.addChatText(role,content);
		return {seg:RunStep,result:(result),preSeg:"1I1UC0APN0",outlet:"1I1UC0V4R0"};
	};
	ShowError.jaxId="1I1UC0APN0"
	ShowError.url="ShowError@"+agentURL
	
	agent={
		isAIAgent:true,
		session:session,
		name:"RunSkillChain",
		url:agentURL,
		autoStart:true,
		jaxId:"1I1U4I09F0",
		context:context,
		livingSeg:null,
		execChat:async function(input/*{chainPath,command}*/){
			let result;
			parseAgentArgs(input);
			/*#{1I1U4I09F0PreEntry*/
			if(!chainPath){
				if(input[0]==="{"){
					try{
						input=JSON.parse(input);
						parseAgentArgs(input);
					}catch(err){
						throw Error("Missing skill-chain path.");
					}
				}else{
					chainPath=input;
				}
			}
			/*}#1I1U4I09F0PreEntry*/
			result={seg:MakeEnv,"input":input};
			/*#{1I1U4I09F0PostEntry*/
			/*}#1I1U4I09F0PostEntry*/
			return result;
		},
		/*#{1I1U4I09F0MoreAgentAttrs*/
		/*}#1I1U4I09F0MoreAgentAttrs*/
	};
	/*#{1I1U4I09F0PostAgent*/
	/*}#1I1U4I09F0PostAgent*/
	return agent;
};
/*#{1I1U4I09F0ExCodes*/
/*}#1I1U4I09F0ExCodes*/

/*#{1I1U4I09F0PostDoc*/
/*}#1I1U4I09F0PostDoc*/


export default RunSkillChain;
export{RunSkillChain};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DocAIAgent",
//	"jaxId": "1I1U4I09F0",
//	"attrs": {
//		"editObjs": {
//			"jaxId": "1I1U4I09F1",
//			"attrs": {
//				"RunSkillChain": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1I1U4I09F7",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1I1U4I09F8",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1I1U4I09F9",
//							"attrs": {}
//						},
//						"functions": {
//							"jaxId": "1I1U4I09F10",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false"
//					},
//					"mockups": {}
//				}
//			}
//		},
//		"agent": {
//			"jaxId": "1I1U4I09F2",
//			"attrs": {}
//		},
//		"entry": "",
//		"autoStart": "true",
//		"debug": "true",
//		"apiArgs": {
//			"jaxId": "1I1U4I09F3",
//			"attrs": {
//				"chainPath": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I1U5NS9O0",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "null",
//						"desc": ""
//					}
//				},
//				"command": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I1U5NS9O1",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1I1U4I09F4",
//			"attrs": {}
//		},
//		"context": {
//			"jaxId": "1I1U4I09F5",
//			"attrs": {
//				"aaSkills": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I1U6952G0",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "null",
//						"desc": ""
//					}
//				},
//				"aaChain": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I1U6ITHF0",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "null",
//						"desc": ""
//					}
//				},
//				"skillIndex": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I1UAGVDJ0",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				},
//				"curSkill": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I1UAKRR50",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				},
//				"skillMap": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I1UB7AA10",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				}
//			}
//		},
//		"globalMockup": {
//			"jaxId": "1I1U4I09F6",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I1U5GI0N0",
//					"attrs": {
//						"id": "MakeEnv",
//						"label": "New AI Seg",
//						"x": "50",
//						"y": "365",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I1U5GSKF0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1U5GSKF1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I1U5GSKC0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1U9DAUJ0"
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "callLLM",
//					"jaxId": "1I1U4IB8C0",
//					"attrs": {
//						"id": "RunStep",
//						"label": "New AI Seg",
//						"x": "520",
//						"y": "365",
//						"desc": "执行一次LLM调用。",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I1U4IL1T0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1U4IL1T1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"platform": "\"OpenAI\"",
//						"mode": "gpt-4o",
//						"system": "#`\n你是一个根据执行指引和用户输入，选择适合的Skill或智能体运行，与用户对话，完成任务的AI。\n当前的SKill/智能体有：\n${JSON.stringify(context.skillIndex,null,\"\\t\")}\n- 第一轮对话时，用户输入的是“任务执行指引”，和额外的据用户的输入，你根据“任务执行指引”选择合适的Skill执行任务或与用户对话。\n\n- 每一回合对话，跟根据“任务执行指引”和当前任务执行的情况，回复一个JSON对象。如果需要执行一个Skill，回复JSON中的\"skill\"属性是下一步要执行的SKill或智能体的名称; 回复JSON中的prompt属性是调用这个Skill的输入指令。例如：\n{\n\t\"skill\":\"Skill-3\",\n    \"prompt\":\"Search for: Who is the winner of 2024 F1?\"\n}\n\n- 执行Skill的结果会在对话中告知，你根据任务目标以及Skill的执行情况，选择新的Skill或与用户对话。\n\n- 如果成功的完成了用户提出的任务，回复将JSON中的\"finish\"属性设置为true。并通过\"result\"属性总结汇报执行情况。例如\n{\n\t\"finish\":true,\n    \"result\":\"论坛帖子已经成功发布。\"\n}\n\n- 如果执行Skill出现错误，你认为无法完成用户的任务，设置回复JSON中的\"abort\"属性为true，并在\"reason\"属性中说明原因。例如:\n{\n\t\"abort\":true,\n    \"reason\":\"没有登录脸书账号，无法发布新的内容。\"\n}\n\n- 如果要完成任务需要一些额外的信息，这只回复中的question属性向用户提问，例如：\n{\n\t\"question\":\"请问你要发布的帖子内容是什么？\"\n}\n\n- 如果完成任务不需要使用任何skill，用回复JSON中的\"replay\"属性回答用户，如果对话已结束，同时设置\"finish\"属性为true。例如：当用户询问：\"西瓜是一种水果么？\"，你的回复：\n{\n\t\"finish\":true,\n\t\"reply\":\"是的，西瓜是一种水果。\"\n}\n`\n",
//						"temperature": "0",
//						"maxToken": "2000",
//						"topP": "1",
//						"fqcP": "0",
//						"prcP": "0",
//						"messages": {
//							"attrs": []
//						},
//						"prompt": "#input",
//						"seed": "",
//						"outlet": {
//							"jaxId": "1I1U4IL1R0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1U4J5J80"
//						},
//						"secret": "false",
//						"allowCheat": "false",
//						"GPTCheats": {
//							"attrs": []
//						},
//						"shareChatName": "",
//						"keepChat": "50 messages",
//						"clearChat": "2",
//						"apiFiles": {
//							"attrs": []
//						},
//						"parallelFunction": "false",
//						"responseFormat": "json_object"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "brunch",
//					"jaxId": "1I1U4J5J80",
//					"attrs": {
//						"id": "CheckStep",
//						"label": "New AI Seg",
//						"x": "740",
//						"y": "365",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I1U4KJK00",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1U4KJK01",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I1U4KJJT1",
//							"attrs": {
//								"id": "Default",
//								"desc": "输出节点。",
//								"output": ""
//							}
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I1U4KJJT0",
//									"attrs": {
//										"id": "UseSkill",
//										"desc": "输出节点。",
//										"output": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I1U4KJK02",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I1U4KJK03",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#input.skill"
//									},
//									"linkedSeg": "1I1U4Q6O90"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I1U4LSG90",
//									"attrs": {
//										"id": "Finish",
//										"desc": "输出节点。",
//										"output": "#input.result",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I1U4LSGC0",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I1U4LSGC1",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#input.finish&&input.result"
//									},
//									"linkedSeg": "1I1U50BE50"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I1U4LMPQ0",
//									"attrs": {
//										"id": "Abort",
//										"desc": "输出节点。",
//										"output": "#input.reason",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I1U4LSGC2",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I1U4LSGC3",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#input.abort"
//									},
//									"linkedSeg": "1I1U52CR00"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I1U4MK000",
//									"attrs": {
//										"id": "Reply",
//										"desc": "输出节点。",
//										"output": "#input.reply",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I1U4N9FG0",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I1U4N9FG1",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#input.reply"
//									},
//									"linkedSeg": "1I1U5301T0"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I1U4O5FG0",
//									"attrs": {
//										"id": "Question",
//										"desc": "输出节点。",
//										"output": "#input",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I1U4OAVF0",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I1U4OAVF1",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#input.question"
//									},
//									"linkedSeg": "1I1U58CA70"
//								}
//							]
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "tryCatch",
//					"jaxId": "1I1U4Q6O90",
//					"attrs": {
//						"id": "CallSkill",
//						"label": "New AI Seg",
//						"x": "990",
//						"y": "185",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I1U4Q6O91",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1U4Q6OA0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I1U4Q6OA1",
//							"attrs": {
//								"id": "Try",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1U4QSMF0"
//						},
//						"catchlet": {
//							"jaxId": "1I1U4Q6OA2",
//							"attrs": {
//								"id": "Catch",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1U4R7NR0"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I1U4QSMF0",
//					"attrs": {
//						"id": "PickSkill",
//						"label": "New AI Seg",
//						"x": "1195",
//						"y": "120",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "working.svg",
//						"context": {
//							"jaxId": "1I1U4QSMG0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1U4QSMG1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I1U4QSMG2",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1U4RRQR0"
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I1U4R7NR0",
//					"attrs": {
//						"id": "LogError",
//						"label": "New AI Seg",
//						"x": "1195",
//						"y": "200",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "working.svg",
//						"context": {
//							"jaxId": "1I1U4R7NS0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1U4R7NS1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I1U4R7NS2",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1UC0APN0"
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1I1U4RRQR0",
//					"attrs": {
//						"id": "ShowSkill",
//						"label": "New AI Seg",
//						"x": "1400",
//						"y": "120",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I1U4RRQR1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1U4RRQR2",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "Assistant",
//						"text": "#`- Skill: ${context.curSkill.getNameText()}\n- Prompt: ${input.prompt}\n`",
//						"outlet": {
//							"jaxId": "1I1U4RRQS0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1U4S7NN0"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I1U4S7NN0",
//					"attrs": {
//						"id": "RunSkill",
//						"label": "New AI Seg",
//						"x": "1620",
//						"y": "120",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "lint_bug.svg",
//						"context": {
//							"jaxId": "1I1U4S7NO0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1U4S7NO1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I1U4S7NO2",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1U4STLQ0"
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1I1U4STLQ0",
//					"attrs": {
//						"id": "ShowSkillResult",
//						"label": "New AI Seg",
//						"x": "1840",
//						"y": "120",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I1U4STLQ1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1U4STLQ2",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "System",
//						"text": "#input",
//						"outlet": {
//							"jaxId": "1I1U4STLQ3",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1U4T7KL0"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I1U4T7KL0",
//					"attrs": {
//						"id": "appendMessage",
//						"label": "New AI Seg",
//						"x": "2090",
//						"y": "120",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "working.svg",
//						"context": {
//							"jaxId": "1I1U4T7KL1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1U4T7KL2",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I1U4T7KL3",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1U4TE4G0"
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I1U4TE4G0",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "2265",
//						"y": "35",
//						"outlet": {
//							"jaxId": "1I1U4UUTT0",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1U4TOI70"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I1U4TOI70",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "740",
//						"y": "35",
//						"outlet": {
//							"jaxId": "1I1U4UUTT1",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1U4U8GV0"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I1U4U8GV0",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "555",
//						"y": "295",
//						"outlet": {
//							"jaxId": "1I1U4UUTT2",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1U4IB8C0"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1I1U50BE50",
//					"attrs": {
//						"id": "ShowFinish",
//						"label": "New AI Seg",
//						"x": "990",
//						"y": "285",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I1U50BE60",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1U50BE61",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "Assistant",
//						"text": "#input",
//						"outlet": {
//							"jaxId": "1I1U50BE62",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1U53E7B3"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connectorL",
//					"jaxId": "1I1U50VCC0",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "2235",
//						"y": "200",
//						"outlet": {
//							"jaxId": "1I1U51CC20",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1U4TE4G0"
//						},
//						"dir": "L2R"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1I1U52CR00",
//					"attrs": {
//						"id": "ShowAbort",
//						"label": "New AI Seg",
//						"x": "990",
//						"y": "350",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I1U52CR01",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1U52CR02",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "Assistant",
//						"text": "#input",
//						"outlet": {
//							"jaxId": "1I1U52CR03",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1U53E7B3"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1I1U5301T0",
//					"attrs": {
//						"id": "ShowReply",
//						"label": "New AI Seg",
//						"x": "990",
//						"y": "420",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I1U5301T1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1U5301T2",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "Assistant",
//						"text": "#input",
//						"outlet": {
//							"jaxId": "1I1U5301T3",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1U53E7B3"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "askMenu",
//					"jaxId": "1I1U53E7B3",
//					"attrs": {
//						"id": "NextMenu",
//						"label": "New AI Seg",
//						"x": "1225",
//						"y": "350",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"prompt": "Please confirm",
//						"multi": "false",
//						"withChat": "false",
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1I1U53E7B4",
//									"attrs": {
//										"id": "NewTask",
//										"desc": "输出节点。",
//										"text": "执行新的任务",
//										"result": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I1U53E7B5",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I1U53E7B6",
//											"attrs": {
//												"cast": ""
//											}
//										}
//									},
//									"linkedSeg": "1I1U54DHA0"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1I1U53E7B7",
//									"attrs": {
//										"id": "Continue",
//										"desc": "输出节点。",
//										"text": {
//											"type": "string",
//											"valText": "Continue current task",
//											"localize": {
//												"EN": "Continue current task",
//												"CN": "继续当前任务"
//											},
//											"localizable": true
//										},
//										"result": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I1U53E7B8",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I1U53E7B9",
//											"attrs": {
//												"cast": ""
//											}
//										}
//									},
//									"linkedSeg": "1I1U569G70"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1I1U53E7B10",
//									"attrs": {
//										"id": "Exit",
//										"desc": "输出节点。",
//										"text": {
//											"type": "string",
//											"valText": "Exit conversation",
//											"localize": {
//												"EN": "Exit conversation",
//												"CN": "退出对话"
//											},
//											"localizable": true
//										},
//										"result": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I1U53E7B11",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I1U53E7B12",
//											"attrs": {
//												"cast": ""
//											}
//										}
//									},
//									"linkedSeg": "1I1U56PCG0"
//								}
//							]
//						},
//						"silent": "false"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I1U54DHA0",
//					"attrs": {
//						"id": "ResetMsg",
//						"label": "New AI Seg",
//						"x": "1465",
//						"y": "285",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "working.svg",
//						"context": {
//							"jaxId": "1I1U54DHA1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1U54DHA2",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I1U54DHA3",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1U55JV90"
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "askChat",
//					"jaxId": "1I1U55JV90",
//					"attrs": {
//						"id": "AskNewCmd",
//						"label": "New AI Seg",
//						"x": "1685",
//						"y": "285",
//						"desc": "这是一个AISeg。",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I1U55JVA0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1U55JVA1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"tip": "有什么新的指示么？",
//						"tipRole": "Assistant",
//						"placeholder": "",
//						"text": "",
//						"file": "false",
//						"showText": "true",
//						"outlet": {
//							"jaxId": "1I1U55JVA2",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1U59UT10"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "askChat",
//					"jaxId": "1I1U569G70",
//					"attrs": {
//						"id": "AskMore",
//						"label": "New AI Seg",
//						"x": "1465",
//						"y": "350",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I1U569G71",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1U569G72",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"tip": {
//							"type": "string",
//							"valText": "Please give instructions",
//							"localize": {
//								"EN": "Please give instructions",
//								"CN": "请给出指示"
//							},
//							"localizable": true
//						},
//						"tipRole": "Assistant",
//						"placeholder": "",
//						"text": "",
//						"file": "false",
//						"showText": "true",
//						"outlet": {
//							"jaxId": "1I1U569G73",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1U59UT10"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I1U56PCG0",
//					"attrs": {
//						"id": "CloseChat",
//						"label": "New AI Seg",
//						"x": "1465",
//						"y": "415",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "flag.svg",
//						"context": {
//							"jaxId": "1I1U57A510",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1U57A511",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I1U57A4U0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							}
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "askChat",
//					"jaxId": "1I1U58CA70",
//					"attrs": {
//						"id": "AskQuestion",
//						"label": "New AI Seg",
//						"x": "990",
//						"y": "490",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I1U59G1A0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1U59G1A1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"tip": "#input.question",
//						"tipRole": "Assistant",
//						"placeholder": "",
//						"text": "",
//						"file": "false",
//						"showText": "true",
//						"outlet": {
//							"jaxId": "1I1U59G180",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1U592S60"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I1U592S60",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "1145",
//						"y": "565",
//						"outlet": {
//							"jaxId": "1I1U59G1A2",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1U59AJH0"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I1U59AJH0",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "555",
//						"y": "565",
//						"outlet": {
//							"jaxId": "1I1U59G1A3",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1U4IB8C0"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connectorT",
//					"jaxId": "1I1U59UT10",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "1905",
//						"y": "405",
//						"outlet": {
//							"jaxId": "1I1U5AI6P0",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1U5A6140"
//						},
//						"dir": "T2B"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I1U5A6140",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "1845",
//						"y": "565",
//						"outlet": {
//							"jaxId": "1I1U5AI6P1",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1U592S60"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1I1U9DAUJ0",
//					"attrs": {
//						"id": "StartTip",
//						"label": "New AI Seg",
//						"x": "270",
//						"y": "365",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I1U9DAUJ1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1U9DAUJ2",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "User",
//						"text": "#`\n- 任务链: ${chainPath}\n- 额外指令：${command?command:\"无\"}\n`",
//						"outlet": {
//							"jaxId": "1I1U9DAUK0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1U4IB8C0"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1I1UC0APN0",
//					"attrs": {
//						"id": "ShowError",
//						"label": "New AI Seg",
//						"x": "1445",
//						"y": "200",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I1UC0V530",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1UC0V531",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "Assistant",
//						"text": "#input",
//						"outlet": {
//							"jaxId": "1I1UC0V4R0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1U50VCC0"
//						}
//					}
//				}
//			]
//		},
//		"desc": "这是一个AI智能体。",
//		"exportAPI": "false",
//		"exportAddOn": "false",
//		"addOnOpts": ""
//	}
//}