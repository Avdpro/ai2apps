//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import pathLib from "/@path";
import inherits from "/@inherits";
import Base64 from "/@tabos/utils/base64.js";
import {trimJSON} from "/@aichat/utils.js";
/*#{1I0IEGBJ00MoreImports*/
import {tabFS} from "/@tabos";
import $actionDef from "./ActionsDef.js";
/*}#1I0IEGBJ00MoreImports*/
const agentURL=(new URL(import.meta.url)).pathname;
const basePath=pathLib.dirname(agentURL);
const $ln=VFACT.lanCode||"EN";
/*#{1I0IEGBJ00StartDoc*/
/*}#1I0IEGBJ00StartDoc*/
//----------------------------------------------------------------------------
let MakeTaskAgent=async function(session){
	let targetPage,startURL,execData,command,execSteps;
	let context,globalContext;
	let self;
	let HasPage,ShowData,QueryPage,QDescOK,AskName,CheckName,TipBadName,GenFunction,ShowCode,QModify,AskFix,AbortCode,GenDoc,TipFin,TipAbort,CheckQuestion,AskQuestion,GenDesc,ShowDesc,AskFixDesc,AskOverwrite;
	let actionDef="ActionDef";
	let funcName="newWebTask";
	let hostName="www.targetsite.com";
	
	/*#{1I0IEGBJ00LocalVals*/
	actionDef=$actionDef;
	/*}#1I0IEGBJ00LocalVals*/
	
	/*#{1I0IEGBJ00PreContext*/
	/*}#1I0IEGBJ00PreContext*/
	globalContext=session.globalContext;
	context={
		descVO: "",
		initPrompt: "Init-Prompt",
		docName: "FileName",
		docPath: "",
		docCode: "",
		/*#{1I0IEGBJ14ExCtxAttrs*/
		/*}#1I0IEGBJ14ExCtxAttrs*/
	};
	context=VFACT.flexState(context);
	/*#{1I0IEGBJ00PostContext*/
	/*}#1I0IEGBJ00PostContext*/
	let agent,segs={};
	segs["HasPage"]=HasPage=async function(input){//:1I0IEK7E30
		let result=input;
		/*#{1I0IEK7E30Start*/
		/*}#1I0IEK7E30Start*/
		if(!targetPage){
			return {seg:QueryPage,result:(input),preSeg:"1I0IEK7E30",outlet:"1I0IEK7E34"};
		}
		/*#{1I0IEK7E30Post*/
		/*}#1I0IEK7E30Post*/
		return {seg:ShowData,result:(result),preSeg:"1I0IEK7E30",outlet:"1I0IEK7E33"};
	};
	HasPage.jaxId="1I0IEK7E30"
	HasPage.url="HasPage@"+agentURL
	
	segs["ShowData"]=ShowData=async function(input){//:1I0IEL3AE0
		let result=input;
		let role="assistant";
		let content=`Command: ${command}
ExecData：
\`\`\`
${JSON.stringify(execData,null,"\t")}
\`\`\`
ExecSteps:
\`\`\`
${JSON.stringify(execSteps,null,"\t")}
\`\`\`
`;
		/*#{1I0IEL3AE0PreCodes*/
		/*}#1I0IEL3AE0PreCodes*/
		session.addChatText(role,content);
		/*#{1I0IEL3AE0PostCodes*/
		result={
			command:command,
			execData:execData,
			execSteps:execSteps			
		};
		result=JSON.stringify(result,null,"\t");
		context["initPrompt"]=result;
		/*}#1I0IEL3AE0PostCodes*/
		return {seg:GenDesc,result:(result),preSeg:"1I0IEL3AE0",outlet:"1I0IEL3AE3"};
	};
	ShowData.jaxId="1I0IEL3AE0"
	ShowData.url="ShowData@"+agentURL
	
	segs["QueryPage"]=QueryPage=async function(input){//:1I0IENUST0
		let result,args={};
		/*#{1I0IENUST0PreCodes*/
		/*}#1I0IENUST0PreCodes*/
		result= await session.pipeChat("/@aae/ai/QueryPage.js",args,false);
		/*#{1I0IENUST0PostCodes*/
		/*}#1I0IENUST0PostCodes*/
		return {seg:ShowData,result:(result),preSeg:"1I0IENUST0",outlet:"1I0IENUSU1"};
	};
	QueryPage.jaxId="1I0IENUST0"
	QueryPage.url="QueryPage@"+agentURL
	
	segs["QDescOK"]=QDescOK=async function(input){//:1I0KLAEFQ0
		let prompt=((($ln==="CN")?("这个函数的descVO是否需要修改？"):("Does this function desVO need modify?")))||input;
		let silent=false;
		let button1=("Code It")||"OK";
		let button2=("Modify")||"Cancel";
		let button3="";
		let result="";
		let value=0;
		if(silent){
			result="";
			/*#{1I0KLAEFA0Silent*/
			/*}#1I0KLAEFA0Silent*/
			return {seg:AskName,result:(result),preSeg:"1I0KLAEFQ0",outlet:"1I0KLAEFA0"};
		}
		[result,value]=await session.askUserRaw({type:"confirm",prompt:prompt,button1:button1,button2:button2,button3:button3});
		if(value===1){
			result=("")||result;
			/*#{1I0KLAEFA0Btn1*/
			const u=new URL(startURL);
			hostName=u.hostname;
			hostName=hostName.replaceAll(".","_");
			funcName=context.descVO.name;
			context.docName=funcName;
			context.docName="SKILL_"+hostName+"_"+funcName[0].toUpperCase()+funcName.substring(1)+".js";
			/*}#1I0KLAEFA0Btn1*/
			return {seg:AskName,result:(result),preSeg:"1I0KLAEFQ0",outlet:"1I0KLAEFA0"};
		}
		result=("")||result;
		return {seg:AskFixDesc,result:(result),preSeg:"1I0KLAEFQ0",outlet:"1I0KLAEFA1"};
	
	};
	QDescOK.jaxId="1I0KLAEFQ0"
	QDescOK.url="QDescOK@"+agentURL
	
	segs["AskName"]=AskName=async function(input){//:1I0IEU6620
		let tip=("Please name your new API Agent doc");
		let tipRole=("assistant");
		let placeholder=("");
		let text=(context.docName);
		let result="";
		if(tip){
			session.addChatText(tipRole,tip);
		}
		result=await session.askChatInput({type:"input",placeholder:placeholder,text:text});
		session.addChatText("user",result);
		return {seg:CheckName,result:(result),preSeg:"1I0IEU6620",outlet:"1I0IEV6DA0"};
	};
	AskName.jaxId="1I0IEU6620"
	AskName.url="AskName@"+agentURL
	
	segs["CheckName"]=CheckName=async function(input){//:1I0IF3QSC0
		let result=input;
		/*#{1I0IF3QSC0Start*/
		let nameOK,path,askOverwrite=false;
		path=basePath;
		if(path[0]==="/"){
			if(path[1]==="/"){
				path=path.substring(1);
			}else if(path[1]==="~"){
				path=path.substring(2);
			}
		}
		path=context.docPath=pathLib.join(path,context.docName);
		if(await tabFS.isExist(path)){
			input=nameOK=true;
			askOverwrite=true;
		}else{
			input=nameOK=true;
		}
		/*}#1I0IF3QSC0Start*/
		if(!input){
			return {seg:TipBadName,result:(input),preSeg:"1I0IF3QSC0",outlet:"1I0IF8STR0"};
		}
		if(askOverwrite){
			return {seg:AskOverwrite,result:(input),preSeg:"1I0IF3QSC0",outlet:"1I0V5M79U0"};
		}
		/*#{1I0IF3QSC0Post*/
		/*}#1I0IF3QSC0Post*/
		return {seg:GenFunction,result:(result),preSeg:"1I0IF3QSC0",outlet:"1I0IF8STR1"};
	};
	CheckName.jaxId="1I0IF3QSC0"
	CheckName.url="CheckName@"+agentURL
	
	segs["TipBadName"]=TipBadName=async function(input){//:1I0IF5KTR0
		let result=input;
		let role="assistant";
		let content=(($ln==="CN")?("文件名不合法或者已被占用，请输入一个新的名字"):("Invalid file name or already in use, please enter a new name"));
		session.addChatText(role,content);
		return {seg:AskName,result:(result),preSeg:"1I0IF5KTR0",outlet:"1I0IF8STR2"};
	};
	TipBadName.jaxId="1I0IF5KTR0"
	TipBadName.url="TipBadName@"+agentURL
	
	segs["GenFunction"]=GenFunction=async function(input){//:1I0IFC2U70
		let prompt;
		let result;
		
		let opts={
			platform:"OpenAI",
			mode:"gpt-4o",
			maxToken:3800,
			temperature:0,
			topP:1,
			fqcP:0,
			prcP:0,
			secret:false,
			responseFormat:"json_object"
		};
		let chatMem=GenFunction.messages
		let seed="";
		if(seed!==undefined){opts.seed=seed;}
		let messages=[
			{role:"system",content:`
### 你是一个强大的Javascript函数编写器。
第一轮对话时，用户会输入一个记录了一次操控网页执行任务的JSON对象。  
- command属性是任务的简单描述。  
- execData属性是任务的执行参数。  
- execSteps是完成这个任务的具体执行步骤内容JSON。
---
${actionDef}
---
- 请根据输入的JSON对象，设计，编写一个函数，用来生成执行同样任务的步骤。

- 请用对象展开的模式定义函数参数。函数的参数应该是一个和execData属性结构相同对象。

- 你的函数需要参考execSteps，生成完成任务的步骤数组。

- 注意：如果execData中的某个属性是数组，可能需要用循环的方式来生成多个步骤。

- 注意：请分析command、execData和execSteps，对于某些参数可能要进行合理性判断分析来生成或者跳过某些步骤。

- 你的函数应该返回一个数组，里面包含的是要执行的步骤。

---
- 你编写的函数的函数名是${funcName}。

- 你可以通过多轮与用户的对话来完善函数。

- 在每轮对话时，你要用JSON格式回答，把完整的函数代码放在"code"属性里。例如：
{
	"code":"...function code generated...",
}

- 如果完整实现这个函数需要一些额外的信息，你应该在JSON中增加question属性，例如：
{
	"code":"...",
    "question":"需要考虑名字不合法的情况么？"
}

- 如果用户表示要放弃编写，请在JSON则红添加stop属性，属性的内容是放弃编写的原因。例如：
{
	"code":"...",
    "stop":"User abort."
}

`},
		];
		messages.push(...chatMem);
		prompt=context.initPrompt;
		if(prompt!==null){
			messages.push({role:"user",content:prompt});
		}
		result=await session.callSegLLM("GenFunction@"+agentURL,opts,messages,true);
		chatMem.push({role:"user",content:prompt});
		chatMem.push({role:"assistant",content:result});
		if(chatMem.length>20){
			let removedMsgs=chatMem.splice(0,2);
		}
		result=trimJSON(result);
		return {seg:ShowCode,result:(result),preSeg:"1I0IFC2U70",outlet:"1I0IFCCG00"};
	};
	GenFunction.jaxId="1I0IFC2U70"
	GenFunction.url="GenFunction@"+agentURL
	GenFunction.messages=[];
	
	segs["ShowCode"]=ShowCode=async function(input){//:1I0IFEBGT0
		let result=input;
		let role="assistant";
		let content=`Current code:  \n\`\`\`\n${input.code}\n\`\`\``;
		session.addChatText(role,content);
		return {seg:CheckQuestion,result:(result),preSeg:"1I0IFEBGT0",outlet:"1I0IFGUFS0"};
	};
	ShowCode.jaxId="1I0IFEBGT0"
	ShowCode.url="ShowCode@"+agentURL
	
	segs["QModify"]=QModify=async function(input){//:1I0IFF4JJ0
		let prompt=("Please confirm")||input;
		let silent=false;
		let button1=("Code is OK")||"OK";
		let button2=("Abort")||"Cancel";
		let button3=("Modify")||"";
		let result="";
		let value=0;
		if(silent){
			result="";
			/*#{1I0IFF4J10Silent*/
			/*}#1I0IFF4J10Silent*/
			return {seg:GenDoc,result:(result),preSeg:"1I0IFF4JJ0",outlet:"1I0IFF4J10"};
		}
		[result,value]=await session.askUserRaw({type:"confirm",prompt:prompt,button1:button1,button2:button2,button3:button3});
		if(value===1){
			result=("")||result;
			/*#{1I0IFF4J10Btn1*/
			context.docCode=input.code;			
			/*}#1I0IFF4J10Btn1*/
			return {seg:GenDoc,result:(result),preSeg:"1I0IFF4JJ0",outlet:"1I0IFF4J10"};
		}
		if(value===2){
			result=("")||result;
			return {seg:AskFix,result:(result),preSeg:"1I0IFF4JJ0",outlet:"1I0IFF4J12"};
		}
		result=("")||result;
		return {seg:AbortCode,result:(result),preSeg:"1I0IFF4JJ0",outlet:"1I0IFF4J11"};
	
	};
	QModify.jaxId="1I0IFF4JJ0"
	QModify.url="QModify@"+agentURL
	
	segs["AskFix"]=AskFix=async function(input){//:1I0IFKNSP0
		let tip=("Please enter advice to modify:");
		let tipRole=("assistant");
		let placeholder=("");
		let text=("");
		let result="";
		if(tip){
			session.addChatText(tipRole,tip);
		}
		result=await session.askChatInput({type:"input",placeholder:placeholder,text:text});
		session.addChatText("user",result);
		return {seg:GenFunction,result:(result),preSeg:"1I0IFKNSP0",outlet:"1I0IFNKT20"};
	};
	AskFix.jaxId="1I0IFKNSP0"
	AskFix.url="AskFix@"+agentURL
	
	segs["AbortCode"]=AbortCode=async function(input){//:1I0IFMDDS0
		let result=input
		/*#{1I0IFMDDS0Code*/
		/*}#1I0IFMDDS0Code*/
		return {seg:TipAbort,result:(result),preSeg:"1I0IFMDDS0",outlet:"1I0IFNKT21"};
	};
	AbortCode.jaxId="1I0IFMDDS0"
	AbortCode.url="AbortCode@"+agentURL
	
	segs["GenDoc"]=GenDoc=async function(input){//:1I0IFN7B10
		let result;
		let sourcePath=pathLib.joinTabOSURL(basePath,"./GenTaskAgentDoc.js");
		let arg={"agentVO":context.descVO,"funcCode":context.docCode,"filePath":context.docPath,"hostName":hostName,"startURL":startURL};
		result= await session.pipeChat(sourcePath,arg,false);
		return {seg:TipFin,result:(result),preSeg:"1I0IFN7B10",outlet:"1I0IFNKT22"};
	};
	GenDoc.jaxId="1I0IFN7B10"
	GenDoc.url="GenDoc@"+agentURL
	
	segs["TipFin"]=TipFin=async function(input){//:1I0IFO26G0
		let result=input;
		let role="assistant";
		let content=input;
		session.addChatText(role,content);
		return {result:result};
	};
	TipFin.jaxId="1I0IFO26G0"
	TipFin.url="TipFin@"+agentURL
	
	segs["TipAbort"]=TipAbort=async function(input){//:1I0IFOA600
		let result=input;
		let role="assistant";
		let content=input;
		session.addChatText(role,content);
		return {result:result};
	};
	TipAbort.jaxId="1I0IFOA600"
	TipAbort.url="TipAbort@"+agentURL
	
	segs["CheckQuestion"]=CheckQuestion=async function(input){//:1I0KGASH10
		let result=input;
		if(input.question){
			return {seg:AskQuestion,result:(input),preSeg:"1I0KGASH10",outlet:"1I0KGEA600"};
		}
		return {seg:QModify,result:(result),preSeg:"1I0KGASH10",outlet:"1I0KGEA601"};
	};
	CheckQuestion.jaxId="1I0KGASH10"
	CheckQuestion.url="CheckQuestion@"+agentURL
	
	segs["AskQuestion"]=AskQuestion=async function(input){//:1I0KGEQA60
		let tip=(input.question);
		let tipRole=("assistant");
		let placeholder=("");
		let text=("");
		let result="";
		if(tip){
			session.addChatText(tipRole,tip);
		}
		result=await session.askChatInput({type:"input",placeholder:placeholder,text:text});
		session.addChatText("user",result);
		return {seg:GenFunction,result:(result),preSeg:"1I0KGEQA60",outlet:"1I0KGH0DF0"};
	};
	AskQuestion.jaxId="1I0KGEQA60"
	AskQuestion.url="AskQuestion@"+agentURL
	
	segs["GenDesc"]=GenDesc=async function(input){//:1I0KL8KBP0
		let prompt;
		let result;
		
		let opts={
			platform:"OpenAI",
			mode:"gpt-4o",
			maxToken:2000,
			temperature:0,
			topP:1,
			fqcP:0,
			prcP:0,
			secret:false,
			responseFormat:"json_object"
		};
		let chatMem=GenDesc.messages
		let seed="";
		if(seed!==undefined){opts.seed=seed;}
		let messages=[
			{role:"system",content:"你是负责设计网页RPA行为函数的AI。\n在第一轮对话时，用户给给你一个描述RPA任务例子的JSON对象，包括：\n- command属性是这个RPA例子任务的简单描述\n- execData是执行这个RPA任务例子时的参数列表对象\n- execSteps是这个例子中具体执行的RPA步骤\n\n根据这个例子JSON对象，设计一个的JS函数，请设计这个函数的名称和参数列表，以及返回值类型，用JSON返回设计内容。\n你可以和用户进行多轮对话，根据用户意见完善你的设计。\n\n-  你设计的函数的调用参数，应该与execData里的内容一致。\n\n- 每回合对话，你都应该返回设计函数的JSON，例如：\n{\n\t\"name\":\"sendSMS\",\n    \"desc\":\"use web page send a SMS to certain phone number\",\n    \"parameters\":{\n\t    \"type\": \"object\",\n\t    \"properties\":{\n\t    \t\"phoneNumber\":{\n            \t\"type\":\"string\",\n                \"description\":\"The phone number to send SMS\"\n            },\n\t    \t\"content\":{\n            \t\"type\":\"string\",\n                \"description\":\"The SMS content to send\"\n            }\n    \t}\n    },\n    \"result\":{\n\t    \"type\":\"boolean\",\n    \t\"description\":\"If send SMS success, return true, otherwise, reutrn false.\"\n    }\n}\n\n- 请保持简单直接的设计原则\n\t- 你设计的函数的调用参数尽量简洁，使用最直接的调用方法\n\t- 你设计的函数应该直接返回结果，不要进行成功/错误封装（如果出错就抛异常，不需要通过返回值体现）。\n"},
		];
		messages.push(...chatMem);
		prompt=context.initPrompt;
		if(prompt!==null){
			messages.push({role:"user",content:prompt});
		}
		result=await session.callSegLLM("GenDesc@"+agentURL,opts,messages,true);
		chatMem.push({role:"user",content:prompt});
		chatMem.push({role:"assistant",content:result});
		if(chatMem.length>20){
			let removedMsgs=chatMem.splice(0,2);
		}
		result=trimJSON(result);
		return {seg:ShowDesc,result:(result),preSeg:"1I0KL8KBP0",outlet:"1I0KLJDH10"};
	};
	GenDesc.jaxId="1I0KL8KBP0"
	GenDesc.url="GenDesc@"+agentURL
	GenDesc.messages=[];
	
	segs["ShowDesc"]=ShowDesc=async function(input){//:1I0KL929D0
		let result=input;
		let role="assistant";
		let content=(`Design JSON:\n\`\`\`\n${JSON.stringify(input,null,"\t")}\`\`\`\n`);
		/*#{1I0KL929D0PreCodes*/
		/*}#1I0KL929D0PreCodes*/
		session.addChatText(role,content);
		/*#{1I0KL929D0PostCodes*/
		/*}#1I0KL929D0PostCodes*/
		context["descVO"]=input;
		return {seg:QDescOK,result:(result),preSeg:"1I0KL929D0",outlet:"1I0KLJDH20"};
	};
	ShowDesc.jaxId="1I0KL929D0"
	ShowDesc.url="ShowDesc@"+agentURL
	
	segs["AskFixDesc"]=AskFixDesc=async function(input){//:1I0KL9RAO0
		let tip=((($ln==="CN")?("请提供修改建议"):("Please provide suggestions for modification")));
		let tipRole=("assistant");
		let placeholder=("");
		let text=("");
		let result="";
		if(tip){
			session.addChatText(tipRole,tip);
		}
		result=await session.askChatInput({type:"input",placeholder:placeholder,text:text});
		session.addChatText("user",result);
		return {seg:GenDesc,result:(result),preSeg:"1I0KL9RAO0",outlet:"1I0KLJDH21"};
	};
	AskFixDesc.jaxId="1I0KL9RAO0"
	AskFixDesc.url="AskFixDesc@"+agentURL
	
	segs["AskOverwrite"]=AskOverwrite=async function(input){//:1I0V5JLG10
		let prompt=((($ln==="CN")?("文件已存在，是否覆盖？"):("The file already exists, do you want to overwrite it?")))||input;
		let silent=false;
		let button1=((($ln==="CN")?("换个名字"):("Change Name")))||"OK";
		let button2=((($ln==="CN")?("覆盖"):("Overwrite")))||"Cancel";
		let button3="";
		let result="";
		let value=0;
		if(silent){
			result="";
			return {seg:AskName,result:(result),preSeg:"1I0V5JLG10",outlet:"1I0V5JLFF0"};
		}
		[result,value]=await session.askUserRaw({type:"confirm",prompt:prompt,button1:button1,button2:button2,button3:button3});
		if(value===1){
			result=("")||result;
			return {seg:AskName,result:(result),preSeg:"1I0V5JLG10",outlet:"1I0V5JLFF0"};
		}
		result=("")||result;
		return {seg:GenFunction,result:(result),preSeg:"1I0V5JLG10",outlet:"1I0V5JLFG0"};
	
	};
	AskOverwrite.jaxId="1I0V5JLG10"
	AskOverwrite.url="AskOverwrite@"+agentURL
	
	agent={
		isAIAgent:true,
		session:session,
		name:"MakeTaskAgent",
		url:agentURL,
		autoStart:true,
		jaxId:"1I0IEGBJ00",
		context:context,
		livingSeg:null,
		execChat:async function(input/*{targetPage,startURL,execData,command,execSteps}*/){
			let result;
			if(typeof(input)=='object'){
				targetPage=input.targetPage;
				startURL=input.startURL;
				execData=input.execData;
				command=input.command;
				execSteps=input.execSteps;
			}else{
				targetPage=undefined;
				startURL=undefined;
				execData=undefined;
				command=undefined;
				execSteps=undefined;
			}
			/*#{1I0IEGBJ00PreEntry*/
			/*}#1I0IEGBJ00PreEntry*/
			result={seg:HasPage,"input":input};
			/*#{1I0IEGBJ00PostEntry*/
			/*}#1I0IEGBJ00PostEntry*/
			return result;
		},
		/*#{1I0IEGBJ00MoreAgentAttrs*/
		/*}#1I0IEGBJ00MoreAgentAttrs*/
	};
	/*#{1I0IEGBJ00PostAgent*/
	/*}#1I0IEGBJ00PostAgent*/
	return agent;
};
/*#{1I0IEGBJ00ExCodes*/
/*}#1I0IEGBJ00ExCodes*/


export default MakeTaskAgent;
export{MakeTaskAgent};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DocAIAgent",
//	"jaxId": "1I0IEGBJ00",
//	"attrs": {
//		"editObjs": {
//			"jaxId": "1I0IEGBJ10",
//			"attrs": {
//				"MakeTaskAgent": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1I0IEGBJ16",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1I0IEGBJ17",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1I0IEGBJ18",
//							"attrs": {}
//						},
//						"functions": {
//							"jaxId": "1I0IEGBJ19",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false"
//					},
//					"mockups": {}
//				}
//			}
//		},
//		"agent": {
//			"jaxId": "1I0IEGBJ11",
//			"attrs": {}
//		},
//		"entry": "",
//		"autoStart": "true",
//		"debug": "true",
//		"apiArgs": {
//			"jaxId": "1I0IEGBJ12",
//			"attrs": {
//				"targetPage": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I0IEIGQA0",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				},
//				"startURL": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I0IEIGQA1",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				},
//				"execData": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I0IEIGQB0",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				},
//				"command": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I0IEIGQB1",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				},
//				"execSteps": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I0IEIGQB2",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1I0IEGBJ13",
//			"attrs": {
//				"actionDef": {
//					"type": "string",
//					"valText": "ActionDef"
//				},
//				"funcName": {
//					"type": "string",
//					"valText": "newWebTask"
//				},
//				"hostName": {
//					"type": "string",
//					"valText": "www.targetsite.com"
//				}
//			}
//		},
//		"context": {
//			"jaxId": "1I0IEGBJ14",
//			"attrs": {
//				"descVO": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I0KLNA0N0",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				},
//				"initPrompt": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I0KM6ARM0",
//					"attrs": {
//						"type": "String",
//						"mockup": "Init-Prompt",
//						"desc": ""
//					}
//				},
//				"docName": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I0LMCSC80",
//					"attrs": {
//						"type": "String",
//						"mockup": "FileName",
//						"desc": ""
//					}
//				},
//				"docPath": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I0N035I40",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				},
//				"docCode": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I0N374580",
//					"attrs": {
//						"type": "String",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				}
//			}
//		},
//		"globalMockup": {
//			"jaxId": "1I0IEGBJ15",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "aiseg",
//					"def": "brunch",
//					"jaxId": "1I0IEK7E30",
//					"attrs": {
//						"id": "HasPage",
//						"label": "New AI Seg",
//						"x": "85",
//						"y": "170",
//						"desc": "This is an AISeg.",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "Flag",
//						"context": {
//							"jaxId": "1I0IEK7E31",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0IEK7E32",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I0IEK7E33",
//							"attrs": {
//								"id": "Default",
//								"desc": "Outlet.",
//								"output": "",
//								"ouput": {
//									"valText": ""
//								}
//							},
//							"linkedSeg": "1I0KGKUT70"
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I0IEK7E34",
//									"attrs": {
//										"id": "NoPage",
//										"desc": "Outlet.",
//										"output": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I0IEK7E35",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I0IEK7E36",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#!targetPage",
//										"ouput": {
//											"valText": ""
//										}
//									},
//									"linkedSeg": "1I0IENUST0"
//								}
//							]
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1I0IEL3AE0",
//					"attrs": {
//						"id": "ShowData",
//						"label": "New AI Seg",
//						"x": "550",
//						"y": "220",
//						"desc": "This is an AISeg.",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0IEL3AE1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0IEL3AE2",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "Assistant",
//						"text": "#`Command: ${command}\nExecData：\n\\`\\`\\`\n${JSON.stringify(execData,null,\"\\t\")}\n\\`\\`\\`\nExecSteps:\n\\`\\`\\`\n${JSON.stringify(execSteps,null,\"\\t\")}\n\\`\\`\\`\n`",
//						"outlet": {
//							"jaxId": "1I0IEL3AE3",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0KL8KBP0"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "QueryPage",
//					"jaxId": "1I0IENUST0",
//					"attrs": {
//						"id": "QueryPage",
//						"label": "New AI Seg",
//						"x": "320",
//						"y": "155",
//						"desc": "This is an AISeg.",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0IENUST1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0IENUSU0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I0IENUSU1",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0IEL3AE0"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "askConfirm",
//					"jaxId": "1I0KLAEFQ0",
//					"attrs": {
//						"id": "QDescOK",
//						"label": "New AI Seg",
//						"x": "1260",
//						"y": "220",
//						"desc": "This is an AISeg.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"prompt": {
//							"type": "string",
//							"valText": "Does this function desVO need modify?",
//							"localize": {
//								"EN": "Does this function desVO need modify?",
//								"CN": "这个函数的descVO是否需要修改？"
//							},
//							"localizable": true
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1I0KLAEFA0",
//									"attrs": {
//										"id": "OK",
//										"desc": "Outlet.",
//										"text": "Code It",
//										"result": "",
//										"codes": "true",
//										"context": {
//											"jaxId": "1I0KLJDH96",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I0KLJDH97",
//											"attrs": {
//												"cast": ""
//											}
//										}
//									},
//									"linkedSeg": "1I0IEU6620"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1I0KLAEFA1",
//									"attrs": {
//										"id": "Modify",
//										"desc": "Outlet.",
//										"text": "Modify",
//										"result": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I0KLJDH98",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I0KLJDH99",
//											"attrs": {
//												"cast": ""
//											}
//										}
//									},
//									"linkedSeg": "1I0KL9RAO0"
//								}
//							]
//						},
//						"silent": "false"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "askChat",
//					"jaxId": "1I0IEU6620",
//					"attrs": {
//						"id": "AskName",
//						"label": "New AI Seg",
//						"x": "1490",
//						"y": "165",
//						"desc": "This is an AISeg.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0IEV6DD0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0IEV6DD1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"tip": "Please name your new API Agent doc",
//						"tipRole": "Assistant",
//						"placeholder": "",
//						"text": "#context.docName",
//						"file": "false",
//						"showText": "true",
//						"outlet": {
//							"jaxId": "1I0IEV6DA0",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0IF3QSC0"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "brunch",
//					"jaxId": "1I0IF3QSC0",
//					"attrs": {
//						"id": "CheckName",
//						"label": "New AI Seg",
//						"x": "1710",
//						"y": "165",
//						"desc": "This is an AISeg.",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0IF8STV0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0IF8STV1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I0IF8STR1",
//							"attrs": {
//								"id": "NameOK",
//								"desc": "Outlet.",
//								"output": ""
//							},
//							"linkedSeg": "1I0IFC2U70"
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I0IF8STR0",
//									"attrs": {
//										"id": "BadName",
//										"desc": "Outlet.",
//										"output": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I0IF8STV2",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I0IF8STV3",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#!input"
//									},
//									"linkedSeg": "1I0IF5KTR0"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I0V5M79U0",
//									"attrs": {
//										"id": "Overwrite",
//										"desc": "输出节点。",
//										"output": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I0V5M7A70",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I0V5M7A71",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "askOverwrite"
//									},
//									"linkedSeg": "1I0V5JLG10"
//								}
//							]
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1I0IF5KTR0",
//					"attrs": {
//						"id": "TipBadName",
//						"label": "New AI Seg",
//						"x": "1970",
//						"y": "70",
//						"desc": "This is an AISeg.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0IF8STV4",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0IF8STV5",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "Assistant",
//						"text": {
//							"type": "string",
//							"valText": "Invalid file name or already in use, please enter a new name",
//							"localize": {
//								"EN": "Invalid file name or already in use, please enter a new name",
//								"CN": "文件名不合法或者已被占用，请输入一个新的名字"
//							},
//							"localizable": true
//						},
//						"outlet": {
//							"jaxId": "1I0IF8STR2",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0IF8C810"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I0IF8C810",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "2125",
//						"y": "5",
//						"outlet": {
//							"jaxId": "1I0IF8STV6",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0KBN2JN0"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I0IF8H8N0",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "1525",
//						"y": "90",
//						"outlet": {
//							"jaxId": "1I0IF8STV7",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0IEU6620"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "callLLM",
//					"jaxId": "1I0IFC2U70",
//					"attrs": {
//						"id": "GenFunction",
//						"label": "New AI Seg",
//						"x": "1970",
//						"y": "310",
//						"desc": "Excute a LLM call.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "event.svg",
//						"context": {
//							"jaxId": "1I0IFCCG10",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0IFCCG11",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"platform": "\"OpenAI\"",
//						"mode": "gpt-4o",
//						"system": "#`\n### 你是一个强大的Javascript函数编写器。\n第一轮对话时，用户会输入一个记录了一次操控网页执行任务的JSON对象。  \n- command属性是任务的简单描述。  \n- execData属性是任务的执行参数。  \n- execSteps是完成这个任务的具体执行步骤内容JSON。\n---\n${actionDef}\n---\n- 请根据输入的JSON对象，设计，编写一个函数，用来生成执行同样任务的步骤。\n\n- 请用对象展开的模式定义函数参数。函数的参数应该是一个和execData属性结构相同对象。\n\n- 你的函数需要参考execSteps，生成完成任务的步骤数组。\n\n- 注意：如果execData中的某个属性是数组，可能需要用循环的方式来生成多个步骤。\n\n- 注意：请分析command、execData和execSteps，对于某些参数可能要进行合理性判断分析来生成或者跳过某些步骤。\n\n- 你的函数应该返回一个数组，里面包含的是要执行的步骤。\n\n---\n- 你编写的函数的函数名是${funcName}。\n\n- 你可以通过多轮与用户的对话来完善函数。\n\n- 在每轮对话时，你要用JSON格式回答，把完整的函数代码放在\"code\"属性里。例如：\n{\n\t\"code\":\"...function code generated...\",\n}\n\n- 如果完整实现这个函数需要一些额外的信息，你应该在JSON中增加question属性，例如：\n{\n\t\"code\":\"...\",\n    \"question\":\"需要考虑名字不合法的情况么？\"\n}\n\n- 如果用户表示要放弃编写，请在JSON则红添加stop属性，属性的内容是放弃编写的原因。例如：\n{\n\t\"code\":\"...\",\n    \"stop\":\"User abort.\"\n}\n\n`",
//						"temperature": "0",
//						"maxToken": "3800",
//						"topP": "1",
//						"fqcP": "0",
//						"prcP": "0",
//						"messages": {
//							"attrs": []
//						},
//						"prompt": "#context.initPrompt",
//						"seed": "",
//						"outlet": {
//							"jaxId": "1I0IFCCG00",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0IFEBGT0"
//						},
//						"secret": "false",
//						"allowCheat": "false",
//						"GPTCheats": {
//							"attrs": [
//								{
//									"type": "object",
//									"def": "GPTCheat",
//									"jaxId": "1I0V550B70",
//									"attrs": {
//										"prompt": "",
//										"reply": "{\n\t\"code\": \"function executeSearch({ search }) {\\n    // Define the steps array to hold all actions\\n    const steps = [];\\n\\n    // Step 1: Click on the search bar\\n    steps.push({\\n        execute: {\\n            desc: \\\"Click on the search bar\\\",\\n            action: \\\"Click\\\",\\n            queryHint: \\\"search bar\\\",\\n            willNavi: false,\\n            fileName: \\\"\\\"\\n        },\\n        result: null,\\n        abort: false\\n    });\\n\\n    // Step 2: Type the search query\\n    steps.push({\\n        execute: {\\n            desc: `Type the search query '${search}'`,\\n            action: \\\"Type\\\",\\n            content: `#\\n${search}`,\\n            willNavi: false,\\n            fileName: \\\"\\\"\\n        },\\n        result: null,\\n        abort: false\\n    });\\n\\n    // Step 3: Press the Enter key\\n    steps.push({\\n        execute: {\\n            desc: \\\"Press the Enter key to execute the search\\\",\\n            action: \\\"PressKey\\\",\\n            key: \\\"Enter\\\",\\n            willNavi: true\\n        },\\n        result: null,\\n        abort: false\\n    });\\n\\n    // Return the steps array\\n    return steps;\\n}\"\n}"
//									}
//								}
//							]
//						},
//						"shareChatName": "",
//						"keepChat": "20 messages",
//						"clearChat": "2",
//						"apiFiles": {
//							"attrs": []
//						},
//						"parallelFunction": "false",
//						"responseFormat": "json_object"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1I0IFEBGT0",
//					"attrs": {
//						"id": "ShowCode",
//						"label": "New AI Seg",
//						"x": "2230",
//						"y": "310",
//						"desc": "This is an AISeg.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0IFGUG00",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0IFGUG01",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "Assistant",
//						"text": "#`Current code:  \\n\\`\\`\\`\\n${input.code}\\n\\`\\`\\``",
//						"outlet": {
//							"jaxId": "1I0IFGUFS0",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0KGASH10"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "askConfirm",
//					"jaxId": "1I0IFF4JJ0",
//					"attrs": {
//						"id": "QModify",
//						"label": "New AI Seg",
//						"x": "2965",
//						"y": "325",
//						"desc": "This is an AISeg.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"prompt": "Please confirm",
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1I0IFF4J10",
//									"attrs": {
//										"id": "GenDoc",
//										"desc": "Outlet.",
//										"text": "Code is OK",
//										"result": "",
//										"codes": "true",
//										"context": {
//											"jaxId": "1I0IFGUG02",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I0IFGUG03",
//											"attrs": {
//												"cast": ""
//											}
//										}
//									},
//									"linkedSeg": "1I0IFN7B10"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1I0IFF4J11",
//									"attrs": {
//										"id": "Abort",
//										"desc": "Outlet.",
//										"text": "Abort",
//										"result": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I0IFGUG04",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I0IFGUG05",
//											"attrs": {
//												"cast": ""
//											}
//										}
//									},
//									"linkedSeg": "1I0IFMDDS0"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1I0IFF4J12",
//									"attrs": {
//										"id": "Modify",
//										"desc": "Outlet.",
//										"text": "Modify",
//										"result": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I0IFGUG06",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I0IFGUG07",
//											"attrs": {
//												"cast": ""
//											}
//										}
//									},
//									"linkedSeg": "1I0IFKNSP0"
//								}
//							]
//						},
//						"silent": "false"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "askChat",
//					"jaxId": "1I0IFKNSP0",
//					"attrs": {
//						"id": "AskFix",
//						"label": "New AI Seg",
//						"x": "3205",
//						"y": "395",
//						"desc": "This is an AISeg.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0IFNKT70",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0IFNKT71",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"tip": "Please enter advice to modify:",
//						"tipRole": "Assistant",
//						"placeholder": "",
//						"text": "",
//						"file": "false",
//						"showText": "true",
//						"outlet": {
//							"jaxId": "1I0IFNKT20",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0IFLMA30"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I0IFLMA30",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "3325",
//						"y": "465",
//						"outlet": {
//							"jaxId": "1I0IFNKT72",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0KGG3E90"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I0IFLV5P0",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "1995",
//						"y": "395",
//						"outlet": {
//							"jaxId": "1I0IFNKT73",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0IFC2U70"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I0IFMDDS0",
//					"attrs": {
//						"id": "AbortCode",
//						"label": "New AI Seg",
//						"x": "3205",
//						"y": "325",
//						"desc": "This is an AISeg.",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0IFNKT74",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0IFNKT75",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I0IFNKT21",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0IFOA600"
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "aiBot",
//					"jaxId": "1I0IFN7B10",
//					"attrs": {
//						"id": "GenDoc",
//						"label": "New AI Seg",
//						"x": "3205",
//						"y": "260",
//						"desc": "Call AI Agent, use it's output as result",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0IFNKT76",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0IFNKT77",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"source": "ai/GenTaskAgentDoc.js",
//						"argument": "{\"agentVO\":\"#context.descVO\",\"funcCode\":\"#context.docCode\",\"filePath\":\"#context.docPath\",\"hostName\":\"#hostName\",\"startURL\":\"#startURL\"}",
//						"secret": "false",
//						"outlet": {
//							"jaxId": "1I0IFNKT22",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0IFO26G0"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1I0IFO26G0",
//					"attrs": {
//						"id": "TipFin",
//						"label": "New AI Seg",
//						"x": "3445",
//						"y": "260",
//						"desc": "This is an AISeg.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0IFOHHB0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0IFOHHB1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "Assistant",
//						"text": "#input",
//						"outlet": {
//							"jaxId": "1I0IFOHHA0",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							}
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1I0IFOA600",
//					"attrs": {
//						"id": "TipAbort",
//						"label": "New AI Seg",
//						"x": "3445",
//						"y": "325",
//						"desc": "This is an AISeg.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0IFOHHB2",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0IFOHHB3",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "Assistant",
//						"text": "#input",
//						"outlet": {
//							"jaxId": "1I0IFOHHA1",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							}
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I0KBN2JN0",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "1715",
//						"y": "5",
//						"outlet": {
//							"jaxId": "1I0KBNCT20",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0IF8H8N0"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "brunch",
//					"jaxId": "1I0KGASH10",
//					"attrs": {
//						"id": "CheckQuestion",
//						"label": "New AI Seg",
//						"x": "2460",
//						"y": "310",
//						"desc": "This is an AISeg.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0KGEA660",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0KGEA661",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I0KGEA601",
//							"attrs": {
//								"id": "NoQ",
//								"desc": "Outlet.",
//								"output": ""
//							},
//							"linkedSeg": "1I0IFF4JJ0"
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I0KGEA600",
//									"attrs": {
//										"id": "HasQ",
//										"desc": "Outlet.",
//										"output": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I0KGEA662",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I0KGEA663",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#input.question"
//									},
//									"linkedSeg": "1I0KGEQA60"
//								}
//							]
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "askChat",
//					"jaxId": "1I0KGEQA60",
//					"attrs": {
//						"id": "AskQuestion",
//						"label": "New AI Seg",
//						"x": "2710",
//						"y": "260",
//						"desc": "This is an AISeg.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0KGH0DO0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0KGH0DO1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"tip": "#input.question",
//						"tipRole": "Assistant",
//						"placeholder": "",
//						"text": "",
//						"file": "false",
//						"showText": "true",
//						"outlet": {
//							"jaxId": "1I0KGH0DF0",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0KLQK170"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I0KGG3E90",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "2970",
//						"y": "465",
//						"outlet": {
//							"jaxId": "1I0KGH0DO2",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0KLQK170"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connectorL",
//					"jaxId": "1I0KGKUT70",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "325",
//						"y": "220",
//						"outlet": {
//							"jaxId": "1I0KGLUEP0",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0IEL3AE0"
//						},
//						"dir": "L2R"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "callLLM",
//					"jaxId": "1I0KL8KBP0",
//					"attrs": {
//						"id": "GenDesc",
//						"label": "New AI Seg",
//						"x": "820",
//						"y": "220",
//						"desc": "Excute a LLM call.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "check_fat.svg",
//						"context": {
//							"jaxId": "1I0KLJDH90",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0KLJDH91",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"platform": "\"OpenAI\"",
//						"mode": "gpt-4o",
//						"system": "你是负责设计网页RPA行为函数的AI。\n在第一轮对话时，用户给给你一个描述RPA任务例子的JSON对象，包括：\n- command属性是这个RPA例子任务的简单描述\n- execData是执行这个RPA任务例子时的参数列表对象\n- execSteps是这个例子中具体执行的RPA步骤\n\n根据这个例子JSON对象，设计一个的JS函数，请设计这个函数的名称和参数列表，以及返回值类型，用JSON返回设计内容。\n你可以和用户进行多轮对话，根据用户意见完善你的设计。\n\n-  你设计的函数的调用参数，应该与execData里的内容一致。\n\n- 每回合对话，你都应该返回设计函数的JSON，例如：\n{\n\t\"name\":\"sendSMS\",\n    \"desc\":\"use web page send a SMS to certain phone number\",\n    \"parameters\":{\n\t    \"type\": \"object\",\n\t    \"properties\":{\n\t    \t\"phoneNumber\":{\n            \t\"type\":\"string\",\n                \"description\":\"The phone number to send SMS\"\n            },\n\t    \t\"content\":{\n            \t\"type\":\"string\",\n                \"description\":\"The SMS content to send\"\n            }\n    \t}\n    },\n    \"result\":{\n\t    \"type\":\"boolean\",\n    \t\"description\":\"If send SMS success, return true, otherwise, reutrn false.\"\n    }\n}\n\n- 请保持简单直接的设计原则\n\t- 你设计的函数的调用参数尽量简洁，使用最直接的调用方法\n\t- 你设计的函数应该直接返回结果，不要进行成功/错误封装（如果出错就抛异常，不需要通过返回值体现）。\n",
//						"temperature": "0",
//						"maxToken": "2000",
//						"topP": "1",
//						"fqcP": "0",
//						"prcP": "0",
//						"messages": {
//							"attrs": []
//						},
//						"prompt": "#context.initPrompt",
//						"seed": "",
//						"outlet": {
//							"jaxId": "1I0KLJDH10",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0KL929D0"
//						},
//						"secret": "false",
//						"allowCheat": "false",
//						"GPTCheats": {
//							"attrs": [
//								{
//									"type": "object",
//									"def": "GPTCheat",
//									"jaxId": "1I0V2G0PJ0",
//									"attrs": {
//										"prompt": "",
//										"reply": "{\n\t\"name\": \"executeSearch\",\n\t\"desc\": \"Execute a search on a webpage using the given search query\",\n\t\"parameters\": {\n\t\t\"type\": \"object\",\n\t\t\"properties\": {\n\t\t\t\"search\": {\n\t\t\t\t\"type\": \"string\",\n\t\t\t\t\"description\": \"The search query to execute\"\n\t\t\t}\n\t\t},\n\t\t\"required\": [\n\t\t\t\"search\"\n\t\t]\n\t},\n\t\"result\": {\n\t\t\"type\": \"boolean\",\n\t\t\"description\": \"Returns true if the search was executed successfully, otherwise throws an error\"\n\t}\n}`"
//									}
//								}
//							]
//						},
//						"shareChatName": "",
//						"keepChat": "20 messages",
//						"clearChat": "2",
//						"apiFiles": {
//							"attrs": []
//						},
//						"parallelFunction": "false",
//						"responseFormat": "json_object"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1I0KL929D0",
//					"attrs": {
//						"id": "ShowDesc",
//						"label": "New AI Seg",
//						"x": "1035",
//						"y": "220",
//						"desc": "This is an AISeg.",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0KLJDH92",
//							"attrs": {
//								"cast": "{\"descVO\":\"input\",\"initPrompt\":\"\"}"
//							}
//						},
//						"global": {
//							"jaxId": "1I0KLJDH93",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "Assistant",
//						"text": {
//							"type": "string",
//							"valText": "#`Design JSON:\\n\\`\\`\\`\\n${JSON.stringify(input,null,\"\\t\")}\\`\\`\\`\\n`",
//							"localize": {
//								"EN": "#`Design JSON:\\n\\`\\`\\`\\n${JSON.stringify(input,null,\"\\t\")}\\`\\`\\`\\n`"
//							},
//							"localizable": true
//						},
//						"outlet": {
//							"jaxId": "1I0KLJDH20",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0KLAEFQ0"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "askChat",
//					"jaxId": "1I0KL9RAO0",
//					"attrs": {
//						"id": "AskFixDesc",
//						"label": "New AI Seg",
//						"x": "1490",
//						"y": "260",
//						"desc": "This is an AISeg.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0KLJDH94",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0KLJDH95",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"tip": {
//							"type": "string",
//							"valText": "Please provide suggestions for modification",
//							"localize": {
//								"EN": "Please provide suggestions for modification",
//								"CN": "请提供修改建议"
//							},
//							"localizable": true
//						},
//						"tipRole": "Assistant",
//						"placeholder": "",
//						"text": "",
//						"file": "false",
//						"showText": "true",
//						"outlet": {
//							"jaxId": "1I0KLJDH21",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0KLI39N0"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I0KLI39N0",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "1640",
//						"y": "330",
//						"outlet": {
//							"jaxId": "1I0KLJDH910",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0KLIBLR0"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I0KLIBLR0",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "850",
//						"y": "330",
//						"outlet": {
//							"jaxId": "1I0KLJDH911",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0KL8KBP0"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I0KLQK170",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "2860",
//						"y": "395",
//						"outlet": {
//							"jaxId": "1I0KLS0800",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0IFLV5P0"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "askConfirm",
//					"jaxId": "1I0V5JLG10",
//					"attrs": {
//						"id": "AskOverwrite",
//						"label": "New AI Seg",
//						"x": "1970",
//						"y": "165",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"prompt": {
//							"type": "string",
//							"valText": "The file already exists, do you want to overwrite it?",
//							"localize": {
//								"EN": "The file already exists, do you want to overwrite it?",
//								"CN": "文件已存在，是否覆盖？"
//							},
//							"localizable": true
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1I0V5JLFF0",
//									"attrs": {
//										"id": "Rename",
//										"desc": "输出节点。",
//										"text": {
//											"type": "string",
//											"valText": "Change Name",
//											"localize": {
//												"EN": "Change Name",
//												"CN": "换个名字"
//											},
//											"localizable": true
//										},
//										"result": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I0V5M7A72",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I0V5M7A73",
//											"attrs": {
//												"cast": ""
//											}
//										}
//									},
//									"linkedSeg": "1I0IF8C810"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1I0V5JLFG0",
//									"attrs": {
//										"id": "Overwrite",
//										"desc": "输出节点。",
//										"text": {
//											"type": "string",
//											"valText": "Overwrite",
//											"localize": {
//												"EN": "Overwrite",
//												"CN": "覆盖"
//											},
//											"localizable": true
//										},
//										"result": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I0V5M7A74",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I0V5M7A75",
//											"attrs": {
//												"cast": ""
//											}
//										}
//									},
//									"linkedSeg": "1I10D2CAO0"
//								}
//							]
//						},
//						"silent": "false"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I10D2CAO0",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "2135",
//						"y": "245",
//						"outlet": {
//							"jaxId": "1I10D3N2D0",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I10D2NPG0"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I10D2NPG0",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "2010",
//						"y": "245",
//						"outlet": {
//							"jaxId": "1I10D3N2D1",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I0IFC2U70"
//						},
//						"dir": "R2L"
//					}
//				}
//			]
//		},
//		"desc": "This is an AI agent.",
//		"exportAPI": "false",
//		"exportAddOn": "false",
//		"addOnOpts": ""
//	}
//}