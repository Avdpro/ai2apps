//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import pathLib from "/@path";
import inherits from "/@inherits";
import Base64 from "/@tabos/utils/base64.js";
import {trimJSON} from "/@aichat/utils.js";
/*#{1I5D2VJ3G0MoreImports*/
/*}#1I5D2VJ3G0MoreImports*/
const agentURL=(new URL(import.meta.url)).pathname;
const basePath=pathLib.dirname(agentURL);
const $ln=VFACT.lanCode||"EN";
const argsTemplate={
	properties:{
		"userName":{
			"name":"userName","type":"string",
			"defaultValue":"",
			"desc":"User name",
		}
	},
	/*#{1I5D2VJ3G0ArgsView*/
	/*}#1I5D2VJ3G0ArgsView*/
};

/*#{1I5D2VJ3G0StartDoc*/
/*}#1I5D2VJ3G0StartDoc*/
//----------------------------------------------------------------------------
let MockupUserInfo=async function(session){
	let userName;
	let context,globalContext;
	let self;
	let FixArgs,AskBtns,Mockup,AskMenu;
	/*#{1I5D2VJ3G0LocalVals*/
	/*}#1I5D2VJ3G0LocalVals*/
	
	function parseAgentArgs(input){
		if(typeof(input)=='object'){
			userName=input.userName;
		}else{
			userName=undefined;
		}
		/*#{1I5D2VJ3G0ParseArgs*/
		/*}#1I5D2VJ3G0ParseArgs*/
	}
	
	/*#{1I5D2VJ3G0PreContext*/
	/*}#1I5D2VJ3G0PreContext*/
	globalContext=session.globalContext;
	context={};
	context=VFACT.flexState(context);
	/*#{1I5D2VJ3G0PostContext*/
	/*}#1I5D2VJ3G0PostContext*/
	let agent,segs={};
	segs["FixArgs"]=FixArgs=async function(input){//:1I5D30OEI0
		let result=input;
		let missing=false;
		if(userName===undefined || userName==="") missing=true;
		if(missing){
			result=await session.pipeChat("/@aichat/ai/CompleteArgs.js",{"argsTemplate":argsTemplate,"command":input},false);
			parseAgentArgs(result);
		}
		return {seg:AskBtns,result:(result),preSeg:"1I5D30OEI0",outlet:"1I5D31UG50"};
	};
	FixArgs.jaxId="1I5D30OEI0"
	FixArgs.url="FixArgs@"+agentURL
	
	segs["AskBtns"]=AskBtns=async function(input){//:1I5OBJBAQ0
		let prompt=("Please confirm")||input;
		let silent=false;
		let countdown=undefined;
		let button1=("OK")||"OK";
		let button2=("Cancel")||"Cancel";
		let button3="";
		let result="";
		let value=0;
		if(silent){
			result="";
			return {seg:Mockup,result:(result),preSeg:"1I5OBJBAQ0",outlet:"1I5OBJBA60"};
		}
		[result,value]=await session.askUserRaw({type:"confirm",prompt:prompt,button1:button1,button2:button2,button3:button3,countdown:countdown});
		if(value===1){
			result=("")||result;
			return {seg:Mockup,result:(result),preSeg:"1I5OBJBAQ0",outlet:"1I5OBJBA60"};
		}
		result=("")||result;
		return {result:result};
	
	};
	AskBtns.jaxId="1I5OBJBAQ0"
	AskBtns.url="AskBtns@"+agentURL
	
	segs["Mockup"]=Mockup=async function(input){//:1I5D329IU0
		let result=input
		/*#{1I5D329IU0Code*/
		result={
			name:userName,age:25,gender:"male",rank:"Member",email:"mockup@mockup.com"
		};
		//result="Error: user not found.";
		//result="Please input your access token.";
		//throw Error("Error: user not found.");
		/*}#1I5D329IU0Code*/
		return {result:result};
	};
	Mockup.jaxId="1I5D329IU0"
	Mockup.url="Mockup@"+agentURL
	
	segs["AskMenu"]=AskMenu=async function(input){//:1I5OBK53U0
		let prompt=("Please confirm")||input;
		let countdown=undefined;
		let silent=false;
		let items=[
			{icon:"/~/-tabos/shared/assets/hudbox.svg",text:"Item 1",code:0},
			{icon:"/~/-tabos/shared/assets/hudbox.svg",text:"Item 2",code:1},
			{icon:"/~/-tabos/shared/assets/hudbox.svg",text:"Item 3",code:2},
		];
		let result="";
		let item=null;
		
		if(silent){
			result="";
			return {result:result};
		}
		[result,item]=await session.askUserRaw({type:"menu",prompt:prompt,multiSelect:false,items:items,withChat:false,countdown:countdown});
		if(item.code===0){
			return {result:result};
		}
		if(item.code===1){
			return {result:result};
		}
		if(item.code===2){
			return {result:result};
		}
	};
	AskMenu.jaxId="1I5OBK53U0"
	AskMenu.url="AskMenu@"+agentURL
	
	agent={
		isAIAgent:true,
		session:session,
		name:"MockupUserInfo",
		url:agentURL,
		autoStart:true,
		jaxId:"1I5D2VJ3G0",
		context:context,
		livingSeg:null,
		execChat:async function(input/*{userName}*/){
			let result;
			parseAgentArgs(input);
			/*#{1I5D2VJ3G0PreEntry*/
			/*}#1I5D2VJ3G0PreEntry*/
			result={seg:FixArgs,"input":input};
			/*#{1I5D2VJ3G0PostEntry*/
			/*}#1I5D2VJ3G0PostEntry*/
			return result;
		},
		/*#{1I5D2VJ3G0MoreAgentAttrs*/
		/*}#1I5D2VJ3G0MoreAgentAttrs*/
	};
	/*#{1I5D2VJ3G0PostAgent*/
	/*}#1I5D2VJ3G0PostAgent*/
	return agent;
};
/*#{1I5D2VJ3G0ExCodes*/
/*}#1I5D2VJ3G0ExCodes*/

export const ChatAPI=[{
	def:{
		name: "MockupUserInfo",
		description: "This is an AI agent that return user information by user name.",
		parameters:{
			type: "object",
			properties:{
				userName:{type:"string",description:"User name"}
			}
		}
	},
	agent: MockupUserInfo
}];

//:Export Edit-AddOn:
const DocAIAgentExporter=VFACT.classRegs.DocAIAgentExporter;
if(DocAIAgentExporter){
	const EditAttr=VFACT.classRegs.EditAttr;
	const EditAISeg=VFACT.classRegs.EditAISeg;
	const EditAISegOutlet=VFACT.classRegs.EditAISegOutlet;
	const SegObjShellAttr=EditAISeg.SegObjShellAttr;
	const SegOutletDef=EditAISegOutlet.SegOutletDef;
	const docAIAgentExporter=DocAIAgentExporter.prototype;
	const packExtraCodes=docAIAgentExporter.packExtraCodes;
	const packResult=docAIAgentExporter.packResult;
	const varNameRegex = /^[a-zA-Z_$][a-zA-Z0-9_$]*$/;
	
	EditAISeg.regDef({
		name:"MockupUserInfo",showName:"MockupUserInfo",icon:"agent.svg",catalog:["AI Call"],
		attrs:{
			...SegObjShellAttr,
			"userName":{name:"userName",type:"string",key:1,fixed:1,initVal:""},
			"outlet":{name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc"}
		},
		listHint:["id","userName","codes","desc"],
		desc:"This is an AI agent that return user information by user name."
	});
	
	DocAIAgentExporter.segTypeExporters["MockupUserInfo"]=
	function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let exportDebug=this.isExportDebug();
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();coder.newLine();
		{
			coder.packText(`let result,args={};`);coder.newLine();
			coder.packText("args['userName']=");this.genAttrStatement(seg.getAttr("userName"));coder.packText(";");coder.newLine();
			this.packExtraCodes(coder,seg,"PreCodes");
			coder.packText(`result= await session.pipeChat("/~/aae/ai/MockupUserInfo.js",args,false);`);coder.newLine();
			this.packExtraCodes(coder,seg,"PostCodes");
			this.packResult(coder,seg,seg.outlet);
		}
		coder.indentLess();coder.maybeNewLine();
		coder.packText(`};`);coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		coder.newLine();
	};
}
/*#{1I5D2VJ3G0PostDoc*/
/*}#1I5D2VJ3G0PostDoc*/


export default MockupUserInfo;
export{MockupUserInfo};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DocAIAgent",
//	"jaxId": "1I5D2VJ3G0",
//	"attrs": {
//		"editObjs": {
//			"jaxId": "1I5D2VJ3H0",
//			"attrs": {
//				"MockupUserInfo": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1I5D2VJ3H6",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1I5D2VJ3H7",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1I5D2VJ3H8",
//							"attrs": {}
//						},
//						"functions": {
//							"jaxId": "1I5D2VJ3H9",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false"
//					},
//					"mockups": {}
//				}
//			}
//		},
//		"agent": {
//			"jaxId": "1I5D2VJ3H1",
//			"attrs": {}
//		},
//		"entry": "",
//		"autoStart": "true",
//		"debug": "true",
//		"apiArgs": {
//			"jaxId": "1I5D2VJ3H2",
//			"attrs": {
//				"userName": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I5D31UGA0",
//					"attrs": {
//						"type": "String",
//						"mockup": "\"\"",
//						"desc": "User name"
//					}
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1I5D2VJ3H3",
//			"attrs": {}
//		},
//		"context": {
//			"jaxId": "1I5D2VJ3H4",
//			"attrs": {}
//		},
//		"globalMockup": {
//			"jaxId": "1I5D2VJ3H5",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "aiseg",
//					"def": "fixArgs",
//					"jaxId": "1I5D30OEI0",
//					"attrs": {
//						"id": "FixArgs",
//						"label": "New AI Seg",
//						"x": "115",
//						"y": "185",
//						"desc": "This is an AISeg.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"outlet": {
//							"jaxId": "1I5D31UG50",
//							"attrs": {
//								"id": "Next",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I5OBJBAQ0"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "askConfirm",
//					"jaxId": "1I5OBJBAQ0",
//					"attrs": {
//						"id": "AskBtns",
//						"label": "New AI Seg",
//						"x": "320",
//						"y": "185",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"prompt": "Please confirm",
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1I5OBJBA60",
//									"attrs": {
//										"id": "OK",
//										"desc": "输出节点。",
//										"text": "OK",
//										"result": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I5S5SLRP0",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I5S5SLRP1",
//											"attrs": {
//												"cast": ""
//											}
//										}
//									},
//									"linkedSeg": "1I5D329IU0"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1I5OBJBA61",
//									"attrs": {
//										"id": "Cancel",
//										"desc": "输出节点。",
//										"text": "Cancel",
//										"result": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I5S5SLRP2",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I5S5SLRP3",
//											"attrs": {
//												"cast": ""
//											}
//										}
//									}
//								}
//							]
//						},
//						"silent": "false"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I5D329IU0",
//					"attrs": {
//						"id": "Mockup",
//						"label": "New AI Seg",
//						"x": "550",
//						"y": "170",
//						"desc": "This is an AISeg.",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I5D33SDK0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I5D33SDK1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I5D32I7V0",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							}
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "askMenu",
//					"jaxId": "1I5OBK53U0",
//					"attrs": {
//						"id": "AskMenu",
//						"label": "New AI Seg",
//						"x": "450",
//						"y": "445",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"prompt": "Please confirm",
//						"multi": "false",
//						"withChat": "false",
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1I5OBK5390",
//									"attrs": {
//										"id": "Item1",
//										"desc": "输出节点。",
//										"text": "Item 1",
//										"result": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I5S5SLRP4",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I5S5SLRP5",
//											"attrs": {
//												"cast": ""
//											}
//										}
//									}
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1I5OBK5391",
//									"attrs": {
//										"id": "Item2",
//										"desc": "输出节点。",
//										"text": "Item 2",
//										"result": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I5S5SLRP6",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I5S5SLRP7",
//											"attrs": {
//												"cast": ""
//											}
//										}
//									}
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1I5OBK5392",
//									"attrs": {
//										"id": "Item3",
//										"desc": "输出节点。",
//										"text": "Item 3",
//										"result": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I5S5SLRP8",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I5S5SLRP9",
//											"attrs": {
//												"cast": ""
//											}
//										}
//									}
//								}
//							]
//						},
//						"silent": "false"
//					}
//				}
//			]
//		},
//		"desc": "This is an AI agent that return user information by user name.",
//		"exportAPI": "true",
//		"exportAddOn": "true",
//		"addOnOpts": ""
//	}
//}