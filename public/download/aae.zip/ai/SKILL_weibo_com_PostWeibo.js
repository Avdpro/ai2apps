export default function postWeibo({ text, photos }) {
    const steps = [];

    // Step 1: Click on the Weibo input box
    steps.push({
        execute: {
            desc: "点击发布微博的输入框。",
            action: "Click",
            queryHint: "发布微博的输入框",
            willNavi: false,
            fileName: ""
        },
        result: null,
        abort: false
    });

    // Step 2: Type the Weibo text
    steps.push({
        execute: {
            desc: "输入微博内容",
            action: "Type",
            content: `${text}`,
            willNavi: false,
            fileName: ""
        },
        result: null,
        abort: false
    });

    // Step 3: Upload each photo
    for (let i = 0; i < photos.length; i++) {
        steps.push({
            execute: {
                desc: `上传第${i + 1}张图片`,
                action: "ClickUpload",
                queryHint: "图片上传输入框",
                willNavi: false,
                fileName: `#${photos[i]}`
            },
            result: null,
            abort: false
        });
    }

    return steps;
}
export const SkillDef={
	"host": "weibo_com",
	"startURL": "https://weibo.com/",
	"name": "postWeibo",
	"desc": "发布微博，包含文字和图片。",
	"parameters": {
		"type": "object",
		"properties": {
			"text": {
				"type": "string",
				"description": "微博内容"
			},
			"photos": {
				"type": "array",
				"items": {
					"type": "string",
					"description": "图片文件路径"
				},
				"description": "需要上传的图片文件路径列表"
			}
		},
		"required": [
			"text",
			"photos"
		]
	},
	"result": {
		"type": "boolean",
		"description": "如果微博发布成功，返回true，否则抛出异常。"
	}
};