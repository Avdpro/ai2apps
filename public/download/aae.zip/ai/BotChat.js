//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import pathLib from "/@path";
import inherits from "/@inherits";
import Base64 from "/@tabos/utils/base64.js";
import {trimJSON} from "/@aichat/utils.js";
/*#{1I2RN5R900MoreImports*/
import {appCfg} from "../cfg/appCfg.js";
import {AAUser} from "../AAUser.js";
import {AAFileLib} from "../AAFileLib.js";
import {BoxAAChatMessage} from "../ui/BoxAAChatMessage.js";
import {BoxAAChatLogs} from "../ui/BoxAAChatLogs.js";
/*}#1I2RN5R900MoreImports*/
const agentURL=(new URL(import.meta.url)).pathname;
const basePath=pathLib.dirname(agentURL);
const $ln=VFACT.lanCode||"EN";
const argsTemplate={
	properties:{
		"botId":{
			"name":"botId","type":"auto",
			"defaultValue":"",
			"desc":"",
		},
		"userId":{
			"name":"userId","type":"auto",
			"defaultValue":"",
			"desc":"",
		},
		"password":{
			"name":"password","type":"auto",
			"defaultValue":"",
			"desc":"",
		},
		"chatFlow":{
			"name":"chatFlow","type":"auto",
			"defaultValue":"",
			"desc":"",
		},
		"showAsk":{
			"name":"showAsk","type":"bool",
			"defaultValue":"",
			"desc":"",
		},
		"logThreshold":{
			"name":"logThreshold","type":"integer",
			"defaultValue":2,
			"desc":"",
		}
	},
	/*#{1I2RN5R900ArgsView*/
	/*}#1I2RN5R900ArgsView*/
};

/*#{1I2RN5R900StartDoc*/
const cfgColor=appCfg.color;
const chatIconFix={
	iconBorderColor:cfgColor["fontBodyLit"],
	iconBG:cfgColor.body,
	iconColor:cfgColor.fontBodySub,
	iconCorner:100,
};
/*}#1I2RN5R900StartDoc*/
//----------------------------------------------------------------------------
let BotChat=async function(session){
	let botId,userId,password,chatFlow,showAsk,logThreshold;
	let context,globalContext;
	let self;
	let TipStart,Start,WaitInput,SendMsg,ShowPic;
	let msgLength=0;
	let newMessages=[];
	let user=undefined;
	
	/*#{1I2RN5R900LocalVals*/
	async function showChatMsg(msg){
		let msgType,from,role,msgText,assets,fileLib,text
		console.log("[BotChat.js] Get message:");
		console.log(msg);
		msgType=msg.type;
		chatFlow=msg.chatFlow;
		from=msg.from;
		role=msg.from===user.id?"user":"assistant";
		if(msgType==="Ask"){
			let askType,askVO,func,result,prompt;
			askVO=msg.askVO;
			askType=msg.askType;
			if(showAsk){
				if(session.ui[askType]){
					let replyVO;
					prompt=askVO.prompt|askVO.text;
					if(chatFlow){
						askVO.prompt=`[${chatFlow}?${msg.askId}]:\n${prompt}`;
					}else{
						askVO.prompt=`[?${msg.askId}]:\n${prompt}`;
					}
					Object.assign(askVO,chatIconFix);
					result=await session.ui[askType](askVO);
					console.log("Ask result:");
					console.log(result);
					replyVO={
						type:"ReplyAsk",
						to:msg.from,
						askId:msg.askId,
						askReq:msg.askReq,
						chatFlow:chatFlow,
						result:result
					};
					await user.sendMessage(replyVO);
				}else{
					console.log("Ask error:");
					console.Error(`Missing askType: ${askType}`);
				}
				//TODO: reply ask:
			}
		}else if(msgType==="ReplyAsk"){
			if(session.addAAChatMessage){
				//await session.addAAChatMessage(msg);
			}else{
				//TODO: Code this:
			}
	
		}else{
			msgText=msg.content;
			msgText=msgText.text||msgText.result||msgText;
			assets=msg.content.assets;
			fileLib=globalContext.fileLib;
			if(session.addAAChatMessage){
				switch(msg.type){
					case "User":
					case "Chat":{
						await session.addAAChatMessage(msg);
						if(chatFlow && msg.from!==user.id){
							if((!msg.chatFlowFinish) && chatFlow!==msg.id){
								session.askChatInput({type:"input",placeholder:"",maybeText:`[${chatFlow}]\n`,waitInput:false});
							}
						}
						break;
					}
					case "Ask":{
						await session.addAAChatMessage(msg);
						session.askChatInput({type:"input",placeholder:"",maybeText:`[${chatFlow}-${msg.askId}]\n`,waitInput:false});
					}
				}
			}else{
				if(chatFlow && msg.from!==user.id){
					if(msg.chatFlowFinish){
						text=`[ChatFlow: ${chatFlow}, finished]  \n`;
					}else if(chatFlow===msg.id){
						text=`[ChatFlow: ${chatFlow}, created]  \n`;
					}else{
						text=`[ChatFlow: ${chatFlow}, continue]  \n`;
						session.askChatInput({type:"input",placeholder:"",maybeText:`[${chatFlow}]\n`,waitInput:false});
					}
					text+=msgText;
				}else{
					if(chatFlow){
						if(msg.chatFlowFinish){
							text=`[ChatFlow: ${chatFlow}, finished]  \n`;
						}else if(chatFlow===msg.id){
							text=`[ChatFlow: ${chatFlow}, created]  \n`;
						}else{
							text=`[ChatFlow: ${chatFlow}, continue]  \n`;
						}
						text+=msgText;
					}else{
						text=msgText;
					}
				}
				if(text instanceof Object){
				}
				await session.addChatText(role,text);
				if(assets){
					let asset,ext;
					for(asset of assets){
						ext=pathLib.extname(asset).toLowerCase();
						switch(ext){
							case ".jpg":
							case ".jpeg":
							case ".gif":
							case ".png":{
								let dataURL;
								if(asset.startsWith("hub://")&&fileLib){
									dataURL=await fileLib.readDataURL(asset);
									await ShowPic({label:(($ln==="CN")?("附件: "):/*EN*/("Attachment: "))+asset,url:dataURL});
								}else if(asset.startsWith("data:")||asset.startsWith("http://")||asset.startsWith("https://")){
									await ShowPic({label:(($ln==="CN")?("附件: "):/*EN*/("Attachment: "))+asset,url:asset});
								}else{
									text="附件: "+asset;
									await session.addChatText(role,text);
								}
								break;
							}
							default:{
								text="附件: "+asset;
								await session.addChatText(role,text);
							}
						}
					}
					//TODO: deal with assets (images, files, etc):
				}
			}
		}
	}
	
	async function showMessages(messages){
		let msg,lastTime;
		lastTime=user.lastMsgTime;
		for(msg of messages){
			if(msg.time>lastTime){
				await showChatMsg(msg);
			}
		}
		if(msg){
			user.lastMsgTime=msg.time;
		}
	}
	
	function showLogs(logs){
		let ui,blk,log;
		if(!Array.isArray(logs)){
			logs=[logs];
		}
		ui=session.ui;
		blk=ui.lastChild;
		for(log of logs){
			if(log.visibility>=logThreshold){
				if(blk && blk.addLog){
					blk.addLog(log);
				}else{
					blk=ui.appendChatBlock(null,BoxAAChatLogs(log));
				}
			}
	
		}
	}
	/*}#1I2RN5R900LocalVals*/
	
	function parseAgentArgs(input){
		if(typeof(input)=='object'){
			botId=input.botId;
			userId=input.userId;
			password=input.password;
			chatFlow=input.chatFlow;
			showAsk=input.showAsk;
			logThreshold=input.logThreshold;
		}else{
			botId=undefined;
			userId=undefined;
			password=undefined;
			chatFlow=undefined;
			showAsk=undefined;
			logThreshold=undefined;
		}
		/*#{1I2RN5R900ParseArgs*/
		/*}#1I2RN5R900ParseArgs*/
	}
	
	/*#{1I2RN5R900PreContext*/
	/*}#1I2RN5R900PreContext*/
	globalContext=session.globalContext;
	context={};
	context=VFACT.flexState(context);
	/*#{1I2RN5R900PostContext*/
	/*}#1I2RN5R900PostContext*/
	let agent,segs={};
	segs["TipStart"]=TipStart=async function(input){//:1I2RN5VFH0
		let result=input;
		let role="assistant";
		let content=input;
		session.addChatText(role,content);
		return {seg:Start,result:(result),preSeg:"1I2RN5VFH0",outlet:"1I2RN9R5K0"};
	};
	TipStart.jaxId="1I2RN5VFH0"
	TipStart.url="TipStart@"+agentURL
	
	segs["Start"]=Start=async function(input){//:1I2RN6BHT0
		let result=input
		/*#{1I2RN6BHT0Code*/
		session.addAAChatMessage=async function(chatMsg){
			let def;
			def=BoxAAChatMessage(session,user,chatMsg,true);
			session.ui.appendChatBlock(chatMsg,def);
		};
		
		if(!globalContext.fileLib){
			globalContext.fileLib=new AAFileLib();
		}
		botId=botId||"BOT_MASTER";
		if(!userId){
			userId="admin";
		}
		if(typeof(userId)==="string"){
			user=new AAUser();
			await user.login(userId,password);
			user.startMessageClient();
		}else{
			user=userId;
		}
		user.onNotify("GetLog",()=>{
			let logs;
			logs=[...user.logs];
			user.logs.splice(0);
			showLogs(logs);
		});
		user.onNotify("GetMessage",()=>{
			let messages,msg;
			messages=[...user.messages];
			user.messages.splice(0);
			showMessages(messages);
		});
		user.onNotify("Disconnected",()=>{
			session.addChatText("system",`Server disconnected.`);
		});
		/*}#1I2RN6BHT0Code*/
		return {seg:WaitInput,result:(result),preSeg:"1I2RN6BHT0",outlet:"1I2RN9R5K1"};
	};
	Start.jaxId="1I2RN6BHT0"
	Start.url="Start@"+agentURL
	
	segs["WaitInput"]=WaitInput=async function(input){//:1I2RN7QRO0
		let tip=("");
		let tipRole=("assistant");
		let placeholder=("");
		let text=("");
		let result="";
		if(tip){
			session.addChatText(tipRole,tip);
		}
		result=await session.askChatInput({type:"input",placeholder:placeholder,text:text});
		return {seg:SendMsg,result:(result),preSeg:"1I2RN7QRO0",outlet:"1I2RN9R5K2"};
	};
	WaitInput.jaxId="1I2RN7QRO0"
	WaitInput.url="WaitInput@"+agentURL
	
	segs["SendMsg"]=SendMsg=async function(input){//:1I2UEPQQT0
		let result=input
		/*#{1I2UEPQQT0Code*/
		let msgVO,flow,askId,text,match;
		const regex = /^\[\d+\]/;
		const regex2 = /^\[\d+-\d+\]/;
		text=input;
		match=text.match(regex2);
		if(match){
			let lead,index;
			lead=match[0];
			flow=lead.substring(1,lead.length-1);
			text=text.substring(lead.length).trim();
			index=flow.indexOf("-");
			askId=flow.substring(index+1);
			flow=flow.substring(index);
		}else{
			match=text.match(regex);
			if(match){
				let lead;
				lead=match[0];
				flow=lead.substring(1,lead.length-1);
				text=text.substring(lead.length).trim();
			}
		}
		if(askId){
			msgVO={
				from:user.id,to:botId,type:"ReplyAsk",content:text,askId:askId
			};
		}else{
			msgVO={
				from:user.id,to:botId,type:"User",content:text
			};
		}
		if(flow){
			msgVO.chatFlow=flow;
		}
		user.sendMessage(msgVO);
		/*}#1I2UEPQQT0Code*/
		return {seg:WaitInput,result:(result),preSeg:"1I2UEPQQT0",outlet:"1I2UEQG3C0"};
	};
	SendMsg.jaxId="1I2UEPQQT0"
	SendMsg.url="SendMsg@"+agentURL
	
	segs["ShowPic"]=ShowPic=async function(input){//:1I5LFT8MP0
		let result=input;
		let role="assistant";
		let content=input.label;
		session.addChatText(role,content,{image:input.url});
		return {result:result};
	};
	ShowPic.jaxId="1I5LFT8MP0"
	ShowPic.url="ShowPic@"+agentURL
	
	agent={
		isAIAgent:true,
		session:session,
		name:"BotChat",
		url:agentURL,
		autoStart:true,
		jaxId:"1I2RN5R900",
		context:context,
		livingSeg:null,
		execChat:async function(input/*{botId,userId,password,chatFlow,showAsk,logThreshold}*/){
			let result;
			parseAgentArgs(input);
			/*#{1I2RN5R900PreEntry*/
			/*}#1I2RN5R900PreEntry*/
			result={seg:TipStart,"input":input};
			/*#{1I2RN5R900PostEntry*/
			/*}#1I2RN5R900PostEntry*/
			return result;
		},
		/*#{1I2RN5R900MoreAgentAttrs*/
		/*}#1I2RN5R900MoreAgentAttrs*/
	};
	/*#{1I2RN5R900PostAgent*/
	/*}#1I2RN5R900PostAgent*/
	return agent;
};
/*#{1I2RN5R900ExCodes*/
/*}#1I2RN5R900ExCodes*/

/*#{1I2RN5R900PostDoc*/
/*}#1I2RN5R900PostDoc*/


export default BotChat;
export{BotChat};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DocAIAgent",
//	"jaxId": "1I2RN5R900",
//	"attrs": {
//		"editObjs": {
//			"jaxId": "1I2RN5R901",
//			"attrs": {
//				"BotChat": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1I2RN5R910",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1I2RN5R911",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1I2RN5R912",
//							"attrs": {}
//						},
//						"functions": {
//							"jaxId": "1I2RN5R913",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false"
//					},
//					"mockups": {}
//				}
//			}
//		},
//		"agent": {
//			"jaxId": "1I2RN5R902",
//			"attrs": {}
//		},
//		"entry": "",
//		"autoStart": "true",
//		"debug": "true",
//		"apiArgs": {
//			"jaxId": "1I2RN5R903",
//			"attrs": {
//				"botId": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I2UCJSMU0",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				},
//				"userId": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I3CH4J7L0",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				},
//				"password": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I3CH4J7L1",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				},
//				"chatFlow": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I5SD4FAM0",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				},
//				"showAsk": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I5SD4FAM1",
//					"attrs": {
//						"type": "Boolean",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				},
//				"logThreshold": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I6BUURHO0",
//					"attrs": {
//						"type": "Integer",
//						"mockup": "2",
//						"desc": ""
//					}
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1I2RN5R904",
//			"attrs": {
//				"msgLength": {
//					"type": "int",
//					"valText": "0"
//				},
//				"newMessages": {
//					"type": "auto",
//					"valText": "[]"
//				},
//				"user": {
//					"type": "auto",
//					"valText": ""
//				}
//			}
//		},
//		"context": {
//			"jaxId": "1I2RN5R905",
//			"attrs": {}
//		},
//		"globalMockup": {
//			"jaxId": "1I2RN5R906",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1I2RN5VFH0",
//					"attrs": {
//						"id": "TipStart",
//						"label": "New AI Seg",
//						"x": "100",
//						"y": "225",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I2RN9R5L0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I2RN9R5L1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "Assistant",
//						"text": "#input",
//						"outlet": {
//							"jaxId": "1I2RN9R5K0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I2RN6BHT0"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I2RN6BHT0",
//					"attrs": {
//						"id": "Start",
//						"label": "New AI Seg",
//						"x": "310",
//						"y": "225",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I2RN9R5L2",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I2RN9R5L3",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I2RN9R5K1",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I2RN7QRO0"
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "askChat",
//					"jaxId": "1I2RN7QRO0",
//					"attrs": {
//						"id": "WaitInput",
//						"label": "New AI Seg",
//						"x": "510",
//						"y": "225",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I2RN9R5L4",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I2RN9R5L5",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"tip": "",
//						"tipRole": "Assistant",
//						"placeholder": "",
//						"text": "",
//						"file": "false",
//						"showText": "false",
//						"outlet": {
//							"jaxId": "1I2RN9R5K2",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I2UEPQQT0"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I2RN9E9E0",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "540",
//						"y": "145",
//						"outlet": {
//							"jaxId": "1I2RN9R5L6",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I2RN7QRO0"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I2UEPQQT0",
//					"attrs": {
//						"id": "SendMsg",
//						"label": "New AI Seg",
//						"x": "730",
//						"y": "225",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I2UEQG3H0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I2UEQG3H1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I2UEQG3C0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I2UEQ79D0"
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I2UEQ79D0",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "865",
//						"y": "145",
//						"outlet": {
//							"jaxId": "1I2UEQG3H2",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I2RN9E9E0"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "image",
//					"jaxId": "1I5LFT8MP0",
//					"attrs": {
//						"id": "ShowPic",
//						"label": "New AI Seg",
//						"x": "310",
//						"y": "330",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I5LFT8MQ0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I5LFT8MQ1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"text": "#input.label",
//						"image": "#input.url",
//						"role": "Assistant",
//						"sizeLimit": "",
//						"format": "JEPG",
//						"outlet": {
//							"jaxId": "1I5LFT8MQ2",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							}
//						}
//					}
//				}
//			]
//		},
//		"desc": "这是一个AI智能体。",
//		"exportAPI": "false",
//		"exportAddOn": "false",
//		"addOnOpts": ""
//	}
//}