//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import pathLib from "/@path";
import inherits from "/@inherits";
import Base64 from "/@tabos/utils/base64.js";
import {trimJSON} from "/@aichat/utils.js";
import {AAFarm} from "/@aae/aafarm.js";
/*#{1I1QFEHQL0MoreImports*/
/*}#1I1QFEHQL0MoreImports*/
const agentURL=(new URL(import.meta.url)).pathname;
const basePath=pathLib.dirname(agentURL);
const $ln=VFACT.lanCode||"EN";
const argsTemplate={
	properties:{
		"url":{
			"name":"url","type":"auto",
			"defaultValue":"",
			"desc":"要读取的URL",
		},
		"request":{
			"name":"request","type":"auto",
			"defaultValue":"",
			"desc":"用户问题或指令",
		}
	},
	/*#{1I1QFEHQL0ArgsView*/
	/*}#1I1QFEHQL0ArgsView*/
};

/*#{1I1QFEHQL0StartDoc*/
/*}#1I1QFEHQL0StartDoc*/
//----------------------------------------------------------------------------
let ReadPage=async function(session){
	let url,request;
	let context,globalContext;
	let self;
	let FixArgs,StartAAF,OpenBrowser,OpenPage,ReadHTML,TipNoAAF,ClosePage,RunLLM;
	/*#{1I1QFEHQL0LocalVals*/
	/*}#1I1QFEHQL0LocalVals*/
	
	function parseAgentArgs(input){
		if(typeof(input)=='object'){
			url=input.url;
			request=input.request;
		}else{
			url=undefined;
			request=undefined;
		}
		/*#{1I1QFEHQL0ParseArgs*/
		/*}#1I1QFEHQL0ParseArgs*/
	}
	
	/*#{1I1QFEHQL0PreContext*/
	/*}#1I1QFEHQL0PreContext*/
	globalContext=session.globalContext;
	context={};
	context=VFACT.flexState(context);
	/*#{1I1QFEHQL0PostContext*/
	/*}#1I1QFEHQL0PostContext*/
	let agent,segs={};
	segs["FixArgs"]=FixArgs=async function(input){//:1I2477RAB0
		let result=input;
		let missing=false;
		if(url===undefined || url==="") missing=true;
		if(request===undefined || request==="") missing=true;
		if(missing){
			result=await session.pipeChat("/@aichat/ai/CompleteArgs.js",{"argsTemplate":argsTemplate,"command":input},false);
			parseAgentArgs(result);
		}
		return {seg:StartAAF,result:(result),preSeg:"1I2477RAB0",outlet:"1I2478HP40"};
	};
	FixArgs.jaxId="1I2477RAB0"
	FixArgs.url="FixArgs@"+agentURL
	
	segs["StartAAF"]=StartAAF=async function(input){//:1I1QFR73G0
		let result=true;
		let aiQuery=true;
		try{
			context.aaFarm=new AAFarm();
			aiQuery && (await context.aaFarm.setupAIQuery(session,context,basePath,"1I1QFR73G0"));
		}catch(err){
			return {seg:TipNoAAF,result:(err),preSeg:"1I1QFR73G0",outlet:"1I1QFSE3K2",catchSeg:TipNoAAF,catchlet:"1I1QFSE3K2"};
		}
		return {seg:OpenBrowser,result:(result),preSeg:"1I1QFR73G0",outlet:"1I1QFSE3J0"};
	};
	StartAAF.jaxId="1I1QFR73G0"
	StartAAF.url="StartAAF@"+agentURL
	
	segs["OpenBrowser"]=OpenBrowser=async function(input){//:1I1QFS54K0
		let result=true;
		let browser=null;
		let headless=false;
		let devtools=false;
		let dataDir=false;
		let alias="AAHOME";
		context.aaBrowser=browser=await context.aaFarm.openBrowser(alias,{headless,devtools,autoDataDir:dataDir});
		context.aaHostPage=browser.hostPage;
		return {seg:OpenPage,result:(result),preSeg:"1I1QFS54K0",outlet:"1I1QFSE3J1"};
	};
	OpenBrowser.jaxId="1I1QFS54K0"
	OpenBrowser.url="OpenBrowser@"+agentURL
	
	segs["OpenPage"]=OpenPage=async function(input){//:1I1QFSKFR0
		let pageVal="aaPage";
		let $url=url;
		let $waitBefore=0;
		let $waitAfter=1000;
		let $width=1200;
		let $height=1900;
		let $userAgent="";
		let page=null;
		$waitBefore && (await sleep($waitBefore));
		context[pageVal]=page=await context.aaBrowser.newPage();
		($width && $height) && (await page.setViewport({width:$width,height:$height}));
		$userAgent && (await page.setUserAgent($userAgent));
		await page.goto($url);
		$waitAfter && (await sleep($waitAfter));
		return {seg:ReadHTML,result:(page),preSeg:"1I1QFSKFR0",outlet:"1I1QFSSHG0"};
	};
	OpenPage.jaxId="1I1QFSKFR0"
	OpenPage.url="OpenPage@"+agentURL
	
	segs["ReadHTML"]=ReadHTML=async function(input){//:1I1QFU05F0
		let result=null;
		let pageVal="aaPage";
		let $target="cleanHTML";
		let $node=null;
		let $options={"compact":3,"cleanMarks":true};
		let $waitBefore=0;
		let $waitAfter=0;
		let page=context[pageVal];
		$waitBefore && (await sleep($waitBefore));
		switch($target){
			case "cleanHTML":
				result=await page.readInnerHTML($node,{compact:2,...$options});
				break;
			case "html":
				result=await page.readInnerHTML($node,{...$options});
				break;
			case "view":
				result=await page.readView($node,{...$options});
				break;
			case "text":
				result=await page.readInnerText($node,{...$options});
				break;
			case "article":
				result=await page.readArticle($node,{...$options});
				break;
		}$waitAfter && (await sleep($waitAfter))
		return {seg:ClosePage,result:(result),preSeg:"1I1QFU05F0",outlet:"1I1QFVH520"};
	};
	ReadHTML.jaxId="1I1QFU05F0"
	ReadHTML.url="ReadHTML@"+agentURL
	
	segs["TipNoAAF"]=TipNoAAF=async function(input){//:1I1QGG5K90
		let result=input;
		let role="assistant";
		let content=input;
		session.addChatText(role,content);
		return {result:result};
	};
	TipNoAAF.jaxId="1I1QGG5K90"
	TipNoAAF.url="TipNoAAF@"+agentURL
	
	segs["ClosePage"]=ClosePage=async function(input){//:1I1RHVC7V0
		let result=input;
		let pageVal="aaPage";
		let waitBefore=0;
		let waitAfter=0;
		let page=context[pageVal];
		waitBefore && (await sleep(waitBefore));
		await page.close();
		waitAfter && (await sleep(waitAfter))
		return {seg:RunLLM,result:(result),preSeg:"1I1RHVC7V0",outlet:"1I1RHVI140"};
	};
	ClosePage.jaxId="1I1RHVC7V0"
	ClosePage.url="ClosePage@"+agentURL
	
	segs["RunLLM"]=RunLLM=async function(input){//:1I20G4PQV0
		let prompt;
		let result;
		
		let opts={
			platform:"OpenAI",
			mode:"gpt-4o",
			maxToken:2000,
			temperature:0,
			topP:1,
			fqcP:0,
			prcP:0,
			secret:false,
			responseFormat:"text"
		};
		let chatMem=RunLLM.messages
		let seed="";
		if(seed!==undefined){opts.seed=seed;}
		let messages=[
			{role:"system",content:`
你是一个分析网页内容，回答用的问题或者完成用户指定的任务
当前网页内容：
\`\`\`html
${input}
\`\`\`
`},
		];
		prompt=`${request?request:"总结一下当前网页内容"}`;
		if(prompt!==null){
			messages.push({role:"user",content:prompt});
		}
		result=await session.callSegLLM("RunLLM@"+agentURL,opts,messages,true);
		return {result:result};
	};
	RunLLM.jaxId="1I20G4PQV0"
	RunLLM.url="RunLLM@"+agentURL
	
	agent={
		isAIAgent:true,
		session:session,
		name:"ReadPage",
		url:agentURL,
		autoStart:true,
		jaxId:"1I1QFEHQL0",
		context:context,
		livingSeg:null,
		execChat:async function(input/*{url,request}*/){
			let result;
			parseAgentArgs(input);
			/*#{1I1QFEHQL0PreEntry*/
			/*}#1I1QFEHQL0PreEntry*/
			result={seg:FixArgs,"input":input};
			/*#{1I1QFEHQL0PostEntry*/
			/*}#1I1QFEHQL0PostEntry*/
			return result;
		},
		/*#{1I1QFEHQL0MoreAgentAttrs*/
		/*}#1I1QFEHQL0MoreAgentAttrs*/
	};
	/*#{1I1QFEHQL0PostAgent*/
	/*}#1I1QFEHQL0PostAgent*/
	return agent;
};
/*#{1I1QFEHQL0ExCodes*/
/*}#1I1QFEHQL0ExCodes*/

export const ChatAPI=[{
	def:{
		name: "ReadPage",
		description: "arguments：{url}, {request}\nRead given {url}'s web page's html content. And extract conent or answer question by {request}",
		parameters:{
			type: "object",
			properties:{
				url:{type:"auto",description:"要读取的URL"},
				request:{type:"auto",description:"用户问题或指令"}
			}
		}
	},
	label: "ReadHTML",
	agent: ReadPage
}];

//:Export Edit-AddOn:
const DocAIAgentExporter=VFACT.classRegs.DocAIAgentExporter;
if(DocAIAgentExporter){
	const EditAttr=VFACT.classRegs.EditAttr;
	const EditAISeg=VFACT.classRegs.EditAISeg;
	const EditAISegOutlet=VFACT.classRegs.EditAISegOutlet;
	const SegObjShellAttr=EditAISeg.SegObjShellAttr;
	const SegOutletDef=EditAISegOutlet.SegOutletDef;
	const docAIAgentExporter=DocAIAgentExporter.prototype;
	const packExtraCodes=docAIAgentExporter.packExtraCodes;
	const packResult=docAIAgentExporter.packResult;
	const varNameRegex = /^[a-zA-Z_$][a-zA-Z0-9_$]*$/;
	
	EditAISeg.regDef({
		name:"ReadPage",showName:"ReadHTML",icon:"agent.svg",catalog:["AI Call"],
		attrs:{
			...SegObjShellAttr,
			"url":{name:"url",type:"auto",key:1,fixed:1,initVal:""},
			"request":{name:"request",type:"auto",key:1,fixed:1,initVal:""},
			"outlet":{name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc"}
		},
		listHint:["id","url","request","codes","desc"],
		desc:"arguments：{url}, {request}\nRead given {url}'s web page's html content. And extract conent or answer question by {request}"
	});
	
	DocAIAgentExporter.segTypeExporters["ReadPage"]=
	function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let exportDebug=this.isExportDebug();
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();coder.newLine();
		{
			coder.packText(`let result,args={};`);coder.newLine();
			coder.packText("args['url']=");this.genAttrStatement(seg.getAttr("url"));coder.packText(";");coder.newLine();
			coder.packText("args['request']=");this.genAttrStatement(seg.getAttr("request"));coder.packText(";");coder.newLine();
			this.packExtraCodes(coder,seg,"PreCodes");
			coder.packText(`result= await session.pipeChat("/~/aae/ai/ReadPage.js",args,false);`);coder.newLine();
			this.packExtraCodes(coder,seg,"PostCodes");
			this.packResult(coder,seg,seg.outlet);
		}
		coder.indentLess();coder.maybeNewLine();
		coder.packText(`};`);coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		coder.newLine();
	};
}
/*#{1I1QFEHQL0PostDoc*/
/*}#1I1QFEHQL0PostDoc*/


export default ReadPage;
export{ReadPage};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DocAIAgent",
//	"jaxId": "1I1QFEHQL0",
//	"attrs": {
//		"editObjs": {
//			"jaxId": "1I1QFEHQL1",
//			"attrs": {
//				"ReadPage": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1I1QFEHQL7",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1I1QFEHQL8",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1I1QFEHQL9",
//							"attrs": {}
//						},
//						"functions": {
//							"jaxId": "1I1QFEHQL10",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false"
//					},
//					"mockups": {}
//				}
//			}
//		},
//		"agent": {
//			"jaxId": "1I1QFEHQL2",
//			"attrs": {}
//		},
//		"entry": "FixArgs",
//		"autoStart": "true",
//		"debug": "true",
//		"apiArgs": {
//			"jaxId": "1I1QFEHQL3",
//			"attrs": {
//				"url": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I1QFH2SE0",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "\"\"",
//						"desc": "要读取的URL"
//					}
//				},
//				"request": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I20GB6MJ0",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "\"\"",
//						"desc": "用户问题或指令"
//					}
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1I1QFEHQL4",
//			"attrs": {}
//		},
//		"context": {
//			"jaxId": "1I1QFEHQL5",
//			"attrs": {}
//		},
//		"globalMockup": {
//			"jaxId": "1I1QFEHQL6",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "aiseg",
//					"def": "fixArgs",
//					"jaxId": "1I2477RAB0",
//					"attrs": {
//						"id": "FixArgs",
//						"label": "New AI Seg",
//						"x": "90",
//						"y": "215",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"outlet": {
//							"jaxId": "1I2478HP40",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1QFR73G0"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "AAFStart",
//					"jaxId": "1I1QFR73G0",
//					"attrs": {
//						"id": "StartAAF",
//						"label": "New AI Seg",
//						"x": "300",
//						"y": "215",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I1QFSE3K0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1QFSE3K1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I1QFSE3J0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1QFS54K0"
//						},
//						"catchlet": {
//							"jaxId": "1I1QFSE3K2",
//							"attrs": {
//								"id": "NoAAE",
//								"desc": "输出节点。",
//								"output": "",
//								"codes": "false",
//								"context": {
//									"jaxId": "1I1QFSE3K3",
//									"attrs": {
//										"cast": ""
//									}
//								},
//								"global": {
//									"jaxId": "1I1QFSE3K4",
//									"attrs": {
//										"cast": ""
//									}
//								}
//							},
//							"linkedSeg": "1I1QGG5K90"
//						},
//						"aiQuery": "true"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "AAFOpenBrowser",
//					"jaxId": "1I1QFS54K0",
//					"attrs": {
//						"id": "OpenBrowser",
//						"label": "New AI Seg",
//						"x": "535",
//						"y": "200",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I1QFSE3K5",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1QFSE3K6",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"alias": "AAHOME",
//						"headless": "false",
//						"devtools": "false",
//						"dataDir": "false",
//						"outlet": {
//							"jaxId": "1I1QFSE3J1",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1QFSKFR0"
//						},
//						"run": ""
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "AAFOpenPage",
//					"jaxId": "1I1QFSKFR0",
//					"attrs": {
//						"id": "OpenPage",
//						"label": "New AI Seg",
//						"x": "785",
//						"y": "200",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I1QFSSHH0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1QFSSHH1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"valName": "aaPage",
//						"url": "#url",
//						"vpWidth": "1200",
//						"vpHeight": "1900",
//						"userAgent": "",
//						"waitBefore": "0",
//						"waitAfter": "1000",
//						"outlet": {
//							"jaxId": "1I1QFSSHG0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1QFU05F0"
//						},
//						"run": ""
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "AAFReadPage",
//					"jaxId": "1I1QFU05F0",
//					"attrs": {
//						"id": "ReadHTML",
//						"label": "New AI Seg",
//						"x": "1020",
//						"y": "200",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "flag.svg",
//						"context": {
//							"jaxId": "1I1QFVH540",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1QFVH541",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"page": "aaPage",
//						"target": "CleanHTML",
//						"node": "null",
//						"options": "{\"compact\":3,\"cleanMarks\":true}",
//						"waitBefore": "0",
//						"waitAfter": "0",
//						"outlet": {
//							"jaxId": "1I1QFVH520",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1RHVC7V0"
//						},
//						"run": ""
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1I1QGG5K90",
//					"attrs": {
//						"id": "TipNoAAF",
//						"label": "New AI Seg",
//						"x": "535",
//						"y": "305",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "flag.svg",
//						"context": {
//							"jaxId": "1I1QGGJPN0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1QGGJPN1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "Assistant",
//						"text": "#input",
//						"outlet": {
//							"jaxId": "1I1QGGJPM0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							}
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "AAFClosePage",
//					"jaxId": "1I1RHVC7V0",
//					"attrs": {
//						"id": "ClosePage",
//						"label": "New AI Seg",
//						"x": "1265",
//						"y": "200",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I1RHVI160",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1RHVI161",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"page": "aaPage",
//						"waitBefore": "0",
//						"waitAfter": "0",
//						"outlet": {
//							"jaxId": "1I1RHVI140",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I20G4PQV0"
//						},
//						"run": ""
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "callLLM",
//					"jaxId": "1I20G4PQV0",
//					"attrs": {
//						"id": "RunLLM",
//						"label": "New AI Seg",
//						"x": "1500",
//						"y": "200",
//						"desc": "执行一次LLM调用。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I20GAEGA0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I20GAEGA1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"platform": "\"OpenAI\"",
//						"mode": "gpt-4o",
//						"system": "#`\n你是一个分析网页内容，回答用的问题或者完成用户指定的任务\n当前网页内容：\n\\`\\`\\`html\n${input}\n\\`\\`\\`\n`",
//						"temperature": "0",
//						"maxToken": "2000",
//						"topP": "1",
//						"fqcP": "0",
//						"prcP": "0",
//						"messages": {
//							"attrs": []
//						},
//						"prompt": "#`${request?request:\"总结一下当前网页内容\"}`",
//						"seed": "",
//						"outlet": {
//							"jaxId": "1I20GAEG60",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							}
//						},
//						"secret": "false",
//						"allowCheat": "false",
//						"GPTCheats": {
//							"attrs": [
//								{
//									"type": "object",
//									"def": "GPTCheat",
//									"jaxId": "1I20IQKMM0",
//									"attrs": {
//										"prompt": "",
//										"reply": "英国大选结束"
//									}
//								}
//							]
//						},
//						"shareChatName": "",
//						"keepChat": "No",
//						"clearChat": "2",
//						"apiFiles": {
//							"attrs": []
//						},
//						"parallelFunction": "false",
//						"responseFormat": "text"
//					}
//				}
//			]
//		},
//		"desc": "arguments：{url}, {request}\nRead given {url}'s web page's html content. And extract conent or answer question by {request}",
//		"exportAPI": "true",
//		"exportAddOn": "true",
//		"addOnOpts": "{\"name\":\"\",\"label\":\"ReadHTML\",\"path\":\"\",\"isRPA\":false,\"rpaHost\":\"\",\"segIcon\":\"\",\"catalog\":\"AI Call\"}"
//	}
//}