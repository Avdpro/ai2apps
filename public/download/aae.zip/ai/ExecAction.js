//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import pathLib from "/@path";
import inherits from "/@inherits";
import Base64 from "/@tabos/utils/base64.js";
import {trimJSON} from "/@aichat/utils.js";
/*#{1I0F8V5V80MoreImports*/
/*}#1I0F8V5V80MoreImports*/
const agentURL=(new URL(import.meta.url)).pathname;
const baseURL=pathLib.dirname(agentURL);
const basePath=baseURL.startsWith("file://")?decodeURI(baseURL):baseURL;
const $ln=VFACT.lanCode||"EN";
const argsTemplate={
	properties:{
		"targetPage":{
			"name":"targetPage","type":"auto",
			"defaultValue":"",
			"desc":"",
		},
		"execData":{
			"name":"execData","type":"auto",
			"defaultValue":"",
			"desc":"",
		},
		"action":{
			"name":"action","type":"auto",
			"defaultValue":"",
			"desc":"",
		}
	},
	/*#{1I0F8V5V80ArgsView*/
	/*}#1I0F8V5V80ArgsView*/
};

/*#{1I0F8V5V80StartDoc*/
function compileText(text,execData){
	let func;
	if(text[0]!=="#"){
		return text;
	}
	try{
		func=new Function("execData","return `"+text.substring(1)+"`;");
		return func(execData);
	}catch(err){
		throw Error("Text format error!");
	}
}
/*}#1I0F8V5V80StartDoc*/
//----------------------------------------------------------------------------
let ExecAction=async function(session){
	let targetPage,execData,action;
	const $ln=session.language||"EN";
	let context,globalContext=session.globalContext;
	let self;
	let CheckNavi,FlagNavi,CheckFile,FlagFile,SwitchAction,LogError,IsHandleNavi,HandleNavi,IsHandleFile,WaitFileDlg,HandleFile,ActionEnd,DoClick,DoHover,DoType,DoKeyPress,DoGoto,Execute,ShowError,ReportError,FlagNT,WaitNT;
	/*#{1I0F8V5V80LocalVals*/
	/*}#1I0F8V5V80LocalVals*/
	
	function parseAgentArgs(input){
		if(typeof(input)=='object'){
			targetPage=input.targetPage;
			execData=input.execData;
			action=input.action;
		}else{
			targetPage=undefined;
			execData=undefined;
			action=undefined;
		}
		/*#{1I0F8V5V80ParseArgs*/
		/*}#1I0F8V5V80ParseArgs*/
	}
	
	/*#{1I0F8V5V80PreContext*/
	/*}#1I0F8V5V80PreContext*/
	context={};
	context=VFACT.flexState(context);
	/*#{1I0F8V5V80PostContext*/
	/*}#1I0F8V5V80PostContext*/
	let $agent,agent,segs={};
	segs["CheckNavi"]=CheckNavi=async function(input){//:1I0F95HS30
		let result=input;
		/*#{1I0F95HS30Start*/
		context.aaPage=targetPage;
		/*}#1I0F95HS30Start*/
		if(action.willNavi){
			return {seg:FlagNavi,result:(input),preSeg:"1I0F95HS30",outlet:"1I0FA7HK60"};
		}
		result=action;
		/*#{1I0F95HS30Post*/
		/*}#1I0F95HS30Post*/
		return {seg:CheckFile,result:(result),preSeg:"1I0F95HS30",outlet:"1I0FA7HK61"};
	};
	CheckNavi.jaxId="1I0F95HS30"
	CheckNavi.url="CheckNavi@"+agentURL
	
	segs["FlagNavi"]=FlagNavi=async function(input){//:1I0F97EME0
		let result=true;
		let pageVal="aaPage";
		let $action="navi";
		let $flag="WaitNavi";
		let $query="";
		let $queryHint="";
		let $waitBefore=0;
		let $waitAfter=0;
		let $options={};
		let page=context[pageVal];
		$waitBefore && (await sleep($waitBefore));
		switch($action){
			case "navi":
			case "networkidle":
			case "dialog":
			case "filechooser":
			default:
				page.waitFor($flag,$action,$options);
				break;
			case "query":
				$query=$queryHint?(await page.confirmQuery($query,$queryHint,"1I0F97EME0")):$query;
				if(!$query) throw Error("Missing query. Query hint: "+$queryHint);
				page.waitForQuery($flag,$query,$options);
				break;
			case "function":
				page.waitForFunction($flag,$query,$options);
				break;
		}$waitAfter && (await sleep($waitAfter))
		return {seg:CheckFile,result:(result),preSeg:"1I0F97EME0",outlet:"1I0FA7HK62"};
	};
	FlagNavi.jaxId="1I0F97EME0"
	FlagNavi.url="FlagNavi@"+agentURL
	
	segs["CheckFile"]=CheckFile=async function(input){//:1I0F98BRR0
		let result=input;
		if(!!action.fileName){
			return {seg:FlagFile,result:(input),preSeg:"1I0F98BRR0",outlet:"1I0FA7HK63"};
		}
		return {seg:SwitchAction,result:(result),preSeg:"1I0F98BRR0",outlet:"1I0FA7HK64"};
	};
	CheckFile.jaxId="1I0F98BRR0"
	CheckFile.url="CheckFile@"+agentURL
	
	segs["FlagFile"]=FlagFile=async function(input){//:1I0F9B3320
		let result=true;
		let pageVal="aaPage";
		let $action="filechooser";
		let $flag="WaitFile";
		let $query="";
		let $queryHint="";
		let $waitBefore=0;
		let $waitAfter=0;
		let $options={};
		let page=context[pageVal];
		$waitBefore && (await sleep($waitBefore));
		switch($action){
			case "navi":
			case "networkidle":
			case "dialog":
			case "filechooser":
			default:
				page.waitFor($flag,$action,$options);
				break;
			case "query":
				$query=$queryHint?(await page.confirmQuery($query,$queryHint,"1I0F9B3320")):$query;
				if(!$query) throw Error("Missing query. Query hint: "+$queryHint);
				page.waitForQuery($flag,$query,$options);
				break;
			case "function":
				page.waitForFunction($flag,$query,$options);
				break;
		}$waitAfter && (await sleep($waitAfter))
		return {seg:SwitchAction,result:(result),preSeg:"1I0F9B3320",outlet:"1I0FA7HK65"};
	};
	FlagFile.jaxId="1I0F9B3320"
	FlagFile.url="FlagFile@"+agentURL
	
	segs["SwitchAction"]=SwitchAction=async function(input){//:1I0F9C2F30
		let result=input;
		if(action.action==="Click"){
			return {seg:DoClick,result:(input),preSeg:"1I0F9C2F30",outlet:"1I0FA7HK66"};
		}
		if(action.action==="ClickUpload"){
			return {seg:DoClick,result:(input),preSeg:"1I0F9C2F30",outlet:"1I0H5BT7V0"};
		}
		if(action.action==="Hover"){
			return {seg:DoHover,result:(input),preSeg:"1I0F9C2F30",outlet:"1I0F9JKOE0"};
		}
		if(action.action==="Type"){
			return {seg:DoType,result:(input),preSeg:"1I0F9C2F30",outlet:"1I0F9D8I90"};
		}
		if(action.action==="PressKey"){
			return {seg:DoKeyPress,result:(input),preSeg:"1I0F9C2F30",outlet:"1I0F9DQ190"};
		}
		if(action.action==="Goto"){
			return {seg:DoGoto,result:(input),preSeg:"1I0F9C2F30",outlet:"1I0F9G97G0"};
		}
		return {seg:LogError,result:(result),preSeg:"1I0F9C2F30",outlet:"1I0FA7HK67"};
	};
	SwitchAction.jaxId="1I0F9C2F30"
	SwitchAction.url="SwitchAction@"+agentURL
	
	segs["LogError"]=LogError=async function(input){//:1I0F9M77B0
		let result=input
		/*#{1I0F9M77B0Code*/
		/*}#1I0F9M77B0Code*/
		return {result:result};
	};
	LogError.jaxId="1I0F9M77B0"
	LogError.url="LogError@"+agentURL
	
	segs["IsHandleNavi"]=IsHandleNavi=async function(input){//:1I0F9N4GC0
		let result=input;
		if(input.willNavi){
			return {seg:HandleNavi,result:(input),preSeg:"1I0F9N4GC0",outlet:"1I0F9Q5R03"};
		}
		return {seg:IsHandleFile,result:(result),preSeg:"1I0F9N4GC0",outlet:"1I0F9Q5R02"};
	};
	IsHandleNavi.jaxId="1I0F9N4GC0"
	IsHandleNavi.url="IsHandleNavi@"+agentURL
	
	segs["HandleNavi"]=HandleNavi=async function(input){//:1I0F9PLM90
		let result=true;
		let pageVal="aaPage";
		let $flag="WaitNavi";
		let $waitBefore=0;
		let $waitAfter=0;
		let page=context[pageVal];
		$waitBefore && (await sleep($waitBefore));
		await page.awaitFor($flag);
		$waitAfter && (await sleep($waitAfter))
		return {seg:IsHandleFile,result:(result),preSeg:"1I0F9PLM90",outlet:"1I0FA7HK70"};
	};
	HandleNavi.jaxId="1I0F9PLM90"
	HandleNavi.url="HandleNavi@"+agentURL
	
	segs["IsHandleFile"]=IsHandleFile=async function(input){//:1I0F9Q64C0
		let result=input;
		if(action.fileName){
			return {seg:WaitFileDlg,result:(input),preSeg:"1I0F9Q64C0",outlet:"1I0F9Q64C4"};
		}
		return {seg:ActionEnd,result:(result),preSeg:"1I0F9Q64C0",outlet:"1I0F9Q64C3"};
	};
	IsHandleFile.jaxId="1I0F9Q64C0"
	IsHandleFile.url="IsHandleFile@"+agentURL
	
	segs["WaitFileDlg"]=WaitFileDlg=async function(input){//:1I0F9RS3S0
		let result=true;
		let pageVal="aaPage";
		let $flag="WaitFile";
		let $waitBefore=0;
		let $waitAfter=0;
		let page=context[pageVal];
		$waitBefore && (await sleep($waitBefore));
		await page.awaitFor($flag);
		$waitAfter && (await sleep($waitAfter))
		return {seg:HandleFile,result:(result),preSeg:"1I0F9RS3S0",outlet:"1I0FA7HK71"};
	};
	WaitFileDlg.jaxId="1I0F9RS3S0"
	WaitFileDlg.url="WaitFileDlg@"+agentURL
	
	segs["HandleFile"]=HandleFile=async function(input){//:1I0F9T4EV0
		let result=true;
		let $pageVal="aaPage";
		let $action="accept";
		let $text="";
		let $fileName=compileText(action.fileName,execData);
		let $waitBefore=0;
		let $waitAfter=0;
		let $page=context[$pageVal];
		$waitBefore && (await sleep($waitBefore));
		/*#{1I0F9T4EV0PreCodes*/
		/*}#1I0F9T4EV0PreCodes*/
		if($action==="accept"){
			await $page.acceptDialog($text,$fileName?[$fileName]:null);
		}else{
			await $page.dissmissDialog();
		}
		$waitAfter && (await sleep($waitAfter))
		/*#{1I0F9T4EV0PostCodes*/
		result="Upload file success, step done."
		/*}#1I0F9T4EV0PostCodes*/
		return {seg:FlagNT,result:(result),preSeg:"1I0F9T4EV0",outlet:"1I0FA7HK72"};
	};
	HandleFile.jaxId="1I0F9T4EV0"
	HandleFile.url="HandleFile@"+agentURL
	
	segs["ActionEnd"]=ActionEnd=async function(input){//:1I0F9URGM0
		let result=input
		/*#{1I0F9URGM0Code*/
		/*}#1I0F9URGM0Code*/
		return {result:result};
	};
	ActionEnd.jaxId="1I0F9URGM0"
	ActionEnd.url="ActionEnd@"+agentURL
	
	segs["DoClick"]=DoClick=async function(input){//:1I0F9VSV20
		let result=true;
		let pageVal="aaPage";
		let $action="Click";
		let $query="";
		let $queryHint=action.queryHint;
		let $x=0;
		let $y=0;
		let $options=null;
		let $waitBefore=0;
		let $waitAfter=0;
		let page=context[pageVal];
		$waitBefore && (await sleep($waitBefore));
		/*#{1I0F9VSV20PreCodes*/
		/*}#1I0F9VSV20PreCodes*/
		switch($action){
			case "Click":
				if($query||$queryHint){
					$query=$queryHint?(await page.confirmQuery($query,$queryHint,"1I0F9VSV20")):$query;
					if(!$query) throw Error("Missing query. Query hint: "+$queryHint);
					await page.clickOn("::-p-xpath"+$query,{...$options,offset:((!!$x) || (!!$y))?{x:$x||0,y:$y||0}:undefined});
				}else{
					await page.mouseClick($x,$y,$options||{});
				}
				break;
			case "Tap":
				if($query||$queryHint){
					$query=$queryHint?(await page.confirmQuery($query,$queryHint,"1I0F9VSV20")):$query;
					if(!$query) throw Error("Missing query. Query hint: "+$queryHint);
					await page.tapOn("::-p-xpath"+$query);
				}else{
					await page.touchTap($x,$y);
				}
				break;
			case "MouseMove":
				await page.mouseMove($x,$y,$options||{});
				break;
			case "MouseDown":
				await page.mouseDown($options||{});
				break;
			case "MouseUp":
				await page.mouseUp($options||{});
				break;
			case "MouseReset":
				await page.mouseReset();
				break;
			case "TouchStart":
				await page.touchStart($x,$y);
				break;
			case "TouchMove":
				await page.touchStart($x,$y);
				break;
			case "TouchEnd":
				await page.touchEnd();
				break;
		}
		$waitAfter && (await sleep($waitAfter))
		/*#{1I0F9VSV20PostCodes*/
		result="Click action execute success."
		/*}#1I0F9VSV20PostCodes*/
		return {seg:IsHandleNavi,result:(result),preSeg:"1I0F9VSV20",outlet:"1I0FA7HK74"};
	};
	DoClick.jaxId="1I0F9VSV20"
	DoClick.url="DoClick@"+agentURL
	
	segs["DoHover"]=DoHover=async function(input){//:1I0FA1OPR0
		let result=true;
		let pageVal="aaPage";
		let $action="MouseMove";
		let $query=input.query;
		let $queryHint=action.queryHint;
		let $x=0;
		let $y=0;
		let $options=null;
		let $waitBefore=0;
		let $waitAfter=0;
		let page=context[pageVal];
		$waitBefore && (await sleep($waitBefore));
		/*#{1I0FA1OPR0PreCodes*/
		/*}#1I0FA1OPR0PreCodes*/
		switch($action){
			case "Click":
				if($query||$queryHint){
					$query=$queryHint?(await page.confirmQuery($query,$queryHint,"1I0FA1OPR0")):$query;
					if(!$query) throw Error("Missing query. Query hint: "+$queryHint);
					await page.clickOn("::-p-xpath"+$query,{...$options,offset:((!!$x) || (!!$y))?{x:$x||0,y:$y||0}:undefined});
				}else{
					await page.mouseClick($x,$y,$options||{});
				}
				break;
			case "Tap":
				if($query||$queryHint){
					$query=$queryHint?(await page.confirmQuery($query,$queryHint,"1I0FA1OPR0")):$query;
					if(!$query) throw Error("Missing query. Query hint: "+$queryHint);
					await page.tapOn("::-p-xpath"+$query);
				}else{
					await page.touchTap($x,$y);
				}
				break;
			case "MouseMove":
				await page.mouseMove($x,$y,$options||{});
				break;
			case "MouseDown":
				await page.mouseDown($options||{});
				break;
			case "MouseUp":
				await page.mouseUp($options||{});
				break;
			case "MouseReset":
				await page.mouseReset();
				break;
			case "TouchStart":
				await page.touchStart($x,$y);
				break;
			case "TouchMove":
				await page.touchStart($x,$y);
				break;
			case "TouchEnd":
				await page.touchEnd();
				break;
		}
		$waitAfter && (await sleep($waitAfter))
		/*#{1I0FA1OPR0PostCodes*/
		result="Hover action execute success."
		/*}#1I0FA1OPR0PostCodes*/
		return {seg:IsHandleNavi,result:(result),preSeg:"1I0FA1OPR0",outlet:"1I0FA7HK75"};
	};
	DoHover.jaxId="1I0FA1OPR0"
	DoHover.url="DoHover@"+agentURL
	
	segs["DoType"]=DoType=async function(input){//:1I0FA3GTB0
		let result=true;
		let pageVal="aaPage";
		let $action="Type";
		let $query="";
		let $queryHint=action.queryHint;
		let $key=compileText(action.content,execData);
		let $options=null;
		let $waitBefore=0;
		let $waitAfter=0;
		let page=context[pageVal];
		$waitBefore && (await sleep($waitBefore));
		/*#{1I0FA3GTB0PreCodes*/
		/*}#1I0FA3GTB0PreCodes*/
		switch($action){
			case "Type":
				if($query||$queryHint){
					$query=$queryHint?(await page.confirmQuery($query,$queryHint,"1I0FA3GTB0")):$query;
					if(!$query) throw Error("Missing query. Query hint: "+$queryHint);
					await page.typeOn("::-p-xpath"+$query,$key,$options||{});
				}else{
					await page.keyboardType($key,$options||{});
				}
				break;
			case "KeyPress":
				await page.keyboardPress($key,$options||{});
				break;
			case "KeyDown":
				await page.keyboardDown($key,$options||{});
				break;
			case "KeyUp":
				await page.keyboardUp($key,$options||{});
				break;
		}$waitAfter && (await sleep($waitAfter))
		/*#{1I0FA3GTB0PostCodes*/
		result="Type action execute success.";
		/*}#1I0FA3GTB0PostCodes*/
		return {seg:IsHandleNavi,result:(result),preSeg:"1I0FA3GTB0",outlet:"1I0FA7HK76"};
	};
	DoType.jaxId="1I0FA3GTB0"
	DoType.url="DoType@"+agentURL
	
	segs["DoKeyPress"]=DoKeyPress=async function(input){//:1I0FA4UH50
		let result=true;
		let pageVal="aaPage";
		let $action="KeyPress";
		let $query="";
		let $queryHint=action.queryHint;
		let $key=action.key;
		let $options=null;
		let $waitBefore=0;
		let $waitAfter=0;
		let page=context[pageVal];
		$waitBefore && (await sleep($waitBefore));
		/*#{1I0FA4UH50PreCodes*/
		/*}#1I0FA4UH50PreCodes*/
		switch($action){
			case "Type":
				if($query||$queryHint){
					$query=$queryHint?(await page.confirmQuery($query,$queryHint,"1I0FA4UH50")):$query;
					if(!$query) throw Error("Missing query. Query hint: "+$queryHint);
					await page.typeOn("::-p-xpath"+$query,$key,$options||{});
				}else{
					await page.keyboardType($key,$options||{});
				}
				break;
			case "KeyPress":
				await page.keyboardPress($key,$options||{});
				break;
			case "KeyDown":
				await page.keyboardDown($key,$options||{});
				break;
			case "KeyUp":
				await page.keyboardUp($key,$options||{});
				break;
		}$waitAfter && (await sleep($waitAfter))
		/*#{1I0FA4UH50PostCodes*/
		result="PressKey action execute success."
		/*}#1I0FA4UH50PostCodes*/
		return {seg:IsHandleNavi,result:(result),preSeg:"1I0FA4UH50",outlet:"1I0FA7HK77"};
	};
	DoKeyPress.jaxId="1I0FA4UH50"
	DoKeyPress.url="DoKeyPress@"+agentURL
	
	segs["DoGoto"]=DoGoto=async function(input){//:1I0FAVBP90
		let result=true;
		let pageVal="aaPage";
		let waitBefore=0;
		let waitAfter=0;
		let url=action.url;
		let page=context[pageVal];
		waitBefore && (await sleep(waitBefore));
		/*#{1I0FAVBP90PreCodes*/
		/*}#1I0FAVBP90PreCodes*/
		await page.goto(url,{});
		waitAfter && (await sleep(waitAfter))
		/*#{1I0FAVBP90PostCodes*/
		result="Goto action execute success."
		/*}#1I0FAVBP90PostCodes*/
		return {seg:IsHandleNavi,result:(result),preSeg:"1I0FAVBP90",outlet:"1I0FB2M7M0"};
	};
	DoGoto.jaxId="1I0FAVBP90"
	DoGoto.url="DoGoto@"+agentURL
	
	segs["Execute"]=Execute=async function(input){//:1I0GE6O0C0
		let result=input;
		/*#{1I0GE6O0C0Code*/
		false
		/*}#1I0GE6O0C0Code*/
		return {seg:CheckNavi,result:(result),preSeg:"1I0GE6O0C0",outlet:"1I0GEB4MQ0",catchSeg:ShowError,catchlet:"1I0GEB4MQ1"};
	};
	Execute.jaxId="1I0GE6O0C0"
	Execute.url="Execute@"+agentURL
	
	segs["ShowError"]=ShowError=async function(input){//:1I0GE8FOF0
		let result=input;
		let channel="Chat";
		let opts={txtHeader:($agent.showName||$agent.name||null),channel:channel};
		let role="assistant";
		let content="Error: "+input;
		session.addChatText(role,content,opts);
		return {seg:ReportError,result:(result),preSeg:"1I0GE8FOF0",outlet:"1I0GEB4MQ2"};
	};
	ShowError.jaxId="1I0GE8FOF0"
	ShowError.url="ShowError@"+agentURL
	
	segs["ReportError"]=ReportError=async function(input){//:1I0GE9JHE0
		let result=`执行步骤出现错误: ${input}`
		/*#{1I0GE9JHE0Code*/
		/*}#1I0GE9JHE0Code*/
		return {result:result};
	};
	ReportError.jaxId="1I0GE9JHE0"
	ReportError.url="ReportError@"+agentURL
	
	segs["FlagNT"]=FlagNT=async function(input){//:1I0S8B0290
		let result=true;
		let pageVal="aaPage";
		let $action="networkidle";
		let $flag="WaitNT";
		let $query="";
		let $queryHint="";
		let $waitBefore=0;
		let $waitAfter=0;
		let $options={};
		let page=context[pageVal];
		$waitBefore && (await sleep($waitBefore));
		switch($action){
			case "navi":
			case "networkidle":
			case "dialog":
			case "filechooser":
			default:
				page.waitFor($flag,$action,$options);
				break;
			case "query":
				$query=$queryHint?(await page.confirmQuery($query,$queryHint,"1I0S8B0290")):$query;
				if(!$query) throw Error("Missing query. Query hint: "+$queryHint);
				page.waitForQuery($flag,$query,$options);
				break;
			case "function":
				page.waitForFunction($flag,$query,$options);
				break;
		}$waitAfter && (await sleep($waitAfter))
		return {seg:WaitNT,result:(result),preSeg:"1I0S8B0290",outlet:"1I0S8DRJF0"};
	};
	FlagNT.jaxId="1I0S8B0290"
	FlagNT.url="FlagNT@"+agentURL
	
	segs["WaitNT"]=WaitNT=async function(input){//:1I0S8BI900
		let result=true;
		let pageVal="aaPage";
		let $flag="WaitNT";
		let $waitBefore=0;
		let $waitAfter=0;
		let page=context[pageVal];
		$waitBefore && (await sleep($waitBefore));
		await page.awaitFor($flag);
		$waitAfter && (await sleep($waitAfter))
		return {seg:ActionEnd,result:(result),preSeg:"1I0S8BI900",outlet:"1I0S8DRJF1"};
	};
	WaitNT.jaxId="1I0S8BI900"
	WaitNT.url="WaitNT@"+agentURL
	
	agent=$agent={
		isAIAgent:true,
		session:session,
		name:"ExecAction",
		url:agentURL,
		autoStart:true,
		jaxId:"1I0F8V5V80",
		context:context,
		livingSeg:null,
		execChat:async function(input/*{targetPage,execData,action}*/){
			let result;
			parseAgentArgs(input);
			/*#{1I0F8V5V80PreEntry*/
			/*}#1I0F8V5V80PreEntry*/
			result={seg:Execute,"input":input};
			/*#{1I0F8V5V80PostEntry*/
			/*}#1I0F8V5V80PostEntry*/
			return result;
		},
		/*#{1I0F8V5V80MoreAgentAttrs*/
		/*}#1I0F8V5V80MoreAgentAttrs*/
	};
	/*#{1I0F8V5V80PostAgent*/
	/*}#1I0F8V5V80PostAgent*/
	return agent;
};
/*#{1I0F8V5V80ExCodes*/
/*}#1I0F8V5V80ExCodes*/

//#CodyExport>>>
export const ChatAPI=[{
	def:{
		name: "ExecAction",
		description: "This is an AI agent.",
		parameters:{
			type: "object",
			properties:{
				targetPage:{type:"auto",description:""},
				execData:{type:"auto",description:""},
				action:{type:"auto",description:""}
			}
		}
	},
	isChatApi: true,
	agent: ExecAction
}];

//:Export Edit-AddOn:
const DocAIAgentExporter=VFACT?VFACT.classRegs.DocAIAgentExporter:null;
if(DocAIAgentExporter){
	const EditAttr=VFACT.classRegs.EditAttr;
	const EditAISeg=VFACT.classRegs.EditAISeg;
	const EditAISegOutlet=VFACT.classRegs.EditAISegOutlet;
	const SegObjShellAttr=EditAISeg.SegObjShellAttr;
	const SegOutletDef=EditAISegOutlet.SegOutletDef;
	const docAIAgentExporter=DocAIAgentExporter.prototype;
	const packExtraCodes=docAIAgentExporter.packExtraCodes;
	const packResult=docAIAgentExporter.packResult;
	const varNameRegex = /^[a-zA-Z_$][a-zA-Z0-9_$]*$/;
	
	EditAISeg.regDef({
		name:"ExecAction",showName:"ExecAction",icon:"agent.svg",catalog:["AI Call"],
		attrs:{
			...SegObjShellAttr,
			"targetPage":{name:"targetPage",showName:undefined,type:"auto",key:1,fixed:1,initVal:""},
			"execData":{name:"execData",showName:undefined,type:"auto",key:1,fixed:1,initVal:""},
			"action":{name:"action",showName:undefined,type:"auto",key:1,fixed:1,initVal:""},
			"outlet":{name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc"}
		},
		listHint:["id","targetPage","execData","action","codes","desc"],
		desc:"This is an AI agent."
	});
	
	DocAIAgentExporter.segTypeExporters["ExecAction"]=
	function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let exportDebug=this.isExportDebug();
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();coder.newLine();
		{
			coder.packText(`let result,args={};`);coder.newLine();
			coder.packText("args['targetPage']=");this.genAttrStatement(seg.getAttr("targetPage"));coder.packText(";");coder.newLine();
			coder.packText("args['execData']=");this.genAttrStatement(seg.getAttr("execData"));coder.packText(";");coder.newLine();
			coder.packText("args['action']=");this.genAttrStatement(seg.getAttr("action"));coder.packText(";");coder.newLine();
			this.packExtraCodes(coder,seg,"PreCodes");
			coder.packText(`result= await session.pipeChat("/~/aae/ai/ExecAction.js",args,false);`);coder.newLine();
			this.packExtraCodes(coder,seg,"PostCodes");
			this.packUpdateContext(coder,seg);
			this.packUpdateGlobal(coder,seg);
			this.packResult(coder,seg,seg.outlet);
		}
		coder.indentLess();coder.maybeNewLine();
		coder.packText(`};`);coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		coder.newLine();
	};
}
//#CodyExport<<<
/*#{1I0F8V5V80PostDoc*/
/*}#1I0F8V5V80PostDoc*/


export default ExecAction;
export{ExecAction};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DocAIAgent",
//	"jaxId": "1I0F8V5V80",
//	"attrs": {
//		"editObjs": {
//			"jaxId": "1I0F8V5V81",
//			"attrs": {
//				"ExecAction": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1I0F8V5V90",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1I0F8V5V91",
//							"attrs": {}
//						},
//						"properties": {
//							"jaxId": "1I0F8V5V92",
//							"attrs": {}
//						},
//						"functions": {
//							"jaxId": "1I0F8V5V93",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false",
//						"superClass": "",
//						"exportClass": "false"
//					},
//					"mockups": {}
//				}
//			}
//		},
//		"agent": {
//			"jaxId": "1I0F8V5V82",
//			"attrs": {}
//		},
//		"showName": "",
//		"entry": "Execute",
//		"autoStart": "true",
//		"inBrowser": "true",
//		"debug": "true",
//		"apiArgs": {
//			"jaxId": "1I0F8V5V83",
//			"attrs": {
//				"targetPage": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I0F90IDT0",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				},
//				"execData": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I0F90IDT1",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				},
//				"action": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I0F90IDT2",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1I0F8V5V84",
//			"attrs": {}
//		},
//		"context": {
//			"jaxId": "1I0F8V5V85",
//			"attrs": {}
//		},
//		"globalMockup": {
//			"jaxId": "1I0F8V5V86",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "aiseg",
//					"def": "brunch",
//					"jaxId": "1I0F95HS30",
//					"attrs": {
//						"id": "CheckNavi",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "355",
//						"y": "310",
//						"desc": "This is an AISeg.",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0FA7HKA0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0FA7HKA1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I0FA7HK61",
//							"attrs": {
//								"id": "Default",
//								"desc": "Outlet.",
//								"output": "#action"
//							},
//							"linkedSeg": "1I0F98BRR0"
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I0FA7HK60",
//									"attrs": {
//										"id": "HasNavi",
//										"desc": "Outlet.",
//										"output": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I0FA7HKB0",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I0FA7HKB1",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "action.willNavi"
//									},
//									"linkedSeg": "1I0F97EME0"
//								}
//							]
//						}
//					},
//					"icon": "condition.svg",
//					"reverseOutlets": true
//				},
//				{
//					"type": "aiseg",
//					"def": "AAFWaitFor",
//					"jaxId": "1I0F97EME0",
//					"attrs": {
//						"id": "FlagNavi",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "590",
//						"y": "260",
//						"desc": "This is an AISeg.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0FA7HKB2",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0FA7HKB3",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"page": "aaPage",
//						"action": "Navigate",
//						"flag": "WaitNavi",
//						"query": "",
//						"queryHint": "",
//						"waitBefore": "0",
//						"waitAfter": "0",
//						"outlet": {
//							"jaxId": "1I0FA7HK62",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0F98BRR0"
//						}
//					},
//					"icon": "/@aae/assets/wait_event.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "brunch",
//					"jaxId": "1I0F98BRR0",
//					"attrs": {
//						"id": "CheckFile",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "805",
//						"y": "325",
//						"desc": "This is an AISeg.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0FA7HKB4",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0FA7HKB5",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I0FA7HK64",
//							"attrs": {
//								"id": "Default",
//								"desc": "Outlet.",
//								"output": ""
//							},
//							"linkedSeg": "1I0F9C2F30"
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I0FA7HK63",
//									"attrs": {
//										"id": "HasFile",
//										"desc": "Outlet.",
//										"output": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I0FA7HKB6",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I0FA7HKB7",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#!!action.fileName"
//									},
//									"linkedSeg": "1I0F9B3320"
//								}
//							]
//						}
//					},
//					"icon": "condition.svg",
//					"reverseOutlets": true
//				},
//				{
//					"type": "aiseg",
//					"def": "AAFWaitFor",
//					"jaxId": "1I0F9B3320",
//					"attrs": {
//						"id": "FlagFile",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "1030",
//						"y": "275",
//						"desc": "This is an AISeg.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0FA7HKB8",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0FA7HKB9",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"page": "aaPage",
//						"action": "FileChooser",
//						"flag": "WaitFile",
//						"query": "",
//						"queryHint": "",
//						"waitBefore": "0",
//						"waitAfter": "0",
//						"outlet": {
//							"jaxId": "1I0FA7HK65",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0F9C2F30"
//						}
//					},
//					"icon": "/@aae/assets/wait_event.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "brunch",
//					"jaxId": "1I0F9C2F30",
//					"attrs": {
//						"id": "SwitchAction",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "1235",
//						"y": "340",
//						"desc": "This is an AISeg.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0FA7HKB10",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0FA7HKB11",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I0FA7HK67",
//							"attrs": {
//								"id": "Default",
//								"desc": "Outlet.",
//								"output": ""
//							},
//							"linkedSeg": "1I0F9M77B0"
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I0FA7HK66",
//									"attrs": {
//										"id": "Click",
//										"desc": "Outlet.",
//										"output": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I0FA7HKB12",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I0FA7HKB13",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#action.action===\"Click\""
//									},
//									"linkedSeg": "1I0F9VSV20"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I0H5BT7V0",
//									"attrs": {
//										"id": "ClickUpload",
//										"desc": "Outlet.",
//										"output": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I0H5BT8B0",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I0H5BT8B1",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#action.action===\"ClickUpload\""
//									},
//									"linkedSeg": "1I0F9VSV20"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I0F9JKOE0",
//									"attrs": {
//										"id": "Hover",
//										"desc": "Outlet.",
//										"output": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I0FA7HKB14",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I0FA7HKB15",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#action.action===\"Hover\""
//									},
//									"linkedSeg": "1I0FA1OPR0"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I0F9D8I90",
//									"attrs": {
//										"id": "Type",
//										"desc": "Outlet.",
//										"output": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I0FA7HKB16",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I0FA7HKB17",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#action.action===\"Type\""
//									},
//									"linkedSeg": "1I0FA3GTB0"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I0F9DQ190",
//									"attrs": {
//										"id": "PressKey",
//										"desc": "Outlet.",
//										"output": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I0FA7HKB18",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I0FA7HKB19",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#action.action===\"PressKey\""
//									},
//									"linkedSeg": "1I0FA4UH50"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I0F9G97G0",
//									"attrs": {
//										"id": "Navi",
//										"desc": "Outlet.",
//										"output": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I0FA7HKB20",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I0FA7HKB21",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#action.action===\"Goto\""
//									},
//									"linkedSeg": "1I0FAVBP90"
//								}
//							]
//						}
//					},
//					"icon": "condition.svg",
//					"reverseOutlets": true
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I0F9M77B0",
//					"attrs": {
//						"id": "LogError",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "1520",
//						"y": "525",
//						"desc": "This is an AISeg.",
//						"mkpInput": "$$input$$",
//						"segMark": "Run",
//						"context": {
//							"jaxId": "1I0FA7HKB24",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0FA7HKB25",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I0FA7HK69",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							}
//						},
//						"outlets": {
//							"attrs": []
//						},
//						"result": "#input"
//					},
//					"icon": "tab_css.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "brunch",
//					"jaxId": "1I0F9N4GC0",
//					"attrs": {
//						"id": "IsHandleNavi",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "1780",
//						"y": "340",
//						"desc": "This is an AISeg.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0F9Q5R00",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0F9Q5R01",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I0F9Q5R02",
//							"attrs": {
//								"id": "Default",
//								"desc": "Outlet.",
//								"output": ""
//							},
//							"linkedSeg": "1I0F9Q64C0"
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I0F9Q5R03",
//									"attrs": {
//										"id": "HandleNavi",
//										"desc": "Outlet.",
//										"output": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I0F9Q5R04",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I0F9Q5R05",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#input.willNavi"
//									},
//									"linkedSeg": "1I0F9PLM90"
//								}
//							]
//						}
//					},
//					"icon": "condition.svg",
//					"reverseOutlets": true
//				},
//				{
//					"type": "aiseg",
//					"def": "AAFAWaitFor",
//					"jaxId": "1I0F9PLM90",
//					"attrs": {
//						"id": "HandleNavi",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "2045",
//						"y": "280",
//						"desc": "This is an AISeg.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0FA7HKB26",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0FA7HKB27",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"page": "aaPage",
//						"flag": "WaitNavi",
//						"waitBefore": "0",
//						"waitAfter": "0",
//						"outlet": {
//							"jaxId": "1I0FA7HK70",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0F9Q64C0"
//						}
//					},
//					"icon": "/@aae/assets/wait_await.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "brunch",
//					"jaxId": "1I0F9Q64C0",
//					"attrs": {
//						"id": "IsHandleFile",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "2270",
//						"y": "355",
//						"desc": "This is an AISeg.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0F9Q64C1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0F9Q64C2",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I0F9Q64C3",
//							"attrs": {
//								"id": "Default",
//								"desc": "Outlet.",
//								"output": ""
//							},
//							"linkedSeg": "1I0F9URGM0"
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I0F9Q64C4",
//									"attrs": {
//										"id": "HandleFile",
//										"desc": "Outlet.",
//										"output": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I0F9Q64C5",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I0F9Q64C6",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#action.fileName"
//									},
//									"linkedSeg": "1I0F9RS3S0"
//								}
//							]
//						}
//					},
//					"icon": "condition.svg",
//					"reverseOutlets": true
//				},
//				{
//					"type": "aiseg",
//					"def": "AAFAWaitFor",
//					"jaxId": "1I0F9RS3S0",
//					"attrs": {
//						"id": "WaitFileDlg",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "2535",
//						"y": "280",
//						"desc": "This is an AISeg.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0FA7HKB28",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0FA7HKB29",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"page": "aaPage",
//						"flag": "WaitFile",
//						"waitBefore": "0",
//						"waitAfter": "0",
//						"outlet": {
//							"jaxId": "1I0FA7HK71",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0F9T4EV0"
//						}
//					},
//					"icon": "/@aae/assets/wait_await.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "AAFHandleDialog",
//					"jaxId": "1I0F9T4EV0",
//					"attrs": {
//						"id": "HandleFile",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "2775",
//						"y": "280",
//						"desc": "This is an AISeg.",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0FA7HKB30",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0FA7HKB31",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"page": "aaPage",
//						"action": "Accept",
//						"text": "",
//						"fileName": "#compileText(action.fileName,execData)",
//						"waitBefore": "0",
//						"waitAfter": "0",
//						"outlet": {
//							"jaxId": "1I0FA7HK72",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0S8B0290"
//						}
//					},
//					"icon": "/@aae/assets/wait_dialog.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I0F9URGM0",
//					"attrs": {
//						"id": "ActionEnd",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "3435",
//						"y": "370",
//						"desc": "This is an AISeg.",
//						"mkpInput": "$$input$$",
//						"segMark": "Run",
//						"context": {
//							"jaxId": "1I0FA7HKB32",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0FA7HKB33",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I0FA7HK73",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							}
//						},
//						"outlets": {
//							"attrs": []
//						},
//						"result": "#input"
//					},
//					"icon": "tab_css.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "AAFMouseAction",
//					"jaxId": "1I0F9VSV20",
//					"attrs": {
//						"id": "DoClick",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "1510",
//						"y": "210",
//						"desc": "This is an AISeg.",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0FA7HKB34",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0FA7HKB35",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"page": "aaPage",
//						"action": "Click",
//						"query": "",
//						"queryHint": "#action.queryHint",
//						"dx": "0",
//						"dy": "0",
//						"options": "",
//						"waitBefore": "0",
//						"waitAfter": "0",
//						"outlet": {
//							"jaxId": "1I0FA7HK74",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0F9N4GC0"
//						},
//						"run": ""
//					},
//					"icon": "mouse.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "AAFMouseAction",
//					"jaxId": "1I0FA1OPR0",
//					"attrs": {
//						"id": "DoHover",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "1510",
//						"y": "275",
//						"desc": "This is an AISeg.",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0FA7HKB36",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0FA7HKB37",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"page": "aaPage",
//						"action": "Mouse Move",
//						"query": "#input.query",
//						"queryHint": "#action.queryHint",
//						"dx": "0",
//						"dy": "0",
//						"options": "",
//						"waitBefore": "0",
//						"waitAfter": "0",
//						"outlet": {
//							"jaxId": "1I0FA7HK75",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0F9N4GC0"
//						},
//						"run": ""
//					},
//					"icon": "mouse.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "AAFKeyboardAction",
//					"jaxId": "1I0FA3GTB0",
//					"attrs": {
//						"id": "DoType",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "1515",
//						"y": "340",
//						"desc": "This is an AISeg.",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0FA7HKB38",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0FA7HKB39",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"page": "aaPage",
//						"action": "Type",
//						"query": "",
//						"queryHint": "#action.queryHint",
//						"key": "#compileText(action.content,execData)",
//						"options": "",
//						"waitBefore": "0",
//						"waitAfter": "0",
//						"outlet": {
//							"jaxId": "1I0FA7HK76",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0F9N4GC0"
//						},
//						"run": ""
//					},
//					"icon": "keybtn.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "AAFKeyboardAction",
//					"jaxId": "1I0FA4UH50",
//					"attrs": {
//						"id": "DoKeyPress",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "1515",
//						"y": "400",
//						"desc": "This is an AISeg.",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0FA7HKB40",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0FA7HKB41",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"page": "aaPage",
//						"action": "Key Press",
//						"query": "",
//						"queryHint": "#action.queryHint",
//						"key": "#action.key",
//						"options": "",
//						"waitBefore": "0",
//						"waitAfter": "0",
//						"outlet": {
//							"jaxId": "1I0FA7HK77",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0F9N4GC0"
//						},
//						"run": ""
//					},
//					"icon": "keybtn.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "AAFPageGoto",
//					"jaxId": "1I0FAVBP90",
//					"attrs": {
//						"id": "DoGoto",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "1520",
//						"y": "460",
//						"desc": "This is an AISeg.",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0FB2M7Q0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0FB2M7R0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"page": "aaPage",
//						"url": "#action.url",
//						"waitBefore": "0",
//						"waitAfter": "0",
//						"outlet": {
//							"jaxId": "1I0FB2M7M0",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0F9N4GC0"
//						},
//						"run": ""
//					},
//					"icon": "/@aae/assets/wait_goto.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "tryCatch",
//					"jaxId": "1I0GE6O0C0",
//					"attrs": {
//						"id": "Execute",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "130",
//						"y": "385",
//						"desc": "This is an AISeg.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0GEB4N10",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0GEB4N11",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I0GEB4MQ0",
//							"attrs": {
//								"id": "Try",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0F95HS30"
//						},
//						"catchlet": {
//							"jaxId": "1I0GEB4MQ1",
//							"attrs": {
//								"id": "Catch",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0GE8FOF0"
//						}
//					},
//					"icon": "trycatch.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1I0GE8FOF0",
//					"attrs": {
//						"id": "ShowError",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "355",
//						"y": "465",
//						"desc": "This is an AISeg.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0GEB4N20",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0GEB4N21",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "Assistant",
//						"channel": "Chat",
//						"text": "#\"Error: \"+input",
//						"outlet": {
//							"jaxId": "1I0GEB4MQ2",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0GE9JHE0"
//						}
//					},
//					"icon": "hudtxt.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I0GE9JHE0",
//					"attrs": {
//						"id": "ReportError",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "585",
//						"y": "465",
//						"desc": "This is an AISeg.",
//						"mkpInput": "$$input$$",
//						"segMark": "run.svg",
//						"context": {
//							"jaxId": "1I0GEB4N22",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0GEB4N23",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I0GEB4MQ3",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							}
//						},
//						"outlets": {
//							"attrs": []
//						},
//						"result": "#`执行步骤出现错误: ${input}`"
//					},
//					"icon": "tab_css.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "AAFWaitFor",
//					"jaxId": "1I0S8B0290",
//					"attrs": {
//						"id": "FlagNT",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "3005",
//						"y": "280",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0S8DRJJ0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0S8DRJJ1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"page": "aaPage",
//						"action": "NetworkIdle",
//						"flag": "WaitNT",
//						"query": "",
//						"queryHint": "",
//						"waitBefore": "0",
//						"waitAfter": "0",
//						"outlet": {
//							"jaxId": "1I0S8DRJF0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I0S8BI900"
//						}
//					},
//					"icon": "/@aae/assets/wait_event.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "AAFAWaitFor",
//					"jaxId": "1I0S8BI900",
//					"attrs": {
//						"id": "WaitNT",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "3205",
//						"y": "280",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0S8DRJJ2",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0S8DRJJ3",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"page": "aaPage",
//						"flag": "WaitNT",
//						"waitBefore": "0",
//						"waitAfter": "0",
//						"outlet": {
//							"jaxId": "1I0S8DRJF1",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I0F9URGM0"
//						}
//					},
//					"icon": "/@aae/assets/wait_await.svg"
//				}
//			]
//		},
//		"desc": "This is an AI agent.",
//		"exportAPI": "true",
//		"exportAddOn": "true",
//		"addOnOpts": ""
//	}
//}