//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import pathLib from "/@path";
import inherits from "/@inherits";
import Base64 from "/@tabos/utils/base64.js";
import {trimJSON} from "/@aichat/utils.js";
import {AAFarm} from "/@aae/aafarm.js";
/*#{1I0AF5EJH0MoreImports*/
import {Actions,ActionFilter,BrowserArgs} from "../data/AppData.js";
/*}#1I0AF5EJH0MoreImports*/
const agentURL=(new URL(import.meta.url)).pathname;
const basePath=pathLib.dirname(agentURL);
const $ln=VFACT.lanCode||"EN";
/*#{1I0AF5EJH0StartDoc*/
/*}#1I0AF5EJH0StartDoc*/
//----------------------------------------------------------------------------
let QueryPage=async function(session){
	let execInput;
	let context,globalContext;
	let self;
	let Start,AskBrowser,AskPage,CheckPage,ShowNoAAF,AskURL,OpenPage;
	/*#{1I0AF5EJH0LocalVals*/
	/*}#1I0AF5EJH0LocalVals*/
	
	/*#{1I0AF5EJH0PreContext*/
	/*}#1I0AF5EJH0PreContext*/
	globalContext=session.globalContext;
	context={};
	context=VFACT.flexState(context);
	/*#{1I0AF5EJH0PostContext*/
	/*}#1I0AF5EJH0PostContext*/
	let agent,segs={};
	segs["Start"]=Start=async function(input){//:1I0AFHBKO0
		let result=true;
		let aiQuery=true;
		try{
			context.aaFarm=new AAFarm();
			aiQuery && (await context.aaFarm.setupAIQuery(session,context,basePath,"1I0AFHBKO0"));
		}catch(err){
			return {seg:ShowNoAAF,result:(err),preSeg:"1I0AFHBKO0",outlet:"1I0AFI2RF1",catchSeg:ShowNoAAF,catchlet:"1I0AFI2RF1"};
		}
		return {seg:AskBrowser,result:(result),preSeg:"1I0AFHBKO0",outlet:"1I0AFI2RF0"};
	};
	Start.jaxId="1I0AFHBKO0"
	Start.url="Start@"+agentURL
	
	segs["AskBrowser"]=AskBrowser=async function(input){//:1I0AF6A4A0
		let prompt=((($ln==="CN")?("清选择一个浏览器，或者打开新的"):("Please choose a browser, or open a new one")))||input;
		let countdown=undefined;
		let silent=false;
		let items=[
		];
		let result="";
		let item=null;
		
		/*#{1I0AF6A4A0PreCodes*/
		let app,liveBrowsers,browser,alias,homeLive;
		let farm =context.aaFarm;
		app=VFACT.app;
		liveBrowsers=await farm.getBrowsers();
		for(browser of liveBrowsers){
			alias=browser.alias;
			items.push({text:alias+`: ${browser.pages.length} pages`,alias:browser.alias,browserId:browser.id});
			if(alias==="AAHOME"){
				homeLive=true;
			}
		}
		if(!homeLive){
			items.push({text:"AAHOME",alias:"AAHOME",browserId:null});
		}
		items.push({text:"New browser",alias:"",browserId:null});
		/*}#1I0AF6A4A0PreCodes*/
		if(silent){
			result="";
			return {seg:AskPage,result:(result),preSeg:"1I0AF6A4A0",outlet:"1I0AF6A3S2"};
		}
		[result,item]=await session.askUserRaw({type:"menu",prompt:prompt,multiSelect:false,items:items,withChat:false,countdown:countdown});
		/*#{1I0AF6A4A0PostCodes*/
		let openBrowserId,openBrowserAlias,openBrowserWithDir;
		let browserId;
		browserId=item.browserId;
		alias=item.alias;
		if(browserId){
			openBrowserId=browserId;
			openBrowserAlias=alias;
			openBrowserWithDir=false;
		}else if(alias){
			openBrowserId=null;
			openBrowserAlias=alias;
			openBrowserWithDir=true;
		}else if(alias===null){
			//ask a new alias and if use data-dir:
			let cfg=await app.modalDlg("/@StdUI/ui/DlgDataView.js",{
				hud:app,
				x:(app.w-380)*0.5,y:0,width:380,
				template:BrowserArgs,object:null,
				title:"New browser"
			});
			if(!cfg){
				return null;
			}
			openBrowserAlias=cfg.alias;
			openBrowserWithDir=cfg.dataDir;
		}else if(alias===""){
			openBrowserId=null;
			openBrowserAlias="";
			openBrowserWithDir=false;
		}
		let opts;
		opts={headless:false,devtools:false};
		if(openBrowserAlias && openBrowserWithDir){
			opts.autoDataDir=true;
		}
		browser=await farm.openBrowser(openBrowserAlias,opts);
		openBrowserAlias=browser.alias;
		context.browser=browser;
		context.aaBrowser=browser;
		if(!browser){
			throw Error("Browser not created.");
		}
		result=browser;
		/*}#1I0AF6A4A0PostCodes*/
		/*#{1I0AF6A4A0FinCodes*/
		/*}#1I0AF6A4A0FinCodes*/
		return {seg:AskPage,result:(result),preSeg:"1I0AF6A4A0",outlet:"1I0AF6A3S2"};
	};
	AskBrowser.jaxId="1I0AF6A4A0"
	AskBrowser.url="AskBrowser@"+agentURL
	
	segs["AskPage"]=AskPage=async function(input){//:1I0AFB1LK3
		let prompt=((($ln==="CN")?("请选择一个页面"):("Please choose a page")))||input;
		let countdown=undefined;
		let silent=false;
		let items=[
		];
		let result="";
		let item=null;
		
		/*#{1I0AFB1LK3PreCodes*/
		let pages,page,title;
		let browser=input;
		pages=await browser.getPages();
		for(page of pages){
			title=(await page.getTitle())||(await page.getURL());
			items.push({"text":title,page:page});
		}
		items.push({"text":"New Page",page:null});
		/*}#1I0AFB1LK3PreCodes*/
		if(silent){
			result="";
			return {seg:CheckPage,result:(result),preSeg:"1I0AFB1LK3",outlet:"1I0AFB1LK4"};
		}
		[result,item]=await session.askUserRaw({type:"menu",prompt:prompt,multiSelect:false,items:items,withChat:false,countdown:countdown});
		/*#{1I0AFB1LK3PostCodes*/
		result=item.page;
		/*}#1I0AFB1LK3PostCodes*/
		/*#{1I0AFB1LK3FinCodes*/
		/*}#1I0AFB1LK3FinCodes*/
		return {seg:CheckPage,result:(result),preSeg:"1I0AFB1LK3",outlet:"1I0AFB1LK4"};
	};
	AskPage.jaxId="1I0AFB1LK3"
	AskPage.url="AskPage@"+agentURL
	
	segs["CheckPage"]=CheckPage=async function(input){//:1I0AFBUAG0
		let result=input;
		if(!input){
			return {seg:AskURL,result:(input),preSeg:"1I0AFBUAG0",outlet:"1I0AFDR031"};
		}
		return {result:result};
	};
	CheckPage.jaxId="1I0AFBUAG0"
	CheckPage.url="CheckPage@"+agentURL
	
	segs["ShowNoAAF"]=ShowNoAAF=async function(input){//:1I0AFI5K00
		let result=input;
		let role="system";
		let content="AAF environment not found.";
		/*#{1I0AFI5K00PreCodes*/
		/*}#1I0AFI5K00PreCodes*/
		session.addChatText(role,content);
		/*#{1I0AFI5K00PostCodes*/
		result=null;
		/*}#1I0AFI5K00PostCodes*/
		return {result:result};
	};
	ShowNoAAF.jaxId="1I0AFI5K00"
	ShowNoAAF.url="ShowNoAAF@"+agentURL
	
	segs["AskURL"]=AskURL=async function(input){//:1I0AGCPEK0
		let tip=("Please input new page's URL");
		let tipRole=("system");
		let placeholder=("");
		let text=("");
		let result="";
		if(tip){
			session.addChatText(tipRole,tip);
		}
		result=await session.askChatInput({type:"input",placeholder:placeholder,text:text});
		session.addChatText("user",result);
		return {seg:OpenPage,result:(result),preSeg:"1I0AGCPEK0",outlet:"1I0AGDLJR0"};
	};
	AskURL.jaxId="1I0AGCPEK0"
	AskURL.url="AskURL@"+agentURL
	
	segs["OpenPage"]=OpenPage=async function(input){//:1I0AGE26F0
		let pageVal="aaPage";
		let $url=input;
		let $waitBefore=0;
		let $waitAfter=0;
		let $width=800;
		let $height=600;
		let $userAgent="";
		let page=null;
		$waitBefore && (await sleep($waitBefore));
		context[pageVal]=page=await context.aaBrowser.newPage();
		($width && $height) && (await page.setViewport({width:$width,height:$height}));
		$userAgent && (await page.setUserAgent($userAgent));
		await page.goto($url);
		$waitAfter && (await sleep($waitAfter));
		return {result:page};
	};
	OpenPage.jaxId="1I0AGE26F0"
	OpenPage.url="OpenPage@"+agentURL
	
	agent={
		isAIAgent:true,
		session:session,
		name:"QueryPage",
		url:agentURL,
		autoStart:true,
		jaxId:"1I0AF5EJH0",
		context:context,
		livingSeg:null,
		execChat:async function(input){
			let result;
			execInput=input;
			/*#{1I0AF5EJH0PreEntry*/
			/*}#1I0AF5EJH0PreEntry*/
			result={seg:Start,"input":input};
			/*#{1I0AF5EJH0PostEntry*/
			/*}#1I0AF5EJH0PostEntry*/
			return result;
		},
		/*#{1I0AF5EJH0MoreAgentAttrs*/
		/*}#1I0AF5EJH0MoreAgentAttrs*/
	};
	/*#{1I0AF5EJH0PostAgent*/
	/*}#1I0AF5EJH0PostAgent*/
	return agent;
};
/*#{1I0AF5EJH0ExCodes*/
/*}#1I0AF5EJH0ExCodes*/

export const ChatAPI=[{
	def:{
		name: "AGT_QueryPage",
		description: "AI Agent that ask the user choose or open new web page to perform RPA operations ",
		parameters:{
			type: "object",
			properties:{
			}
		}
	},
	path: "/@aae/ai/QueryPage.js",
	label: "Query Page",
	isRPA: true,
	rpaHost: "www.ai2apps.com",
	agent: QueryPage
}];

//:Export Edit-AddOn:
const DocAIAgentExporter=VFACT.classRegs.DocAIAgentExporter;
if(DocAIAgentExporter){
	const EditAttr=VFACT.classRegs.EditAttr;
	const EditAISeg=VFACT.classRegs.EditAISeg;
	const EditAISegOutlet=VFACT.classRegs.EditAISegOutlet;
	const SegObjShellAttr=EditAISeg.SegObjShellAttr;
	const SegOutletDef=EditAISegOutlet.SegOutletDef;
	const docAIAgentExporter=DocAIAgentExporter.prototype;
	const packExtraCodes=docAIAgentExporter.packExtraCodes;
	const packResult=docAIAgentExporter.packResult;
	const varNameRegex = /^[a-zA-Z_$][a-zA-Z0-9_$]*$/;
	
	EditAISeg.regDef({
		name:"QueryPage",showName:"Query Page",icon:"agent.svg",catalog:["AI Call"],
		attrs:{
			...SegObjShellAttr,
			"outlet":{name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc"}
		},
		listHint:["id","codes","desc"],
		desc:"AI Agent that ask the user choose or open new web page to perform RPA operations "
	});
	
	DocAIAgentExporter.segTypeExporters["QueryPage"]=
	function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let exportDebug=this.isExportDebug();
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();coder.newLine();
		{
			coder.packText(`let result,args={};`);coder.newLine();
			this.packExtraCodes(coder,seg,"PreCodes");
			coder.packText(`result= await session.pipeChat("/@aae/ai/QueryPage.js",args,false);`);coder.newLine();
			this.packExtraCodes(coder,seg,"PostCodes");
			this.packResult(coder,seg,seg.outlet);
		}
		coder.indentLess();coder.maybeNewLine();
		coder.packText(`};`);coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		coder.newLine();
	};
}

export default QueryPage;
export{QueryPage};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DocAIAgent",
//	"jaxId": "1I0AF5EJH0",
//	"attrs": {
//		"editObjs": {
//			"jaxId": "1I0AF5EJI0",
//			"attrs": {
//				"QueryPage": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1I0AF5EJI6",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1I0AF5EJI7",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1I0AF5EJI8",
//							"attrs": {}
//						},
//						"functions": {
//							"jaxId": "1I0AF5EJI9",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false"
//					},
//					"mockups": {}
//				}
//			}
//		},
//		"agent": {
//			"jaxId": "1I0AF5EJI1",
//			"attrs": {}
//		},
//		"entry": "Start",
//		"autoStart": "true",
//		"debug": "true",
//		"apiArgs": {
//			"jaxId": "1I0AF5EJI2",
//			"attrs": {}
//		},
//		"localVars": {
//			"jaxId": "1I0AF5EJI3",
//			"attrs": {}
//		},
//		"context": {
//			"jaxId": "1I0AF5EJI4",
//			"attrs": {}
//		},
//		"globalMockup": {
//			"jaxId": "1I0AF5EJI5",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "aiseg",
//					"def": "AAFStart",
//					"jaxId": "1I0AFHBKO0",
//					"attrs": {
//						"id": "Start",
//						"label": "New AI Seg",
//						"x": "85",
//						"y": "205",
//						"desc": "This is an AISeg.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0AFI2RN0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0AFI2RN1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I0AFI2RF0",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0AF6A4A0"
//						},
//						"catchlet": {
//							"jaxId": "1I0AFI2RF1",
//							"attrs": {
//								"id": "NoAAE",
//								"desc": "Outlet.",
//								"output": "",
//								"codes": "false",
//								"context": {
//									"jaxId": "1I0AFI2RN2",
//									"attrs": {
//										"cast": ""
//									}
//								},
//								"global": {
//									"jaxId": "1I0AFI2RN3",
//									"attrs": {
//										"cast": ""
//									}
//								},
//								"ouput": {
//									"valText": ""
//								}
//							},
//							"linkedSeg": "1I0AFI5K00"
//						},
//						"aiQuery": "true"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "askMenu",
//					"jaxId": "1I0AF6A4A0",
//					"attrs": {
//						"id": "AskBrowser",
//						"label": "New AI Seg",
//						"x": "285",
//						"y": "110",
//						"desc": "This is an AISeg.",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"prompt": {
//							"type": "string",
//							"valText": "Please choose a browser, or open a new one",
//							"localize": {
//								"EN": "Please choose a browser, or open a new one",
//								"CN": "清选择一个浏览器，或者打开新的"
//							},
//							"localizable": true
//						},
//						"multi": "false",
//						"withChat": "false",
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1I0AF6A3S2",
//									"attrs": {
//										"id": "Next",
//										"desc": "Outlet.",
//										"text": "",
//										"result": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I0AF854S0",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I0AF854S1",
//											"attrs": {
//												"cast": ""
//											}
//										}
//									},
//									"linkedSeg": "1I0AFB1LK3"
//								}
//							]
//						},
//						"silent": "false"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "askMenu",
//					"jaxId": "1I0AFB1LK3",
//					"attrs": {
//						"id": "AskPage",
//						"label": "New AI Seg",
//						"x": "525",
//						"y": "110",
//						"desc": "This is an AISeg.",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"prompt": {
//							"type": "string",
//							"valText": "Please choose a page",
//							"localize": {
//								"EN": "Please choose a page",
//								"CN": "请选择一个页面"
//							},
//							"localizable": true
//						},
//						"multi": "false",
//						"withChat": "false",
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1I0AFB1LK4",
//									"attrs": {
//										"id": "Next",
//										"desc": "Outlet.",
//										"text": "",
//										"result": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I0AFB1LK5",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I0AFB1LK6",
//											"attrs": {
//												"cast": ""
//											}
//										}
//									},
//									"linkedSeg": "1I0AFBUAG0"
//								}
//							]
//						},
//						"silent": "false"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "brunch",
//					"jaxId": "1I0AFBUAG0",
//					"attrs": {
//						"id": "CheckPage",
//						"label": "New AI Seg",
//						"x": "735",
//						"y": "110",
//						"desc": "This is an AISeg.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0AFDR066",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0AFDR067",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I0AFDR032",
//							"attrs": {
//								"id": "Default",
//								"desc": "Outlet.",
//								"output": ""
//							}
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I0AFDR031",
//									"attrs": {
//										"id": "OpenPage",
//										"desc": "Outlet.",
//										"output": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I0AFDR068",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I0AFDR069",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "!input",
//										"ouput": {
//											"valText": ""
//										}
//									},
//									"linkedSeg": "1I0AGCPEK0"
//								}
//							]
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1I0AFI5K00",
//					"attrs": {
//						"id": "ShowNoAAF",
//						"label": "New AI Seg",
//						"x": "285",
//						"y": "220",
//						"desc": "This is an AISeg.",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0AFJJ1B0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0AFJJ1B1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "System",
//						"text": "AAF environment not found.",
//						"outlet": {
//							"jaxId": "1I0AFJJ160",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							}
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "askChat",
//					"jaxId": "1I0AGCPEK0",
//					"attrs": {
//						"id": "AskURL",
//						"label": "New AI Seg",
//						"x": "990",
//						"y": "95",
//						"desc": "This is an AISeg.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0AGDLJU0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0AGDLJU1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"tip": "Please input new page's URL",
//						"tipRole": "System",
//						"placeholder": "",
//						"text": "",
//						"file": "false",
//						"showText": "true",
//						"outlet": {
//							"jaxId": "1I0AGDLJR0",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0AGE26F0"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "AAFOpenPage",
//					"jaxId": "1I0AGE26F0",
//					"attrs": {
//						"id": "OpenPage",
//						"label": "New AI Seg",
//						"x": "1200",
//						"y": "95",
//						"desc": "This is an AISeg.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0AGEI4C0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0AGEI4C1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"valName": "aaPage",
//						"url": "#input",
//						"vpWidth": "800",
//						"vpHeight": "600",
//						"userAgent": "",
//						"waitBefore": "0",
//						"waitAfter": "0",
//						"outlet": {
//							"jaxId": "1I0AGEI490",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							}
//						},
//						"run": ""
//					}
//				}
//			]
//		},
//		"desc": "AI Agent that ask the user choose or open new web page to perform RPA operations ",
//		"exportAPI": "true",
//		"exportAddOn": "true",
//		"addOnOpts": "{\"name\":\"\",\"label\":\"Query Page\",\"path\":\"/@aae/ai/QueryPage.js\",\"isRPA\":1,\"rpaHost\":\"www.ai2apps.com\",\"segIcon\":\"\",\"catalog\":\"AI Call\"}"
//	}
//}