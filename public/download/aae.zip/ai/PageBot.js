//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import pathLib from "/@path";
import inherits from "/@inherits";
import Base64 from "/@tabos/utils/base64.js";
import {trimJSON} from "/@aichat/utils.js";
/*#{1I0FBILTT0MoreImports*/
import {} from "../data/AppData.js";
import $actionDef from "./ActionsDef.js";
/*}#1I0FBILTT0MoreImports*/
const agentURL=(new URL(import.meta.url)).pathname;
const baseURL=pathLib.dirname(agentURL);
const basePath=baseURL.startsWith("file://")?decodeURI(baseURL):baseURL;
const $ln=VFACT.lanCode||"EN";
const argsTemplate={
	properties:{
		"targetPage":{
			"name":"targetPage","type":"auto",
			"defaultValue":"",
			"desc":"",
		},
		"execData":{
			"name":"execData","type":"auto",
			"defaultValue":"",
			"desc":"",
		},
		"command":{
			"name":"command","type":"string",
			"defaultValue":"",
			"desc":"",
		}
	},
	/*#{1I0FBILTT0ArgsView*/
	/*}#1I0FBILTT0ArgsView*/
};

/*#{1I0FBILTT0StartDoc*/
/*}#1I0FBILTT0StartDoc*/
//----------------------------------------------------------------------------
let PageBot=async function(session){
	let targetPage,execData,command;
	const $ln=session.language||"EN";
	let context,globalContext=session.globalContext;
	let self;
	let CheckCmd,AskCmd,ShowCmd,HasPage,QueryPage,GetSnap,ShowImage,GenStep,RunStep,CheckEnd,GenAgent,CheckInStep,ShowStepVO,AskNext,ShowStep,FeedBack,QHint,AskTip,QExec,QGenAgent,ShowSteps,QEnd,UpdateMessage,TipTaskDone,CheckStep,MarkError,TipAbort,VerifyCmd,TipBadCmd;
	let actionDef="ActionDef";
	
	/*#{1I0FBILTT0LocalVals*/
	actionDef=$actionDef;
	/*}#1I0FBILTT0LocalVals*/
	
	function parseAgentArgs(input){
		if(typeof(input)=='object'){
			targetPage=input.targetPage;
			execData=input.execData;
			command=input.command;
		}else{
			targetPage=undefined;
			execData=undefined;
			command=undefined;
		}
		/*#{1I0FBILTT0ParseArgs*/
		/*}#1I0FBILTT0ParseArgs*/
	}
	
	/*#{1I0FBILTT0PreContext*/
	/*}#1I0FBILTT0PreContext*/
	context={
		screenImg: null,
		curStep: 0,
		stepResult: null,
		stepTip: "",
		curStepVO: "",
		execSteps: [],
		/*#{1I0FBILTT5ExCtxAttrs*/
		/*}#1I0FBILTT5ExCtxAttrs*/
	};
	context=VFACT.flexState(context);
	/*#{1I0FBILTT0PostContext*/
	/*}#1I0FBILTT0PostContext*/
	let $agent,agent,segs={};
	segs["CheckCmd"]=CheckCmd=async function(input){//:1I18ICLRT0
		let result=input;
		if((!command) || (!execData)){
			let output="null";
			return {seg:AskCmd,result:(output),preSeg:"1I18ICLRT0",outlet:"1I18IIB7L0"};
		}
		return {seg:ShowCmd,result:(result),preSeg:"1I18ICLRT0",outlet:"1I18IIB7L1"};
	};
	CheckCmd.jaxId="1I18ICLRT0"
	CheckCmd.url="CheckCmd@"+agentURL
	
	segs["AskCmd"]=AskCmd=async function(input){//:1I18IEFQ10
		let result,resultText;
		let role="assistant";
		let md=await import("/@StdUI/ui/AIAskDataBlock.js");
		let func=md.default;
		let text="Please input skill execData and command.";
		let template="1I18I5LNG0";
		let data=input||{};
		let edit=true;
		if(typeof(template)==="string"){
			template=VFACT.getEditUITemplate(template)||VFACT.getUITemplate(template);
		}
		let inputVO={template:template,data:data,options:{edit:edit}};
		/*#{1I18IEFQ10Pre*/
		/*}#1I18IEFQ10Pre*/
		[resultText,result]=await session.askUserRaw({type:"block",text:text,block:func(session,{}),input:inputVO,role:role});
		/*#{1I18IEFQ10Codes*/
		try{
			execData=JSON.parse(result.execData);
		}catch(err){
			execData=null;
		}
		command=result.command;
		/*}#1I18IEFQ10Codes*/
		return {seg:VerifyCmd,result:(result),preSeg:"1I18IEFQ10",outlet:"1I18IIB7M0"};
	};
	AskCmd.jaxId="1I18IEFQ10"
	AskCmd.url="AskCmd@"+agentURL
	
	segs["ShowCmd"]=ShowCmd=async function(input){//:1I18IFMGC0
		let result=input;
		let channel="Chat";
		let opts={txtHeader:($agent.showName||$agent.name||null),channel:channel};
		let role="assistant";
		let content=`ExecData：
\`\`\`
${JSON.stringify(execData,null,"\t")}
\`\`\`
Command: ${command}
`;
		session.addChatText(role,content,opts);
		return {seg:HasPage,result:(result),preSeg:"1I18IFMGC0",outlet:"1I18IFMGC3"};
	};
	ShowCmd.jaxId="1I18IFMGC0"
	ShowCmd.url="ShowCmd@"+agentURL
	
	segs["HasPage"]=HasPage=async function(input){//:1I0FBOFR90
		let result=input;
		/*#{1I0FBOFR90Start*/
		context.execSteps=[];
		/*}#1I0FBOFR90Start*/
		if(!targetPage){
			return {seg:QueryPage,result:(input),preSeg:"1I0FBOFR90",outlet:"1I0FBOFR94"};
		}
		/*#{1I0FBOFR90Post*/
		context.aaPage=targetPage;
		/*}#1I0FBOFR90Post*/
		return {seg:GetSnap,result:(result),preSeg:"1I0FBOFR90",outlet:"1I0FBOFR93"};
	};
	HasPage.jaxId="1I0FBOFR90"
	HasPage.url="HasPage@"+agentURL
	
	segs["QueryPage"]=QueryPage=async function(input){//:1I0FBP7A20
		let result,args={};
		/*#{1I0FBP7A20PreCodes*/
		/*}#1I0FBP7A20PreCodes*/
		result= await session.pipeChat("/@aae/ai/QueryPage.js",args,false);
		/*#{1I0FBP7A20PostCodes*/
		context.aaPage=targetPage=result;
		/*}#1I0FBP7A20PostCodes*/
		return {seg:GetSnap,result:(result),preSeg:"1I0FBP7A20",outlet:"1I0FBP7A23"};
	};
	QueryPage.jaxId="1I0FBP7A20"
	QueryPage.url="QueryPage@"+agentURL
	
	segs["GetSnap"]=GetSnap=async function(input){//:1I0FBRUBP0
		let result=null;
		let data=null;
		let pageVal="aaPage";
		let fullPage=false;
		let waitBefore=0;
		let waitAfter=500;
		let page=context[pageVal];
		waitBefore && (await sleep(waitBefore));
		result=await page.screenshot({fullPage:fullPage});
		data=result.substring(result.indexOf(","))
		waitAfter && (await sleep(waitAfter));
		context["screenImg"]=result;
		return {seg:ShowImage,result:(result),preSeg:"1I0FBRUBP0",outlet:"1I0FBVSB11"};
	};
	GetSnap.jaxId="1I0FBRUBP0"
	GetSnap.url="GetSnap@"+agentURL
	
	segs["ShowImage"]=ShowImage=async function(input){//:1I0FCSBF50
		let result=input;
		let role="assistant";
		let content="Image:";
		//Limit size:
		let callback =null;
		let pms=new Promise((resolve)=>{callback=resolve;});
		{
			
			let maxSize =600;
			let img = new Image();
			img.crossOrigin = "Anonymous";
			img.src = input;
			img.onload = function () {
				let imgW = img.width;
				let imgH = img.height;
				let scale = maxSize/(imgW>imgH?imgW:imgH);
				if(scale<1){
					let canvas = document.createElement("canvas");
					let context = canvas.getContext("2d");
					canvas.width = Math.floor(img.width*scale);
					canvas.height = Math.floor(img.height*scale);
					context.drawImage(img, 0, 0,canvas.width,canvas.height);
					result = canvas.toDataURL("image/png");
				}
				callback();
			};
		}
		await pms;
		let vo={image:result};
		session.addChatText(role,content,vo);
		return {seg:QHint,result:(result),preSeg:"1I0FCSBF50",outlet:"1I0FCSRML0"};
	};
	ShowImage.jaxId="1I0FCSBF50"
	ShowImage.url="ShowImage@"+agentURL
	
	segs["GenStep"]=GenStep=async function(input){//:1I0FBQP7D0
		let prompt;
		let result=null;
		/*#{1I0FBQP7D0Input*/
		let orgInput,url;
		/*}#1I0FBQP7D0Input*/
		
		let opts={
			platform:"OpenAI",
			mode:"gpt-4o",
			maxToken:2000,
			temperature:0,
			topP:1,
			fqcP:0,
			prcP:0,
			secret:false,
			responseFormat:"json_object"
		};
		let chatMem=GenStep.messages
		let seed="";
		if(seed!==undefined){opts.seed=seed;}
		let messages=[
			{role:"system",content:`
### 你是一个强大的网页分析，动作规划智能体。

- 你根据任务描述，以及当前任务的执行状态，通过网页图像分析并推导为了完成任务，下一步要进行的操作。

- 第一轮对话时，会用告诉你：当前网页的URL，当前网页的截图，本次任务的目标，任务输入数据。其中任务输入数据是一个对象，里面包含执行任务需要的数据，比如执行网页搜索数据时的目标搜索内容。

- 之后每一回合对话，会告诉你上一次执行的结果，当前网页的URL和截图，你根据任务目标和当前状态生成下一步要进行的操作。

- 请用JSON格式进行回复，例如：
\`\`\`
{
	"execute":{
    	"desc":"Click the search button."
    	"action":"Click",
        "queryHint":"Search button",
        "willNavi":false,
        "fileName":""
    },
    "result":null,
    "abort":false
}
\`\`\`

- "execute": 在回复JSON里: 该属性定义下一步操作, 根据分析，需要继续执行网页操作，请按照《执行指令规则》生成内容；如果不需要下一步操作，吧这个属性设置为null。

- "abort": 在回复JSON里：当你认为任务因为无法完成，需要终止吧该属性设置为终止的原因；否则设为false。

- "result": 在回复JSON里：当任务已经执行完毕，把结果输出到该属性里。

${actionDef}
`},
		];
		messages.push(...chatMem);
		/*#{1I0FBQP7D0PrePrompt*/
		input=null;
		/*}#1I0FBQP7D0PrePrompt*/
		prompt=input;
		if(prompt!==null){
			if(typeof(prompt)!=="string"){
				prompt=JSON.stringify(prompt,null,"	");
			}
			let msg={role:"user",content:prompt};
			/*#{1I0FBQP7D0FilterMessage*/
			/*}#1I0FBQP7D0FilterMessage*/
			messages.push(msg);
		}
		/*#{1I0FBQP7D0PreCall*/
		//Make message:
		url=await context.aaPage.getURL();
		if(context.curStep===0){
			prompt=`图片是当前网页内容。当前网页的URL: ${url} \n任务执行目标: ${command} \n任务输入数据(execData): \n${JSON.stringify(execData,null,"\t")}。`;
		}else{
			prompt=`步骤执行结果：${JSON.stringify(context.stepResult)}。图片是当前网页内容，当前网页的URL: ${url}}。`;
		}
		if(context.stepTip){
			prompt+=`\n用户对当前步骤建议：${context.stepTip}`;
		}
		messages.push({role:"user",content:[
			{type:"text",text:prompt},
			{type:"image_url",image_url:{url:context.screenImg}}
		]});
		messages.push({role:"user",content:[
			{type:"text",text:prompt}
		]});
		/*}#1I0FBQP7D0PreCall*/
		result=GenStep.cheats[prompt]||GenStep.cheats[input]||GenStep.cheats[""+chatMem.length]||GenStep.cheats[""];
		if(!result){
			result=(result===undefined)?(await session.callSegLLM("GenStep@"+agentURL,opts,messages,true)):result;
		
		}
		/*#{1I0FBQP7D0PostLLM*/
		/*}#1I0FBQP7D0PostLLM*/
		chatMem.push({role:"user",content:prompt});
		chatMem.push({role:"assistant",content:result});
		if(chatMem.length>50){
			let removedMsgs=chatMem.splice(0,2);
			/*#{1I0FBQP7D0PostClear*/
			/*}#1I0FBQP7D0PostClear*/
		}
		result=trimJSON(result);
		/*#{1I0FBQP7D0PostCall*/
		/*}#1I0FBQP7D0PostCall*/
		/*#{1I0FBQP7D0PreResult*/
		/*}#1I0FBQP7D0PreResult*/
		return {seg:ShowStepVO,result:(result),preSeg:"1I0FBQP7D0",outlet:"1I0FBVSB10"};
	};
	GenStep.jaxId="1I0FBQP7D0"
	GenStep.url="GenStep@"+agentURL
	GenStep.messages=[];
	GenStep.cheats={
		"":"{\n\t\"execute\": {\n\t\t\"desc\": \"点击搜索输入框\",\n\t\t\"action\": \"Click\",\n\t\t\"queryHint\": \"搜索输入框\",\n\t\t\"willNavi\": false,\n\t\t\"willUploadFile\": false\n\t},\n\t\"result\": null,\n\t\"abort\": false\n}"
	};
	
	segs["RunStep"]=RunStep=async function(input){//:1I0FBVAOL0
		let result;
		let arg={"targetPage":targetPage,"execData":execData,"action":input.execute};
		let agentNode=(undefined)||null;
		let sourcePath=pathLib.joinTabOSURL(basePath,"./ExecAction.js");
		let opts={secrect:false,fromAgent:$agent,askUpwardSeg:null};
		result= await session.callAgent(agentNode,sourcePath,arg,opts);
		return {seg:ShowStep,result:(result),preSeg:"1I0FBVAOL0",outlet:"1I0FBVSB20"};
	};
	RunStep.jaxId="1I0FBVAOL0"
	RunStep.url="RunStep@"+agentURL
	
	segs["CheckEnd"]=CheckEnd=async function(input){//:1I0FC0E5C0
		let result=input;
		if(((!input.execute)||(!input.execute.action))&&(!input.result)){
			return {seg:FeedBack,result:(input),preSeg:"1I0FC0E5C0",outlet:"1I0GL8CI80"};
		}
		if(input.result||input.abort){
			return {seg:QEnd,result:(input),preSeg:"1I0FC0E5C0",outlet:"1I0FC6L320"};
		}
		result=input;
		return {seg:QExec,result:(result),preSeg:"1I0FC0E5C0",outlet:"1I0FC6L321"};
	};
	CheckEnd.jaxId="1I0FC0E5C0"
	CheckEnd.url="CheckEnd@"+agentURL
	
	segs["GenAgent"]=GenAgent=async function(input){//:1I0FC11MF0
		let result=input
		/*#{1I0FC11MF0Code*/
		/*}#1I0FC11MF0Code*/
		return {result:result};
	};
	GenAgent.jaxId="1I0FC11MF0"
	GenAgent.url="GenAgent@"+agentURL
	
	segs["CheckInStep"]=CheckInStep=async function(input){//:1I0FCAHD50
		let result=input
		/*#{1I0FCAHD50Code*/
		context.curStep+=1;
		context.execSteps.push(context.curStepVO);
		/*}#1I0FCAHD50Code*/
		context["stepResult"]=input;
		return {seg:AskNext,result:(result),preSeg:"1I0FCAHD50",outlet:"1I0FCBGUH0"};
	};
	CheckInStep.jaxId="1I0FCAHD50"
	CheckInStep.url="CheckInStep@"+agentURL
	
	segs["ShowStepVO"]=ShowStepVO=async function(input){//:1I0FMBD8V0
		let result=input;
		let channel="Chat";
		let opts={txtHeader:($agent.showName||$agent.name||null),channel:channel};
		let role="assistant";
		let content=`Step VO：\n\`\`\`\n${JSON.stringify(input,null,"\t")}\n\`\`\`\n`;
		session.addChatText(role,content,opts);
		context["curStepVO"]=input;
		return {seg:CheckEnd,result:(result),preSeg:"1I0FMBD8V0",outlet:"1I0FMC0980"};
	};
	ShowStepVO.jaxId="1I0FMBD8V0"
	ShowStepVO.url="ShowStepVO@"+agentURL
	
	segs["AskNext"]=AskNext=async function(input){//:1I0FVQCBS0
		let prompt=("Continue?")||input;
		let silent=false;
		let countdown=5;
		let placeholder=(undefined)||null;
		let button1=("Continue")||"OK";
		let button2=("Wrong Step")||"Cancel";
		let button3="";
		let result="";
		let value=0;
		if(silent){
			result=input;
			return {seg:GetSnap,result:(result),preSeg:"1I0FVQCBS0",outlet:"1I0FVQCBD0"};
		}
		[result,value]=await session.askUserRaw({type:"confirm",prompt:prompt,button1:button1,button2:button2,button3:button3,countdown:countdown,withChat:undefined,placeholder:placeholder});
		if(value===1){
			result=(input)||result;
			return {seg:GetSnap,result:(result),preSeg:"1I0FVQCBS0",outlet:"1I0FVQCBD0"};
		}
		result=("")||result;
		return {result:result};
	
	};
	AskNext.jaxId="1I0FVQCBS0"
	AskNext.url="AskNext@"+agentURL
	
	segs["ShowStep"]=ShowStep=async function(input){//:1I0GF44K40
		let result=input;
		let channel="Chat";
		let opts={txtHeader:($agent.showName||$agent.name||null),channel:channel};
		let role="assistant";
		let content=input;
		/*#{1I0GF44K40PreCodes*/
		/*}#1I0GF44K40PreCodes*/
		session.addChatText(role,content,opts);
		/*#{1I0GF44K40PostCodes*/
		/*}#1I0GF44K40PostCodes*/
		return {seg:CheckStep,result:(result),preSeg:"1I0GF44K40",outlet:"1I0GF4VIN0"};
	};
	ShowStep.jaxId="1I0GF44K40"
	ShowStep.url="ShowStep@"+agentURL
	
	segs["FeedBack"]=FeedBack=async function(input){//:1I0GL3KFO0
		let result=input
		/*#{1I0GL3KFO0Code*/
		result=`生成的步骤错误：找不到正确的执行信息。`
		/*}#1I0GL3KFO0Code*/
		return {seg:GetSnap,result:(result),preSeg:"1I0GL3KFO0",outlet:"1I0GL8CI90"};
	};
	FeedBack.jaxId="1I0GL3KFO0"
	FeedBack.url="FeedBack@"+agentURL
	
	segs["QHint"]=QHint=async function(input){//:1I0H9M7EE0
		let prompt=((($ln==="CN")?("你对当前步骤有什么建议么"):("Do you have any advices for the current step?")))||input;
		let silent=true;
		let countdown=30;
		let placeholder=(undefined)||null;
		let button1=("No advice")||"OK";
		let button2=("Advice")||"Cancel";
		let button3="";
		let result="";
		let value=0;
		if(silent){
			result="";
			return {seg:GenStep,result:(result),preSeg:"1I0H9M7EE0",outlet:"1I0H9M7E30"};
		}
		[result,value]=await session.askUserRaw({type:"confirm",prompt:prompt,button1:button1,button2:button2,button3:button3,countdown:countdown,withChat:undefined,placeholder:placeholder});
		if(value===1){
			result=("")||result;
			return {seg:GenStep,result:(result),preSeg:"1I0H9M7EE0",outlet:"1I0H9M7E30"};
		}
		result=("")||result;
		context["stepTip"]="";
		return {seg:AskTip,result:(result),preSeg:"1I0H9M7EE0",outlet:"1I0H9M7E31"};
	
	};
	QHint.jaxId="1I0H9M7EE0"
	QHint.url="QHint@"+agentURL
	
	segs["AskTip"]=AskTip=async function(input){//:1I0HAQHML0
		let tip=("Please input step tip:");
		let tipRole=("assistant");
		let placeholder=("");
		let allowFile=(false)||false;
		let allowEmpty=(false)||false;
		let askUpward=(false);
		let text=("");
		let result="";
		if(askUpward && tip){
			result=await session.askUpward($agent,tip);
		}else{
			if(tip){
				session.addChatText(tipRole,tip);
			}
			result=await session.askChatInput({type:"input",placeholder:placeholder,text:text,allowFile:allowFile,allowEmpty:allowEmpty});
		}
		if(typeof(result)==="string"){
			session.addChatText("user",result);
		}else if(result.assets && result.prompt){
			session.addChatText("user",`${result.prompt}\n- - -\n${result.assets.join("\n- - -\n")}`,{render:true});
		}else{
			session.addChatText("user",result.text||result.prompt||result);
		}
		context["stepTip"]=result;
		return {seg:GenStep,result:(result),preSeg:"1I0HAQHML0",outlet:"1I0HAU47F0"};
	};
	AskTip.jaxId="1I0HAQHML0"
	AskTip.url="AskTip@"+agentURL
	
	segs["QExec"]=QExec=async function(input){//:1I0HBF5480
		let prompt=("Execute action or give advice to modify?")||input;
		let silent=false;
		let countdown=5;
		let placeholder=(undefined)||null;
		let button1=("Execute")||"OK";
		let button2=("Modify")||"Cancel";
		let button3=("Abort")||"";
		let result="";
		let value=0;
		if(silent){
			result=input;
			return {seg:RunStep,result:(result),preSeg:"1I0HBF5480",outlet:"1I0HBF53S0"};
		}
		[result,value]=await session.askUserRaw({type:"confirm",prompt:prompt,button1:button1,button2:button2,button3:button3,countdown:countdown,withChat:undefined,placeholder:placeholder});
		if(value===1){
			result=(input)||result;
			return {seg:RunStep,result:(result),preSeg:"1I0HBF5480",outlet:"1I0HBF53S0"};
		}
		if(value===2){
			result=("")||result;
			return {seg:TipAbort,result:(result),preSeg:"1I0HBF5480",outlet:"1I0HBF53S2"};
		}
		result=("")||result;
		/*#{1I0HBF53S1Btn2*/
		context.stepResult="这个步骤设计的不合理，需要重新设计。";
		/*}#1I0HBF53S1Btn2*/
		return {seg:AskTip,result:(result),preSeg:"1I0HBF5480",outlet:"1I0HBF53S1"};
	
	};
	QExec.jaxId="1I0HBF5480"
	QExec.url="QExec@"+agentURL
	
	segs["QGenAgent"]=QGenAgent=async function(input){//:1I0IE773U0
		let prompt=((($ln==="CN")?("您是否想生成此操作的API-Agent。"):("Do you want to generate an API-Agent doc for this operation.")))||input;
		let silent=false;
		let countdown=undefined;
		let placeholder=(undefined)||null;
		let button1=("Generate")||"OK";
		let button2=("No Thanks")||"Cancel";
		let button3="";
		let result="";
		let value=0;
		if(silent){
			result="";
			return {seg:ShowSteps,result:(result),preSeg:"1I0IE773U0",outlet:"1I0IE773D0"};
		}
		[result,value]=await session.askUserRaw({type:"confirm",prompt:prompt,button1:button1,button2:button2,button3:button3,countdown:countdown,withChat:undefined,placeholder:placeholder});
		if(value===1){
			result=("")||result;
			return {seg:ShowSteps,result:(result),preSeg:"1I0IE773U0",outlet:"1I0IE773D0"};
		}
		result=("")||result;
		return {seg:TipTaskDone,result:(result),preSeg:"1I0IE773U0",outlet:"1I0IE773D1"};
	
	};
	QGenAgent.jaxId="1I0IE773U0"
	QGenAgent.url="QGenAgent@"+agentURL
	
	segs["ShowSteps"]=ShowSteps=async function(input){//:1I0IQ0MU10
		let result=input;
		let channel="Chat";
		let opts={txtHeader:($agent.showName||$agent.name||null),channel:channel};
		let role="assistant";
		let content=`Run steps：\n\`\`\`\n${JSON.stringify(context.execSteps,null,"\t")}\n\`\`\`\n`;
		session.addChatText(role,content,opts);
		return {seg:GenAgent,result:(result),preSeg:"1I0IQ0MU10",outlet:"1I0IQ0MU20"};
	};
	ShowSteps.jaxId="1I0IQ0MU10"
	ShowSteps.url="ShowSteps@"+agentURL
	
	segs["QEnd"]=QEnd=async function(input){//:1I0KA96980
		let prompt=("End task or need more steps?")||input;
		let silent=false;
		let countdown=undefined;
		let placeholder=(undefined)||null;
		let button1=("More Steps")||"OK";
		let button2=("End Task")||"Cancel";
		let button3="";
		let result="";
		let value=0;
		if(silent){
			result="";
			return {seg:UpdateMessage,result:(result),preSeg:"1I0KA96980",outlet:"1I0KA968N0"};
		}
		[result,value]=await session.askUserRaw({type:"confirm",prompt:prompt,button1:button1,button2:button2,button3:button3,countdown:countdown,withChat:undefined,placeholder:placeholder});
		if(value===1){
			result=("")||result;
			return {seg:UpdateMessage,result:(result),preSeg:"1I0KA96980",outlet:"1I0KA968N0"};
		}
		result=(input)||result;
		return {seg:QGenAgent,result:(result),preSeg:"1I0KA96980",outlet:"1I0KA968N1"};
	
	};
	QEnd.jaxId="1I0KA96980"
	QEnd.url="QEnd@"+agentURL
	
	segs["UpdateMessage"]=UpdateMessage=async function(input){//:1I0KAENJ20
		let result=input
		/*#{1I0KAENJ20Code*/
		GenStep.messages.push({role:"user",content:"操作还未结束，需要生成进一步动作。"});
		/*}#1I0KAENJ20Code*/
		return {seg:GetSnap,result:(result),preSeg:"1I0KAENJ20",outlet:"1I0KAGSHS0"};
	};
	UpdateMessage.jaxId="1I0KAENJ20"
	UpdateMessage.url="UpdateMessage@"+agentURL
	
	segs["TipTaskDone"]=TipTaskDone=async function(input){//:1I0KB8DPD0
		let result=input;
		let channel="Chat";
		let opts={txtHeader:($agent.showName||$agent.name||null),channel:channel};
		let role="assistant";
		let content="任务结束。";
		session.addChatText(role,content,opts);
		return {result:result};
	};
	TipTaskDone.jaxId="1I0KB8DPD0"
	TipTaskDone.url="TipTaskDone@"+agentURL
	
	segs["CheckStep"]=CheckStep=async function(input){//:1I16ERQJ60
		let result=input;
		if(!input.error){
			return {seg:CheckInStep,result:(input),preSeg:"1I16ERQJ60",outlet:"1I16FHPS51"};
		}
		return {seg:MarkError,result:(result),preSeg:"1I16ERQJ60",outlet:"1I16FHPS52"};
	};
	CheckStep.jaxId="1I16ERQJ60"
	CheckStep.url="CheckStep@"+agentURL
	
	segs["MarkError"]=MarkError=async function(input){//:1I16ESMEE0
		let result=input
		/*#{1I16ESMEE0Code*/
		/*}#1I16ESMEE0Code*/
		return {seg:GetSnap,result:(result),preSeg:"1I16ESMEE0",outlet:"1I16FHPS53"};
	};
	MarkError.jaxId="1I16ESMEE0"
	MarkError.url="MarkError@"+agentURL
	
	segs["TipAbort"]=TipAbort=async function(input){//:1I16FJ6Q60
		let result=input;
		let channel="Chat";
		let opts={txtHeader:($agent.showName||$agent.name||null),channel:channel};
		let role="assistant";
		let content=input;
		session.addChatText(role,content,opts);
		return {result:result};
	};
	TipAbort.jaxId="1I16FJ6Q60"
	TipAbort.url="TipAbort@"+agentURL
	
	segs["VerifyCmd"]=VerifyCmd=async function(input){//:1I18IQ0G70
		let result=input;
		if((!command) || (!execData)){
			return {seg:TipBadCmd,result:(input),preSeg:"1I18IQ0G70",outlet:"1I18J4HDN0"};
		}
		return {seg:HasPage,result:(result),preSeg:"1I18IQ0G70",outlet:"1I18J4HDN1"};
	};
	VerifyCmd.jaxId="1I18IQ0G70"
	VerifyCmd.url="VerifyCmd@"+agentURL
	
	segs["TipBadCmd"]=TipBadCmd=async function(input){//:1I18IRTEH0
		let result=input;
		let channel="Chat";
		let opts={txtHeader:($agent.showName||$agent.name||null),channel:channel};
		let role="assistant";
		let content="execData不正确或者缺少command指令，请重新输入";
		session.addChatText(role,content,opts);
		return {seg:AskCmd,result:(result),preSeg:"1I18IRTEH0",outlet:"1I18J4HDN2"};
	};
	TipBadCmd.jaxId="1I18IRTEH0"
	TipBadCmd.url="TipBadCmd@"+agentURL
	
	agent=$agent={
		isAIAgent:true,
		session:session,
		name:"PageBot",
		url:agentURL,
		autoStart:true,
		jaxId:"1I0FBILTT0",
		context:context,
		livingSeg:null,
		execChat:async function(input/*{targetPage,execData,command}*/){
			let result;
			parseAgentArgs(input);
			/*#{1I0FBILTT0PreEntry*/
			/*}#1I0FBILTT0PreEntry*/
			result={seg:CheckCmd,"input":input};
			/*#{1I0FBILTT0PostEntry*/
			/*}#1I0FBILTT0PostEntry*/
			return result;
		},
		/*#{1I0FBILTT0MoreAgentAttrs*/
		/*}#1I0FBILTT0MoreAgentAttrs*/
	};
	/*#{1I0FBILTT0PostAgent*/
	/*}#1I0FBILTT0PostAgent*/
	return agent;
};
/*#{1I0FBILTT0ExCodes*/
/*}#1I0FBILTT0ExCodes*/

//#CodyExport>>>
//#CodyExport<<<
/*#{1I0FBILTT0PostDoc*/
/*}#1I0FBILTT0PostDoc*/


export default PageBot;
export{PageBot};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DocAIAgent",
//	"jaxId": "1I0FBILTT0",
//	"attrs": {
//		"editObjs": {
//			"jaxId": "1I0FBILTT1",
//			"attrs": {
//				"PageBot": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1I0FBILTU0",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1I0FBILTU1",
//							"attrs": {}
//						},
//						"properties": {
//							"jaxId": "1I0FBILTU2",
//							"attrs": {}
//						},
//						"functions": {
//							"jaxId": "1I0FBILTU3",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false",
//						"superClass": "",
//						"exportClass": "false"
//					},
//					"mockups": {}
//				}
//			}
//		},
//		"agent": {
//			"jaxId": "1I0FBILTT2",
//			"attrs": {}
//		},
//		"showName": "",
//		"entry": "CheckCmd",
//		"autoStart": "true",
//		"inBrowser": "true",
//		"debug": "true",
//		"apiArgs": {
//			"jaxId": "1I0FBILTT3",
//			"attrs": {
//				"targetPage": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I0FBMDN70",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				},
//				"execData": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I0FBNC120",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				},
//				"command": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I0FBNC121",
//					"attrs": {
//						"type": "String",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1I0FBILTT4",
//			"attrs": {
//				"actionDef": {
//					"type": "string",
//					"valText": "ActionDef"
//				}
//			}
//		},
//		"context": {
//			"jaxId": "1I0FBILTT5",
//			"attrs": {
//				"screenImg": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I0FHFGV10",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "null",
//						"desc": ""
//					}
//				},
//				"curStep": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I0FLTJEH0",
//					"attrs": {
//						"type": "Integer",
//						"mockup": "0",
//						"desc": ""
//					}
//				},
//				"stepResult": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I0FM7V590",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "null",
//						"desc": ""
//					}
//				},
//				"stepTip": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I0HAVRMD0",
//					"attrs": {
//						"type": "String",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				},
//				"curStepVO": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I0IE220H0",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				},
//				"execSteps": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I0HCIH810",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "[]",
//						"desc": ""
//					}
//				}
//			}
//		},
//		"globalMockup": {
//			"jaxId": "1I0FBILTT6",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "aiseg",
//					"def": "brunch",
//					"jaxId": "1I18ICLRT0",
//					"attrs": {
//						"id": "CheckCmd",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "90",
//						"y": "200",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I18IIB7P0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I18IIB7P1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I18IIB7L1",
//							"attrs": {
//								"id": "Default",
//								"desc": "输出节点。",
//								"output": ""
//							},
//							"linkedSeg": "1I18IFMGC0"
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I18IIB7L0",
//									"attrs": {
//										"id": "NoCommand",
//										"desc": "输出节点。",
//										"output": "null",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I18IIB7P2",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I18IIB7P3",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "(!command) || (!execData)"
//									},
//									"linkedSeg": "1I18IEFQ10"
//								}
//							]
//						}
//					},
//					"icon": "condition.svg",
//					"reverseOutlets": true
//				},
//				{
//					"type": "aiseg",
//					"def": "askDataView",
//					"jaxId": "1I18IEFQ10",
//					"attrs": {
//						"id": "AskCmd",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "360",
//						"y": "65",
//						"desc": "这是一个AISeg。",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I18IIB7P4",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I18IIB7P5",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I18IIB7M0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I18IQ0G70"
//						},
//						"text": "Please input skill execData and command.",
//						"role": "Assistant",
//						"data": "#input||{}",
//						"template": "\"1I18I5LNG0\"",
//						"editData": "true"
//					},
//					"icon": "rename.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1I18IFMGC0",
//					"attrs": {
//						"id": "ShowCmd",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "355",
//						"y": "215",
//						"desc": "This is an AISeg.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I18IFMGC1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I18IFMGC2",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "Assistant",
//						"channel": "Chat",
//						"text": "#`ExecData：\n\\`\\`\\`\n${JSON.stringify(execData,null,\"\\t\")}\n\\`\\`\\`\nCommand: ${command}\n`",
//						"outlet": {
//							"jaxId": "1I18IFMGC3",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0FBOFR90"
//						}
//					},
//					"icon": "hudtxt.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "brunch",
//					"jaxId": "1I0FBOFR90",
//					"attrs": {
//						"id": "HasPage",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "590",
//						"y": "200",
//						"desc": "This is an AISeg.",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "Flag",
//						"context": {
//							"jaxId": "1I0FBOFR91",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0FBOFR92",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I0FBOFR93",
//							"attrs": {
//								"id": "Default",
//								"desc": "Outlet.",
//								"output": "",
//								"ouput": {
//									"valText": ""
//								}
//							},
//							"linkedSeg": "1I0FBRUBP0"
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I0FBOFR94",
//									"attrs": {
//										"id": "NoPage",
//										"desc": "Outlet.",
//										"output": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I0FBOFR95",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I0FBOFR96",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#!targetPage",
//										"ouput": {
//											"valText": ""
//										}
//									},
//									"linkedSeg": "1I0FBP7A20"
//								}
//							]
//						}
//					},
//					"icon": "condition.svg",
//					"reverseOutlets": true
//				},
//				{
//					"type": "aiseg",
//					"def": "QueryPage",
//					"jaxId": "1I0FBP7A20",
//					"attrs": {
//						"id": "QueryPage",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "815",
//						"y": "145",
//						"desc": "This is an AISeg.",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0FBP7A21",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0FBP7A22",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I0FBP7A23",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0FBRUBP0"
//						}
//					},
//					"icon": "agent.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "AAFCapturePage",
//					"jaxId": "1I0FBRUBP0",
//					"attrs": {
//						"id": "GetSnap",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "1055",
//						"y": "215",
//						"desc": "This is an AISeg.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0FBVSB92",
//							"attrs": {
//								"cast": "{\"screenImg\":\"result\",\"curStep\":\"\",\"stepResult\":\"\"}"
//							}
//						},
//						"global": {
//							"jaxId": "1I0FBVSB93",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"page": "aaPage",
//						"fullPage": "false",
//						"dataURL": "true",
//						"waitBefore": "0",
//						"waitAfter": "500",
//						"outlet": {
//							"jaxId": "1I0FBVSB11",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0FCSBF50"
//						}
//					},
//					"icon": "/@aae/assets/tab_cam.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "image",
//					"jaxId": "1I0FCSBF50",
//					"attrs": {
//						"id": "ShowImage",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "1275",
//						"y": "215",
//						"desc": "This is an AISeg.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0FCSRMT0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0FCSRMT1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"text": "Image:",
//						"image": "#input",
//						"role": "Assistant",
//						"sizeLimit": "600",
//						"format": "PNG",
//						"outlet": {
//							"jaxId": "1I0FCSRML0",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0H9M7EE0"
//						}
//					},
//					"icon": "hudimg.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "callLLM",
//					"jaxId": "1I0FBQP7D0",
//					"attrs": {
//						"id": "GenStep",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "1920",
//						"y": "200",
//						"desc": "Excute a LLM call.",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "faces.svg",
//						"context": {
//							"jaxId": "1I0FBVSB90",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0FBVSB91",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"platform": "\"OpenAI\"",
//						"mode": "gpt-4o",
//						"system": "#`\n### 你是一个强大的网页分析，动作规划智能体。\n\n- 你根据任务描述，以及当前任务的执行状态，通过网页图像分析并推导为了完成任务，下一步要进行的操作。\n\n- 第一轮对话时，会用告诉你：当前网页的URL，当前网页的截图，本次任务的目标，任务输入数据。其中任务输入数据是一个对象，里面包含执行任务需要的数据，比如执行网页搜索数据时的目标搜索内容。\n\n- 之后每一回合对话，会告诉你上一次执行的结果，当前网页的URL和截图，你根据任务目标和当前状态生成下一步要进行的操作。\n\n- 请用JSON格式进行回复，例如：\n\\`\\`\\`\n{\n\t\"execute\":{\n    \t\"desc\":\"Click the search button.\"\n    \t\"action\":\"Click\",\n        \"queryHint\":\"Search button\",\n        \"willNavi\":false,\n        \"fileName\":\"\"\n    },\n    \"result\":null,\n    \"abort\":false\n}\n\\`\\`\\`\n\n- \"execute\": 在回复JSON里: 该属性定义下一步操作, 根据分析，需要继续执行网页操作，请按照《执行指令规则》生成内容；如果不需要下一步操作，吧这个属性设置为null。\n\n- \"abort\": 在回复JSON里：当你认为任务因为无法完成，需要终止吧该属性设置为终止的原因；否则设为false。\n\n- \"result\": 在回复JSON里：当任务已经执行完毕，把结果输出到该属性里。\n\n${actionDef}\n`",
//						"temperature": "0",
//						"maxToken": "2000",
//						"topP": "1",
//						"fqcP": "0",
//						"prcP": "0",
//						"messages": {
//							"attrs": []
//						},
//						"prompt": "#input",
//						"seed": "",
//						"outlet": {
//							"jaxId": "1I0FBVSB10",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0FMBD8V0"
//						},
//						"stream": "true",
//						"secret": "false",
//						"allowCheat": "true",
//						"GPTCheats": {
//							"attrs": [
//								{
//									"type": "object",
//									"def": "GPTCheat",
//									"jaxId": "1I0FU562S0",
//									"attrs": {
//										"reply": "{\n\t\"execute\": {\n\t\t\"desc\": \"点击搜索输入框\",\n\t\t\"action\": \"Click\",\n\t\t\"queryHint\": \"搜索输入框\",\n\t\t\"willNavi\": false,\n\t\t\"willUploadFile\": false\n\t},\n\t\"result\": null,\n\t\"abort\": false\n}",
//										"prompt": ""
//									}
//								}
//							]
//						},
//						"shareChatName": "",
//						"keepChat": "50 messages",
//						"clearChat": "2",
//						"apiFiles": {
//							"attrs": []
//						},
//						"parallelFunction": "false",
//						"responseFormat": "json_object",
//						"formatDef": "\"\"",
//						"outlets": {
//							"attrs": []
//						}
//					},
//					"icon": "llm.svg",
//					"reverseOutlets": true
//				},
//				{
//					"type": "aiseg",
//					"def": "aiBot",
//					"jaxId": "1I0FBVAOL0",
//					"attrs": {
//						"id": "RunStep",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "2850",
//						"y": "355",
//						"desc": "Call AI Agent, use it's output as result",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0FBVSB94",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0FBVSB95",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"source": "ai/ExecAction.js",
//						"argument": "{\"targetPage\":\"#targetPage\",\"execData\":\"#execData\",\"action\":\"#input.execute\"}",
//						"secret": "false",
//						"outlet": {
//							"jaxId": "1I0FBVSB20",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0GF44K40"
//						},
//						"outlets": {
//							"attrs": []
//						}
//					},
//					"icon": "agent.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "brunch",
//					"jaxId": "1I0FC0E5C0",
//					"attrs": {
//						"id": "CheckEnd",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "2375",
//						"y": "200",
//						"desc": "This is an AISeg.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0FC6L390",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0FC6L391",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I0FC6L321",
//							"attrs": {
//								"id": "Default",
//								"desc": "Outlet.",
//								"output": "#input"
//							},
//							"linkedSeg": "1I0HBF5480"
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I0GL8CI80",
//									"attrs": {
//										"id": "NoExecute",
//										"desc": "Outlet.",
//										"output": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I0GL8CID0",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I0GL8CID1",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#((!input.execute)||(!input.execute.action))&&(!input.result)"
//									},
//									"linkedSeg": "1I0GL3KFO0"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I0FC6L320",
//									"attrs": {
//										"id": "End",
//										"desc": "Outlet.",
//										"output": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I0FC6L392",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I0FC6L393",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#input.result||input.abort"
//									},
//									"linkedSeg": "1I0KA96980"
//								}
//							]
//						}
//					},
//					"icon": "condition.svg",
//					"reverseOutlets": true
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I0FC11MF0",
//					"attrs": {
//						"id": "GenAgent",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "3320",
//						"y": "195",
//						"desc": "This is an AISeg.",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0FC6L394",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0FC6L395",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I0FC6L322",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							}
//						},
//						"outlets": {
//							"attrs": []
//						},
//						"result": "#input"
//					},
//					"icon": "tab_css.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I0FCAHD50",
//					"attrs": {
//						"id": "CheckInStep",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "3545",
//						"y": "295",
//						"desc": "This is an AISeg.",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0FCBGUM0",
//							"attrs": {
//								"cast": "{\"screenImg\":\"\",\"curStep\":\"\",\"stepResult\":\"input\"}"
//							}
//						},
//						"global": {
//							"jaxId": "1I0FCBGUM1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I0FCBGUH0",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0FVQCBS0"
//						},
//						"outlets": {
//							"attrs": []
//						},
//						"result": "#input"
//					},
//					"icon": "tab_css.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I0FCB2BT0",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "3920",
//						"y": "500",
//						"outlet": {
//							"jaxId": "1I0FCBGUM2",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I16EUV5Q0"
//						},
//						"dir": "R2L"
//					},
//					"icon": "arrowright.svg",
//					"isConnector": true
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I0FCBA8C0",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "1080",
//						"y": "500",
//						"outlet": {
//							"jaxId": "1I0FCBGUM3",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0FBRUBP0"
//						},
//						"dir": "R2L"
//					},
//					"icon": "arrowright.svg",
//					"isConnector": true
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1I0FMBD8V0",
//					"attrs": {
//						"id": "ShowStepVO",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "2135",
//						"y": "200",
//						"desc": "This is an AISeg.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "",
//						"context": {
//							"jaxId": "1I0FMC09H0",
//							"attrs": {
//								"cast": "{\"screenImg\":\"\",\"curStep\":\"\",\"stepResult\":\"\",\"stepTip\":\"\",\"curStepVO\":\"input\",\"execSteps\":\"\"}"
//							}
//						},
//						"global": {
//							"jaxId": "1I0FMC09H1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "Assistant",
//						"channel": "Chat",
//						"text": "#`Step VO：\\n\\`\\`\\`\\n${JSON.stringify(input,null,\"\\t\")}\\n\\`\\`\\`\\n`",
//						"outlet": {
//							"jaxId": "1I0FMC0980",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0FC0E5C0"
//						}
//					},
//					"icon": "hudtxt.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "askConfirm",
//					"jaxId": "1I0FVQCBS0",
//					"attrs": {
//						"id": "AskNext",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "3790",
//						"y": "295",
//						"desc": "This is an AISeg.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"prompt": "Continue?",
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1I0FVQCBD0",
//									"attrs": {
//										"id": "Next",
//										"desc": "Outlet.",
//										"text": "Continue",
//										"result": "#input",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I0FVT5M90",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I0FVT5M91",
//											"attrs": {
//												"cast": ""
//											}
//										}
//									},
//									"linkedSeg": "1I0FCB2BT0"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1I16FHPS50",
//									"attrs": {
//										"id": "BadStep",
//										"desc": "输出节点。",
//										"text": "Wrong Step",
//										"result": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I16FHPSE0",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I16FHPSE1",
//											"attrs": {
//												"cast": ""
//											}
//										}
//									}
//								}
//							]
//						},
//						"silent": "false",
//						"countdown": "5"
//					},
//					"icon": "help.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1I0GF44K40",
//					"attrs": {
//						"id": "ShowStep",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "3070",
//						"y": "355",
//						"desc": "This is an AISeg.",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0GF4VJ10",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0GF4VJ11",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "Assistant",
//						"channel": "Chat",
//						"text": "#input",
//						"outlet": {
//							"jaxId": "1I0GF4VIN0",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I16ERQJ60"
//						}
//					},
//					"icon": "hudtxt.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I0GL3KFO0",
//					"attrs": {
//						"id": "FeedBack",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "2630",
//						"y": "140",
//						"desc": "This is an AISeg.",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0GL8CID2",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0GL8CID3",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I0GL8CI90",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0GL5BBH0"
//						},
//						"outlets": {
//							"attrs": []
//						},
//						"result": "#input"
//					},
//					"icon": "tab_css.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I0GL5BBH0",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "2770",
//						"y": "65",
//						"outlet": {
//							"jaxId": "1I0GL8CID4",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0GL65VO0"
//						},
//						"dir": "R2L"
//					},
//					"icon": "arrowright.svg",
//					"isConnector": true
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I0GL65VO0",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "1090",
//						"y": "65",
//						"outlet": {
//							"jaxId": "1I0GL8CID5",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0FBRUBP0"
//						},
//						"dir": "R2L"
//					},
//					"icon": "arrowright.svg",
//					"isConnector": true
//				},
//				{
//					"type": "aiseg",
//					"def": "askConfirm",
//					"jaxId": "1I0H9M7EE0",
//					"attrs": {
//						"id": "QHint",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "1505",
//						"y": "215",
//						"desc": "This is an AISeg.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"prompt": {
//							"type": "string",
//							"valText": "Do you have any advices for the current step?",
//							"localize": {
//								"EN": "Do you have any advices for the current step?",
//								"CN": "你对当前步骤有什么建议么"
//							},
//							"localizable": true
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1I0H9M7E30",
//									"attrs": {
//										"id": "JustGo",
//										"desc": "Outlet.",
//										"text": "No advice",
//										"result": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I0HAU47M0",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I0HAU47M1",
//											"attrs": {
//												"cast": ""
//											}
//										}
//									},
//									"linkedSeg": "1I0FBQP7D0"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1I0H9M7E31",
//									"attrs": {
//										"id": "Advice",
//										"desc": "Outlet.",
//										"text": "Advice",
//										"result": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I0HAU47M2",
//											"attrs": {
//												"cast": "{\"screenImg\":\"\",\"curStep\":\"\",\"stepResult\":\"\",\"stepTip\":\"\\\"\\\"\"}"
//											}
//										},
//										"global": {
//											"jaxId": "1I0HAU47M3",
//											"attrs": {
//												"cast": ""
//											}
//										}
//									},
//									"linkedSeg": "1I0HAQHML0"
//								}
//							]
//						},
//						"silent": "true",
//						"countdown": "30"
//					},
//					"icon": "help.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "askChat",
//					"jaxId": "1I0HAQHML0",
//					"attrs": {
//						"id": "AskTip",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "1715",
//						"y": "265",
//						"desc": "This is an AISeg.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0HAU47M4",
//							"attrs": {
//								"cast": "{\"screenImg\":\"\",\"curStep\":\"\",\"stepResult\":\"\",\"stepTip\":\"result\"}"
//							}
//						},
//						"global": {
//							"jaxId": "1I0HAU47M5",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"tip": "Please input step tip:",
//						"tipRole": "Assistant",
//						"placeholder": "",
//						"text": "",
//						"file": "false",
//						"allowEmpty": "false",
//						"showText": "true",
//						"askUpward": "false",
//						"outlet": {
//							"jaxId": "1I0HAU47F0",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0FBQP7D0"
//						}
//					},
//					"icon": "chat.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "askConfirm",
//					"jaxId": "1I0HBF5480",
//					"attrs": {
//						"id": "QExec",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "2630",
//						"y": "385",
//						"desc": "This is an AISeg.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"prompt": "Execute action or give advice to modify?",
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1I0HBF53S0",
//									"attrs": {
//										"id": "Execute",
//										"desc": "Outlet.",
//										"text": "Execute",
//										"result": "#input",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I0HBMLK50",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I0HBMLK51",
//											"attrs": {
//												"cast": ""
//											}
//										}
//									},
//									"linkedSeg": "1I0FBVAOL0"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1I0HBF53S1",
//									"attrs": {
//										"id": "Modify",
//										"desc": "Outlet.",
//										"text": "Modify",
//										"result": "",
//										"codes": "true",
//										"context": {
//											"jaxId": "1I0HBMLK52",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I0HBMLK53",
//											"attrs": {
//												"cast": ""
//											}
//										}
//									},
//									"linkedSeg": "1I0HBK3ER0"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1I0HBF53S2",
//									"attrs": {
//										"id": "Abort",
//										"desc": "Outlet.",
//										"text": "Abort",
//										"result": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I0HBMLK54",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I0HBMLK55",
//											"attrs": {
//												"cast": ""
//											}
//										}
//									},
//									"linkedSeg": "1I16FJ6Q60"
//								}
//							]
//						},
//						"silent": "false",
//						"countdown": "5"
//					},
//					"icon": "help.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I0HBK3ER0",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "2760",
//						"y": "455",
//						"outlet": {
//							"jaxId": "1I0HBMLK56",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0HBOEFF0"
//						},
//						"dir": "R2L"
//					},
//					"icon": "arrowright.svg",
//					"isConnector": true
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I0HBOEFF0",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "1745",
//						"y": "455",
//						"outlet": {
//							"jaxId": "1I0HBP9B80",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0HAQHML0"
//						},
//						"dir": "R2L"
//					},
//					"icon": "arrowright.svg",
//					"isConnector": true
//				},
//				{
//					"type": "aiseg",
//					"def": "askConfirm",
//					"jaxId": "1I0IE773U0",
//					"attrs": {
//						"id": "QGenAgent",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "2845",
//						"y": "245",
//						"desc": "This is an AISeg.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"prompt": {
//							"type": "string",
//							"valText": "Do you want to generate an API-Agent doc for this operation.",
//							"localize": {
//								"EN": "Do you want to generate an API-Agent doc for this operation.",
//								"CN": "您是否想生成此操作的API-Agent。"
//							},
//							"localizable": true
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1I0IE773D0",
//									"attrs": {
//										"id": "Gen",
//										"desc": "Outlet.",
//										"text": "Generate",
//										"result": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I0IEA22J0",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I0IEA22J1",
//											"attrs": {
//												"cast": ""
//											}
//										}
//									},
//									"linkedSeg": "1I0IQ0MU10"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1I0IE773D1",
//									"attrs": {
//										"id": "No",
//										"desc": "Outlet.",
//										"text": "No Thanks",
//										"result": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I0IEA22J2",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I0IEA22J3",
//											"attrs": {
//												"cast": ""
//											}
//										}
//									},
//									"linkedSeg": "1I0KB8DPD0"
//								}
//							]
//						},
//						"silent": "false"
//					},
//					"icon": "help.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1I0IQ0MU10",
//					"attrs": {
//						"id": "ShowSteps",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "3075",
//						"y": "195",
//						"desc": "This is an AISeg.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0IQ0MU11",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0IQ0MU12",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "Assistant",
//						"channel": "Chat",
//						"text": "#`Run steps：\\n\\`\\`\\`\\n${JSON.stringify(context.execSteps,null,\"\\t\")}\\n\\`\\`\\`\\n`",
//						"outlet": {
//							"jaxId": "1I0IQ0MU20",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0FC11MF0"
//						}
//					},
//					"icon": "hudtxt.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "askConfirm",
//					"jaxId": "1I0KA96980",
//					"attrs": {
//						"id": "QEnd",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "2630",
//						"y": "230",
//						"desc": "This is an AISeg.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"prompt": "End task or need more steps?",
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1I0KA968N0",
//									"attrs": {
//										"id": "More",
//										"desc": "Outlet.",
//										"text": "More Steps",
//										"result": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I0KAGSI50",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I0KAGSI51",
//											"attrs": {
//												"cast": ""
//											}
//										}
//									},
//									"linkedSeg": "1I0KAENJ20"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1I0KA968N1",
//									"attrs": {
//										"id": "End",
//										"desc": "Outlet.",
//										"text": "End Task",
//										"result": "#input",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I0KAGSI52",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I0KAGSI53",
//											"attrs": {
//												"cast": ""
//											}
//										}
//									},
//									"linkedSeg": "1I0IE773U0"
//								}
//							]
//						},
//						"silent": "false"
//					},
//					"icon": "help.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I0KADO1F0",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "3045",
//						"y": "65",
//						"outlet": {
//							"jaxId": "1I0KAGSI54",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0GL5BBH0"
//						},
//						"dir": "R2L"
//					},
//					"icon": "arrowright.svg",
//					"isConnector": true
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I0KAENJ20",
//					"attrs": {
//						"id": "UpdateMessage",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "2870",
//						"y": "140",
//						"desc": "This is an AISeg.",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0KAGSI55",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0KAGSI56",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I0KAGSHS0",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0KADO1F0"
//						},
//						"outlets": {
//							"attrs": []
//						},
//						"result": "#input"
//					},
//					"icon": "tab_css.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1I0KB8DPD0",
//					"attrs": {
//						"id": "TipTaskDone",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "3075",
//						"y": "260",
//						"desc": "This is an AISeg.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "flag.svg",
//						"context": {
//							"jaxId": "1I0KB9GH70",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0KB9GH71",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "Assistant",
//						"channel": "Chat",
//						"text": "任务结束。",
//						"outlet": {
//							"jaxId": "1I0KB9GH10",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							}
//						}
//					},
//					"icon": "hudtxt.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "brunch",
//					"jaxId": "1I16ERQJ60",
//					"attrs": {
//						"id": "CheckStep",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "3300",
//						"y": "355",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I16FHPSE2",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I16FHPSE3",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I16FHPS52",
//							"attrs": {
//								"id": "Default",
//								"desc": "输出节点。",
//								"output": ""
//							},
//							"linkedSeg": "1I16ESMEE0"
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I16FHPS51",
//									"attrs": {
//										"id": "StepOK",
//										"desc": "输出节点。",
//										"output": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I16FHPSE4",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I16FHPSE5",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "!input.error"
//									},
//									"linkedSeg": "1I0FCAHD50"
//								}
//							]
//						}
//					},
//					"icon": "condition.svg",
//					"reverseOutlets": true
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I16ESMEE0",
//					"attrs": {
//						"id": "MarkError",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "3545",
//						"y": "415",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I16FHPSE6",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I16FHPSE7",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I16FHPS53",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I16EUV5Q0"
//						},
//						"outlets": {
//							"attrs": []
//						},
//						"result": "#input"
//					},
//					"icon": "tab_css.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I16EUV5Q0",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "3690",
//						"y": "500",
//						"outlet": {
//							"jaxId": "1I16FHPSE8",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I0FCBA8C0"
//						},
//						"dir": "R2L"
//					},
//					"icon": "arrowright.svg",
//					"isConnector": true
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1I16FJ6Q60",
//					"attrs": {
//						"id": "TipAbort",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "2850",
//						"y": "415",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "flag.svg",
//						"context": {
//							"jaxId": "1I16FN79D0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I16FN79D1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "Assistant",
//						"channel": "Chat",
//						"text": "#input",
//						"outlet": {
//							"jaxId": "1I16FN7960",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							}
//						}
//					},
//					"icon": "hudtxt.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "brunch",
//					"jaxId": "1I18IQ0G70",
//					"attrs": {
//						"id": "VerifyCmd",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "570",
//						"y": "0",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I18J4HDV0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I18J4HDV1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I18J4HDN1",
//							"attrs": {
//								"id": "Default",
//								"desc": "输出节点。",
//								"output": ""
//							},
//							"linkedSeg": "1I18IST2G0"
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I18J4HDN0",
//									"attrs": {
//										"id": "Bad",
//										"desc": "输出节点。",
//										"output": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I18J4HDV2",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I18J4HDV3",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "(!command) || (!execData)"
//									},
//									"linkedSeg": "1I18IRTEH0"
//								}
//							]
//						}
//					},
//					"icon": "condition.svg",
//					"reverseOutlets": true
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1I18IRTEH0",
//					"attrs": {
//						"id": "TipBadCmd",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "840",
//						"y": "-15",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I18J4HDV4",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I18J4HDV5",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "Assistant",
//						"channel": "Chat",
//						"text": "execData不正确或者缺少command指令，请重新输入",
//						"outlet": {
//							"jaxId": "1I18J4HDN2",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I18ISB410"
//						}
//					},
//					"icon": "hudtxt.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I18ISB410",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "990",
//						"y": "-85",
//						"outlet": {
//							"jaxId": "1I18J4HDV6",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I18ISFSD0"
//						},
//						"dir": "R2L"
//					},
//					"icon": "arrowright.svg",
//					"isConnector": true
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I18ISFSD0",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "405",
//						"y": "-85",
//						"outlet": {
//							"jaxId": "1I18J4HDV7",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I18IEFQ10"
//						},
//						"dir": "R2L"
//					},
//					"icon": "arrowright.svg",
//					"isConnector": true
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I18IST2G0",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "670",
//						"y": "100",
//						"outlet": {
//							"jaxId": "1I18J4HDV8",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I0FBOFR90"
//						},
//						"dir": "R2L"
//					},
//					"icon": "arrowright.svg",
//					"isConnector": true
//				}
//			]
//		},
//		"desc": "This is an AI agent.",
//		"exportAPI": "false",
//		"exportAddOn": "false",
//		"addOnOpts": ""
//	}
//}