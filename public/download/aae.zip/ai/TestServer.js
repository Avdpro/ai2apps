//Auto genterated by Cody
import pathLib from "path";
import Base64 from "../../agenthub/base64.js";
import {trimJSON} from "../../agenthub/ChatSession.mjs";
import URL from "url";
/*#{1IDVFKQBQ0MoreImports*/
/*}#1IDVFKQBQ0MoreImports*/
const agentURL=(new URL(import.meta.url)).pathname;
const basePath=pathLib.dirname(agentURL);
/*#{1IDVFKQBQ0StartDoc*/
/*}#1IDVFKQBQ0StartDoc*/
//----------------------------------------------------------------------------
let TestServer=async function(session){
	let execInput;
	const $ln=session.language||"EN";let context,globalContext;
	let self;
	let Ask,CallLLM,Result;
	/*#{1IDVFKQBQ0LocalVals*/
	/*}#1IDVFKQBQ0LocalVals*/
	
	function parseAgentArgs(input){
		execInput=input;
		/*#{1IDVFKQBQ0ParseArgs*/
		/*}#1IDVFKQBQ0ParseArgs*/
	}
	
	/*#{1IDVFKQBQ0PreContext*/
	/*}#1IDVFKQBQ0PreContext*/
	globalContext=session.globalContext;
	context={};
	/*#{1IDVFKQBQ0PostContext*/
	/*}#1IDVFKQBQ0PostContext*/
	let agent,segs={};
	segs["Ask"]=Ask=async function(input){//:1IDVFLMKV0
		let tip=("");
		let tipRole=("assistant");
		let placeholder=("");
		let text=("");
		let result="";
		if(tip){
			session.addChatText(tipRole,tip);
		}
		result=await session.askChatInput({type:"input",placeholder:placeholder,text:text});
		session.addChatText("user",result);
		return {seg:CallLLM,result:(result),preSeg:"1IDVFLMKV0",outlet:"1IDVFMBG60"};
	};
	Ask.jaxId="1IDVFLMKV0"
	Ask.url="Ask@"+agentURL
	
	segs["CallLLM"]=CallLLM=async function(input){//:1IDVFLU2O0
		let prompt;
		let result;
		
		let opts={
			platform:"OpenAI",
			mode:"gpt-3.5-turbo",
			maxToken:2000,
			temperature:0,
			topP:1,
			fqcP:0,
			prcP:0,
			secret:false,
			responseFormat:"text"
		};
		let chatMem=CallLLM.messages
		let seed="";
		if(seed!==undefined){opts.seed=seed;}
		let messages=[
			{role:"system",content:"You are a smart assistant."},
		];
		prompt=input;
		if(prompt!==null){
			if(typeof(prompt)!=="string"){
				prompt=JSON.stringify(prompt,null,"	");
			}
			messages.push({role:"user",content:prompt});
		}
		result=await session.callSegLLM("CallLLM@"+agentURL,opts,messages,true);
		return {seg:Result,result:(result),preSeg:"1IDVFLU2O0",outlet:"1IDVFMBG61"};
	};
	CallLLM.jaxId="1IDVFLU2O0"
	CallLLM.url="CallLLM@"+agentURL
	
	segs["Result"]=Result=async function(input){//:1IDVFM6280
		let result=input;
		let role="assistant";
		let content=input;
		session.addChatText(role,content);
		return {result:result};
	};
	Result.jaxId="1IDVFM6280"
	Result.url="Result@"+agentURL
	
	agent={
		isAIAgent:true,
		session:session,
		name:"TestServer",
		url:agentURL,
		autoStart:true,
		jaxId:"1IDVFKQBQ0",
		context:context,
		livingSeg:null,
		execChat:async function(input){
			let result;
			parseAgentArgs(input);
			/*#{1IDVFKQBQ0PreEntry*/
			/*}#1IDVFKQBQ0PreEntry*/
			result={seg:Ask,"input":input};
			/*#{1IDVFKQBQ0PostEntry*/
			/*}#1IDVFKQBQ0PostEntry*/
			return result;
		},
		/*#{1IDVFKQBQ0MoreAgentAttrs*/
		/*}#1IDVFKQBQ0MoreAgentAttrs*/
	};
	/*#{1IDVFKQBQ0PostAgent*/
	/*}#1IDVFKQBQ0PostAgent*/
	return agent;
};
/*#{1IDVFKQBQ0ExCodes*/
/*}#1IDVFKQBQ0ExCodes*/

//#CodyExport>>>
let ChatAPI=[{
	def:{
		name: "TestServer",
		description: "这是一个AI智能体。",
		parameters:{
			type: "object",
			properties:{
			}
		}
	},
	agent: TestServer
}];

//:Export Edit-AddOn:
const DocAIAgentExporter=VFACT.classRegs.DocAIAgentExporter;
if(DocAIAgentExporter){
	const EditAttr=VFACT.classRegs.EditAttr;
	const EditAISeg=VFACT.classRegs.EditAISeg;
	const EditAISegOutlet=VFACT.classRegs.EditAISegOutlet;
	const SegObjShellAttr=EditAISeg.SegObjShellAttr;
	const SegOutletDef=EditAISegOutlet.SegOutletDef;
	const docAIAgentExporter=DocAIAgentExporter.prototype;
	const packExtraCodes=docAIAgentExporter.packExtraCodes;
	const packResult=docAIAgentExporter.packResult;
	const varNameRegex = /^[a-zA-Z_$][a-zA-Z0-9_$]*$/;
	
	EditAISeg.regDef({
		name:"TestServer",showName:"TestServer",icon:"agent.svg",catalog:["AI Call"],
		attrs:{
			...SegObjShellAttr,
			"outlet":{name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc"}
		},
		listHint:["id","codes","desc"],
		desc:"这是一个AI智能体。"
	});
	
	DocAIAgentExporter.segTypeExporters["TestServer"]=
	function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let exportDebug=this.isExportDebug();
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();coder.newLine();
		{
			coder.packText(`let result,args={};`);coder.newLine();
			this.packExtraCodes(coder,seg,"PreCodes");
			coder.packText(`result= await session.pipeChat("/~/aae/ai/TestServer.js",args,false);`);coder.newLine();
			this.packExtraCodes(coder,seg,"PostCodes");
			this.packResult(coder,seg,seg.outlet);
		}
		coder.indentLess();coder.maybeNewLine();
		coder.packText(`};`);coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		coder.newLine();
	};
}
//#CodyExport<<<
/*#{1IDVFKQBQ0PostDoc*/
/*}#1IDVFKQBQ0PostDoc*/


export default TestServer;
export{TestServer};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DocAIAgent",
//	"jaxId": "1IDVFKQBQ0",
//	"attrs": {
//		"editObjs": {
//			"jaxId": "1IDVFKQBQ1",
//			"attrs": {
//				"TestServer": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1IDVFKQBQ7",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1IDVFKQBR0",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1IDVFKQBR1",
//							"attrs": {}
//						},
//						"functions": {
//							"jaxId": "1IDVFKQBR2",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false"
//					},
//					"mockups": {}
//				}
//			}
//		},
//		"agent": {
//			"jaxId": "1IDVFKQBQ2",
//			"attrs": {}
//		},
//		"entry": "",
//		"autoStart": "true",
//		"inBrowser": "false",
//		"debug": "true",
//		"apiArgs": {
//			"jaxId": "1IDVFKQBQ3",
//			"attrs": {}
//		},
//		"localVars": {
//			"jaxId": "1IDVFKQBQ4",
//			"attrs": {}
//		},
//		"context": {
//			"jaxId": "1IDVFKQBQ5",
//			"attrs": {}
//		},
//		"globalMockup": {
//			"jaxId": "1IDVFKQBQ6",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "aiseg",
//					"def": "askChat",
//					"jaxId": "1IDVFLMKV0",
//					"attrs": {
//						"id": "Ask",
//						"viewName": "",
//						"label": "",
//						"x": "135",
//						"y": "175",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1IDVFMBGB0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1IDVFMBGB1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"tip": "",
//						"tipRole": "Assistant",
//						"placeholder": "",
//						"text": "",
//						"file": "false",
//						"showText": "true",
//						"outlet": {
//							"jaxId": "1IDVFMBG60",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1IDVFLU2O0"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "callLLM",
//					"jaxId": "1IDVFLU2O0",
//					"attrs": {
//						"id": "CallLLM",
//						"viewName": "",
//						"label": "",
//						"x": "345",
//						"y": "175",
//						"desc": "执行一次LLM调用。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1IDVFMBGB2",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1IDVFMBGB3",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"platform": "\"OpenAI\"",
//						"mode": "GPT-3.5",
//						"system": "You are a smart assistant.",
//						"temperature": "0",
//						"maxToken": "2000",
//						"topP": "1",
//						"fqcP": "0",
//						"prcP": "0",
//						"messages": {
//							"attrs": []
//						},
//						"prompt": "#input",
//						"seed": "",
//						"outlet": {
//							"jaxId": "1IDVFMBG61",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1IDVFM6280"
//						},
//						"secret": "false",
//						"allowCheat": "false",
//						"GPTCheats": {
//							"attrs": []
//						},
//						"shareChatName": "",
//						"keepChat": "No",
//						"clearChat": "2",
//						"apiFiles": {
//							"attrs": []
//						},
//						"parallelFunction": "false",
//						"responseFormat": "text"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1IDVFM6280",
//					"attrs": {
//						"id": "Result",
//						"viewName": "",
//						"label": "",
//						"x": "565",
//						"y": "175",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1IDVFMBGB4",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1IDVFMBGB5",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "Assistant",
//						"text": "#input",
//						"outlet": {
//							"jaxId": "1IDVFMBG62",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							}
//						}
//					}
//				}
//			]
//		},
//		"desc": "这是一个AI智能体。",
//		"exportAPI": "true",
//		"exportAddOn": "true",
//		"addOnOpts": ""
//	}
//}