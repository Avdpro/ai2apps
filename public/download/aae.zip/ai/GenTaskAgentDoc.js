//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import pathLib from "/@path";
import inherits from "/@inherits";
import Base64 from "/@tabos/utils/base64.js";
import {trimJSON} from "/@aichat/utils.js";
/*#{1I0KK0V1B0MoreImports*/
import {tabFS} from "/@tabos";
/*}#1I0KK0V1B0MoreImports*/
const agentURL=(new URL(import.meta.url)).pathname;
const basePath=pathLib.dirname(agentURL);
const $ln=VFACT.lanCode||"EN";
/*#{1I0KK0V1B0StartDoc*/
let topWindow;
topWindow=window;
while(topWindow && topWindow.parent && topWindow.parent!==topWindow){
	topWindow=topWindow.parent;
}
const topVFACT=topWindow.VFACT;
const EditPrj=topVFACT.classRegs.EditPrj;
const editPrj=EditPrj.instance;
const EditAISeg=topVFACT.classRegs.EditAISeg;
/*}#1I0KK0V1B0StartDoc*/
//----------------------------------------------------------------------------
let GenTaskAgentDoc=async function(session){
	let agentVO,funcCode,filePath,hostName,startURL;
	let context,globalContext;
	let self;
	let CreateDoc,SaveDoc,UpdateIndex;
	/*#{1I0KK0V1B0LocalVals*/
	let app,fileCodes;
	app=topVFACT.app;
	let naviView=app.naviView;
	let infoView=app.infoView;
	/*}#1I0KK0V1B0LocalVals*/
	
	/*#{1I0KK0V1B0PreContext*/
	/*}#1I0KK0V1B0PreContext*/
	globalContext=session.globalContext;
	context={};
	context=VFACT.flexState(context);
	/*#{1I0KK0V1B0PostContext*/
	/*}#1I0KK0V1B0PostContext*/
	let agent,segs={};
	segs["CreateDoc"]=CreateDoc=async function(input){//:1I0KK2KAN0
		let result=input
		/*#{1I0KK2KAN0Code*/
		let fileCodes;
		agentVO={
			host:hostName,
			startURL:startURL,
			...agentVO,
		};
		fileCodes="export default "+funcCode;
		fileCodes+="\n";
		fileCodes+="export const SkillDef="+JSON.stringify(agentVO,"","\t")+";";
		result=fileCodes;
		/*}#1I0KK2KAN0Code*/
		return {seg:SaveDoc,result:(result),preSeg:"1I0KK2KAN0",outlet:"1I0KK2KAO0"};
	};
	CreateDoc.jaxId="1I0KK2KAN0"
	CreateDoc.url="CreateDoc@"+agentURL
	
	segs["SaveDoc"]=SaveDoc=async function(input){//:1I0KK6QI90
		let result=input
		/*#{1I0KK6QI90Code*/
		await tabFS.writeFile(filePath,input,"utf8");
		/*}#1I0KK6QI90Code*/
		return {seg:UpdateIndex,result:(result),preSeg:"1I0KK6QI90",outlet:"1I0KK6UNC2"};
	};
	SaveDoc.jaxId="1I0KK6QI90"
	SaveDoc.url="SaveDoc@"+agentURL
	
	segs["UpdateIndex"]=UpdateIndex=async function(input){//:1I0MUJVDJ0
		let result=input
		/*#{1I0MUJVDJ0Code*/
		let fileName,indexJSON,hostVO,skillsVO,path;
		fileName=pathLib.basename(filePath);
		path=basePath;
		if(path[0]==="/"){
			if(path[1]==="/"){
				path=path.substring(1);
			}else if(path[1]==="~"){
				path=path.substring(2);
			}
		}
		path=context.docPath=pathLib.join(path,"SkillIndex.json");
		try{
			indexJSON=await tabFS.readFile(path,"utf8");
			indexJSON=JSON.parse(indexJSON);
		}catch(err){
			indexJSON={};
		}
		hostVO=indexJSON[hostName];
		if(!hostVO){
			hostVO=indexJSON[hostName]={
				skills:{}
			};
		}
		skillsVO=hostVO.skills;
		skillsVO[fileName]=agentVO.desc;
		await tabFS.writeFile(path,JSON.stringify(indexJSON,null,"\t"),"utf8");
		/*}#1I0MUJVDJ0Code*/
		return {result:result};
	};
	UpdateIndex.jaxId="1I0MUJVDJ0"
	UpdateIndex.url="UpdateIndex@"+agentURL
	
	agent={
		isAIAgent:true,
		session:session,
		name:"GenTaskAgentDoc",
		url:agentURL,
		autoStart:true,
		jaxId:"1I0KK0V1B0",
		context:context,
		livingSeg:null,
		execChat:async function(input/*{agentVO,funcCode,filePath,hostName,startURL}*/){
			let result;
			if(typeof(input)=='object'){
				agentVO=input.agentVO;
				funcCode=input.funcCode;
				filePath=input.filePath;
				hostName=input.hostName;
				startURL=input.startURL;
			}else{
				agentVO=undefined;
				funcCode=undefined;
				filePath=undefined;
				hostName=undefined;
				startURL=undefined;
			}
			/*#{1I0KK0V1B0PreEntry*/
			/*}#1I0KK0V1B0PreEntry*/
			result={seg:CreateDoc,"input":input};
			/*#{1I0KK0V1B0PostEntry*/
			/*}#1I0KK0V1B0PostEntry*/
			return result;
		},
		/*#{1I0KK0V1B0MoreAgentAttrs*/
		/*}#1I0KK0V1B0MoreAgentAttrs*/
	};
	/*#{1I0KK0V1B0PostAgent*/
	/*}#1I0KK0V1B0PostAgent*/
	return agent;
};
/*#{1I0KK0V1B0ExCodes*/
/*}#1I0KK0V1B0ExCodes*/

export const ChatAPI=[{
	def:{
		name: "AGT_GenTaskAgentDoc",
		description: "This is an AI agent.",
		parameters:{
			type: "object",
			properties:{
				agentVO:{type:"auto",description:""},
				funcCode:{type:"string",description:""},
				filePath:{type:"auto",description:""},
				hostName:{type:"string",description:""},
				startURL:{type:"auto",description:""}
			}
		}
	},
	agent: GenTaskAgentDoc
}];

//:Export Edit-AddOn:
const DocAIAgentExporter=VFACT.classRegs.DocAIAgentExporter;
if(DocAIAgentExporter){
	const EditAttr=VFACT.classRegs.EditAttr;
	const EditAISeg=VFACT.classRegs.EditAISeg;
	const EditAISegOutlet=VFACT.classRegs.EditAISegOutlet;
	const SegObjShellAttr=EditAISeg.SegObjShellAttr;
	const SegOutletDef=EditAISegOutlet.SegOutletDef;
	const docAIAgentExporter=DocAIAgentExporter.prototype;
	const packExtraCodes=docAIAgentExporter.packExtraCodes;
	const packResult=docAIAgentExporter.packResult;
	const varNameRegex = /^[a-zA-Z_$][a-zA-Z0-9_$]*$/;
	
	EditAISeg.regDef({
		name:"GenTaskAgentDoc",showName:"GenTaskAgentDoc",icon:"agent.svg",catalog:["AI Call"],
		attrs:{
			...SegObjShellAttr,
			"agentVO":{name:"agentVO",type:"auto",key:1,fixed:1,initVal:""},
			"funcCode":{name:"funcCode",type:"string",key:1,fixed:1,initVal:""},
			"filePath":{name:"filePath",type:"auto",key:1,fixed:1,initVal:""},
			"hostName":{name:"hostName",type:"string",key:1,fixed:1,initVal:""},
			"startURL":{name:"startURL",type:"auto",key:1,fixed:1,initVal:""},
			"outlet":{name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc"}
		},
		listHint:["id","agentVO","funcCode","filePath","hostName","startURL","codes","desc"],
		desc:"This is an AI agent."
	});
	
	DocAIAgentExporter.segTypeExporters["GenTaskAgentDoc"]=
	function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let exportDebug=this.isExportDebug();
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();coder.newLine();
		{
			coder.packText(`let result,args={};`);coder.newLine();
			coder.packText("args['agentVO']=");this.genAttrStatement(seg.getAttr("agentVO"));coder.packText(";");coder.newLine();
			coder.packText("args['funcCode']=");this.genAttrStatement(seg.getAttr("funcCode"));coder.packText(";");coder.newLine();
			coder.packText("args['filePath']=");this.genAttrStatement(seg.getAttr("filePath"));coder.packText(";");coder.newLine();
			coder.packText("args['hostName']=");this.genAttrStatement(seg.getAttr("hostName"));coder.packText(";");coder.newLine();
			coder.packText("args['startURL']=");this.genAttrStatement(seg.getAttr("startURL"));coder.packText(";");coder.newLine();
			this.packExtraCodes(coder,seg,"PreCodes");
			coder.packText(`result= await session.pipeChat("/~/aae/ai/GenTaskAgentDoc.js",args,false);`);coder.newLine();
			this.packExtraCodes(coder,seg,"PostCodes");
			this.packResult(coder,seg,seg.outlet);
		}
		coder.indentLess();coder.maybeNewLine();
		coder.packText(`};`);coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		coder.newLine();
	};
}

export default GenTaskAgentDoc;
export{GenTaskAgentDoc};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DocAIAgent",
//	"jaxId": "1I0KK0V1B0",
//	"attrs": {
//		"editObjs": {
//			"jaxId": "1I0KK0V1B1",
//			"attrs": {
//				"GenTaskAgentDoc": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1I0KK0V1B7",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1I0KK0V1C0",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1I0KK0V1C1",
//							"attrs": {}
//						},
//						"functions": {
//							"jaxId": "1I0KK0V1C2",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false"
//					},
//					"mockups": {}
//				}
//			}
//		},
//		"agent": {
//			"jaxId": "1I0KK0V1B2",
//			"attrs": {}
//		},
//		"entry": "",
//		"autoStart": "true",
//		"debug": "true",
//		"apiArgs": {
//			"jaxId": "1I0KK0V1B3",
//			"attrs": {
//				"agentVO": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I0LLPAD80",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				},
//				"funcCode": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I0LLPAD81",
//					"attrs": {
//						"type": "String",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				},
//				"filePath": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I0MU1BFB0",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				},
//				"hostName": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I0VD1KVD0",
//					"attrs": {
//						"type": "String",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				},
//				"startURL": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I1214K8M0",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1I0KK0V1B4",
//			"attrs": {}
//		},
//		"context": {
//			"jaxId": "1I0KK0V1B5",
//			"attrs": {}
//		},
//		"globalMockup": {
//			"jaxId": "1I0KK0V1B6",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I0KK2KAN0",
//					"attrs": {
//						"id": "CreateDoc",
//						"label": "New AI Seg",
//						"x": "95",
//						"y": "110",
//						"desc": "This is an AISeg.",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0KK2KAN1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0KK2KAN2",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I0KK2KAO0",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0KK6QI90"
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I0KK6QI90",
//					"attrs": {
//						"id": "SaveDoc",
//						"label": "New AI Seg",
//						"x": "345",
//						"y": "110",
//						"desc": "This is an AISeg.",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0KK6UNE4",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0KK6UNE5",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I0KK6UNC2",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0MUJVDJ0"
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I0MUJVDJ0",
//					"attrs": {
//						"id": "UpdateIndex",
//						"label": "New AI Seg",
//						"x": "580",
//						"y": "110",
//						"desc": "This is an AISeg.",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0MUK9PS0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0MUK9PS1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I0MUK9PL0",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							}
//						},
//						"result": "#input"
//					}
//				}
//			]
//		},
//		"desc": "This is an AI agent.",
//		"exportAPI": "true",
//		"exportAddOn": "true",
//		"addOnOpts": ""
//	}
//}