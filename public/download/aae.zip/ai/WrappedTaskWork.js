//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import pathLib from "/@path";
import inherits from "/@inherits";
import Base64 from "/@tabos/utils/base64.js";
import {trimJSON} from "/@aichat/utils.js";
/*#{1I5D3SFAO0MoreImports*/
import {AAChatFlow} from "../AAChatFlow.js";
/*}#1I5D3SFAO0MoreImports*/
const agentURL=(new URL(import.meta.url)).pathname;
const basePath=pathLib.dirname(agentURL);
const $ln=VFACT.lanCode||"EN";
const argsTemplate={
	properties:{
		"hostBot":{
			"name":"hostBot","type":"auto",
			"defaultValue":"",
			"desc":"",
		},
		"taskWork":{
			"name":"taskWork","type":"auto",
			"defaultValue":"",
			"desc":"",
		},
		"progress":{
			"name":"progress","type":"auto",
			"defaultValue":"",
			"desc":"",
		}
	},
	/*#{1I5D3SFAO0ArgsView*/
	/*}#1I5D3SFAO0ArgsView*/
};

/*#{1I5D3SFAO0StartDoc*/
/*}#1I5D3SFAO0StartDoc*/
//----------------------------------------------------------------------------
let WrappedTaskWork=async function(session){
	let hostBot,taskWork,progress;
	let context,globalContext;
	let self;
	let Start,WorkCore,WorkResult,NewTaskReq,NotifyTask,WorkEnd,FinishWork,AskUser,CatchError,FailWork;
	let botId="";
	let taskId="";
	let fromId="";
	let workPrompt="";
	let chatFlow="";
	let messages=undefined;
	
	/*#{1I5D3SFAO0LocalVals*/
	/*}#1I5D3SFAO0LocalVals*/
	
	function parseAgentArgs(input){
		if(typeof(input)=='object'){
			hostBot=input.hostBot;
			taskWork=input.taskWork;
			progress=input.progress;
		}else{
			hostBot=undefined;
			taskWork=undefined;
			progress=undefined;
		}
		/*#{1I5D3SFAO0ParseArgs*/
		/*}#1I5D3SFAO0ParseArgs*/
	}
	
	/*#{1I5D3SFAO0PreContext*/
	/*}#1I5D3SFAO0PreContext*/
	globalContext=session.globalContext;
	context={};
	context=VFACT.flexState(context);
	/*#{1I5D3SFAO0PostContext*/
	/*}#1I5D3SFAO0PostContext*/
	let agent,segs={};
	segs["Start"]=Start=async function(input){//:1I5D3SJFN0
		let result=input
		/*#{1I5D3SJFN0Code*/
		let flowObj,hierarchy,parentTask,subTasks;
		botId=hostBot.id;
		fromId=taskWork.fromBot;
		taskId=taskWork.id;
		chatFlow=taskWork.chatFlow;
		flowObj=await AAChatFlow.getFlow(chatFlow);
		
		messages=[];
		if(progress){
			hierarchy=await taskWork.getHierarchy();
			//TODO: construct messages:
		}else{
			workPrompt=taskWork.prompt;
		}
		//Init session
		/*}#1I5D3SJFN0Code*/
		return {seg:CatchError,result:(result),preSeg:"1I5D3SJFN0",outlet:"1I5D3SQRH0"};
	};
	Start.jaxId="1I5D3SJFN0"
	Start.url="Start@"+agentURL
	
	segs["WorkCore"]=WorkCore=async function(input){//:1I5D6AGQI0
		let result;
		let sourcePath=pathLib.joinTabOSURL(basePath,"./BotWorkCore.js");
		let arg={"hostBot":hostBot,"command":workPrompt,"chatMessages":messages};
		/*#{1I5D6AGQI0Input*/
		/*}#1I5D6AGQI0Input*/
		result= await session.pipeChat(sourcePath,arg,false);
		/*#{1I5D6AGQI0Output*/
		console.log("[WrappedTaskWork]WorkCore result:");
		console.log(result);
		/*}#1I5D6AGQI0Output*/
		return {seg:WorkResult,result:(result),preSeg:"1I5D6AGQI0",outlet:"1I5D6AP3T0"};
	};
	WorkCore.jaxId="1I5D6AGQI0"
	WorkCore.url="WorkCore@"+agentURL
	
	segs["WorkResult"]=WorkResult=async function(input){//:1I5D6B1JA0
		let result=input;
		if(input==="Task"){
			return {seg:NewTaskReq,result:(input),preSeg:"1I5D6B1JA0",outlet:"1I5D6HJFF0"};
		}
		if(input.finish){
			/*#{1I5D6BIQG0Codes*/
			//Finish task:
			await taskWork.finish(input.result,input.assets);
			/*}#1I5D6BIQG0Codes*/
			return {seg:FinishWork,result:(input),preSeg:"1I5D6B1JA0",outlet:"1I5D6BIQG0"};
		}
		if(input.ask){
			return {seg:AskUser,result:(input),preSeg:"1I5D6B1JA0",outlet:"1I5NEPGR20"};
		}
		return {seg:WorkEnd,result:(result),preSeg:"1I5D6B1JA0",outlet:"1I5D6B6RO0"};
	};
	WorkResult.jaxId="1I5D6B1JA0"
	WorkResult.url="WorkResult@"+agentURL
	
	segs["NewTaskReq"]=NewTaskReq=async function(input){//:1I5D6DFLK0
		let result=input
		/*#{1I5D6DFLK0Code*/
		/*}#1I5D6DFLK0Code*/
		return {seg:NotifyTask,result:(result),preSeg:"1I5D6DFLK0",outlet:"1I5D6HJFF1"};
	};
	NewTaskReq.jaxId="1I5D6DFLK0"
	NewTaskReq.url="NewTaskReq@"+agentURL
	
	segs["NotifyTask"]=NotifyTask=async function(input){//:1I5D6E21Q0
		let result=input
		/*#{1I5D6E21Q0Code*/
		/*}#1I5D6E21Q0Code*/
		return {seg:WorkEnd,result:(result),preSeg:"1I5D6E21Q0",outlet:"1I5D6HJFF2"};
	};
	NotifyTask.jaxId="1I5D6E21Q0"
	NotifyTask.url="NotifyTask@"+agentURL
	
	segs["WorkEnd"]=WorkEnd=async function(input){//:1I5D6EO8D0
		let result=input
		/*#{1I5D6EO8D0Code*/
		/*}#1I5D6EO8D0Code*/
		return {result:result};
	};
	WorkEnd.jaxId="1I5D6EO8D0"
	WorkEnd.url="WorkEnd@"+agentURL
	
	segs["FinishWork"]=FinishWork=async function(input){//:1I5DPA49H0
		let result=input
		/*#{1I5DPA49H0Code*/
		/*}#1I5DPA49H0Code*/
		return {result:result};
	};
	FinishWork.jaxId="1I5DPA49H0"
	FinishWork.url="FinishWork@"+agentURL
	
	segs["AskUser"]=AskUser=async function(input){//:1I5NEOVV00
		let result=input
		/*#{1I5NEOVV00Code*/
		let msgVO,flowObj;
		flowObj=await AAChatFlow.getFlow(chatFlow);
		msgVO={
			type:"Ask",
			from:hostBot.id,to:flowObj.from,
			content:{
				text:input.ask,assets:input.assets
			}
		};
		await hostBot.sendMessage(msgVO);
		/*}#1I5NEOVV00Code*/
		return {result:result};
	};
	AskUser.jaxId="1I5NEOVV00"
	AskUser.url="AskUser@"+agentURL
	
	segs["CatchError"]=CatchError=async function(input){//:1I5FQ5AHT0
		let result=input;
		/*#{1I5FQ5AHT0Code*/
		false
		/*}#1I5FQ5AHT0Code*/
		return {seg:WorkCore,result:(result),preSeg:"1I5FQ5AHT0",outlet:"1I5HVSG520",catchSeg:FailWork,catchlet:"1I5HVSG521"};
	};
	CatchError.jaxId="1I5FQ5AHT0"
	CatchError.url="CatchError@"+agentURL
	
	segs["FailWork"]=FailWork=async function(input){//:1I5FQ5ST80
		let result=input
		/*#{1I5FQ5ST80Code*/
		/*}#1I5FQ5ST80Code*/
		return {result:result};
	};
	FailWork.jaxId="1I5FQ5ST80"
	FailWork.url="FailWork@"+agentURL
	
	agent={
		isAIAgent:true,
		session:session,
		name:"WrappedTaskWork",
		url:agentURL,
		autoStart:true,
		jaxId:"1I5D3SFAO0",
		context:context,
		livingSeg:null,
		execChat:async function(input/*{hostBot,taskWork,progress}*/){
			let result;
			parseAgentArgs(input);
			/*#{1I5D3SFAO0PreEntry*/
			/*}#1I5D3SFAO0PreEntry*/
			result={seg:Start,"input":input};
			/*#{1I5D3SFAO0PostEntry*/
			/*}#1I5D3SFAO0PostEntry*/
			return result;
		},
		/*#{1I5D3SFAO0MoreAgentAttrs*/
		/*}#1I5D3SFAO0MoreAgentAttrs*/
	};
	/*#{1I5D3SFAO0PostAgent*/
	/*}#1I5D3SFAO0PostAgent*/
	return agent;
};
/*#{1I5D3SFAO0ExCodes*/
/*}#1I5D3SFAO0ExCodes*/

export const ChatAPI=[{
	def:{
		name: "WrappedTaskWork",
		description: "这是一个AI智能体。",
		parameters:{
			type: "object",
			properties:{
				hostBot:{type:"auto",description:""},
				taskWork:{type:"auto",description:""},
				progress:{type:"auto",description:""}
			}
		}
	},
	agent: WrappedTaskWork
}];

//:Export Edit-AddOn:
const DocAIAgentExporter=VFACT.classRegs.DocAIAgentExporter;
if(DocAIAgentExporter){
	const EditAttr=VFACT.classRegs.EditAttr;
	const EditAISeg=VFACT.classRegs.EditAISeg;
	const EditAISegOutlet=VFACT.classRegs.EditAISegOutlet;
	const SegObjShellAttr=EditAISeg.SegObjShellAttr;
	const SegOutletDef=EditAISegOutlet.SegOutletDef;
	const docAIAgentExporter=DocAIAgentExporter.prototype;
	const packExtraCodes=docAIAgentExporter.packExtraCodes;
	const packResult=docAIAgentExporter.packResult;
	const varNameRegex = /^[a-zA-Z_$][a-zA-Z0-9_$]*$/;
	
	EditAISeg.regDef({
		name:"WrappedTaskWork",showName:"WrappedTaskWork",icon:"agent.svg",catalog:["AI Call"],
		attrs:{
			...SegObjShellAttr,
			"hostBot":{name:"hostBot",type:"auto",key:1,fixed:1,initVal:""},
			"taskWork":{name:"taskWork",type:"auto",key:1,fixed:1,initVal:""},
			"progress":{name:"progress",type:"auto",key:1,fixed:1,initVal:""},
			"outlet":{name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc"}
		},
		listHint:["id","hostBot","taskWork","progress","codes","desc"],
		desc:"这是一个AI智能体。"
	});
	
	DocAIAgentExporter.segTypeExporters["WrappedTaskWork"]=
	function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let exportDebug=this.isExportDebug();
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();coder.newLine();
		{
			coder.packText(`let result,args={};`);coder.newLine();
			coder.packText("args['hostBot']=");this.genAttrStatement(seg.getAttr("hostBot"));coder.packText(";");coder.newLine();
			coder.packText("args['taskWork']=");this.genAttrStatement(seg.getAttr("taskWork"));coder.packText(";");coder.newLine();
			coder.packText("args['progress']=");this.genAttrStatement(seg.getAttr("progress"));coder.packText(";");coder.newLine();
			this.packExtraCodes(coder,seg,"PreCodes");
			coder.packText(`result= await session.pipeChat("/~/aae/ai/WrappedTaskWork.js",args,false);`);coder.newLine();
			this.packExtraCodes(coder,seg,"PostCodes");
			this.packResult(coder,seg,seg.outlet);
		}
		coder.indentLess();coder.maybeNewLine();
		coder.packText(`};`);coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		coder.newLine();
	};
}
/*#{1I5D3SFAO0PostDoc*/
/*}#1I5D3SFAO0PostDoc*/


export default WrappedTaskWork;
export{WrappedTaskWork};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DocAIAgent",
//	"jaxId": "1I5D3SFAO0",
//	"attrs": {
//		"editObjs": {
//			"jaxId": "1I5D3SFAO1",
//			"attrs": {
//				"WrappedTaskWork": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1I5D3SFAO7",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1I5D3SFAO8",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1I5D3SFAO9",
//							"attrs": {}
//						},
//						"functions": {
//							"jaxId": "1I5D3SFAO10",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false"
//					},
//					"mockups": {}
//				}
//			}
//		},
//		"agent": {
//			"jaxId": "1I5D3SFAO2",
//			"attrs": {}
//		},
//		"entry": "",
//		"autoStart": "true",
//		"debug": "true",
//		"apiArgs": {
//			"jaxId": "1I5D3SFAO3",
//			"attrs": {
//				"hostBot": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I5D4294H0",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				},
//				"taskWork": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I5D43B6I0",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				},
//				"progress": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I5DOPQA30",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1I5D3SFAO4",
//			"attrs": {
//				"botId": {
//					"type": "string",
//					"valText": ""
//				},
//				"taskId": {
//					"type": "string",
//					"valText": ""
//				},
//				"fromId": {
//					"type": "string",
//					"valText": ""
//				},
//				"workPrompt": {
//					"type": "string",
//					"valText": ""
//				},
//				"chatFlow": {
//					"type": "string",
//					"valText": ""
//				},
//				"messages": {
//					"type": "auto",
//					"valText": ""
//				}
//			}
//		},
//		"context": {
//			"jaxId": "1I5D3SFAO5",
//			"attrs": {}
//		},
//		"globalMockup": {
//			"jaxId": "1I5D3SFAO6",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I5D3SJFN0",
//					"attrs": {
//						"id": "Start",
//						"label": "New AI Seg",
//						"x": "100",
//						"y": "195",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I5D3SQRK0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I5D3SQRK1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I5D3SQRH0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I5FQ5AHT0"
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "aiBot",
//					"jaxId": "1I5D6AGQI0",
//					"attrs": {
//						"id": "WorkCore",
//						"label": "New AI Seg",
//						"x": "520",
//						"y": "180",
//						"desc": "调用其它AI Agent，把调用的结果作为输出",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I5D6AP420",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I5D6AP421",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"source": "ai/BotWorkCore.js",
//						"argument": "{\"hostBot\":\"#hostBot\",\"command\":\"#workPrompt\",\"chatMessages\":\"#messages\"}",
//						"secret": "false",
//						"outlet": {
//							"jaxId": "1I5D6AP3T0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I5D6B1JA0"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "brunch",
//					"jaxId": "1I5D6B1JA0",
//					"attrs": {
//						"id": "WorkResult",
//						"label": "New AI Seg",
//						"x": "740",
//						"y": "180",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I5D6B6RR0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I5D6B6RR1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I5D6B6RO0",
//							"attrs": {
//								"id": "Default",
//								"desc": "输出节点。",
//								"output": ""
//							},
//							"linkedSeg": "1I5D6CVLJ0"
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I5D6HJFF0",
//									"attrs": {
//										"id": "Task",
//										"desc": "输出节点。",
//										"output": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I5D6HJFK0",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I5D6HJFK1",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": ""
//									},
//									"linkedSeg": "1I5D6DFLK0"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I5D6BIQG0",
//									"attrs": {
//										"id": "Finish",
//										"desc": "输出节点。",
//										"output": "",
//										"codes": "true",
//										"context": {
//											"jaxId": "1I5D6HJFK2",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I5D6HJFK3",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#input.finish"
//									},
//									"linkedSeg": "1I5DPA49H0"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I5NEPGR20",
//									"attrs": {
//										"id": "Ask",
//										"desc": "输出节点。",
//										"output": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I5NEPGR50",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I5NEPGR51",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#input.ask"
//									},
//									"linkedSeg": "1I5NEOVV00"
//								}
//							]
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connectorL",
//					"jaxId": "1I5D6CVLJ0",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "990",
//						"y": "275",
//						"outlet": {
//							"jaxId": "1I5D6HJFK4",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I5D6EEHS0"
//						},
//						"dir": "L2R"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I5D6DFLK0",
//					"attrs": {
//						"id": "NewTaskReq",
//						"label": "New AI Seg",
//						"x": "990",
//						"y": "75",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I5D6HJFK5",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I5D6HJFK6",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I5D6HJFF1",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I5D6E21Q0"
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I5D6E21Q0",
//					"attrs": {
//						"id": "NotifyTask",
//						"label": "New AI Seg",
//						"x": "1230",
//						"y": "75",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I5D6HJFK7",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I5D6HJFK8",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I5D6HJFF2",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I5D6EO8D0"
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connectorL",
//					"jaxId": "1I5D6EEHS0",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "1335",
//						"y": "275",
//						"outlet": {
//							"jaxId": "1I5D6HJFK9",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I5D6EO8D0"
//						},
//						"dir": "L2R"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I5D6EO8D0",
//					"attrs": {
//						"id": "WorkEnd",
//						"label": "New AI Seg",
//						"x": "1455",
//						"y": "180",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I5D6HJFK10",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I5D6HJFK11",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I5D6HJFF3",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							}
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I5DPA49H0",
//					"attrs": {
//						"id": "FinishWork",
//						"label": "New AI Seg",
//						"x": "990",
//						"y": "145",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "flag.svg",
//						"context": {
//							"jaxId": "1I5DPAI9P0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I5DPAI9P1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I5DPAI9F0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							}
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I5NEOVV00",
//					"attrs": {
//						"id": "AskUser",
//						"label": "New AI Seg",
//						"x": "990",
//						"y": "215",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "flag.svg",
//						"context": {
//							"jaxId": "1I5NEPGR52",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I5NEPGR60",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I5NEPGR21",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							}
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "tryCatch",
//					"jaxId": "1I5FQ5AHT0",
//					"attrs": {
//						"id": "CatchError",
//						"label": "New AI Seg",
//						"x": "295",
//						"y": "195",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I5HVSI830",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I5HVSI831",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I5HVSG520",
//							"attrs": {
//								"id": "Try",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I5D6AGQI0"
//						},
//						"catchlet": {
//							"jaxId": "1I5HVSG521",
//							"attrs": {
//								"id": "Catch",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I5FQ5ST80"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I5FQ5ST80",
//					"attrs": {
//						"id": "FailWork",
//						"label": "New AI Seg",
//						"x": "520",
//						"y": "285",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "flag.svg",
//						"context": {
//							"jaxId": "1I5HVSI832",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I5HVSI833",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I5HVSG530",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							}
//						},
//						"result": "#input"
//					}
//				}
//			]
//		},
//		"desc": "这是一个AI智能体。",
//		"exportAPI": "true",
//		"exportAddOn": "true",
//		"addOnOpts": ""
//	}
//}