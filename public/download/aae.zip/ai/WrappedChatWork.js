//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import pathLib from "/@path";
import inherits from "/@inherits";
import Base64 from "/@tabos/utils/base64.js";
import {trimJSON} from "/@aichat/utils.js";
/*#{1I5CINK1A0MoreImports*/
import {AABotNode} from "../AABotNode.js";
import {AAChatFlow} from "../AAChatFlow.js";
/*}#1I5CINK1A0MoreImports*/
const agentURL=(new URL(import.meta.url)).pathname;
const basePath=pathLib.dirname(agentURL);
const $ln=VFACT.lanCode||"EN";
const argsTemplate={
	properties:{
		"botId":{
			"name":"botId","type":"auto",
			"defaultValue":"",
			"desc":"",
		},
		"chatMsg":{
			"name":"chatMsg","type":"auto",
			"defaultValue":"",
			"desc":"",
		}
	},
	/*#{1I5CINK1A0ArgsView*/
	/*}#1I5CINK1A0ArgsView*/
};

/*#{1I5CINK1A0StartDoc*/
/*}#1I5CINK1A0StartDoc*/
//----------------------------------------------------------------------------
let WrappedChatWork=async function(session){
	let botId,chatMsg;
	let context,globalContext;
	let self;
	let Start,WorkCore,CoreResult,NewTaskReq,SendReply,NotifyTask;
	let aaBotNode=AABotNode.getAppBotNode(false);
	let hostBot=null;
	let fromId="";
	let command="";
	let chatFlow=null;
	let messages=[];
	let flowFromId="";
	
	/*#{1I5CINK1A0LocalVals*/
	/*}#1I5CINK1A0LocalVals*/
	
	function parseAgentArgs(input){
		if(typeof(input)=='object'){
			botId=input.botId;
			chatMsg=input.chatMsg;
		}else{
			botId=undefined;
			chatMsg=undefined;
		}
		/*#{1I5CINK1A0ParseArgs*/
		/*}#1I5CINK1A0ParseArgs*/
	}
	
	/*#{1I5CINK1A0PreContext*/
	/*}#1I5CINK1A0PreContext*/
	globalContext=session.globalContext;
	context={};
	context=VFACT.flexState(context);
	/*#{1I5CINK1A0PostContext*/
	/*}#1I5CINK1A0PostContext*/
	let agent,segs={};
	segs["Start"]=Start=async function(input){//:1I5CJQ6BF0
		let result=input
		/*#{1I5CJQ6BF0Code*/
		await aaBotNode.syncBots();
		hostBot=aaBotNode.getBot(botId);
		fromId=chatMsg.from;
		if(chatMsg.content.type){
			command=chatMsg.content.text;
		}else{
			command=chatMsg.content;
		}
		//Make chat history:
		chatFlow=chatMsg.chatFlow;
		if(chatFlow){
			let flowObj;
			flowObj=await AAChatFlow.getFlow(chatFlow);
			messages.splice(0);
			if(flowObj){
				let flowMsgs,msg;
				flowFromId=flowObj.from;
				flowMsgs=flowObj.messages;
				console.log("[WrappedChatWork.js]ChatFlow messages:");
				console.log([...flowMsgs]);
				/*if(flowMsgs.length>=15){
					throw Error("Chat flow too deep!!");
				}*/
				for(msg of flowMsgs){
					if(msg.from===botId && msg.to===fromId){
						messages.push({role:"assistant",content:`{"reply":"${msg.content.text||msg.content}"}`});
					}else if(msg.to===botId && msg.from===fromId){
						messages.push({role:"user",content:msg.content.text||msg.content});
					}else if(msg.from===botId && msg.to===botId){
						messages.push({role:"assistant",content:msg.content.text||msg.content});
					}
				}
				messages.pop();
			}
		}
		/*}#1I5CJQ6BF0Code*/
		return {seg:WorkCore,result:(result),preSeg:"1I5CJQ6BF0",outlet:"1I5CJQDJJ0"};
	};
	Start.jaxId="1I5CJQ6BF0"
	Start.url="Start@"+agentURL
	
	segs["WorkCore"]=WorkCore=async function(input){//:1I5CPFD5G0
		let result;
		let sourcePath=pathLib.joinTabOSURL(basePath,"./BotWorkCore.js");
		let arg={"hostBot":hostBot,"command":command,"chatMessages":messages};
		result= await session.pipeChat(sourcePath,arg,false);
		return {seg:CoreResult,result:(result),preSeg:"1I5CPFD5G0",outlet:"1I5CPL1CR0"};
	};
	WorkCore.jaxId="1I5CPFD5G0"
	WorkCore.url="WorkCore@"+agentURL
	
	segs["CoreResult"]=CoreResult=async function(input){//:1I5CPFQVT0
		let result=input;
		/*#{1I5CPFQVT0Start*/
		let msgVO,content,assets;
		content=input.result||input;
		assets=input.assets;
		if(assets){
			msgVO={
				to:fromId,from:botId,type:"Chat",chatFlow:chatFlow,
				content:{
					text:content,assets:assets
				}
			};
		}else{
			msgVO={
				to:fromId,from:botId,type:"Chat",chatFlow:chatFlow,
				content:content
			};
		}
		if(msgVO.to===botId){
			msgVO.to=flowFromId;
		}
		/*}#1I5CPFQVT0Start*/
		if(input.botTaskReq){
			let output=input.botTaskReq;
			return {seg:NewTaskReq,result:(output),preSeg:"1I5CPFQVT0",outlet:"1I5CPL1CR1"};
		}
		if(input.finish){
			let output=msgVO;
			/*#{1I5CPJU510Codes*/
			await AAChatFlow.closeFlow(msgVO.chatFlow);
			msgVO.chatFlowFinish=true;
			/*}#1I5CPJU510Codes*/
			return {seg:SendReply,result:(output),preSeg:"1I5CPFQVT0",outlet:"1I5CPJU510"};
		}
		/*#{1I5CPFQVT0Post*/
		result=msgVO;
		/*}#1I5CPFQVT0Post*/
		return {seg:SendReply,result:(result),preSeg:"1I5CPFQVT0",outlet:"1I5CPL1CR2"};
	};
	CoreResult.jaxId="1I5CPFQVT0"
	CoreResult.url="CoreResult@"+agentURL
	
	segs["NewTaskReq"]=NewTaskReq=async function(input){//:1I5CPIN6O0
		let result=input
		/*#{1I5CPIN6O0Code*/
		let msgVO,taskReq;
		taskReq=await hostBot.newTaskReq(input.bot,input.prompt,chatFlow);
		result={
			to:fromId,from:botId,type:"User",
			content:`Bot-task {bot: "${input.bot}", prompt: ${JSON.stringify(input.prompt)}} created, it may take a while to finish. Please wait.`,
			chatFlow:chatFlow
		};
		/*}#1I5CPIN6O0Code*/
		return {seg:NotifyTask,result:(result),preSeg:"1I5CPIN6O0",outlet:"1I5CPL1CR3"};
	};
	NewTaskReq.jaxId="1I5CPIN6O0"
	NewTaskReq.url="NewTaskReq@"+agentURL
	
	segs["SendReply"]=SendReply=async function(input){//:1I5CPKFG90
		let result=input
		/*#{1I5CPKFG90Code*/
		console.log(input);
		await hostBot.sendMessage(input.to||(fromId===botId?flowFromId:fromId),input);
		/*}#1I5CPKFG90Code*/
		return {result:result};
	};
	SendReply.jaxId="1I5CPKFG90"
	SendReply.url="SendReply@"+agentURL
	
	segs["NotifyTask"]=NotifyTask=async function(input){//:1I5CRM0OM0
		let result=input
		/*#{1I5CRM0OM0Code*/
		/*}#1I5CRM0OM0Code*/
		return {seg:SendReply,result:(result),preSeg:"1I5CRM0OM0",outlet:"1I5CRMIJL0"};
	};
	NotifyTask.jaxId="1I5CRM0OM0"
	NotifyTask.url="NotifyTask@"+agentURL
	
	agent={
		isAIAgent:true,
		session:session,
		name:"WrappedChatWork",
		url:agentURL,
		autoStart:true,
		jaxId:"1I5CINK1A0",
		context:context,
		livingSeg:null,
		execChat:async function(input/*{botId,chatMsg}*/){
			let result;
			parseAgentArgs(input);
			/*#{1I5CINK1A0PreEntry*/
			/*}#1I5CINK1A0PreEntry*/
			result={seg:Start,"input":input};
			/*#{1I5CINK1A0PostEntry*/
			/*}#1I5CINK1A0PostEntry*/
			return result;
		},
		/*#{1I5CINK1A0MoreAgentAttrs*/
		/*}#1I5CINK1A0MoreAgentAttrs*/
	};
	/*#{1I5CINK1A0PostAgent*/
	/*}#1I5CINK1A0PostAgent*/
	return agent;
};
/*#{1I5CINK1A0ExCodes*/
/*}#1I5CINK1A0ExCodes*/

export const ChatAPI=[{
	def:{
		name: "WrappedChatWork",
		description: "这是一个AI智能体。",
		parameters:{
			type: "object",
			properties:{
				botId:{type:"auto",description:""},
				chatMsg:{type:"auto",description:""}
			}
		}
	},
	agent: WrappedChatWork
}];

//:Export Edit-AddOn:
const DocAIAgentExporter=VFACT.classRegs.DocAIAgentExporter;
if(DocAIAgentExporter){
	const EditAttr=VFACT.classRegs.EditAttr;
	const EditAISeg=VFACT.classRegs.EditAISeg;
	const EditAISegOutlet=VFACT.classRegs.EditAISegOutlet;
	const SegObjShellAttr=EditAISeg.SegObjShellAttr;
	const SegOutletDef=EditAISegOutlet.SegOutletDef;
	const docAIAgentExporter=DocAIAgentExporter.prototype;
	const packExtraCodes=docAIAgentExporter.packExtraCodes;
	const packResult=docAIAgentExporter.packResult;
	const varNameRegex = /^[a-zA-Z_$][a-zA-Z0-9_$]*$/;
	
	EditAISeg.regDef({
		name:"WrappedChatWork",showName:"WrappedChatWork",icon:"agent.svg",catalog:["AI Call"],
		attrs:{
			...SegObjShellAttr,
			"botId":{name:"botId",type:"auto",key:1,fixed:1,initVal:""},
			"chatMsg":{name:"chatMsg",type:"auto",key:1,fixed:1,initVal:""},
			"outlet":{name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc"}
		},
		listHint:["id","botId","chatMsg","codes","desc"],
		desc:"这是一个AI智能体。"
	});
	
	DocAIAgentExporter.segTypeExporters["WrappedChatWork"]=
	function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let exportDebug=this.isExportDebug();
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();coder.newLine();
		{
			coder.packText(`let result,args={};`);coder.newLine();
			coder.packText("args['botId']=");this.genAttrStatement(seg.getAttr("botId"));coder.packText(";");coder.newLine();
			coder.packText("args['chatMsg']=");this.genAttrStatement(seg.getAttr("chatMsg"));coder.packText(";");coder.newLine();
			this.packExtraCodes(coder,seg,"PreCodes");
			coder.packText(`result= await session.pipeChat("/~/aae/ai/WrappedChatWork.js",args,false);`);coder.newLine();
			this.packExtraCodes(coder,seg,"PostCodes");
			this.packResult(coder,seg,seg.outlet);
		}
		coder.indentLess();coder.maybeNewLine();
		coder.packText(`};`);coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		coder.newLine();
	};
}
/*#{1I5CINK1A0PostDoc*/
/*}#1I5CINK1A0PostDoc*/


export default WrappedChatWork;
export{WrappedChatWork};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DocAIAgent",
//	"jaxId": "1I5CINK1A0",
//	"attrs": {
//		"editObjs": {
//			"jaxId": "1I5CINK1A1",
//			"attrs": {
//				"WrappedChatWork": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1I5CINK1A7",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1I5CINK1B0",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1I5CINK1B1",
//							"attrs": {}
//						},
//						"functions": {
//							"jaxId": "1I5CINK1B2",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false"
//					},
//					"mockups": {}
//				}
//			}
//		},
//		"agent": {
//			"jaxId": "1I5CINK1A2",
//			"attrs": {}
//		},
//		"entry": "",
//		"autoStart": "true",
//		"debug": "true",
//		"apiArgs": {
//			"jaxId": "1I5CINK1A3",
//			"attrs": {
//				"botId": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I5CISVTA0",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				},
//				"chatMsg": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I5CISVTA1",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1I5CINK1A4",
//			"attrs": {
//				"aaBotNode": {
//					"type": "auto",
//					"valText": "#AABotNode.getAppBotNode(false)"
//				},
//				"hostBot": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"fromId": {
//					"type": "string",
//					"valText": ""
//				},
//				"command": {
//					"type": "string",
//					"valText": ""
//				},
//				"chatFlow": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"messages": {
//					"type": "auto",
//					"valText": "[]"
//				},
//				"flowFromId": {
//					"type": "string",
//					"valText": ""
//				}
//			}
//		},
//		"context": {
//			"jaxId": "1I5CINK1A5",
//			"attrs": {}
//		},
//		"globalMockup": {
//			"jaxId": "1I5CINK1A6",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I5CJQ6BF0",
//					"attrs": {
//						"id": "Start",
//						"label": "New AI Seg",
//						"x": "95",
//						"y": "260",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I5CJQTB10",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I5CJQTB11",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I5CJQDJJ0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I5CPFD5G0"
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "aiBot",
//					"jaxId": "1I5CPFD5G0",
//					"attrs": {
//						"id": "WorkCore",
//						"label": "New AI Seg",
//						"x": "295",
//						"y": "260",
//						"desc": "调用其它AI Agent，把调用的结果作为输出",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I5CPL1D00",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I5CPL1D01",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"source": "ai/BotWorkCore.js",
//						"argument": "{\"hostBot\":\"#hostBot\",\"command\":\"#command\",\"chatMessages\":\"#messages\"}",
//						"secret": "false",
//						"outlet": {
//							"jaxId": "1I5CPL1CR0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I5CPFQVT0"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "brunch",
//					"jaxId": "1I5CPFQVT0",
//					"attrs": {
//						"id": "CoreResult",
//						"label": "New AI Seg",
//						"x": "520",
//						"y": "260",
//						"desc": "这是一个AISeg。",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I5CPL1D02",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I5CPL1D03",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I5CPL1CR2",
//							"attrs": {
//								"id": "Default",
//								"desc": "输出节点。",
//								"output": ""
//							},
//							"linkedSeg": "1I5CUTK3J0"
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I5CPL1CR1",
//									"attrs": {
//										"id": "Task",
//										"desc": "输出节点。",
//										"output": "#input.botTaskReq",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I5CPL1D04",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I5CPL1D05",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#input.botTaskReq"
//									},
//									"linkedSeg": "1I5CPIN6O0"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I5CPJU510",
//									"attrs": {
//										"id": "Finished",
//										"desc": "输出节点。",
//										"output": "#msgVO",
//										"codes": "true",
//										"context": {
//											"jaxId": "1I5CPL1D06",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I5CPL1D07",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#input.finish"
//									},
//									"linkedSeg": "1I5CUTK3J0"
//								}
//							]
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I5CPIN6O0",
//					"attrs": {
//						"id": "NewTaskReq",
//						"label": "New AI Seg",
//						"x": "760",
//						"y": "230",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I5CPL1D08",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I5CPL1D09",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I5CPL1CR3",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I5CRM0OM0"
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I5CPKFG90",
//					"attrs": {
//						"id": "SendReply",
//						"label": "New AI Seg",
//						"x": "1230",
//						"y": "260",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "flag.svg",
//						"context": {
//							"jaxId": "1I5CPL1D010",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I5CPL1D011",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I5CPL1CR4",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							}
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I5CRM0OM0",
//					"attrs": {
//						"id": "NotifyTask",
//						"label": "New AI Seg",
//						"x": "1000",
//						"y": "230",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "",
//						"context": {
//							"jaxId": "1I5CRMIJS0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I5CRMIJS1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I5CRMIJL0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I5CPKFG90"
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connectorL",
//					"jaxId": "1I5CUTK3J0",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "760",
//						"y": "290",
//						"outlet": {
//							"jaxId": "1I5CUU3DD0",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I5DNEOL70"
//						},
//						"dir": "L2R"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connectorL",
//					"jaxId": "1I5DNEOL70",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "1110",
//						"y": "290",
//						"outlet": {
//							"jaxId": "1I5DNF0M00",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I5CPKFG90"
//						},
//						"dir": "L2R"
//					}
//				}
//			]
//		},
//		"desc": "这是一个AI智能体。",
//		"exportAPI": "true",
//		"exportAddOn": "true",
//		"addOnOpts": ""
//	}
//}