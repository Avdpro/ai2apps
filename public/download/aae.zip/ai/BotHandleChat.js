//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import pathLib from "/@path";
import inherits from "/@inherits";
import Base64 from "/@tabos/utils/base64.js";
import {trimJSON} from "/@aichat/utils.js";
/*#{1I33BVLV00MoreImports*/
import {tabFS} from "/@tabos";
import {AASkills} from "/@aae/AASkills.js";
import {AABotNode} from "../AABotNode.js";
import {AAChatFlow} from "../AAChatFlow.js";
/*}#1I33BVLV00MoreImports*/
const agentURL=(new URL(import.meta.url)).pathname;
const basePath=pathLib.dirname(agentURL);
const $ln=VFACT.lanCode||"EN";
const argsTemplate={
	properties:{
		"botId":{
			"name":"botId","type":"auto",
			"defaultValue":"",
			"desc":"",
		},
		"userId":{
			"name":"userId","type":"auto",
			"defaultValue":"",
			"desc":"",
		},
		"command":{
			"name":"command","type":"string",
			"defaultValue":"",
			"desc":"",
		},
		"chatFlow":{
			"name":"chatFlow","type":"auto",
			"defaultValue":null,
			"desc":"",
		}
	},
	/*#{1I33BVLV00ArgsView*/
	/*}#1I33BVLV00ArgsView*/
};

/*#{1I33BVLV00StartDoc*/
let topWindow;
topWindow=window;
while(topWindow && topWindow.parent && topWindow.parent!==topWindow){
	topWindow=topWindow.parent;
}
const topVFACT=topWindow.VFACT;
let tempDirPath;
//----------------------------------------------------------------------------
async function setupTempDir(glbCtx){
	let baseName,dirPath,cnt;
	if(!glbCtx.exechangeRes){
		glbCtx.exechangeRes={};
	}
	if(glbCtx.tempDirPath){
		tempDirPath=glbCtx.tempDirPath;
		return;
	}
	cnt=0;
	dirPath=baseName="/doc/Temp/TEMP_"+Date.now();
	do{
		if(!(await tabFS.isExist(dirPath))){
			break;
		}
		cnt+=1;
		dirPath=baseName+cnt;
	}while(1);
	await tabFS.newDir(dirPath);
	glbCtx.tempDirPath=tempDirPath=dirPath;
	return dirPath;
};
async function clearTempDir(path){
	path=path||tempDirPath;
	try{
		await tabFS.del(path);
	}catch(err){
	}
};
/*}#1I33BVLV00StartDoc*/
//----------------------------------------------------------------------------
let BotHandleChat=async function(session){
	let botId,userId,command,chatFlow;
	let context,globalContext;
	let self;
	let Start,ChooseAct,SwitchAct,PickSkill,TipRunSkill,RunSkill,ShowResult,AppendMessage,TipBotTask,RunBotTask,TipFinish,TipAbort,TipReply;
	let aaBotNode=AABotNode.getAppBotNode(false);
	let hostBot=undefined;
	
	/*#{1I33BVLV00LocalVals*/
	/*}#1I33BVLV00LocalVals*/
	
	function parseAgentArgs(input){
		if(typeof(input)=='object'){
			botId=input.botId;
			userId=input.userId;
			command=input.command;
			chatFlow=input.chatFlow;
		}else{
			botId=undefined;
			userId=undefined;
			command=undefined;
			chatFlow=undefined;
		}
		/*#{1I33BVLV00ParseArgs*/
		/*}#1I33BVLV00ParseArgs*/
	}
	
	/*#{1I33BVLV00PreContext*/
	/*}#1I33BVLV00PreContext*/
	globalContext=session.globalContext;
	context={
		aaSkills: null,
		skillsIndexVO: null,
		curSkill: null,
		workRound: 0,
		botsIndex: {},
		/*#{1I33BVLV05ExCtxAttrs*/
		/*}#1I33BVLV05ExCtxAttrs*/
	};
	context=VFACT.flexState(context);
	/*#{1I33BVLV00PostContext*/
	await setupTempDir(globalContext);
	/*}#1I33BVLV00PostContext*/
	let agent,segs={};
	segs["Start"]=Start=async function(input){//:1I33C22650
		let result=input
		/*#{1I33C22650Code*/
		let skills,saveVO,botDef;
		botId=botId||"BOT_MASTER";
		hostBot=aaBotNode.getBot(botId);
		botDef=await hostBot.getBotDef();
		skills=context.aaSkills=new AASkills();
		//Try read /doc/SkillIndex.json first:
		try{
			if(botDef && botDef.skills){
				saveVO={skills:botDef.skills,chains:[],groups:[]};
			}else{
				saveVO=await (await fetch("/~/doc/SkillIndex.json")).json();
			}
		}catch(err){
			saveVO=await (await fetch("/@aae/ai/SkillIndex.json")).json();
		}
		await skills.loadFromVO(saveVO);
		context.skillsIndexVO=skills.getSkillDescIndex();
		console.log(context.skillsIndexVO);
		context.botsIndex=await aaBotNode.getBotsIndex();
		delete context.botsIndex[botId];
		console.log(context.botsIndex);
		result=command;
		if(chatFlow){
			let flowObj,messages,msg,history;
			//Compose message by chatFlow:
			history=ChooseAct.messages;
			history.splice(0);
			flowObj=await AAChatFlow.getFlow(chatFlow);
			if(flowObj){
				messages=flowObj.messages;
				for(msg of messages){
					if(msg.from===botId && msg.to===userId){
						history.push({role:"assistant",content:`{"reply":"${msg.content.text||msg.content}"}`});
					}else if(msg.to===botId && msg.from===userId){
						history.push({role:"user",content:msg.content.text||msg.content});
					}
				}
				history.pop();//TODO: Check if the last is this turn's input?
			}
		}else{
			ChooseAct.messages.splice(0);
		}
		/*}#1I33C22650Code*/
		return {seg:ChooseAct,result:(result),preSeg:"1I33C22650",outlet:"1I33C3IEM1"};
	};
	Start.jaxId="1I33C22650"
	Start.url="Start@"+agentURL
	
	segs["ChooseAct"]=ChooseAct=async function(input){//:1I3EQ3FAE0
		let prompt;
		let result;
		
		let opts={
			platform:"OpenAI",
			mode:"gpt-4o",
			maxToken:2000,
			temperature:0,
			topP:1,
			fqcP:0,
			prcP:0,
			secret:false,
			responseFormat:"json_object"
		};
		let chatMem=ChooseAct.messages
		let seed="";
		if(seed!==undefined){opts.seed=seed;}
		let messages=[
			{role:"system",content:`
你是一个根据用户输入，选择适合的Skill、或外部智能体(bot)运行，与用户对话，完成任务的AI。
当前可以使用的的SKill有: 
${JSON.stringify(context.skillsIndexVO,null,"\t")}  

当前可以调用的其它智能体(bot)有:
${JSON.stringify(context.botsIndex,null,"\t")}  

- 第一轮对话时，用户输入的是要完成的任务，你根据用户的输入，选择合适的Skill，智能体用于执行，或者回答用户的问题。

- 每一回合对话，跟根据当前任务执行的情况，回复一个JSON对象。

- 如果需要执行一个Skill，回复JSON中的"skill"属性是下一步要执行的SKill的名称; 回复JSON中的prompt属性是调用这个Skill的输入指令。例如：
{
	"skill":"Skill-3",
    "prompt":"Search for: Who is the winner of 2024 F1?"
}

- 如果需要执行一个外部智能体(bot)，回复JSON中的"bot"属性是下一步要执行的智能体的名称，"prompt"属性是要执行的任务描述。例如：
{
	"bot":"BOT_ALICE,
    "prompt":"Draw a picture of a cat driving a car."
}

- 你同时只能执行一个外部智能体（Bot）任务，在当前Bot任务完成前，不能开始新的任务，如果用户要开启新任务或询问进度，请通过回复中的"reply"参数告诉用户。例如:
{
	"reply":"执行当前任务可能还需要一些时间，请再等等"
}
或者：
{
	"reply":"正在执行'绘制汽车图片的外部任务，无法现在执行新的任务。'"
}

- 执行Skill或者智能体的结果会在对话中告知，你根据任务目标以及执行情况，选择新的Skill/智能体继续，直到结束。

- 如果成功的完成了用户提出的任务，回复将JSON中的"finish"属性设置为true。并通过"result"属性总结汇报执行情况。例如
{
	"finish":true,
    "result":"论坛帖子已经成功发布。"
}

- 如果执行Skill出现错误，你认为无法完成用户的任务，设置回复JSON中的"abort"属性为true，并在"reason"属性中说明原因。例如:
{
	"abort":true,
    "reason":"没有登录脸书账号，无法发布新的内容。"
}

- 如果要响应用户的指令需要用户回答问题，提供更多信息或者持续的对话，设置JSON中的 "reply"属性与用户对话，并把finsish设置为false。例如
{
	"finish":false,
	"reply":"请问你职业是什么？"
}

- 如果回答用户的输入不需要或者不再需要使用任何skill、智能体调用，用回复JSON中的"replay"属性回答用户，如果对话已结束，同时设置"finish"属性为true；否则，设置"finish"属性为false。例如：
\`\`\`
//对话结束：
{
	"finish":true,
	"reply":"是的，西瓜是一种水果。"
}
//继续对话：
{
	"finish":false,
	"reply":"是的，西瓜是一种水果。"
}
\`\`\`

- 非常重要：如果能够本地Skill完成任务，就不要调用外部智能体(Bot)
`
},
		];
		messages.push(...chatMem);
		prompt=input;
		if(prompt!==null){
			messages.push({role:"user",content:prompt});
		}
		result=await session.callSegLLM("ChooseAct@"+agentURL,opts,messages,true);
		chatMem.push({role:"user",content:prompt});
		chatMem.push({role:"assistant",content:result});
		if(chatMem.length>50){
			let removedMsgs=chatMem.splice(0,6);
		}
		result=trimJSON(result);
		return {seg:SwitchAct,result:(result),preSeg:"1I3EQ3FAE0",outlet:"1I3EQH43J0"};
	};
	ChooseAct.jaxId="1I3EQ3FAE0"
	ChooseAct.url="ChooseAct@"+agentURL
	ChooseAct.messages=[];
	
	segs["SwitchAct"]=SwitchAct=async function(input){//:1I3EQ4O560
		let result=input;
		if(!!input.skill){
			/*#{1I3EQH43K0Codes*/
			/*}#1I3EQH43K0Codes*/
			return {seg:PickSkill,result:(input),preSeg:"1I3EQ4O560",outlet:"1I3EQH43K0"};
		}
		if(!!input.bot){
			return {seg:TipBotTask,result:(input),preSeg:"1I3EQ4O560",outlet:"1I3EQ567O0"};
		}
		if(!!input.finish){
			let output=input.result||input.reply;
			return {seg:TipFinish,result:(output),preSeg:"1I3EQ4O560",outlet:"1I3EQ7E8N0"};
		}
		if(input.abort){
			let output=`Task aborted, reason: ${input.reason}`;
			return {seg:TipAbort,result:(output),preSeg:"1I3EQ4O560",outlet:"1I3EQ7MT20"};
		}
		if(!!input.reply){
			let output=input.reply;
			return {seg:TipReply,result:(output),preSeg:"1I3EQ4O560",outlet:"1I3EQ81MS0"};
		}
		return {result:result};
	};
	SwitchAct.jaxId="1I3EQ4O560"
	SwitchAct.url="SwitchAct@"+agentURL
	
	segs["PickSkill"]=PickSkill=async function(input){//:1I3FECJ020
		let result=input
		/*#{1I3FECJ020Code*/
		let skillId;
		console.log(input);
		skillId=input.skill;
		skillId=parseInt(skillId.substring(6));
		context.curSkill=context.aaSkills.getSkills()[skillId];
		/*}#1I3FECJ020Code*/
		return {seg:TipRunSkill,result:(result),preSeg:"1I3FECJ020",outlet:"1I3FEDCEN0"};
	};
	PickSkill.jaxId="1I3FECJ020"
	PickSkill.url="PickSkill@"+agentURL
	
	segs["TipRunSkill"]=TipRunSkill=async function(input){//:1I3EQI4GG0
		let result=input;
		let role="assistant";
		let content=`- Skill: ${context.curSkill.getNameText()}- Prompt: ${input.prompt}`;
		session.addChatText(role,content);
		return {seg:RunSkill,result:(result),preSeg:"1I3EQI4GG0",outlet:"1I3EQIK5A1"};
	};
	TipRunSkill.jaxId="1I3EQI4GG0"
	TipRunSkill.url="TipRunSkill@"+agentURL
	
	segs["RunSkill"]=RunSkill=async function(input){//:1I3EQ92PI0
		let result=input
		/*#{1I3EQ92PI0Code*/
		let skill=context.curSkill;
		result=await context.aaSkills.execSkill(topVFACT.app,skill,input.prompt?JSON.stringify(input.prompt):"",session);
		/*}#1I3EQ92PI0Code*/
		return {seg:ShowResult,result:(result),preSeg:"1I3EQ92PI0",outlet:"1I3EQH43K2"};
	};
	RunSkill.jaxId="1I3EQ92PI0"
	RunSkill.url="RunSkill@"+agentURL
	
	segs["ShowResult"]=ShowResult=async function(input){//:1I3EQAJ9G0
		let result=input;
		let role="assistant";
		let content=input;
		session.addChatText(role,content);
		return {seg:AppendMessage,result:(result),preSeg:"1I3EQAJ9G0",outlet:"1I3EQH43K4"};
	};
	ShowResult.jaxId="1I3EQAJ9G0"
	ShowResult.url="ShowResult@"+agentURL
	
	segs["AppendMessage"]=AppendMessage=async function(input){//:1I3EQA2HE0
		let result=input
		/*#{1I3EQA2HE0Code*/
		result=`Run skill result: ${JSON.stringify(input,null,"\t")}`;
		/*}#1I3EQA2HE0Code*/
		return {seg:ChooseAct,result:(result),preSeg:"1I3EQA2HE0",outlet:"1I3EQH43K3"};
	};
	AppendMessage.jaxId="1I3EQA2HE0"
	AppendMessage.url="AppendMessage@"+agentURL
	
	segs["TipBotTask"]=TipBotTask=async function(input){//:1I3EQJN9E0
		let result=input;
		let role="assistant";
		let content=`Task: ${JSON.stringify(input)}`;
		session.addChatText(role,content);
		return {seg:RunBotTask,result:(result),preSeg:"1I3EQJN9E0",outlet:"1I3EQQH5H0"};
	};
	TipBotTask.jaxId="1I3EQJN9E0"
	TipBotTask.url="TipBotTask@"+agentURL
	
	segs["RunBotTask"]=RunBotTask=async function(input){//:1I3EQKCNE0
		let result=input
		/*#{1I3EQKCNE0Code*/
		await hostBot.newTaskReq(input.bot,input.prompt,chatFlow);
		result={result: `Bot-task {bot: "${input.bot}", prompt: ${JSON.stringify(input.prompt)}} created, it may take a while to finish. Please wait.`,finish:false};
		/*}#1I3EQKCNE0Code*/
		return {result:result};
	};
	RunBotTask.jaxId="1I3EQKCNE0"
	RunBotTask.url="RunBotTask@"+agentURL
	
	segs["TipFinish"]=TipFinish=async function(input){//:1I3EQM7E80
		let result=input;
		let role="assistant";
		let content=input;
		/*#{1I3EQM7E80PreCodes*/
		/*}#1I3EQM7E80PreCodes*/
		session.addChatText(role,content);
		/*#{1I3EQM7E80PostCodes*/
		result={result:input,finish:true};
		/*}#1I3EQM7E80PostCodes*/
		return {result:result};
	};
	TipFinish.jaxId="1I3EQM7E80"
	TipFinish.url="TipFinish@"+agentURL
	
	segs["TipAbort"]=TipAbort=async function(input){//:1I3EQOAOR0
		let result=input;
		let role="assistant";
		let content=input;
		/*#{1I3EQOAOR0PreCodes*/
		/*}#1I3EQOAOR0PreCodes*/
		session.addChatText(role,content);
		/*#{1I3EQOAOR0PostCodes*/
		result={result:input,abort:true,finish:true};
		/*}#1I3EQOAOR0PostCodes*/
		return {result:result};
	};
	TipAbort.jaxId="1I3EQOAOR0"
	TipAbort.url="TipAbort@"+agentURL
	
	segs["TipReply"]=TipReply=async function(input){//:1I3EQOPT80
		let result=input;
		let role="assistant";
		let content=input;
		/*#{1I3EQOPT80PreCodes*/
		/*}#1I3EQOPT80PreCodes*/
		session.addChatText(role,content);
		/*#{1I3EQOPT80PostCodes*/
		result={result:input,finish:false};
		/*}#1I3EQOPT80PostCodes*/
		return {result:result};
	};
	TipReply.jaxId="1I3EQOPT80"
	TipReply.url="TipReply@"+agentURL
	
	agent={
		isAIAgent:true,
		session:session,
		name:"BotHandleChat",
		url:agentURL,
		autoStart:true,
		jaxId:"1I33BVLV00",
		context:context,
		livingSeg:null,
		execChat:async function(input/*{botId,userId,command,chatFlow}*/){
			let result;
			parseAgentArgs(input);
			/*#{1I33BVLV00PreEntry*/
			/*}#1I33BVLV00PreEntry*/
			result={seg:Start,"input":input};
			/*#{1I33BVLV00PostEntry*/
			/*}#1I33BVLV00PostEntry*/
			return result;
		},
		/*#{1I33BVLV00MoreAgentAttrs*/
		/*}#1I33BVLV00MoreAgentAttrs*/
	};
	/*#{1I33BVLV00PostAgent*/
	/*}#1I33BVLV00PostAgent*/
	return agent;
};
/*#{1I33BVLV00ExCodes*/
/*}#1I33BVLV00ExCodes*/

export const ChatAPI=[{
	def:{
		name: "BotHandleChat",
		description: "这是一个AI智能体。",
		parameters:{
			type: "object",
			properties:{
				botId:{type:"auto",description:""},
				userId:{type:"auto",description:""},
				command:{type:"string",description:""},
				chatFlow:{type:"auto",description:""}
			}
		}
	},
	agent: BotHandleChat
}];

//:Export Edit-AddOn:
const DocAIAgentExporter=VFACT.classRegs.DocAIAgentExporter;
if(DocAIAgentExporter){
	const EditAttr=VFACT.classRegs.EditAttr;
	const EditAISeg=VFACT.classRegs.EditAISeg;
	const EditAISegOutlet=VFACT.classRegs.EditAISegOutlet;
	const SegObjShellAttr=EditAISeg.SegObjShellAttr;
	const SegOutletDef=EditAISegOutlet.SegOutletDef;
	const docAIAgentExporter=DocAIAgentExporter.prototype;
	const packExtraCodes=docAIAgentExporter.packExtraCodes;
	const packResult=docAIAgentExporter.packResult;
	const varNameRegex = /^[a-zA-Z_$][a-zA-Z0-9_$]*$/;
	
	EditAISeg.regDef({
		name:"BotHandleChat",showName:"BotHandleChat",icon:"agent.svg",catalog:["AI Call"],
		attrs:{
			...SegObjShellAttr,
			"botId":{name:"botId",type:"auto",key:1,fixed:1,initVal:""},
			"userId":{name:"userId",type:"auto",key:1,fixed:1,initVal:""},
			"command":{name:"command",type:"string",key:1,fixed:1,initVal:""},
			"chatFlow":{name:"chatFlow",type:"auto",key:1,fixed:1,initVal:null},
			"outlet":{name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc"}
		},
		listHint:["id","botId","userId","command","chatFlow","codes","desc"],
		desc:"这是一个AI智能体。"
	});
	
	DocAIAgentExporter.segTypeExporters["BotHandleChat"]=
	function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let exportDebug=this.isExportDebug();
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();coder.newLine();
		{
			coder.packText(`let result,args={};`);coder.newLine();
			coder.packText("args['botId']=");this.genAttrStatement(seg.getAttr("botId"));coder.packText(";");coder.newLine();
			coder.packText("args['userId']=");this.genAttrStatement(seg.getAttr("userId"));coder.packText(";");coder.newLine();
			coder.packText("args['command']=");this.genAttrStatement(seg.getAttr("command"));coder.packText(";");coder.newLine();
			coder.packText("args['chatFlow']=");this.genAttrStatement(seg.getAttr("chatFlow"));coder.packText(";");coder.newLine();
			this.packExtraCodes(coder,seg,"PreCodes");
			coder.packText(`result= await session.pipeChat("/~/aae/ai/BotHandleChat.js",args,false);`);coder.newLine();
			this.packExtraCodes(coder,seg,"PostCodes");
			this.packResult(coder,seg,seg.outlet);
		}
		coder.indentLess();coder.maybeNewLine();
		coder.packText(`};`);coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		coder.newLine();
	};
}
/*#{1I33BVLV00PostDoc*/
/*}#1I33BVLV00PostDoc*/


export default BotHandleChat;
export{BotHandleChat};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DocAIAgent",
//	"jaxId": "1I33BVLV00",
//	"attrs": {
//		"editObjs": {
//			"jaxId": "1I33BVLV01",
//			"attrs": {
//				"BotHandleChat": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1I33BVLV07",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1I33BVLV08",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1I33BVLV09",
//							"attrs": {}
//						},
//						"functions": {
//							"jaxId": "1I33BVLV010",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false"
//					},
//					"mockups": {}
//				}
//			}
//		},
//		"agent": {
//			"jaxId": "1I33BVLV02",
//			"attrs": {}
//		},
//		"entry": "Start",
//		"autoStart": "true",
//		"debug": "true",
//		"apiArgs": {
//			"jaxId": "1I33BVLV03",
//			"attrs": {
//				"botId": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I3GF07010",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				},
//				"userId": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I3J1BT2M0",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				},
//				"command": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I3F1IO940",
//					"attrs": {
//						"type": "String",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				},
//				"chatFlow": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I3GHGLVO0",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "null",
//						"desc": ""
//					}
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1I33BVLV04",
//			"attrs": {
//				"aaBotNode": {
//					"type": "auto",
//					"valText": "#AABotNode.getAppBotNode(false)"
//				},
//				"hostBot": {
//					"type": "auto",
//					"valText": ""
//				}
//			}
//		},
//		"context": {
//			"jaxId": "1I33BVLV05",
//			"attrs": {
//				"aaSkills": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I3F1SVUN0",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "null",
//						"desc": ""
//					}
//				},
//				"skillsIndexVO": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I3F1SVUN1",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "null",
//						"desc": ""
//					}
//				},
//				"curSkill": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I3F1SVUN2",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "null",
//						"desc": ""
//					}
//				},
//				"workRound": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I3F1SVUN3",
//					"attrs": {
//						"type": "Integer",
//						"mockup": "0",
//						"desc": ""
//					}
//				},
//				"botsIndex": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I3F1VQBR0",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "{}",
//						"desc": ""
//					}
//				}
//			}
//		},
//		"globalMockup": {
//			"jaxId": "1I33BVLV06",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I33C22650",
//					"attrs": {
//						"id": "Start",
//						"label": "New AI Seg",
//						"x": "60",
//						"y": "390",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I33C3IEP3",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I33C3IEP4",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I33C3IEM1",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I3EQ3FAE0"
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "callLLM",
//					"jaxId": "1I3EQ3FAE0",
//					"attrs": {
//						"id": "ChooseAct",
//						"label": "New AI Seg",
//						"x": "270",
//						"y": "390",
//						"desc": "执行一次LLM调用。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "faces.svg",
//						"context": {
//							"jaxId": "1I3EQH43N0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I3EQH43N1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"platform": "\"OpenAI\"",
//						"mode": "gpt-4o",
//						"system": "#`\n你是一个根据用户输入，选择适合的Skill、或外部智能体(bot)运行，与用户对话，完成任务的AI。\n当前可以使用的的SKill有: \n${JSON.stringify(context.skillsIndexVO,null,\"\\t\")}  \n\n当前可以调用的其它智能体(bot)有:\n${JSON.stringify(context.botsIndex,null,\"\\t\")}  \n\n- 第一轮对话时，用户输入的是要完成的任务，你根据用户的输入，选择合适的Skill，智能体用于执行，或者回答用户的问题。\n\n- 每一回合对话，跟根据当前任务执行的情况，回复一个JSON对象。\n\n- 如果需要执行一个Skill，回复JSON中的\"skill\"属性是下一步要执行的SKill的名称; 回复JSON中的prompt属性是调用这个Skill的输入指令。例如：\n{\n\t\"skill\":\"Skill-3\",\n    \"prompt\":\"Search for: Who is the winner of 2024 F1?\"\n}\n\n- 如果需要执行一个外部智能体(bot)，回复JSON中的\"bot\"属性是下一步要执行的智能体的名称，\"prompt\"属性是要执行的任务描述。例如：\n{\n\t\"bot\":\"BOT_ALICE,\n    \"prompt\":\"Draw a picture of a cat driving a car.\"\n}\n\n- 你同时只能执行一个外部智能体（Bot）任务，在当前Bot任务完成前，不能开始新的任务，如果用户要开启新任务或询问进度，请通过回复中的\"reply\"参数告诉用户。例如:\n{\n\t\"reply\":\"执行当前任务可能还需要一些时间，请再等等\"\n}\n或者：\n{\n\t\"reply\":\"正在执行'绘制汽车图片的外部任务，无法现在执行新的任务。'\"\n}\n\n- 执行Skill或者智能体的结果会在对话中告知，你根据任务目标以及执行情况，选择新的Skill/智能体继续，直到结束。\n\n- 如果成功的完成了用户提出的任务，回复将JSON中的\"finish\"属性设置为true。并通过\"result\"属性总结汇报执行情况。例如\n{\n\t\"finish\":true,\n    \"result\":\"论坛帖子已经成功发布。\"\n}\n\n- 如果执行Skill出现错误，你认为无法完成用户的任务，设置回复JSON中的\"abort\"属性为true，并在\"reason\"属性中说明原因。例如:\n{\n\t\"abort\":true,\n    \"reason\":\"没有登录脸书账号，无法发布新的内容。\"\n}\n\n- 如果要响应用户的指令需要用户回答问题，提供更多信息或者持续的对话，设置JSON中的 \"reply\"属性与用户对话，并把finsish设置为false。例如\n{\n\t\"finish\":false,\n\t\"reply\":\"请问你职业是什么？\"\n}\n\n- 如果回答用户的输入不需要或者不再需要使用任何skill、智能体调用，用回复JSON中的\"replay\"属性回答用户，如果对话已结束，同时设置\"finish\"属性为true；否则，设置\"finish\"属性为false。例如：\n\\`\\`\\`\n//对话结束：\n{\n\t\"finish\":true,\n\t\"reply\":\"是的，西瓜是一种水果。\"\n}\n//继续对话：\n{\n\t\"finish\":false,\n\t\"reply\":\"是的，西瓜是一种水果。\"\n}\n\\`\\`\\`\n\n- 非常重要：如果能够本地Skill完成任务，就不要调用外部智能体(Bot)\n`\n",
//						"temperature": "0",
//						"maxToken": "2000",
//						"topP": "1",
//						"fqcP": "0",
//						"prcP": "0",
//						"messages": {
//							"attrs": []
//						},
//						"prompt": "#input",
//						"seed": "",
//						"outlet": {
//							"jaxId": "1I3EQH43J0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I3EQ4O560"
//						},
//						"secret": "false",
//						"allowCheat": "false",
//						"GPTCheats": {
//							"attrs": []
//						},
//						"shareChatName": "",
//						"keepChat": "50 messages",
//						"clearChat": "6 messages",
//						"apiFiles": {
//							"attrs": []
//						},
//						"parallelFunction": "false",
//						"responseFormat": "json_object"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "brunch",
//					"jaxId": "1I3EQ4O560",
//					"attrs": {
//						"id": "SwitchAct",
//						"label": "New AI Seg",
//						"x": "500",
//						"y": "390",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I3EQH43N2",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I3EQH43N3",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I3EQH43K1",
//							"attrs": {
//								"id": "Default",
//								"desc": "输出节点。",
//								"output": ""
//							}
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I3EQH43K0",
//									"attrs": {
//										"id": "Skill",
//										"desc": "Run skill in this bot",
//										"output": "",
//										"codes": "true",
//										"context": {
//											"jaxId": "1I3EQH43N4",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I3EQH43N5",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#!!input.skill"
//									},
//									"linkedSeg": "1I3FECJ020"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I3EQ567O0",
//									"attrs": {
//										"id": "BotTask",
//										"desc": "Call other bot",
//										"output": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I3EQH43N8",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I3EQH43N9",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#!!input.bot"
//									},
//									"linkedSeg": "1I3EQJN9E0"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I3EQ7E8N0",
//									"attrs": {
//										"id": "Finish",
//										"desc": "输出节点。",
//										"output": "#input.result||input.reply",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I3EQH43N10",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I3EQH43N11",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#!!input.finish"
//									},
//									"linkedSeg": "1I3EQM7E80"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I3EQ7MT20",
//									"attrs": {
//										"id": "Abort",
//										"desc": "输出节点。",
//										"output": "#`Task aborted, reason: ${input.reason}`",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I3EQH43N12",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I3EQH43N13",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#input.abort"
//									},
//									"linkedSeg": "1I3EQOAOR0"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I3EQ81MS0",
//									"attrs": {
//										"id": "Reply",
//										"desc": "输出节点。",
//										"output": "#input.reply",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I3EQH43N14",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I3EQH43N15",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#!!input.reply"
//									},
//									"linkedSeg": "1I3EQOPT80"
//								}
//							]
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I3FECJ020",
//					"attrs": {
//						"id": "PickSkill",
//						"label": "New AI Seg",
//						"x": "740",
//						"y": "195",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I3FEDCET0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I3FEDCET1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I3FEDCEN0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I3EQI4GG0"
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1I3EQI4GG0",
//					"attrs": {
//						"id": "TipRunSkill",
//						"label": "New AI Seg",
//						"x": "975",
//						"y": "195",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I3EQIK5C2",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I3EQIK5C3",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "Assistant",
//						"text": "#`- Skill: ${context.curSkill.getNameText()}- Prompt: ${input.prompt}`",
//						"outlet": {
//							"jaxId": "1I3EQIK5A1",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I3EQ92PI0"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I3EQ92PI0",
//					"attrs": {
//						"id": "RunSkill",
//						"label": "New AI Seg",
//						"x": "1210",
//						"y": "195",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I3EQH43N16",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I3EQH43N17",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I3EQH43K2",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I3EQAJ9G0"
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1I3EQAJ9G0",
//					"attrs": {
//						"id": "ShowResult",
//						"label": "New AI Seg",
//						"x": "1440",
//						"y": "195",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I3EQH43N20",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I3EQH43N21",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "Assistant",
//						"text": "#input",
//						"outlet": {
//							"jaxId": "1I3EQH43K4",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I3EQA2HE0"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I3EQA2HE0",
//					"attrs": {
//						"id": "AppendMessage",
//						"label": "New AI Seg",
//						"x": "1675",
//						"y": "195",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I3EQH43N18",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I3EQH43N19",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I3EQH43K3",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I3EQG2N10"
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I3EQG2N10",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "1850",
//						"y": "120",
//						"outlet": {
//							"jaxId": "1I3EQH43N22",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I3EQGA780"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I3EQGA780",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "525",
//						"y": "120",
//						"outlet": {
//							"jaxId": "1I3EQH43N23",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I3EQGFC60"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I3EQGFC60",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "300",
//						"y": "315",
//						"outlet": {
//							"jaxId": "1I3EQH43N24",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I3EQ3FAE0"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1I3EQJN9E0",
//					"attrs": {
//						"id": "TipBotTask",
//						"label": "New AI Seg",
//						"x": "740",
//						"y": "275",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I3EQQH5K2",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I3EQQH5K3",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "Assistant",
//						"text": "#`Task: ${JSON.stringify(input)}`",
//						"outlet": {
//							"jaxId": "1I3EQQH5H0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I3EQKCNE0"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I3EQKCNE0",
//					"attrs": {
//						"id": "RunBotTask",
//						"label": "New AI Seg",
//						"x": "975",
//						"y": "275",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "flag.svg",
//						"context": {
//							"jaxId": "1I3EQQH5K4",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I3EQQH5K5",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I3EQQH5H1",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							}
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1I3EQM7E80",
//					"attrs": {
//						"id": "TipFinish",
//						"label": "New AI Seg",
//						"x": "740",
//						"y": "350",
//						"desc": "这是一个AISeg。",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "flag.svg",
//						"context": {
//							"jaxId": "1I3EQQH5K6",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I3EQQH5K7",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "Assistant",
//						"text": "#input",
//						"outlet": {
//							"jaxId": "1I3EQQH5H2",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							}
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1I3EQOAOR0",
//					"attrs": {
//						"id": "TipAbort",
//						"label": "New AI Seg",
//						"x": "740",
//						"y": "430",
//						"desc": "这是一个AISeg。",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "flag.svg",
//						"context": {
//							"jaxId": "1I3EQQH5K8",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I3EQQH5K9",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "Assistant",
//						"text": "#input",
//						"outlet": {
//							"jaxId": "1I3EQQH5H3",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							}
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1I3EQOPT80",
//					"attrs": {
//						"id": "TipReply",
//						"label": "New AI Seg",
//						"x": "740",
//						"y": "505",
//						"desc": "这是一个AISeg。",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "flag.svg",
//						"context": {
//							"jaxId": "1I3EQQH5K10",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I3EQQH5K11",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "Assistant",
//						"text": "#input",
//						"outlet": {
//							"jaxId": "1I3EQQH5H4",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							}
//						}
//					}
//				}
//			]
//		},
//		"desc": "这是一个AI智能体。",
//		"exportAPI": "true",
//		"exportAddOn": "true",
//		"addOnOpts": ""
//	}
//}