//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import pathLib from "/@path";
import inherits from "/@inherits";
import Base64 from "/@tabos/utils/base64.js";
import {trimJSON} from "/@aichat/utils.js";
/*#{1I1EEBVQH0MoreImports*/
/*}#1I1EEBVQH0MoreImports*/
const agentURL=(new URL(import.meta.url)).pathname;
const basePath=pathLib.dirname(agentURL);
const $ln=VFACT.lanCode||"EN";
/*#{1I1EEBVQH0StartDoc*/
/*}#1I1EEBVQH0StartDoc*/
//----------------------------------------------------------------------------
let RunCrew=async function(session){
	let execInput;
	let context,globalContext;
	let self;
	let GetCrewInfo,CheckTasks,HasTask,ExecTask,GetMessages,GenTaskByMsg;
	/*#{1I1EEBVQH0LocalVals*/
	/*}#1I1EEBVQH0LocalVals*/
	
	/*#{1I1EEBVQH0PreContext*/
	/*}#1I1EEBVQH0PreContext*/
	globalContext=session.globalContext;
	context={};
	context=VFACT.flexState(context);
	/*#{1I1EEBVQH0PostContext*/
	/*}#1I1EEBVQH0PostContext*/
	let agent,segs={};
	segs["GetCrewInfo"]=GetCrewInfo=async function(input){//:1I1EEC70G0
		let result=input
		/*#{1I1EEC70G0Code*/
		/*}#1I1EEC70G0Code*/
		return {seg:CheckTasks,result:(result),preSeg:"1I1EEC70G0",outlet:"1I1EECGU70"};
	};
	GetCrewInfo.jaxId="1I1EEC70G0"
	GetCrewInfo.url="GetCrewInfo@"+agentURL
	
	segs["CheckTasks"]=CheckTasks=async function(input){//:1I1EEDG150
		let result=input
		/*#{1I1EEDG150Code*/
		/*}#1I1EEDG150Code*/
		return {seg:HasTask,result:(result),preSeg:"1I1EEDG150",outlet:"1I1EEDTKN0"};
	};
	CheckTasks.jaxId="1I1EEDG150"
	CheckTasks.url="CheckTasks@"+agentURL
	
	segs["HasTask"]=HasTask=async function(input){//:1I1EEENN10
		let result=input;
		if(input==="Task"){
			return {seg:ExecTask,result:(input),preSeg:"1I1EEENN10",outlet:"1I1EEIRNT0"};
		}
		return {seg:GetMessages,result:(result),preSeg:"1I1EEENN10",outlet:"1I1EEIRNT1"};
	};
	HasTask.jaxId="1I1EEENN10"
	HasTask.url="HasTask@"+agentURL
	
	segs["ExecTask"]=ExecTask=async function(input){//:1I1EEFJCA0
		let result=input
		/*#{1I1EEFJCA0Code*/
		/*}#1I1EEFJCA0Code*/
		return {seg:CheckTasks,result:(result),preSeg:"1I1EEFJCA0",outlet:"1I1EEIRNT2"};
	};
	ExecTask.jaxId="1I1EEFJCA0"
	ExecTask.url="ExecTask@"+agentURL
	
	segs["GetMessages"]=GetMessages=async function(input){//:1I1EEGFR60
		let result=input
		/*#{1I1EEGFR60Code*/
		/*}#1I1EEGFR60Code*/
		return {seg:GenTaskByMsg,result:(result),preSeg:"1I1EEGFR60",outlet:"1I1EEIRNT3"};
	};
	GetMessages.jaxId="1I1EEGFR60"
	GetMessages.url="GetMessages@"+agentURL
	
	segs["GenTaskByMsg"]=GenTaskByMsg=async function(input){//:1I1EEHPPT0
		let result=input
		/*#{1I1EEHPPT0Code*/
		/*}#1I1EEHPPT0Code*/
		return {seg:CheckTasks,result:(result),preSeg:"1I1EEHPPT0",outlet:"1I1EEIRNT4"};
	};
	GenTaskByMsg.jaxId="1I1EEHPPT0"
	GenTaskByMsg.url="GenTaskByMsg@"+agentURL
	
	agent={
		isAIAgent:true,
		session:session,
		name:"RunCrew",
		url:agentURL,
		autoStart:true,
		jaxId:"1I1EEBVQH0",
		context:context,
		livingSeg:null,
		execChat:async function(input){
			let result;
			execInput=input;
			/*#{1I1EEBVQH0PreEntry*/
			/*}#1I1EEBVQH0PreEntry*/
			result={seg:GetCrewInfo,"input":input};
			/*#{1I1EEBVQH0PostEntry*/
			/*}#1I1EEBVQH0PostEntry*/
			return result;
		},
		/*#{1I1EEBVQH0MoreAgentAttrs*/
		/*}#1I1EEBVQH0MoreAgentAttrs*/
	};
	/*#{1I1EEBVQH0PostAgent*/
	/*}#1I1EEBVQH0PostAgent*/
	return agent;
};
/*#{1I1EEBVQH0ExCodes*/
/*}#1I1EEBVQH0ExCodes*/


export default RunCrew;
export{RunCrew};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DocAIAgent",
//	"jaxId": "1I1EEBVQH0",
//	"attrs": {
//		"editObjs": {
//			"jaxId": "1I1EEBVQH1",
//			"attrs": {
//				"RunCrew": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1I1EEBVQH7",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1I1EEBVQH8",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1I1EEBVQH9",
//							"attrs": {}
//						},
//						"functions": {
//							"jaxId": "1I1EEBVQH10",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false"
//					},
//					"mockups": {}
//				}
//			}
//		},
//		"agent": {
//			"jaxId": "1I1EEBVQH2",
//			"attrs": {}
//		},
//		"entry": "",
//		"autoStart": "true",
//		"debug": "true",
//		"apiArgs": {
//			"jaxId": "1I1EEBVQH3",
//			"attrs": {}
//		},
//		"localVars": {
//			"jaxId": "1I1EEBVQH4",
//			"attrs": {}
//		},
//		"context": {
//			"jaxId": "1I1EEBVQH5",
//			"attrs": {}
//		},
//		"globalMockup": {
//			"jaxId": "1I1EEBVQH6",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I1EEC70G0",
//					"attrs": {
//						"id": "GetCrewInfo",
//						"label": "New AI Seg",
//						"x": "85",
//						"y": "120",
//						"desc": "Get crew infomation from server.",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I1EECGU90",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1EECGU91",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I1EECGU70",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1EEDG150"
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I1EEDG150",
//					"attrs": {
//						"id": "CheckTasks",
//						"label": "New AI Seg",
//						"x": "320",
//						"y": "120",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I1EEDTKO0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1EEDTKO1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I1EEDTKN0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1EEENN10"
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "brunch",
//					"jaxId": "1I1EEENN10",
//					"attrs": {
//						"id": "HasTask",
//						"label": "New AI Seg",
//						"x": "555",
//						"y": "120",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I1EEIRO00",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1EEIRO01",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I1EEIRNT1",
//							"attrs": {
//								"id": "Default",
//								"desc": "输出节点。",
//								"output": ""
//							},
//							"linkedSeg": "1I1EEGFR60"
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I1EEIRNT0",
//									"attrs": {
//										"id": "Task",
//										"desc": "输出节点。",
//										"output": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I1EEIRO02",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I1EEIRO03",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": ""
//									},
//									"linkedSeg": "1I1EEFJCA0"
//								}
//							]
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I1EEFJCA0",
//					"attrs": {
//						"id": "ExecTask",
//						"label": "New AI Seg",
//						"x": "780",
//						"y": "105",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I1EEIRO10",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1EEIRO11",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I1EEIRNT2",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1EEFU5Q0"
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I1EEFU5Q0",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "920",
//						"y": "40",
//						"outlet": {
//							"jaxId": "1I1EEIRO12",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1EEG77D0"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I1EEG77D0",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "350",
//						"y": "40",
//						"outlet": {
//							"jaxId": "1I1EEIRO13",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1EEDG150"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I1EEGFR60",
//					"attrs": {
//						"id": "GetMessages",
//						"label": "New AI Seg",
//						"x": "780",
//						"y": "195",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I1EEIRO14",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1EEIRO15",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I1EEIRNT3",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1EEHPPT0"
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I1EEHPPT0",
//					"attrs": {
//						"id": "GenTaskByMsg",
//						"label": "New AI Seg",
//						"x": "1025",
//						"y": "195",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I1EEIRO16",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1EEIRO17",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I1EEIRNT4",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1EEIIED0"
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I1EEIIED0",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "1195",
//						"y": "40",
//						"outlet": {
//							"jaxId": "1I1EEIRO18",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1EEFU5Q0"
//						},
//						"dir": "R2L"
//					}
//				}
//			]
//		},
//		"desc": "这是一个AI代理。",
//		"exportAPI": "false",
//		"exportAddOn": "false",
//		"addOnOpts": ""
//	}
//}