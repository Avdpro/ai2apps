export default function executeSearch({ search }) {
    // Define the steps array to hold all actions
    const steps = [];

    // Step 1: Click on the search bar
    steps.push({
        execute: {
            desc: "Click on the search bar",
            action: "Click",
            queryHint: "search bar",
            willNavi: false,
            fileName: ""
        },
        result: null,
        abort: false
    });

    // Step 2: Type the search query
    steps.push({
        execute: {
            desc: `Type the search query '${search}'`,
            action: "Type",
            content: `#${search}`,
            willNavi: false,
            fileName: ""
        },
        result: null,
        abort: false
    });

    // Step 3: Press the Enter key
    steps.push({
        execute: {
            desc: "Press the Enter key to execute the search",
            action: "PressKey",
            key: "Enter",
            willNavi: true
        },
        result: null,
        abort: false
    });

    // Return the steps array
    return steps;
}
export const SkillDef={
	"host": "www_google_com",
	"startURL": "https://www.google.com",
	"name": "executeSearch",
	"desc": "Execute a search on a webpage using the given search query",
	"parameters": {
		"type": "object",
		"properties": {
			"search": {
				"type": "string",
				"description": "The search query to execute"
			}
		},
		"required": [
			"search"
		]
	},
	"result": {
		"type": "boolean",
		"description": "Returns true if the search was executed successfully, otherwise throws an error"
	}
};