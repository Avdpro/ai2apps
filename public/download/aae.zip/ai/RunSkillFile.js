//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import pathLib from "/@path";
import inherits from "/@inherits";
import Base64 from "/@tabos/utils/base64.js";
import {trimJSON} from "/@aichat/utils.js";
import {AAFarm} from "/@aae/aafarm.js";
/*#{1I11L4SS40MoreImports*/
/*}#1I11L4SS40MoreImports*/
const agentURL=(new URL(import.meta.url)).pathname;
const basePath=pathLib.dirname(agentURL);
const $ln=VFACT.lanCode||"EN";
/*#{1I11L4SS40StartDoc*/
/*}#1I11L4SS40StartDoc*/
//----------------------------------------------------------------------------
let RunSkillFile=async function(session){
	let skillFileName,args,command;
	let context,globalContext;
	let self;
	let Start,LoadFile,CheckArg,GenArg,CheckArgsOK,GenArgTemplate,AskArgs,OpenBrowser,OpenPage,GenSteps,RunSteps,ShowArgVO,ShowSteps,LoopSteps,Wait1S,ClosePage;
	let skillFunction=null;
	let skillDefVO=null;
	let argTemplate=null;
	let argVO=null;
	let runSteps=null;
	
	/*#{1I11L4SS40LocalVals*/
	/*}#1I11L4SS40LocalVals*/
	
	/*#{1I11L4SS40PreContext*/
	/*}#1I11L4SS40PreContext*/
	globalContext=session.globalContext;
	context={};
	context=VFACT.flexState(context);
	/*#{1I11L4SS40PostContext*/
	/*}#1I11L4SS40PostContext*/
	let agent,segs={};
	segs["Start"]=Start=async function(input){//:1I11L5GP70
		let result=true;
		let aiQuery=true;
		try{
			context.aaFarm=new AAFarm();
			aiQuery && (await context.aaFarm.setupAIQuery(session,context,basePath,"1I11L5GP70"));
		}catch(err){
			throw err;
		}
		return {seg:LoadFile,result:(result),preSeg:"1I11L5GP70",outlet:"1I11LE2JJ0"};
	};
	Start.jaxId="1I11L5GP70"
	Start.url="Start@"+agentURL
	
	segs["LoadFile"]=LoadFile=async function(input){//:1I11LEM940
		let result=input
		/*#{1I11LEM940Code*/
		let path,mod;
		path=basePath;
		path=pathLib.join(path,skillFileName);
		mod=await import(path);
		skillFunction=mod.default;
		skillDefVO=mod.SkillDef;
		/*}#1I11LEM940Code*/
		return {seg:CheckArg,result:(result),preSeg:"1I11LEM940",outlet:"1I11LEV510"};
	};
	LoadFile.jaxId="1I11LEM940"
	LoadFile.url="LoadFile@"+agentURL
	
	segs["CheckArg"]=CheckArg=async function(input){//:1I11LFF340
		let result=input;
		if(input==="HasArg"){
			return {seg:CheckArgsOK,result:(input),preSeg:"1I11LFF340",outlet:"1I11LIUT90"};
		}
		return {seg:GenArg,result:(result),preSeg:"1I11LFF340",outlet:"1I11LIUT91"};
	};
	CheckArg.jaxId="1I11LFF340"
	CheckArg.url="CheckArg@"+agentURL
	
	segs["GenArg"]=GenArg=async function(input){//:1I11LGKLB0
		let prompt;
		let result=null;
		/*#{1I11LGKLB0Input*/
		/*}#1I11LGKLB0Input*/
		
		let opts={
			platform:"OpenAI",
			mode:"gpt-4o",
			maxToken:2000,
			temperature:0,
			topP:1,
			fqcP:0,
			prcP:0,
			secret:false,
			responseFormat:"json_object"
		};
		let chatMem=GenArg.messages
		let seed="";
		if(seed!==undefined){opts.seed=seed;}
		let messages=[
			{role:"system",content:"你是一个根据API调用定义VO和自然语言指令生成调用API参数对象的AI\n- 每轮对话的输入包含\"API调用定义VO\"和需要API执行操作的自然语言指令。\n- 分析\"API调用定义VO\"和自然语言指令，生成调用API的参数对象，如果自然语你需要在调用参数把缺少的参数的值设置为\"$$MISSING$$\"。例如：\n//缺少\"size\"属性：\n```\n{\n\t\"number\":100,\n    \"size:\"$$MISSGING$$\"\n}\n```\n请用JSON格式返回调用参数VO"},
		];
		/*#{1I11LGKLB0PrePrompt*/
		/*}#1I11LGKLB0PrePrompt*/
		prompt=`
API调用定义VO：
\`\`\`
${JSON.stringify(skillDefVO,null,"\t")}
\`\`\`
自然语言指令：
${command}
`;
		if(prompt!==null){
			messages.push({role:"user",content:prompt});
		}
		/*#{1I11LGKLB0PreCall*/
		/*}#1I11LGKLB0PreCall*/
		result=GenArg.cheats[prompt]||GenArg.cheats[input]||GenArg.cheats[""];
		if(!result){
			result=(result===undefined)?(await session.callSegLLM("GenArg@"+agentURL,opts,messages,true)):result;
		
		}
		result=trimJSON(result);
		/*#{1I11LGKLB0PostCall*/
		argVO=result;
		/*}#1I11LGKLB0PostCall*/
		return {seg:ShowArgVO,result:(result),preSeg:"1I11LGKLB0",outlet:"1I11LIUT92"};
	};
	GenArg.jaxId="1I11LGKLB0"
	GenArg.url="GenArg@"+agentURL
	GenArg.cheats={
		"":"{\n\t\"text\": \"今天在AI2App的RPA DashBoard\",\n\t\"photos\": \"$$MISSING$$\"\n}"
	};
	
	segs["CheckArgsOK"]=CheckArgsOK=async function(input){//:1I11LHK050
		let result=input;
		/*#{1I11LHK050Start*/
		let callVO,key,value,hasMissing;
		hasMissing=false;
		callVO=input;
		for(key in callVO){
			value=callVO[key];
			if(value==="$$MISSING$$"){
				delete callVO[key];
				hasMissing=true;
			}
		}
		/*}#1I11LHK050Start*/
		if(hasMissing){
			return {seg:GenArgTemplate,result:(input),preSeg:"1I11LHK050",outlet:"1I11LNC0A0"};
		}
		/*#{1I11LHK050Post*/
		/*}#1I11LHK050Post*/
		return {seg:OpenBrowser,result:(result),preSeg:"1I11LHK050",outlet:"1I11LIUTA0"};
	};
	CheckArgsOK.jaxId="1I11LHK050"
	CheckArgsOK.url="CheckArgsOK@"+agentURL
	
	segs["GenArgTemplate"]=GenArgTemplate=async function(input){//:1I11T5RQP0
		let result=input
		/*#{1I11T5RQP0Code*/
		let attrDef,ppts,attrName,attrType,attrVO;
		attrDef=skillDefVO.parameters.properties;
		//Generate template
		ppts={};
		argTemplate={
			name:"SkillArguments",
			type:"object",
			properties:ppts,
		};
		for(attrName in attrDef){
			attrType=attrDef[attrName].type;
			attrVO=ppts[attrName]={
				name:attrName,
				type:attrType,
				desc:attrDef[attrName].description
			};
			if(attrType==="array"){
				let subType;
				subType=attrDef[attrName].items.type;
				attrVO.template={
					type:subType,label:"###"
				};
			}
		}
		/*}#1I11T5RQP0Code*/
		return {seg:AskArgs,result:(result),preSeg:"1I11T5RQP0",outlet:"1I11TA8KG0"};
	};
	GenArgTemplate.jaxId="1I11T5RQP0"
	GenArgTemplate.url="GenArgTemplate@"+agentURL
	
	segs["AskArgs"]=AskArgs=async function(input){//:1I11T95520
		let result,resultText;
		let role="assistant";
		let md=await import("/@StdUI/ui/AIAskDataBlock.js");
		let func=md.default;
		let text="Please input:";
		let template=undefined;
		let data=argVO;
		let edit=true;
		let inputVO={template:template,data:data,options:{edit:edit}};
		/*#{1I11T95520Pre*/
		inputVO.template=argTemplate;
		/*}#1I11T95520Pre*/
		[resultText,result]=await session.askUserRaw({type:"block",text:text,block:func(session,{}),input:inputVO,role:role});
		/*#{1I11T95520Codes*/
		argVO=result;
		/*}#1I11T95520Codes*/
		return {seg:OpenBrowser,result:(result),preSeg:"1I11T95520",outlet:"1I11TA8KG1"};
	};
	AskArgs.jaxId="1I11T95520"
	AskArgs.url="AskArgs@"+agentURL
	
	segs["OpenBrowser"]=OpenBrowser=async function(input){//:1I11LLJ7D0
		let result=true;
		let browser=null;
		let headless=false;
		let devtools=false;
		let dataDir=false;
		let alias="AAHOME";
		context.aaBrowser=browser=await context.aaFarm.openBrowser(alias,{headless,devtools,autoDataDir:dataDir});
		context.aaHostPage=browser.hostPage;
		return {seg:OpenPage,result:(result),preSeg:"1I11LLJ7D0",outlet:"1I11LNC0A1"};
	};
	OpenBrowser.jaxId="1I11LLJ7D0"
	OpenBrowser.url="OpenBrowser@"+agentURL
	
	segs["OpenPage"]=OpenPage=async function(input){//:1I11LMVSQ0
		let pageVal="aaPage";
		let $url=skillDefVO.startURL;
		let $waitBefore=0;
		let $waitAfter=0;
		let $width=1200;
		let $height=900;
		let $userAgent="";
		let page=null;
		$waitBefore && (await sleep($waitBefore));
		context[pageVal]=page=await context.aaBrowser.newPage();
		($width && $height) && (await page.setViewport({width:$width,height:$height}));
		$userAgent && (await page.setUserAgent($userAgent));
		await page.goto($url);
		$waitAfter && (await sleep($waitAfter));
		return {seg:GenSteps,result:(page),preSeg:"1I11LMVSQ0",outlet:"1I11LNC0B0"};
	};
	OpenPage.jaxId="1I11LMVSQ0"
	OpenPage.url="OpenPage@"+agentURL
	
	segs["GenSteps"]=GenSteps=async function(input){//:1I11LOV7B0
		let result=input
		/*#{1I11LOV7B0Code*/
		runSteps=skillFunction(argVO);
		result=runSteps;
		/*}#1I11LOV7B0Code*/
		return {seg:ShowSteps,result:(result),preSeg:"1I11LOV7B0",outlet:"1I11LS3KC0"};
	};
	GenSteps.jaxId="1I11LOV7B0"
	GenSteps.url="GenSteps@"+agentURL
	
	segs["RunSteps"]=RunSteps=async function(input){//:1I11LRKTM0
		let result;
		let sourcePath=pathLib.joinTabOSURL(basePath,"./ExecAction.js");
		let arg={"targetPage":context.aaPage,"execData":{},"action":input.execute};
		result= await session.pipeChat(sourcePath,arg,false);
		return {seg:Wait1S,result:(result),preSeg:"1I11LRKTM0",outlet:"1I11LS3KC1"};
	};
	RunSteps.jaxId="1I11LRKTM0"
	RunSteps.url="RunSteps@"+agentURL
	
	segs["ShowArgVO"]=ShowArgVO=async function(input){//:1I11O5KMB0
		let result=input;
		let role="assistant";
		let content=`ArgVO: \n\`\`\`\n${JSON.stringify(input,null,"\t")}\n\`\`\`\n`;
		session.addChatText(role,content);
		return {seg:CheckArgsOK,result:(result),preSeg:"1I11O5KMB0",outlet:"1I11OD8B10"};
	};
	ShowArgVO.jaxId="1I11O5KMB0"
	ShowArgVO.url="ShowArgVO@"+agentURL
	
	segs["ShowSteps"]=ShowSteps=async function(input){//:1I12LABKT0
		let result=input;
		let role="assistant";
		let content=`ArgVO: \n\`\`\`\n${JSON.stringify(input,null,"\t")}\n\`\`\`\n`;
		session.addChatText(role,content);
		return {seg:LoopSteps,result:(result),preSeg:"1I12LABKT0",outlet:"1I12LABKU0"};
	};
	ShowSteps.jaxId="1I12LABKT0"
	ShowSteps.url="ShowSteps@"+agentURL
	
	segs["LoopSteps"]=LoopSteps=async function(input){//:1I12TQ3N50
		let result=input;
		let list=runSteps;
		let i,n,item;
		n=list.length;
		for(i=0;i<n;i++){
			item=list[i];
			await session.runAISeg(agent,RunSteps,item,"1I12TQ3N50","1I12TS48D0")
		}
		return {result:result};
	};
	LoopSteps.jaxId="1I12TQ3N50"
	LoopSteps.url="LoopSteps@"+agentURL
	
	segs["Wait1S"]=Wait1S=async function(input){//:1I12TRIS30
		let result=input;
		let time=1000;
		await sleep(time);
		return {result:result};
	};
	Wait1S.jaxId="1I12TRIS30"
	Wait1S.url="Wait1S@"+agentURL
	
	segs["ClosePage"]=ClosePage=async function(input){//:1I12TT1UL0
		let result=true;
		let pageVal="aaPage";
		let waitBefore=0;
		let waitAfter=0;
		let page=context[pageVal];
		waitBefore && (await sleep(waitBefore));
		await page.close();
		waitAfter && (await sleep(waitAfter))
		return {result:result};
	};
	ClosePage.jaxId="1I12TT1UL0"
	ClosePage.url="ClosePage@"+agentURL
	
	agent={
		isAIAgent:true,
		session:session,
		name:"RunSkillFile",
		url:agentURL,
		autoStart:true,
		jaxId:"1I11L4SS40",
		context:context,
		livingSeg:null,
		execChat:async function(input/*{skillFileName,args,command}*/){
			let result;
			if(typeof(input)=='object'){
				skillFileName=input.skillFileName;
				args=input.args;
				command=input.command;
			}else{
				skillFileName=undefined;
				args=undefined;
				command=undefined;
			}
			/*#{1I11L4SS40PreEntry*/
			/*}#1I11L4SS40PreEntry*/
			result={seg:Start,"input":input};
			/*#{1I11L4SS40PostEntry*/
			/*}#1I11L4SS40PostEntry*/
			return result;
		},
		/*#{1I11L4SS40MoreAgentAttrs*/
		/*}#1I11L4SS40MoreAgentAttrs*/
	};
	/*#{1I11L4SS40PostAgent*/
	/*}#1I11L4SS40PostAgent*/
	return agent;
};
/*#{1I11L4SS40ExCodes*/
/*}#1I11L4SS40ExCodes*/


export default RunSkillFile;
export{RunSkillFile};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DocAIAgent",
//	"jaxId": "1I11L4SS40",
//	"attrs": {
//		"editObjs": {
//			"jaxId": "1I11L4SS50",
//			"attrs": {
//				"RunSkillFile": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1I11L4SS56",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1I11L4SS57",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1I11L4SS58",
//							"attrs": {}
//						},
//						"functions": {
//							"jaxId": "1I11L4SS59",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false"
//					},
//					"mockups": {}
//				}
//			}
//		},
//		"agent": {
//			"jaxId": "1I11L4SS51",
//			"attrs": {}
//		},
//		"entry": "",
//		"autoStart": "true",
//		"debug": "true",
//		"apiArgs": {
//			"jaxId": "1I11L4SS52",
//			"attrs": {
//				"skillFileName": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I11LE2JM0",
//					"attrs": {
//						"type": "String",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				},
//				"args": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I11LE2JM1",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "null",
//						"desc": ""
//					}
//				},
//				"command": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I11LE2JM2",
//					"attrs": {
//						"type": "String",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1I11L4SS53",
//			"attrs": {
//				"skillFunction": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"skillDefVO": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"argTemplate": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"argVO": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"runSteps": {
//					"type": "auto",
//					"valText": "null"
//				}
//			}
//		},
//		"context": {
//			"jaxId": "1I11L4SS54",
//			"attrs": {}
//		},
//		"globalMockup": {
//			"jaxId": "1I11L4SS55",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "aiseg",
//					"def": "AAFStart",
//					"jaxId": "1I11L5GP70",
//					"attrs": {
//						"id": "Start",
//						"label": "New AI Seg",
//						"x": "110",
//						"y": "130",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I11LE2JM3",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I11LE2JM4",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I11LE2JJ0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I11LEM940"
//						},
//						"catchlet": {
//							"jaxId": "1I11LE2JM5",
//							"attrs": {
//								"id": "NoAAE",
//								"desc": "输出节点。",
//								"output": "",
//								"codes": "false",
//								"context": {
//									"jaxId": "1I11LE2JM6",
//									"attrs": {
//										"cast": ""
//									}
//								},
//								"global": {
//									"jaxId": "1I11LE2JM7",
//									"attrs": {
//										"cast": ""
//									}
//								}
//							}
//						},
//						"aiQuery": "true"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I11LEM940",
//					"attrs": {
//						"id": "LoadFile",
//						"label": "New AI Seg",
//						"x": "320",
//						"y": "115",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I11LEV520",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I11LEV521",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I11LEV510",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I11LFF340"
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "brunch",
//					"jaxId": "1I11LFF340",
//					"attrs": {
//						"id": "CheckArg",
//						"label": "New AI Seg",
//						"x": "540",
//						"y": "115",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I11LIUTC0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I11LIUTC1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I11LIUT91",
//							"attrs": {
//								"id": "Default",
//								"desc": "输出节点。",
//								"output": ""
//							},
//							"linkedSeg": "1I11LGKLB0"
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I11LIUT90",
//									"attrs": {
//										"id": "HasArg",
//										"desc": "输出节点。",
//										"output": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I11LIUTC2",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I11LIUTC3",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": ""
//									},
//									"linkedSeg": "1I11LI4110"
//								}
//							]
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "callLLM",
//					"jaxId": "1I11LGKLB0",
//					"attrs": {
//						"id": "GenArg",
//						"label": "New AI Seg",
//						"x": "780",
//						"y": "150",
//						"desc": "执行一次LLM调用。",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "faces.svg",
//						"context": {
//							"jaxId": "1I11LIUTC4",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I11LIUTC5",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"platform": "\"OpenAI\"",
//						"mode": "gpt-4o",
//						"system": "你是一个根据API调用定义VO和自然语言指令生成调用API参数对象的AI\n- 每轮对话的输入包含\"API调用定义VO\"和需要API执行操作的自然语言指令。\n- 分析\"API调用定义VO\"和自然语言指令，生成调用API的参数对象，如果自然语你需要在调用参数把缺少的参数的值设置为\"$$MISSING$$\"。例如：\n//缺少\"size\"属性：\n```\n{\n\t\"number\":100,\n    \"size:\"$$MISSGING$$\"\n}\n```\n请用JSON格式返回调用参数VO",
//						"temperature": "0",
//						"maxToken": "2000",
//						"topP": "1",
//						"fqcP": "0",
//						"prcP": "0",
//						"messages": {
//							"attrs": []
//						},
//						"prompt": "#`\nAPI调用定义VO：\n\\`\\`\\`\n${JSON.stringify(skillDefVO,null,\"\\t\")}\n\\`\\`\\`\n自然语言指令：\n${command}\n`",
//						"seed": "",
//						"outlet": {
//							"jaxId": "1I11LIUT92",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I11O5KMB0"
//						},
//						"secret": "false",
//						"allowCheat": "true",
//						"GPTCheats": {
//							"attrs": [
//								{
//									"type": "object",
//									"def": "GPTCheat",
//									"jaxId": "1I12L969D0",
//									"attrs": {
//										"prompt": "",
//										"reply": "{\n\t\"text\": \"今天在AI2App的RPA DashBoard\",\n\t\"photos\": \"$$MISSING$$\"\n}"
//									}
//								}
//							]
//						},
//						"shareChatName": "",
//						"keepChat": "No",
//						"clearChat": "2",
//						"apiFiles": {
//							"attrs": []
//						},
//						"parallelFunction": "false",
//						"responseFormat": "json_object"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "brunch",
//					"jaxId": "1I11LHK050",
//					"attrs": {
//						"id": "CheckArgsOK",
//						"label": "New AI Seg",
//						"x": "1250",
//						"y": "150",
//						"desc": "这是一个AISeg。",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I11LIUTC6",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I11LIUTC7",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I11LIUTA0",
//							"attrs": {
//								"id": "Default",
//								"desc": "输出节点。",
//								"output": ""
//							},
//							"linkedSeg": "1I12012CH0"
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I11LNC0A0",
//									"attrs": {
//										"id": "Missing",
//										"desc": "输出节点。",
//										"output": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I11LNC0E0",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I11LNC0E1",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "hasMissing"
//									},
//									"linkedSeg": "1I11T5RQP0"
//								}
//							]
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I11T5RQP0",
//					"attrs": {
//						"id": "GenArgTemplate",
//						"label": "New AI Seg",
//						"x": "1500",
//						"y": "85",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I11TGIHL0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I11TGIHL1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I11TA8KG0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I11T95520"
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "askDataView",
//					"jaxId": "1I11T95520",
//					"attrs": {
//						"id": "AskArgs",
//						"label": "New AI Seg",
//						"x": "1760",
//						"y": "85",
//						"desc": "这是一个AISeg。",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I11TGIHL2",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I11TGIHL3",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I11TA8KG1",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I11LLJ7D0"
//						},
//						"text": "Please input:",
//						"role": "Assistant",
//						"data": "#argVO",
//						"editData": "true"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connectorL",
//					"jaxId": "1I11LI4110",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "780",
//						"y": "75",
//						"outlet": {
//							"jaxId": "1I11LIUTC8",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I11O7ARE0"
//						},
//						"dir": "L2R"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "AAFOpenBrowser",
//					"jaxId": "1I11LLJ7D0",
//					"attrs": {
//						"id": "OpenBrowser",
//						"label": "New AI Seg",
//						"x": "2000",
//						"y": "130",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I11LNC0E2",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I11LNC0E3",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"alias": "AAHOME",
//						"headless": "false",
//						"devtools": "false",
//						"dataDir": "false",
//						"outlet": {
//							"jaxId": "1I11LNC0A1",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I11LMVSQ0"
//						},
//						"run": ""
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "AAFOpenPage",
//					"jaxId": "1I11LMVSQ0",
//					"attrs": {
//						"id": "OpenPage",
//						"label": "New AI Seg",
//						"x": "2245",
//						"y": "130",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I11LNC0E4",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I11LNC0E5",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"valName": "aaPage",
//						"url": "#skillDefVO.startURL",
//						"vpWidth": "1200",
//						"vpHeight": "900",
//						"userAgent": "",
//						"waitBefore": "0",
//						"waitAfter": "0",
//						"outlet": {
//							"jaxId": "1I11LNC0B0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I11LOV7B0"
//						},
//						"run": ""
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I11LOV7B0",
//					"attrs": {
//						"id": "GenSteps",
//						"label": "New AI Seg",
//						"x": "2470",
//						"y": "130",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I11LS3KF0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I11LS3KF1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I11LS3KC0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I12LABKT0"
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "aiBot",
//					"jaxId": "1I11LRKTM0",
//					"attrs": {
//						"id": "RunSteps",
//						"label": "New AI Seg",
//						"x": "3175",
//						"y": "60",
//						"desc": "调用其它AI Agent，把调用的结果作为输出",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I11LS3KF2",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I11LS3KF3",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"source": "ai/ExecAction.js",
//						"argument": "{\"targetPage\":\"#context.aaPage\",\"execData\":\"#{}\",\"action\":\"#input.execute\"}",
//						"secret": "false",
//						"outlet": {
//							"jaxId": "1I11LS3KC1",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I12TRIS30"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1I11O5KMB0",
//					"attrs": {
//						"id": "ShowArgVO",
//						"label": "New AI Seg",
//						"x": "995",
//						"y": "150",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I11OD8B70",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I11OD8B71",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "Assistant",
//						"text": "#`ArgVO: \\n\\`\\`\\`\\n${JSON.stringify(input,null,\"\\t\")}\\n\\`\\`\\`\\n`",
//						"outlet": {
//							"jaxId": "1I11OD8B10",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I11LHK050"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connectorL",
//					"jaxId": "1I11O7ARE0",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "1115",
//						"y": "75",
//						"outlet": {
//							"jaxId": "1I11OD8B72",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I11LHK050"
//						},
//						"dir": "L2R"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connectorL",
//					"jaxId": "1I12012CH0",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "1860",
//						"y": "165",
//						"outlet": {
//							"jaxId": "1I1202NNT0",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I11LLJ7D0"
//						},
//						"dir": "L2R"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1I12LABKT0",
//					"attrs": {
//						"id": "ShowSteps",
//						"label": "New AI Seg",
//						"x": "2700",
//						"y": "130",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I12LABKT1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I12LABKT2",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "Assistant",
//						"text": "#`ArgVO: \\n\\`\\`\\`\\n${JSON.stringify(input,null,\"\\t\")}\\n\\`\\`\\`\\n`",
//						"outlet": {
//							"jaxId": "1I12LABKU0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I12TQ3N50"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "loopArray",
//					"jaxId": "1I12TQ3N50",
//					"attrs": {
//						"id": "LoopSteps",
//						"label": "New AI Seg",
//						"x": "2945",
//						"y": "130",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I12TS48K0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I12TS48K1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"loopArray": "#runSteps",
//						"method": "forEach",
//						"outlet": {
//							"jaxId": "1I12TS48D0",
//							"attrs": {
//								"id": "Looper",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I11LRKTM0"
//						},
//						"catchlet": {
//							"jaxId": "1I12TS48D1",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "sleep",
//					"jaxId": "1I12TRIS30",
//					"attrs": {
//						"id": "Wait1S",
//						"label": "New AI Seg",
//						"x": "3395",
//						"y": "60",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I12TS48K2",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I12TS48K3",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"time": "1000",
//						"outlet": {
//							"jaxId": "1I12TS48D2",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							}
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "AAFClosePage",
//					"jaxId": "1I12TT1UL0",
//					"attrs": {
//						"id": "ClosePage",
//						"label": "New AI Seg",
//						"x": "3175",
//						"y": "190",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I12TTB200",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I12TTB201",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"page": "aaPage",
//						"waitBefore": "0",
//						"waitAfter": "0",
//						"outlet": {
//							"jaxId": "1I12TTB1R0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							}
//						},
//						"run": ""
//					}
//				}
//			]
//		},
//		"desc": "这是一个AI代理。",
//		"exportAPI": "false",
//		"exportAddOn": "false",
//		"addOnOpts": ""
//	}
//}