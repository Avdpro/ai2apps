//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import pathLib from "/@path";
import inherits from "/@inherits";
import Base64 from "/@tabos/utils/base64.js";
import {trimJSON} from "/@aichat/utils.js";
/*#{1I33BVLV01MoreImports*/
import {tabFS} from "/@tabos";
import {AASkills} from "/@aae/AASkills.js";
/*}#1I33BVLV01MoreImports*/
const agentURL=(new URL(import.meta.url)).pathname;
const basePath=pathLib.dirname(agentURL);
const $ln=VFACT.lanCode||"EN";
const argsTemplate={
	properties:{
		"hostBot":{
			"name":"hostBot","type":"auto",
			"defaultValue":"",
			"desc":"",
		},
		"command":{
			"name":"command","type":"string",
			"defaultValue":"",
			"desc":"",
		},
		"chatMessages":{
			"name":"chatMessages","type":"auto",
			"defaultValue":"",
			"desc":"",
		}
	},
	/*#{1I33BVLV01ArgsView*/
	/*}#1I33BVLV01ArgsView*/
};

/*#{1I33BVLV01StartDoc*/
let topWindow;
topWindow=window;
while(topWindow && topWindow.parent && topWindow.parent!==topWindow){
	topWindow=topWindow.parent;
}
const topVFACT=topWindow.VFACT;
let tempDirPath;
//----------------------------------------------------------------------------
async function setupTempDir(glbCtx){
	let baseName,dirPath,cnt;
	if(!glbCtx.exechangeRes){
		glbCtx.exechangeRes={};
	}
	if(glbCtx.tempDirPath){
		tempDirPath=glbCtx.tempDirPath;
		return;
	}
	cnt=0;
	dirPath=baseName="/doc/Temp/TEMP_"+Date.now();
	do{
		if(!(await tabFS.isExist(dirPath))){
			break;
		}
		cnt+=1;
		dirPath=baseName+cnt;
	}while(1);
	await tabFS.newDir(dirPath);
	glbCtx.tempDirPath=tempDirPath=dirPath;
	return dirPath;
};
async function clearTempDir(path){
	path=path||tempDirPath;
	try{
		await tabFS.del(path);
	}catch(err){
	}
};
/*}#1I33BVLV01StartDoc*/
//----------------------------------------------------------------------------
let BotWorkCore=async function(session){
	let hostBot,command,chatMessages;
	let context,globalContext;
	let self;
	let Start,ChooseAct,SwitchAct,PickSkill,TipRunSkill,RunSkill,ShowResult,AppendMessage,TipBotTask,RunBotTask,TipFinish,TipAbort,TipReply,WrapSkill,ShowError,AskUser;
	/*#{1I33BVLV01LocalVals*/
	/*}#1I33BVLV01LocalVals*/
	
	function parseAgentArgs(input){
		if(typeof(input)=='object'){
			hostBot=input.hostBot;
			command=input.command;
			chatMessages=input.chatMessages;
		}else{
			hostBot=undefined;
			command=undefined;
			chatMessages=undefined;
		}
		/*#{1I33BVLV01ParseArgs*/
		/*}#1I33BVLV01ParseArgs*/
	}
	
	/*#{1I33BVLV01PreContext*/
	/*}#1I33BVLV01PreContext*/
	globalContext=session.globalContext;
	context={
		aaSkills: null,
		skillScope: null,
		botScope: {},
		curSkill: null,
		workRound: 0,
		/*#{1I33BVLV05ExCtxAttrs*/
		/*}#1I33BVLV05ExCtxAttrs*/
	};
	context=VFACT.flexState(context);
	/*#{1I33BVLV01PostContext*/
	await setupTempDir(globalContext);
	/*}#1I33BVLV01PostContext*/
	let agent,segs={};
	segs["Start"]=Start=async function(input){//:1I33C22650
		let result=input
		/*#{1I33C22650Code*/
		let saveVO,history;
		
		context.aaSkills=hostBot.skills;
		context.skillScope=await hostBot.getSkillScope(true);
		console.log("WorkCore skill scope:");
		console.log(context.skillScope);
		
		context.botScope=await hostBot.getBotScope(true);
		console.log("WorkCore bot scope:");
		console.log(context.botScope);
		
		history=ChooseAct.messages;
		history.splice(0);
		if(chatMessages){
			history.push(...chatMessages);
		}
		console.log("WorkCore messages:");
		console.log(chatMessages);
		
		result=command;
		console.log("WorkCore prompt:");
		console.log(command);
		/*}#1I33C22650Code*/
		return {seg:ChooseAct,result:(result),preSeg:"1I33C22650",outlet:"1I33C3IEM1"};
	};
	Start.jaxId="1I33C22650"
	Start.url="Start@"+agentURL
	
	segs["ChooseAct"]=ChooseAct=async function(input){//:1I3EQ3FAE0
		let prompt;
		let result=null;
		/*#{1I3EQ3FAE0Input*/
		/*}#1I3EQ3FAE0Input*/
		
		let opts={
			platform:"OpenAI",
			mode:"gpt-4o",
			maxToken:2000,
			temperature:0,
			topP:1,
			fqcP:0,
			prcP:0,
			secret:false,
			responseFormat:"json_object"
		};
		let chatMem=ChooseAct.messages
		let seed="";
		if(seed!==undefined){opts.seed=seed;}
		let messages=[
			{role:"system",content:`
你是一个根据用户输入，选择适合的Skill、或外部智能体(bot)运行，与用户对话，完成任务的AI。
当前可以使用的的SKill有: 
${JSON.stringify(context.skillScope,null,"\t")}  

当前可以调用的其它智能体(bot)有:
${JSON.stringify(context.botScope,null,"\t")}  

- 第一轮对话时，用户输入的是要完成的任务，你根据用户的输入，选择合适的Skill，智能体用于执行，或者回答用户的问题。

- 每一回合对话，跟根据当前任务执行的情况，回复一个JSON对象。

- 如果需要执行一个Skill，回复JSON中的"skill"属性是下一步要执行的SKill的名称; 回复JSON中的prompt属性是调用这个Skill的输入指令。例如：
{
	"skill":"Skill-3",
    "prompt":"Search for: Who is the winner of 2024 F1?"
}

- 如果需要执行一个外部智能体(bot)，回复JSON中的"bot"属性是下一步要执行的智能体的名称，"prompt"属性是要执行的任务描述。例如：
{
	"bot":"BOT_ALICE,
    "prompt":"Draw a picture of a cat driving a car."
}

- 你同时只能执行一个外部智能体（Bot）任务，在当前Bot任务完成前，不能开始新的任务，如果用户要开启新任务或询问进度，请通过回复中的"reply"参数告诉用户。例如:
{
	"reply":"执行当前任务可能还需要一些时间，请再等等"
}
或者：
{
	"reply":"正在执行'绘制汽车图片的外部任务，无法现在执行新的任务。'"
}

- 执行Skill或者智能体的结果会在对话中告知，你根据任务目标以及执行情况，选择新的Skill/智能体继续，直到结束。

- 如果成功的完成了用户提出的任务，回复将JSON中的"finish"属性设置为true。并通过"result"属性总结汇报执行情况。例如
{
	"finish":true,
    "result":"论坛帖子已经成功发布。"
}

- 如果执行Skill出现错误，你认为无法完成用户的任务，设置回复JSON中的"abort"属性为true，并在"reason"属性中说明原因。例如:
{
	"abort":true,
    "reason":"没有登录脸书账号，无法发布新的内容。"
}

- 应用户的指令需要更多信息，或者需要用户回答问题，才能继续执行任务、持续的对话，设置JSON中的 "ask"属性向用户提问或与用户对话，并把finsish设置为false。例如
{
	"ask":"请问你职业是什么？",
	"finish":false
}

- 如果回答用户的输入不需要更多信息，或者不再需要使用任何skill、智能体调用，用回复JSON中的"replay"属性回答用户，如果对话已结束，同时设置"finish"属性为true；否则，设置"finish"属性为false。例如：
\`\`\`
//对话结束：
{
	"finish":true,
	"reply":"是的，西瓜是一种水果。"
}
//继续对话：
{
	"finish":false,
	"reply":"是的，西瓜是一种水果。"
}
\`\`\`

- 如果回答用户的输入包含一个或文件链接，在回复JSON中的:"assets"数组属性里包含这些文件链接。例如：
\`\`\`
//单个文件
{
	"finish":true,
	"result":"PDF文件已生成: res://MyGreateDoc.pdf。",
    "assets":["res://MyGreateDoc.pdf"]
}
//多个文件：
{
	"finish":true,
	"reply":"绘制了3幅图片: res://File121-image1.png, res://File122-image2.png, res://File123-image3.png。",
    "assets":[
    	"res://File121-image1.png",
        "res://File122-image2.png,
        "res://File123-image3.png"
    ]
}
\`\`\`

- 非常重要：如果能够本地Skill完成任务，就不要调用外部智能体(Bot)
`
},
		];
		messages.push(...chatMem);
		/*#{1I3EQ3FAE0PrePrompt*/
		/*}#1I3EQ3FAE0PrePrompt*/
		prompt=input;
		if(prompt!==null){
			messages.push({role:"user",content:prompt});
		}
		/*#{1I3EQ3FAE0PreCall*/
		/*}#1I3EQ3FAE0PreCall*/
		result=(result===null)?(await session.callSegLLM("ChooseAct@"+agentURL,opts,messages,true)):result;
		/*#{1I3EQ3FAE0PostLLM*/
		/*}#1I3EQ3FAE0PostLLM*/
		chatMem.push({role:"user",content:prompt});
		chatMem.push({role:"assistant",content:result});
		if(chatMem.length>50){
			let removedMsgs=chatMem.splice(0,6);
			/*#{1I3EQ3FAE0PostClear*/
			/*}#1I3EQ3FAE0PostClear*/
		}
		result=trimJSON(result);
		/*#{1I3EQ3FAE0PostCall*/
		console.log("[BotWOrkCore.js] ChooseAct result:");
		console.log(result);
		/*}#1I3EQ3FAE0PostCall*/
		return {seg:SwitchAct,result:(result),preSeg:"1I3EQ3FAE0",outlet:"1I3EQH43J0"};
	};
	ChooseAct.jaxId="1I3EQ3FAE0"
	ChooseAct.url="ChooseAct@"+agentURL
	ChooseAct.messages=[];
	
	segs["SwitchAct"]=SwitchAct=async function(input){//:1I3EQ4O560
		let result=input;
		if(!!input.skill){
			let output=input;
			/*#{1I3EQH43K0Codes*/
			/*}#1I3EQH43K0Codes*/
			return {seg:PickSkill,result:(output),preSeg:"1I3EQ4O560",outlet:"1I3EQH43K0"};
		}
		if(!!input.ask){
			let output=input;
			return {seg:AskUser,result:(output),preSeg:"1I3EQ4O560",outlet:"1I5FPLMRR0"};
		}
		if(!!input.bot){
			let output=input;
			return {seg:TipBotTask,result:(output),preSeg:"1I3EQ4O560",outlet:"1I3EQ567O0"};
		}
		if(!!input.finish){
			let output=input;
			return {seg:TipFinish,result:(output),preSeg:"1I3EQ4O560",outlet:"1I3EQ7E8N0"};
		}
		if(input.abort){
			let output=input;
			return {seg:TipAbort,result:(output),preSeg:"1I3EQ4O560",outlet:"1I3EQ7MT20"};
		}
		if(!!input.reply){
			let output=input;
			return {seg:TipReply,result:(output),preSeg:"1I3EQ4O560",outlet:"1I3EQ81MS0"};
		}
		return {result:result};
	};
	SwitchAct.jaxId="1I3EQ4O560"
	SwitchAct.url="SwitchAct@"+agentURL
	
	segs["PickSkill"]=PickSkill=async function(input){//:1I3FECJ020
		let result=input
		/*#{1I3FECJ020Code*/
		let skillId;
		console.log(input);
		skillId=input.skill;
		skillId=parseInt(skillId.substring(6));
		context.curSkill=context.aaSkills.getSkills()[skillId];
		/*}#1I3FECJ020Code*/
		return {seg:TipRunSkill,result:(result),preSeg:"1I3FECJ020",outlet:"1I3FEDCEN0"};
	};
	PickSkill.jaxId="1I3FECJ020"
	PickSkill.url="PickSkill@"+agentURL
	
	segs["TipRunSkill"]=TipRunSkill=async function(input){//:1I3EQI4GG0
		let result=input;
		let role="assistant";
		let content=`- Skill: ${context.curSkill.getNameText()}- Prompt: ${input.prompt}`;
		session.addChatText(role,content);
		return {seg:WrapSkill,result:(result),preSeg:"1I3EQI4GG0",outlet:"1I3EQIK5A1"};
	};
	TipRunSkill.jaxId="1I3EQI4GG0"
	TipRunSkill.url="TipRunSkill@"+agentURL
	
	segs["RunSkill"]=RunSkill=async function(input){//:1I3EQ92PI0
		let result=input
		/*#{1I3EQ92PI0Code*/
		let skill=context.curSkill;
		result=await context.aaSkills.execSkill(topVFACT.app,skill,input.prompt?JSON.stringify(input.prompt):"",session);
		/*}#1I3EQ92PI0Code*/
		return {seg:ShowResult,result:(result),preSeg:"1I3EQ92PI0",outlet:"1I3EQH43K2"};
	};
	RunSkill.jaxId="1I3EQ92PI0"
	RunSkill.url="RunSkill@"+agentURL
	
	segs["ShowResult"]=ShowResult=async function(input){//:1I3EQAJ9G0
		let result=input;
		let role="assistant";
		let content=input;
		session.addChatText(role,content);
		return {seg:AppendMessage,result:(result),preSeg:"1I3EQAJ9G0",outlet:"1I3EQH43K4"};
	};
	ShowResult.jaxId="1I3EQAJ9G0"
	ShowResult.url="ShowResult@"+agentURL
	
	segs["AppendMessage"]=AppendMessage=async function(input){//:1I3EQA2HE0
		let result=input
		/*#{1I3EQA2HE0Code*/
		result=`Run skill result: ${JSON.stringify(input,null,"\t")}`;
		/*}#1I3EQA2HE0Code*/
		return {seg:ChooseAct,result:(result),preSeg:"1I3EQA2HE0",outlet:"1I3EQH43K3"};
	};
	AppendMessage.jaxId="1I3EQA2HE0"
	AppendMessage.url="AppendMessage@"+agentURL
	
	segs["TipBotTask"]=TipBotTask=async function(input){//:1I3EQJN9E0
		let result=input;
		let role="assistant";
		let content=`Task: 
\`\`\`
${JSON.stringify(input,null,"\t")}
\`\`\`
`;
		session.addChatText(role,content);
		return {seg:RunBotTask,result:(result),preSeg:"1I3EQJN9E0",outlet:"1I3EQQH5H0"};
	};
	TipBotTask.jaxId="1I3EQJN9E0"
	TipBotTask.url="TipBotTask@"+agentURL
	
	segs["RunBotTask"]=RunBotTask=async function(input){//:1I3EQKCNE0
		let result=input
		/*#{1I3EQKCNE0Code*/
		//await hostBot.newTaskReq(input.bot,input.prompt,chatFlow);
		result={
			finish:false,
			botTaskReq: {bot:input.bot,prompt:input.prompt}
		};
		/*}#1I3EQKCNE0Code*/
		return {result:result};
	};
	RunBotTask.jaxId="1I3EQKCNE0"
	RunBotTask.url="RunBotTask@"+agentURL
	
	segs["TipFinish"]=TipFinish=async function(input){//:1I3EQM7E80
		let result=input;
		let role="assistant";
		let content=input.result||input.reply;
		/*#{1I3EQM7E80PreCodes*/
		/*}#1I3EQM7E80PreCodes*/
		session.addChatText(role,content);
		/*#{1I3EQM7E80PostCodes*/
		result={result:content,finish:true,assets:input.assets};
		/*}#1I3EQM7E80PostCodes*/
		return {result:result};
	};
	TipFinish.jaxId="1I3EQM7E80"
	TipFinish.url="TipFinish@"+agentURL
	
	segs["TipAbort"]=TipAbort=async function(input){//:1I3EQOAOR0
		let result=input;
		let role="assistant";
		let content=`Task aborted, reason: ${input.reason}`;
		/*#{1I3EQOAOR0PreCodes*/
		/*}#1I3EQOAOR0PreCodes*/
		session.addChatText(role,content);
		/*#{1I3EQOAOR0PostCodes*/
		result={result:content,abort:true,finish:true,assets:input.assets};
		/*}#1I3EQOAOR0PostCodes*/
		return {result:result};
	};
	TipAbort.jaxId="1I3EQOAOR0"
	TipAbort.url="TipAbort@"+agentURL
	
	segs["TipReply"]=TipReply=async function(input){//:1I3EQOPT80
		let result=input;
		let role="assistant";
		let content=input.reply;
		/*#{1I3EQOPT80PreCodes*/
		/*}#1I3EQOPT80PreCodes*/
		session.addChatText(role,content);
		/*#{1I3EQOPT80PostCodes*/
		result={result:content,finish:false,assets:input.assets};
		/*}#1I3EQOPT80PostCodes*/
		return {result:result};
	};
	TipReply.jaxId="1I3EQOPT80"
	TipReply.url="TipReply@"+agentURL
	
	segs["WrapSkill"]=WrapSkill=async function(input){//:1I5FHT3860
		let result=input;
		/*#{1I5FHT3860Code*/
		false
		/*}#1I5FHT3860Code*/
		return {seg:RunSkill,result:(result),preSeg:"1I5FHT3860",outlet:"1I5FHVOUE0",catchSeg:ShowError,catchlet:"1I5FHVOUE1"};
	};
	WrapSkill.jaxId="1I5FHT3860"
	WrapSkill.url="WrapSkill@"+agentURL
	
	segs["ShowError"]=ShowError=async function(input){//:1I5FI0D7O0
		let result=input;
		let role="assistant";
		let content=`Skill error: ${input}`;
		/*#{1I5FI0D7O0PreCodes*/
		/*}#1I5FI0D7O0PreCodes*/
		session.addChatText(role,content);
		/*#{1I5FI0D7O0PostCodes*/
		throw(input);
		/*}#1I5FI0D7O0PostCodes*/
		return {result:result};
	};
	ShowError.jaxId="1I5FI0D7O0"
	ShowError.url="ShowError@"+agentURL
	
	segs["AskUser"]=AskUser=async function(input){//:1I5FPO5LP0
		let result=input
		/*#{1I5FPO5LP0Code*/
		result={ask:input.ask,finish:false,assets:input.assets};
		/*}#1I5FPO5LP0Code*/
		return {result:result};
	};
	AskUser.jaxId="1I5FPO5LP0"
	AskUser.url="AskUser@"+agentURL
	
	agent={
		isAIAgent:true,
		session:session,
		name:"BotWorkCore",
		url:agentURL,
		autoStart:true,
		jaxId:"1I33BVLV01",
		context:context,
		livingSeg:null,
		execChat:async function(input/*{hostBot,command,chatMessages}*/){
			let result;
			parseAgentArgs(input);
			/*#{1I33BVLV01PreEntry*/
			/*}#1I33BVLV01PreEntry*/
			result={seg:Start,"input":input};
			/*#{1I33BVLV01PostEntry*/
			/*}#1I33BVLV01PostEntry*/
			return result;
		},
		/*#{1I33BVLV01MoreAgentAttrs*/
		/*}#1I33BVLV01MoreAgentAttrs*/
	};
	/*#{1I33BVLV01PostAgent*/
	/*}#1I33BVLV01PostAgent*/
	return agent;
};
/*#{1I33BVLV01ExCodes*/
/*}#1I33BVLV01ExCodes*/

export const ChatAPI=[{
	def:{
		name: "BotWorkCore",
		description: "这是一个AI智能体。",
		parameters:{
			type: "object",
			properties:{
				hostBot:{type:"auto",description:""},
				command:{type:"string",description:""},
				chatMessages:{type:"auto",description:""}
			}
		}
	},
	agent: BotWorkCore
}];

//:Export Edit-AddOn:
const DocAIAgentExporter=VFACT.classRegs.DocAIAgentExporter;
if(DocAIAgentExporter){
	const EditAttr=VFACT.classRegs.EditAttr;
	const EditAISeg=VFACT.classRegs.EditAISeg;
	const EditAISegOutlet=VFACT.classRegs.EditAISegOutlet;
	const SegObjShellAttr=EditAISeg.SegObjShellAttr;
	const SegOutletDef=EditAISegOutlet.SegOutletDef;
	const docAIAgentExporter=DocAIAgentExporter.prototype;
	const packExtraCodes=docAIAgentExporter.packExtraCodes;
	const packResult=docAIAgentExporter.packResult;
	const varNameRegex = /^[a-zA-Z_$][a-zA-Z0-9_$]*$/;
	
	EditAISeg.regDef({
		name:"BotWorkCore",showName:"BotWorkCore",icon:"agent.svg",catalog:["AI Call"],
		attrs:{
			...SegObjShellAttr,
			"hostBot":{name:"hostBot",type:"auto",key:1,fixed:1,initVal:""},
			"command":{name:"command",type:"string",key:1,fixed:1,initVal:""},
			"chatMessages":{name:"chatMessages",type:"auto",key:1,fixed:1,initVal:""},
			"outlet":{name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc"}
		},
		listHint:["id","hostBot","command","chatMessages","codes","desc"],
		desc:"这是一个AI智能体。"
	});
	
	DocAIAgentExporter.segTypeExporters["BotWorkCore"]=
	function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let exportDebug=this.isExportDebug();
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();coder.newLine();
		{
			coder.packText(`let result,args={};`);coder.newLine();
			coder.packText("args['hostBot']=");this.genAttrStatement(seg.getAttr("hostBot"));coder.packText(";");coder.newLine();
			coder.packText("args['command']=");this.genAttrStatement(seg.getAttr("command"));coder.packText(";");coder.newLine();
			coder.packText("args['chatMessages']=");this.genAttrStatement(seg.getAttr("chatMessages"));coder.packText(";");coder.newLine();
			this.packExtraCodes(coder,seg,"PreCodes");
			coder.packText(`result= await session.pipeChat("/~/aae/ai/BotWorkCore.js",args,false);`);coder.newLine();
			this.packExtraCodes(coder,seg,"PostCodes");
			this.packResult(coder,seg,seg.outlet);
		}
		coder.indentLess();coder.maybeNewLine();
		coder.packText(`};`);coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		coder.newLine();
	};
}
/*#{1I33BVLV01PostDoc*/
/*}#1I33BVLV01PostDoc*/


export default BotWorkCore;
export{BotWorkCore};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DocAIAgent",
//	"jaxId": "1I33BVLV01",
//	"attrs": {
//		"editObjs": {
//			"jaxId": "1I33BVLV01",
//			"attrs": {
//				"BotWorkCore": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1I33BVLV07",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1I33BVLV08",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1I33BVLV09",
//							"attrs": {}
//						},
//						"functions": {
//							"jaxId": "1I33BVLV010",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false"
//					},
//					"mockups": {}
//				}
//			}
//		},
//		"agent": {
//			"jaxId": "1I33BVLV02",
//			"attrs": {}
//		},
//		"entry": "Start",
//		"autoStart": "true",
//		"debug": "true",
//		"apiArgs": {
//			"jaxId": "1I33BVLV03",
//			"attrs": {
//				"hostBot": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I5CNUQV60",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				},
//				"command": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I3F1IO940",
//					"attrs": {
//						"type": "String",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				},
//				"chatMessages": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I5CO49N80",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1I33BVLV04",
//			"attrs": {}
//		},
//		"context": {
//			"jaxId": "1I33BVLV05",
//			"attrs": {
//				"aaSkills": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I3F1SVUN0",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "null",
//						"desc": ""
//					}
//				},
//				"skillScope": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I3F1SVUN1",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "null",
//						"desc": ""
//					}
//				},
//				"botScope": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I3F1VQBR0",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "{}",
//						"desc": ""
//					}
//				},
//				"curSkill": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I3F1SVUN2",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "null",
//						"desc": ""
//					}
//				},
//				"workRound": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I3F1SVUN3",
//					"attrs": {
//						"type": "Integer",
//						"mockup": "0",
//						"desc": ""
//					}
//				}
//			}
//		},
//		"globalMockup": {
//			"jaxId": "1I33BVLV06",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I33C22650",
//					"attrs": {
//						"id": "Start",
//						"label": "New AI Seg",
//						"x": "60",
//						"y": "390",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I33C3IEP3",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I33C3IEP4",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I33C3IEM1",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I3EQ3FAE0"
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "callLLM",
//					"jaxId": "1I3EQ3FAE0",
//					"attrs": {
//						"id": "ChooseAct",
//						"label": "New AI Seg",
//						"x": "270",
//						"y": "390",
//						"desc": "执行一次LLM调用。",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "faces.svg",
//						"context": {
//							"jaxId": "1I3EQH43N0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I3EQH43N1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"platform": "\"OpenAI\"",
//						"mode": "gpt-4o",
//						"system": "#`\n你是一个根据用户输入，选择适合的Skill、或外部智能体(bot)运行，与用户对话，完成任务的AI。\n当前可以使用的的SKill有: \n${JSON.stringify(context.skillScope,null,\"\\t\")}  \n\n当前可以调用的其它智能体(bot)有:\n${JSON.stringify(context.botScope,null,\"\\t\")}  \n\n- 第一轮对话时，用户输入的是要完成的任务，你根据用户的输入，选择合适的Skill，智能体用于执行，或者回答用户的问题。\n\n- 每一回合对话，跟根据当前任务执行的情况，回复一个JSON对象。\n\n- 如果需要执行一个Skill，回复JSON中的\"skill\"属性是下一步要执行的SKill的名称; 回复JSON中的prompt属性是调用这个Skill的输入指令。例如：\n{\n\t\"skill\":\"Skill-3\",\n    \"prompt\":\"Search for: Who is the winner of 2024 F1?\"\n}\n\n- 如果需要执行一个外部智能体(bot)，回复JSON中的\"bot\"属性是下一步要执行的智能体的名称，\"prompt\"属性是要执行的任务描述。例如：\n{\n\t\"bot\":\"BOT_ALICE,\n    \"prompt\":\"Draw a picture of a cat driving a car.\"\n}\n\n- 你同时只能执行一个外部智能体（Bot）任务，在当前Bot任务完成前，不能开始新的任务，如果用户要开启新任务或询问进度，请通过回复中的\"reply\"参数告诉用户。例如:\n{\n\t\"reply\":\"执行当前任务可能还需要一些时间，请再等等\"\n}\n或者：\n{\n\t\"reply\":\"正在执行'绘制汽车图片的外部任务，无法现在执行新的任务。'\"\n}\n\n- 执行Skill或者智能体的结果会在对话中告知，你根据任务目标以及执行情况，选择新的Skill/智能体继续，直到结束。\n\n- 如果成功的完成了用户提出的任务，回复将JSON中的\"finish\"属性设置为true。并通过\"result\"属性总结汇报执行情况。例如\n{\n\t\"finish\":true,\n    \"result\":\"论坛帖子已经成功发布。\"\n}\n\n- 如果执行Skill出现错误，你认为无法完成用户的任务，设置回复JSON中的\"abort\"属性为true，并在\"reason\"属性中说明原因。例如:\n{\n\t\"abort\":true,\n    \"reason\":\"没有登录脸书账号，无法发布新的内容。\"\n}\n\n- 应用户的指令需要更多信息，或者需要用户回答问题，才能继续执行任务、持续的对话，设置JSON中的 \"ask\"属性向用户提问或与用户对话，并把finsish设置为false。例如\n{\n\t\"ask\":\"请问你职业是什么？\",\n\t\"finish\":false\n}\n\n- 如果回答用户的输入不需要更多信息，或者不再需要使用任何skill、智能体调用，用回复JSON中的\"replay\"属性回答用户，如果对话已结束，同时设置\"finish\"属性为true；否则，设置\"finish\"属性为false。例如：\n\\`\\`\\`\n//对话结束：\n{\n\t\"finish\":true,\n\t\"reply\":\"是的，西瓜是一种水果。\"\n}\n//继续对话：\n{\n\t\"finish\":false,\n\t\"reply\":\"是的，西瓜是一种水果。\"\n}\n\\`\\`\\`\n\n- 如果回答用户的输入包含一个或文件链接，在回复JSON中的:\"assets\"数组属性里包含这些文件链接。例如：\n\\`\\`\\`\n//单个文件\n{\n\t\"finish\":true,\n\t\"result\":\"PDF文件已生成: res://MyGreateDoc.pdf。\",\n    \"assets\":[\"res://MyGreateDoc.pdf\"]\n}\n//多个文件：\n{\n\t\"finish\":true,\n\t\"reply\":\"绘制了3幅图片: res://File121-image1.png, res://File122-image2.png, res://File123-image3.png。\",\n    \"assets\":[\n    \t\"res://File121-image1.png\",\n        \"res://File122-image2.png,\n        \"res://File123-image3.png\"\n    ]\n}\n\\`\\`\\`\n\n- 非常重要：如果能够本地Skill完成任务，就不要调用外部智能体(Bot)\n`\n",
//						"temperature": "0",
//						"maxToken": "2000",
//						"topP": "1",
//						"fqcP": "0",
//						"prcP": "0",
//						"messages": {
//							"attrs": []
//						},
//						"prompt": "#input",
//						"seed": "",
//						"outlet": {
//							"jaxId": "1I3EQH43J0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I3EQ4O560"
//						},
//						"secret": "false",
//						"allowCheat": "false",
//						"GPTCheats": {
//							"attrs": []
//						},
//						"shareChatName": "",
//						"keepChat": "50 messages",
//						"clearChat": "6 messages",
//						"apiFiles": {
//							"attrs": []
//						},
//						"parallelFunction": "false",
//						"responseFormat": "json_object"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "brunch",
//					"jaxId": "1I3EQ4O560",
//					"attrs": {
//						"id": "SwitchAct",
//						"label": "New AI Seg",
//						"x": "500",
//						"y": "390",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I3EQH43N2",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I3EQH43N3",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I3EQH43K1",
//							"attrs": {
//								"id": "Default",
//								"desc": "输出节点。",
//								"output": ""
//							}
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I3EQH43K0",
//									"attrs": {
//										"id": "Skill",
//										"desc": "Run skill in this bot",
//										"output": "#input",
//										"codes": "true",
//										"context": {
//											"jaxId": "1I3EQH43N4",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I3EQH43N5",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#!!input.skill"
//									},
//									"linkedSeg": "1I3FECJ020"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I5FPLMRR0",
//									"attrs": {
//										"id": "Ask",
//										"desc": "输出节点。",
//										"output": "#input",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I5FPUSQB0",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I5FPUSQB1",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#!!input.ask"
//									},
//									"linkedSeg": "1I5FPO5LP0"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I3EQ567O0",
//									"attrs": {
//										"id": "BotTask",
//										"desc": "Call other bot",
//										"output": "#input",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I3EQH43N8",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I3EQH43N9",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#!!input.bot"
//									},
//									"linkedSeg": "1I3EQJN9E0"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I3EQ7E8N0",
//									"attrs": {
//										"id": "Finish",
//										"desc": "输出节点。",
//										"output": "#input",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I3EQH43N10",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I3EQH43N11",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#!!input.finish"
//									},
//									"linkedSeg": "1I3EQM7E80"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I3EQ7MT20",
//									"attrs": {
//										"id": "Abort",
//										"desc": "输出节点。",
//										"output": "#input",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I3EQH43N12",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I3EQH43N13",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#input.abort"
//									},
//									"linkedSeg": "1I3EQOAOR0"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I3EQ81MS0",
//									"attrs": {
//										"id": "Reply",
//										"desc": "输出节点。",
//										"output": "#input",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I3EQH43N14",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I3EQH43N15",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#!!input.reply"
//									},
//									"linkedSeg": "1I3EQOPT80"
//								}
//							]
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I3FECJ020",
//					"attrs": {
//						"id": "PickSkill",
//						"label": "New AI Seg",
//						"x": "740",
//						"y": "210",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I3FEDCET0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I3FEDCET1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I3FEDCEN0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I3EQI4GG0"
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1I3EQI4GG0",
//					"attrs": {
//						"id": "TipRunSkill",
//						"label": "New AI Seg",
//						"x": "975",
//						"y": "210",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I3EQIK5C2",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I3EQIK5C3",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "Assistant",
//						"text": "#`- Skill: ${context.curSkill.getNameText()}- Prompt: ${input.prompt}`",
//						"outlet": {
//							"jaxId": "1I3EQIK5A1",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I5FHT3860"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I3EQ92PI0",
//					"attrs": {
//						"id": "RunSkill",
//						"label": "New AI Seg",
//						"x": "1420",
//						"y": "195",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I3EQH43N16",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I3EQH43N17",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I3EQH43K2",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I3EQAJ9G0"
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1I3EQAJ9G0",
//					"attrs": {
//						"id": "ShowResult",
//						"label": "New AI Seg",
//						"x": "1650",
//						"y": "195",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I3EQH43N20",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I3EQH43N21",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "Assistant",
//						"text": "#input",
//						"outlet": {
//							"jaxId": "1I3EQH43K4",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I3EQA2HE0"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I3EQA2HE0",
//					"attrs": {
//						"id": "AppendMessage",
//						"label": "New AI Seg",
//						"x": "1885",
//						"y": "195",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I3EQH43N18",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I3EQH43N19",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I3EQH43K3",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I3EQG2N10"
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I3EQG2N10",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "2060",
//						"y": "120",
//						"outlet": {
//							"jaxId": "1I3EQH43N22",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I3EQGA780"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I3EQGA780",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "505",
//						"y": "120",
//						"outlet": {
//							"jaxId": "1I3EQH43N23",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I3EQGFC60"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I3EQGFC60",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "300",
//						"y": "315",
//						"outlet": {
//							"jaxId": "1I3EQH43N24",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I3EQ3FAE0"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1I3EQJN9E0",
//					"attrs": {
//						"id": "TipBotTask",
//						"label": "New AI Seg",
//						"x": "740",
//						"y": "340",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I3EQQH5K2",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I3EQQH5K3",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "Assistant",
//						"text": "#`Task: \n\\`\\`\\`\n${JSON.stringify(input,null,\"\\t\")}\n\\`\\`\\`\n`",
//						"outlet": {
//							"jaxId": "1I3EQQH5H0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I3EQKCNE0"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I3EQKCNE0",
//					"attrs": {
//						"id": "RunBotTask",
//						"label": "New AI Seg",
//						"x": "965",
//						"y": "340",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "flag.svg",
//						"context": {
//							"jaxId": "1I3EQQH5K4",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I3EQQH5K5",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I3EQQH5H1",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							}
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1I3EQM7E80",
//					"attrs": {
//						"id": "TipFinish",
//						"label": "New AI Seg",
//						"x": "740",
//						"y": "405",
//						"desc": "这是一个AISeg。",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "flag.svg",
//						"context": {
//							"jaxId": "1I3EQQH5K6",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I3EQQH5K7",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "Assistant",
//						"text": "#input.result||input.reply",
//						"outlet": {
//							"jaxId": "1I3EQQH5H2",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							}
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1I3EQOAOR0",
//					"attrs": {
//						"id": "TipAbort",
//						"label": "New AI Seg",
//						"x": "740",
//						"y": "465",
//						"desc": "这是一个AISeg。",
//						"codes": "true",
//						"mkpInput": "\"$$input$$\"",
//						"segMark": "flag.svg",
//						"context": {
//							"jaxId": "1I3EQQH5K8",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I3EQQH5K9",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "Assistant",
//						"text": "#`Task aborted, reason: ${input.reason}`",
//						"outlet": {
//							"jaxId": "1I3EQQH5H3",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							}
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1I3EQOPT80",
//					"attrs": {
//						"id": "TipReply",
//						"label": "New AI Seg",
//						"x": "740",
//						"y": "525",
//						"desc": "这是一个AISeg。",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "flag.svg",
//						"context": {
//							"jaxId": "1I3EQQH5K10",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I3EQQH5K11",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "Assistant",
//						"text": "#input.reply",
//						"outlet": {
//							"jaxId": "1I3EQQH5H4",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							}
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "tryCatch",
//					"jaxId": "1I5FHT3860",
//					"attrs": {
//						"id": "WrapSkill",
//						"label": "New AI Seg",
//						"x": "1195",
//						"y": "210",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I5FI4C7U0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I5FI4C7U1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I5FHVOUE0",
//							"attrs": {
//								"id": "Try",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I3EQ92PI0"
//						},
//						"catchlet": {
//							"jaxId": "1I5FHVOUE1",
//							"attrs": {
//								"id": "Catch",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I5FI0D7O0"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1I5FI0D7O0",
//					"attrs": {
//						"id": "ShowError",
//						"label": "New AI Seg",
//						"x": "1420",
//						"y": "265",
//						"desc": "这是一个AISeg。",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "flag.svg",
//						"context": {
//							"jaxId": "1I5FI4C7U4",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I5FI4C7U5",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "Assistant",
//						"text": "#`Skill error: ${input}`",
//						"outlet": {
//							"jaxId": "1I5FI4C7J0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							}
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connectorB",
//					"jaxId": "1I5FI2DV40",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "2140",
//						"y": "215",
//						"outlet": {
//							"jaxId": "1I5FI4C7U7",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I3EQG2N10"
//						},
//						"dir": "B2T"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I5FPO5LP0",
//					"attrs": {
//						"id": "AskUser",
//						"label": "New AI Seg",
//						"x": "740",
//						"y": "275",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "working.svg",
//						"context": {
//							"jaxId": "1I5FPUSQB2",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I5FPUSQB3",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I5FPU3BR0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							}
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connectorL",
//					"jaxId": "1I5FPR1D20",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "1120",
//						"y": "275",
//						"outlet": {
//							"jaxId": "1I5FPUSQB4",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I5FPR6QQ0"
//						},
//						"dir": "L2R"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connectorL",
//					"jaxId": "1I5FPR6QQ0",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "1285",
//						"y": "340",
//						"outlet": {
//							"jaxId": "1I5FPUSQB5",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I5FPRM2U0"
//						},
//						"dir": "L2R"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connectorL",
//					"jaxId": "1I5FPRM2U0",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "2045",
//						"y": "340",
//						"outlet": {
//							"jaxId": "1I5FPUSQB6",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I5FI2DV40"
//						},
//						"dir": "L2R"
//					}
//				}
//			]
//		},
//		"desc": "这是一个AI智能体。",
//		"exportAPI": "true",
//		"exportAddOn": "true",
//		"addOnOpts": ""
//	}
//}