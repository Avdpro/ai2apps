//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import pathLib from "/@path";
import inherits from "/@inherits";
import Base64 from "/@tabos/utils/base64.js";
import {trimJSON} from "/@aichat/utils.js";
/*#{1I236CB1G0MoreImports*/
/*}#1I236CB1G0MoreImports*/
const agentURL=(new URL(import.meta.url)).pathname;
const basePath=pathLib.dirname(agentURL);
const $ln=VFACT.lanCode||"EN";
const argsTemplate={
	properties:{
		"askText":{
			"name":"askText","type":"string",
			"required":true,
			"defaultValue":"",
			"desc":"询问用户的文本",
		},
		"filter":{
			"name":"filter","type":"string",
			"required":false,
			"defaultValue":"",
			"desc":"文件类型，用分号隔开，例如：'*.png;*.jpg'",
		}
	},
	/*#{1I236CB1G0ArgsView*/
	/*}#1I236CB1G0ArgsView*/
};

/*#{1I236CB1G0StartDoc*/
/*}#1I236CB1G0StartDoc*/
//----------------------------------------------------------------------------
let AskFile=async function(session){
	let askText,filter;
	let context,globalContext;
	let self;
	let FixArgs,AskFile,PushFile;
	/*#{1I236CB1G0LocalVals*/
	/*}#1I236CB1G0LocalVals*/
	
	function parseAgentArgs(input){
		if(typeof(input)=='object'){
			askText=input.askText;
			filter=input.filter;
		}else{
			askText=undefined;
			filter=undefined;
		}
		/*#{1I236CB1G0ParseArgs*/
		/*}#1I236CB1G0ParseArgs*/
	}
	
	/*#{1I236CB1G0PreContext*/
	/*}#1I236CB1G0PreContext*/
	globalContext=session.globalContext;
	context={
		fileName: "",
		fileData: "",
		/*#{1I236CB1G5ExCtxAttrs*/
		/*}#1I236CB1G5ExCtxAttrs*/
	};
	context=VFACT.flexState(context);
	/*#{1I236CB1G0PostContext*/
	/*}#1I236CB1G0PostContext*/
	let agent,segs={};
	segs["FixArgs"]=FixArgs=async function(input){//:1I2478V6S0
		let result=input;
		let missing=false;
		if(askText===undefined || askText==="") missing=true;
		if(missing){
			result=await session.pipeChat("/@aichat/ai/CompleteArgs.js",{"argsTemplate":argsTemplate,"command":input},false);
			parseAgentArgs(result);
		}
		return {seg:AskFile,result:(result),preSeg:"1I2478V6S0",outlet:"1I247941A0"};
	};
	FixArgs.jaxId="1I2478V6S0"
	FixArgs.url="FixArgs@"+agentURL
	
	segs["AskFile"]=AskFile=async function(input){//:1I236L4BM0
		let prompt=(askText)||input;
		let resultText="";
		let fileData=null;
		let enc=null;
		let ext=null;
		let fileSys="native";
		let result="";
		let path=("/doc");
		let filter=("");
		/*#{1I236L4BM0PreCodes*/
		/*}#1I236L4BM0PreCodes*/
		[resultText,result]=await session.askUserRaw({type:"input",prompt:prompt,text:"",path:path,file:fileSys,filter:filter,});
		fileData=result||(await (await fetch(resultText)).arrayBuffer());
		result=Base64.encode(fileData);
		/*#{1I236L4BM0PostCodes*/
		context.fileName=resultText;
		context.fileData=result;
		/*}#1I236L4BM0PostCodes*/
		return {seg:PushFile,result:(result),preSeg:"1I236L4BM0",outlet:"1I236LCIU0"};
	};
	AskFile.jaxId="1I236L4BM0"
	AskFile.url="AskFile@"+agentURL
	
	segs["PushFile"]=PushFile=async function(input){//:1I236OJL60
		let result=input
		/*#{1I236OJL60Code*/
		let resLib,name,cnt,ext2name,basename;
		resLib=globalContext.exechangeRes;
		if(!resLib){
			resLib=globalContext.exechangeRes={};
		}
		name=context.fileName;
		name=name.replace(/\s+/g, '_');
		ext2name=pathLib.ext2name(name)||pathLib.extname();
		basename=name.substring(0,name.length-ext2name.length);
		cnt=0;
		while(resLib.name){
			cnt+=1;
			name=basename+cnt+ext2name;
		}
		resLib[name]=context.fileData;
		result=`用户选择文件的资源路径是: res://${name}`;
		/*}#1I236OJL60Code*/
		return {result:result};
	};
	PushFile.jaxId="1I236OJL60"
	PushFile.url="PushFile@"+agentURL
	
	agent={
		isAIAgent:true,
		session:session,
		name:"AskFile",
		url:agentURL,
		autoStart:true,
		jaxId:"1I236CB1G0",
		context:context,
		livingSeg:null,
		execChat:async function(input/*{askText,filter}*/){
			let result;
			parseAgentArgs(input);
			/*#{1I236CB1G0PreEntry*/
			/*}#1I236CB1G0PreEntry*/
			result={seg:FixArgs,"input":input};
			/*#{1I236CB1G0PostEntry*/
			/*}#1I236CB1G0PostEntry*/
			return result;
		},
		/*#{1I236CB1G0MoreAgentAttrs*/
		/*}#1I236CB1G0MoreAgentAttrs*/
	};
	/*#{1I236CB1G0PostAgent*/
	/*}#1I236CB1G0PostAgent*/
	return agent;
};
/*#{1I236CB1G0ExCodes*/
/*}#1I236CB1G0ExCodes*/

export const ChatAPI=[{
	def:{
		name: "AskFile",
		description: "arguments: {askText}, {filter}\nThis is a agent that ask user select a file with {filter} extname. It will show {askText} to user while asking.",
		parameters:{
			type: "object",
			properties:{
				askText:{type:"string",description:"询问用户的文本"},
				filter:{type:"string",description:"文件类型，用分号隔开，例如：'*.png;*.jpg'"}
			}
		}
	},
	agent: AskFile
}];

//:Export Edit-AddOn:
const DocAIAgentExporter=VFACT.classRegs.DocAIAgentExporter;
if(DocAIAgentExporter){
	const EditAttr=VFACT.classRegs.EditAttr;
	const EditAISeg=VFACT.classRegs.EditAISeg;
	const EditAISegOutlet=VFACT.classRegs.EditAISegOutlet;
	const SegObjShellAttr=EditAISeg.SegObjShellAttr;
	const SegOutletDef=EditAISegOutlet.SegOutletDef;
	const docAIAgentExporter=DocAIAgentExporter.prototype;
	const packExtraCodes=docAIAgentExporter.packExtraCodes;
	const packResult=docAIAgentExporter.packResult;
	const varNameRegex = /^[a-zA-Z_$][a-zA-Z0-9_$]*$/;
	
	EditAISeg.regDef({
		name:"AskFile",showName:"AskFile",icon:"agent.svg",catalog:["AI Call"],
		attrs:{
			...SegObjShellAttr,
			"askText":{name:"askText",type:"string",key:1,fixed:1,initVal:""},
			"filter":{name:"filter",type:"string",key:1,fixed:1,initVal:""},
			"outlet":{name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc"}
		},
		listHint:["id","askText","filter","codes","desc"],
		desc:"arguments: {askText}, {filter}\nThis is a agent that ask user select a file with {filter} extname. It will show {askText} to user while asking."
	});
	
	DocAIAgentExporter.segTypeExporters["AskFile"]=
	function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let exportDebug=this.isExportDebug();
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();coder.newLine();
		{
			coder.packText(`let result,args={};`);coder.newLine();
			coder.packText("args['askText']=");this.genAttrStatement(seg.getAttr("askText"));coder.packText(";");coder.newLine();
			coder.packText("args['filter']=");this.genAttrStatement(seg.getAttr("filter"));coder.packText(";");coder.newLine();
			this.packExtraCodes(coder,seg,"PreCodes");
			coder.packText(`result= await session.pipeChat("/~/aae/ai/AskFile.js",args,false);`);coder.newLine();
			this.packExtraCodes(coder,seg,"PostCodes");
			this.packResult(coder,seg,seg.outlet);
		}
		coder.indentLess();coder.maybeNewLine();
		coder.packText(`};`);coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		coder.newLine();
	};
}
/*#{1I236CB1G0PostDoc*/
/*}#1I236CB1G0PostDoc*/


export default AskFile;
export{AskFile};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DocAIAgent",
//	"jaxId": "1I236CB1G0",
//	"attrs": {
//		"editObjs": {
//			"jaxId": "1I236CB1G1",
//			"attrs": {
//				"AskFile": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1I236CB1G7",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1I236CB1H0",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1I236CB1H1",
//							"attrs": {}
//						},
//						"functions": {
//							"jaxId": "1I236CB1H2",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false"
//					},
//					"mockups": {}
//				}
//			}
//		},
//		"agent": {
//			"jaxId": "1I236CB1G2",
//			"attrs": {}
//		},
//		"entry": "FixArgs",
//		"autoStart": "true",
//		"debug": "true",
//		"apiArgs": {
//			"jaxId": "1I236CB1G3",
//			"attrs": {
//				"askText": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I236KKCQ0",
//					"attrs": {
//						"type": "String",
//						"mockup": "\"\"",
//						"desc": "询问用户的文本",
//						"required": "true"
//					}
//				},
//				"filter": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I2381LBL0",
//					"attrs": {
//						"type": "String",
//						"mockup": "\"\"",
//						"desc": "文件类型，用分号隔开，例如：'*.png;*.jpg'",
//						"required": "false"
//					}
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1I236CB1G4",
//			"attrs": {}
//		},
//		"context": {
//			"jaxId": "1I236CB1G5",
//			"attrs": {
//				"fileName": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I236VHF80",
//					"attrs": {
//						"type": "String",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				},
//				"fileData": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I236VHF81",
//					"attrs": {
//						"type": "String",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				}
//			}
//		},
//		"globalMockup": {
//			"jaxId": "1I236CB1G6",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "aiseg",
//					"def": "fixArgs",
//					"jaxId": "1I2478V6S0",
//					"attrs": {
//						"id": "FixArgs",
//						"label": "New AI Seg",
//						"x": "110",
//						"y": "165",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"outlet": {
//							"jaxId": "1I247941A0",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I236L4BM0"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "askFile",
//					"jaxId": "1I236L4BM0",
//					"attrs": {
//						"id": "AskFile",
//						"label": "New AI Seg",
//						"x": "320",
//						"y": "165",
//						"desc": "这是一个AISeg。",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I236LCIV0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I236LCIV1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"prompt": "#askText",
//						"path": "/doc",
//						"fileSys": "naive",
//						"filter": "",
//						"read": "Base64",
//						"outlet": {
//							"jaxId": "1I236LCIU0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I236OJL60"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I236OJL60",
//					"attrs": {
//						"id": "PushFile",
//						"label": "New AI Seg",
//						"x": "530",
//						"y": "165",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I236RE3B4",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I236RE3B5",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I236RE380",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							}
//						},
//						"result": "#input"
//					}
//				}
//			]
//		},
//		"desc": "arguments: {askText}, {filter}\nThis is a agent that ask user select a file with {filter} extname. It will show {askText} to user while asking.",
//		"exportAPI": "true",
//		"exportAddOn": "true",
//		"addOnOpts": ""
//	}
//}