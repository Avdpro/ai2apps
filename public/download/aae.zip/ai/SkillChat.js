//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import pathLib from "/@path";
import inherits from "/@inherits";
import Base64 from "/@tabos/utils/base64.js";
import {trimJSON} from "/@aichat/utils.js";
/*#{1I1L1U8U20MoreImports*/
import {tabFS} from "/@tabos";
import {AASkills} from "/@aae/AASkills.js";
/*}#1I1L1U8U20MoreImports*/
const agentURL=(new URL(import.meta.url)).pathname;
const basePath=pathLib.dirname(agentURL);
const $ln=VFACT.lanCode||"EN";
const argsTemplate={
	properties:{
		"command":{
			"name":"command","type":"string",
			"defaultValue":"",
			"desc":"Command to execute",
		}
	},
	/*#{1I1L1U8U20ArgsView*/
	/*}#1I1L1U8U20ArgsView*/
};

/*#{1I1L1U8U20StartDoc*/
let topWindow;
topWindow=window;
while(topWindow && topWindow.parent && topWindow.parent!==topWindow){
	topWindow=topWindow.parent;
}
const topVFACT=topWindow.VFACT;
let tempDirPath;
//----------------------------------------------------------------------------
async function setupTempDir(glbCtx){
	let baseName,dirPath,cnt;
	if(!glbCtx.exechangeRes){
		glbCtx.exechangeRes={};
	}
	if(glbCtx.tempDirPath){
		tempDirPath=glbCtx.tempDirPath;
		return;
	}
	cnt=0;
	dirPath=baseName="/doc/Temp/TEMP_"+Date.now();
	do{
		if(!(await tabFS.isExist(dirPath))){
			break;
		}
		cnt+=1;
		dirPath=baseName+cnt;
	}while(1);
	await tabFS.newDir(dirPath);
	glbCtx.tempDirPath=tempDirPath=dirPath;
	return dirPath;
};
async function clearTempDir(path){
	path=path||tempDirPath;
	try{
		await tabFS.del(path);
	}catch(err){
	}
};
/*}#1I1L1U8U20StartDoc*/
//----------------------------------------------------------------------------
let SkillChat=async function(session){
	let command;
	let context,globalContext;
	let self;
	let BuildSkillsIndex,ChooseSkill,CheckSkill,PickSkill,ShowSkill,RunSkill,ShowSkillResult,appendMessage,ShowResult,ShowReply,ShowAbort,ShowFinish,ShowMissing,AskCreate,CallSkill,LogError,StartTip,ResetMsg,AskNewCmd,CreeateSkill,ReloadSkills,NextMenu,AskMore,ExitChat;
	/*#{1I1L1U8U20LocalVals*/
	/*}#1I1L1U8U20LocalVals*/
	
	function parseAgentArgs(input){
		if(typeof(input)=='object'){
			command=input.command;
		}else{
			command=undefined;
		}
		/*#{1I1L1U8U20ParseArgs*/
		/*}#1I1L1U8U20ParseArgs*/
	}
	
	/*#{1I1L1U8U20PreContext*/
	/*}#1I1L1U8U20PreContext*/
	globalContext=session.globalContext;
	context={
		aaSkills: "",
		skillsIndexVO: {"a":"b"},
		curSkill: null,
		taskRound: 0,
		/*#{1I1L1U8U25ExCtxAttrs*/
		/*}#1I1L1U8U25ExCtxAttrs*/
	};
	context=VFACT.flexState(context);
	/*#{1I1L1U8U20PostContext*/
	await setupTempDir(globalContext);
	/*}#1I1L1U8U20PostContext*/
	let agent,segs={};
	segs["BuildSkillsIndex"]=BuildSkillsIndex=async function(input){//:1I1L1UN1D0
		let result=input
		/*#{1I1L1UN1D0Code*/
		let skills,saveVO;
		skills=context.aaSkills=new AASkills();
		//Try read /doc/SkillIndex.json first:
		try{
			saveVO=await (await fetch("/~/doc/SkillIndex.json")).json();
		}catch(err){
			saveVO=await (await fetch("/@aae/ai/SkillIndex.json")).json();
		}
		await skills.loadFromVO(saveVO);
		context.skillsIndexVO=skills.getSkillDescIndex();
		console.log(context.skillsIndexVO);
		result=command;
		/*}#1I1L1UN1D0Code*/
		return {seg:StartTip,result:(result),preSeg:"1I1L1UN1D0",outlet:"1I1L26LKH0"};
	};
	BuildSkillsIndex.jaxId="1I1L1UN1D0"
	BuildSkillsIndex.url="BuildSkillsIndex@"+agentURL
	
	segs["ChooseSkill"]=ChooseSkill=async function(input){//:1I1L2072D0
		let prompt;
		let result;
		
		let opts={
			platform:globalContext.LLMP_MAX||"OpenAI",
			mode:globalContext.LLMM_Logic||"gpt-4o",
			maxToken:2000,
			temperature:0,
			topP:1,
			fqcP:0,
			prcP:0,
			secret:false,
			responseFormat:"json_object"
		};
		let chatMem=ChooseSkill.messages
		let seed="";
		if(seed!==undefined){opts.seed=seed;}
		let messages=[
			{role:"system",content:`
你是一个根据用户输入，选择适合的Skill或智能体运行，与用户对话，完成任务的AI。
当前的SKill/智能体有：
${JSON.stringify(context.skillsIndexVO,null,"\t")}
- 第一轮对话时，用户输入的是要完成的任务，你根据用户的输入，选择合适的Skill

- 每一回合对话，跟根据当前任务执行的情况，回复一个JSON对象。如果需要执行一个Skill，回复JSON中的"skill"属性是下一步要执行的SKill或智能体的名称; 回复JSON中的prompt属性是调用这个Skill的输入指令。例如：
{
	"skill":"Skill-3",
    "prompt":"Search for: Who is the winner of 2024 F1?"
}

- 执行Skill的结果会在对话中告知，你根据任务目标以及Skill的执行情况，选择新的Skill。

- 如果成功的完成了用户提出的任务，回复将JSON中的"finish"属性设置为true。并通过"result"属性总结汇报执行情况。例如
{
	"finish":true,
    "result":"论坛帖子已经成功发布。"
}

- 如果执行Skill出现错误，你认为无法完成用户的任务，设置回复JSON中的"abort"属性为true，并在"reason"属性中说明原因。例如:
{
	"abort":true,
    "reason":"没有登录脸书账号，无法发布新的内容。"
}

- 如果没有Skill可以完成用户的要求，请设计一个或多个用来完成用户需求的Skill，在回复JSON中用"missingSkills"数组属性里描述缺失的Skill。例如：
{
	"missingSkills":[
    	"检查脸书账号登录状态",
        "发布脸书动态"
    ]
}

- 如果回答用户的输入不需要使用任何skill，用回复JSON中的"replay"属性回答用户，如果对话已结束，同时设置"finish"属性为true。例如：当用户询问："西瓜是一种水果么？"，你的回复：
{
	"finish":true,
	"reply":"是的，西瓜是一种水果。"
}
`
},
		];
		messages.push(...chatMem);
		prompt=input;
		if(prompt!==null){
			messages.push({role:"user",content:prompt});
		}
		result=await session.callSegLLM("ChooseSkill@"+agentURL,opts,messages,true);
		chatMem.push({role:"user",content:prompt});
		chatMem.push({role:"assistant",content:result});
		if(chatMem.length>50){
			let removedMsgs=chatMem.splice(0,2);
		}
		result=trimJSON(result);
		return {seg:CheckSkill,result:(result),preSeg:"1I1L2072D0",outlet:"1I1L26LKI0"};
	};
	ChooseSkill.jaxId="1I1L2072D0"
	ChooseSkill.url="ChooseSkill@"+agentURL
	ChooseSkill.messages=[];
	
	segs["CheckSkill"]=CheckSkill=async function(input){//:1I1L20SLD0
		let result=input;
		/*#{1I1L20SLD0Start*/
		console.log("Choose Skill:");
		console.log(input);
		/*}#1I1L20SLD0Start*/
		if(input.missingSkills){
			return {seg:ShowMissing,result:(input),preSeg:"1I1L20SLD0",outlet:"1I1L4HCRJ0"};
		}
		if(input.skill){
			let output=input;
			return {seg:CallSkill,result:(output),preSeg:"1I1L20SLD0",outlet:"1I1L26LKI1"};
		}
		if(input.finish&&input.result){
			let output=input.result;
			return {seg:ShowFinish,result:(output),preSeg:"1I1L20SLD0",outlet:"1I1L4HMHK0"};
		}
		if(input.abort){
			let output=input.reason;
			return {seg:ShowAbort,result:(output),preSeg:"1I1L20SLD0",outlet:"1I1L4HSMS0"};
		}
		if(input.reply){
			let output=input.reply;
			return {seg:ShowReply,result:(output),preSeg:"1I1L20SLD0",outlet:"1I1L4IO2S0"};
		}
		/*#{1I1L20SLD0Post*/
		/*}#1I1L20SLD0Post*/
		return {seg:ShowResult,result:(result),preSeg:"1I1L20SLD0",outlet:"1I1L26LKJ0"};
	};
	CheckSkill.jaxId="1I1L20SLD0"
	CheckSkill.url="CheckSkill@"+agentURL
	
	segs["PickSkill"]=PickSkill=async function(input){//:1I1L2433G0
		let result=input
		/*#{1I1L2433G0Code*/
		let skillId=input.skill;
		skillId=parseInt(skillId.substring(6));
		context.curSkill=context.aaSkills.getSkills()[skillId];
		console.log(result);
		/*}#1I1L2433G0Code*/
		return {seg:ShowSkill,result:(result),preSeg:"1I1L2433G0",outlet:"1I1L26LKJ1"};
	};
	PickSkill.jaxId="1I1L2433G0"
	PickSkill.url="PickSkill@"+agentURL
	
	segs["ShowSkill"]=ShowSkill=async function(input){//:1I1QH2J920
		let result=input;
		let role="assistant";
		let content=`- Skill: ${context.curSkill.getNameText()}
- Prompt: ${input.prompt}
`;
		session.addChatText(role,content);
		return {seg:RunSkill,result:(result),preSeg:"1I1QH2J920",outlet:"1I1QH48FB0"};
	};
	ShowSkill.jaxId="1I1QH2J920"
	ShowSkill.url="ShowSkill@"+agentURL
	
	segs["RunSkill"]=RunSkill=async function(input){//:1I1N74RVL0
		let result=input
		/*#{1I1N74RVL0Code*/
		let skill=context.curSkill;
		result=await context.aaSkills.execSkill(topVFACT.app,skill,input.prompt?JSON.stringify(input.prompt):"",session);
		/*}#1I1N74RVL0Code*/
		return {seg:ShowSkillResult,result:(result),preSeg:"1I1N74RVL0",outlet:"1I1N75UQ20"};
	};
	RunSkill.jaxId="1I1N74RVL0"
	RunSkill.url="RunSkill@"+agentURL
	
	segs["ShowSkillResult"]=ShowSkillResult=async function(input){//:1I1N7NL9G0
		let result=input;
		let role="system";
		let content=input;
		session.addChatText(role,content);
		return {seg:appendMessage,result:(result),preSeg:"1I1N7NL9G0",outlet:"1I1N7RO010"};
	};
	ShowSkillResult.jaxId="1I1N7NL9G0"
	ShowSkillResult.url="ShowSkillResult@"+agentURL
	
	segs["appendMessage"]=appendMessage=async function(input){//:1I1N876690
		let result=input
		/*#{1I1N876690Code*/
		result=`Run skill result: ${JSON.stringify(input,null,"\t")}`;
		/*}#1I1N876690Code*/
		return {seg:ChooseSkill,result:(result),preSeg:"1I1N876690",outlet:"1I1N88PH50"};
	};
	appendMessage.jaxId="1I1N876690"
	appendMessage.url="appendMessage@"+agentURL
	
	segs["ShowResult"]=ShowResult=async function(input){//:1I1L24UDT0
		let result=input;
		let role="assistant";
		let content=input;
		session.addChatText(role,content);
		return {seg:ChooseSkill,result:(result),preSeg:"1I1L24UDT0",outlet:"1I1L26LKJ2"};
	};
	ShowResult.jaxId="1I1L24UDT0"
	ShowResult.url="ShowResult@"+agentURL
	
	segs["ShowReply"]=ShowReply=async function(input){//:1I1L4IVOP0
		let result=input;
		let role="assistant";
		let content=input;
		session.addChatText(role,content);
		return {seg:NextMenu,result:(result),preSeg:"1I1L4IVOP0",outlet:"1I1L51Q1G0"};
	};
	ShowReply.jaxId="1I1L4IVOP0"
	ShowReply.url="ShowReply@"+agentURL
	
	segs["ShowAbort"]=ShowAbort=async function(input){//:1I1L4JP9K0
		let result=input;
		let role="assistant";
		let content=input;
		session.addChatText(role,content);
		return {seg:NextMenu,result:(result),preSeg:"1I1L4JP9K0",outlet:"1I1L51Q1G1"};
	};
	ShowAbort.jaxId="1I1L4JP9K0"
	ShowAbort.url="ShowAbort@"+agentURL
	
	segs["ShowFinish"]=ShowFinish=async function(input){//:1I1L4K6GU0
		let result=input;
		let role="assistant";
		let content=input;
		session.addChatText(role,content);
		return {seg:NextMenu,result:(result),preSeg:"1I1L4K6GU0",outlet:"1I1L51Q1G2"};
	};
	ShowFinish.jaxId="1I1L4K6GU0"
	ShowFinish.url="ShowFinish@"+agentURL
	
	segs["ShowMissing"]=ShowMissing=async function(input){//:1I1L4N5OQ0
		let result=input;
		let role="assistant";
		let content=input;
		session.addChatText(role,content);
		return {seg:AskCreate,result:(result),preSeg:"1I1L4N5OQ0",outlet:"1I1L51Q1G3"};
	};
	ShowMissing.jaxId="1I1L4N5OQ0"
	ShowMissing.url="ShowMissing@"+agentURL
	
	segs["AskCreate"]=AskCreate=async function(input){//:1I1L4NP3H0
		let prompt=("Please confirm")||input;
		let silent=false;
		let countdown=undefined;
		let button1=("Abort")||"OK";
		let button2=("Create")||"Cancel";
		let button3="";
		let result="";
		let value=0;
		if(silent){
			result="";
			/*#{1I1L4NP3A2Silent*/
			/*}#1I1L4NP3A2Silent*/
			return {seg:ChooseSkill,result:(result),preSeg:"1I1L4NP3H0",outlet:"1I1L4NP3A2"};
		}
		[result,value]=await session.askUserRaw({type:"confirm",prompt:prompt,button1:button1,button2:button2,button3:button3,countdown:countdown});
		if(value===1){
			result=("")||result;
			/*#{1I1L4NP3A2Btn1*/
			ChooseSkill.messages.splice(0);
			/*}#1I1L4NP3A2Btn1*/
			return {seg:ChooseSkill,result:(result),preSeg:"1I1L4NP3H0",outlet:"1I1L4NP3A2"};
		}
		result=("")||result;
		return {seg:CreeateSkill,result:(result),preSeg:"1I1L4NP3H0",outlet:"1I1L4NP3A0"};
	
	};
	AskCreate.jaxId="1I1L4NP3H0"
	AskCreate.url="AskCreate@"+agentURL
	
	segs["CallSkill"]=CallSkill=async function(input){//:1I1L5B9VP0
		let result=input;
		/*#{1I1L5B9VP0Code*/
		false
		/*}#1I1L5B9VP0Code*/
		return {seg:PickSkill,result:(result),preSeg:"1I1L5B9VP0",outlet:"1I1L5DNUF0",catchSeg:LogError,catchlet:"1I1L5DNUF1"};
	};
	CallSkill.jaxId="1I1L5B9VP0"
	CallSkill.url="CallSkill@"+agentURL
	
	segs["LogError"]=LogError=async function(input){//:1I1L5CSLR0
		let result=input
		/*#{1I1L5CSLR0Code*/
		/*}#1I1L5CSLR0Code*/
		return {seg:ChooseSkill,result:(result),preSeg:"1I1L5CSLR0",outlet:"1I1L5DNUF2"};
	};
	LogError.jaxId="1I1L5CSLR0"
	LogError.url="LogError@"+agentURL
	
	segs["StartTip"]=StartTip=async function(input){//:1I1M9GPHP0
		let result=input;
		let role="user";
		let content=`${command}`;
		session.addChatText(role,content);
		return {seg:ChooseSkill,result:(result),preSeg:"1I1M9GPHP0",outlet:"1I1M9HO1M0"};
	};
	StartTip.jaxId="1I1M9GPHP0"
	StartTip.url="StartTip@"+agentURL
	
	segs["ResetMsg"]=ResetMsg=async function(input){//:1I1N8JRGV0
		let result=input
		/*#{1I1N8JRGV0Code*/
		let messages,endMessage;
		messages=ChooseSkill.messages;
		//Clear chat messages:
		context.taskRound+=1;
		messages.splice(context.taskRound*2+1);
		/*}#1I1N8JRGV0Code*/
		return {seg:AskNewCmd,result:(result),preSeg:"1I1N8JRGV0",outlet:"1I1N8OS6J0"};
	};
	ResetMsg.jaxId="1I1N8JRGV0"
	ResetMsg.url="ResetMsg@"+agentURL
	
	segs["AskNewCmd"]=AskNewCmd=async function(input){//:1I1N8NG750
		let tip=("有什么新的指示么？");
		let tipRole=("assistant");
		let placeholder=("");
		let text=("");
		let result="";
		/*#{1I1N8NG750PreCodes*/
		/*}#1I1N8NG750PreCodes*/
		if(tip){
			session.addChatText(tipRole,tip);
		}
		result=await session.askChatInput({type:"input",placeholder:placeholder,text:text});
		session.addChatText("user",result);
		/*#{1I1N8NG750PostCodes*/
		command=result;
		/*}#1I1N8NG750PostCodes*/
		return {seg:ChooseSkill,result:(result),preSeg:"1I1N8NG750",outlet:"1I1N8OS6J1"};
	};
	AskNewCmd.jaxId="1I1N8NG750"
	AskNewCmd.url="AskNewCmd@"+agentURL
	
	segs["CreeateSkill"]=CreeateSkill=async function(input){//:1I1N9J5G70
		let result;
		let sourcePath=pathLib.joinTabOSURL(basePath,"");
		let arg={};
		result= await session.pipeChat(sourcePath,arg,false);
		return {seg:ReloadSkills,result:(result),preSeg:"1I1N9J5G70",outlet:"1I1N9KMMV0"};
	};
	CreeateSkill.jaxId="1I1N9J5G70"
	CreeateSkill.url="CreeateSkill@"+agentURL
	
	segs["ReloadSkills"]=ReloadSkills=async function(input){//:1I1N9QI710
		let result=input
		/*#{1I1N9QI710Code*/
		let skills=context.aaSkills;
		let saveVO=await (await fetch("/@aae/ai/SkillIndex.json")).json();
		await skills.loadFromVO(saveVO);
		context.skillsIndexVO=skills.getSkillDescIndex();
		console.log(context.skillsIndexVO);
		result="New skill has been created. Skills updated.";
		/*}#1I1N9QI710Code*/
		return {seg:ChooseSkill,result:(result),preSeg:"1I1N9QI710",outlet:"1I1N9S0AV0"};
	};
	ReloadSkills.jaxId="1I1N9QI710"
	ReloadSkills.url="ReloadSkills@"+agentURL
	
	segs["NextMenu"]=NextMenu=async function(input){//:1I1SF3OGA0
		let prompt=("Please confirm")||input;
		let countdown=undefined;
		let silent=false;
		let items=[
			{icon:"/~/-tabos/shared/assets/hudbox.svg",text:"执行新的任务",code:0},
			{icon:"/~/-tabos/shared/assets/hudbox.svg",text:(($ln==="CN")?("继续当前任务"):("Continue current task")),code:1},
			{icon:"/~/-tabos/shared/assets/hudbox.svg",text:(($ln==="CN")?("退出对话"):("Exit conversation")),code:2},
		];
		let result="";
		let item=null;
		
		if(silent){
			result="";
			return {seg:ResetMsg,result:(result),preSeg:"1I1SF3OGA0",outlet:"1I1SF3OFR0"};
		}
		[result,item]=await session.askUserRaw({type:"menu",prompt:prompt,multiSelect:false,items:items,withChat:false,countdown:countdown});
		if(item.code===0){
			return {seg:ResetMsg,result:(result),preSeg:"1I1SF3OGA0",outlet:"1I1SF3OFR0"};
		}
		if(item.code===1){
			return {seg:AskMore,result:(result),preSeg:"1I1SF3OGA0",outlet:"1I1SF3OFR1"};
		}
		if(item.code===2){
			return {seg:ExitChat,result:(result),preSeg:"1I1SF3OGA0",outlet:"1I1SF3OFR2"};
		}
	};
	NextMenu.jaxId="1I1SF3OGA0"
	NextMenu.url="NextMenu@"+agentURL
	
	segs["AskMore"]=AskMore=async function(input){//:1I1SFAGFA0
		let tip=((($ln==="CN")?("请给出指示"):("Please give instructions")));
		let tipRole=("assistant");
		let placeholder=("");
		let text=("");
		let result="";
		if(tip){
			session.addChatText(tipRole,tip);
		}
		result=await session.askChatInput({type:"input",placeholder:placeholder,text:text});
		session.addChatText("user",result);
		return {seg:ChooseSkill,result:(result),preSeg:"1I1SFAGFA0",outlet:"1I1SFCVN70"};
	};
	AskMore.jaxId="1I1SFAGFA0"
	AskMore.url="AskMore@"+agentURL
	
	segs["ExitChat"]=ExitChat=async function(input){//:1I1SFCDUK0
		let result=input
		/*#{1I1SFCDUK0Code*/
		let app=VFACT.app;
		if(app && app.closeApp){
			app.closeApp();
		}
		/*}#1I1SFCDUK0Code*/
		return {result:result};
	};
	ExitChat.jaxId="1I1SFCDUK0"
	ExitChat.url="ExitChat@"+agentURL
	
	agent={
		isAIAgent:true,
		session:session,
		name:"SkillChat",
		url:agentURL,
		autoStart:true,
		jaxId:"1I1L1U8U20",
		context:context,
		livingSeg:null,
		execChat:async function(input/*{command}*/){
			let result;
			parseAgentArgs(input);
			/*#{1I1L1U8U20PreEntry*/
			if(typeof(input)==="string"){
				command=input;
			}
			/*}#1I1L1U8U20PreEntry*/
			result={seg:BuildSkillsIndex,"input":input};
			/*#{1I1L1U8U20PostEntry*/
			/*}#1I1L1U8U20PostEntry*/
			return result;
		},
		/*#{1I1L1U8U20MoreAgentAttrs*/
		/*}#1I1L1U8U20MoreAgentAttrs*/
	};
	/*#{1I1L1U8U20PostAgent*/
	/*}#1I1L1U8U20PostAgent*/
	return agent;
};
/*#{1I1L1U8U20ExCodes*/
/*}#1I1L1U8U20ExCodes*/

export const ChatAPI=[{
	def:{
		name: "SkillChat",
		description: "这是一个AI代理。",
		parameters:{
			type: "object",
			properties:{
				command:{type:"string",description:"Command to execute"}
			}
		}
	},
	agent: SkillChat
}];

//:Export Edit-AddOn:
const DocAIAgentExporter=VFACT.classRegs.DocAIAgentExporter;
if(DocAIAgentExporter){
	const EditAttr=VFACT.classRegs.EditAttr;
	const EditAISeg=VFACT.classRegs.EditAISeg;
	const EditAISegOutlet=VFACT.classRegs.EditAISegOutlet;
	const SegObjShellAttr=EditAISeg.SegObjShellAttr;
	const SegOutletDef=EditAISegOutlet.SegOutletDef;
	const docAIAgentExporter=DocAIAgentExporter.prototype;
	const packExtraCodes=docAIAgentExporter.packExtraCodes;
	const packResult=docAIAgentExporter.packResult;
	const varNameRegex = /^[a-zA-Z_$][a-zA-Z0-9_$]*$/;
	
	EditAISeg.regDef({
		name:"SkillChat",showName:"SkillChat",icon:"agent.svg",catalog:["AI Call"],
		attrs:{
			...SegObjShellAttr,
			"command":{name:"command",type:"string",key:1,fixed:1,initVal:""},
			"outlet":{name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc"}
		},
		listHint:["id","command","codes","desc"],
		desc:"这是一个AI代理。"
	});
	
	DocAIAgentExporter.segTypeExporters["SkillChat"]=
	function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let exportDebug=this.isExportDebug();
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();coder.newLine();
		{
			coder.packText(`let result,args={};`);coder.newLine();
			coder.packText("args['command']=");this.genAttrStatement(seg.getAttr("command"));coder.packText(";");coder.newLine();
			this.packExtraCodes(coder,seg,"PreCodes");
			coder.packText(`result= await session.pipeChat("/~/aae/ai/SkillChat.js",args,false);`);coder.newLine();
			this.packExtraCodes(coder,seg,"PostCodes");
			this.packResult(coder,seg,seg.outlet);
		}
		coder.indentLess();coder.maybeNewLine();
		coder.packText(`};`);coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		coder.newLine();
	};
}
/*#{1I1L1U8U20PostDoc*/
/*}#1I1L1U8U20PostDoc*/


export default SkillChat;
export{SkillChat};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DocAIAgent",
//	"jaxId": "1I1L1U8U20",
//	"attrs": {
//		"editObjs": {
//			"jaxId": "1I1L1U8U21",
//			"attrs": {
//				"SkillChat": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1I1L1U8U27",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1I1L1U8U28",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1I1L1U8U29",
//							"attrs": {}
//						},
//						"functions": {
//							"jaxId": "1I1L1U8U210",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false"
//					},
//					"mockups": {}
//				}
//			}
//		},
//		"agent": {
//			"jaxId": "1I1L1U8U22",
//			"attrs": {}
//		},
//		"entry": "BuildSkillsIndex",
//		"autoStart": "true",
//		"debug": "true",
//		"apiArgs": {
//			"jaxId": "1I1L1U8U23",
//			"attrs": {
//				"command": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I1L867JC0",
//					"attrs": {
//						"type": "String",
//						"mockup": "\"\"",
//						"desc": "Command to execute"
//					}
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1I1L1U8U24",
//			"attrs": {}
//		},
//		"context": {
//			"jaxId": "1I1L1U8U25",
//			"attrs": {
//				"aaSkills": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I1L88I310",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				},
//				"skillsIndexVO": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I1L2LV9Q0",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "{\"a\":\"b\"}",
//						"desc": ""
//					}
//				},
//				"curSkill": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I1MGVHE10",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "null",
//						"desc": ""
//					}
//				},
//				"taskRound": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I1SHDI1V0",
//					"attrs": {
//						"type": "Integer",
//						"mockup": "0",
//						"desc": ""
//					}
//				}
//			}
//		},
//		"globalMockup": {
//			"jaxId": "1I1L1U8U26",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I1L1UN1D0",
//					"attrs": {
//						"id": "BuildSkillsIndex",
//						"label": "New AI Seg",
//						"x": "95",
//						"y": "380",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I1L26LKM0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1L26LKM1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I1L26LKH0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1M9GPHP0"
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "callLLM",
//					"jaxId": "1I1L2072D0",
//					"attrs": {
//						"id": "ChooseSkill",
//						"label": "New AI Seg",
//						"x": "610",
//						"y": "380",
//						"desc": "执行一次LLM调用。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "faces.svg",
//						"context": {
//							"jaxId": "1I1L26LKM2",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1L26LKM3",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"platform": "#globalContext.LLMP_MAX||\"OpenAI\"",
//						"mode": "#globalContext.LLMM_Logic||\"gpt-4o\"",
//						"system": "#`\n你是一个根据用户输入，选择适合的Skill或智能体运行，与用户对话，完成任务的AI。\n当前的SKill/智能体有：\n${JSON.stringify(context.skillsIndexVO,null,\"\\t\")}\n- 第一轮对话时，用户输入的是要完成的任务，你根据用户的输入，选择合适的Skill\n\n- 每一回合对话，跟根据当前任务执行的情况，回复一个JSON对象。如果需要执行一个Skill，回复JSON中的\"skill\"属性是下一步要执行的SKill或智能体的名称; 回复JSON中的prompt属性是调用这个Skill的输入指令。例如：\n{\n\t\"skill\":\"Skill-3\",\n    \"prompt\":\"Search for: Who is the winner of 2024 F1?\"\n}\n\n- 执行Skill的结果会在对话中告知，你根据任务目标以及Skill的执行情况，选择新的Skill。\n\n- 如果成功的完成了用户提出的任务，回复将JSON中的\"finish\"属性设置为true。并通过\"result\"属性总结汇报执行情况。例如\n{\n\t\"finish\":true,\n    \"result\":\"论坛帖子已经成功发布。\"\n}\n\n- 如果执行Skill出现错误，你认为无法完成用户的任务，设置回复JSON中的\"abort\"属性为true，并在\"reason\"属性中说明原因。例如:\n{\n\t\"abort\":true,\n    \"reason\":\"没有登录脸书账号，无法发布新的内容。\"\n}\n\n- 如果没有Skill可以完成用户的要求，请设计一个或多个用来完成用户需求的Skill，在回复JSON中用\"missingSkills\"数组属性里描述缺失的Skill。例如：\n{\n\t\"missingSkills\":[\n    \t\"检查脸书账号登录状态\",\n        \"发布脸书动态\"\n    ]\n}\n\n- 如果回答用户的输入不需要使用任何skill，用回复JSON中的\"replay\"属性回答用户，如果对话已结束，同时设置\"finish\"属性为true。例如：当用户询问：\"西瓜是一种水果么？\"，你的回复：\n{\n\t\"finish\":true,\n\t\"reply\":\"是的，西瓜是一种水果。\"\n}\n`\n",
//						"temperature": "0",
//						"maxToken": "2000",
//						"topP": "1",
//						"fqcP": "0",
//						"prcP": "0",
//						"messages": {
//							"attrs": []
//						},
//						"prompt": "#input",
//						"seed": "",
//						"outlet": {
//							"jaxId": "1I1L26LKI0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1L20SLD0"
//						},
//						"secret": "false",
//						"allowCheat": "false",
//						"GPTCheats": {
//							"attrs": [
//								{
//									"type": "object",
//									"def": "GPTCheat",
//									"jaxId": "1I1MIE76U0",
//									"attrs": {
//										"prompt": "",
//										"reply": "{\"skill\":\"Skill-2\"}\n"
//									}
//								}
//							]
//						},
//						"shareChatName": "",
//						"keepChat": "50 messages",
//						"clearChat": "2",
//						"apiFiles": {
//							"attrs": []
//						},
//						"parallelFunction": "false",
//						"responseFormat": "json_object"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "brunch",
//					"jaxId": "1I1L20SLD0",
//					"attrs": {
//						"id": "CheckSkill",
//						"label": "New AI Seg",
//						"x": "845",
//						"y": "380",
//						"desc": "这是一个AISeg。",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I1L26LKM4",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1L26LKM5",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I1L26LKJ0",
//							"attrs": {
//								"id": "Default",
//								"desc": "输出节点。",
//								"output": ""
//							},
//							"linkedSeg": "1I1L24UDT0"
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I1L4HCRJ0",
//									"attrs": {
//										"id": "Missing",
//										"desc": "输出节点。",
//										"output": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I1L51Q1J0",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I1L51Q1J1",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#input.missingSkills"
//									},
//									"linkedSeg": "1I1L4N5OQ0"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I1L26LKI1",
//									"attrs": {
//										"id": "UseSkill",
//										"desc": "输出节点。",
//										"output": "#input",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I1L26LKM6",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I1L26LKM7",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#input.skill"
//									},
//									"linkedSeg": "1I1L5B9VP0"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I1L4HMHK0",
//									"attrs": {
//										"id": "Finish",
//										"desc": "输出节点。",
//										"output": "#input.result",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I1L51Q1J2",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I1L51Q1J3",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#input.finish&&input.result"
//									},
//									"linkedSeg": "1I1L4K6GU0"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I1L4HSMS0",
//									"attrs": {
//										"id": "Abort",
//										"desc": "输出节点。",
//										"output": "#input.reason",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I1L51Q1J4",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I1L51Q1J5",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#input.abort"
//									},
//									"linkedSeg": "1I1L4JP9K0"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I1L4IO2S0",
//									"attrs": {
//										"id": "Reply",
//										"desc": "输出节点。",
//										"output": "#input.reply",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I1L51Q1J6",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I1L51Q1J7",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#input.reply"
//									},
//									"linkedSeg": "1I1L4IVOP0"
//								}
//							]
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I1L2433G0",
//					"attrs": {
//						"id": "PickSkill",
//						"label": "New AI Seg",
//						"x": "1320",
//						"y": "255",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I1L26LKM8",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1L26LKM9",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I1L26LKJ1",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1QH2J920"
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1I1QH2J920",
//					"attrs": {
//						"id": "ShowSkill",
//						"label": "New AI Seg",
//						"x": "1565",
//						"y": "255",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I1QH48FK0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1QH48FK1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "Assistant",
//						"text": "#`- Skill: ${context.curSkill.getNameText()}\n- Prompt: ${input.prompt}\n`",
//						"outlet": {
//							"jaxId": "1I1QH48FB0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1N74RVL0"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I1N74RVL0",
//					"attrs": {
//						"id": "RunSkill",
//						"label": "New AI Seg",
//						"x": "1790",
//						"y": "255",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I1N75UQ80",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1N75UQ81",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I1N75UQ20",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1N7NL9G0"
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1I1N7NL9G0",
//					"attrs": {
//						"id": "ShowSkillResult",
//						"label": "New AI Seg",
//						"x": "1995",
//						"y": "185",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I1N7RO060",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1N7RO061",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "System",
//						"text": "#input",
//						"outlet": {
//							"jaxId": "1I1N7RO010",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1N876690"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I1N876690",
//					"attrs": {
//						"id": "appendMessage",
//						"label": "New AI Seg",
//						"x": "2260",
//						"y": "185",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I1N88PHE0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1N88PHE1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I1N88PH50",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1N87SVA0"
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1I1L24UDT0",
//					"attrs": {
//						"id": "ShowResult",
//						"label": "New AI Seg",
//						"x": "1085",
//						"y": "535",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I1L26LKM10",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1L26LKM11",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "Assistant",
//						"text": "#input",
//						"outlet": {
//							"jaxId": "1I1L26LKJ2",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1L276T40"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I1L276T40",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "1235",
//						"y": "610",
//						"outlet": {
//							"jaxId": "1I1L284PT0",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1L27N6E0"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I1L27N6E0",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "970",
//						"y": "610",
//						"outlet": {
//							"jaxId": "1I1L284PT1",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1N9AI7S0"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1I1L4IVOP0",
//					"attrs": {
//						"id": "ShowReply",
//						"label": "New AI Seg",
//						"x": "1085",
//						"y": "475",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I1L51Q1J8",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1L51Q1J9",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "Assistant",
//						"text": "#input",
//						"outlet": {
//							"jaxId": "1I1L51Q1G0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1SF3OGA0"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1I1L4JP9K0",
//					"attrs": {
//						"id": "ShowAbort",
//						"label": "New AI Seg",
//						"x": "1085",
//						"y": "420",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I1L51Q1J10",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1L51Q1J11",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "Assistant",
//						"text": "#input",
//						"outlet": {
//							"jaxId": "1I1L51Q1G1",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1SF3OGA0"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1I1L4K6GU0",
//					"attrs": {
//						"id": "ShowFinish",
//						"label": "New AI Seg",
//						"x": "1085",
//						"y": "365",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I1L51Q1J12",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1L51Q1J13",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "Assistant",
//						"text": "#input",
//						"outlet": {
//							"jaxId": "1I1L51Q1G2",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1SF3OGA0"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I1L4LN2D0",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "1935",
//						"y": "610",
//						"outlet": {
//							"jaxId": "1I1L51Q1J15",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1SFB7FP0"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1I1L4N5OQ0",
//					"attrs": {
//						"id": "ShowMissing",
//						"label": "New AI Seg",
//						"x": "1085",
//						"y": "225",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I1L51Q1J16",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1L51Q1J17",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "Assistant",
//						"text": "#input",
//						"outlet": {
//							"jaxId": "1I1L51Q1G3",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1L4NP3H0"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "askConfirm",
//					"jaxId": "1I1L4NP3H0",
//					"attrs": {
//						"id": "AskCreate",
//						"label": "New AI Seg",
//						"x": "1320",
//						"y": "170",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"prompt": "Please confirm",
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1I1L4NP3A2",
//									"attrs": {
//										"id": "Abort",
//										"desc": "Will clear messages",
//										"text": "Abort",
//										"result": "",
//										"codes": "true",
//										"context": {
//											"jaxId": "1I1L51Q1J20",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I1L51Q1J21",
//											"attrs": {
//												"cast": ""
//											}
//										}
//									},
//									"linkedSeg": "1I1N9K0UV0"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1I1L4NP3A0",
//									"attrs": {
//										"id": "Create",
//										"desc": "输出节点。",
//										"text": "Create",
//										"result": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I1L51Q1J18",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I1L51Q1J19",
//											"attrs": {
//												"cast": ""
//											}
//										}
//									},
//									"linkedSeg": "1I1N9J5G70"
//								}
//							]
//						},
//						"silent": "false"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "tryCatch",
//					"jaxId": "1I1L5B9VP0",
//					"attrs": {
//						"id": "CallSkill",
//						"label": "New AI Seg",
//						"x": "1085",
//						"y": "295",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I1L5DNUI0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1L5DNUI1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I1L5DNUF0",
//							"attrs": {
//								"id": "Try",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1L2433G0"
//						},
//						"catchlet": {
//							"jaxId": "1I1L5DNUF1",
//							"attrs": {
//								"id": "Catch",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1L5CSLR0"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I1L5CSLR0",
//					"attrs": {
//						"id": "LogError",
//						"label": "New AI Seg",
//						"x": "1320",
//						"y": "335",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I1L5DNUI2",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1L5DNUI3",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I1L5DNUF2",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1N94UGV0"
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1I1M9GPHP0",
//					"attrs": {
//						"id": "StartTip",
//						"label": "New AI Seg",
//						"x": "365",
//						"y": "380",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I1M9HO1R0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1M9HO1R1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "User",
//						"text": "#`${command}`",
//						"outlet": {
//							"jaxId": "1I1M9HO1M0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1L2072D0"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I1N87SVA0",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "2435",
//						"y": "60",
//						"outlet": {
//							"jaxId": "1I1N88PHE2",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1N9REU70"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I1N881SF0",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "970",
//						"y": "60",
//						"outlet": {
//							"jaxId": "1I1N88PHE3",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1N99IJJ0"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I1N8JRGV0",
//					"attrs": {
//						"id": "ResetMsg",
//						"label": "New AI Seg",
//						"x": "1565",
//						"y": "390",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I1N8PN2J0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1N8PN2J1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I1N8OS6J0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1N8NG750"
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "askChat",
//					"jaxId": "1I1N8NG750",
//					"attrs": {
//						"id": "AskNewCmd",
//						"label": "New AI Seg",
//						"x": "1790",
//						"y": "390",
//						"desc": "这是一个AISeg。",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I1N8PN2J2",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1N8PN2J3",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"tip": "有什么新的指示么？",
//						"tipRole": "Assistant",
//						"placeholder": "",
//						"text": "",
//						"file": "false",
//						"showText": "true",
//						"outlet": {
//							"jaxId": "1I1N8OS6J1",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1L4LN2D0"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connectorL",
//					"jaxId": "1I1N94UGV0",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "2400",
//						"y": "335",
//						"outlet": {
//							"jaxId": "1I1N957VS0",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1N87SVA0"
//						},
//						"dir": "L2R"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I1N99IJJ0",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "645",
//						"y": "300",
//						"outlet": {
//							"jaxId": "1I1N9IAOD0",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1L2072D0"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I1N9AI7S0",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "645",
//						"y": "460",
//						"outlet": {
//							"jaxId": "1I1N9IAOD1",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1L2072D0"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "aiBot",
//					"jaxId": "1I1N9J5G70",
//					"attrs": {
//						"id": "CreeateSkill",
//						"label": "New AI Seg",
//						"x": "1565",
//						"y": "185",
//						"desc": "调用其它AI Agent，把调用的结果作为输出",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I1N9KMN50",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1N9KMN51",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"source": "",
//						"argument": "#{}#>input",
//						"secret": "false",
//						"outlet": {
//							"jaxId": "1I1N9KMMV0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1N9QI710"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I1N9K0UV0",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "1465",
//						"y": "60",
//						"outlet": {
//							"jaxId": "1I1N9KMN52",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1N881SF0"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I1N9QI710",
//					"attrs": {
//						"id": "ReloadSkills",
//						"label": "New AI Seg",
//						"x": "1795",
//						"y": "135",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I1N9S0B80",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1N9S0B81",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I1N9S0AV0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1N9REU70"
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I1N9REU70",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "1950",
//						"y": "60",
//						"outlet": {
//							"jaxId": "1I1N9S0B82",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1N9K0UV0"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "askMenu",
//					"jaxId": "1I1SF3OGA0",
//					"attrs": {
//						"id": "NextMenu",
//						"label": "New AI Seg",
//						"x": "1320",
//						"y": "420",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"prompt": "Please confirm",
//						"multi": "false",
//						"withChat": "false",
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1I1SF3OFR0",
//									"attrs": {
//										"id": "NewTask",
//										"desc": "输出节点。",
//										"text": "执行新的任务",
//										"result": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I1SFCVNF0",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I1SFCVNF1",
//											"attrs": {
//												"cast": ""
//											}
//										}
//									},
//									"linkedSeg": "1I1N8JRGV0"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1I1SF3OFR1",
//									"attrs": {
//										"id": "Continue",
//										"desc": "输出节点。",
//										"text": {
//											"type": "string",
//											"valText": "Continue current task",
//											"localize": {
//												"EN": "Continue current task",
//												"CN": "继续当前任务"
//											},
//											"localizable": true
//										},
//										"result": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I1SFCVNF2",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I1SFCVNF3",
//											"attrs": {
//												"cast": ""
//											}
//										}
//									},
//									"linkedSeg": "1I1SFAGFA0"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1I1SF3OFR2",
//									"attrs": {
//										"id": "Exit",
//										"desc": "输出节点。",
//										"text": {
//											"type": "string",
//											"valText": "Exit conversation",
//											"localize": {
//												"EN": "Exit conversation",
//												"CN": "退出对话"
//											},
//											"localizable": true
//										},
//										"result": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I1SFCVNF4",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I1SFCVNF5",
//											"attrs": {
//												"cast": ""
//											}
//										}
//									},
//									"linkedSeg": "1I1SFCDUK0"
//								}
//							]
//						},
//						"silent": "false"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "askChat",
//					"jaxId": "1I1SFAGFA0",
//					"attrs": {
//						"id": "AskMore",
//						"label": "New AI Seg",
//						"x": "1565",
//						"y": "460",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I1SFCVNF6",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1SFCVNF7",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"tip": {
//							"type": "string",
//							"valText": "Please give instructions",
//							"localize": {
//								"EN": "Please give instructions",
//								"CN": "请给出指示"
//							},
//							"localizable": true
//						},
//						"tipRole": "Assistant",
//						"placeholder": "",
//						"text": "",
//						"file": "false",
//						"showText": "true",
//						"outlet": {
//							"jaxId": "1I1SFCVN70",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1SFB7FP0"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I1SFB7FP0",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "1690",
//						"y": "610",
//						"outlet": {
//							"jaxId": "1I1SFCVNF8",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1L276T40"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I1SFCDUK0",
//					"attrs": {
//						"id": "ExitChat",
//						"label": "New AI Seg",
//						"x": "1565",
//						"y": "530",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "flag.svg",
//						"context": {
//							"jaxId": "1I1SFCVNF9",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1SFCVNF10",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I1SFCVN71",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							}
//						},
//						"result": "#input"
//					}
//				}
//			]
//		},
//		"desc": "这是一个AI代理。",
//		"exportAPI": "true",
//		"exportAddOn": "true",
//		"addOnOpts": ""
//	}
//}