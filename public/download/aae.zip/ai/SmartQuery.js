//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import pathLib from "/@path";
import inherits from "/@inherits";
import Base64 from "/@tabos/utils/base64.js";
import {trimJSON} from "/@aichat/utils.js";
/*#{1I00BCBT10MoreImports*/
/*}#1I00BCBT10MoreImports*/
const agentURL=(new URL(import.meta.url)).pathname;
const basePath=pathLib.dirname(agentURL);
const $ln=VFACT.lanCode||"EN";
const argsTemplate={
	properties:{
		"targetPage":{
			"name":"targetPage","type":"auto",
			"defaultValue":"",
			"desc":"",
		},
		"query":{
			"name":"query","type":"string",
			"defaultValue":"",
			"desc":"",
		},
		"aaeId":{
			"name":"aaeId","type":"auto",
			"defaultValue":"",
			"desc":"",
		}
	},
	/*#{1I00BCBT10ArgsView*/
	/*}#1I00BCBT10ArgsView*/
};

/*#{1I00BCBT10StartDoc*/
/*}#1I00BCBT10StartDoc*/
//----------------------------------------------------------------------------
let SmartQuery=async function(session){
	let targetPage,query,aaeId;
	const $ln=session.language||"EN";
	let context,globalContext=session.globalContext;
	let self;
	let HasPage,QueryPage,CheckQuery,AskQuery,Read2,AIQuery,ShowJSON2,AskMode,Read1,AICompile,ShowJSON1,CheckResult,ShowNotFound,AskFix,TestResult1,ChooseQuery2,IsResultOK1,ShowFailed1,TestResult2,IsResultOK2,ShowFailed2,IsSilence1,ChooseQuery,CommitResult,IsSilence2,AutoFix,CheckRetry,FailResult,RankQuery,IsSilence3,AutoFix2,AskFix2,CheckEnd,CheckEnd2,AskFix3,CheckEnd3,FailResult2,LoopResult,DrawItem,ChooseItem,TipMultiResult,SnapPage,CheckItem,TipTarget;
	let pageHTML="";
	let silence=false;
	let RPALogger=null;
	
	/*#{1I00BCBT10LocalVals*/
	/*}#1I00BCBT10LocalVals*/
	
	function parseAgentArgs(input){
		if(typeof(input)=='object'){
			targetPage=input.targetPage;
			query=input.query;
			aaeId=input.aaeId;
		}else{
			targetPage=undefined;
			query=undefined;
			aaeId=undefined;
		}
		/*#{1I00BCBT10ParseArgs*/
		/*}#1I00BCBT10ParseArgs*/
	}
	
	/*#{1I00BCBT10PreContext*/
	/*}#1I00BCBT10PreContext*/
	context={
		maxRetry: 3,
		retry: 0,
		findVO: "",
		results: "",
		pageSnap: "",
		/*#{1I00BCBT15ExCtxAttrs*/
		/*}#1I00BCBT15ExCtxAttrs*/
	};
	context=VFACT.flexState(context);
	/*#{1I00BCBT10PostContext*/
	if(globalContext && globalContext.RPA){
		silence=silence||(!!globalContext.RPA.slience);
		RPALogger=globalContext.RPA.logger;
	}
	/*}#1I00BCBT10PostContext*/
	let agent,segs={};
	segs["HasPage"]=HasPage=async function(input){//:1I0AET6B00
		let result=input;
		if(!targetPage){
			return {seg:QueryPage,result:(input),preSeg:"1I0AET6B00",outlet:"1I0AF25M90"};
		}
		return {seg:CheckQuery,result:(result),preSeg:"1I0AET6B00",outlet:"1I0AF25M91"};
	};
	HasPage.jaxId="1I0AET6B00"
	HasPage.url="HasPage@"+agentURL
	
	segs["QueryPage"]=QueryPage=async function(input){//:1I0AM1LOU0
		let result,args={};
		/*#{1I0AM1LOU0PreCodes*/
		/*}#1I0AM1LOU0PreCodes*/
		result= await session.pipeChat("/@aae/ai/QueryPage.js",args,false);
		/*#{1I0AM1LOU0PostCodes*/
		targetPage=result;
		/*}#1I0AM1LOU0PostCodes*/
		return {seg:CheckQuery,result:(result),preSeg:"1I0AM1LOU0",outlet:"1I0AM29PD0"};
	};
	QueryPage.jaxId="1I0AM1LOU0"
	QueryPage.url="QueryPage@"+agentURL
	
	segs["CheckQuery"]=CheckQuery=async function(input){//:1I01VBHFF0
		let result=input;
		if(!!aaeId){
			return {seg:AskMode,result:(input),preSeg:"1I01VBHFF0",outlet:"1I022AD7S0"};
		}
		if(!query){
			return {seg:AskQuery,result:(input),preSeg:"1I01VBHFF0",outlet:"1I01VGJ7T0"};
		}
		return {seg:TipTarget,result:(result),preSeg:"1I01VBHFF0",outlet:"1I01VGJ7T1"};
	};
	CheckQuery.jaxId="1I01VBHFF0"
	CheckQuery.url="CheckQuery@"+agentURL
	
	segs["AskQuery"]=AskQuery=async function(input){//:1I01VE3PU0
		let tip=((($ln==="CN")?("您想查询什么？（例如“搜索按钮”，“结果列表”）"):("What do you want query? (e.g. \"The search button\", \"Result list\")")));
		let tipRole=("assistant");
		let placeholder=("");
		let text=("");
		let result="";
		/*#{1I01VE3PU0PreCodes*/
		/*}#1I01VE3PU0PreCodes*/
		if(tip){
			session.addChatText(tipRole,tip);
		}
		result=await session.askChatInput({type:"input",placeholder:placeholder,text:text});
		session.addChatText("user",result);
		/*#{1I01VE3PU0PostCodes*/
		query=result;
		/*}#1I01VE3PU0PostCodes*/
		return {seg:TipTarget,result:(result),preSeg:"1I01VE3PU0",outlet:"1I01VGJ7T2"};
	};
	AskQuery.jaxId="1I01VE3PU0"
	AskQuery.url="AskQuery@"+agentURL
	
	segs["Read2"]=Read2=async function(input){//:1I00BLB6E0
		let result=null;
		let pageVal="aaPage";
		let $target="cleanHTML";
		let $node=null;
		let $options={"compact":4,"cleanMarks":0};
		let $waitBefore=0;
		let $waitAfter=0;
		let page=context[pageVal];
		$waitBefore && (await sleep($waitBefore));
		/*#{1I00BLB6E0PreCodes*/
		page=targetPage;
		/*}#1I00BLB6E0PreCodes*/
		switch($target){
			case "cleanHTML":
				result=await page.readInnerHTML($node,{compact:2,...$options});
				break;
			case "html":
				result=await page.readInnerHTML($node,{...$options});
				break;
			case "view":
				result=await page.readView($node,{...$options});
				break;
			case "text":
				result=await page.readInnerText($node,{...$options});
				break;
			case "article":
				result=await page.readArticle($node,{...$options});
				break;
		}$waitAfter && (await sleep($waitAfter))
		/*#{1I00BLB6E0PostCodes*/
		pageHTML=result;
		console.log(pageHTML);
		result=`- 当前HTML内容：\n\`\`\`\n${pageHTML}\`\`\`\n - 请在这个页面中查找复合描述:  ${query} 的元素。`
		/*}#1I00BLB6E0PostCodes*/
		return {seg:AIQuery,result:(result),preSeg:"1I00BLB6E0",outlet:"1I00D1FFA0"};
	};
	Read2.jaxId="1I00BLB6E0"
	Read2.url="Read2@"+agentURL
	
	segs["AIQuery"]=AIQuery=async function(input){//:1I00BVJBN0
		let prompt;
		let result=null;
		/*#{1I00BVJBN0Input*/
		/*}#1I00BVJBN0Input*/
		
		let opts={
			platform:"OpenAI",
			mode:"gpt-4o",
			maxToken:2000,
			temperature:0,
			topP:1,
			fqcP:0,
			prcP:0,
			secret:false,
			responseFormat:"json_object"
		};
		let chatMem=AIQuery.messages
		let seed="";
		if(seed!==undefined){opts.seed=seed;}
		let messages=[
			{role:"system",content:`
你是一个根据网页的HTML文本进行解析网页内容，定位复合用户描述的一个或者多个元素，并生成查找它们的X-Path指令表达式。

- 每次对话开始时，用户会告诉你当前网页的HTML文本内容，以及用户需定位的元素的描述。

- 在HTML元素标签的属性中有两个重要的辅助属性你需要注意：
1）aaeid: 这是每个HTML元素唯一的ID，用来区分每一个HTML元素
2）rect：这个属性描述的是元素在网页视图内的位置和尺寸信息，如果一个元素没有这个属性，则这个元素可能是不可见的。

- 请用JSON回答用户，下面是一个实例：
\`\`\`
{
	"result":["123"],
    "query":[
    	"(//DIV[contains(@class,"FileUpload_box")])",
    	"(//DIV[@id="upload"])",
	]
}
\`\`\`

- "result"属性是一个包含查找到的元素的aaeid属性的数组。

- "reuslt"里面每一项是一个复合用户需求的元素的aaeid属性的值。

- 如果找不到复合用户描述的元素，把"result"属性为0长度的数组：[]。

- "query"属性是你根据当前网页内容以及元素的属性特点，生成的可以用来定位复合需求的元素的X-Path搜索指令组。

- "query"数组内的每一项是一种可以用来定位结果元素的X-Path指令，如果能找到复合描述的元素，请提供至少2种，最多5种不同的指令。

- 生成的X-Path指令里，不能包含涉及aaeid和rect属性的内容。

- 生成的X-Path指令，需要按照是否符合自然语言习惯进行排序，最符合自然语言习惯的表达式，排在最前面。

- 你可以与用户进行多轮对话，每次根据用户的反馈修正并返回新的JSON。
`},
		];
		messages.push(...chatMem);
		/*#{1I00BVJBN0PrePrompt*/
		/*}#1I00BVJBN0PrePrompt*/
		prompt=input;
		if(prompt!==null){
			if(typeof(prompt)!=="string"){
				prompt=JSON.stringify(prompt,null,"	");
			}
			messages.push({role:"user",content:prompt});
		}
		/*#{1I00BVJBN0PreCall*/
		/*}#1I00BVJBN0PreCall*/
		result=(result===null)?(await session.callSegLLM("AIQuery@"+agentURL,opts,messages,true)):result;
		/*#{1I00BVJBN0PostLLM*/
		/*}#1I00BVJBN0PostLLM*/
		chatMem.push({role:"user",content:prompt});
		chatMem.push({role:"assistant",content:result});
		if(chatMem.length>20){
			let removedMsgs=chatMem.splice(0,2);
			/*#{1I00BVJBN0PostClear*/
			/*}#1I00BVJBN0PostClear*/
		}
		result=trimJSON(result);
		/*#{1I00BVJBN0PostCall*/
		console.log(result);
		/*}#1I00BVJBN0PostCall*/
		return {seg:ShowJSON2,result:(result),preSeg:"1I00BVJBN0",outlet:"1I00D1FFB0"};
	};
	AIQuery.jaxId="1I00BVJBN0"
	AIQuery.url="AIQuery@"+agentURL
	AIQuery.messages=[];
	
	segs["ShowJSON2"]=ShowJSON2=async function(input){//:1I00DH8UQ0
		let result=input;
		let opts={};
		let role="assistant";
		let content=`生成结果：\n\`\`\`\n${JSON.stringify(input,null,"\t")}\n\`\`\`\n`;
		session.addChatText(role,content,opts);
		context["findVO"]=input;
		return {seg:CheckResult,result:(result),preSeg:"1I00DH8UQ0",outlet:"1I00DIT6V0"};
	};
	ShowJSON2.jaxId="1I00DH8UQ0"
	ShowJSON2.url="ShowJSON2@"+agentURL
	
	segs["AskMode"]=AskMode=async function(input){//:1I022C89U0
		let prompt=("Search selected element or input a new query")||input;
		let silent=false;
		let countdown=undefined;
		let placeholder=(undefined)||null;
		let button1=("Selected")||"OK";
		let button2=("Input")||"Cancel";
		let button3="";
		let result="";
		let value=0;
		if(silent){
			result="OK";
			return {seg:Read1,result:(result),preSeg:"1I022C89U0",outlet:"1I022C89E0"};
		}
		[result,value]=await session.askUserRaw({type:"confirm",prompt:prompt,button1:button1,button2:button2,button3:button3,countdown:countdown,withChat:undefined,placeholder:placeholder});
		if(value===1){
			result=("OK")||result;
			return {seg:Read1,result:(result),preSeg:"1I022C89U0",outlet:"1I022C89E0"};
		}
		result=("Cancel")||result;
		return {seg:AskQuery,result:(result),preSeg:"1I022C89U0",outlet:"1I022C89E1"};
	
	};
	AskMode.jaxId="1I022C89U0"
	AskMode.url="AskMode@"+agentURL
	
	segs["Read1"]=Read1=async function(input){//:1I022F5DE0
		let result=null;
		let pageVal="aaPage";
		let $target="cleanHTML";
		let $node=null;
		let $options={"compact":4,"cleanMarks":0};
		let $waitBefore=0;
		let $waitAfter=0;
		let page=context[pageVal];
		$waitBefore && (await sleep($waitBefore));
		/*#{1I022F5DE0PreCodes*/
		page=targetPage;
		/*}#1I022F5DE0PreCodes*/
		switch($target){
			case "cleanHTML":
				result=await page.readInnerHTML($node,{compact:2,...$options});
				break;
			case "html":
				result=await page.readInnerHTML($node,{...$options});
				break;
			case "view":
				result=await page.readView($node,{...$options});
				break;
			case "text":
				result=await page.readInnerText($node,{...$options});
				break;
			case "article":
				result=await page.readArticle($node,{...$options});
				break;
		}$waitAfter && (await sleep($waitAfter))
		/*#{1I022F5DE0PostCodes*/
		pageHTML=result;
		result=`- 当前HTML内容：\n\`\`\`\n${pageHTML}\`\`\`\n - 请生成在这个页面中，根据元素属性（但不要使用aaeid、aaerect、aaestyle属性）以及层级关系，生成：查找aaeid="${aaeId}"代表的元素的X-Path表达式。`
		/*}#1I022F5DE0PostCodes*/
		return {seg:AICompile,result:(result),preSeg:"1I022F5DE0",outlet:"1I022FCB10"};
	};
	Read1.jaxId="1I022F5DE0"
	Read1.url="Read1@"+agentURL
	
	segs["AICompile"]=AICompile=async function(input){//:1I022LUPO0
		let prompt;
		let result;
		
		let opts={
			platform:"OpenAI",
			mode:"gpt-4o",
			maxToken:2000,
			temperature:0,
			topP:1,
			fqcP:0,
			prcP:0,
			secret:false,
			responseFormat:"json_object"
		};
		let chatMem=AICompile.messages
		let seed="";
		if(seed!==undefined){opts.seed=seed;}
		let messages=[
			{role:"system",content:`
你是一个根据网页的HTML文本进行解析网页内容，生成查找用户指定元素的X-Path指令表达式。

- 在HTML元素标签的属性中有3个重要的辅助属性你需要注意：
1）aaeid: 这是每个HTML元素唯一的索引ID，用来区分每一个HTML元素
2）aaerect：这个属性描述的是元素在网页视图内的位置和尺寸信息，如果一个元素没有这个属性，则这个元素可能是不可见的。
3）aaestyle：这个属性描述的是元素在网页视图内的最终CSS-Style。

- 每次对话开始时，用户会告诉你当前网页的HTML文本内容，以及用户需定位的元素的索引ID（aaeid）。

- 请用JSON回答用户，下面是一个实例：
\`\`\`
{
    "query":[
    	"(//DIV[contains(@class,"FileUpload_box")])",
    	"(//DIV[@id="upload"])",
	]
}
\`\`\`

- "query"属性是你根据当前网页内容以及指定元素的属性特点，生成的可以用来定位复合需求的元素的X-Path搜索指令组。

- "query"数组内的每一项是一种可以用来定位结果元素的X-Path指令，如果能找到复合描述的元素，请提供至少2种，最多10种不同的指令。

- 生成的X-Path指令里，不能包含涉及aaeid、aaerect和aaestyle属性的内容。

- 你生成的X-Path指令里必须包含至少一个只通过目标元素本身类型、属性进行查找的X-Path

- 你生成的X-Path指令里必须包含至少一个通过完全的元素层级关系进行查找的X-Path

- 非常重要：生成的X-Path指令，应该注意避免使用乱码或者没有意义的属性值（例如"afjxk28"、"78yeumzh"等），这样的属性值往往会发生变化，导致搜索指令失效，你可以截取属性值里有意义的部分，用“包含”模式查询。

- 你可以与用户进行多轮对话，每次根据用户的反馈修正并返回新的JSON。
`},
		];
		prompt=input;
		if(prompt!==null){
			if(typeof(prompt)!=="string"){
				prompt=JSON.stringify(prompt,null,"	");
			}
			messages.push({role:"user",content:prompt});
		}
		result=await session.callSegLLM("AICompile@"+agentURL,opts,messages,true);
		result=trimJSON(result);
		return {seg:ShowJSON1,result:(result),preSeg:"1I022LUPO0",outlet:"1I023BU3H0"};
	};
	AICompile.jaxId="1I022LUPO0"
	AICompile.url="AICompile@"+agentURL
	
	segs["ShowJSON1"]=ShowJSON1=async function(input){//:1I022NE1A0
		let result=input;
		let opts={};
		let role="assistant";
		let content=`生成结果：\n\`\`\`\n${JSON.stringify(input,null,"\t")}\n\`\`\`\n`;
		session.addChatText(role,content,opts);
		return {seg:TestResult1,result:(result),preSeg:"1I022NE1A0",outlet:"1I023BU3H1"};
	};
	ShowJSON1.jaxId="1I022NE1A0"
	ShowJSON1.url="ShowJSON1@"+agentURL
	
	segs["CheckResult"]=CheckResult=async function(input){//:1I022QPIT0
		let result=input;
		if(input.result&&input.result.length>1&&(!silence)){
			return {seg:TipMultiResult,result:(input),preSeg:"1I022QPIT0",outlet:"1I0S9P6O10"};
		}
		if(input.result&&input.result.length>0){
			return {seg:TestResult2,result:(input),preSeg:"1I022QPIT0",outlet:"1I023BU3H2"};
		}
		return {seg:ShowNotFound,result:(result),preSeg:"1I022QPIT0",outlet:"1I023BU3H3"};
	};
	CheckResult.jaxId="1I022QPIT0"
	CheckResult.url="CheckResult@"+agentURL
	
	segs["ShowNotFound"]=ShowNotFound=async function(input){//:1I022S31H0
		let result=input;
		let opts={};
		let role="assistant";
		let content="AI can't find element in the page based on your query.";
		session.addChatText(role,content,opts);
		return {seg:IsSilence2,result:(result),preSeg:"1I022S31H0",outlet:"1I023BU3H4"};
	};
	ShowNotFound.jaxId="1I022S31H0"
	ShowNotFound.url="ShowNotFound@"+agentURL
	
	segs["AskFix"]=AskFix=async function(input){//:1I022T3620
		let tip=("Please give more advice for searching element(s). Input \"end\" to abort this task");
		let tipRole=("assistant");
		let placeholder=("");
		let text=("");
		let result="";
		if(tip){
			session.addChatText(tipRole,tip);
		}
		result=await session.askChatInput({type:"input",placeholder:placeholder,text:text});
		session.addChatText("user",result);
		return {seg:CheckEnd2,result:(result),preSeg:"1I022T3620",outlet:"1I023BU3I0"};
	};
	AskFix.jaxId="1I022T3620"
	AskFix.url="AskFix@"+agentURL
	
	segs["TestResult1"]=TestResult1=async function(input){//:1I023070E0
		let result=input
		/*#{1I023070E0Code*/
		let tgtAAEId,qryList,query,node;
		tgtAAEId=aaeId;
		qryList=input.query;
		result=[];
		for(query of qryList){
			session.addChatText("system","Checking query: "+query);
			if(query[0]!=="(" || !query.endsWith(")")){
				query="("+query+")";
			}
			try{
				node=await targetPage.queryNode(null,query,{});
			}catch(err){
				node=null;
			}
			if(node && node.AAEId===tgtAAEId){
				session.addChatText("system",`Query: ${query} is OK.`);
				result.push(query);
			}
		}
		result=result.length?result:null;
		/*}#1I023070E0Code*/
		return {seg:IsResultOK1,result:(result),preSeg:"1I023070E0",outlet:"1I023BU3I1"};
	};
	TestResult1.jaxId="1I023070E0"
	TestResult1.url="TestResult1@"+agentURL
	
	segs["ChooseQuery2"]=ChooseQuery2=async function(input){//:1I0233DG30
		let prompt=("Please confirm")||input;
		let countdown=undefined;
		let placeholder=(undefined)||null;
		let withChat=false;
		let silent=false;
		let items=[
		];
		let result="";
		let item=null;
		
		/*#{1I0233DG30PreCodes*/
		for(let query of input){
			items.push({text:query,query:query});
		}
		/*}#1I0233DG30PreCodes*/
		if(silent){
			result="";
			return {result:result};
		}
		[result,item]=await session.askUserRaw({type:"menu",prompt:prompt,multiSelect:false,items:items,withChat:withChat,countdown:countdown,placeholder:placeholder});
		/*#{1I0233DG30PostCodes*/
		/*}#1I0233DG30PostCodes*/
		if(typeof(item)==='string'){
			result=item;
			return {result:result};
		}
		/*#{1I0233DG30FinCodes*/
		if(!item){
			result=null;
		}
		result=item.query;
		/*}#1I0233DG30FinCodes*/
		return {result:result};
	};
	ChooseQuery2.jaxId="1I0233DG30"
	ChooseQuery2.url="ChooseQuery2@"+agentURL
	
	segs["IsResultOK1"]=IsResultOK1=async function(input){//:1I0236HP70
		let result=input;
		if(input){
			return {seg:ChooseQuery2,result:(input),preSeg:"1I0236HP70",outlet:"1I023BU3I2"};
		}
		return {seg:ShowFailed1,result:(result),preSeg:"1I0236HP70",outlet:"1I023BU3I3"};
	};
	IsResultOK1.jaxId="1I0236HP70"
	IsResultOK1.url="IsResultOK1@"+agentURL
	
	segs["ShowFailed1"]=ShowFailed1=async function(input){//:1I023CEKO0
		let result=input;
		let opts={};
		let role="assistant";
		let content="Queries generated by AI can't pass test.";
		session.addChatText(role,content,opts);
		return {seg:AskFix3,result:(result),preSeg:"1I023CEKO0",outlet:"1I023DLEH0"};
	};
	ShowFailed1.jaxId="1I023CEKO0"
	ShowFailed1.url="ShowFailed1@"+agentURL
	
	segs["TestResult2"]=TestResult2=async function(input){//:1I0AD8QU80
		let result=input
		/*#{1I0AD8QU80Code*/
		let tgtList,tgtAAEId,qryList,query,node;
		function checkNodes(nodes){
			let nodeIds;
			nodeIds=nodes.map((item)=>{return item.AAEId});
			for(tgtAAEId of tgtList){
				if(nodeIds.indexOf(tgtAAEId)<0){
					return false;
				}
			}
			return true;
		}
		
		input=context.findVO;
		tgtList=input.result;
		if(tgtList.length===1){
			tgtAAEId=tgtList[0];
			qryList=input.query;
			result=[];
			for(query of qryList){
				if(query[0]!=="(" || !query.endsWith(")")){
					query="("+query+")";
				}
				//session.addChatText("system","Checking query: "+query);
				try{
					node=await targetPage.queryNode(null,query,{});
				}catch(err){
					node=null;
				}
				if(node && node.AAEId===tgtAAEId){
					//session.addChatText("system",`Query: ${query} is OK.`);
					result.push(query);
				}
			}
			result=result.length?result:null;
		}else if(tgtList.length>1){
			let nodes;
			//The qeury should find all items in tgtList
			qryList=input.query;
			result=[];
			for(query of qryList){
				if(query[0]!=="(" || !query.endsWith(")")){
					query="("+query+")";
				}
				//session.addChatText("system","Checking query: "+query);
				try{
					nodes=await targetPage.queryNodes(null,query,{});
				}catch(err){
					node=null;
				}
				if(nodes){
					if(checkNodes(nodes)){
						//session.addChatText("system",`Query: ${query} is OK.`);
						result.push(query);
					}
				}
			}
			result=result.length?result:null;
		}
		/*}#1I0AD8QU80Code*/
		return {seg:IsResultOK2,result:(result),preSeg:"1I0AD8QU80",outlet:"1I0ADBE5N0"};
	};
	TestResult2.jaxId="1I0AD8QU80"
	TestResult2.url="TestResult2@"+agentURL
	
	segs["IsResultOK2"]=IsResultOK2=async function(input){//:1I0ADAOOU0
		let result=input;
		if(input){
			return {seg:IsSilence1,result:(input),preSeg:"1I0ADAOOU0",outlet:"1I0ADAOOV3"};
		}
		return {seg:ShowFailed2,result:(result),preSeg:"1I0ADAOOU0",outlet:"1I0ADAOOV2"};
	};
	IsResultOK2.jaxId="1I0ADAOOU0"
	IsResultOK2.url="IsResultOK2@"+agentURL
	
	segs["ShowFailed2"]=ShowFailed2=async function(input){//:1I0ADCFB30
		let result=input;
		let opts={};
		let role="assistant";
		let content="No query passed check.";
		session.addChatText(role,content,opts);
		return {seg:IsSilence3,result:(result),preSeg:"1I0ADCFB30",outlet:"1I0ADDRGD0"};
	};
	ShowFailed2.jaxId="1I0ADCFB30"
	ShowFailed2.url="ShowFailed2@"+agentURL
	
	segs["IsSilence1"]=IsSilence1=async function(input){//:1I0ADGFRA0
		let result=input;
		if((!silence) && input.length>1){
			return {seg:ChooseQuery,result:(input),preSeg:"1I0ADGFRA0",outlet:"1I0ADIQ3C0"};
		}
		if(input==="OneEntry"){
			return {seg:CommitResult,result:(input),preSeg:"1I0ADGFRA0",outlet:"1I0TED54L0"};
		}
		return {seg:RankQuery,result:(result),preSeg:"1I0ADGFRA0",outlet:"1I0ADIQ3C1"};
	};
	IsSilence1.jaxId="1I0ADGFRA0"
	IsSilence1.url="IsSilence1@"+agentURL
	
	segs["ChooseQuery"]=ChooseQuery=async function(input){//:1I0ADEPSD0
		let prompt=((($ln==="CN")?("多条X-Path查询指令可以找到正确的结果，请选择你认为更确切的一个。"):("Multiple X-Path query instructions can find the correct result, please select the one you think is more accurate.")))||input;
		let countdown=undefined;
		let placeholder=(undefined)||null;
		let withChat=false;
		let silent=false;
		let items=[
		];
		let result="";
		let item=null;
		
		/*#{1I0ADEPSD0PreCodes*/
		for(let query of input){
			items.push({text:query,query:query});
		}
		/*}#1I0ADEPSD0PreCodes*/
		if(silent){
			result="";
			return {seg:CommitResult,result:(result),preSeg:"1I0ADEPSD0",outlet:"1I0AEKGQI0"};
		}
		[result,item]=await session.askUserRaw({type:"menu",prompt:prompt,multiSelect:false,items:items,withChat:withChat,countdown:countdown,placeholder:placeholder});
		/*#{1I0ADEPSD0PostCodes*/
		if(!item){
			result=null;
		}
		result=item.query;
		/*}#1I0ADEPSD0PostCodes*/
		if(typeof(item)==='string'){
			result=item;
			return {result:result};
		}
		/*#{1I0ADEPSD0FinCodes*/
		/*}#1I0ADEPSD0FinCodes*/
		return {seg:CommitResult,result:(result),preSeg:"1I0ADEPSD0",outlet:"1I0AEKGQI0"};
	};
	ChooseQuery.jaxId="1I0ADEPSD0"
	ChooseQuery.url="ChooseQuery@"+agentURL
	
	segs["CommitResult"]=CommitResult=async function(input){//:1I0ADIDM10
		let result=input
		/*#{1I0ADIDM10Code*/
		console.log(input);
		if(Array.isArray(input)){
			result=input[0];
		}else if(input.sorted){
			result=input.sorted[0];
		}
		/*}#1I0ADIDM10Code*/
		return {result:result};
	};
	CommitResult.jaxId="1I0ADIDM10"
	CommitResult.url="CommitResult@"+agentURL
	
	segs["IsSilence2"]=IsSilence2=async function(input){//:1I0ADT3Q50
		let result=input;
		if(!silence){
			return {seg:AskFix,result:(input),preSeg:"1I0ADT3Q50",outlet:"1I0ADT3Q54"};
		}
		return {seg:AutoFix,result:(result),preSeg:"1I0ADT3Q50",outlet:"1I0ADT3Q53"};
	};
	IsSilence2.jaxId="1I0ADT3Q50"
	IsSilence2.url="IsSilence2@"+agentURL
	
	segs["AutoFix"]=AutoFix=async function(input){//:1I0ADVL920
		let result="找不到符合的元素，看看有没有类似的元素。"
		/*#{1I0ADVL920Code*/
		/*}#1I0ADVL920Code*/
		return {seg:CheckRetry,result:(result),preSeg:"1I0ADVL920",outlet:"1I0AEB6I90"};
	};
	AutoFix.jaxId="1I0ADVL920"
	AutoFix.url="AutoFix@"+agentURL
	
	segs["CheckRetry"]=CheckRetry=async function(input){//:1I0AE1CP40
		let result=input;
		if((context.retry++)>context.maxRetry){
			return {seg:FailResult,result:(input),preSeg:"1I0AE1CP40",outlet:"1I0AEB6I91"};
		}
		return {seg:AIQuery,result:(result),preSeg:"1I0AE1CP40",outlet:"1I0AEB6I92"};
	};
	CheckRetry.jaxId="1I0AE1CP40"
	CheckRetry.url="CheckRetry@"+agentURL
	
	segs["FailResult"]=FailResult=async function(input){//:1I0AE3P1P0
		let result=input
		/*#{1I0AE3P1P0Code*/
		result=null;
		/*}#1I0AE3P1P0Code*/
		return {result:result};
	};
	FailResult.jaxId="1I0AE3P1P0"
	FailResult.url="FailResult@"+agentURL
	
	segs["RankQuery"]=RankQuery=async function(input){//:1I0CO0MFU0
		let prompt;
		let result;
		
		let opts={
			platform:"OpenAI",
			mode:"gpt-4o",
			maxToken:2000,
			temperature:0,
			topP:1,
			fqcP:0,
			prcP:0,
			secret:false,
			responseFormat:"json_object"
		};
		let chatMem=RankQuery.messages
		let seed="";
		if(seed!==undefined){opts.seed=seed;}
		let messages=[
			{role:"system",content:"你是一个评判X-Path表达式是否符合自然语言习惯的AI\n\n- 每轮对话时，用户会输入包含一个或多个X-Path表达式数组，你从中挑选一个最符合自然语言习惯的。\n\n- 使用自然语言词汇、简写进行查询是更符合自然语言习惯的\n\n- 使用无规律的的字母/数字组合进行查询，是不符合自然语言习惯的\n\n- 回答问题时，按照符合自然语言习惯的程度把输入的数组进行排序，并用JSON格式返回。\n```\n{\n  \"sorted\":[\n      \"(//div[@jsname='header'])\",\n      \"(//div[@class='xxb89header'])\",\n      \"(//div[@dcd='xcxbar98vj8sa89ab'])\"\n  ]\n}\n```\n- 把排序后的数组放作为返回JSON的\"sorted\"属性。\n"},
		];
		prompt=`${JSON.stringify(input)}`;
		if(prompt!==null){
			if(typeof(prompt)!=="string"){
				prompt=JSON.stringify(prompt,null,"	");
			}
			messages.push({role:"user",content:prompt});
		}
		result=await session.callSegLLM("RankQuery@"+agentURL,opts,messages,true);
		result=trimJSON(result);
		return {seg:CommitResult,result:(result),preSeg:"1I0CO0MFU0",outlet:"1I0COA8R70"};
	};
	RankQuery.jaxId="1I0CO0MFU0"
	RankQuery.url="RankQuery@"+agentURL
	
	segs["IsSilence3"]=IsSilence3=async function(input){//:1I0DE07ES0
		let result=input;
		if(!silence){
			return {seg:AskFix2,result:(input),preSeg:"1I0DE07ES0",outlet:"1I0DE07ES4"};
		}
		return {seg:AutoFix2,result:(result),preSeg:"1I0DE07ES0",outlet:"1I0DE07ES3"};
	};
	IsSilence3.jaxId="1I0DE07ES0"
	IsSilence3.url="IsSilence3@"+agentURL
	
	segs["AutoFix2"]=AutoFix2=async function(input){//:1I0DE1FI10
		let result=input
		/*#{1I0DE1FI10Code*/
		result="这些X-Path指令不能找到指定的元素，请仔细的再看一下，生成正确的X-Path指令。";
		/*}#1I0DE1FI10Code*/
		return {seg:CheckRetry,result:(result),preSeg:"1I0DE1FI10",outlet:"1I0DE3ISF0"};
	};
	AutoFix2.jaxId="1I0DE1FI10"
	AutoFix2.url="AutoFix2@"+agentURL
	
	segs["AskFix2"]=AskFix2=async function(input){//:1I0DE2E2I0
		let tip=("");
		let tipRole=("assistant");
		let placeholder=("");
		let text=("");
		let result="";
		if(tip){
			session.addChatText(tipRole,tip);
		}
		result=await session.askChatInput({type:"input",placeholder:placeholder,text:text});
		session.addChatText("user",result);
		return {seg:CheckEnd,result:(result),preSeg:"1I0DE2E2I0",outlet:"1I0DE3ISF1"};
	};
	AskFix2.jaxId="1I0DE2E2I0"
	AskFix2.url="AskFix2@"+agentURL
	
	segs["CheckEnd"]=CheckEnd=async function(input){//:1I0DE38IP0
		let result=input;
		if(input.toLowerCase()==="end"){
			return {seg:FailResult,result:(input),preSeg:"1I0DE38IP0",outlet:"1I0DE3ISF2"};
		}
		return {seg:AIQuery,result:(result),preSeg:"1I0DE38IP0",outlet:"1I0DE3ISF3"};
	};
	CheckEnd.jaxId="1I0DE38IP0"
	CheckEnd.url="CheckEnd@"+agentURL
	
	segs["CheckEnd2"]=CheckEnd2=async function(input){//:1I0DGQHPA0
		let result=input;
		if(input.toLowerCase()==="end"){
			return {seg:FailResult,result:(input),preSeg:"1I0DGQHPA0",outlet:"1I0DGVEQF0"};
		}
		return {seg:AIQuery,result:(result),preSeg:"1I0DGQHPA0",outlet:"1I0DGVEQF1"};
	};
	CheckEnd2.jaxId="1I0DGQHPA0"
	CheckEnd2.url="CheckEnd2@"+agentURL
	
	segs["AskFix3"]=AskFix3=async function(input){//:1I0F889I70
		let tip=("Please give some advice to fix, or type \"end\" to abort.");
		let tipRole=("assistant");
		let placeholder=("");
		let text=("");
		let result="";
		if(tip){
			session.addChatText(tipRole,tip);
		}
		result=await session.askChatInput({type:"input",placeholder:placeholder,text:text});
		session.addChatText("user",result);
		return {seg:CheckEnd3,result:(result),preSeg:"1I0F889I70",outlet:"1I0F8E4CL0"};
	};
	AskFix3.jaxId="1I0F889I70"
	AskFix3.url="AskFix3@"+agentURL
	
	segs["CheckEnd3"]=CheckEnd3=async function(input){//:1I0F8A6SO0
		let result=input;
		/*#{1I0F8A6SO0Start*/
		/*}#1I0F8A6SO0Start*/
		if(input.toLowerCase()==="end"){
			return {seg:FailResult2,result:(input),preSeg:"1I0F8A6SO0",outlet:"1I0F8A6SO4"};
		}
		/*#{1I0F8A6SO0Post*/
		input=`根据建议：\n${input}\n重新生成X-Path。`;
		/*}#1I0F8A6SO0Post*/
		return {seg:AICompile,result:(result),preSeg:"1I0F8A6SO0",outlet:"1I0F8A6SO3"};
	};
	CheckEnd3.jaxId="1I0F8A6SO0"
	CheckEnd3.url="CheckEnd3@"+agentURL
	
	segs["FailResult2"]=FailResult2=async function(input){//:1I0F8B30I0
		let result=input
		/*#{1I0F8B30I0Code*/
		/*}#1I0F8B30I0Code*/
		return {result:result};
	};
	FailResult2.jaxId="1I0F8B30I0"
	FailResult2.url="FailResult2@"+agentURL
	
	segs["LoopResult"]=LoopResult=async function(input){//:1I0SA1UM00
		let result=input;
		let list=context.results;
		let i,n,item;
		n=list.length;
		for(i=0;i<n;i++){
			item=list[i];
			await session.runAISeg(agent,DrawItem,item,"1I0SA1UM00","1I0SA5OUS0")
		}
		return {seg:ChooseItem,result:(result),preSeg:"1I0SA1UM00",outlet:"1I0SA5OUS1"};
	};
	LoopResult.jaxId="1I0SA1UM00"
	LoopResult.url="LoopResult@"+agentURL
	
	segs["DrawItem"]=DrawItem=async function(input){//:1I0SA770Q0
		let result=input;
		let role="assistant";
		let content=`Element ${input}`;
		/*#{1I0SA770Q0PreCodes*/
		//Get node and rect:
		let node,rect;
		node=await targetPage.readView(input);
		rect=node.rect;
		/*}#1I0SA770Q0PreCodes*/
		//Limit size:
		let callback =null;
		let pms=new Promise((resolve)=>{callback=resolve;});
		{
			
			let maxSize =512;
			let img = new Image();
			img.crossOrigin = "Anonymous";
			img.src = context.pageSnap;
			img.onload = function () {
				let imgW = img.width;
				let imgH = img.height;
				let scale = maxSize/(imgW>imgH?imgW:imgH);
				{
					let canvas = document.createElement("canvas");
					let context = canvas.getContext("2d");
					canvas.width = Math.floor(img.width*scale);
					canvas.height = Math.floor(img.height*scale);
					context.drawImage(img, 0, 0,canvas.width,canvas.height);
					/*#{1I0SA770Q0Draw*/
					context.lineWidth = 3;
					context.strokeStyle = 'rgba(255, 0, 0, 0.6)';
					context.strokeRect(rect.x*scale*2, rect.y*scale*2, rect.width*scale*2, rect.height*scale*2);
					/*}#1I0SA770Q0Draw*/
					result = canvas.toDataURL("image/png");
				}
				callback();
			};
		}
		await pms;
		let vo={image:result};
		/*#{1I0SA770Q0Options*/
		/*}#1I0SA770Q0Options*/
		session.addChatText(role,content,vo);
		/*#{1I0SA770Q0PostCodes*/
		result=input;
		/*}#1I0SA770Q0PostCodes*/
		return {result:result};
	};
	DrawItem.jaxId="1I0SA770Q0"
	DrawItem.url="DrawItem@"+agentURL
	
	segs["ChooseItem"]=ChooseItem=async function(input){//:1I0SA8EPB0
		let prompt=((($ln==="CN")?("请选择正确的元素，如果正确的没有被列出，请不要选择任何元素。"):("Please select the correct element(s). If the correct one is not listed, do not select any element.")))||input;
		let countdown=undefined;
		let placeholder=(undefined)||null;
		let withChat=false;
		let silent=false;
		let items=[
		];
		let result="";
		let item=null;
		
		/*#{1I0SA8EPB0PreCodes*/
		let list=context.results;
		for(item of list){
			items.push({text:"Element: "+item,item:item});
		}
		/*}#1I0SA8EPB0PreCodes*/
		if(silent){
			result="";
			return {seg:CheckItem,result:(result),preSeg:"1I0SA8EPB0",outlet:"1I0SA8EON2"};
		}
		[result,item]=await session.askUserRaw({type:"menu",prompt:prompt,multiSelect:true,items:items,withChat:withChat,countdown:countdown,placeholder:placeholder});
		/*#{1I0SA8EPB0PostCodes*/
		/*}#1I0SA8EPB0PostCodes*/
		/*#{1I0SA8EPB0FinCodes*/
		if(item){
			context.findVO.result=item.map((item)=>{return item.item;});
		}
		/*}#1I0SA8EPB0FinCodes*/
		return {seg:CheckItem,result:(result),preSeg:"1I0SA8EPB0",outlet:"1I0SA8EON2"};
	};
	ChooseItem.jaxId="1I0SA8EPB0"
	ChooseItem.url="ChooseItem@"+agentURL
	
	segs["TipMultiResult"]=TipMultiResult=async function(input){//:1I0SG8BA20
		let result=input;
		let opts={};
		let role="assistant";
		let content="Multiple result found:";
		session.addChatText(role,content,opts);
		context["results"]=input.result;
		return {seg:SnapPage,result:(result),preSeg:"1I0SG8BA20",outlet:"1I0SGAANJ0"};
	};
	TipMultiResult.jaxId="1I0SG8BA20"
	TipMultiResult.url="TipMultiResult@"+agentURL
	
	segs["SnapPage"]=SnapPage=async function(input){//:1I0SJFEAK0
		let result=null;
		let data=null;
		let pageVal=targetPage;
		let fullPage=false;
		let waitBefore=0;
		let waitAfter=0;
		let page=context[pageVal];
		waitBefore && (await sleep(waitBefore));
		/*#{1I0SJFEAK0PreCodes*/
		page=targetPage;
		/*}#1I0SJFEAK0PreCodes*/
		result=await page.screenshot({fullPage:fullPage});
		data=result.substring(result.indexOf(","))
		waitAfter && (await sleep(waitAfter));
		/*#{1I0SJFEAK0PostCodes*/
		/*}#1I0SJFEAK0PostCodes*/
		context["pageSnap"]=result;
		return {seg:LoopResult,result:(result),preSeg:"1I0SJFEAK0",outlet:"1I0SJIMO90"};
	};
	SnapPage.jaxId="1I0SJFEAK0"
	SnapPage.url="SnapPage@"+agentURL
	
	segs["CheckItem"]=CheckItem=async function(input){//:1I0TD4FJ10
		let result=input;
		if(!input || input.length===0){
			return {result:input};
		}
		return {seg:TestResult2,result:(result),preSeg:"1I0TD4FJ10",outlet:"1I0TD67IU1"};
	};
	CheckItem.jaxId="1I0TD4FJ10"
	CheckItem.url="CheckItem@"+agentURL
	
	segs["TipTarget"]=TipTarget=async function(input){//:1I0TDPQLR0
		let result=input;
		let opts={};
		let role="assistant";
		let content=`Will generate X-Path query to locate: "${input}"`;
		session.addChatText(role,content,opts);
		return {seg:Read2,result:(result),preSeg:"1I0TDPQLR0",outlet:"1I0TDQOS60"};
	};
	TipTarget.jaxId="1I0TDPQLR0"
	TipTarget.url="TipTarget@"+agentURL
	
	agent={
		isAIAgent:true,
		session:session,
		name:"SmartQuery",
		url:agentURL,
		autoStart:true,
		jaxId:"1I00BCBT10",
		context:context,
		livingSeg:null,
		execChat:async function(input/*{targetPage,query,aaeId}*/){
			let result;
			parseAgentArgs(input);
			/*#{1I00BCBT10PreEntry*/
			/*}#1I00BCBT10PreEntry*/
			result={seg:HasPage,"input":input};
			/*#{1I00BCBT10PostEntry*/
			/*}#1I00BCBT10PostEntry*/
			return result;
		},
		/*#{1I00BCBT10MoreAgentAttrs*/
		/*}#1I00BCBT10MoreAgentAttrs*/
	};
	/*#{1I00BCBT10PostAgent*/
	/*}#1I00BCBT10PostAgent*/
	return agent;
};
/*#{1I00BCBT10ExCodes*/
/*}#1I00BCBT10ExCodes*/

//#CodyExport>>>
//#CodyExport<<<
/*#{1I00BCBT10PostDoc*/
/*}#1I00BCBT10PostDoc*/


export default SmartQuery;
export{SmartQuery};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DocAIAgent",
//	"jaxId": "1I00BCBT10",
//	"attrs": {
//		"editObjs": {
//			"jaxId": "1I00BCBT11",
//			"attrs": {
//				"SmartQuery": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1I00BCBT20",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1I00BCBT21",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1I00BCBT22",
//							"attrs": {}
//						},
//						"functions": {
//							"jaxId": "1I00BCBT23",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false",
//						"exportClass": "false"
//					},
//					"mockups": {}
//				}
//			}
//		},
//		"agent": {
//			"jaxId": "1I00BCBT12",
//			"attrs": {}
//		},
//		"entry": "HasPage",
//		"autoStart": "true",
//		"inBrowser": "true",
//		"debug": "true",
//		"apiArgs": {
//			"jaxId": "1I00BCBT13",
//			"attrs": {
//				"targetPage": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I00BGSHQ0",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				},
//				"query": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I00BGSHQ1",
//					"attrs": {
//						"type": "String",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				},
//				"aaeId": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I022FCBA0",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1I00BCBT14",
//			"attrs": {
//				"pageHTML": {
//					"type": "string",
//					"valText": ""
//				},
//				"silence": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"RPALogger": {
//					"type": "auto",
//					"valText": "null"
//				}
//			}
//		},
//		"context": {
//			"jaxId": "1I00BCBT15",
//			"attrs": {
//				"maxRetry": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I0AEB6IF0",
//					"attrs": {
//						"type": "Integer",
//						"mockup": "3",
//						"desc": ""
//					}
//				},
//				"retry": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I0AEB6IF1",
//					"attrs": {
//						"type": "Integer",
//						"mockup": "0",
//						"desc": ""
//					}
//				},
//				"findVO": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I0T53I4Q0",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				},
//				"results": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I0SJIMOI0",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				},
//				"pageSnap": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I0SJJUMM0",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				}
//			}
//		},
//		"globalMockup": {
//			"jaxId": "1I00BCBT16",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "aiseg",
//					"def": "brunch",
//					"jaxId": "1I0AET6B00",
//					"attrs": {
//						"id": "HasPage",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "90",
//						"y": "345",
//						"desc": "This is an AISeg.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "Flag",
//						"context": {
//							"jaxId": "1I0AF25ML0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0AF25ML1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I0AF25M91",
//							"attrs": {
//								"id": "Default",
//								"desc": "Outlet.",
//								"output": "",
//								"ouput": {
//									"valText": ""
//								}
//							},
//							"linkedSeg": "1I01VBHFF0"
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I0AF25M90",
//									"attrs": {
//										"id": "NoPage",
//										"desc": "Outlet.",
//										"output": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I0AF25ML2",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I0AF25ML3",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#!targetPage",
//										"ouput": {
//											"valText": ""
//										}
//									},
//									"linkedSeg": "1I0AM1LOU0"
//								}
//							]
//						}
//					},
//					"icon": "condition.svg",
//					"reverseOutlets": true
//				},
//				{
//					"type": "aiseg",
//					"def": "QueryPage",
//					"jaxId": "1I0AM1LOU0",
//					"attrs": {
//						"id": "QueryPage",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "315",
//						"y": "275",
//						"desc": "This is an AISeg.",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0AM29PI0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0AM29PI1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I0AM29PD0",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I01VBHFF0"
//						}
//					},
//					"icon": "agent.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "brunch",
//					"jaxId": "1I01VBHFF0",
//					"attrs": {
//						"id": "CheckQuery",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "540",
//						"y": "360",
//						"desc": "This is an AISeg.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I01VGJ830",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I01VGJ831",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I01VGJ7T1",
//							"attrs": {
//								"id": "Default",
//								"desc": "Outlet.",
//								"output": ""
//							},
//							"linkedSeg": "1I0AEG8580"
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I022AD7S0",
//									"attrs": {
//										"id": "HasID",
//										"desc": "Condition outlet.",
//										"output": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I0A8KLTK0",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I0A8KLTK1",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "!!aaeId"
//									},
//									"linkedSeg": "1I022C89U0"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I01VGJ7T0",
//									"attrs": {
//										"id": "NoQuery",
//										"desc": "Condition outlet.",
//										"output": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I0A8KLTK2",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I0A8KLTK3",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#!query"
//									},
//									"linkedSeg": "1I01VE3PU0"
//								}
//							]
//						}
//					},
//					"icon": "condition.svg",
//					"reverseOutlets": true
//				},
//				{
//					"type": "aiseg",
//					"def": "askChat",
//					"jaxId": "1I01VE3PU0",
//					"attrs": {
//						"id": "AskQuery",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "830",
//						"y": "360",
//						"desc": "This is an AISeg.",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I01VGJ832",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I01VGJ833",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"tip": {
//							"type": "string",
//							"valText": "What do you want query? (e.g. \"The search button\", \"Result list\")",
//							"localize": {
//								"EN": "What do you want query? (e.g. \"The search button\", \"Result list\")",
//								"CN": "您想查询什么？（例如“搜索按钮”，“结果列表”）"
//							},
//							"localizable": true
//						},
//						"tipRole": "Assistant",
//						"placeholder": "",
//						"text": "",
//						"file": "false",
//						"showText": "true",
//						"outlet": {
//							"jaxId": "1I01VGJ7T2",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0TDPQLR0"
//						}
//					},
//					"icon": "chat.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "AAFReadPage",
//					"jaxId": "1I00BLB6E0",
//					"attrs": {
//						"id": "Read2",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "1265",
//						"y": "430",
//						"desc": "This is an AISeg.",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I00D1FFF0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I00D1FFF1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"page": "aaPage",
//						"target": "CleanHTML",
//						"node": "null",
//						"options": "{\"compact\":4,\"cleanMarks\":0}",
//						"waitBefore": "0",
//						"waitAfter": "0",
//						"outlet": {
//							"jaxId": "1I00D1FFA0",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I00BVJBN0"
//						},
//						"run": ""
//					},
//					"icon": "read.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "callLLM",
//					"jaxId": "1I00BVJBN0",
//					"attrs": {
//						"id": "AIQuery",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "1480",
//						"y": "430",
//						"desc": "Excute a LLM call.",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "Notify",
//						"context": {
//							"jaxId": "1I00D1FFF2",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I00D1FFF3",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"platform": "\"OpenAI\"",
//						"mode": "gpt-4o",
//						"system": "#`\n你是一个根据网页的HTML文本进行解析网页内容，定位复合用户描述的一个或者多个元素，并生成查找它们的X-Path指令表达式。\n\n- 每次对话开始时，用户会告诉你当前网页的HTML文本内容，以及用户需定位的元素的描述。\n\n- 在HTML元素标签的属性中有两个重要的辅助属性你需要注意：\n1）aaeid: 这是每个HTML元素唯一的ID，用来区分每一个HTML元素\n2）rect：这个属性描述的是元素在网页视图内的位置和尺寸信息，如果一个元素没有这个属性，则这个元素可能是不可见的。\n\n- 请用JSON回答用户，下面是一个实例：\n\\`\\`\\`\n{\n\t\"result\":[\"123\"],\n    \"query\":[\n    \t\"(//DIV[contains(@class,\"FileUpload_box\")])\",\n    \t\"(//DIV[@id=\"upload\"])\",\n\t]\n}\n\\`\\`\\`\n\n- \"result\"属性是一个包含查找到的元素的aaeid属性的数组。\n\n- \"reuslt\"里面每一项是一个复合用户需求的元素的aaeid属性的值。\n\n- 如果找不到复合用户描述的元素，把\"result\"属性为0长度的数组：[]。\n\n- \"query\"属性是你根据当前网页内容以及元素的属性特点，生成的可以用来定位复合需求的元素的X-Path搜索指令组。\n\n- \"query\"数组内的每一项是一种可以用来定位结果元素的X-Path指令，如果能找到复合描述的元素，请提供至少2种，最多5种不同的指令。\n\n- 生成的X-Path指令里，不能包含涉及aaeid和rect属性的内容。\n\n- 生成的X-Path指令，需要按照是否符合自然语言习惯进行排序，最符合自然语言习惯的表达式，排在最前面。\n\n- 你可以与用户进行多轮对话，每次根据用户的反馈修正并返回新的JSON。\n`",
//						"temperature": "0",
//						"maxToken": "2000",
//						"topP": "1",
//						"fqcP": "0",
//						"prcP": "0",
//						"messages": {
//							"attrs": []
//						},
//						"prompt": "#input",
//						"seed": "",
//						"outlet": {
//							"jaxId": "1I00D1FFB0",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I00DH8UQ0"
//						},
//						"secret": "false",
//						"allowCheat": "false",
//						"GPTCheats": {
//							"attrs": [
//								{
//									"type": "object",
//									"def": "GPTCheat",
//									"jaxId": "1I0CD5QIB0",
//									"attrs": {
//										"prompt": "",
//										"reply": "{\n\t\"result\": [\n\t\t\"621\",\n\t\t\"687\",\n\t\t\"751\",\n\t\t\"809\",\n\t\t\"927\",\n\t\t\"979\",\n\t\t\"1033\",\n\t\t\"1091\"\n\t],\n\t\"query\": [\n\t\t\"(//a[contains(@href, '/url?sa=t&source=web&')])\",\n\t\t\"(//a[contains(@ping, '/url?sa=t&source=web&')])\",\n\t\t\"(//a[@jsname='UWckNb'])\",\n\t\t\"(//a[contains(@class, 'EASEnb') and @aria-label])\",\n\t\t\"(//a[contains(@class, 'EASEnb PZPZlf Bb1JKe')])\"\n\t]\n}"
//									}
//								}
//							]
//						},
//						"shareChatName": "",
//						"keepChat": "20 messages",
//						"clearChat": "2",
//						"apiFiles": {
//							"attrs": []
//						},
//						"parallelFunction": "false",
//						"responseFormat": "json_object",
//						"formatDef": "\"\""
//					},
//					"icon": "llm.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1I00DH8UQ0",
//					"attrs": {
//						"id": "ShowJSON2",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "1705",
//						"y": "430",
//						"desc": "This is an AISeg.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I00DIT730",
//							"attrs": {
//								"cast": "{\"maxRetry\":\"\",\"retry\":\"\",\"findVO\":\"input\",\"results\":\"\",\"pageSnap\":\"\"}"
//							}
//						},
//						"global": {
//							"jaxId": "1I00DIT731",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "Assistant",
//						"text": "#`生成结果：\\n\\`\\`\\`\\n${JSON.stringify(input,null,\"\\t\")}\\n\\`\\`\\`\\n`",
//						"outlet": {
//							"jaxId": "1I00DIT6V0",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I022QPIT0"
//						}
//					},
//					"icon": "hudtxt.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "askConfirm",
//					"jaxId": "1I022C89U0",
//					"attrs": {
//						"id": "AskMode",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "790",
//						"y": "215",
//						"desc": "This is an AISeg.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"prompt": "Search selected element or input a new query",
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1I022C89E0",
//									"attrs": {
//										"id": "Selected",
//										"desc": "Outlet.",
//										"text": "Selected",
//										"result": "OK",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I0A8KLTK4",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I0A8KLTK5",
//											"attrs": {
//												"cast": ""
//											}
//										}
//									},
//									"linkedSeg": "1I022F5DE0"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1I022C89E1",
//									"attrs": {
//										"id": "Input",
//										"desc": "Outlet.",
//										"text": "Input",
//										"result": "Cancel",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I0A8KLTK6",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I0A8KLTK7",
//											"attrs": {
//												"cast": ""
//											}
//										}
//									},
//									"linkedSeg": "1I022KHCJ0"
//								}
//							]
//						},
//						"silent": "false"
//					},
//					"icon": "help.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "AAFReadPage",
//					"jaxId": "1I022F5DE0",
//					"attrs": {
//						"id": "Read1",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "1015",
//						"y": "-45",
//						"desc": "This is an AISeg.",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I022FCBA3",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I022FCBA4",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"page": "aaPage",
//						"target": "CleanHTML",
//						"node": "null",
//						"options": "{\"compact\":4,\"cleanMarks\":0}",
//						"waitBefore": "0",
//						"waitAfter": "0",
//						"outlet": {
//							"jaxId": "1I022FCB10",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I022LUPO0"
//						},
//						"run": ""
//					},
//					"icon": "read.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I022KHCJ0",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "910",
//						"y": "295",
//						"outlet": {
//							"jaxId": "1I023BU3Q0",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I01VE3PU0"
//						},
//						"dir": "R2L"
//					},
//					"icon": "arrowright.svg",
//					"isConnector": true
//				},
//				{
//					"type": "aiseg",
//					"def": "callLLM",
//					"jaxId": "1I022LUPO0",
//					"attrs": {
//						"id": "AICompile",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "1220",
//						"y": "-45",
//						"desc": "Excute a LLM call.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "Notify",
//						"context": {
//							"jaxId": "1I023BU3Q1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I023BU3Q2",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"platform": "OpenAI",
//						"mode": "gpt-4o",
//						"system": "#`\n你是一个根据网页的HTML文本进行解析网页内容，生成查找用户指定元素的X-Path指令表达式。\n\n- 在HTML元素标签的属性中有3个重要的辅助属性你需要注意：\n1）aaeid: 这是每个HTML元素唯一的索引ID，用来区分每一个HTML元素\n2）aaerect：这个属性描述的是元素在网页视图内的位置和尺寸信息，如果一个元素没有这个属性，则这个元素可能是不可见的。\n3）aaestyle：这个属性描述的是元素在网页视图内的最终CSS-Style。\n\n- 每次对话开始时，用户会告诉你当前网页的HTML文本内容，以及用户需定位的元素的索引ID（aaeid）。\n\n- 请用JSON回答用户，下面是一个实例：\n\\`\\`\\`\n{\n    \"query\":[\n    \t\"(//DIV[contains(@class,\"FileUpload_box\")])\",\n    \t\"(//DIV[@id=\"upload\"])\",\n\t]\n}\n\\`\\`\\`\n\n- \"query\"属性是你根据当前网页内容以及指定元素的属性特点，生成的可以用来定位复合需求的元素的X-Path搜索指令组。\n\n- \"query\"数组内的每一项是一种可以用来定位结果元素的X-Path指令，如果能找到复合描述的元素，请提供至少2种，最多10种不同的指令。\n\n- 生成的X-Path指令里，不能包含涉及aaeid、aaerect和aaestyle属性的内容。\n\n- 你生成的X-Path指令里必须包含至少一个只通过目标元素本身类型、属性进行查找的X-Path\n\n- 你生成的X-Path指令里必须包含至少一个通过完全的元素层级关系进行查找的X-Path\n\n- 非常重要：生成的X-Path指令，应该注意避免使用乱码或者没有意义的属性值（例如\"afjxk28\"、\"78yeumzh\"等），这样的属性值往往会发生变化，导致搜索指令失效，你可以截取属性值里有意义的部分，用“包含”模式查询。\n\n- 你可以与用户进行多轮对话，每次根据用户的反馈修正并返回新的JSON。\n`",
//						"temperature": "0",
//						"maxToken": "2000",
//						"topP": "1",
//						"fqcP": "0",
//						"prcP": "0",
//						"messages": {
//							"attrs": []
//						},
//						"prompt": "#input",
//						"seed": "",
//						"outlet": {
//							"jaxId": "1I023BU3H0",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I022NE1A0"
//						},
//						"secret": "false",
//						"allowCheat": "false",
//						"GPTCheats": {
//							"attrs": []
//						},
//						"shareChatName": "",
//						"keepChat": "No",
//						"clearChat": "2",
//						"apiFiles": {
//							"attrs": []
//						},
//						"parallelFunction": "false",
//						"responseFormat": "json_object",
//						"formatDef": "\"\""
//					},
//					"icon": "llm.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1I022NE1A0",
//					"attrs": {
//						"id": "ShowJSON1",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "1460",
//						"y": "-45",
//						"desc": "This is an AISeg.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I023BU3Q3",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I023BU3Q4",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "Assistant",
//						"text": "#`生成结果：\\n\\`\\`\\`\\n${JSON.stringify(input,null,\"\\t\")}\\n\\`\\`\\`\\n`",
//						"outlet": {
//							"jaxId": "1I023BU3H1",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I023070E0"
//						}
//					},
//					"icon": "hudtxt.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "brunch",
//					"jaxId": "1I022QPIT0",
//					"attrs": {
//						"id": "CheckResult",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "1950",
//						"y": "430",
//						"desc": "This is an AISeg.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I023BU3Q5",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I023BU3Q6",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I023BU3H3",
//							"attrs": {
//								"id": "Default",
//								"desc": "Outlet.",
//								"output": ""
//							},
//							"linkedSeg": "1I022S31H0"
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I0S9P6O10",
//									"attrs": {
//										"id": "FindMulti",
//										"desc": "输出节点。",
//										"output": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I0S9P6OB0",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I0S9P6OB1",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#input.result&&input.result.length>1&&(!silence)"
//									},
//									"linkedSeg": "1I0SG8BA20"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I023BU3H2",
//									"attrs": {
//										"id": "Found",
//										"desc": "Condition outlet.",
//										"output": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I0A8KLTL0",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I0A8KLTL1",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#input.result&&input.result.length>0"
//									},
//									"linkedSeg": "1I0AD8QU80"
//								}
//							]
//						}
//					},
//					"icon": "condition.svg",
//					"reverseOutlets": true
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1I022S31H0",
//					"attrs": {
//						"id": "ShowNotFound",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "2190",
//						"y": "630",
//						"desc": "This is an AISeg.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I023BU3Q7",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I023BU3Q8",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "Assistant",
//						"text": "AI can't find element in the page based on your query.",
//						"outlet": {
//							"jaxId": "1I023BU3H4",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0ADT3Q50"
//						}
//					},
//					"icon": "hudtxt.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "askChat",
//					"jaxId": "1I022T3620",
//					"attrs": {
//						"id": "AskFix",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "2725",
//						"y": "575",
//						"desc": "This is an AISeg.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I023BU3Q9",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I023BU3Q10",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"tip": "Please give more advice for searching element(s). Input \"end\" to abort this task",
//						"tipRole": "Assistant",
//						"placeholder": "",
//						"text": "",
//						"file": "false",
//						"showText": "true",
//						"outlet": {
//							"jaxId": "1I023BU3I0",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0DGQHPA0"
//						}
//					},
//					"icon": "chat.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I022UTAJ0",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "3105",
//						"y": "760",
//						"outlet": {
//							"jaxId": "1I023BU3Q11",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I022V6AK0"
//						},
//						"dir": "R2L"
//					},
//					"icon": "arrowright.svg",
//					"isConnector": true
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I022V6AK0",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "1505",
//						"y": "760",
//						"outlet": {
//							"jaxId": "1I023BU3Q12",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I00BVJBN0"
//						},
//						"dir": "R2L"
//					},
//					"icon": "arrowright.svg",
//					"isConnector": true
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I023070E0",
//					"attrs": {
//						"id": "TestResult1",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "1705",
//						"y": "-45",
//						"desc": "This is an AISeg.",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I023BU3Q13",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I023BU3Q14",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I023BU3I1",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0236HP70"
//						},
//						"result": "#input"
//					},
//					"icon": "tab_css.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "askMenu",
//					"jaxId": "1I0233DG30",
//					"attrs": {
//						"id": "ChooseQuery2",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "2190",
//						"y": "-60",
//						"desc": "This is an AISeg.",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "Run",
//						"prompt": "Please confirm",
//						"multi": "false",
//						"withChat": "false",
//						"outlet": {
//							"jaxId": "1IKNILKD30",
//							"attrs": {
//								"id": "ChatInput",
//								"desc": "输出节点。",
//								"codes": "false"
//							}
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1I0233DFF0",
//									"attrs": {
//										"id": "Next",
//										"desc": "Outlet.",
//										"text": "",
//										"result": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I0A8KLTL2",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I0A8KLTL3",
//											"attrs": {
//												"cast": ""
//											}
//										}
//									}
//								}
//							]
//						},
//						"silent": "false",
//						"context": {},
//						"global": {}
//					},
//					"icon": "menu.svg",
//					"reverseOutlets": true
//				},
//				{
//					"type": "aiseg",
//					"def": "brunch",
//					"jaxId": "1I0236HP70",
//					"attrs": {
//						"id": "IsResultOK1",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "1940",
//						"y": "-45",
//						"desc": "This is an AISeg.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I023BU3Q17",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I023BU3Q18",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I023BU3I3",
//							"attrs": {
//								"id": "Default",
//								"desc": "Outlet.",
//								"output": ""
//							},
//							"linkedSeg": "1I023CEKO0"
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I023BU3I2",
//									"attrs": {
//										"id": "OK",
//										"desc": "Condition outlet.",
//										"output": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I0A8KLTL4",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I0A8KLTL5",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#input"
//									},
//									"linkedSeg": "1I0233DG30"
//								}
//							]
//						}
//					},
//					"icon": "condition.svg",
//					"reverseOutlets": true
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1I023CEKO0",
//					"attrs": {
//						"id": "ShowFailed1",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "2215",
//						"y": "40",
//						"desc": "This is an AISeg.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I023DLEO0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I023DLEO1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "Assistant",
//						"text": "Queries generated by AI can't pass test.",
//						"outlet": {
//							"jaxId": "1I023DLEH0",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0F889I70"
//						}
//					},
//					"icon": "hudtxt.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I0AD8QU80",
//					"attrs": {
//						"id": "TestResult2",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "2245",
//						"y": "430",
//						"desc": "This is an AISeg.",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0ADBE610",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0ADBE611",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I0ADBE5N0",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0ADAOOU0"
//						},
//						"result": "#input"
//					},
//					"icon": "tab_css.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "brunch",
//					"jaxId": "1I0ADAOOU0",
//					"attrs": {
//						"id": "IsResultOK2",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "2475",
//						"y": "430",
//						"desc": "This is an AISeg.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0ADAOOV0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0ADAOOV1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I0ADAOOV2",
//							"attrs": {
//								"id": "Default",
//								"desc": "Outlet.",
//								"output": "",
//								"ouput": {
//									"valText": ""
//								}
//							},
//							"linkedSeg": "1I0ADCFB30"
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I0ADAOOV3",
//									"attrs": {
//										"id": "OK",
//										"desc": "Condition outlet.",
//										"output": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I0ADAOOV4",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I0ADAOOV5",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#input",
//										"ouput": {
//											"valText": ""
//										}
//									},
//									"linkedSeg": "1I0ADGFRA0"
//								}
//							]
//						}
//					},
//					"icon": "condition.svg",
//					"reverseOutlets": true
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1I0ADCFB30",
//					"attrs": {
//						"id": "ShowFailed2",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "2715",
//						"y": "445",
//						"desc": "This is an AISeg.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0ADDRGK0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0ADDRGK1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "Assistant",
//						"text": "No query passed check.",
//						"outlet": {
//							"jaxId": "1I0ADDRGD0",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0DE07ES0"
//						}
//					},
//					"icon": "hudtxt.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "brunch",
//					"jaxId": "1I0ADGFRA0",
//					"attrs": {
//						"id": "IsSilence1",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "2715",
//						"y": "360",
//						"desc": "This is an AISeg.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0ADIQ3J6",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0ADIQ3J7",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I0ADIQ3C1",
//							"attrs": {
//								"id": "Default",
//								"desc": "",
//								"output": "",
//								"ouput": {
//									"valText": "#input[0]"
//								}
//							},
//							"linkedSeg": "1I0CO0MFU0"
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I0ADIQ3C0",
//									"attrs": {
//										"id": "NotSilence",
//										"desc": "Outlet.",
//										"output": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I0ADIQ3J8",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I0ADIQ3J9",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#(!silence) && input.length>1",
//										"ouput": {
//											"valText": "#input"
//										}
//									},
//									"linkedSeg": "1I0ADEPSD0"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I0TED54L0",
//									"attrs": {
//										"id": "OneEntry",
//										"desc": "输出节点。",
//										"output": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I0TEG8280",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I0TEG8290",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": ""
//									},
//									"linkedSeg": "1I0ADIDM10"
//								}
//							]
//						}
//					},
//					"icon": "condition.svg",
//					"reverseOutlets": true
//				},
//				{
//					"type": "aiseg",
//					"def": "askMenu",
//					"jaxId": "1I0ADEPSD0",
//					"attrs": {
//						"id": "ChooseQuery",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "2975",
//						"y": "305",
//						"desc": "This is an AISeg.",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"prompt": {
//							"type": "string",
//							"valText": "Multiple X-Path query instructions can find the correct result, please select the one you think is more accurate.",
//							"localize": {
//								"EN": "Multiple X-Path query instructions can find the correct result, please select the one you think is more accurate.",
//								"CN": "多条X-Path查询指令可以找到正确的结果，请选择你认为更确切的一个。"
//							},
//							"localizable": true
//						},
//						"multi": "false",
//						"withChat": "false",
//						"outlet": {
//							"jaxId": "1IKNILKD40",
//							"attrs": {
//								"id": "ChatInput",
//								"desc": "输出节点。",
//								"codes": "false"
//							}
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1I0AEKGQI0",
//									"attrs": {
//										"id": "Result",
//										"desc": "Outlet.",
//										"text": "",
//										"result": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I0AEQH7G0",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I0AEQH7G1",
//											"attrs": {
//												"cast": ""
//											}
//										}
//									},
//									"linkedSeg": "1I0ADIDM10"
//								}
//							]
//						},
//						"silent": "false"
//					},
//					"icon": "menu.svg",
//					"reverseOutlets": true
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I0ADIDM10",
//					"attrs": {
//						"id": "CommitResult",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "3220",
//						"y": "360",
//						"desc": "This is an AISeg.",
//						"mkpInput": "$$input$$",
//						"segMark": "Run",
//						"context": {
//							"jaxId": "1I0ADIQ3J10",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0ADIQ3J11",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I0ADIQ3C2",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							}
//						},
//						"result": "#input"
//					},
//					"icon": "tab_css.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "brunch",
//					"jaxId": "1I0ADT3Q50",
//					"attrs": {
//						"id": "IsSilence2",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "2475",
//						"y": "630",
//						"desc": "This is an AISeg.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0ADT3Q51",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0ADT3Q52",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I0ADT3Q53",
//							"attrs": {
//								"id": "Default",
//								"desc": "Outlet.",
//								"output": ""
//							},
//							"linkedSeg": "1I0ADVL920"
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I0ADT3Q54",
//									"attrs": {
//										"id": "NotSilence",
//										"desc": "Outlet.",
//										"output": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I0ADT3Q55",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I0ADT3Q56",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#!silence"
//									},
//									"linkedSeg": "1I022T3620"
//								}
//							]
//						}
//					},
//					"icon": "condition.svg",
//					"reverseOutlets": true
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I0ADVL920",
//					"attrs": {
//						"id": "AutoFix",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "2725",
//						"y": "680",
//						"desc": "This is an AISeg.",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0AEB6IG0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0AEB6IG1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I0AEB6I90",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0AE1CP40"
//						},
//						"result": "找不到符合的元素，看看有没有类似的元素。"
//					},
//					"icon": "tab_css.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "brunch",
//					"jaxId": "1I0AE1CP40",
//					"attrs": {
//						"id": "CheckRetry",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "3430",
//						"y": "680",
//						"desc": "This is an AISeg.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0AEB6IG2",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0AEB6IG3",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I0AEB6I92",
//							"attrs": {
//								"id": "Default",
//								"desc": "Outlet.",
//								"output": ""
//							},
//							"linkedSeg": "1I0AE5Q090"
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I0AEB6I91",
//									"attrs": {
//										"id": "MaxRetry",
//										"desc": "Outlet.",
//										"output": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I0AEB6IG4",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I0AEB6IG5",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#(context.retry++)>context.maxRetry"
//									},
//									"linkedSeg": "1I0AE3P1P0"
//								}
//							]
//						}
//					},
//					"icon": "condition.svg",
//					"reverseOutlets": true
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I0AE3P1P0",
//					"attrs": {
//						"id": "FailResult",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "3745",
//						"y": "665",
//						"desc": "This is an AISeg.",
//						"mkpInput": "$$input$$",
//						"segMark": "Run",
//						"context": {
//							"jaxId": "1I0AEB6IG6",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0AEB6IG7",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I0AEB6I93",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							}
//						},
//						"result": "#input"
//					},
//					"icon": "tab_css.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I0AE5Q090",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "3590",
//						"y": "760",
//						"outlet": {
//							"jaxId": "1I0AEB6IG8",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I022UTAJ0"
//						},
//						"dir": "R2L"
//					},
//					"icon": "arrowright.svg",
//					"isConnector": true
//				},
//				{
//					"type": "aiseg",
//					"def": "connectorL",
//					"jaxId": "1I0AEG8580",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "790",
//						"y": "430",
//						"outlet": {
//							"jaxId": "1I0AEGOKG2",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0TDPQLR0"
//						},
//						"dir": "L2R"
//					},
//					"icon": "arrowright.svg",
//					"isConnector": true
//				},
//				{
//					"type": "aiseg",
//					"def": "callLLM",
//					"jaxId": "1I0CO0MFU0",
//					"attrs": {
//						"id": "RankQuery",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "2975",
//						"y": "405",
//						"desc": "Excute a LLM call.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "faces.svg",
//						"context": {
//							"jaxId": "1I0COA8RC0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0COA8RC1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"platform": "\"OpenAI\"",
//						"mode": "gpt-4o",
//						"system": "你是一个评判X-Path表达式是否符合自然语言习惯的AI\n\n- 每轮对话时，用户会输入包含一个或多个X-Path表达式数组，你从中挑选一个最符合自然语言习惯的。\n\n- 使用自然语言词汇、简写进行查询是更符合自然语言习惯的\n\n- 使用无规律的的字母/数字组合进行查询，是不符合自然语言习惯的\n\n- 回答问题时，按照符合自然语言习惯的程度把输入的数组进行排序，并用JSON格式返回。\n```\n{\n  \"sorted\":[\n      \"(//div[@jsname='header'])\",\n      \"(//div[@class='xxb89header'])\",\n      \"(//div[@dcd='xcxbar98vj8sa89ab'])\"\n  ]\n}\n```\n- 把排序后的数组放作为返回JSON的\"sorted\"属性。\n",
//						"temperature": "0",
//						"maxToken": "2000",
//						"topP": "1",
//						"fqcP": "0",
//						"prcP": "0",
//						"messages": {
//							"attrs": []
//						},
//						"prompt": "#`${JSON.stringify(input)}`",
//						"seed": "",
//						"outlet": {
//							"jaxId": "1I0COA8R70",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0ADIDM10"
//						},
//						"secret": "false",
//						"allowCheat": "false",
//						"GPTCheats": {
//							"attrs": []
//						},
//						"shareChatName": "",
//						"keepChat": "No",
//						"clearChat": "2",
//						"apiFiles": {
//							"attrs": []
//						},
//						"parallelFunction": "false",
//						"responseFormat": "json_object",
//						"formatDef": "\"\""
//					},
//					"icon": "llm.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "brunch",
//					"jaxId": "1I0DE07ES0",
//					"attrs": {
//						"id": "IsSilence3",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "2975",
//						"y": "515",
//						"desc": "This is an AISeg.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0DE07ES1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0DE07ES2",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I0DE07ES3",
//							"attrs": {
//								"id": "Default",
//								"desc": "",
//								"output": "",
//								"ouput": {
//									"valText": "#input[0]"
//								}
//							},
//							"linkedSeg": "1I0DE1FI10"
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I0DE07ES4",
//									"attrs": {
//										"id": "NotSilence",
//										"desc": "Outlet.",
//										"output": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I0DE07ES5",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I0DE07ES6",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#!silence",
//										"ouput": {
//											"valText": "#input"
//										}
//									},
//									"linkedSeg": "1I0DE2E2I0"
//								}
//							]
//						}
//					},
//					"icon": "condition.svg",
//					"reverseOutlets": true
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I0DE1FI10",
//					"attrs": {
//						"id": "AutoFix2",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "3220",
//						"y": "565",
//						"desc": "This is an AISeg.",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0DE3ISM0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0DE3ISM1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I0DE3ISF0",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0AE1CP40"
//						},
//						"result": "#input"
//					},
//					"icon": "tab_css.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "askChat",
//					"jaxId": "1I0DE2E2I0",
//					"attrs": {
//						"id": "AskFix2",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "3220",
//						"y": "455",
//						"desc": "This is an AISeg.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0DE3ISM2",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0DE3ISM3",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"tip": "",
//						"tipRole": "Assistant",
//						"placeholder": "",
//						"text": "",
//						"file": "false",
//						"showText": "true",
//						"outlet": {
//							"jaxId": "1I0DE3ISF1",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0DE38IP0"
//						}
//					},
//					"icon": "chat.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "brunch",
//					"jaxId": "1I0DE38IP0",
//					"attrs": {
//						"id": "CheckEnd",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "3440",
//						"y": "455",
//						"desc": "This is an AISeg.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0DE3ISM4",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0DE3ISM5",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I0DE3ISF3",
//							"attrs": {
//								"id": "Default",
//								"desc": "Outlet.",
//								"output": ""
//							},
//							"linkedSeg": "1I0AE5Q090"
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I0DE3ISF2",
//									"attrs": {
//										"id": "End",
//										"desc": "Outlet.",
//										"output": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I0DE3ISM6",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I0DE3ISM7",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#input.toLowerCase()===\"end\""
//									},
//									"linkedSeg": "1I0AE3P1P0"
//								}
//							]
//						}
//					},
//					"icon": "condition.svg",
//					"reverseOutlets": true
//				},
//				{
//					"type": "aiseg",
//					"def": "brunch",
//					"jaxId": "1I0DGQHPA0",
//					"attrs": {
//						"id": "CheckEnd2",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "2925",
//						"y": "625",
//						"desc": "This is an AISeg.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0DGVEQL0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0DGVEQL1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I0DGVEQF1",
//							"attrs": {
//								"id": "Query Again",
//								"desc": "Outlet.",
//								"output": ""
//							},
//							"linkedSeg": "1I022UTAJ0"
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I0DGVEQF0",
//									"attrs": {
//										"id": "End",
//										"desc": "Outlet.",
//										"output": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I0DGVEQL2",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I0DGVEQL3",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#input.toLowerCase()===\"end\""
//									},
//									"linkedSeg": "1I0DGTB5V0"
//								}
//							]
//						}
//					},
//					"icon": "condition.svg",
//					"reverseOutlets": true
//				},
//				{
//					"type": "aiseg",
//					"def": "connectorL",
//					"jaxId": "1I0DGTB5V0",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "3255",
//						"y": "805",
//						"outlet": {
//							"jaxId": "1I0DGVEQL4",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0DGTLQK0"
//						},
//						"dir": "L2R"
//					},
//					"icon": "arrowright.svg",
//					"isConnector": true
//				},
//				{
//					"type": "aiseg",
//					"def": "connectorL",
//					"jaxId": "1I0DGTLQK0",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "3575",
//						"y": "805",
//						"outlet": {
//							"jaxId": "1I0DGVEQL5",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0AE3P1P0"
//						},
//						"dir": "L2R"
//					},
//					"icon": "arrowright.svg",
//					"isConnector": true
//				},
//				{
//					"type": "aiseg",
//					"def": "askChat",
//					"jaxId": "1I0F889I70",
//					"attrs": {
//						"id": "AskFix3",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "2460",
//						"y": "-25",
//						"desc": "This is an AISeg.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0F8E4CV0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0F8E4CV1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"tip": "Please give some advice to fix, or type \"end\" to abort.",
//						"tipRole": "Assistant",
//						"placeholder": "",
//						"text": "",
//						"file": "false",
//						"showText": "true",
//						"outlet": {
//							"jaxId": "1I0F8E4CL0",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0F8A6SO0"
//						}
//					},
//					"icon": "chat.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "brunch",
//					"jaxId": "1I0F8A6SO0",
//					"attrs": {
//						"id": "CheckEnd3",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "2680",
//						"y": "-25",
//						"desc": "This is an AISeg.",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0F8A6SO1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0F8A6SO2",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I0F8A6SO3",
//							"attrs": {
//								"id": "Query Again",
//								"desc": "Outlet.",
//								"output": ""
//							},
//							"linkedSeg": "1I0F8CMVJ0"
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I0F8A6SO4",
//									"attrs": {
//										"id": "End",
//										"desc": "Outlet.",
//										"output": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I0F8A6SO5",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I0F8A6SO6",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#input.toLowerCase()===\"end\""
//									},
//									"linkedSeg": "1I0F8B30I0"
//								}
//							]
//						}
//					},
//					"icon": "condition.svg",
//					"reverseOutlets": true
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I0F8B30I0",
//					"attrs": {
//						"id": "FailResult2",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "3020",
//						"y": "-40",
//						"desc": "This is an AISeg.",
//						"mkpInput": "$$input$$",
//						"segMark": "Run",
//						"context": {
//							"jaxId": "1I0F8B30I1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0F8B30I2",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I0F8B30I3",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							}
//						},
//						"result": "#input"
//					},
//					"icon": "tab_css.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I0F8CMVJ0",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "2850",
//						"y": "-140",
//						"outlet": {
//							"jaxId": "1I0F8E4CV2",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I0F8D81Q0"
//						},
//						"dir": "R2L"
//					},
//					"icon": "arrowright.svg",
//					"isConnector": true
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I0F8D81Q0",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "1250",
//						"y": "-140",
//						"outlet": {
//							"jaxId": "1I0F8E4CV3",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1I022LUPO0"
//						},
//						"dir": "R2L"
//					},
//					"icon": "arrowright.svg",
//					"isConnector": true
//				},
//				{
//					"type": "aiseg",
//					"def": "loopArray",
//					"jaxId": "1I0SA1UM00",
//					"attrs": {
//						"id": "LoopResult",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "2695",
//						"y": "155",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0SA5OV20",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0SA5OV21",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"loopArray": "#context.results",
//						"method": "forEach",
//						"outlet": {
//							"jaxId": "1I0SA5OUS0",
//							"attrs": {
//								"id": "Looper",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I0SA770Q0"
//						},
//						"catchlet": {
//							"jaxId": "1I0SA5OUS1",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I0SA8EPB0"
//						}
//					},
//					"icon": "loop_array.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "image",
//					"jaxId": "1I0SA770Q0",
//					"attrs": {
//						"id": "DrawItem",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "2935",
//						"y": "95",
//						"desc": "这是一个AISeg。",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0SAAPBN0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0SAAPBN1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"text": "#`Element ${input}`",
//						"image": "#context.pageSnap",
//						"role": "Assistant",
//						"sizeLimit": "512",
//						"format": "PNG",
//						"outlet": {
//							"jaxId": "1I0SAAPBD0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							}
//						},
//						"codeDraw": "true"
//					},
//					"icon": "hudimg.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "askMenu",
//					"jaxId": "1I0SA8EPB0",
//					"attrs": {
//						"id": "ChooseItem",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "2935",
//						"y": "170",
//						"desc": "这是一个AISeg。",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"prompt": {
//							"type": "string",
//							"valText": "Please select the correct element(s). If the correct one is not listed, do not select any element.",
//							"localize": {
//								"EN": "Please select the correct element(s). If the correct one is not listed, do not select any element.",
//								"CN": "请选择正确的元素，如果正确的没有被列出，请不要选择任何元素。"
//							},
//							"localizable": true
//						},
//						"multi": "true",
//						"withChat": "false",
//						"outlet": {
//							"jaxId": "1IKNILKDC0",
//							"attrs": {
//								"id": "ChatInput",
//								"desc": "输出节点。",
//								"codes": "false"
//							}
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1I0SA8EON2",
//									"attrs": {
//										"id": "Result",
//										"desc": "输出节点。",
//										"text": "",
//										"result": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I0SAAPBN2",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I0SAAPBN3",
//											"attrs": {
//												"cast": ""
//											}
//										}
//									},
//									"linkedSeg": "1I0TD4FJ10"
//								}
//							]
//						},
//						"silent": "false"
//					},
//					"icon": "menu.svg",
//					"reverseOutlets": true
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I0SA9J320",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "3310",
//						"y": "245",
//						"outlet": {
//							"jaxId": "1I0SAAPBN4",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I0SAA28I0"
//						},
//						"dir": "R2L"
//					},
//					"icon": "arrowright.svg",
//					"isConnector": true
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I0SAA28I0",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "2405",
//						"y": "245",
//						"outlet": {
//							"jaxId": "1I0SAAPBN5",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I0SG9TG70"
//						},
//						"dir": "R2L"
//					},
//					"icon": "arrowright.svg",
//					"isConnector": true
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1I0SG8BA20",
//					"attrs": {
//						"id": "TipMultiResult",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "2190",
//						"y": "155",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0SGAAO00",
//							"attrs": {
//								"cast": "{\"maxRetry\":\"\",\"retry\":\"\",\"results\":\"#input.result\"}"
//							}
//						},
//						"global": {
//							"jaxId": "1I0SGAAO01",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "Assistant",
//						"text": "Multiple result found:",
//						"outlet": {
//							"jaxId": "1I0SGAANJ0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I0SJFEAK0"
//						}
//					},
//					"icon": "hudtxt.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I0SG9TG70",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "2275",
//						"y": "350",
//						"outlet": {
//							"jaxId": "1I0SGAAO02",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I0AD8QU80"
//						},
//						"dir": "R2L"
//					},
//					"icon": "arrowright.svg",
//					"isConnector": true
//				},
//				{
//					"type": "aiseg",
//					"def": "AAFCapturePage",
//					"jaxId": "1I0SJFEAK0",
//					"attrs": {
//						"id": "SnapPage",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "2455",
//						"y": "155",
//						"desc": "这是一个AISeg。",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0SJIMOJ0",
//							"attrs": {
//								"cast": "{\"maxRetry\":\"\",\"retry\":\"\",\"results\":\"\",\"pageSnap\":\"result\"}"
//							}
//						},
//						"global": {
//							"jaxId": "1I0SJIMOJ1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"page": "#targetPage",
//						"fullPage": "false",
//						"dataURL": "true",
//						"waitBefore": "0",
//						"waitAfter": "0",
//						"outlet": {
//							"jaxId": "1I0SJIMO90",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I0SA1UM00"
//						}
//					},
//					"icon": "/@aae/assets/tab_cam.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "brunch",
//					"jaxId": "1I0TD4FJ10",
//					"attrs": {
//						"id": "CheckItem",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "3160",
//						"y": "170",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0TD67JF0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0TD67JF1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I0TD67IU1",
//							"attrs": {
//								"id": "Default",
//								"desc": "输出节点。",
//								"output": ""
//							},
//							"linkedSeg": "1I0SA9J320"
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I0TD67IU0",
//									"attrs": {
//										"id": "NoItem",
//										"desc": "输出节点。",
//										"output": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I0TD67JF2",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I0TD67JF3",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#!input || input.length===0"
//									}
//								}
//							]
//						}
//					},
//					"icon": "condition.svg",
//					"reverseOutlets": true
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1I0TDPQLR0",
//					"attrs": {
//						"id": "TipTarget",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "1045",
//						"y": "430",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I0TDQOSI0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I0TDQOSI1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "Assistant",
//						"text": "#`Will generate X-Path query to locate: \"${input}\"`",
//						"outlet": {
//							"jaxId": "1I0TDQOS60",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I00BLB6E0"
//						}
//					},
//					"icon": "hudtxt.svg"
//				}
//			]
//		},
//		"desc": "This is an AI agent.",
//		"exportAPI": "false",
//		"exportAddOn": "false",
//		"addOnOpts": ""
//	}
//}