export default `
### 《执行指令规则》
步骤JSON的"execute"属性是下一步要执行操作的"动作描述对象"，根据要执行的动作，"动作描述对象"有不同的属性：

- "动作描述对象"属性"desc": 用自然语言，简洁明确的描述的本次执行的内容。例如："点击'开始对话按钮'", "打开网址：'www.supersite.com/nextmove/'"

- "动作描述对象"属性"action"是下一步操作的操作类型，目前可以选择的操作类型有：
	1. "ClickUpload"：通过"queryHint"定位并点击触发文件上传的元素，在"fileName"里指定上传的文件名
    2. "Click": 通过"queryHint"定位并点击一个元素
    3. "Type"输入文本，需要先通过"Click"动作激活输入的目标
    4. "Hover"将鼠标移动到由"queryHint"定位的某个元素上方悬停
    5. "PressKey"发送单个按键操作，不能指定queryHint
    6. "Goto"让当前页面进入指定的URL
    7. "Read"读取并总结当前页面的内容

- "动作描述对象"属性"fileName": 类型：拼装字符串
	- 在"ClickUpload"操作执行时，会导致页面要求用户选择一个文件上传，把要上传的文件名放在"fileName"属性里。"fileName"是在"execData"里的文件名变量的拼装表达式例如: "#\$\{execData.file\}", "#\$\{execData.image3}"。
	- 字符串以"#"开头，用\$\{\}定义JS表达式。例如 "#\$\{execData.photo\}", "#\$\{execData.images[2]\}"...
	- 其它操作不会引起打开文件操作，这个变量设置为空字符串。
	
- "动作描述对象"属性"queryHint": 类型：字符串
    - 当action为"Click"、"ClickUpload"或者"Hover"时，这个属性里是对目标点击元素的自然语言描述。例如: "登录按钮", "贴子内容输入框"等。描述要尽量准确，确保通过描述可以找到正确的目标元素。
	- 当action为其它时，不包含这个属性。

- "动作描述对象"属性"content": 类型：字符串或拼装字符串
	- 当action为"Type"时，这个属性里是要输入的文本。当action为其它时，不包含这个属性。
	- "content"可以是一个关于execData内容的拼装字符串：在这种情况下，字符串以"#"开头，用\$\{\}定义JS表达式。例如 "#\$\{execData.text\}", "#\$\{execData.size+10\}"...
	- 尽量使用拼装模式引用execData里的内容。
	- 注意：如果content不是拼装字符串，不要用"#"开头

- "动作描述对象"属性"key": 类型：字符串
	- 当action为"PressKey"按键代码，例如"Enter"代表回车键。其它action，不包含这个属性。

- "动作描述对象"属性"url": 类型：字符串
	- 当action为"Goto"时，目标网页URL。其它action，不包含这个属性。

- "动作描述对象"属性"summary": 字符串类型
	- 当action为"Read"时，需要进行总结的目标内容。其它action，不包含这个属性

- "动作描述对象"属性"willNavi": 类型：布尔
	- 如果这个操作执行完毕后，会导致页面跳转，这个属性要设置为true。
	
---
- 例子1: 上传一张图片: 
\`\`\`
{
	"execute": {
		"desc": "Click on the '图片' button to upload 3rd image.",
		"action": "ClickUpload",
		"queryHint": "图片 button",
		"willNavi": false,
		"fileName": "\$\{execData.images[2]\}"
	},
	"result": null,
	"abort": false
}
\`\`\`

- 例子2: 点击信件按钮: 
\`\`\`
{
	"execute": {
		"desc": "Click on the mail button",
		"action": "Click",
		"queryHint": "Mail button",
		"willNavi": true,
		"fileName": ""
	},
	"result": null,
	"abort": false
}
\`\`\`

- 例子3: 输入问题: 
\`\`\`
{
	"execute": {
		"desc": "Input question",
		"action": "Type",
		"content": "#\$\{execData.questionToAsk\}"
		"willNavi": false,
		"fileName": ""
	},
	"result": null,
	"abort": false
}
\`\`\`

`;