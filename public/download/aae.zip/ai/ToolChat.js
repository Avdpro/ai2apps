//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import pathLib from "/@path";
import inherits from "/@inherits";
import Base64 from "/@tabos/utils/base64.js";
import {trimJSON} from "/@aichat/utils.js";
/*#{1I1L1U8U20MoreImports*/
import {tabFS,tabNT} from "/@tabos";
import {AATools} from "/@tabos/AATools.js";
import {RemoteSession} from "/@aichat/remotesession.js";
/*}#1I1L1U8U20MoreImports*/
const agentURL=(new URL(import.meta.url)).pathname;
const basePath=pathLib.dirname(agentURL);
const $ln=VFACT.lanCode||"EN";
const argsTemplate={
	properties:{
		"command":{
			"name":"command","type":"string",
			"defaultValue":"",
			"desc":"Command to execute",
		}
	},
	/*#{1I1L1U8U20ArgsView*/
	/*}#1I1L1U8U20ArgsView*/
};

/*#{1I1L1U8U20StartDoc*/
let topWindow;
topWindow=window;
while(topWindow && topWindow.parent && topWindow.parent!==topWindow){
	topWindow=topWindow.parent;
}
const topVFACT=topWindow.VFACT;
let tempDirPath;
//----------------------------------------------------------------------------
async function setupTempDir(glbCtx){
	let baseName,dirPath,cnt;
	if(!glbCtx.exechangeRes){
		glbCtx.exechangeRes={};
	}
	if(glbCtx.tempDirPath){
		tempDirPath=glbCtx.tempDirPath;
		return;
	}
	cnt=0;
	dirPath=baseName="/doc/Temp/TEMP_"+Date.now();
	do{
		if(!(await tabFS.isExist(dirPath))){
			break;
		}
		cnt+=1;
		dirPath=baseName+cnt;
	}while(1);
	await tabFS.newDir(dirPath);
	glbCtx.tempDirPath=tempDirPath=dirPath;
	return dirPath;
};
async function clearTempDir(path){
	path=path||tempDirPath;
	try{
		await tabFS.del(path);
	}catch(err){
	}
};
/*}#1I1L1U8U20StartDoc*/
//----------------------------------------------------------------------------
let ToolChat=async function(session){
	let command;
	const $ln=session.language||"EN";let context,globalContext;
	let self;
	let BuildToolsIndex,ChooseTool,CheckTool,PickTool,ShowTool,RunTool,ShowToolResult,pushToolMessage,ShowResult,ShowReply,ShowAbort,ShowFinish,ShowMissing,AskCreate,CallTool,LogToolError,StartTip,ResetMsg,AskNewCmd,CreeateTool,ReloadTools,NextMenu,ExitChat,CallNode,RunNode,LogNodeError,ShowNodeResult,pushNodeMessage,ShowTaskLog,DoAsk;
	/*#{1I1L1U8U20LocalVals*/
	/*}#1I1L1U8U20LocalVals*/
	
	function parseAgentArgs(input){
		if(typeof(input)=='object'){
			command=input.command;
		}else{
			command=undefined;
		}
		/*#{1I1L1U8U20ParseArgs*/
		/*}#1I1L1U8U20ParseArgs*/
	}
	
	/*#{1I1L1U8U20PreContext*/
	async function resetTaskLog(){
		let logs=globalContext.taskLogs;
		if(logs){
			globalContext.taskLogs=[];
		}
		return logs;
	}
	async function addTaskLog(log){
		let logs=globalContext.taskLogs;
		if(!logs){
			logs=globalContext.taskLogs=[];
		}
		logs.push(log);
	}
	/*}#1I1L1U8U20PreContext*/
	globalContext=session.globalContext;
	context={
		aaTools: null,
		toolsIndexVO: {"a":"b"},
		curTool: null,
		taskRound: 0,
		agentNodes: [],
		nodesIndexVO: {},
		callNode: null,
		/*#{1I1L1U8U25ExCtxAttrs*/
		/*}#1I1L1U8U25ExCtxAttrs*/
	};
	context=VFACT.flexState(context);
	/*#{1I1L1U8U20PostContext*/
	if(!globalContext.resetTaskLog){
		globalContext.resetTaskLog=resetTaskLog;
		globalContext.addTaskLog=addTaskLog;
	}
	await setupTempDir(globalContext);
	/*}#1I1L1U8U20PostContext*/
	let agent,segs={};
	segs["BuildToolsIndex"]=BuildToolsIndex=async function(input){//:1I1L1UN1D0
		let result=input
		/*#{1I1L1UN1D0Code*/
		let tools,saveVO;
		tools=context.aaTools=new AATools();
		await tools.load();
		context.toolsIndexVO=tools.getToolDescIndex();
		console.log("Tools index:");
		console.log(context.toolsIndexVO);
		
		//Build agentNodes info:
		{
			let res,nodes;
			nodes=context.agentNodes={};
			res=await tabNT.makeCall("AhListAgentNodes",{});
			if(res && res.code===200){
				let list,node;
				list=res.nodes;
				for(node of list){
					nodes[node.name]={
						"descritption":node.description,
						"workload":node.workload
					}
				}
			}
			console.log("Nodes index:");
			console.log(nodes);
		}
		result=command;
		/*}#1I1L1UN1D0Code*/
		return {seg:StartTip,result:(result),preSeg:"1I1L1UN1D0",outlet:"1I1L26LKH0"};
	};
	BuildToolsIndex.jaxId="1I1L1UN1D0"
	BuildToolsIndex.url="BuildToolsIndex@"+agentURL
	
	segs["ChooseTool"]=ChooseTool=async function(input){//:1I1L2072D0
		let prompt;
		let result=null;
		/*#{1I1L2072D0Input*/
		/*}#1I1L2072D0Input*/
		
		let opts={
			platform:"OpenAI",
			mode:"gpt-4o",
			maxToken:2000,
			temperature:0,
			topP:1,
			fqcP:0,
			prcP:0,
			secret:false,
			responseFormat:"json_object"
		};
		let chatMem=ChooseTool.messages
		let seed="";
		if(seed!==undefined){opts.seed=seed;}
		let messages=[
			{role:"system",content:`
你是一个根据用户输入，选择适合的Tool(本地智能体)或Node(外部智能体节点)运行，与用户对话，完成任务的AI。
当前的Tools（本地智能体工具）有:
${JSON.stringify(context.toolsIndexVO,null,"\t")}
当前的Nodes（外部智能体节点）有:
${JSON.stringify(context.agentNodes,null,"\t")}

- 第一轮对话时，用户输入的是要完成的任务，你根据用户的输入，选择合适的Tool

- 每一回合对话，跟根据当前任务执行的情况，回复一个JSON对象。
- 如果需要执行一个Tool，回复JSON中的"tool"属性是下一步要执行的Tool(智能体)的名称; 回复JSON中的prompt属性是调用这个Tool的输入指令。例如：
{
	"tool":"Tool-3",
    "prompt":"Search for: Who is the winner of 2024 F1?"
}

- 如果需要执行一个Node，回复JSON中的"node"属性是下一步要执行的Node（外部智能体）的名称; 回复JSON中的prompt属性是调用这个Tool的输入指令。例如：
{
	"node":"DrawNode",
    "prompt":"Draw picture of a cute fat cat."
}

- 执行Tool或Node的结果会在对话中告知。你根据任务目标以及当前的执行情况，可能需要继续选择新的Tool/Node进一步执行。

- 如果同时有Tool和Node可以执行当前的任务需求，优先使用Tool，如果Tool执行失败或无法完成任务再尝试Node。

- 如果成功的完成了用户提出的任务，回复将JSON中的"finish"属性设置为true。并通过"result"属性总结汇报执行情况。例如
{
	"finish":true,
    "result":"论坛帖子已经成功发布。"
}

- 如果执行Tool出现错误，你认为无法完成用户的任务，设置回复JSON中的"abort"属性为true，并在"reason"属性中说明原因。例如:
{
	"abort":true,
    "reason":"没有登录脸书账号，无法发布新的内容。"
}

- 如果没有Tool或Node可以完成用户的要求，请设计一个或多个用来完成用户需求的Tool，在回复JSON中用"missingTools"数组属性里描述缺失的Tool。例如：
{
	"missingTools":[
    	"检查脸书账号登录状态",
        "发布脸书动态"
    ]
}

- 如果回答用户的输入不需要使用任何tool，用回复JSON中的"replay"属性回答用户，如果对话已结束，同时设置"finish"属性为true。例如：当用户询问："西瓜是一种水果么？"，你的回复：
{
	"finish":true,
	"result":"是的，西瓜是一种水果。"
}

- 如果执行任务需要用户提供更多的信息，用回复JSON中的"ask"属性询问用户，同时设置finish属性为false。例如，需要用户
提供邮箱地址：
{
	"finish":false,
	"ask":"请告诉我你的电子邮箱地址"
}
`},
		];
		messages.push(...chatMem);
		/*#{1I1L2072D0PrePrompt*/
		if(input instanceof Error){
			input=""+input;
			if(input.stack){
				input+="\nCall-stack:\n"+input.stack;
			}
		}
		/*}#1I1L2072D0PrePrompt*/
		prompt=input;
		if(prompt!==null){
			if(typeof(prompt)!=="string"){
				prompt=JSON.stringify(prompt,null,"	");
			}
			messages.push({role:"user",content:prompt});
		}
		/*#{1I1L2072D0PreCall*/
		/*}#1I1L2072D0PreCall*/
		result=(result===null)?(await session.callSegLLM("ChooseTool@"+agentURL,opts,messages,true)):result;
		/*#{1I1L2072D0PostLLM*/
		/*}#1I1L2072D0PostLLM*/
		chatMem.push({role:"user",content:prompt});
		chatMem.push({role:"assistant",content:result});
		if(chatMem.length>50){
			let removedMsgs=chatMem.splice(0,2);
			/*#{1I1L2072D0PostClear*/
			/*}#1I1L2072D0PostClear*/
		}
		result=trimJSON(result);
		/*#{1I1L2072D0PostCall*/
		/*}#1I1L2072D0PostCall*/
		return {seg:CheckTool,result:(result),preSeg:"1I1L2072D0",outlet:"1I1L26LKI0"};
	};
	ChooseTool.jaxId="1I1L2072D0"
	ChooseTool.url="ChooseTool@"+agentURL
	ChooseTool.messages=[];
	
	segs["CheckTool"]=CheckTool=async function(input){//:1I1L20SLD0
		let result=input;
		/*#{1I1L20SLD0Start*/
		console.log("Choose Tool:");
		console.log(input);
		/*}#1I1L20SLD0Start*/
		if(input.missingTools){
			return {seg:ShowMissing,result:(input),preSeg:"1I1L20SLD0",outlet:"1I1L4HCRJ0"};
		}
		if(input.node){
			let output=input;
			return {seg:CallNode,result:(output),preSeg:"1I1L20SLD0",outlet:"1IDOTLSQJ0"};
		}
		if(input.tool){
			let output=input;
			return {seg:CallTool,result:(output),preSeg:"1I1L20SLD0",outlet:"1I1L26LKI1"};
		}
		if(input.finish&&input.result){
			let output=input.result;
			return {seg:ShowFinish,result:(output),preSeg:"1I1L20SLD0",outlet:"1I1L4HMHK0"};
		}
		if(input.abort){
			let output=input.reason;
			return {seg:ShowAbort,result:(output),preSeg:"1I1L20SLD0",outlet:"1I1L4HSMS0"};
		}
		if(input.ask){
			let output=input.ask;
			return {seg:DoAsk,result:(output),preSeg:"1I1L20SLD0",outlet:"1I1L4IO2S0"};
		}
		/*#{1I1L20SLD0Post*/
		/*}#1I1L20SLD0Post*/
		return {seg:ShowResult,result:(result),preSeg:"1I1L20SLD0",outlet:"1I1L26LKJ0"};
	};
	CheckTool.jaxId="1I1L20SLD0"
	CheckTool.url="CheckTool@"+agentURL
	
	segs["PickTool"]=PickTool=async function(input){//:1I1L2433G0
		let result=input
		/*#{1I1L2433G0Code*/
		let toolId=input.tool;
		toolId=parseInt(toolId.substring("Tool-".length));
		let tool=context.aaTools.getTools()[toolId];
		if(!tool){
			throw `Tool "${input.tool}" not found. Are you confusing Node and Tool? Choose tool or agent node.`;
		}
		context.curTool=tool;
		console.log(result);
		/*}#1I1L2433G0Code*/
		return {seg:ShowTool,result:(result),preSeg:"1I1L2433G0",outlet:"1I1L26LKJ1"};
	};
	PickTool.jaxId="1I1L2433G0"
	PickTool.url="PickTool@"+agentURL
	
	segs["ShowTool"]=ShowTool=async function(input){//:1I1QH2J920
		let result=input;
		let role="assistant";
		let content=`- Tool: ${context.curTool.getNameText()}
- Prompt: ${input.prompt}
`;
		session.addChatText(role,content);
		return {seg:RunTool,result:(result),preSeg:"1I1QH2J920",outlet:"1I1QH48FB0"};
	};
	ShowTool.jaxId="1I1QH2J920"
	ShowTool.url="ShowTool@"+agentURL
	
	segs["RunTool"]=RunTool=async function(input){//:1I1N74RVL0
		let result=input
		/*#{1I1N74RVL0Code*/
		let tools=context.aaTools;
		let tool=context.curTool;
		let toolPath=tool.filePath;
		let prompt=input.prompt;
		if(typeof(prompt)!=="string"){
			prompt=JSON.stringify(prompt);
		}
		addTaskLog({type:"CallTool",tool:toolPath,prompt:prompt});
		result=await tools.execTool(VFACT.app,tool,prompt,session);
		//result=await session.pipeChat(toolPath,input.prompt?JSON.stringify(input.prompt):"",session);
		addTaskLog({type:"ToolResult",tool:toolPath,result:result});
		/*}#1I1N74RVL0Code*/
		return {seg:ShowToolResult,result:(result),preSeg:"1I1N74RVL0",outlet:"1I1N75UQ20"};
	};
	RunTool.jaxId="1I1N74RVL0"
	RunTool.url="RunTool@"+agentURL
	
	segs["ShowToolResult"]=ShowToolResult=async function(input){//:1I1N7NL9G0
		let result=input;
		let role="system";
		let content=input;
		session.addChatText(role,content);
		return {seg:pushToolMessage,result:(result),preSeg:"1I1N7NL9G0",outlet:"1I1N7RO010"};
	};
	ShowToolResult.jaxId="1I1N7NL9G0"
	ShowToolResult.url="ShowToolResult@"+agentURL
	
	segs["pushToolMessage"]=pushToolMessage=async function(input){//:1I1N876690
		let result=input
		/*#{1I1N876690Code*/
		result=`Run tool result: ${JSON.stringify(input,null,"\t")}`;
		/*}#1I1N876690Code*/
		return {seg:ChooseTool,result:(result),preSeg:"1I1N876690",outlet:"1I1N88PH50"};
	};
	pushToolMessage.jaxId="1I1N876690"
	pushToolMessage.url="pushToolMessage@"+agentURL
	
	segs["ShowResult"]=ShowResult=async function(input){//:1I1L24UDT0
		let result=input;
		let role="assistant";
		let content=input;
		/*#{1I1L24UDT0PreCodes*/
		addTaskLog({type:"LLMResult",result:input});
		/*}#1I1L24UDT0PreCodes*/
		session.addChatText(role,content);
		/*#{1I1L24UDT0PostCodes*/
		/*}#1I1L24UDT0PostCodes*/
		return {seg:ChooseTool,result:(result),preSeg:"1I1L24UDT0",outlet:"1I1L26LKJ2"};
	};
	ShowResult.jaxId="1I1L24UDT0"
	ShowResult.url="ShowResult@"+agentURL
	
	segs["ShowReply"]=ShowReply=async function(input){//:1I1L4IVOP0
		let result=input;
		let role="assistant";
		let content=input;
		/*#{1I1L4IVOP0PreCodes*/
		addTaskLog({type:"TaskReply",content:content});
		/*}#1I1L4IVOP0PreCodes*/
		session.addChatText(role,content);
		/*#{1I1L4IVOP0PostCodes*/
		/*}#1I1L4IVOP0PostCodes*/
		return {result:result};
	};
	ShowReply.jaxId="1I1L4IVOP0"
	ShowReply.url="ShowReply@"+agentURL
	
	segs["ShowAbort"]=ShowAbort=async function(input){//:1I1L4JP9K0
		let result=input;
		let role="assistant";
		let content=input;
		/*#{1I1L4JP9K0PreCodes*/
		addTaskLog({type:"TaskAbort",reason:content});
		/*}#1I1L4JP9K0PreCodes*/
		session.addChatText(role,content);
		/*#{1I1L4JP9K0PostCodes*/
		/*}#1I1L4JP9K0PostCodes*/
		return {seg:NextMenu,result:(result),preSeg:"1I1L4JP9K0",outlet:"1I1L51Q1G1"};
	};
	ShowAbort.jaxId="1I1L4JP9K0"
	ShowAbort.url="ShowAbort@"+agentURL
	
	segs["ShowFinish"]=ShowFinish=async function(input){//:1I1L4K6GU0
		let result=input;
		let role="assistant";
		let content=input;
		/*#{1I1L4K6GU0PreCodes*/
		addTaskLog({type:"TaskFinish",content:content});
		/*}#1I1L4K6GU0PreCodes*/
		session.addChatText(role,content);
		/*#{1I1L4K6GU0PostCodes*/
		/*}#1I1L4K6GU0PostCodes*/
		return {seg:NextMenu,result:(result),preSeg:"1I1L4K6GU0",outlet:"1I1L51Q1G2"};
	};
	ShowFinish.jaxId="1I1L4K6GU0"
	ShowFinish.url="ShowFinish@"+agentURL
	
	segs["ShowMissing"]=ShowMissing=async function(input){//:1I1L4N5OQ0
		let result=input;
		let role="assistant";
		let content=input;
		session.addChatText(role,content);
		return {seg:AskCreate,result:(result),preSeg:"1I1L4N5OQ0",outlet:"1I1L51Q1G3"};
	};
	ShowMissing.jaxId="1I1L4N5OQ0"
	ShowMissing.url="ShowMissing@"+agentURL
	
	segs["AskCreate"]=AskCreate=async function(input){//:1I1L4NP3H0
		let prompt=((($ln==="CN")?("是否创建新的工具来完成任务，或者请提供执行这个任务的提示"):("Whether to create a new tool to complete the task or provide tips for performing this task")))||input;
		let silent=false;
		let countdown=undefined;
		let button1=("Abort")||"OK";
		let button2=("Create")||"Cancel";
		let button3="";
		let result="";
		let value=0;
		if(silent){
			result="";
			/*#{1I1L4NP3A2Silent*/
			/*}#1I1L4NP3A2Silent*/
			return {seg:ChooseTool,result:(result),preSeg:"1I1L4NP3H0",outlet:"1I1L4NP3A2"};
		}
		[result,value]=await session.askUserRaw({type:"confirm",prompt:prompt,button1:button1,button2:button2,button3:button3,countdown:countdown});
		if(value===1){
			result=("")||result;
			/*#{1I1L4NP3A2Btn1*/
			ChooseTool.messages.splice(0);
			/*}#1I1L4NP3A2Btn1*/
			return {seg:ChooseTool,result:(result),preSeg:"1I1L4NP3H0",outlet:"1I1L4NP3A2"};
		}
		result=("")||result;
		return {seg:CreeateTool,result:(result),preSeg:"1I1L4NP3H0",outlet:"1I1L4NP3A0"};
	
	};
	AskCreate.jaxId="1I1L4NP3H0"
	AskCreate.url="AskCreate@"+agentURL
	
	segs["CallTool"]=CallTool=async function(input){//:1I1L5B9VP0
		let result=input;
		/*#{1I1L5B9VP0Code*/
		false
		/*}#1I1L5B9VP0Code*/
		return {seg:PickTool,result:(result),preSeg:"1I1L5B9VP0",outlet:"1I1L5DNUF0",catchSeg:LogToolError,catchlet:"1I1L5DNUF1"};
	};
	CallTool.jaxId="1I1L5B9VP0"
	CallTool.url="CallTool@"+agentURL
	
	segs["LogToolError"]=LogToolError=async function(input){//:1I1L5CSLR0
		let result=input
		/*#{1I1L5CSLR0Code*/
		addTaskLog({type:"ToolError",err:input});
		/*}#1I1L5CSLR0Code*/
		return {seg:ChooseTool,result:(result),preSeg:"1I1L5CSLR0",outlet:"1I1L5DNUF2"};
	};
	LogToolError.jaxId="1I1L5CSLR0"
	LogToolError.url="LogToolError@"+agentURL
	
	segs["StartTip"]=StartTip=async function(input){//:1I1M9GPHP0
		let result=input;
		let role="user";
		let content=`${command}`;
		/*#{1I1M9GPHP0PreCodes*/
		addTaskLog({type:"UserCommand",commad:command});
		/*}#1I1M9GPHP0PreCodes*/
		session.addChatText(role,content);
		/*#{1I1M9GPHP0PostCodes*/
		/*}#1I1M9GPHP0PostCodes*/
		return {seg:ChooseTool,result:(result),preSeg:"1I1M9GPHP0",outlet:"1I1M9HO1M0"};
	};
	StartTip.jaxId="1I1M9GPHP0"
	StartTip.url="StartTip@"+agentURL
	
	segs["ResetMsg"]=ResetMsg=async function(input){//:1I1N8JRGV0
		let result=input
		/*#{1I1N8JRGV0Code*/
		let messages,endMessage;
		messages=ChooseTool.messages;
		//Clear chat messages:
		context.taskRound+=1;
		messages.splice(context.taskRound*2+1);
		resetTaskLog();
		/*}#1I1N8JRGV0Code*/
		return {seg:AskNewCmd,result:(result),preSeg:"1I1N8JRGV0",outlet:"1I1N8OS6J0"};
	};
	ResetMsg.jaxId="1I1N8JRGV0"
	ResetMsg.url="ResetMsg@"+agentURL
	
	segs["AskNewCmd"]=AskNewCmd=async function(input){//:1I1N8NG750
		let tip=("有什么新的指示么？");
		let tipRole=("assistant");
		let placeholder=("");
		let text=("");
		let result="";
		/*#{1I1N8NG750PreCodes*/
		/*}#1I1N8NG750PreCodes*/
		if(tip){
			session.addChatText(tipRole,tip);
		}
		result=await session.askChatInput({type:"input",placeholder:placeholder,text:text});
		session.addChatText("user",result);
		/*#{1I1N8NG750PostCodes*/
		command=result;
		/*}#1I1N8NG750PostCodes*/
		return {seg:ChooseTool,result:(result),preSeg:"1I1N8NG750",outlet:"1I1N8OS6J1"};
	};
	AskNewCmd.jaxId="1I1N8NG750"
	AskNewCmd.url="AskNewCmd@"+agentURL
	
	segs["CreeateTool"]=CreeateTool=async function(input){//:1I1N9J5G70
		let result;
		let sourcePath=pathLib.joinTabOSURL(basePath,"");
		let arg={};
		result= await session.pipeChat(sourcePath,arg,false);
		return {seg:ReloadTools,result:(result),preSeg:"1I1N9J5G70",outlet:"1I1N9KMMV0"};
	};
	CreeateTool.jaxId="1I1N9J5G70"
	CreeateTool.url="CreeateTool@"+agentURL
	
	segs["ReloadTools"]=ReloadTools=async function(input){//:1I1N9QI710
		let result=input
		/*#{1I1N9QI710Code*/
		let tools=context.aaTools;
		let saveVO=await (await fetch("/@aae/ai/ToolIndex.json")).json();
		await tools.loadFromVO(saveVO);
		context.toolsIndexVO=tools.getToolDescIndex();
		console.log(context.toolsIndexVO);
		result="New tool has been created. Tools updated.";
		/*}#1I1N9QI710Code*/
		return {seg:ChooseTool,result:(result),preSeg:"1I1N9QI710",outlet:"1I1N9S0AV0"};
	};
	ReloadTools.jaxId="1I1N9QI710"
	ReloadTools.url="ReloadTools@"+agentURL
	
	segs["NextMenu"]=NextMenu=async function(input){//:1I1SF3OGA0
		let prompt=((($ln==="CN")?("请输入新的消息，或者结束当前对话"):("Please enter a new message or end the current conversation")))||input;
		let countdown=undefined;
		let silent=false;
		let items=[
			{icon:"/~/-tabos/shared/assets/hudbox.svg",text:(($ln==="CN")?("开启新的对话"):("Perform a new session")),code:0},
			{icon:"/~/-tabos/shared/assets/hudbox.svg",text:(($ln==="CN")?("退出对话"):("Exit conversation")),code:1},
		];
		let result="";
		let item=null;
		
		if(silent){
			result="";
			return {seg:ShowTaskLog,result:(result),preSeg:"1I1SF3OGA0",outlet:"1I1SF3OFR0"};
		}
		[result,item]=await session.askUserRaw({type:"menu",prompt:prompt,multiSelect:false,items:items,withChat:true,countdown:countdown});
		if(typeof(item)==='string'){
			result=item;
			/*#{1IBTHHLOO0ChatInput*/
			addTaskLog({type:"UserReply",content:result});
			/*}#1IBTHHLOO0ChatInput*/
			return {seg:ChooseTool,result:(result),preSeg:"1I1SF3OGA0",outlet:"1IBTHHLOO0"};
		}else if(item.code===0){
			return {seg:ShowTaskLog,result:(result),preSeg:"1I1SF3OGA0",outlet:"1I1SF3OFR0"};
		}else if(item.code===1){
			return {seg:ExitChat,result:(result),preSeg:"1I1SF3OGA0",outlet:"1I1SF3OFR2"};
		}
	};
	NextMenu.jaxId="1I1SF3OGA0"
	NextMenu.url="NextMenu@"+agentURL
	
	segs["ExitChat"]=ExitChat=async function(input){//:1I1SFCDUK0
		let result=input
		/*#{1I1SFCDUK0Code*/
		let app=VFACT.app;
		if(app && app.closeApp){
			app.closeApp();
		}
		/*}#1I1SFCDUK0Code*/
		return {result:result};
	};
	ExitChat.jaxId="1I1SFCDUK0"
	ExitChat.url="ExitChat@"+agentURL
	
	segs["CallNode"]=CallNode=async function(input){//:1IDOTRRND0
		let result=input;
		/*#{1IDOTRRND0Code*/
		/*}#1IDOTRRND0Code*/
		return {seg:RunNode,result:(result),preSeg:"1IDOTRRND0",outlet:"1IDOVLILT0",catchSeg:LogNodeError,catchlet:"1IDOVLILT1"};
	};
	CallNode.jaxId="1IDOTRRND0"
	CallNode.url="CallNode@"+agentURL
	
	segs["RunNode"]=RunNode=async function(input){//:1IDOTSHK40
		let result=input
		/*#{1IDOTSHK40Code*/
		//Check if node is ok:
		let nodes=context.agentNodes;
		if(!nodes[input.node]){
			throw `Node "${input.node}" not found. Are you confusing Node and Tool? Choose tool or agent node.`;
		}
		addTaskLog({type:"CallAgentNode",node:input.node,prompt:input.prompt});
		session.addChatText("log",`Call agent-node: "${input.node}."`);
		result=await RemoteSession.exec(session,input.node,"/@tabos/NodeChat.py",input.prompt,{});
		addTaskLog({type:"AgentNodeResult",node:input.node,prompt:input.prompt,result:result});
		/*}#1IDOTSHK40Code*/
		return {seg:ShowNodeResult,result:(result),preSeg:"1IDOTSHK40",outlet:"1IDOVLILT2"};
	};
	RunNode.jaxId="1IDOTSHK40"
	RunNode.url="RunNode@"+agentURL
	
	segs["LogNodeError"]=LogNodeError=async function(input){//:1IDOTT4JU0
		let result=input
		/*#{1IDOTT4JU0Code*/
		addTaskLog({type:"AgentNodeError",err:input});
		/*}#1IDOTT4JU0Code*/
		return {seg:ChooseTool,result:(result),preSeg:"1IDOTT4JU0",outlet:"1IDOVLILT3"};
	};
	LogNodeError.jaxId="1IDOTT4JU0"
	LogNodeError.url="LogNodeError@"+agentURL
	
	segs["ShowNodeResult"]=ShowNodeResult=async function(input){//:1IDOU0F1O0
		let result=input;
		let role="log";
		let content=JSON.stringify(input);
		session.addChatText(role,content);
		return {seg:pushNodeMessage,result:(result),preSeg:"1IDOU0F1O0",outlet:"1IDOVLILT4"};
	};
	ShowNodeResult.jaxId="1IDOU0F1O0"
	ShowNodeResult.url="ShowNodeResult@"+agentURL
	
	segs["pushNodeMessage"]=pushNodeMessage=async function(input){//:1IDOU119Q0
		let result=input
		/*#{1IDOU119Q0Code*/
		result=`Node-call result: ${JSON.stringify(input)}`;
		/*}#1IDOU119Q0Code*/
		return {seg:ChooseTool,result:(result),preSeg:"1IDOU119Q0",outlet:"1IDOVLILT5"};
	};
	pushNodeMessage.jaxId="1IDOU119Q0"
	pushNodeMessage.url="pushNodeMessage@"+agentURL
	
	segs["ShowTaskLog"]=ShowTaskLog=async function(input){//:1IDSI9C020
		let result=input;
		let role="assistant";
		let content=`
\`\`\`
${JSON.stringify(globalContext.taskLogs,null,"\t")}
\`\`\`
`;
		session.addChatText(role,content);
		return {seg:ResetMsg,result:(result),preSeg:"1IDSI9C020",outlet:"1IDSIA72G0"};
	};
	ShowTaskLog.jaxId="1IDSI9C020"
	ShowTaskLog.url="ShowTaskLog@"+agentURL
	
	segs["DoAsk"]=DoAsk=async function(input){//:1IF5T46T30
		let tip=(input);
		let tipRole=("assistant");
		let placeholder=("");
		let text=("");
		let result="";
		if(tip){
			session.addChatText(tipRole,tip);
		}
		result=await session.askChatInput({type:"input",placeholder:placeholder,text:text});
		session.addChatText("user",result);
		return {seg:ChooseTool,result:(result),preSeg:"1IF5T46T30",outlet:"1IF5T8R070"};
	};
	DoAsk.jaxId="1IF5T46T30"
	DoAsk.url="DoAsk@"+agentURL
	
	agent={
		isAIAgent:true,
		session:session,
		name:"ToolChat",
		url:agentURL,
		autoStart:true,
		jaxId:"1I1L1U8U20",
		context:context,
		livingSeg:null,
		execChat:async function(input/*{command}*/){
			let result;
			parseAgentArgs(input);
			/*#{1I1L1U8U20PreEntry*/
			if(typeof(input)==="string"){
				command=input;
			}
			/*}#1I1L1U8U20PreEntry*/
			result={seg:BuildToolsIndex,"input":input};
			/*#{1I1L1U8U20PostEntry*/
			/*}#1I1L1U8U20PostEntry*/
			return result;
		},
		/*#{1I1L1U8U20MoreAgentAttrs*/
		/*}#1I1L1U8U20MoreAgentAttrs*/
	};
	/*#{1I1L1U8U20PostAgent*/
	/*}#1I1L1U8U20PostAgent*/
	return agent;
};
/*#{1I1L1U8U20ExCodes*/
/*}#1I1L1U8U20ExCodes*/

//#CodyExport>>>
export const ChatAPI=[{
	def:{
		name: "ToolChat",
		description: "这是一个AI代理。",
		parameters:{
			type: "object",
			properties:{
				command:{type:"string",description:"Command to execute"}
			}
		}
	},
	agent: ToolChat
}];

//:Export Edit-AddOn:
const DocAIAgentExporter=VFACT.classRegs.DocAIAgentExporter;
if(DocAIAgentExporter){
	const EditAttr=VFACT.classRegs.EditAttr;
	const EditAISeg=VFACT.classRegs.EditAISeg;
	const EditAISegOutlet=VFACT.classRegs.EditAISegOutlet;
	const SegObjShellAttr=EditAISeg.SegObjShellAttr;
	const SegOutletDef=EditAISegOutlet.SegOutletDef;
	const docAIAgentExporter=DocAIAgentExporter.prototype;
	const packExtraCodes=docAIAgentExporter.packExtraCodes;
	const packResult=docAIAgentExporter.packResult;
	const varNameRegex = /^[a-zA-Z_$][a-zA-Z0-9_$]*$/;
	
	EditAISeg.regDef({
		name:"ToolChat",showName:"ToolChat",icon:"agent.svg",catalog:["AI Call"],
		attrs:{
			...SegObjShellAttr,
			"command":{name:"command",showName:undefined,type:"string",key:1,fixed:1,initVal:""},
			"outlet":{name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc"}
		},
		listHint:["id","command","codes","desc"],
		desc:"这是一个AI代理。"
	});
	
	DocAIAgentExporter.segTypeExporters["ToolChat"]=
	function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let exportDebug=this.isExportDebug();
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();coder.newLine();
		{
			coder.packText(`let result,args={};`);coder.newLine();
			coder.packText("args['command']=");this.genAttrStatement(seg.getAttr("command"));coder.packText(";");coder.newLine();
			this.packExtraCodes(coder,seg,"PreCodes");
			coder.packText(`result= await session.pipeChat("/~/aae/ai/ToolChat.js",args,false);`);coder.newLine();
			this.packExtraCodes(coder,seg,"PostCodes");
			this.packResult(coder,seg,seg.outlet);
		}
		coder.indentLess();coder.maybeNewLine();
		coder.packText(`};`);coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		coder.newLine();
	};
}
//#CodyExport<<<
/*#{1I1L1U8U20PostDoc*/
/*}#1I1L1U8U20PostDoc*/


export default ToolChat;
export{ToolChat};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DocAIAgent",
//	"jaxId": "1I1L1U8U20",
//	"attrs": {
//		"editObjs": {
//			"jaxId": "1I1L1U8U21",
//			"attrs": {
//				"ToolChat": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1I1L1U8U27",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1I1L1U8U28",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1I1L1U8U29",
//							"attrs": {}
//						},
//						"functions": {
//							"jaxId": "1I1L1U8U210",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false"
//					},
//					"mockups": {}
//				}
//			}
//		},
//		"agent": {
//			"jaxId": "1I1L1U8U22",
//			"attrs": {}
//		},
//		"entry": "BuildToolsIndex",
//		"autoStart": "true",
//		"inBrowser": "true",
//		"debug": "true",
//		"apiArgs": {
//			"jaxId": "1I1L1U8U23",
//			"attrs": {
//				"command": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I1L867JC0",
//					"attrs": {
//						"type": "String",
//						"mockup": "\"\"",
//						"desc": "Command to execute"
//					}
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1I1L1U8U24",
//			"attrs": {}
//		},
//		"context": {
//			"jaxId": "1I1L1U8U25",
//			"attrs": {
//				"aaTools": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I1L88I310",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "null",
//						"desc": ""
//					}
//				},
//				"toolsIndexVO": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I1L2LV9Q0",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "{\"a\":\"b\"}",
//						"desc": ""
//					}
//				},
//				"curTool": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I1MGVHE10",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "null",
//						"desc": ""
//					}
//				},
//				"taskRound": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I1SHDI1V0",
//					"attrs": {
//						"type": "Integer",
//						"mockup": "0",
//						"desc": ""
//					}
//				},
//				"agentNodes": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1IDOVLIM60",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "#[]",
//						"desc": ""
//					}
//				},
//				"nodesIndexVO": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1IDOVLIM61",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "#{}",
//						"desc": ""
//					}
//				},
//				"callNode": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1IDOVLIM62",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "#null",
//						"desc": ""
//					}
//				}
//			}
//		},
//		"globalMockup": {
//			"jaxId": "1I1L1U8U26",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I1L1UN1D0",
//					"attrs": {
//						"id": "BuildToolsIndex",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "65",
//						"y": "570",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I1L26LKM0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1L26LKM1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I1L26LKH0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1M9GPHP0"
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "callLLM",
//					"jaxId": "1I1L2072D0",
//					"attrs": {
//						"id": "ChooseTool",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "580",
//						"y": "570",
//						"desc": "执行一次LLM调用。",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "faces.svg",
//						"context": {
//							"jaxId": "1I1L26LKM2",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1L26LKM3",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"platform": "OpenAI",
//						"mode": "gpt-4o",
//						"system": "#`\n你是一个根据用户输入，选择适合的Tool(本地智能体)或Node(外部智能体节点)运行，与用户对话，完成任务的AI。\n当前的Tools（本地智能体工具）有:\n${JSON.stringify(context.toolsIndexVO,null,\"\\t\")}\n当前的Nodes（外部智能体节点）有:\n${JSON.stringify(context.agentNodes,null,\"\\t\")}\n\n- 第一轮对话时，用户输入的是要完成的任务，你根据用户的输入，选择合适的Tool\n\n- 每一回合对话，跟根据当前任务执行的情况，回复一个JSON对象。\n- 如果需要执行一个Tool，回复JSON中的\"tool\"属性是下一步要执行的Tool(智能体)的名称; 回复JSON中的prompt属性是调用这个Tool的输入指令。例如：\n{\n\t\"tool\":\"Tool-3\",\n    \"prompt\":\"Search for: Who is the winner of 2024 F1?\"\n}\n\n- 如果需要执行一个Node，回复JSON中的\"node\"属性是下一步要执行的Node（外部智能体）的名称; 回复JSON中的prompt属性是调用这个Tool的输入指令。例如：\n{\n\t\"node\":\"DrawNode\",\n    \"prompt\":\"Draw picture of a cute fat cat.\"\n}\n\n- 执行Tool或Node的结果会在对话中告知。你根据任务目标以及当前的执行情况，可能需要继续选择新的Tool/Node进一步执行。\n\n- 如果同时有Tool和Node可以执行当前的任务需求，优先使用Tool，如果Tool执行失败或无法完成任务再尝试Node。\n\n- 如果成功的完成了用户提出的任务，回复将JSON中的\"finish\"属性设置为true。并通过\"result\"属性总结汇报执行情况。例如\n{\n\t\"finish\":true,\n    \"result\":\"论坛帖子已经成功发布。\"\n}\n\n- 如果执行Tool出现错误，你认为无法完成用户的任务，设置回复JSON中的\"abort\"属性为true，并在\"reason\"属性中说明原因。例如:\n{\n\t\"abort\":true,\n    \"reason\":\"没有登录脸书账号，无法发布新的内容。\"\n}\n\n- 如果没有Tool或Node可以完成用户的要求，请设计一个或多个用来完成用户需求的Tool，在回复JSON中用\"missingTools\"数组属性里描述缺失的Tool。例如：\n{\n\t\"missingTools\":[\n    \t\"检查脸书账号登录状态\",\n        \"发布脸书动态\"\n    ]\n}\n\n- 如果回答用户的输入不需要使用任何tool，用回复JSON中的\"replay\"属性回答用户，如果对话已结束，同时设置\"finish\"属性为true。例如：当用户询问：\"西瓜是一种水果么？\"，你的回复：\n{\n\t\"finish\":true,\n\t\"result\":\"是的，西瓜是一种水果。\"\n}\n\n- 如果执行任务需要用户提供更多的信息，用回复JSON中的\"ask\"属性询问用户，同时设置finish属性为false。例如，需要用户\n提供邮箱地址：\n{\n\t\"finish\":false,\n\t\"ask\":\"请告诉我你的电子邮箱地址\"\n}\n`",
//						"temperature": "0",
//						"maxToken": "2000",
//						"topP": "1",
//						"fqcP": "0",
//						"prcP": "0",
//						"messages": {
//							"attrs": []
//						},
//						"prompt": "#input",
//						"seed": "",
//						"outlet": {
//							"jaxId": "1I1L26LKI0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1L20SLD0"
//						},
//						"secret": "false",
//						"allowCheat": "false",
//						"GPTCheats": {
//							"attrs": [
//								{
//									"type": "object",
//									"def": "GPTCheat",
//									"jaxId": "1I1MIE76U0",
//									"attrs": {
//										"prompt": "Draw a fat cat",
//										"reply": "{\"tool\": \"DrawSD\", \"prompt\": \"Draw picture of a cute fat cat.\"}"
//									}
//								}
//							]
//						},
//						"shareChatName": "",
//						"keepChat": "50 messages",
//						"clearChat": "2",
//						"apiFiles": {
//							"attrs": []
//						},
//						"parallelFunction": "false",
//						"responseFormat": "json_object"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "brunch",
//					"jaxId": "1I1L20SLD0",
//					"attrs": {
//						"id": "CheckTool",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "800",
//						"y": "570",
//						"desc": "这是一个AISeg。",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I1L26LKM4",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1L26LKM5",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I1L26LKJ0",
//							"attrs": {
//								"id": "Default",
//								"desc": "输出节点。",
//								"output": ""
//							},
//							"linkedSeg": "1I1L24UDT0"
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I1L4HCRJ0",
//									"attrs": {
//										"id": "Missing",
//										"desc": "输出节点。",
//										"output": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I1L51Q1J0",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I1L51Q1J1",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#input.missingTools"
//									},
//									"linkedSeg": "1I1L4N5OQ0"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1IDOTLSQJ0",
//									"attrs": {
//										"id": "CallNode",
//										"desc": "输出节点。",
//										"output": "#input",
//										"codes": "false",
//										"context": {
//											"jaxId": "1IDOVLIM63",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1IDOVLIM64",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#input.node"
//									},
//									"linkedSeg": "1IDOTRRND0"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I1L26LKI1",
//									"attrs": {
//										"id": "UseTool",
//										"desc": "输出节点。",
//										"output": "#input",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I1L26LKM6",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I1L26LKM7",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#input.tool"
//									},
//									"linkedSeg": "1I1L5B9VP0"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I1L4HMHK0",
//									"attrs": {
//										"id": "Finish",
//										"desc": "输出节点。",
//										"output": "#input.result",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I1L51Q1J2",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I1L51Q1J3",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#input.finish&&input.result"
//									},
//									"linkedSeg": "1I1L4K6GU0"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I1L4HSMS0",
//									"attrs": {
//										"id": "Abort",
//										"desc": "输出节点。",
//										"output": "#input.reason",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I1L51Q1J4",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I1L51Q1J5",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#input.abort"
//									},
//									"linkedSeg": "1I1L4JP9K0"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I1L4IO2S0",
//									"attrs": {
//										"id": "Ask",
//										"desc": "输出节点。",
//										"output": "#input.ask",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I1L51Q1J6",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I1L51Q1J7",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#input.ask"
//									},
//									"linkedSeg": "1IF5T46T30"
//								}
//							]
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I1L2433G0",
//					"attrs": {
//						"id": "PickTool",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "1290",
//						"y": "445",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I1L26LKM8",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1L26LKM9",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I1L26LKJ1",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1QH2J920"
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1I1QH2J920",
//					"attrs": {
//						"id": "ShowTool",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "1535",
//						"y": "445",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I1QH48FK0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1QH48FK1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "Assistant",
//						"text": "#`- Tool: ${context.curTool.getNameText()}\n- Prompt: ${input.prompt}\n`",
//						"outlet": {
//							"jaxId": "1I1QH48FB0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1N74RVL0"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I1N74RVL0",
//					"attrs": {
//						"id": "RunTool",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "1795",
//						"y": "445",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I1N75UQ80",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1N75UQ81",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I1N75UQ20",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1N7NL9G0"
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1I1N7NL9G0",
//					"attrs": {
//						"id": "ShowToolResult",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "2010",
//						"y": "445",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I1N7RO060",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1N7RO061",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "System",
//						"text": "#input",
//						"outlet": {
//							"jaxId": "1I1N7RO010",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1N876690"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I1N876690",
//					"attrs": {
//						"id": "pushToolMessage",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "2270",
//						"y": "445",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I1N88PHE0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1N88PHE1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I1N88PH50",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1N87SVA0"
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1I1L24UDT0",
//					"attrs": {
//						"id": "ShowResult",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "1055",
//						"y": "760",
//						"desc": "这是一个AISeg。",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I1L26LKM10",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1L26LKM11",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "Assistant",
//						"text": "#input",
//						"outlet": {
//							"jaxId": "1I1L26LKJ2",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1L276T40"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I1L276T40",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "1205",
//						"y": "830",
//						"outlet": {
//							"jaxId": "1I1L284PT0",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1L27N6E0"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I1L27N6E0",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "940",
//						"y": "830",
//						"outlet": {
//							"jaxId": "1I1L284PT1",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1N9AI7S0"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1I1L4IVOP0",
//					"attrs": {
//						"id": "ShowReply",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "1075",
//						"y": "940",
//						"desc": "这是一个AISeg。",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I1L51Q1J8",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1L51Q1J9",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "Assistant",
//						"text": "#input",
//						"outlet": {
//							"jaxId": "1I1L51Q1G0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							}
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1I1L4JP9K0",
//					"attrs": {
//						"id": "ShowAbort",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "1055",
//						"y": "645",
//						"desc": "这是一个AISeg。",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I1L51Q1J10",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1L51Q1J11",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "Assistant",
//						"text": "#input",
//						"outlet": {
//							"jaxId": "1I1L51Q1G1",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1SF3OGA0"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1I1L4K6GU0",
//					"attrs": {
//						"id": "ShowFinish",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "1055",
//						"y": "585",
//						"desc": "这是一个AISeg。",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I1L51Q1J12",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1L51Q1J13",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "Assistant",
//						"text": "#input",
//						"outlet": {
//							"jaxId": "1I1L51Q1G2",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1SF3OGA0"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I1L4LN2D0",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "2160",
//						"y": "830",
//						"outlet": {
//							"jaxId": "1I1L51Q1J15",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1IBVULSE10"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1I1L4N5OQ0",
//					"attrs": {
//						"id": "ShowMissing",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "1055",
//						"y": "195",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I1L51Q1J16",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1L51Q1J17",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "Assistant",
//						"text": "#input",
//						"outlet": {
//							"jaxId": "1I1L51Q1G3",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1L4NP3H0"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "askConfirm",
//					"jaxId": "1I1L4NP3H0",
//					"attrs": {
//						"id": "AskCreate",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "1290",
//						"y": "195",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"prompt": {
//							"type": "string",
//							"valText": "Whether to create a new tool to complete the task or provide tips for performing this task",
//							"localize": {
//								"EN": "Whether to create a new tool to complete the task or provide tips for performing this task",
//								"CN": "是否创建新的工具来完成任务，或者请提供执行这个任务的提示"
//							},
//							"localizable": true
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1I1L4NP3A2",
//									"attrs": {
//										"id": "Abort",
//										"desc": "Will clear messages",
//										"text": "Abort",
//										"result": "",
//										"codes": "true",
//										"context": {
//											"jaxId": "1I1L51Q1J20",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I1L51Q1J21",
//											"attrs": {
//												"cast": ""
//											}
//										}
//									},
//									"linkedSeg": "1I1N9K0UV0"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1I1L4NP3A0",
//									"attrs": {
//										"id": "Create",
//										"desc": "输出节点。",
//										"text": "Create",
//										"result": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I1L51Q1J18",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I1L51Q1J19",
//											"attrs": {
//												"cast": ""
//											}
//										}
//									},
//									"linkedSeg": "1I1N9J5G70"
//								}
//							]
//						},
//						"silent": "false"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "tryCatch",
//					"jaxId": "1I1L5B9VP0",
//					"attrs": {
//						"id": "CallTool",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "1055",
//						"y": "490",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I1L5DNUI0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1L5DNUI1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I1L5DNUF0",
//							"attrs": {
//								"id": "Try",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1L2433G0"
//						},
//						"catchlet": {
//							"jaxId": "1I1L5DNUF1",
//							"attrs": {
//								"id": "Catch",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1L5CSLR0"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I1L5CSLR0",
//					"attrs": {
//						"id": "LogToolError",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "1290",
//						"y": "530",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I1L5DNUI2",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1L5DNUI3",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I1L5DNUF2",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1N94UGV0"
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1I1M9GPHP0",
//					"attrs": {
//						"id": "StartTip",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "335",
//						"y": "570",
//						"desc": "这是一个AISeg。",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I1M9HO1R0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1M9HO1R1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "User",
//						"text": "#`${command}`",
//						"outlet": {
//							"jaxId": "1I1M9HO1M0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1L2072D0"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I1N87SVA0",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "2450",
//						"y": "100",
//						"outlet": {
//							"jaxId": "1I1N88PHE2",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1N9REU70"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I1N881SF0",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "940",
//						"y": "100",
//						"outlet": {
//							"jaxId": "1I1N88PHE3",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1N99IJJ0"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I1N8JRGV0",
//					"attrs": {
//						"id": "ResetMsg",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "1785",
//						"y": "580",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I1N8PN2J0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1N8PN2J1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I1N8OS6J0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1N8NG750"
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "askChat",
//					"jaxId": "1I1N8NG750",
//					"attrs": {
//						"id": "AskNewCmd",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "2005",
//						"y": "580",
//						"desc": "这是一个AISeg。",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I1N8PN2J2",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1N8PN2J3",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"tip": "有什么新的指示么？",
//						"tipRole": "Assistant",
//						"placeholder": "",
//						"text": "",
//						"file": "false",
//						"showText": "true",
//						"outlet": {
//							"jaxId": "1I1N8OS6J1",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1L4LN2D0"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connectorL",
//					"jaxId": "1I1N94UGV0",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "2450",
//						"y": "530",
//						"outlet": {
//							"jaxId": "1I1N957VS0",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1N87SVA0"
//						},
//						"dir": "L2R"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I1N99IJJ0",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "615",
//						"y": "490",
//						"outlet": {
//							"jaxId": "1I1N9IAOD0",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1L2072D0"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I1N9AI7S0",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "615",
//						"y": "650",
//						"outlet": {
//							"jaxId": "1I1N9IAOD1",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1L2072D0"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "aiBot",
//					"jaxId": "1I1N9J5G70",
//					"attrs": {
//						"id": "CreeateTool",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "1535",
//						"y": "210",
//						"desc": "调用其它AI Agent，把调用的结果作为输出",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I1N9KMN50",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1N9KMN51",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"source": "",
//						"argument": "#{}#>input",
//						"secret": "false",
//						"outlet": {
//							"jaxId": "1I1N9KMMV0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1N9QI710"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I1N9K0UV0",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "1435",
//						"y": "100",
//						"outlet": {
//							"jaxId": "1I1N9KMN52",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1N881SF0"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I1N9QI710",
//					"attrs": {
//						"id": "ReloadTools",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "1795",
//						"y": "210",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I1N9S0B80",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1N9S0B81",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I1N9S0AV0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1N9REU70"
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1I1N9REU70",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "1965",
//						"y": "100",
//						"outlet": {
//							"jaxId": "1I1N9S0B82",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1N9K0UV0"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "askMenu",
//					"jaxId": "1I1SF3OGA0",
//					"attrs": {
//						"id": "NextMenu",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "1290",
//						"y": "645",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"prompt": {
//							"type": "string",
//							"valText": "Please enter a new message or end the current conversation",
//							"localize": {
//								"EN": "Please enter a new message or end the current conversation",
//								"CN": "请输入新的消息，或者结束当前对话"
//							},
//							"localizable": true
//						},
//						"multi": "false",
//						"withChat": "true",
//						"outlet": {
//							"jaxId": "1IBTHHLOO0",
//							"attrs": {
//								"id": "ChatInput",
//								"desc": "输出节点。",
//								"codes": "true"
//							},
//							"linkedSeg": "1IBVULSE10"
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1I1SF3OFR0",
//									"attrs": {
//										"id": "NewTask",
//										"desc": "输出节点。",
//										"text": {
//											"type": "string",
//											"valText": "Perform a new session",
//											"localize": {
//												"EN": "Perform a new session",
//												"CN": "开启新的对话"
//											},
//											"localizable": true
//										},
//										"result": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I1SFCVNF0",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I1SFCVNF1",
//											"attrs": {
//												"cast": ""
//											}
//										}
//									},
//									"linkedSeg": "1IDSI9C020"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1I1SF3OFR2",
//									"attrs": {
//										"id": "Exit",
//										"desc": "输出节点。",
//										"text": {
//											"type": "string",
//											"valText": "Exit conversation",
//											"localize": {
//												"EN": "Exit conversation",
//												"CN": "退出对话"
//											},
//											"localizable": true
//										},
//										"result": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I1SFCVNF4",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I1SFCVNF5",
//											"attrs": {
//												"cast": ""
//											}
//										}
//									},
//									"linkedSeg": "1I1SFCDUK0"
//								}
//							]
//						},
//						"silent": "false"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I1SFCDUK0",
//					"attrs": {
//						"id": "ExitChat",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "1535",
//						"y": "675",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "flag.svg",
//						"context": {
//							"jaxId": "1I1SFCVNF9",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1SFCVNF10",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I1SFCVN71",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							}
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1IBVULSE10",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "1435",
//						"y": "830",
//						"outlet": {
//							"jaxId": "1IBVUMCS10",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1L276T40"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "tryCatch",
//					"jaxId": "1IDOTRRND0",
//					"attrs": {
//						"id": "CallNode",
//						"viewName": "",
//						"label": "",
//						"x": "1055",
//						"y": "345",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1IDOVLIM65",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1IDOVLIM66",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1IDOVLILT0",
//							"attrs": {
//								"id": "Try",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1IDOTSHK40"
//						},
//						"catchlet": {
//							"jaxId": "1IDOVLILT1",
//							"attrs": {
//								"id": "Catch",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1IDOTT4JU0"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1IDOTSHK40",
//					"attrs": {
//						"id": "RunNode",
//						"viewName": "",
//						"label": "",
//						"x": "1290",
//						"y": "295",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1IDOVLIM67",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1IDOVLIM68",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1IDOVLILT2",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1IDOU0F1O0"
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1IDOTT4JU0",
//					"attrs": {
//						"id": "LogNodeError",
//						"viewName": "",
//						"label": "",
//						"x": "1290",
//						"y": "385",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1IDOVLIM69",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1IDOVLIM610",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1IDOVLILT3",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1IDOU2BOI0"
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1IDOU0F1O0",
//					"attrs": {
//						"id": "ShowNodeResult",
//						"viewName": "",
//						"label": "",
//						"x": "1535",
//						"y": "295",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1IDOVLIM611",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1IDOVLIM612",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "Log",
//						"text": "#JSON.stringify(input)",
//						"outlet": {
//							"jaxId": "1IDOVLILT4",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1IDOU119Q0"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1IDOU119Q0",
//					"attrs": {
//						"id": "pushNodeMessage",
//						"viewName": "",
//						"label": "",
//						"x": "1795",
//						"y": "295",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1IDOVLIM613",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1IDOVLIM614",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1IDOVLILT5",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1N9REU70"
//						},
//						"result": "#input"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connectorL",
//					"jaxId": "1IDOU2BOI0",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "1985",
//						"y": "385",
//						"outlet": {
//							"jaxId": "1IDOVLIM615",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1N9REU70"
//						},
//						"dir": "L2R"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1IDSI9C020",
//					"attrs": {
//						"id": "ShowTaskLog",
//						"viewName": "",
//						"label": "",
//						"x": "1535",
//						"y": "580",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1IDSIA72O0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1IDSIA72O1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "Assistant",
//						"text": "#`\n\\`\\`\\`\n${JSON.stringify(globalContext.taskLogs,null,\"\\t\")}\n\\`\\`\\`\n`",
//						"outlet": {
//							"jaxId": "1IDSIA72G0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1N8JRGV0"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "askChat",
//					"jaxId": "1IF5T46T30",
//					"attrs": {
//						"id": "DoAsk",
//						"viewName": "",
//						"label": "",
//						"x": "1055",
//						"y": "705",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1IF5T8R0G0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1IF5T8R0G1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"tip": "#input",
//						"tipRole": "Assistant",
//						"placeholder": "",
//						"text": "",
//						"file": "false",
//						"showText": "true",
//						"outlet": {
//							"jaxId": "1IF5T8R070",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1IF5T5JO60"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1IF5T5JO60",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "1260",
//						"y": "705",
//						"outlet": {
//							"jaxId": "1IF5T8R0G2",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1L276T40"
//						},
//						"dir": "L2R"
//					}
//				}
//			]
//		},
//		"desc": "这是一个AI代理。",
//		"exportAPI": "true",
//		"exportAddOn": "true",
//		"addOnOpts": ""
//	}
//}