import {makeObjEventEmitter,makeNotify} from "/@events";
import pathLib from "/@path";
function getDomain(url) {
	try{
		if((!url.startsWith("http://"))||(!url.startsWith("https://"))){
			url="https://"+url;
		}
		const parsedUrl = new URL(url);
		const hostname = parsedUrl.hostname;
		if (hostname) {
			const domainParts = hostname.split('.');
			if (domainParts.length >= 2) {
				return domainParts.slice(-2).join('.');
			} else {
				return hostname;
			}
		}
		return url;
	}catch(err){
		return url;
	}
}

//****************************************************************************
//:AASkill
//****************************************************************************
let AASkill,aaSkill;
{
	AASkill=function(skills){
		this.aaSkills=skills;
		this.filePath="";
		this.type="";
		this.codeName="";
		this.name="";
		this.description="";
		this.icon="";
		this.package="";
		this.modual=null;
		this.isRPA=false;
		this.rpaHost="";
		this.appMeta=null;
		this.appFrameW=0;
		this.appFrameH=0;
		this.enable=true;
		makeNotify(this);
	};
	aaSkill=AASkill.prototype={};
	AASkill.TYPE_NONE="";
	AASkill.TYPE_APP="App";
	AASkill.TYPE_PAGE="Page";
	AASkill.TYPE_AGENT="Agent";
	AASkill.TYPE_GUIDE="Guide";
	AASkill.TYPE_API="API";

	//------------------------------------------------------------------------
	aaSkill.loadFromPath=async function(path){
		let apiList,apiVO,modual;
		this.filePath=path;
		//Read package info:
		{
			let pos=path.indexOf("/@");
			if(pos>=0){
				let pos2=path.indexOf("/",pos+2);
				if(pos2>0){
					this.package=path.substring(2,pos);
				}else{
					this.package=path.substring(2);
				}
			}
		}
		modual=this.modual=await import(path);
		apiList=modual.ChatAPI;
		if(Array.isArray(apiList)){
			apiVO=apiList[0];
		}
		if(apiVO){
			this.name=apiVO.def.name;
			this.description=apiVO.def.description;
			this.icon=apiVO.icon;
			if(apiVO.agent){
				this.type=AASkill.TYPE_AGENT;
			}else{
				this.type=AASkill.TYPE_API;
			}
			this.isRPA=apiVO.isRPA;
			if(this.isRPA){
				this.rpaHost=apiVO.rpaHost;
			}
			return true;
		}
		apiVO=modual.skill;
		if(apiVO && apiVO.guide){
			this.type=AASkill.TYPE_GUIDE;
			this.name=apiVO.name;
			this.description=apiVO.description;
			this.icon=apiVO.icon;
			this.isRPA=true;
			this.rpaHost=apiVO.rapHost;
			return true;
		}
		throw Error(`${path} is not a skill file.`);
	};
	
	//------------------------------------------------------------------------
	aaSkill.loadFromVO=async function(vo){
		this.filePath=vo.filePath;
		this.type=vo.type;
		this.name=vo.name;
		this.description=vo.description||"";
		this.icon=vo.icon||"gas.svg";
		this.package=vo.package;
		this.isRPA=vo.isRPA;
		this.rpaHost=vo.rpaHost;
		this.modual=null;
		this.appMeta=null;
		this.appFrameW=vo.appFrameW||0;
		this.appFrameH=vo.appFrameH||0;
		this.enable=vo.enable===false?false:true;
	};

	//------------------------------------------------------------------------
	aaSkill.genSaveVO=async function(){
		let vo = {};
		vo.filePath = this.filePath;
		vo.type = this.type;
		vo.name = this.name;
		vo.description = this.description;
		vo.icon = this.icon;
		vo.package = this.package;
		vo.isRPA = this.isRPA;
		vo.rpaHost = this.rpaHost;
		vo.enable = !!this.enable;
		if(this.appFrameW>0){
			vo.appFrameW=this.appFrameW;
		}
		if(this.appFrameH>0){
			vo.appFrameH=this.appFrameH;
		}
		return vo;
	};
	
	//------------------------------------------------------------------------
	aaSkill.genInfoVO=function(lan){
		let vo={};
		let ref;
		vo.filePath = this.filePath;
		vo.type = this.type;
		vo.name = this.getNameText();
		vo.description = this.getDescText();
		vo.icon = this.icon;
		vo.package = this.package;
		vo.isRPA = this.isRPA;
		vo.rpaHost = this.rpaHost||"NA";
		vo.enable = !!this.enable;
		ref=this.getReference();
		ref.groups=ref.groups.map((g)=>g.getNameText(lan));
		ref.chains=ref.chains.map((c)=>c.getNameText(lan));
		vo.reference=`Chains: ${ref.chains.length?ref.chains:0}. Groups: ${ref.groups.length?ref.groups:0}.`
		return vo;
	};
	
	//------------------------------------------------------------------------
	aaSkill.getNameText=function(lan){
		let text=this.name;
		if(text.EN){
			text=text[lan]||text.EN;
		}
		return text;
	};

	//------------------------------------------------------------------------
	aaSkill.getDescText=function(lan){
		let text=this.description;
		if(text.EN){
			text=text[lan]||text.EN;
		}
		return text;
	};
	
	//------------------------------------------------------------------------
	aaSkill.getReference=function(){
		return this.aaSkills.getSkillRef(this);
	};
}

//****************************************************************************
//::AASkillChain
//****************************************************************************
let AASkillChain,aaSkillChain;
{
	//------------------------------------------------------------------------
	AASkillChain=function(skills){
		this.aaSkills=skills;
		this.name="";
		this.filePath="";
		this.skills={};
		this.guide="";
		this.icon="skillchain.svg";
		this.description="";
		this.enable=true;
		makeNotify(this);
	};
	aaSkillChain=AASkillChain.prototype={};
	
	//------------------------------------------------------------------------
	aaSkillChain.genSaveVO=async function(){
		let vo,skill,skills;
		vo={
			name:this.name,
			guide:this.guide,
			icon:this.icon,
			description:this.description,
			skills:{}
		};
		skills=this.skills;
		for(skill of skills){
			vo.skills[skill.fileName]=skill.fileName;
		}
		return vo;
	};
	
	//------------------------------------------------------------------------
	aaSkillChain.loadFromVO=async function(vo){
		let skill,path,name;
		// Load skill chains from the provided value object (VO):
		this.name = vo.name || '';
		this.guide = vo.guide || '';
		this.icon=vo.icon||'';
		this.description=vo.description||'';
		let chainSkills = vo.skills || {};
		for(name in chainSkills){
			path=chainSkills[name];
			skill=this.aaSkills.getSkill(path);
			if(skill){
				this.skills[name]=skill;
			}else{
				//TODO: Report missing skills:
			}
		}
	};
	
	//------------------------------------------------------------------------
	AASkillChain.loadChainVO=async function(path){
		let chainJSON,ext;
		if(path[0]==="/" && path[1]!=="~" && path[1]!=="/"){
			path="/~"+path;
		}
		ext=pathLib.extname(path).toLowerCase();
		if(ext===".js"){
			chainJSON=(await import(path)).default;
		}else{
			chainJSON=await (await fetch(path)).json();
		}
		return chainJSON;
	};

	//------------------------------------------------------------------------
	aaSkillChain.loadFromPath=async function(path){
		let chainJSON;
		chainJSON=await AASkillChain.loadChainVO(path);
		this.loadFromVO(chainJSON);
	};

	//------------------------------------------------------------------------
	aaSkillChain.getNameText=function(lan){
		let text=this.name;
		if(text.EN){
			text=text[lan]||text.EN;
		}
		return text;
	};

	//------------------------------------------------------------------------
	aaSkillChain.getDescText=function(lan){
		let text=this.description;
		if(text.EN){
			text=text[lan]||text.EN;
		}
		return text;
	};
	
	//------------------------------------------------------------------------
	aaSkillChain.genInfoVO=function(ln){
		let vo={};
		let ref,skills,groups;
		vo.filePath = this.filePath;
		vo.type = this.type;
		vo.name = this.getNameText();
		vo.description = this.getDescText();
		vo.icon = this.icon;
		vo.package = this.package;
		vo.isRPA = this.isRPA;
		vo.rpaHost = this.rpaHost||"NA";
		vo.enable = !!this.enable;
		ref=this.getReference();
		skills=ref.skills.map(s=>s.getNameText(ln));
		groups=ref.groups.map(g=>g.getNameText(ln));
		vo.reference=`Skill: ${skills.length?skills:"0"}. Group: ${groups.length?groups:"0"}`;
		return vo;
	};

	//------------------------------------------------------------------------
	aaSkillChain.getReference=function(){
		let ref;
		ref=this.aaSkills.getChainRef(this);
		ref.skills=Object.values(this.skills);
		return ref;
	};
}

//****************************************************************************
//:AASkillGroup
//****************************************************************************
let AASkillGroup,aaSkillGroup;
{
	AASkillGroup=function(skills){
		this.aaSkills=skills;
		this.codeName="";
		this.name="";
		this.icon="";
		this.description="";
		this.chains=[];
		this.skills=[];
		makeNotify(this);
	};
	aaSkillGroup=AASkillGroup.prototype={};
	
	//------------------------------------------------------------------------
	aaSkillGroup.genSaveVO=async function(){
		let vo={};
		vo.codeName=this.codeName||this.name;
		vo.name=this.name;
		vo.description=this.description;
		vo.skills=this.skills.map(skill => skill.filePath);
		vo.chains=this.chains.map(chain=>chain.filePath);
		vo.icon=this.icon;
		return vo;
	};

	//------------------------------------------------------------------------
	aaSkillGroup.loadFromVO=async function(groupVO){
		let aaSkills,skillStubs,skillStub,skills,skill,chains,chain;
		aaSkills=this.aaSkills;
		// Load group properties from the given value object (VO):
		this.codeName=groupVO.codeName||groupVO.name||"";
		this.name = groupVO.name || '';
		this.description = groupVO.description || '';
		this.icon = groupVO.icon || '';
		// Load the skills by creating AASkill instances for each filePath in the VO:
		skillStubs=groupVO.skills;
		this.skills=skills=[];
		for(skillStub of skillStubs){
			skill=aaSkills.getSkill(skillStub);
			if(skill){
				skills.push(skill);
			}
		}
		// Load the skill chains from the value object:
		chains=groupVO.chains||[];
		this.chains=[];
		for(let chainPath of chains){
			chain=this.aaSkills.getChain(chainPath);
			if(chain){
				this.chains.push(chain);
			}
		}
	};

	//------------------------------------------------------------------------
	aaSkillGroup.addSkill=function(skill){
		let idx;
		idx=this.skills.indexOf(skill);
		if(idx>=0)
			return;
		this.skills.push(skill);
	};
	
	//------------------------------------------------------------------------
	aaSkillGroup.removeSkill=function(skill){
		let idx;
		idx=this.skills.indexOf(skill);
		this.skills.splice(idx,1);
	};

	//------------------------------------------------------------------------
	aaSkillGroup.addChain=function(chain){
		let idx;
		idx=this.chains.indexOf(chain);
		if(idx>=0)
			return;
		this.chains.push(chain);
	};

	//------------------------------------------------------------------------
	aaSkillGroup.removeChain=function(chain){
		let idx;
		idx=this.chains.indexOf(chain);
		this.chains.splice(idx,1);
	};
	
	//------------------------------------------------------------------------
	aaSkillGroup.getNameText=function(lan){
		let text=this.name;
		if(text.EN){
			text=text[lan]||text.EN;
		}
		return text;
	};

	//------------------------------------------------------------------------
	aaSkillGroup.getDescText=function(lan){
		let text=this.description;
		if(text.EN){
			text=text[lan]||text.EN;
		}
		return text;
	};
}

//****************************************************************************
//:AASkillSite
//****************************************************************************
let AASkillSite,aaSkillSite;
{
	AASkillSite=function(skills,hostSite){
		this.aaSkills=skills;
		this.name=getDomain(hostSite);
		this.icon="browser.svg";
		this.hostSite=hostSite;
		this.description=`Skills related to host: ${hostSite}`;
		this.skills=[];
		this.checkLogin="";
	};
	aaSkillSite=AASkillSite.prototype={};
	
	//------------------------------------------------------------------------
	aaSkillSite.genSaveVO=async function(){
		let vo={};
		vo.name=this.name;
		vo.description=this.description;
		vo.hostSite=this.hostSite;
		vo.icon=this.icon;
		vo.checkLogin=this.checkLogin;
		return vo;
	};

	//------------------------------------------------------------------------
	aaSkillSite.loadFromVO=async function(groupVO){
		this.name = groupVO.name || '';
		this.description = groupVO.description || '';
		this.icon = groupVO.icon || '';
		this.hostSite = groupVO.hostSite || '';
		this.checkLogin=groupVO.checkLogin||"";
	};

	//------------------------------------------------------------------------
	aaSkillSite.addSkill=function(skill){
		this.skills.push(skill);
	};
	
	//------------------------------------------------------------------------
	aaSkillSite.removeSkill=function(skill){
		let idx;
		idx=this.skills.indexOf(skill);
		this.skills.splice(idx,1);
	};
}

//****************************************************************************
//:AASkills
//****************************************************************************
let AASkills,aaSkills;
{
	AASkills=function(){
		this.groups=new Map();
		this.sites=new Map();
		this.skills=new Map();
		this.chains=new Map();
		this.fileHandlers={
			open:new Map(),
			edit:new Map()
		};
	};
	aaSkills=AASkills.prototype = {};
	
	//************************************************************************
	//I/O
	//************************************************************************
	{
		//--------------------------------------------------------------------
		aaSkills.genSaveVO=async function(){
			let saveVO = {};
			let list,skill,skills,chains,chain;
			// Generate a Save Value Object (VO) for all skills:
			skills=[];
			list=this.getSkills();
			for(skill of list){
				if(skill.type==="Agent"){
					skills.push({
						type:"Agent",enable:skill.enable,
						filePath:skill.filePath
					});
				}else{
					skills.push(await skill.genSaveVO());
				}
			}
			saveVO.skills=skills;
			
			// Generate a Save Value Object (VO) for all chains:
			chains=Array.from(this.chains.keys());
			saveVO.chains=chains;
			
			// Generate a Save Value Object (VO) for all groups:
			saveVO.groups = [];
			for (let [groupKey, group] of this.groups) {
				let groupSaveVO = await group.genSaveVO();
				saveVO.groups.push(groupSaveVO);
			}
			return saveVO;
		};

		//--------------------------------------------------------------------
		aaSkills.loadFromVO=async function(vo){
			let groupStubs,skillStubs,chainStubs;
			//Load all skills:
			skillStubs = vo.skills || [];
			await Promise.all(skillStubs.map(async (skillStub) => {
				await this.loadSkill(skillStub);
			}));
			chainStubs = vo.chains || [];
			await Promise.all(chainStubs.map(async (chainStub) => {
				await this.loadChain(chainStub);
			}));
			// Load all groups, hosts, and skills from the provided value object (VO):
			groupStubs = vo.groups || [];
			for(let groupVO of groupStubs){
				let group = new AASkillGroup(this);
				await group.loadFromVO(groupVO);
				this.groups.set(group.name, group);
			}
		};

		//--------------------------------------------------------------------
		aaSkills.loadSkill=async function(skillStub){
			let skillPath,skill,host;
			if(typeof(skillStub)==="object"){
				skillPath=skillStub.filePath;
				skill=this.skills.get(skillPath);
				if(skill){
					return skill;
				}
				skill=new AASkill(this);
				if(skillStub.type==="Agent"){
					skillPath=skillStub.filePath;
					try {
						await skill.loadFromPath(skillPath);
						this.skills.set(skillPath, skill);
						host=skill.rpaHost;
						if(host){
							let hostSite;
							hostSite=this.sites.get(host);
							if(!hostSite){
								hostSite=new AASkillSite(this,host);
								this.sites.set(host,hostSite);
							}
							hostSite.addSkill(skill);
						}
						skill.enable=skillStub.enable;
						return skill;
					} catch (error) {
						console.error(`Failed to load skill from path: ${skillPath}`, error);
						return null;
						//throw error;
					}
					
				}else{
					try {
						let handleFiles;
						await skill.loadFromVO(skillStub);
						this.skills.set(skillPath, skill);
						host=skill.rpaHost;
						if(host){
							let hostSite;
							hostSite=this.sites.get(host);
							if(!hostSite){
								hostSite=new AASkillSite(this,hostSite);
								this.sites.set(host,hostSite);
							}
							hostSite.addSkill(skill);
						}
						handleFiles=skill.handleFiles;
						if(handleFiles){
							let types,fileType,map;
							types=handleFiles.open;
							if(types){
								map=this.fileHandlers.open;
								for(fileType of types){
									map.set(fileType,skill);
								}
							}
							types=handleFiles.edit;
							if(types){
								map=this.fileHandlers.edit;
								for(fileType of types){
									map.set(fileType,skill);
								}
							}
						}
						return skill;
					} catch (error) {
						console.error(`Failed to load skill from path: ${skillPath}`, error);
						return null;
						//throw error;
					}
				}
			}
			//Stub is skill path:
			skillPath=skillStub;
			skill=this.skills.get(skillPath);
			if(skill){
				return skill;
			}
			skill = new AASkill(this);
			try {
				await skill.loadFromPath(skillPath);
				this.skills.set(skillPath, skill);
				host=skill.rpaHost;
				if(host){
					let hostSite;
					hostSite=this.sites.get(host);
					if(!hostSite){
						hostSite=new AASkillSite(this,host);
						this.sites.set(host,hostSite);
					}
					hostSite.addSkill(skill);
				}
				return skill;
			} catch (error) {
				console.error(`Failed to load skill from path: ${skillPath}`, error);
				//throw error;
				return null;
			}
		};
		
		//--------------------------------------------------------------------
		aaSkills.loadChain=async function(chainPath){
			let chain;
			chain=this.chains.get(chainPath);
			if(chain){
				return chain;
			}
			chain=new AASkillChain(this);
			chain.filePath=chainPath;
			await chain.loadFromPath(chainPath);
			this.chains.set(chainPath,chain);
			return chain;
		};
	}
	
	//************************************************************************
	//Access contents:
	//************************************************************************
	{	
		//--------------------------------------------------------------------
		aaSkills.getSkill=function(filePath){
			return this.skills.get(filePath);
		};
		
		//--------------------------------------------------------------------
		aaSkills.getChain=function(filePath){
			return this.chains.get(filePath);
		};
		
		//--------------------------------------------------------------------
		aaSkills.getGroup=function(name){
			return this.groups.get(name);
		};
		
		//--------------------------------------------------------------------
		aaSkills.addGroup=function(name){
			let group;
			group=this.groups.get(name);
			if(group){
				return group;
			}
			group = new AASkillGroup(this);
			group.name=name;
			this.groups.set(name,group);
			return group;
		};
		
		//--------------------------------------------------------------------
		aaSkills.renameGroup=function(group,name){
			let oldName;
			oldName=group.name;
			this.groups.delete(oldName);
			group.name=name;
			this.groups.set(name,group);
			return group;
		};

		//--------------------------------------------------------------------
		aaSkills.removeGroup=function(group){
			let oldName;
			oldName=group.name;
			this.groups.delete(oldName);
		};

		//--------------------------------------------------------------------
		aaSkills.getSkills=function(){
			return Array.from(this.skills.values());
		};

		//--------------------------------------------------------------------
		aaSkills.getChains=function(){
			return Array.from(this.chains.values());
		};

		//--------------------------------------------------------------------
		aaSkills.getGroups=function(sort){
			let groups;
			groups=Array.from(this.groups.values());
			if(sort){
				groups.sort((a,b)=>{return a>b?1:(a<b?-1:0);});
			}
			return groups;
		};

		//--------------------------------------------------------------------
		aaSkills.getSites=function(sort){
			let groups;
			groups=Array.from(this.sites.values());
			if(sort){
				groups.sort((a,b)=>{return a>b?1:(a<b?-1:0);});
			}
			return groups;
		};

		//--------------------------------------------------------------------
		aaSkills.getSkillAPIIndex=function(){
			//TODO: Code this:
		};

		//--------------------------------------------------------------------
		aaSkills.getSkillDescIndex=aaSkills.getSkillScope=function(){
			let skills,vo,skill,i,n;
			skills=Array.from(this.skills.values());
			vo={};
			n=skills.length;
			for(i=0;i<n;i++){
				skill=skills[i];
				if(skill.enable){
					vo["Skill-"+i]=skill.description;
				}
			}
			return vo;
		};
		
		//--------------------------------------------------------------------
		aaSkills.removeSkill=function(skill,ref){
			let g;
			if(!ref){
				ref=this.getSkillRef(skill);
			}
			for(g of ref.groups){
				g.removeSkill(skill);
			}
			this.skills.delete(skill.filePath);
		};

		//--------------------------------------------------------------------
		aaSkills.removeChain=function(chain,ref){
			let g;
			if(!ref){
				ref=this.getChainRef(chain);
			}
			for(g of ref.groups){
				g.removeChain(chain);
			}
			this.chains.delete(chain.filePath);
		};
	}
	
	//************************************************************************
	//Run skill or chain:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		aaSkills.execSkill=async function(app,skill,args,session){
			switch(skill.type){
				case "App":{
					let meta,icon;
					meta=skill.appMeta;
					if(!meta){
						let ext;
						ext=pathLib.extname(skill.filePath).toLowerCase();
						icon=skill.icon;
						if(icon[0]!=="/"){
							icon="/~/-tabos/shared/assets/"+icon;
						}
						meta={
							type:"app",
							name:skill.name,
							caption:skill.name,
							icon:icon,
							appFrame:{
								group:"Projects",caption:skill.name,openApp:true,multiInstance:false,
								icon:icon,
								width:skill.appFrameW||360,
								height:skill.appFrameH||600,
							}
						};
						if(ext===".js"){
							meta.appFrame.uiDef=skill.filePath;
						}else{
							meta.appFrame.main=skill.filePath;
						}
						skill.appMeta=meta;
					}
					app.newFrameApp(meta,{},{});
					return `App ${skill.name} started.`;
				}
				case "Page":{
					window.open(document.location.origin+skill.filePath,"","noreferrer");
					return `Page ${skill.name} started.`;
				}
				case "Agent":{
					let meta,icon;
					if(session){
						return await session.pipeChat(skill.filePath,args,false);
					}else{
						meta=skill.appMeta;
						if(!meta){
							icon=skill.icon||"aichat.svg";
							if(icon[0]!=="/"){
								icon="/~/-tabos/shared/assets/"+icon;
							}
							meta={
								type:"app",
								name:"Projects",
								caption:skill.name,
								icon:icon,
								appFrame:{
									group:"Projects",caption:skill.name,openApp:true,multiInstance:false,
									icon:icon,
									width:skill.appFrameW||800,
									height:skill.appFrameH||600,
								}
							};
							meta.appFrame.main=`/@aichat/app.html?chat=${encodeURIComponent(skill.filePath)}&style=pro`;
							skill.appMeta=meta;
						}					
						app.newFrameApp(meta,null,{});
					}
					return "Agent app started.";
				}
				case "API":{
					//TODO: Code this:
					break;
				}
			}
		};
		
		//--------------------------------------------------------------------
		aaSkills.execChain=async function(app,chain,args,session){
			let meta,icon;
			if(session){
				//TODO: Use pipechat:
			}else{
				meta=this.chainAppMeta;
				if(!meta){
					icon="/~/-tabos/shared/assets/aalogo.svg";
					meta={
						type:"app",
						name:"Run command",
						caption:"Run command",
						icon:icon,
						appFrame:{
							group:"RunChain",caption:"Run Skill-Chain",openApp:true,multiInstance:false,
							icon:icon,width:600,height:600,
						}
					};
					this.chainAppMeta=meta;
				}
				meta.appFrame.main=`/@aichat/app.html?chat=${encodeURIComponent("/@aae/ai/RunSkillChain.js")}&prompt=${encodeURIComponent(chain.filePath)}&style=pro`;
				app.newFrameApp(meta,null,{});
			}
		};
	}
	
	//************************************************************************
	//Utils:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		aaSkills.getSkillRef=function(skill){
			let groups,group,chains,chain,list;
			let ref={
				groups:[],chains:[]
			};
			groups=Array.from(this.groups.values());
			chains=Array.from(this.chains.values());
			for(group of groups){
				if(group.skills.indexOf(skill)>=0){
					ref.groups.push(group);
				}
			}
			for(chain of chains){
				if(Object.values(chain.skills).indexOf(skill)>=0){
					ref.chains.push(chain);
				}
			}
			return ref;
		};

		//--------------------------------------------------------------------
		aaSkills.getChainRef=function(chain){
			let groups,group,list;
			let ref={
				groups:[],chains:[]
			};
			groups=Array.from(this.groups.values());
			for(group of groups){
				if(group.chains.indexOf(chain)>=0){
					ref.groups.push(group);
				}
			}
			return ref;
		};
	}
}

export default AASkills;
export {AASkill,AASkillChain,AASkillGroup,AASkillSite,AASkills};