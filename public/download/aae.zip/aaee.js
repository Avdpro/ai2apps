import {tabNT} from "/@tabos";
let compileActions;
let AAEE;
//****************************************************************************
//AAEE 
//****************************************************************************
{
	AAEE=function(){
		this.browser=null;
		this.waitMap=new Map();
	};
	const aaee=AAEE.prototype={};

	//----------------------------------------------------------------------------
	aaee.init=async function(opts){
		let res;
		opts=opts||{headless:false,devtools:true};
		res=await tabNT.makeCall("aaeeOpenBrowser",{options:opts});
		if(!res || res.code!==200){
			return false;
		}
		this.browser=res.browser;
		//Keep browser alive:
		this.hbTimer=setInterval(()=>{
			tabNT.makeCall("aaeeHeartBeat",{browser:this.browser});
		},2*60*1000);
		return true;
	};

	//------------------------------------------------------------------------
	aaee.waitStart=async function(){
		return true;
	};

	//------------------------------------------------------------------------
	aaee.getVersion=async function(){
		let res;
		res=await tabNT.makeCall("aaeeGetVersion",{});
		if(!res || res.code!==200){
			return null;
		}
		return res.version;
	};
	
	//------------------------------------------------------------------------
	aaee.getTabId=async function(){
		//TODO: Rewrite this one:
		return await this.call("CONTENT","GetTabId");
	};

	//------------------------------------------------------------------------
	aaee.connect=async function(){
		return true;
	};

	//************************************************************************
	//:Page access: open, close, focus, capture page:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		aaee.openClient=async function(url,scripts){
			let res,pageId,client;
			res=await tabNT.makeCall("aaeeOpenPage",{browser:this.browser});
			if(!res || res.code!==200){
				return null;
			}
			pageId=res.page;
			res=await tabNT.makeCall("aaeeOpenURL",{page:pageId,url:url});
			if(!res || res.code!==200){
				return null;
			}
			client={page:pageId,browser:this.browser};
			return client;
		};
		
		//--------------------------------------------------------------------
		aaee.waitPageLoad=async function(client,timeout){
			let res;
			res=await tabNT.makeCall("aaeeWaitPageLoad",{page:client.page,timeout:timeout});
			if(!res || res.code!==200){
				return null;
			}
			return {title:res.title,url:res.url};
		};

		//--------------------------------------------------------------------
		aaee.closePage=async function(client){
			let res;
			res=await tabNT.makeCall("aaeeClosePage",{page:client.page});
			if(!res || res.code!==200){
				return false;
			}
			return true;		
		};

		//--------------------------------------------------------------------
		aaee.activeTab=async function(client,timeout){
			let res;
			if(!client){
				return true;
			}
			res=await tabNT.makeCall("aaeeBringToFront",{page:client.page});
			if(!res || res.code!==200){
				return false;
			}
			return true;		
		};
		
		//--------------------------------------------------------------------
		aaee.captureTab=async function(client){
			let res;
			res=await tabNT.makeCall("aaeeCapturePage",{page:client.page});
			if(!res || res.code!==200){
				return null;
			}
			return res.image;
		};

		//--------------------------------------------------------------------
		aaee.execScripts=async function(client,codes){
			//TODO: Code this:
			return false;
		};
	}	
	
	//************************************************************************
	//Read/Query API:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		aaee.readPageView=async function(client){
			let res;
			res=await tabNT.makeCall("aaeeReadPageView",{page:client.page});
			if(!res || res.code!==200){
				return null;
			}
			return res.view;
		};

		//--------------------------------------------------------------------
		aaee.readPageHTML=async function(client){
			let res;
			res=await tabNT.makeCall("aaeeReadPageHTML",{page:client.page});
			if(!res || res.code!==200){
				return null;
			}
			return res.html;
		};

		//--------------------------------------------------------------------
		aaee.readPageInnerText=async function(client){
			let res;
			res=await tabNT.makeCall("aaeeReadPageText",{page:client.page});
			if(!res || res.code!==200){
				return null;
			}
			return res.text;
		};

		//--------------------------------------------------------------------
		aaee.readPageArticle=async function(client){
			let res;
			res=await tabNT.makeCall("aaeeReadPageArticle",{page:client.page});
			if(!res || res.code!==200){
				return null;
			}
			return res.text;
		};

		//--------------------------------------------------------------------
		aaee.readNodeView=async function(client,aaeId){
			let res;
			res=await tabNT.makeCall("aaeeReadNodeView",{page:client.page,aaeId:aaeId});
			if(!res || res.code!==200){
				return null;
			}
			return res.view;
		};

		//--------------------------------------------------------------------
		aaee.readNodeText=async function(client,aaeId){
			let res;
			res=await tabNT.makeCall("aaeeReadNodeText",{page:client.page,aaeId:aaeId});
			if(!res || res.code!==200){
				return null;
			}
			return res.text;
		};

		//--------------------------------------------------------------------
		aaee.queryNode=async function(client,selector,aaeId,opts){
			let res;
			res=await tabNT.makeCall("aaeeQueryNode",{page:client.page,selector:selector,aaeId:aaeId,opts:opts});
			if(!res || res.code!==200){
				return null;
			}
			return res.node;
		};

		//--------------------------------------------------------------------
		aaee.queryNodes=async function(client,selector,opts){
			let res,aaeId,visibleOnly;
			if(opts){
				if(typeof(opts)==="object"){
					aaeId=opts.root||opts.from||opts.AAEId||opts.aaeId||undefined;
					aaeId=aaeId.AAEId||undefined;
					if("filterVisible" in opts){
						visibleOnly=opts.filterVisible;
					}
				}else{
					aaeId=opts;
					opts=null;
				}
				res=await tabNT.makeCall("aaeeQueryNodes",{page:client.page,selector:selector,aaeId:aaeId,opts:opts});
			}else{
				res=await tabNT.makeCall("aaeeQueryNodes",{page:client.page,selector:selector,opts:opts});
			}
			if(!res || res.code!==200){
				return null;
			}
			return res.list;
		};

		//--------------------------------------------------------------------
		aaee.getNodeParent=async function(client,aaeId){
			let res;
			aaeId=aaeId.AAEId||aaeId;
			res=await tabNT.makeCall("aaeeGetNodeParent",{page:client.page,aaeId:aaeId});
			if(!res || res.code!==200){
				return false;
			}
			return res.node;
		};

		//--------------------------------------------------------------------
		aaee.getNodeChildren=async function(client,aaeId){
			let res;
			aaeId=aaeId.AAEId||aaeId;
			res=await tabNT.makeCall("aaeeGetNodeChildren",{page:client.page,aaeId:aaeId});
			if(!res || res.code!==200){
				return null;
			}
			return res.children;
		};

		//--------------------------------------------------------------------
		aaee.getNodeAttribute=async function(client,aaeId,key){
			let res;
			aaeId=aaeId.AAEId||aaeId;
			res=await tabNT.makeCall("aaeeGetNodeAttribute",{page:client.page,aaeId:aaeId,key:key});
			if(!res || res.code!==200){
				return null;
			}
			return res.value;
		};

		//--------------------------------------------------------------------
		aaee.setNodeAttribute=async function(client,aaeId,key,value){
			let res;
			aaeId=aaeId.AAEId||aaeId;
			res=await tabNT.makeCall("aaeeSetNodeAttribute",{page:client.page,aaeId:aaeId,key:key,value:value});
			if(!res || res.code!==200){
				return false;
			}
			return true;
		};

		//--------------------------------------------------------------------
		aaee.getNodeAttributes=async function(client,aaeId){
			let res;
			aaeId=aaeId.AAEId||aaeId;
			res=await tabNT.makeCall("aaeeGetNodeAttributes",{page:client.page,aaeId:aaeId});
			if(!res || res.code!==200){
				return null;
			}
			return res.attributes;
		};
	}
	
	//************************************************************************
	//Wait API:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		//aaee.waitPageLoad already declared in Page access section:
		
		//--------------------------------------------------------------------
		aaee.waitFor=async function(client,waitName){
			let pageId=client.page;
			let waitId=waitName+"@"+pageId;
			let waitPms=this.waitMap.get(waitId);
			if(!waitPms){
				return false;
			}
			await waitPms;
			return true;
		};
		
		//--------------------------------------------------------------------
		aaee.waitForNavigation=async function(client){
			//TODO: Code this:
			let res;
			res=await tabNT.makeCall("aaeeGetNodeAttributes",{page:client.page,aaeId:aaeId});
			if(!res || res.code!==200){
				return null;
			}
			return res.attributes;
		};

		//--------------------------------------------------------------------
		aaee.waitQuery=async function(client,query){
			//TODO: Wait query node:
		};
		
		//--------------------------------------------------------------------
		aaee.waitPrompt=async function(client){
			//TODO: Code this:
		};

		//--------------------------------------------------------------------
		aaee.waitFileChooser=async function(client){
			//TODO: Code this:
		};

		//--------------------------------------------------------------------
		aaee.waitDialog=async function(client){
			//TODO: Code this:
		};
	}
	
	//************************************************************************
	//Run user action on page:
	//************************************************************************
	{
		
		//--------------------------------------------------------------------
		aaee.runAction=async function(client,actions){
			//TODO: Code this:
		};
	}
}

//----------------------------------------------------------------------------
//Compile action array with arguments:
{
	function compileActionVal(act,valName,args){
		let val=act[valName];
		if(typeof(val)==="string" && val.startsWith("#")){
			let code,func;
			code=`return \`${val.substring(1)}\``;
			func=new Function(...args.keys,`return (${code});`);
			act[valName]=func.apply(null,args.values);
		}
	}

	//----------------------------------------------------------------------------
	function compileAction(vo,args){
		let act;
		act={...vo};
		compileActionVal(act,"content",args);
		return act;
	}

	//----------------------------------------------------------------------------
	compileActions=function(actAry,args){
		let actions;
		args={
			keys:Object.keys(args),
			values:Object.values(args),
		};
		if(!Array.isArray(actAry)){
			actAry=[actAry];
		}
		return actAry.map((act)=>{return compileAction(act,args)});
	}
}