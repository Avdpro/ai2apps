import {sleep} from "/@vfact";
import {tabNT} from "/@tabos";
import ReadView from "./readview.js";
import {AIQuery} from "./aiquery.js";
let AAFarm,AABrowser,AAPage,AAFrame;
let aaFarm,aaBrowser,aaPage,aaFrame;
let randomTag,compileActionVal,compileAction,compileActions;
{
	//----------------------------------------------------------------------------
	randomTag=function(digit=6,time=true){
		const characters = 'abcdefghijklmnopqrstuvwxyz0123456789';
		let result = '';
		const charactersLength = characters.length;
		if(time){
			time=""+Date.now();
			time=time.substring(time.length-6);
		}
		for (let i = 0; i < digit; i++) {
			result += characters.charAt(Math.floor(Math.random() * charactersLength));
		}
		return "$"+result+time;
	};
	
	//----------------------------------------------------------------------------
	compileActionVal=function(act,valName,args){
		let val=act[valName];
		if(typeof(val)==="string"){
			if(val.startsWith("#")){
				let code,func,list;
				code=`return (${val.substring(1)});`;
				func=new Function(...args.keys,code);
				act[valName]=func.apply(null,args.values);
			}
		}
	};

	//----------------------------------------------------------------------------
	compileAction=function(vo,args){
		let act;
		act={...vo};
		compileActionVal(act,"query",args);
		compileActionVal(act,"content",args);
		compileActionVal(act,"key",args);
		compileActionVal(act,"x",args);
		compileActionVal(act,"y",args);
		return act;
	};

	//----------------------------------------------------------------------------
	compileActions=function(actAry,args){
		args={
			keys:Object.keys(args),
			values:Object.values(args),
		};
		if(!Array.isArray(actAry)){
			actAry=[actAry];
		}
		return actAry.map((act)=>{return compileAction(act,args);});
	};
}

//****************************************************************************
//:AAFarm:
//****************************************************************************
{
	//------------------------------------------------------------------------
	AAFarm=function(){
		this.browserMap=new Map();
	};
	aaFarm=AAFarm.prototype={};
	
	//------------------------------------------------------------------------
	aaFarm.setupAIQuery=async function(session,context,agentPath,agentJaxId){
		let aiQuery=this.aiQuery=new AIQuery(session,context,agentPath,agentJaxId);
		await aiQuery.setup();
	};
	
	//------------------------------------------------------------------------
	aaFarm.getBrowsers=async function(){
		let res;
		res=await tabNT.makeCall("aaeeGetBrowsers",{});
		if(!res || res.code!==200){
			if(res && res.info){
				throw Error(res.info);
			}
			throw Error("open");
		}
		return res.browsers??[];
	};

	//------------------------------------------------------------------------
	aaFarm.openBrowser=async function(alias,opts){
		let browser;
		if(alias){
			browser=this.browserMap.get(alias);
			if(browser){
				return browser;
			}
		}
		opts=opts||{headless:false,devtools:true};
		browser=new AABrowser(this,alias);
		await browser.open(opts);
		if(alias){
			this.browserMap.set(alias,browser);
		}
		return browser;
	};
	
	//------------------------------------------------------------------------
	aaFarm.getClipboard=async function(){
		let res;
		res=await tabNT.makeCall("aaeeGetClipboard",{});
		if(!res || res.code!==200){
			if(res && res.info){
				throw Error(res.info);
			}
			throw Error("open");
		}
		return res.content;
	};
	
	//------------------------------------------------------------------------
	AAFarm.getLocalAlias=async function(){
		let topWin,tag,oldTitle,doc,res,alias;
		topWin=window;
		while(topWin.parent && topWin.parent!==topWin){
			topWin=topWin.parent;
		}
		doc=topWin.document;
		//TODO: Get top window's document
		tag=randomTag();
		oldTitle=doc.title;
		if(oldTitle[0]!=="$"){
			doc.title=tag;
		}
		res=await tabNT.makeCall("aaeeGetPageByTitle",{title:tag});
		if(res && res.code===200){
			alias=res.alias;
		}
		if(oldTitle[0]!=="$"){
			doc.title=oldTitle;
		}
		return alias||null;
	};
}

//****************************************************************************
//:AABrowser
//****************************************************************************
{
	//------------------------------------------------------------------------
	AABrowser=function(farm,alias){
		this.farm=farm;
		this.alias=alias||"";
		this.browserId=null;
		this.pageMap=new Map();
		this.hostPage=null;
		this.hostPageId=null;
	};
	aaBrowser=AABrowser.prototype={};
	
	//------------------------------------------------------------------------
	aaBrowser.open=async function(opts){
		let res;
		opts=opts||{headless:false,devtools:false};
		res=await tabNT.makeCall("aaeeOpenBrowser",{alias:this.alias,options:opts});
		if(!res || res.code!==200){
			if(res && res.info){
				throw Error(res.info);
			}
			throw Error("open");
		}
		this.browserId=res.browser;
		this.alias=res.alias;
		//Keep browser alive:
		this.hbTimer=setInterval(()=>{
			tabNT.makeCall("aaeeHeartBeat",{browser:this.browserId});
		},2*60*1000);
		await this.getHostPage();
		return true;
	};
	
	//------------------------------------------------------------------------
	aaBrowser.newPage=async function(){
		let page;
		page=new AAPage(this);
		await page.open();
		//Add to page map:
		this.pageMap.set(page.pageId,page);
		return page;
	};
	
	//------------------------------------------------------------------------
	aaBrowser.getPages=async function(){
		let res,pageIds,pages,pageId,page;
		res=await tabNT.makeCall("aaeeGetPages",{browser:this.browserId});
		if(!res || res.code!==200){
			if(res && res.info){
				throw Error(res.info);
			}
			throw Error("open");
		}
		pageIds=res.pages;
		pages=[];
		for(pageId of pageIds){
			page=this.pageMap.get(pageId);
			if(!page){
				page=new AAPage(this,pageId);
				this.pageMap.set(pageId,page);
			}
			pages.push(page);
		}
		return pages;
	};
	
	//------------------------------------------------------------------------
	aaBrowser.getHostPage=async function(){
		let topWin,doc,oldTitle,tag;
		topWin=window;
		while(topWin.parent && topWin.parent!==topWin){
			topWin=topWin.parent;
		}
		doc=topWin.document;
		tag=randomTag();
		oldTitle=doc.title;
		doc.title=tag;
		let res,pageId,page;
		res=await tabNT.makeCall("aaeeGetPageByTitle",{browser:this.browserId,title:tag});
		if(!res || res.code!==200){
			if(res && res.info){
				throw Error(res.info);
			}
			throw Error("open");
		}
		pageId=res.page;
		doc.title=oldTitle;
		if(pageId){
			page=this.pageMap.get(pageId);
			if(!page){
				page=new AAPage(this,pageId);
				this.pageMap.set(pageId,page);
			}
			this.hostPageId=pageId;
			this.hostPage=page;
			return page;
		}
		return null;
	};
	
	//------------------------------------------------------------------------
	aaBrowser.saveFile=async function(fileName,base64Data){
		let res;
		//Fix base64Data if needed:
		if(base64Data.startsWith("data:")){
			let pos=base64Data.indexOf(",");
			base64Data=base64Data.substring(pos);
		}
		res=await tabNT.makeCall("aaeeSaveFile",{browser:this.browserId,data:base64Data,fileName:fileName});
		if(!res || res.code!==200){
			if(res && res.info){
				throw Error(res.info);
			}
			throw Error("open");
		}
		return true;
	};

	//------------------------------------------------------------------------
	aaBrowser.deleteFile=async function(fileName){
		let res;
		res=await tabNT.makeCall("aaeeDeleteFile",{browser:this.browserId,fileName:fileName});
		if(!res || res.code!==200){
			if(res && res.info){
				throw Error(res.info);
			}
			throw Error("open");
		}
		return true;
	};
}

//****************************************************************************
//:AAPage
//****************************************************************************
{
	//------------------------------------------------------------------------
	AAPage=function(browser,pageId){
		this.browser=browser;
		this.farm=browser.farm;
		this.browserId=browser.browserId;
		this.pageId=pageId||null;
		this.waitMap=new Map();
		this.frameMap=new Map();
		this.isTracing=false;
		this.lastTraceEventIdx=0;
		this.willStopTrace=false;
		this.traceCallbacks=[];
	};
	aaPage=AAPage.prototype={};
	
	//------------------------------------------------------------------------
	aaPage.open=async function(){
		let res;
		res=await tabNT.makeCall("aaeeOpenPage",{browser:this.browserId});
		if(!res || res.code!==200){
			if(res && res.info){
				throw Error(res.info);
			}
			throw Error("Open page failed.");
		}
		this.pageId=res.page;
		return true;
	};

	//------------------------------------------------------------------------
	aaPage.close=async function(){
		let res;
		res=await tabNT.makeCall("aaeeClosePage",{browser:this.browserId,page:this.pageId});
		if(!res || res.code!==200){
			if(res && res.info){
				throw Error(res.info);
			}
			throw Error("Close page failed.");
		}
		if(this.browser.hostPage){
			this.browser.hostPage.active();
		}
		return true;
	};
	
	//------------------------------------------------------------------------
	aaPage.active=async function(){
		let res;
		res=await tabNT.makeCall("aaeeBringToFront",{browser:this.browserId,page:this.pageId});
		if(!res || res.code!==200){
			if(res && res.info){
				throw Error(res.info);
			}
			throw Error("Close page failed.");
		}
		return true;
	};
	
	//------------------------------------------------------------------------
	aaPage.screenshot=async function(options){
		let res;
		res=await tabNT.makeCall("aaeeCapturePage",{browser:this.browserId,page:this.pageId,options:options});
		if(!res || res.code!==200){
			return null;
		}
		if(this.browser.hostPage){
			this.browser.hostPage.active();
		}
		return res.image;
	};
	
	//************************************************************************
	//Page settings:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		aaPage.setUserAgent=async function(ua){
			let res;
			res=await tabNT.makeCall("aaeeSetPageUserAgent",{browser:this.browserId,page:this.pageId,userAgent:ua});
			if(!res || res.code!==200){
				if(res && res.info){
					throw Error(res.info);
				}
				throw Error("setUserAgent failed.");
			}
			return true;
		};

		//--------------------------------------------------------------------
		aaPage.getViewport=async function(){
			let res;
			res=await tabNT.makeCall("aaeeGetPageViewport",{browser:this.browserId,page:this.pageId});
			if(!res || res.code!==200){
				if(res && res.info){
					throw Error(res.info);
				}
				throw Error("getViewport failed.");
			}
			return res.viewport;
		};

		//--------------------------------------------------------------------
		aaPage.setViewport=async function(vp){
			let res;
			res=await tabNT.makeCall("aaeeSetPageViewport",{browser:this.browserId,page:this.pageId,viewport:vp});
			if(!res || res.code!==200){
				if(res && res.info){
					throw Error(res.info);
				}
				throw Error("setViewport failed.");
			}
			return true;
		};

		//--------------------------------------------------------------------
		aaPage.getTitle=async function(){
			let res;
			res=await tabNT.makeCall("aaeeGetPageTitle",{browser:this.browserId,page:this.pageId,frame:this.frameId});
			if(!res || res.code!==200){
				if(res && res.info){
					throw Error(res.info);
				}
				throw Error("getViewport failed.");
			}
			return res.title;
		};

		//--------------------------------------------------------------------
		aaPage.getURL=async function(){
			let res;
			res=await tabNT.makeCall("aaeeGetPageURL",{browser:this.browserId,page:this.pageId,frame:this.frameId});
			if(!res || res.code!==200){
				if(res && res.info){
					throw Error(res.info);
				}
				throw Error("getViewport failed.");
			}
			return res.url;
		};
	}
	
	//************************************************************************
	//:Navigation functions:
	//************************************************************************
	{
		//------------------------------------------------------------------------
		aaPage.goto=async function(url,options){
			let res;
			res=await tabNT.makeCall("aaeeGoto",{browser:this.browserId,page:this.pageId,frame:this.frameId,url:url,options:options});
			if(!res || res.code!==200){
				if(res && res.info){
					throw Error(res.info);
				}
				throw Error("Goto url failed.");
			}
			return true;
		};

		//------------------------------------------------------------------------
		aaPage.goBack=async function(url,options){
			let res;
			res=await tabNT.makeCall("aaeeGoBack",{browser:this.browserId,page:this.pageId,url:url,options:options});
			if(!res || res.code!==200){
				if(res && res.info){
					throw Error(res.info);
				}
				throw Error("GoBack failed.");
			}
			return true;
		};

		//------------------------------------------------------------------------
		aaPage.goForward=async function(url,options){
			let res;
			res=await tabNT.makeCall("aaeeGoForward",{browser:this.browserId,page:this.pageId,url:url,options:options});
			if(!res || res.code!==200){
				if(res && res.info){
					throw Error(res.info);
				}
				throw Error("GoForward failed.");
			}
			return true;
		};
	}

	//************************************************************************
	//:Wait functions:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		aaPage.awaitFor=async function(name){
			let pms,result;
			pms=this.waitMap.get(name);
			if(!pms){
				return;
			}
			result=await pms;
			this.waitMap.delete(name);
			return result;
		};
		
		//--------------------------------------------------------------------
		//action can be: navi/navigation, prompt/devicePrompt, filechooser, networkidle, dialog
		aaPage.waitFor=async function(name,action,options){
			let pms;
			action=action.toLowerCase();
			if(action==="click" || action==="keydown"){
				let calltime=Date.now();
				let timeout=options.timeout||0;
				let callback,chkFunc,doneCallback;
				chkFunc=options.check||options.filter;
				callback=async (evt)=>{
					if(evt.event===action){
						if(chkFunc){
							let result=await chkFunc(evt);
							if(result===true){
								this.stopTrace(callback);
								doneCallback && doneCallback();
							}
						}else{
							this.stopTrace(callback);
							doneCallback && doneCallback();
						}
					}
				};
				this.startTrace(callback);
				pms=new Promise(async (resolve,reject)=>{
					doneCallback=resolve;
				});
				this.waitMap.set(name,pms);
				return pms;
			}
			pms=new Promise(async (resolve,reject)=>{
				let res;
				res=await tabNT.makeCall("aaeeWaitFor",{browser:this.browserId,page:this.pageId,frame:this.frameId,action:action,options:options});
				if(!res || res.code!==200){
					if(res && res.info){
						reject(Error(res.info));
					}
					reject(Error("Wait for failed."));
				}
				resolve();
			});
			this.waitMap.set(name,pms);
			return pms;
		};
		
		//--------------------------------------------------------------------
		aaPage.waitForQuery=async function(name,query,options){
			let pms,timeout,startTime;
			timeout=options?(options.timeout||0):0;
			pms=new Promise(async (resolve,reject)=>{
				let node;
				if(timeout>0){
					startTime=Date.now();
				}
				do{
					try{
						node=await this.queryNode(null,query,options);
					}catch(err){
						node=null;
					}
					console.log("Query step.");
					await sleep(300);
					if(startTime && (Date.now()-startTime)>timeout){
						reject("Timeout");
						return;
					}
				}while(!node);
				resolve();
			});
			this.waitMap.set(name,pms);
			return pms;
		};
		
		//--------------------------------------------------------------------
		aaPage.waitForFunction=async function(name,funcCode,options){
			let pms;
			pms=new Promise(async (resolve,reject)=>{
				let res;
				res=await tabNT.makeCall("aaeeWaitFunction",{browser:this.browserId,page:this.pageId,frame:this.frameId,code:funcCode,options:options});
				if(!res || res.code!==200){
					if(res && res.info){
						reject(Error(res.info));
					}
					reject(Error("Wait for failed."));
				}
				resolve();
			});
			this.waitMap.set(name,pms);
			return pms;
		};
	}
	
	//************************************************************************
	//:Page content access:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		aaPage.readView=async function(baseNode,opts){
			let res;
			baseNode=baseNode?(baseNode.AAEId||baseNode):null;
			res=await tabNT.makeCall("aaeeReadNodeView",{browser:this.browserId,page:this.pageId,frame:this.frameId,aaeId:baseNode,options:opts});
			if(!res || res.code!==200){
				if(res && res.info){
					throw Error(res.info);
				}
				throw Error("ReadView failed.");
			}
			return res.view;
		};

		//--------------------------------------------------------------------
		aaPage.readInnerHTML=async function(baseNode,opts){
			let res,html;
			baseNode=baseNode?(baseNode.AAEId||baseNode):null;
			if(opts){
				let markedRoot;
				opts.marked=true;
				res=await tabNT.makeCall("aaeeReadNodeHTML",{browser:this.browserId,page:this.pageId,frame:this.frameId,aaeId:baseNode,options:opts});
				if(!res || res.code!==200){
					if(res && res.info){
						throw Error(res.info);
					}
					throw Error("ReadHTML failed.");
				}
				html=res.html;
				markedRoot=document.createElement("div");
				markedRoot.innerHTML=html;
				if(opts.compact>0){
					//Remove script and style tag
					ReadView.excludeNodes(markedRoot);
				}
				if(opts.compact>1){
					//Remove hidden node
					ReadView.removeHiddenNodes(markedRoot);
				}
				if(opts.compact>2){
					//Remove aaerect and aaestyle:
					ReadView.removeAttributes(markedRoot,["aaestyle","aaerect","pose"],true);
				}
				if(opts.compact>3){
					ReadView.shortNodesText(markedRoot,30);
				}
				if(opts.compact>4){
					ReadView.mergeNodeTree(markedRoot);
				}
				if(opts.shortText>0){
					ReadView.shortNodesText(markedRoot,opts.shortText);
				}
				if(opts.removeHidden){
					ReadView.removeHiddenNodes(markedRoot);
				}
				if(opts.excludeNodeTags || opts.excludeNodeTypes){
					let types;
					types=opts.excludeNodeTypes.toUpperCase().split(",");
					ReadView.excludeNodes(markedRoot,opts.excludeNodeTags,opts.excludeNodeTypes);
				}
				if(opts.filter){
					opts.filter(markedRoot);
				}
				if(opts.cleanMarks){
					ReadView.cleanNodeMarks(markedRoot);
				}
				return markedRoot.innerHTML;
			}else{
				res=await tabNT.makeCall("aaeeReadNodeHTML",{browser:this.browserId,page:this.pageId,frame:this.frameId,aaeId:baseNode});
				if(!res || res.code!==200){
					if(res && res.info){
						throw Error(res.info);
					}
					throw Error("ReadHTML failed.");
				}
				html=res.html;
			}
			return html;
		};

		//--------------------------------------------------------------------
		aaPage.readInnerText=async function(baseNode){
			let res;
			baseNode=baseNode?(baseNode.AAEId||baseNode):null;
			res=await tabNT.makeCall("aaeeReadNodeText",{browser:this.browserId,page:this.pageId,frame:this.frameId,aaeId:baseNode});
			if(!res || res.code!==200){
				if(res && res.info){
					throw Error(res.info);
				}
				throw Error("ReadText failed.");
			}
			return res.text;
		};

		//--------------------------------------------------------------------
		aaPage.readArticle=async function(){
			let res;
			res=await tabNT.makeCall("aaeeReadArticle",{browser:this.browserId,page:this.pageId,frame:this.frameId});
			if(!res || res.code!==200){
				if(res && res.info){
					throw Error(res.info);
				}
				throw Error("readArticle failed.");
			}
			return res.text;
		};
		
		//--------------------------------------------------------------------
		aaPage.queryNode=async function(baseNodeId,selector,options){
			let res;
			baseNodeId=baseNodeId?(baseNodeId.AAEId||baseNodeId):null;
			res=await tabNT.makeCall("aaeeQueryNode",{browser:this.browserId,page:this.pageId,frame:this.frameId,aaeId:baseNodeId,options:options,selector:selector});
			if(!res || res.code!==200){
				if(res && res.info){
					throw Error(res.info);
				}
				throw Error("queryNode failed.");
			}
			return res.node;
		};

		//--------------------------------------------------------------------
		aaPage.queryNodes=async function(baseNodeId,selector,options){
			let res;
			baseNodeId=baseNodeId?(baseNodeId.AAEId||baseNodeId):null;
			res=await tabNT.makeCall("aaeeQueryNodes",{browser:this.browserId,page:this.pageId,frame:this.frameId,aaeId:baseNodeId,options:options,selector:selector});
			if(!res || res.code!==200){
				if(res && res.info){
					throw Error(res.info);
				}
				throw Error("queryNodes failed.");
			}
			return res.list;
		};
		
		//--------------------------------------------------------------------
		aaPage.getNodeParent=async function(nodeId){
			let res;
			nodeId=nodeId.AAEId||nodeId;
			res=await tabNT.makeCall("aaeeGetNodeParent",{browser:this.browserId,page:this.pageId,frame:this.frameId,aaeId:nodeId});
			if(!res || res.code!==200){
				if(res && res.info){
					throw Error(res.info);
				}
				throw Error("getNodeParent failed.");
			}
			return res.node;
		};
		
		//--------------------------------------------------------------------
		aaPage.getNodeChildren=async function(nodeId){
			let res;
			nodeId=nodeId.AAEId||nodeId;
			res=await tabNT.makeCall("aaeeGetNodeChildren",{browser:this.browserId,page:this.pageId,frame:this.frameId,aaeId:nodeId});
			if(!res || res.code!==200){
				if(res && res.info){
					throw Error(res.info);
				}
				throw Error("getNodeParent failed.");
			}
			return res.children;
		};
		
		//--------------------------------------------------------------------
		aaPage.getNodeAttributes=async function(nodeId){
			let res;
			nodeId=nodeId.AAEId||nodeId;
			res=await tabNT.makeCall("aaeeGetNodeAttributes",{browser:this.browserId,page:this.pageId,frame:this.frameId,aaeId:nodeId});
			if(!res || res.code!==200){
				if(res && res.info){
					throw Error(res.info);
				}
				throw Error("getNodeParent failed.");
			}
			return res.attributes;
		};

		//--------------------------------------------------------------------
		aaPage.getNodeAttribute=async function(nodeId,key){
			let res;
			nodeId=nodeId.AAEId||nodeId;
			res=await tabNT.makeCall("aaeeGetNodeAttribute",{browser:this.browserId,page:this.pageId,frame:this.frameId,aaeId:nodeId,key:key});
			if(!res || res.code!==200){
				if(res && res.info){
					throw Error(res.info);
				}
				throw Error("getNodeParent failed.");
			}
			return res.value;
		};

		//--------------------------------------------------------------------
		aaPage.setNodeAttribute=async function(nodeId,key,value){
			let res;
			nodeId=nodeId.AAEId||nodeId;
			res=await tabNT.makeCall("aaeeSetNodeAttribute",{browser:this.browserId,page:this.pageId,frame:this.frameId,aaeId:nodeId,key:key,value:value});
			if(!res || res.code!==200){
				if(res && res.info){
					throw Error(res.info);
				}
				throw Error("getNodeParent failed.");
			}
			return value;
		};
		
		//--------------------------------------------------------------------
		aaPage.confirmQuery=async function(query,queryHint,segId){
			let aiQuery;
			aiQuery=this.farm.aiQuery;
			if(!aiQuery){
				return query;
			}
			return await aiQuery.getQuery(this,query,queryHint,segId);
		};
	}
	
	//************************************************************************
	//:User actions:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		function filterSelector(selector){
			if(selector.AAEId){
				selector=`[aaeid="${selector.AAEId}"]`
			}else if(selector.startsWith && selector.startsWith("(")){
				selector="::-p-xpath"+selector;
			}
			return selector;
		};
		
		//--------------------------------------------------------------------
		aaPage.clickOn=async function(selector,options){
			let res;
			res=await tabNT.makeCall("aaeePageAPI",{browser:this.browserId,page:this.pageId,frame:this.frameId,api:["click"],args:[filterSelector(selector),options]});
			if(!res || res.code!==200){
				if(res && res.info){
					throw Error(res.info);
				}
				throw Error("Click failed.");
			}
			return true;
		};
		
		//--------------------------------------------------------------------
		aaPage.tapOn=async function(selector){
			let res;
			res=await tabNT.makeCall("aaeePageAPI",{browser:this.browserId,page:this.pageId,frame:this.frameId,api:["tap"],args:[filterSelector(selector)]});
			if(!res || res.code!==200){
				if(res && res.info){
					throw Error(res.info);
				}
				throw Error("Tap failed.");
			}
			return true;
		};

		//--------------------------------------------------------------------
		aaPage.hoverOn=async function(selector){
			let res;
			res=await tabNT.makeCall("aaeePageAPI",{browser:this.browserId,page:this.pageId,frame:this.frameId,api:["hover"],args:[filterSelector(selector)]});
			if(!res || res.code!==200){
				if(res && res.info){
					throw Error(res.info);
				}
				throw Error("Hover failed.");
			}
			return true;
		};

		//--------------------------------------------------------------------
		aaPage.selectOn=async function(selector,...values){
			let res;
			res=await tabNT.makeCall("aaeePageAPI",{browser:this.browserId,page:this.pageId,frame:this.frameId,api:["select"],args:[filterSelector(selector),...values]});
			if(!res || res.code!==200){
				if(res && res.info){
					throw Error(res.info);
				}
				throw Error("Hover failed.");
			}
			return true;
		};
		
		//--------------------------------------------------------------------
		aaPage.typeOn=async function(selector,text,options){
			let res;
			options=options||{};
			res=await tabNT.makeCall("aaeePageAPI",{browser:this.browserId,page:this.pageId,frame:this.frameId,api:["type"],args:[filterSelector(selector),text,options]});
			if(!res || res.code!==200){
				if(res && res.info){
					throw Error(res.info);
				}
				throw Error("Hover failed.");
			}
			return true;
		};
		
		//--------------------------------------------------------------------
		//Mouse actions:
		//--------------------------------------------------------------------
		aaPage.mouseReset=async function(){
			let res;
			res=await tabNT.makeCall("aaeePageAPI",{browser:this.browserId,page:this.pageId,frame:this.frameId,api:["mouse","reset"],args:[]});
			if(!res || res.code!==200){
				if(res && res.info){
					throw Error(res.info);
				}
				throw Error("mouseReset failed.");
			}
			return true;
		};

		//--------------------------------------------------------------------
		aaPage.mouseMove=async function(x,y,options){
			let res;
			res=await tabNT.makeCall("aaeePageAPI",{browser:this.browserId,page:this.pageId,frame:this.frameId,api:["mouse","move"],args:[x,y,options]});
			if(!res || res.code!==200){
				if(res && res.info){
					throw Error(res.info);
				}
				throw Error("mouseMove failed.");
			}
			return true;
		};

		//--------------------------------------------------------------------
		aaPage.mouseDown=async function(options){
			let res;
			res=await tabNT.makeCall("aaeePageAPI",{browser:this.browserId,page:this.pageId,frame:this.frameId,api:["mouse","down"],args:[options]});
			if(!res || res.code!==200){
				if(res && res.info){
					throw Error(res.info);
				}
				throw Error("mouseDown failed.");
			}
			return true;
		};

		//--------------------------------------------------------------------
		aaPage.mouseUp=async function(options){
			let res;
			res=await tabNT.makeCall("aaeePageAPI",{browser:this.browserId,page:this.pageId,frame:this.frameId,api:["mouse","up"],args:[options]});
			if(!res || res.code!==200){
				if(res && res.info){
					throw Error(res.info);
				}
				throw Error("mouseUp failed.");
			}
			return true;
		};
		
		//--------------------------------------------------------------------
		aaPage.mouseClick=async function(x,y,options){
			let res;
			res=await tabNT.makeCall("aaeePageAPI",{browser:this.browserId,page:this.pageId,frame:this.frameId,api:["mouse","click"],args:[x,y,options]});
			if(!res || res.code!==200){
				if(res && res.info){
					throw Error(res.info);
				}
				throw Error("mouseClick failed.");
			}
			return true;
		};
		
		//--------------------------------------------------------------------
		//Keyboard actions:
		//--------------------------------------------------------------------
		let parseKeys=function(key){
			let keys,i,n;
			key=key.trim();
			if(key===","){
				return key;
			}
			keys=key.split(",");
			n=keys.length;
			if(n==1){
				return key;
			}
			for(i=0;i<n;i++){
				key=keys[i];
				if(key===""){
					if(keys[i+1]==""){
						keys[i]==",";
					}else{
						keys.split(i,1);
						n--;i--;
					}
				}else{
					keys[i]=key.trim();
				}
			}
			return keys;
		};

		//--------------------------------------------------------------------
		aaPage.keyboardDown=async function(key,options){
			let res;
			if(Array.isArray(key)){
				let keys=key;
				let delay=options.delay||0;
				for(key of keys){
					await this.keyboardDown(key,options);
					await sleep(delay);
				}
				return true;
			}else{
				key=parseKeys(""+key);
				if(Array.isArray(key)){
					let keys=key;
					let delay=options.delay||0;
					for(key of keys){
						await this.keyboardDown(key,options);
						await sleep(delay);
					}
					return true;
				}
			}
			res=await tabNT.makeCall("aaeePageAPI",{browser:this.browserId,page:this.pageId,frame:this.frameId,api:["keyboard","down"],args:[key,options]});
			if(!res || res.code!==200){
				if(res && res.info){
					throw Error(res.info);
				}
				throw Error("keyboardDown failed.");
			}
			return true;
		};
		
		//--------------------------------------------------------------------
		aaPage.keyboardUp=async function(key,options){
			let res;
			if(Array.isArray(key)){
				let keys=key;
				let delay=options.delay||0;
				for(key of keys){
					await this.keyboardUp(key,options);
					await sleep(delay);
				}
				return true;
			}else{
				key=parseKeys(""+key);
				if(Array.isArray(key)){
					let keys=key;
					let delay=options.delay||0;
					for(key of keys){
						await this.keyboardUp(key,options);
						await sleep(delay);
					}
					return true;
				}
			}
			res=await tabNT.makeCall("aaeePageAPI",{browser:this.browserId,page:this.pageId,frame:this.frameId,api:["keyboard","up"],args:[key,options]});
			if(!res || res.code!==200){
				if(res && res.info){
					throw Error(res.info);
				}
				throw Error("keyboardUp failed.");
			}
			return true;
		};

		//--------------------------------------------------------------------
		aaPage.keyboardPress=async function(key,options){
			let res;
			if(Array.isArray(key)){
				let keys=key;
				let delay=options.delay||0;
				for(key of keys){
					await this.keyboardPress(key,options);
					await sleep(delay);
				}
				return true;
			}else{
				key=parseKeys(""+key);
				if(Array.isArray(key)){
					let keys=key;
					let delay=options.delay||0;
					for(key of keys){
						await this.keyboardPress(key,options);
						await sleep(delay);
					}
					return true;
				}
			}
			res=await tabNT.makeCall("aaeePageAPI",{browser:this.browserId,page:this.pageId,frame:this.frameId,api:["keyboard","press"],args:[key,options]});
			if(!res || res.code!==200){
				if(res && res.info){
					throw Error(res.info);
				}
				throw Error("keyboardPress failed.");
			}
			return true;
		};

		//--------------------------------------------------------------------
		aaPage.keyboardType=async function(text,options){
			let res;
			if(options.coverEnter){
				let lines,line,i,n;
				lines=text.split("\n");
				n=lines.length;
				for(i=0;i<n;i++){
					line=lines[i];
					if(i>0){
						await sleep(20);
						await this.keyboardDown(["Shift","Enter"],{delay:10});
						await sleep(20);
						await this.keyboardUp(["Enter","Shift"],{delay:10});
					}
					await this.keyboardType(line,{...options,coverEnter:false});
				}
				return;
			}
			res=await tabNT.makeCall("aaeePageAPI",{browser:this.browserId,page:this.pageId,frame:this.frameId,api:["keyboard","type"],args:[text,options]});
			if(!res || res.code!==200){
				if(res && res.info){
					throw Error(res.info);
				}
				throw Error("keyboardType failed.");
			}
			return true;
		};

		//--------------------------------------------------------------------
		aaPage.keyboardSendCharacter=async function(ch,options){
			let res;
			res=await tabNT.makeCall("aaeePageAPI",{browser:this.browserId,page:this.pageId,frame:this.frameId,api:["keyboard","sendCharacter"],args:[ch,options]});
			if(!res || res.code!==200){
				if(res && res.info){
					throw Error(res.info);
				}
				throw Error("keyboardSendCharacter failed.");
			}
			return true;
		};

		//--------------------------------------------------------------------
		//Touch actions:
		//--------------------------------------------------------------------
		aaPage.touchStart=async function(x,y){
			let res;
			res=await tabNT.makeCall("aaeePageAPI",{browser:this.browserId,page:this.pageId,frame:this.frameId,api:["touchscreen","touchStart"],args:[x,y]});
			if(!res || res.code!==200){
				if(res && res.info){
					throw Error(res.info);
				}
				throw Error("touchStart failed.");
			}
			return true;
		};
		
		//--------------------------------------------------------------------
		aaPage.touchMove=async function(x,y){
			let res;
			res=await tabNT.makeCall("aaeePageAPI",{browser:this.browserId,page:this.pageId,frame:this.frameId,api:["touchscreen","touchMove"],args:[x,y]});
			if(!res || res.code!==200){
				if(res && res.info){
					throw Error(res.info);
				}
				throw Error("touchMove failed.");
			}
			return true;
		};

		//--------------------------------------------------------------------
		aaPage.touchEnd=async function(){
			let res;
			res=await tabNT.makeCall("aaeePageAPI",{browser:this.browserId,page:this.pageId,frame:this.frameId,api:["touchscreen","touchEnd"],args:[]});
			if(!res || res.code!==200){
				if(res && res.info){
					throw Error(res.info);
				}
				throw Error("touchEnd failed.");
			}
			return true;
		};
		
		//--------------------------------------------------------------------
		aaPage.touchTap=async function(x,y){
			let res;
			res=await tabNT.makeCall("aaeePageAPI",{browser:this.browserId,page:this.pageId,frame:this.frameId,api:["touchscreen","tap"],args:[x,y]});
			if(!res || res.code!==200){
				if(res && res.info){
					throw Error(res.info);
				}
				throw Error("touchTap failed.");
			}
			return true;
		};
		
		//--------------------------------------------------------------------
		aaPage.runAction=async function(action){
			let actCode,timeout,options;
			actCode=action.action;
			timeout=action.waitBefore;
			if(timeout>0){
				await sleep(timeout);
			}
			options=action.options||{};
			switch(actCode){
				//User Actions:
				case "clickOn":
					await this.clickOn(action.query,options?{...options,x:action.x,y:options.y}:{});
					break;
				case "tapOn":
					await this.tapOn(action.query);
					break;
				case "typeOn":
					await this.typeOn(action.query,action.content);
					break;
				case "hoverOn":
					await this.hoverOn(action.query);
					break;
				case "selectOn":
					await this.selectOn(action.query,action.content);
					break;
				case "mouseReset":
					await this.mouseReset();
					break;
				case "mouseMove":
					await this.mouseMove(action.x,action.y,options);
					break;
				case "mouseDown":
					await this.mouseDown(options);
					break;
				case "mouseUp":
					await this.mouseUp(options);
					break;
				case "mouseClick":
					await this.mouseClick(action.x,action.y,options);
					break;
				case "keyDown":
					await this.keyboardDown(action.key,options);
					break;
				case "keyUp":
					await this.keyboardUp(action.key,options);
					break;
				case "keyPress":
					await this.keyboardPress(action.key,options);
					break;
				case "keyType":
					await this.keyboardType(action.content,options);
					break;
				case "touchTap":
					await this.touchTap(action.x,action.y);
					break;
				case "touchStart":
					await this.touchStart(action.x,action.y);
					break;
				case "touchMove":
					await this.touchMove(action.x,action.y);
					break;
				case "touchEnd":
					await this.touchEnd();
					break;
				//Page actions:
				case "goto":
					await this.goto(action.query,options);
					break;
				//Wait actions:
				case "await":
					await this.awaitFor(action.key);
					break;
				case "waitNavi":
					await this.awaitFor(action.key,"navi",options);
					break;
				case "waitNetworkIdle":
					await this.awaitFor(action.key,"networkidle",options);
					break;
				case "waitDialog":
					await this.awaitFor(action.key,"dialog",options);
					break;
				case "waitFileChooser":
					await this.awaitFor(action.key,"filechooser",options);
					break;
				case "waitDevicePrompt":
					await this.awaitFor(action.key,"deviceprompt",options);
					break;
				case "waitQuery":
					await this.waitForQuery(action.key,action.query,options);
					break;
				case "waitFunction":
					await this.waitForFunction(action.key,action.content,options);
					break;
			}
			timeout=action.waitAfter;
			if(timeout>0){
				await sleep(timeout);
			}
		};
		
		//--------------------------------------------------------------------
		aaPage.runActionChain=async function(actions,args){
			let action;
			if(!Array.isArray(actions)){
				actions=[actions];
			}
			actions=compileActions(actions,args);
			for(action of actions){
				await this.runAction(action);
			}
			return true;
		};
	}
	
	//************************************************************************
	//:Frame(s) access:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		aaPage.getFrames=async function(){
			let res,list,frameId,frame,frames,frameMap;
			res=await tabNT.makeCall("aaeeGetFrames",{browser:this.browserId,page:this.pageId,frame:this.frameId});
			if(!res || res.code!==200){
				if(res && res.info){
					throw Error(res.info);
				}
				throw Error("Goto url failed.");
			}
			frameMap=this.frameMap;
			frames=[];
			list=res.list;
			for(frameId of list){
				frame=frameMap.get(frameId);
				if(!frame){
					frame=new AAFrame(this,frameId);
					frameMap.set(frameId,frame);
				}
				frames.push(frame);
			}
			return frames;
		};
	}
	
	//************************************************************************
	//:Inject contents
	//************************************************************************
	{
		//--------------------------------------------------------------------
		aaPage.runScriptCode=async function(code,opts){
			let res;
			res=await tabNT.makeCall("aaeeEvaluate",{browser:this.browserId,page:this.pageId,frame:this.frameId,code:code,opts});
			if(!res || res.code!==200){
				if(res && res.info){
					throw Error(res.info);
				}
				throw Error("runScriptCode failed.");
			}
			return res.result;
		};

		//--------------------------------------------------------------------
		aaPage.runScriptFile=async function(filePath,opts){
			let url,code;
			url="/~"+filePath;
			code=await (await fetch(url)).text();
			return await this.runScriptCode(code,opts);
		};

		//--------------------------------------------------------------------
		aaPage.runScriptURL=async function(url,opts){
			let code;
			code=await (await fetch(url)).text();
			return await this.runScriptCode(code,opts);
		};
	}

	//************************************************************************
	//:Handle Dialogs:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		aaPage.acceptDialog=async function(text,files){
			let res;
			res=await tabNT.makeCall("aaeeAcceptDialog",{browser:this.browserId,page:this.pageId,frame:this.frameId,value:text,files});
			if(!res || res.code!==200){
				if(res && res.info){
					throw Error(res.info);
				}
				throw Error("AcceptDialog failed.");
			}
			return true;
		};
		
		//--------------------------------------------------------------------
		aaPage.dissmissDialog=async function(){
			let res;
			res=await tabNT.makeCall("aaeeDismissDialog",{browser:this.browserId,page:this.pageId,frame:this.frameId});
			if(!res || res.code!==200){
				if(res && res.info){
					throw Error(res.info);
				}
				throw Error("DissmisDialog failed.");
			}
			return true;
		};
	}

	//************************************************************************
	//:Watch/Trace user acrions:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		aaPage.startTrace=async function(callback,options){
			let res,page,callbacks,tracePms;
			callbacks=this.traceCallbacks
			page=this;
			const eventLoop=async ()=>{
				let lastIdx,list,event,callback;
				lastIdx=0;
				do{
					res=await tabNT.makeCall("aaeeGetTraceEvents",{browser:page.browserId,page:page.pageId,frame:page.frameId,fromIndex:lastIdx});
					if(!res || res.code!==200){
						//Stop the trace?
						this.isTracing=false;
						return;
					}
					list=res.events;
					if(list && list.length>0){
						lastIdx=list[list.length-1].eventIndex;
						for(event of list){
							for(callback of callbacks){
								if(callback._isTracing){
									await callback(event);
								}
							}
						}
					}
					if(!callbacks.length){
						this.isTracing=false;
						return;
					}
					await sleep(100);//Safer this way?
				}while(1);
			}
			callbacks.push(callback);
			callback._isTracing=true;
			if(!this.isTracing){
				res=await tabNT.makeCall("aaeeTracePage",{browser:this.browserId,page:this.pageId,frame:this.frameId,options:options});
				if(!res || res.code!==200){
					if(res){
						throw Error(`Trace page error: ${res.info}`);
					}
					throw Error(`Trace page error`);
				}
				this.isTracing=1;
				eventLoop();
			}else{
				this.isTracing+=1;
			}
			tracePms=new Promise((resolve,reject)=>{
				callback._traceStopCallback=resolve;
			});
			callback._tracePromise=tracePms;
			return tracePms;
		};
		
		//--------------------------------------------------------------------
		aaPage.stopTrace=async function(callback){
			let idx,callbacks;
			if(!this.isTracing || !callback._isTracing)
				return;
			callbacks=this.traceCallbacks
			idx=callbacks.indexOf(callback);
			if(idx>=0){
				callback._isTracing=false;
				callbacks.splice(idx,1);
				this.isTracing-=1;
				if(callback._traceStopCallback){
					callback._traceStopCallback();
					callback._traceStopCallback=null;
				}
			}
		};
	}
}

//****************************************************************************
//:AAFrame
//****************************************************************************
{
	//------------------------------------------------------------------------
	AAFrame=function(page,frameId){
		this.browser=page.browser;
		this.farm=page.farm;
		this.browserId=page.browserId;
		this.pageId=page.pageId;
		this.frameId=frameId;
		this.waitMap=new Map();
		this.frameMap=new Map();
	};
	aaFrame=AAFrame.prototype={};
	
	//************************************************************************
	//:Basic functions:
	//************************************************************************
	{
		aaFrame.goto=aaPage.goto;
		aaFrame.getTitle=aaPage.getTitle;
		aaFrame.getURL=aaPage.getURL;
	}
	
	//************************************************************************
	//:Wait functions:
	//************************************************************************
	{
		aaFrame.awaitFor=aaPage.awaitFor;
		aaFrame.waitFor=aaPage.waitFor;
		aaFrame.waitForQuery=aaPage.waitForQuery;
		aaFrame.waitForFunction=aaPage.waitForFunction;

	}

	//************************************************************************
	//:Frame content access:
	//************************************************************************
	{
		aaFrame.readView=aaPage.readView;
		aaFrame.readInnerHTML=aaPage.readInnerHTML;
		aaFrame.readInnerText=aaPage.readInnerText;
		aaFrame.readArticle=aaPage.readArticle;
		aaFrame.queryNode=aaPage.queryNode;
		aaFrame.queryNodes=aaPage.queryNodes;
		aaFrame.getNodeParent=aaPage.getNodeParent;
		aaFrame.getNodeChildren=aaPage.getNodeChildren;
		aaFrame.getNodeAttributes=aaPage.getNodeAttributes;
		aaFrame.getNodeAttribute=aaPage.getNodeAttribute;
		aaFrame.setNodeAttribute=aaPage.setNodeAttribute;
		aaFrame.confirmQuery=aaPage.confirmQuery;
	}
	
	//************************************************************************
	//:User actions:
	//************************************************************************
	{
		aaFrame.clickOn=aaPage.clickOn;
		aaFrame.tapOn=aaPage.tapOn;
		aaFrame.hoverOn=aaPage.hoverOn;
		aaFrame.typeOn=aaPage.typeOn;
		aaFrame.runAction=aaPage.runAction;
		aaFrame.runActionChain=aaPage.runActionChain;
	}
	
	//************************************************************************
	//:Frame(s) access:
	//************************************************************************
	{
		aaFrame.getFrames=aaPage.getFrames;
	}
	
	//************************************************************************
	//:Inject contents:
	//************************************************************************
	{
		//TODO: Code this:
	}

	//************************************************************************
	//:Handle dialogs:
	//************************************************************************
	{
		aaFrame.acceptDialog=aaPage.acceptDialog;
		aaFrame.dissmissDialog=aaPage.dissmissDialog;
	}
	
	//************************************************************************
	//:Watch/Trace user acrions:
	//************************************************************************
	{
		aaFrame.startTrace=aaPage.startTrace;
		aaFrame.stopTrace=aaPage.stopTrace;
	}
}

export {AAFarm};