import {makeObjEventEmitter,makeNotify} from "/@events";
import {sleep} from "/@vfact";
import {tabNT,tabFS} from "/@tabos";
import {AAFarm} from "./aafarm.js";
import {AAChatFlow} from "./AAChatFlow.js";

//****************************************************************************
//:AAUser
//****************************************************************************
let AAUser,aaUser;
{
	//------------------------------------------------------------------------
	AAUser=function(){
		this.id="";
		this.name="";
		this.sessionId="";
		this.messages=[];
		this.logs=[];
		this.webSocket=null;
		this.waitMsgCall=null;
		this.lastMsgTime=0;
		this.curChatBot=null;
		this.botScope=[];
		this.botMap=new Map();
		makeNotify(this);
	};
	AAUser.botInfoMap=new Map();
	aaUser=AAUser.prototype={};
	
	//------------------------------------------------------------------------
	aaUser.login=async function(userId,password){
		let res,userInfo;
		res=await tabNT.makeCall("AAEUserLogin",{userId:userId,password:password});
		if(!res || res.code!==200){
			if(res && res.info){
				throw Error(res.info);
			}
			throw Error("Send bot message failed");
		}
		userInfo=res.info;
		this.id=userId;
		this.name=userInfo.name;
		this.sessionId=res.sessionId;
		this.botScope=userInfo.botScope||["BOT_MASTER"];
		await this.getBotScope();
	};
	
	//------------------------------------------------------------------------
	AAUser.getBotInfo=async function(botId){
		let res,botInfo;
		botInfo=AAUser.botInfoMap.get(botId);
		if(botInfo){
			return botInfo;
		}
		res=await tabNT.makeCall("AAEGetBotInfo",{bot:botId});
		if(!res || res.code!==200){
			if(res && res.info){
				return null;
			}
			return null;
		}
		botInfo=res.info;
		AAUser.botInfoMap.set(botId,botInfo);
		return botInfo;
	};
	
	//------------------------------------------------------------------------
	aaUser.getBotScope=async function(){
		let i,n,bots,botId,botInfo;
		bots=this.botScope;
		n=bots.length;
		for(i=0;i<n;i++){
			botId=bots[i];
			botInfo=await AAUser.getBotInfo(botId);
			if(!botInfo){
				botInfo={id:botId,name:botId,description:"NA",active:false};
			}
			bots[i]=botInfo;
			this.botMap.set(botId,botInfo);
		}
		this.curChatBot=bots[0];
	};
	
	//------------------------------------------------------------------------
	aaUser.setChatBot=function(botId){
		let botInfo;
		botInfo=this.botMap.get(botId);
		if(botInfo){
			this.curChatBot=botInfo;
		}
	};
	
	//------------------------------------------------------------------------
	aaUser.startMessageClient=async function(){
		let res,msgs,msg,selector,ws,pms;
		let wsReady,wsError;
		this.lastMsgTime=0;
		pms=new Promise((resolve,reject)=>{
			wsReady=resolve;
			wsError=reject;
		});
		res=await tabNT.makeCall("AAEUserStartMessageClient",{userId:this.id,sessionId:this.sessionId});
		if(!res || res.code!==200){
			if(res && res.info){
				throw Error(res.info);
			}
			throw Error("Start user message client failed");
		}
		selector=res.selectCode;
		ws=new WebSocket(`ws://${document.location.host}`);
		ws.addEventListener('open',()=>{
			this.webSocket=ws;
			ws.send(JSON.stringify({msg:"CONNECT",selector:selector}));
			console.log("WS connected.");
		});
		ws.addEventListener('message', (msg) => {
			let msgVO;
			try{
				msgVO=JSON.parse(msg.data);
				console.log("AAUser get raw message:");
				console.log(msgVO);
			}catch(err){
				return;
			}
			if(msgVO.msg==="CONNECTED"){
				wsReady();
				console.log("WS Ready.");
			}else{
				let handler;
				handler="WSMSG_"+msgVO.msg;
				handler=this[handler]||ws[handler];
				if(handler){
					handler.call(this,msgVO);
				}
			}
		});
		ws.addEventListener('close', (msg) => {
			if(this.webSocket){
				this.emitNotify("Disconnected");
			}
			this.webSocket=null;
		});
		ws.addEventListener('error', (msg) => {
			this.webSocket=null;
			wsError();
		});
		res=await tabNT.makeCall("AAEUserGetMessages",{userId:this.id,sessionId:this.sessionId,fromTime:0,toTime:0,maxNum:100});
		if(!res || res.code!==200){
			if(res && res.info){
				throw Error(res.info);
			}
			throw Error("Send bot message failed");
		}
		//Get current messages:
		msgs=this.messages;
		msgs.push(...res.messages);
		msg=msgs[msgs.length-1];
		this.lastMsgTime=msg?msg.time:1;

		//Wait connection ready:
		await pms;
		console.log("User client started.");
	};

	//------------------------------------------------------------------------
	aaUser.sendMessage=async function(message){
		let msgVO;
		msgVO={
			msg:"Message",
			msgVO:message
		};
		message.type=message.type||"User";
		message.from=this.id;
		if(this.webSocket){
			this.webSocket.send(JSON.stringify(msgVO));
		}else{
			//Use tabNT:
			let res;
			res=await tabNT.makeCall("AAEUserSendMessage",msgVO);
			if(!res || res.code!==200){
				if(res && res.info){
					throw Error(res.info);
				}
				throw Error("Send bot message failed");
			}
		}
	};
	
	//------------------------------------------------------------------------
	aaUser.WSMSG_Message=async function(msg){
		let msgVO,callback;
		msgVO=msg.message;
		this.messages.push(msgVO);
		callback=this.waitMsgCall;
		if(callback){
			this.waitMsgCall=null;
			callback();
		}
		AAChatFlow.addMessage(msgVO);
		this.emitNotify("GetMessage");
	};

	//------------------------------------------------------------------------
	aaUser.WSMSG_Log=async function(msg){
		let msgVO,callback;
		msgVO=msg.log;
		this.logs.push(msgVO);
		this.emitNotify("GetLog");
	};

	//------------------------------------------------------------------------
	aaUser.getNewMessage=async function(fromTime){
		let pms,msgs,msg,i,n;
		if(!fromTime){
			fromTime=this.lastMsgTime;
		}
		msgs=this.messages;
		n=msgs.length;
		msg=msgs[n-1];
		if(!msg || msg.time<=fromTime){
			pms=new Promise((resolve,reject)=>{
				this.waitMsgCall=resolve;
			});
			await pms;
			n=msgs.length;
			msg=msgs[n-1];
		}
		this.waitMsgCall=null;
		if(!fromTime){
			fromTime=this.lastMsgTime;
		}
		if(msg && msg.time>fromTime){
			for(i=n-1;i>=0;i--){
				msg=msgs[i];
				if(msg.time<=fromTime){
					msg=msgs[i+1]
					this.lastMsgTime=msg.time;
					return msg;
				}
			}
			msg=msgs[0]
			this.lastMsgTime=msg.time;
			return msg;
		}
		return null;
	};
}

export default AAUser;
export {AAUser};