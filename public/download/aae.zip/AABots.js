import {makeObjEventEmitter,makeNotify} from "/@events";
import {sleep} from "/@vfact";
import {tabNT,tabFS} from "/@tabos";
import {AAFarm} from "./aafarm.js";

//****************************************************************************
//:AATaskReq
//****************************************************************************
let AATaskReq,aaTaskReq;
{
	//-----------------------------------------------------------------------
	AATaskReq=function(taskId,fromBot,hostBot,prompt){
		this.id=taskId;
		this.fromBot=fromBot;
		this.execBot=hostBot;
		this.prompt=prompt;
		this.state="NA";//WAIT_ACCEPT,ACCEPT,WORKING,FINNISH,REJECT,FAIL
	};
	aaTaskReq=AATaskReq.prototype={};
	
	//-----------------------------------------------------------------------
	aaTaskReq.giveUp=async function(reason){
		let res;
		res=await tabNT.makeCall("AAETaskGiveUpTask",{taskId:this.id,from:this.fromBot,reason:reason});
		if(!res || res.code!==200){
			if(res && res.info){
				throw Error(res.info);
			}
			throw Error("Send bot message failed");
		}
	};
}

//****************************************************************************
//:AATaskWork
//****************************************************************************
let AATaskWork,aaTaskWork;
{
	//-----------------------------------------------------------------------
	AATaskWork=function(taskId,fromBot,hostBot,prompt){
		this.id=taskId;
		this.fromBot=fromBot;
		this.execBot=hostBot;
		this.prompt=prompt;
		this.state="WAIT";//WAIT_ACCEPT,ACCEPT,WORKING,FINNISH,REJECT,FAIL
	};
	aaTaskWork=AATaskWork.prototype={};

	//-----------------------------------------------------------------------
	aaTaskWork.start=async function(){
		let res;
		res=await tabNT.makeCall("AAETaskStartTask",{taskId:this.id,from:this.execBot.id});
		if(!res || res.code!==200){
			if(res && res.info){
				throw Error(res.info);
			}
			throw Error("Send bot message failed");
		}
	};

	//-----------------------------------------------------------------------
	aaTaskWork.finish=async function(result){
		let res;
		res=await tabNT.makeCall("AAETaskFinishTask",{taskId:this.id,from:this.execBot.id,result:result});
		if(!res || res.code!==200){
			if(res && res.info){
				throw Error(res.info);
			}
			throw Error("Send bot message failed");
		}
	};

	//-----------------------------------------------------------------------
	aaTaskWork.fail=async function(reason){
		let res;
		res=await tabNT.makeCall("AAETaskFailTask",{taskId:this.id,from:this.execBot.id,reason:reason});
		if(!res || res.code!==200){
			if(res && res.info){
				throw Error(res.info);
			}
			throw Error("Send bot message failed");
		}
	};
}

//****************************************************************************
//:AABot
//****************************************************************************
let AABot,aaBot;
{
	//------------------------------------------------------------------------
	AABot=function(bots,stub){
		if(!bots){
			return;
		}
		this.aaBots=bots;
		this.id=stub.id;
		this.name=stub.name;
		this.host=false;
		this.type=stub.type;
		this.alias=stub.alias;
		this.active=stub.active;
		this.description=stub.description;
		this.lastMsgId=null;
		this.messages=[];
		makeNotify(this);
	};
	aaBot=AABot.prototype={};
	
	//------------------------------------------------------------------------
	aaBot.getState=async function(){
		//TODO: Code this:
	};
}

//****************************************************************************
//:AAHostBot:
//****************************************************************************
let AAHostBot,aaHostBot;
{
	//------------------------------------------------------------------------
	AAHostBot=function(bots,stub){
		AABot.call(this,bots,stub);
		this.isLooping=false;
		this.sessionId=null;
		this.chatSession=null;
		this.taskReqs=new Map();
		this.taskWorks=new Map();
		this.webSocket=null;
		this.waitMsgCall=null;
		this.lastMsgTime=0;
	};
	aaHostBot=AAHostBot.prototype=new AABot();
	
	//------------------------------------------------------------------------
	aaHostBot.getBotDef=async function(){
		let res;
		res=await tabNT.makeCall("AAEBotNodeGetBotDef",{bot:this.id});
		if(!res || res.code!==200){
			if(res && res.info){
				return null;
			}
			return null;
		}
		return res.def;
	};
	
	//------------------------------------------------------------------------
	aaHostBot.startMessageClient=async function(){
		let res,msgs,msg,selector,ws,pms;
		let wsReady,wsError;
		this.lastMsgTime=0;
		if(this.webSocket){
			console.log("User client already started.");
			return;
		}
		pms=new Promise((resolve,reject)=>{
			wsReady=resolve;
			wsError=reject;
		});
		res=await tabNT.makeCall("AAEBotNodeStartMessageClient",{bot:this.id,sessionId:this.sessionId});
		if(!res || res.code!==200){
			if(res && res.info){
				throw Error(res.info);
			}
			throw Error("Start user message client failed");
		}
		selector=res.selectCode;
		ws=new WebSocket(`ws://${document.location.host}`);
		ws.addEventListener('open',()=>{
			this.webSocket=ws;
			ws.send(JSON.stringify({msg:"CONNECT",selector:selector}));
			console.log("Bot WS connected.");
		});
		ws.addEventListener('message', (msg) => {
			let msgVO;
			msgVO=JSON.parse(msg.data);
			if(msgVO.msg==="CONNECTED"){
				wsReady();
				console.log("Bot WS Ready.");
			}else{
				let handler;
				handler="WSMSG_"+msgVO.msg;
				handler=this[handler]||ws[handler];
				if(handler){
					handler.call(this,msgVO);
				}
			}
		});
		ws.addEventListener('close', (msg) => {
			this.webSocket=null;
		});
		ws.addEventListener('error', (msg) => {
			this.webSocket=null;
			wsError();
		});
		res=await tabNT.makeCall("AAEBotGetMessages",{bot:this.id,sessionId:this.sessionId,fromTime:0,toTime:0,num:100});
		if(!res || res.code!==200){
			if(res && res.info){
				throw Error(res.info);
			}
			throw Error("Send bot message failed");
		}
		//Get current messages:
		msgs=this.messages;
		msgs.push(...res.messages);
		msg=msgs[msgs.length-1];
		this.lastMsgTime=msg?msg.time:1;

		//Wait connection ready:
		await pms;
		console.log("User client started.");
	};
	
	//------------------------------------------------------------------------
	aaHostBot.WSMSG_Message=async function(msg){
		let msgVO,callback;
		msgVO=msg.message;
		this.messages.push(msgVO);
		callback=this.waitMsgCall;
		if(callback){
			this.waitMsgCall=null;
			callback();
		}
		this.emitNotify("GetMessage");
	};

	//------------------------------------------------------------------------
	aaHostBot.getNewMessage=async function(fromTime){
		let pms,msgs,msg,i,n;
		if(!fromTime){
			fromTime=this.lastMsgTime;
		}
		msgs=this.messages;
		n=msgs.length;
		msg=msgs[n-1];
		if(!msg || msg.time<=fromTime){
			pms=new Promise((resolve,reject)=>{
				this.waitMsgCall=resolve;
			});
			await pms;
			n=msgs.length;
			msg=msgs[n-1];
		}
		this.waitMsgCall=null;
		if(!fromTime){
			fromTime=this.lastMsgTime;
		}
		if(msg && msg.time>fromTime){
			for(i=n-1;i>=0;i--){
				msg=msgs[i];
				if(msg.time<=fromTime){
					msg=msgs[i+1]
					this.lastMsgTime=msg.time;
					return msg;
				}
			}
			msg=msgs[0]
			this.lastMsgTime=msg.time;
			return msg;
		}
		return null;
	};

	//------------------------------------------------------------------------
	aaHostBot.startBotClient=async function(chatSession){
		let res;
		if(this.sessionId){
			throw Error("Bot session already started.");
		}
		
		res=await tabNT.makeCall("AAEBotNodeStartBotClient",{bot:this.id});
		if(!res || res.code!==200){
			if(res && res.info){
				throw Error(res.info);
			}
			throw Error("Get bot message error.");
		}
		this.chatSession=chatSession;
		this.sessionId=res.sessionId;
		//Start timeout
	};
	
	//------------------------------------------------------------------------
	aaHostBot.stopBotClient=async function(){
		this.sessionId=null;
	};

	//------------------------------------------------------------------------
	aaHostBot.sendMessage=async function(toBot,msgVO){
		msgVO.from=this.id;
		msgVO.to=typeof(toBot)==="string"?toBot:toBot.id;
		if(this.webSocket){
			this.webSocket.send(JSON.stringify({msg:"Message","message":msgVO}));
		}else{
			this.aaBots.sendMessage(this,toBot,msgVO);
		}
	};

	//************************************************************************
	//:HostBot's task request/work APIs:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		//Request:
		//--------------------------------------------------------------------
		aaHostBot.newTaskReq=async function(toBot,prompt,chatFlow){
			let res,fromId,toId,task;
			fromId=this.id;
			toId=toBot;
			res=await tabNT.makeCall("AAETaskNewTaskReq",{from:fromId,to:toId,prompt:prompt,chatFlow:chatFlow});
			if(!res || res.code!==200){
				if(res && res.info){
					throw Error(res.info);
				}
				throw Error("New task request failed");
			}
			task=new AATaskReq(res.taskId,fromId,toId,prompt);
			//Add to bot:
			this.taskReqs.set(task.id,task);
			return task;
		};

		//--------------------------------------------------------------------
		aaHostBot.rejectTaskReq=async function(taskId,reason){
			let res;
			res=await tabNT.makeCall("AAETaskRejectTaskReq",{taskId:taskId,from:this.id,reason:reason});
			if(!res || res.code!==200){
				if(res && res.info){
					throw Error(res.info);
				}
				throw Error("Reject taskReq failed");
			}
			this.taskReqs.delete(taskId);
		};
		
		//--------------------------------------------------------------------
		aaHostBot.finishTaskReq=async function(taskId,result){
			let res;
			res=await tabNT.makeCall("AAETaskFinishTaskReq",{taskId:taskId,from:this.id,result:result});
			if(!res || res.code!==200){
				if(res && res.info){
					throw Error(res.info);
				}
				throw Error("Finish taskReq failed");
			}
			this.taskReqs.delete(taskId);
		};

		//--------------------------------------------------------------------
		aaHostBot.failTaskReq=async function(taskId,reason){
			let res;
			res=await tabNT.makeCall("AAETaskFailTaskReq",{taskId:taskId,from:this.id,reason:reason});
			if(!res || res.code!==200){
				if(res && res.info){
					throw Error(res.info);
				}
				throw Error("New task failed");
			}
			this.taskReqs.delete(taskId);
		};
		
		//--------------------------------------------------------------------
		aaHostBot.giveUpTaskReq=async function(taskId,reason){
			let res;
			res=await tabNT.makeCall("AAETaskGiveUpTaskReq",{taskId:taskId,from:this.id,reason:reason});
			if(!res || res.code!==200){
				if(res && res.info){
					throw Error(res.info);
				}
				throw Error("New task failed");
			}
			this.taskReqs.delete(taskId);
		};
		
		//--------------------------------------------------------------------
		//Work:
		//--------------------------------------------------------------------
		aaHostBot.acceptTaskWork=async function(taskId,fromBot,prompt){
			let res,fromId,toId,task;
			toId=this.id;
			fromId=fromBot;
			res=await tabNT.makeCall("AAETaskAcceptTaskWork",{taskId:taskId,from:fromId,to:toId,prompt:prompt});
			if(!res || res.code!==200){
				if(res && res.info){
					throw Error(res.info);
				}
				throw Error("New task failed");
			}
			task=new AATaskWork(res.taskId,fromId,toId,prompt);
			this.taskWorks.set(task.id,task);
			return task;
		};

		//--------------------------------------------------------------------
		aaHostBot.getNextTaskWork=async function(){
			let res,task;
			res=await tabNT.makeCall("AAETaskGetNextWork",{bot:this.id});
			if(!res || res.code!==200){
				if(res && res.info){
					throw Error(res.info);
				}
				throw Error("Get next workfailed");
			}
			if(res.taskId){
				task=this.taskWorks.get(res.taskId);
			}
			return task;
		};
		
		//--------------------------------------------------------------------
		aaHostBot.rejectTaskWork=async function(taskId,reason){
			let res;
			res=await tabNT.makeCall("AAETaskRejectTaskWork",{taskId:taskId,from:this.id,reason:reason});
			if(!res || res.code!==200){
				if(res && res.info){
					throw Error(res.info);
				}
				throw Error("New task failed");
			}
		};
		
		//--------------------------------------------------------------------
		aaHostBot.startTaskWork=async function(taskId){
			let res,task;
			task=this.taskWorks.get(taskId);
			if(!task){
				throw Error(`Task ${taskId} not found.`);
			}
			res=await tabNT.makeCall("AAETaskStartTaskWork",{taskId:taskId,from:this.id});
			if(!res || res.code!==200){
				if(res && res.info){
					throw Error(res.info);
				}
				throw Error("New task failed");
			}
		};
		
		//--------------------------------------------------------------------
		aaHostBot.finishTaskWork=async function(taskId,result){
			let res,task;
			task=this.taskWorks.get(taskId);
			if(!task){
				throw Error(`Task ${taskId} not found.`);
			}
			res=await tabNT.makeCall("AAETaskFinishTaskWork",{taskId:taskId,from:this.id,result:result});
			if(!res || res.code!==200){
				if(res && res.info){
					throw Error(res.info);
				}
				throw Error("New task failed");
			}
			this.taskWorks.delete(taskId);
		};

		//--------------------------------------------------------------------
		aaHostBot.failTaskWork=async function(taskId,reason){
			let res,task;
			task=this.taskWorks.get(taskId);
			if(!task){
				throw Error(`Task ${taskId} not found.`);
			}
			res=await tabNT.makeCall("AAETaskFailTaskWork",{taskId:taskId,from:this.id,reason:reason});
			if(!res || res.code!==200){
				if(res && res.info){
					throw Error(res.info);
				}
				throw Error("New task failed");
			}
			this.taskWorks.delete(taskId);
		};

		//--------------------------------------------------------------------
		aaHostBot.giveUpTaskWork=async function(taskId,reason){
			let res,task;
			task=this.taskWorks.get(taskId);
			if(!task){
				throw Error(`Task ${taskId} not found.`);
			}
			res=await tabNT.makeCall("AAETaskGiveUpTaskWork",{taskId:taskId,from:this.id,reason:reason});
			if(!res || res.code!==200){
				if(res && res.info){
					throw Error(res.info);
				}
				throw Error("New task failed");
			}
			this.taskWorks.delete(taskId);
		};
	}
}

//****************************************************************************
//:AABots
//****************************************************************************
let AABots,aaBots;
{
	//------------------------------------------------------------------------
	AABots=function(){
		this.hostAlias=null;
		this.botsMap=new Map();
		this.taskMap=new Map();
		this.botsIndex=null;
	};
	aaBots=AABots.prototype={};
	
	//------------------------------------------------------------------------
	AABots.getAppBots=function(create=false){
		let topWin,bots;
		topWin=window;
		while(topWin.parent && topWin.parent!==topWin){
			topWin=topWin.parent;
		}
		if(create){
			bots=new AABots();
			topWin.AABotsInstance=bots;
		}else{
			bots=topWin.AABotsInstance;
			if(!bots){
				bots=new AABots();
				topWin.AABotsInstance=bots;
			}
		}
		return bots;
	};
	
	//------------------------------------------------------------------------
	aaBots.syncBots=aaBots.getBots=async function(){
		let res,list,bots,stub,bot,botsMap,hostAlias,botsIndex;
		hostAlias=this.hostAlias=await AAFarm.getLocalAlias();
		res=await tabNT.makeCall("AAEBotNodeGetBots",{});
		if(!res || res.code!==200){
			if(res && res.info){
				throw Error(res.info);
			}
			throw Error("open");
		}
		botsIndex=this.botsIndex={};
		botsMap=this.botsMap;
		list=res.bots;
		for(stub of list){
			bot=botsMap.get(stub.id);
			if(!bot){
				if(stub.alias===hostAlias){
					bot=new AAHostBot(this,stub);
				}else{
					bot=new AABot(this,stub);
				}
				botsMap.set(stub.id,bot);
				botsIndex[stub.id]=stub.description;
			}
		}
		return Array.from(botsMap.values());
	};
	
	//------------------------------------------------------------------------
	aaBots.getBotsIndex=async function(){
		if(!this.botsIndex){
			await this.syncBots();
		}
		return {...this.botsIndex};
	};
	
	//------------------------------------------------------------------------
	aaBots.getBot=function(id){
		return this.botsMap.get(id);
	};
	
	//------------------------------------------------------------------------
	aaBots.startHostBot=async function(id){
		let bot;
		bot=this.getBot(id);
		if(!bot){
			throw Error("startHostBot error: Can't find bot: "+id);
		}
		if(!bot.startMessageClient){
			throw Error(`startHostBot error: Bot ${id} is not a HostBot.`);
		}
	};
	
	//************************************************************************
	//:Tasks:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		aaBots.getTask=async function(taskId){
			
		};
	}
}

export {AABots};