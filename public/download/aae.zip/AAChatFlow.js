import {makeObjEventEmitter,makeNotify} from "/@events";
import {sleep} from "/@vfact";
import {tabNT,tabFS} from "/@tabos";
import {AAFarm} from "./aafarm.js";

let AAChatFlow,aaChatFlow;
//----------------------------------------------------------------------------
AAChatFlow=function(vo){
	if(!vo){
		return;
	}
	this.id=vo.id;
	this.from=vo.from;
	this.messages=vo.messages?vo.messages.slice(0):[];
	this.chatUI=null;
	makeObjEventEmitter(this);
	makeNotify(this);
};
const flowMap=AAChatFlow.flowMap=new Map();
AAChatFlow.emptyFlow=null;
aaChatFlow=AAChatFlow.prototype={};

//----------------------------------------------------------------------------
AAChatFlow.newFlow=async function(userId){
	let res,flow;
	res=await tabNT.makeCall("AAEChatFlowsNewFlow",{user:userId});
	if(!res || res.code!==200){
		if(res && res.info){
			console.warn(res.info);
			return false;
		}
		console.warn("Close flow failed");
		return false;
	}
	flow=new AAChatFlow(res);
	flowMap.set(flow.id,flow);
	AAChatFlow.emptyFlow=flow;
	return flow;
};

//----------------------------------------------------------------------------
AAChatFlow.addMessage=async function(message){
	let flow,flowId,time,messages,lastMsg;
	flowId=message.chatFlow;
	if(!flowId){
		return;
	}
	flow=flowMap.get(flowId);
	if(!flow){
		flow=await AAChatFlow.getFlow(message.chatFlow);
	}
	messages=flow.messages;
	lastMsg=messages[messages.length-1];
	if((lastMsg && lastMsg.time<message.time)||(!lastMsg)){
		flow.messages.push(message);
	}
	if(AAChatFlow.emptyFlow===flow){
		AAChatFlow.emptyFlow=null;
	}
	flow.emit("NewMessage",message);
};

//----------------------------------------------------------------------------
AAChatFlow.getFlow=async function(flowId){
	let res,flow;
	flow=flowMap.get(flowId);
	if(flow){
		return flow;
	}
	res=await tabNT.makeCall("AAEChatFlowsGetFlow",{flow:flowId});
	if(!res || res.code!==200){
		if(res && res.info){
			console.warn(res.info);
			return null;
		}
		console.warn("Get flow failed");
		return null;
	}
	flow=new AAChatFlow(res);
	flowMap.set(flowId,flow);
	return flow;
};

//----------------------------------------------------------------------------
AAChatFlow.closeFlow=async function(flowId){
	let res,flow;
	res=await tabNT.makeCall("AAEChatFlowsCloseFlow",{flow:flowId});
	if(!res || res.code!==200){
		if(res && res.info){
			console.warn(res.info);
			return false;
		}
		console.warn("Close flow failed");
		return false;
	}
	return true;
};

//----------------------------------------------------------------------------
AAChatFlow.deleteFlow=async function(flowId){
	let res,flow;
	res=await tabNT.makeCall("AAEChatFlowsDeleteFlow",{flow:flowId});
	if(!res || res.code!==200){
		if(res && res.info){
			console.warn(res.info);
			return false;
		}
		console.warn("Close flow failed");
		return false;
	}
	return true;
};

//----------------------------------------------------------------------------
aaChatFlow.getTitle=function(){
	let title;
	title=this.title;
	if(!title){
		let msg;
		msg=this.messages[0];
		if(msg){
			title=msg.content.text||msg.content.result||msg.content;
			title=(""+title)||"New chat flow";
			if(title.length>200){
				title=title.substring(0,197)+"...";
			}
			this.title=title;
		}else{
			title="New chat flow";
		}
	}
	return title;
};

//----------------------------------------------------------------------------
aaChatFlow.setTitle=async function(title){
	let res;
	if(!title){
		let msg;
		msg=this.messages[0];
		if(msg){
			title=msg.content.text||msg.content.result||msg.content;
			title=(""+title)||"New chat flow";
			if(title.length>200){
				title=title.substring(0,197)+"...";
			}
			this.title=title;
		}else{
			title="New chat flow";
		}
		return;
	}
	this.title=title;
	res=await tabNT.makeCall("AAEChatFlowsSetTitle",{flow:this.id,title:title});
	if(!res || res.code!==200){
		if(res && res.info){
			console.warn(res.info);
			return false;
		}
		console.warn("Close flow failed");
		return false;
	}
	this.emit("SetTitle",title);
	return true;
};

export {AAChatFlow};