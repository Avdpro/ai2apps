import {tabNT} from "/@tabos";
import pathLib from "/@path";
//****************************************************************************
//AAFileLib
//****************************************************************************
let AAFileLib,aaFileLib;
{
	//------------------------------------------------------------------------
	AAFileLib=function(){
		//Add something?
	};
	aaFileLib=AAFileLib.prototype={};
	
	//------------------------------------------------------------------------
	aaFileLib.writeFile=async function(fileName,data){
		let res;
		res=await tabNT.makeCall("AAEFileWrite",{fileName:fileName,data:data});
		if(!res || res.code!==200){
			if(res && res.info){
				throw Error(res.info);
			}
			throw Error("Send bot message failed");
		}
		return res.fileName;
	};

	//------------------------------------------------------------------------
	aaFileLib.readFile=async function(fileName){
		let res;
		if(fileName.startsWith("hub://")){
			fileName=fileName.substring(6);
		}
		res=await tabNT.makeCall("AAEFileRead",{fileName:fileName});
		if(!res || res.code!==200){
			if(res && res.info){
				throw Error(res.info);
			}
			throw Error("Send bot message failed");
		}
		return res.data;
	};

	//------------------------------------------------------------------------
	aaFileLib.readDataURL=async function(fileName){
		let res,data,extName;
		if(fileName.startsWith("hub://")){
			fileName=fileName.substring(6);
		}
		res=await tabNT.makeCall("AAEFileRead",{fileName:fileName});
		if(!res || res.code!==200){
			if(res && res.info){
				throw Error(res.info);
			}
			throw Error("Send bot message failed");
		}
		data=res.data;
		extName=pathLib.extname(fileName).toLowerCase();
		switch(extName){
			case ".jpg":
			case ".jpeg":
				data="data:image/jpeg;base64,"+data;
				break;
			case ".png":
				data="data:image/png;base64,"+data;
				break;
			case ".txt":
				data="data:text/plain;base64,"+data;
				break;
			default:
				data="data:application/octet-stream;base64,"+data;
				break;
		}
		return data;
	};
}

export default AAFileLib;
export {AAFileLib};