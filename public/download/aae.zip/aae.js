import {tabNT} from "/@tabos";
//This file is helper API talk with AI2Apps Chrome extension:
let AAE=null;
let AAEE=null;
let nextCallId=0;
let nextWatchId=0;
let callMap=new Map();
let watchMap=new Map();
let waitAAE=null;
let isAAEReady=false;
let clientMap=new Map();
let AAEWindow=window;
/*
{
	let win=window;
	do{
		if(win.parent===win){
			AAEWindow=win;
			break;
		}
		win=win.parent;
	}while(win);
}*/
function compileActionVal(act,valName,args){
	let val=act[valName];
	if(typeof(val)==="string" && val.startsWith("#")){
		let code,func;
		code=`return \`${val.substring(1)}\``;
		func=new Function(...args.keys,`return (${code});`);
		act[valName]=func.apply(null,args.values);
	}
}

//----------------------------------------------------------------------------
function compileAction(vo,args){
	let act;
	act={...vo};
	compileActionVal(act,"content",args);
	return act;
}

//----------------------------------------------------------------------------
function compileActions(actAry,args){
	let actions;
	args={
		keys:Object.keys(args),
		values:Object.values(args),
	};
	if(!Array.isArray(actAry)){
		actAry=[actAry];
	}
	return actAry.map((act)=>{return compileAction(act,args)});
}

//----------------------------------------------------------------------------
function aaeNode2DOM(aaeNode,onlyVisible=true){
	let domNode,attrs,rect,key,children,sub,subDomNode;
	if(aaeNode.nodeType===3){
		domNode=document.createTextNode(aaeNode.text);
		return domNode;
	}
	if(aaeNode.tagName){
		domNode=document.createElement(aaeNode.tagName);
		attrs=aaeNode.attrs;
		if(attrs){
			for(key in attrs){
				domNode.setAttribute(key,attrs[key]);
			}
		}
		if(aaeNode.AAEDId){
			domNode.setAttribute("aaeid",aaeNode.AAEDId);
		}
	}
	rect=aaeNode.rect;
	if(rect){
		domNode.setAttribute("aae-rect",`x=${rect.x};y=${rect.y};width=${rect.width};height=${rect.height}`);
	}
	children=aaeNode.children;
	if(children){
		for(sub of children){
			if(sub.nodeType!==3 && onlyVisible && (!sub.rect)){
				continue;
			}
			subDomNode=aaeNode2DOM(sub,onlyVisible);
			domNode.appendChild(subDomNode);
		}
	}
	return domNode;
};

const AAECore={
	aaeNode2DOM:aaeNode2DOM,
	compileActions:compileActions,
	compileAction:compileAction,
	compileActionVal:compileActionVal,
};
//****************************************************************************
//AAEE 
//****************************************************************************
{
	AAEE=function(){
		this.browser=null;
	};
	const aaee=AAEE.prototype={};

	//----------------------------------------------------------------------------
	aaee.init=async function(opts){
		let res;
		opts=opts||{headless:false,devtools:true};
		res=await tabNT.makeCall("aaeeOpenBrowser",{options:opts});
		if(!res || res.code!==200){
			return false;
		}
		this.browser=res.browser;
		//Keep browser alive:
		this.hbTimer=setInterval(()=>{
			tabNT.makeCall("aaeeHeartBeat",{browser:this.browser});
		},2*60*1000);
		return true;
	};

	//----------------------------------------------------------------------------
	aaee.waitStart=async function(){
		return true;
	};

	//----------------------------------------------------------------------------
	aaee.getVersion=async function(){
		let res;
		res=await tabNT.makeCall("aaeeGetVersion",{});
		if(!res || res.code!==200){
			return null;
		}
		return res.version;
	};
	
	//----------------------------------------------------------------------------
	aaee.getTabId=async function(){
		return await this.call("CONTENT","GetTabId");
	};

	//----------------------------------------------------------------------------
	aaee.connect=async function(){
		return true;
	};

	//----------------------------------------------------------------------------
	aaee.openPage=
	aaee.openClient=async function(url,scripts){
		let res,pageId,client;
		res=await tabNT.makeCall("aaeeOpenPage",{browser:this.browser});
		if(!res || res.code!==200){
			return null;
		}
		pageId=res.page;
		res=await tabNT.makeCall("aaeeOpenURL",{page:pageId,url:url});
		if(!res || res.code!==200){
			return null;
		}
		client={page:pageId,browser:this.browser};
		return client;
	};
	
	//------------------------------------------------------------------------
	aaee.waitPageLoad=async function(client,timeout){
		let res;
		res=await tabNT.makeCall("aaeeWaitPageLoad",{page:client.page,timeout:timeout});
		if(!res || res.code!==200){
			return null;
		}
		return {title:res.title,url:res.url};
	};
	
	//------------------------------------------------------------------------
	aaee.closeClient=
	aaee.closePage=async function(client){
		let res;
		res=await tabNT.makeCall("aaeeClosePage",{page:client.page});
		if(!res || res.code!==200){
			return false;
		}
		return true;		
	};
	
	//------------------------------------------------------------------------
	aaee.activeTab=async function(client,timeout){
		let res;
		if(!client){
			return true;
		}
		res=await tabNT.makeCall("aaeeBringToFront",{page:client.page});
		if(!res || res.code!==200){
			return false;
		}
		return true;		
	};
	
	//------------------------------------------------------------------------
	aaee.captureTab=async function(client){
		let res;
		res=await tabNT.makeCall("aaeeCapturePage",{page:client.page});
		if(!res || res.code!==200){
			return null;
		}
		return res.image;
	};
	
	//------------------------------------------------------------------------
	aaee.execScripts=async function(client){
		return true;
	};
	
	//************************************************************************
	//Read Page API:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		aaee.readPageView=async function(client){
			let res;
			res=await tabNT.makeCall("aaeeReadPageView",{page:client.page});
			if(!res || res.code!==200){
				return null;
			}
			return res.view;
		};

		//--------------------------------------------------------------------
		aaee.readPageHTML=async function(client){
			let res;
			res=await tabNT.makeCall("aaeeReadPageHTML",{page:client.page});
			if(!res || res.code!==200){
				return null;
			}
			return res.html;
		};

		//--------------------------------------------------------------------
		aaee.readPageInnerText=async function(client){
			let res;
			res=await tabNT.makeCall("aaeeReadPageText",{page:client.page});
			if(!res || res.code!==200){
				return null;
			}
			return res.text;
		};

		//--------------------------------------------------------------------
		aaee.readPageArticle=async function(client){
			let res;
			res=await tabNT.makeCall("aaeeReadPageArticle",{page:client.page});
			if(!res || res.code!==200){
				return null;
			}
			return res.text;
		};

		//--------------------------------------------------------------------
		aaee.readPageArticle=async function(client){
			let res;
			res=await tabNT.makeCall("aaeeReadPageArticle",{page:client.page});
			if(!res || res.code!==200){
				return null;
			}
			return res.text;
		};

		//--------------------------------------------------------------------
		aaee.readNodeView=async function(client,aaeId){
			let res;
			res=await tabNT.makeCall("aaeeReadNodeView",{page:client.page,aaeId:aaeId});
			if(!res || res.code!==200){
				return null;
			}
			return res.view;
		};

		//--------------------------------------------------------------------
		aaee.readNodeText=async function(client,aaeId){
			let res;
			res=await tabNT.makeCall("aaeeReadNodeText",{page:client.page,aaeId:aaeId});
			if(!res || res.code!==200){
				return null;
			}
			return res.text;
		};

		//--------------------------------------------------------------------
		aaee.queryNode=async function(client,selector,aaeId,opts){
			let res;
			res=await tabNT.makeCall("aaeeQueryNode",{page:client.page,selector:selector,aaeId:aaeId,opts:opts});
			if(!res || res.code!==200){
				return null;
			}
			return res.node;
		};

		//--------------------------------------------------------------------
		aaee.queryNodes=async function(client,selector,opts){
			let res,aaeId,visibleOnly;
			if(opts){
				if(typeof(opts)==="object"){
					aaeId=opts.root||opts.AAEId||opts.aaeId||undefined;
					aaeId=aaeId.AAEId||undefined;
					if("filterVisible" in opts){
						visibleOnly=opts.filterVisible;
					}
				}else{
					aaeId=opts;
					opts=null;
				}
				res=await tabNT.makeCall("aaeeQueryNodes",{page:client.page,selector:selector,aaeId:aaeId,opts:opts});
			}else{
				res=await tabNT.makeCall("aaeeQueryNodes",{page:client.page,selector:selector,opts:opts});
			}
			if(!res || res.code!==200){
				return null;
			}
			return res.list;
		};

		//--------------------------------------------------------------------
		aaee.getNodeParent=async function(client,aaeId){
			let res;
			aaeId=aaeId.AAEId||aaeId;
			res=await tabNT.makeCall("aaeeGetNodeParent",{page:client.page,aaeId:aaeId});
			if(!res || res.code!==200){
				return false;
			}
			return res.node;
		};

		//--------------------------------------------------------------------
		aaee.getNodeChildren=async function(client,aaeId){
			let res;
			aaeId=aaeId.AAEId||aaeId;
			res=await tabNT.makeCall("aaeeGetNodeChildren",{page:client.page,aaeId:aaeId});
			if(!res || res.code!==200){
				return null;
			}
			return res.children;
		};

		//--------------------------------------------------------------------
		aaee.getNodeAttribute=async function(client,aaeId,key){
			let res;
			aaeId=aaeId.AAEId||aaeId;
			res=await tabNT.makeCall("aaeeGetNodeAttribute",{page:client.page,aaeId:aaeId,key:key});
			if(!res || res.code!==200){
				return null;
			}
			return res.value;
		};

		//--------------------------------------------------------------------
		aaee.setNodeAttribute=async function(client,aaeId,key,value){
			let res;
			aaeId=aaeId.AAEId||aaeId;
			res=await tabNT.makeCall("aaeeSetNodeAttribute",{page:client.page,aaeId:aaeId,key:key,value:value});
			if(!res || res.code!==200){
				return false;
			}
			return true;
		};

		//--------------------------------------------------------------------
		aaee.getNodeAttributes=async function(client,aaeId){
			let res;
			aaeId=aaeId.AAEId||aaeId;
			res=await tabNT.makeCall("aaeeGetNodeAttributes",{page:client.page,aaeId:aaeId});
			if(!res || res.code!==200){
				return null;
			}
			return res.attributes;
		};
	}
	
	
	//************************************************************************
	//Send / track user actions:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		aaee.nativeAction=async function(client,opts){
			let res;
			res=await tabNT.makeCall("aaeeUserAction",{page:client.page,opts:opts});
			if(!res || res.code!==200){
				return false;
			}
			return true;
		};

		//--------------------------------------------------------------------
		aaee.cancelWatch=async function(){
			return true;
		};

		//--------------------------------------------------------------------
		aaee.watchNode=async function(){
			return true;
		};

		//--------------------------------------------------------------------
		aaee.watchUserAction=async function(){
			return true;
		};
	}
}

const AAEL={
	//------------------------------------------------------------------------
	waitStart:async function(){
		if(!isAAEReady){
			let pms=new Promise((resolve,reject)=>{
				waitAAE=resolve;
				setTimeout(()=>{reject("Timeout")},10000);
			});
			await pms;
			return await this.getVersion();
		}
		return await this.getVersion();
	},

	//------------------------------------------------------------------------
	getVersion:async function(){
		return await this.call("CONTENT","GetVersion");
	},
	
	//------------------------------------------------------------------------
	getTabId:async function(){
		return await this.call("CONTENT","GetTabId");
	},
	
	//------------------------------------------------------------------------
	connect:async function(){
		return await this.call("CONTENT","Connect");
	},

	//------------------------------------------------------------------------
	openClient:async function(url,scripts){
		let client,clientStub;
		client=await this.call("CONENT","OpenClient",{href:url,scripts:scripts});
		clientStub={
			client:client,
			frames:[],
			framesMap:new Map(),
		};
		clientMap.set(client.tabId,clientStub);
		return client;
	},

	//------------------------------------------------------------------------
	waitPageLoad:async function(client,timeout=30){
		return await this.call("PORT","WaitPageLoad",{$client:client,timeout:Math.floor(timeout*1000)});
	},
	
	//------------------------------------------------------------------------
	waitTabActive:async function(){
		return await this.call("PORT","WaitTabActive",{});
	},
	
	//------------------------------------------------------------------------
	findTabs:async function(query){
		return await this.call("PORT","FindTabs",{query:query});
	},
	
	//------------------------------------------------------------------------
	activeTab:async function(client){
		let tabId;
		tabId=client?(client.tabId||client):null;
		return await this.call("PORT","ActiveTab",{tabId:tabId});
	},

	//------------------------------------------------------------------------
	captureTab:async function(client,win){
		return await this.call("PORT","CaptureTab",{window:win});
	},

	//------------------------------------------------------------------------
	execScripts:async function(files,client,frameId){
		let tabId;
		tabId=client.tabId||client;
		return await this.call("PORT","ExecScripts",{tabId:tabId,frameId:frameId,files:files});
	},

	//------------------------------------------------------------------------
	//Read client DOM-View:
	readPageView:async function(client,html=true){
		let aaeNode,opts;
		if(html && typeof(html)==="object"){
			opts=html;
			html=opts.output!=="tree";
		}
		aaeNode=await this.call("CLIENT","ReadPageView",{$client:client,opts:opts});
		return html?aaeNode2DOM(aaeNode):aaeNode;
	},

	//------------------------------------------------------------------------
	//Read client Page HTML:
	readPageHTML:async function(client){
		return await this.call("CLIENT","ReadPageHTML",{$client:client});
	},

	//------------------------------------------------------------------------
	//Read client Page-inner-text:
	readPageInnerText:async function(client){
		return await this.call("CLIENT","ReadPageText",{$client:client});
	},

	//------------------------------------------------------------------------
	//Read client Page article content:
	readPageArticle:async function(client){
		return await this.call("CLIENT","ReadArticle",{$client:client});
	},

	//------------------------------------------------------------------------
	//Read client Node-View:
	readNodeView:async function(client,aaeId,opts){
		let view;
		aaeId=aaeId.AAEId||aaeId;
		view=await this.call("CLIENT","ReadNodeView",{$client:client,AAEId:aaeId,options:opts});
		return aaeNode2DOM(view);
		
	},

	//------------------------------------------------------------------------
	//Read client Node-InnerText:
	readNodeText:async function(client,aaeId){
		let view;
		aaeId=aaeId.AAEId||aaeId;
		view=await this.call("CLIENT","ReadNodeView",{$client:client,AAEId:aaeId});
		view=aaeNode2DOM(view);
		if(view){
			return view.innerText;
		}
		return "";
	},

	//------------------------------------------------------------------------
	//Read client Node-InnerHTML:
	readNodeHTML:async function(client,aaeId){
		let view;
		aaeId=aaeId.AAEId||aaeId;
		view=await this.call("CLIENT","ReadNodeView",{$client:client,AAEId:aaeId});
		view=aaeNode2DOM(view);
		if(view){
			return view.innerHTML;
		}
		return "";
	},

	//------------------------------------------------------------------------
	//Query client DOM Nodes:
	queryNodes:async function(client,selector,opts){
		let aaeId,visibleOnly=true;
		if(opts){
			if(typeof(opts)==="object"){
				aaeId=opts.root||opts.AAEId||undefined;
				aaeId=aaeId.AAEId||undefined;
				if("filterVisible" in opts){
					visibleOnly=opts.filterVisible;
				}
			}else{
				aaeId=opts;
				opts=null;
			}
			return await this.call("CLIENT","QueryNodes",{$client:client,selector:selector,AAEId:aaeId,options:opts,visibleOnly:visibleOnly});
		}
		return await this.call("CLIENT","QueryNodes",{$client:client,selector:selector,visibleOnly:visibleOnly});
	},
	
	//------------------------------------------------------------------------
	//Query one client DOM Node:
	queryNode:async function(client,selector,opts){
		let aaeId,visibleOnly=true;
		if(opts){
			if(typeof(opts)==="object"){
				aaeId=opts.root||opts.AAEId||undefined;
				aaeId=aaeId.AAEId||undefined;
				if("filterVisible" in opts){
					visibleOnly=opts.filterVisible;
				}
			}else{
				aaeId=opts;
				opts=null;
			}
			return await this.call("CLIENT","QueryNode",{$client:client,selector:selector,AAEId:aaeId,options:opts,visibleOnly:visibleOnly});
		}
		return await this.call("CLIENT","QueryNode",{$client:client,selector:selector,visibleOnly:visibleOnly});
	},

	//------------------------------------------------------------------------
	//Find a node that best match with condition
	matchNode:async function(client,condition){
		return await this.call("CLIENT","MatchNode",{$client:client,condition:condition});
	},
	
	//------------------------------------------------------------------------
	//Read client node's parent:
	getNodeParent:async function(client,aaeId){
		aaeId=aaeId.AAEId||aaeId;
		return await this.call("CLIENT","GetNodeParent",{$client:client,AAEId:aaeId});
	},

	//------------------------------------------------------------------------
	//Read client node's children list:
	getNodeChildren:async function(client,aaeId){
		aaeId=aaeId.AAEId||aaeId;
		return await this.call("CLIENT","GetNodeChildren",{$client:client,AAEId:aaeId});
	},

	//------------------------------------------------------------------------
	//Get node attribute:
	getNodeAttribute:async function(client,aaeId,key){
		aaeId=aaeId.AAEId||aaeId;
		return await this.call("CLIENT","GetNodeAttribute",{$client:client,AAEId:aaeId,key:key});
	},
	
	//------------------------------------------------------------------------
	//Set node attribute:
	setNodeAttribute:async function(client,aaeId,key,value){
		aaeId=aaeId.AAEId||aaeId;
		return await this.call("CLIENT","SetNodeAttribute",{$client:client,AAEId:aaeId,key:key,value:value});
	},
	
	//------------------------------------------------------------------------
	//Get node attribute:
	getNodeAttributes:async function(client,aaeId){
		aaeId=aaeId.AAEId||aaeId;
		return await this.call("CLIENT","GetNodeAttributes",{$client:client,AAEId:aaeId});
	},
	
	//------------------------------------------------------------------------
	_addWatch:function(watchId,callback){
		watchMap.set(watchId,callback);
	},
	
	//------------------------------------------------------------------------
	cancelWatch:async function(client,watchId){
		await this.post("CLIENT","CancelWatch",{$client:client,$watchId:watchId});
		watchMap.delete(watchId);
	},
	
	//------------------------------------------------------------------------
	//Watch client DOM changes:
	watchNode:async function(client,aaeNodeId,callback,opts={}){
		let watchId=""+(nextWatchId++);
		this._addWatch(watchId,callback);
		await this.call("CLIENT","WatchNode",{$client:client,node:aaeNodeId,options:opts,$watchId:watchId});
		return watchId;
	},

	//------------------------------------------------------------------------
	//Watch client user actions:
	watchUserAction:async function(client,callback,opts={}){
		let watchId=""+(nextWatchId++);
		this._addWatch(watchId,callback);
		await this.call("CLIENT","WatchAction",{$client:client,options:opts,$watchId:watchId});
		return watchId;
	},

	//------------------------------------------------------------------------
	//Simulate an user action:
	runAction:async function(client,action){
		return await this.call("CLIENT","RunAction",{$client:client,action:action});
	},

	//------------------------------------------------------------------------
	//ClosePage
	closePage:async function(client){
		await this.post("CLIENT","Close",{$client:client});
	},

	//------------------------------------------------------------------------
	call:async function(target,msg,data){
		let type,pms,tabId;
		switch(target){
			case "CONTENT":
			default:
				type="PAGE_CONTENT";
				break;
			case "WORKER":
				type="PAGE_WORKER";
				break;
			case "PORT":
				type="HOST_PORT";
				break;
			case "CLIENT":
				type="HOST_CLIENT";
				tabId=target;
				break;
		}
		pms=new Promise((resolve,reject)=>{
			let callId=""+(nextCallId++);
			if(data){
				data = {AAEType:type, AAEMsg:msg, $callId:callId, ...data};
			}else{
				data = {AAEType:type, AAEMsg:msg, $callId:callId};
			}
			AAEWindow.postMessage(data, "*");
			callMap.set(callId,{resolve:resolve,reject:reject});
		});
		return await pms;
	},
	
	//------------------------------------------------------------------------
	send:async function(target,msg,data){
		let type,pms,tabId;
		switch(target){
			case "CONTENT":
			default:
				type="PAGE_CONTENT";
				break;
			case "WORKER":
				type="PAGE_WORKER";
				break;
			case "PORT":
				type="HOST_PORT";
				break;
			case "CLIENT":
				type="HOST_CLIENT";
				tabId=target;
				break;
		}
		if(data){
			data = {AAEType:type, AAEMsg:msg, ...data};
		}else{
			data = {AAEType:type, AAEMsg:msg};
		}
		AAEWindow.postMessage(data, "*");
	},
};
AAEL.post=AAEL.send;
AAEWindow.addEventListener("message", function(event) {
	let data=event.data;
    // We only accept messages from extension to page:
	console.log("AAEHost got message:");
	console.log(data);
    if (data.AAEType && (data.AAEType.endsWith("_PAGE") || data.AAEType.endsWith("_HOST"))){
		switch(data.AAEMsg){
			case "$ReturnCall$":{
				let callId=data.$callId;
				let stub=callMap.get(callId);
				if(stub){
					stub.resolve(data.data);
					callMap.delete(callId);
				}
				return;
			}
			case "$StartAAE$":{
				isAAEReady=true;
				if(waitAAE){
					let func=waitAAE;
					waitAAE=null;
					func(true);
				}
				return;
			}
			case "$RejectCall$":{
				let callId=data.$callId;
				let stub=callMap.get(callId);
				if(stub){
					stub.reject(data.data);
					callMap.delete(callId);
				}
				return;
			}
			case "$Action$":
			case "$Watch$":{
				let watchId=data.$watchId;
				let stub=watchMap.get(watchId);
				if(stub){
					stub(data.action);
				}
				return;
			}
			case "$NewFrame$":{
				let tabId=data.tabId;
				let frameId=data.frameId;
				let clientStub=clientMap.get(tabId);
				if(clientStub){
					let frameInfo;
					frameInfo=clientStub.framesMap.get(frameId);
					if(frameInfo){
						frameInfo.href=data.href;
						console.log("AAE frame open new page: ");
						console.log(frameInfo);
					}else{
						frameInfo={tabId:tabId,frameId:frameId,frameIdx:clientStub.frames.length,href:data.href};
						console.log("AAE New frame: ");
						console.log(frameInfo);
						clientStub.frames.push(frameInfo);
						clientStub.framesMap.set(frameId,frameInfo);
					}
				}
				return;
			}
			default:{
				//TODO: call handlers:
			}
		}
    }
});
AAEWindow.postMessage({AAEType:"PAGE_CONTENT",AAEMsg:"$StartAAE$"},"*");

let api=AAEL;
AAE=new Proxy({},{
	get:function(tgt,key){
		var attr;
		if(key==="setup"){
			return async function(useAAEE=false,opts){
				if(useAAEE){
					api=new AAEE();
					return await api.init(opts);
				}else{
					api=AAEL;
				}
				return true;
			};
		}
		return api[key]||AAECore[key];
	},
	set:function(tgt,key,val){
		throw new Error(`Can not set attrib on AAEProxy.`);
	}
});


export default AAE;
export {AAE}