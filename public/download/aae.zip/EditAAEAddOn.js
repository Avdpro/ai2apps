import {VFACT} from "/@vfact";
//Avdpro
const $ln=VFACT.lanCode;

const EditAISeg=VFACT.classRegs.EditAISeg;
const EditAISegOutlet=VFACT.classRegs.EditAISegOutlet;
const SegObjShellAttr=EditAISeg.SegObjShellAttr;
const SegOutletDef=EditAISegOutlet.SegOutletDef;

const DocAIAgentExporter=VFACT.classRegs.DocAIAgentExporter;
const docAIAgentExporter=DocAIAgentExporter.prototype;
const varNameRegex = /^[a-zA-Z_$][a-zA-Z0-9_$]*$/;

const packExtraCodes=docAIAgentExporter.packExtraCodes;
const packResult=docAIAgentExporter.packResult;

EditAISeg.regCatalog({
	name:"AAE",showName:(($ln==="CN")?("AAE"):/*EN*/("AAE"))
});

EditAISeg.regCatalog({
	name:"AAE+",showName:(($ln==="CN")?("AAE+"):/*EN*/("AAE+"))
});

//----------------------------------------------------------------------------
//:AISeg that init and start AAE:
EditAISeg.regDef({
	name:"startAAE",showName:(($ln==="CN")?("启动AAE"):/*EN*/("Init AAE")),icon:"start.svg",catalog:["AAE"],
	attrs:{
		...SegObjShellAttr,
		"outlet":{
			name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
		},
		"catchlet":{
			name:"catchlet",showName:"Catch",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
			attrs:{
				"id":{
					name:"id",showName:(($ln==="CN")?("ID名称"):/*EN*/("ID name")),type:"string",key:1,fixed:1,initVal:"NoAAE",
				},
			},
		}
	},
	listHint:[
		"id","mkpInput","codes","context","global","desc",
	],
	importSource:{path:"/@aae",name:"AAE"},
});

DocAIAgentExporter.segTypeExporters["startAAE"]=
function(seg){
	let coder=this.coder;
	let segName=seg.idVal.val;
	let exportDebug=this.isExportDebug();
	segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
	coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
	coder.indentMore();
	coder.newLine();
	{
		coder.maybeNewLine();
		coder.packText(`let result=true;`);coder.newLine();
		packExtraCodes(coder,seg,"PreCodes");
		coder.packText(`try{`);
		coder.indentMore();coder.newLine();
		{
			coder.packText(`await AAE.waitStart();`);coder.newLine();
			coder.packText(`await AAE.connect();`);coder.newLine();
		}
		coder.indentLess();coder.maybeNewLine();
		coder.packText(`}catch(err){`);
		coder.indentMore();coder.newLine();
		{
			let catchlet,catchSeg;
			catchlet=seg.catchlet||null;
			if(catchlet){
				catchSeg=catchlet.getLinkedSeg();
				if(catchSeg){
					packResult(coder,seg,catchlet,"err");
				}else{
					coder.packText(`throw err;`);coder.newLine();
				}
			}else{
				coder.packText(`throw err;`);coder.newLine();
			}
		}
		coder.indentLess();coder.maybeNewLine();
		coder.packText(`}`);
		packExtraCodes(coder,seg,"PostCodes");
		packResult(coder,seg,seg.outlet,"result");
	}
	coder.indentLess();
	coder.newLine();
	coder.packText(`};`);
	coder.newLine();
	if(exportDebug){
		coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
	}
	coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
	//coder.packText(`${segName}.desc=`);this.genAttrStatement(seg.getAttr("desc"));coder.packText(`;`);coder.newLine();
	coder.newLine();
};

//----------------------------------------------------------------------------
//:AISeg that let AAE open page:
EditAISeg.regDef({
	name:"openAAEPage",showName:(($ln==="CN")?("打开AAE网页"):/*EN*/("AAE Open Page")),icon:"/@aae/assets/tab_add.svg",catalog:["AAE"],
	attrs:{
		...SegObjShellAttr,
		"url":{
			name:"url",showName:(($ln==="CN")?("网址"):/*EN*/("URL")),type:"string",key:1,fixed:1,initValText:"#input",initVal:"$$input$$"
		},
		"clientName":{
			name:"clientName",showName:(($ln==="CN")?("客户端名字"):/*EN*/("Client Name")),type:"string",key:1,fixed:1,initVal:"aaeClient"
		},
		"waitLoad":{
			name:"waitLoad",showName:(($ln==="CN")?("等待加载"):/*EN*/("Wait Load")),type:"bool",key:1,fixed:1,initVal:true,rawEdit:false
		},
		"outlet":{
			name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
		},
	},
	listHint:[
		"id","mkpInput","url","clientName","waitLoad","codes","context","global","desc",
	],
	importSource:{path:"/@aae",name:"AAE"},
});

DocAIAgentExporter.segTypeExporters["openAAEPage"]=
function(seg){
	let coder=this.coder;
	let segName=seg.idVal.val;
	let exportDebug=this.isExportDebug();
	let waitLoad=seg.getAttrVal("waitLoad");
	let clientName=seg.getAttrVal("clientName");

	segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
	coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
	coder.indentMore();
	coder.newLine();
	{
		coder.maybeNewLine();
		coder.packText(`let result=null;`);coder.newLine();
		coder.packText(`let url=`);this.genAttrStatement(seg.getAttr("url"));coder.packText(`;`);coder.newLine();
		packExtraCodes(coder,seg,"PreCodes");
		coder.packText(`result=context.${clientName}=await AAE.openClient(url,["scripts/readPage.js","action/action.js"]);`);coder.newLine();
		if(waitLoad){
			coder.packText(`result=await AAE.waitPageLoad(result);`);coder.newLine();
		}
		packExtraCodes(coder,seg,"PostCodes");
		packResult(coder,seg,seg.outlet,"result");
	}
	coder.indentLess();
	coder.newLine();
	coder.packText(`};`);
	coder.newLine();
	if(exportDebug){
		coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
	}
	coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
	//coder.packText(`${segName}.desc=`);this.genAttrStatement(seg.getAttr("desc"));coder.packText(`;`);coder.newLine();
	coder.newLine();
};

//----------------------------------------------------------------------------
//:AISeg that wait AAE client page to load:
EditAISeg.regDef({
	name:"waitAAEPageLoad",showName:(($ln==="CN")?("等待网页加载"):/*EN*/("Wait Page Load")),icon:"hudstate.svg",catalog:["AAE"],
	attrs:{
		...SegObjShellAttr,
		"client":{
			name:"client",showName:(($ln==="CN")?("客户端"):/*EN*/("Client")),type:"auto",key:1,fixed:1,initValText:"#context.aaeClient",initVal:null
		},
		"outlet":{
			name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
		},
	},
	listHint:[
		"id","mkpInput","client","codes","context","global","desc",
	],
	importSource:{path:"/@aae",name:"AAE"},
});

DocAIAgentExporter.segTypeExporters["waitAAEPageLoad"]=
function(seg){
	let coder=this.coder;
	let segName=seg.idVal.val;
	let exportDebug=this.isExportDebug();

	segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
	coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
	coder.indentMore();
	coder.newLine();
	{
		coder.maybeNewLine();
		coder.packText(`let result=null;`);coder.newLine();
		coder.packText(`let client=`);this.genAttrStatement(seg.getAttr("client"));coder.packText(`;`);coder.newLine();
		packExtraCodes(coder,seg,"PreCodes");
		coder.packText(`result=await AAE.waitPageLoad(client);`);coder.newLine();
		packExtraCodes(coder,seg,"PostCodes");
		packResult(coder,seg,seg.outlet,"result");
	}
	coder.indentLess();
	coder.newLine();
	coder.packText(`};`);
	coder.newLine();
	if(exportDebug){
		coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
	}
	coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
	//coder.packText(`${segName}.desc=`);this.genAttrStatement(seg.getAttr("desc"));coder.packText(`;`);coder.newLine();
	coder.newLine();
};

//----------------------------------------------------------------------------
//:AISeg that close AAE client page:
EditAISeg.regDef({
	name:"closeAAEPage",showName:(($ln==="CN")?("关闭网页"):/*EN*/("Close Page")),icon:"/@aae/assets/tab_close.svg",catalog:["AAE"],
	attrs:{
		...SegObjShellAttr,
		"client":{
			name:"client",showName:(($ln==="CN")?("客户端"):/*EN*/("Client")),type:"auto",key:1,fixed:1,initValText:"#context.aaeClient",initVal:null
		},
		"outlet":{
			name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
		},
	},
	listHint:[
		"id","mkpInput","client","codes","context","global","desc",
	],
	importSource:{path:"/@aae",name:"AAE"},
});

DocAIAgentExporter.segTypeExporters["closeAAEPage"]=
function(seg){
	let coder=this.coder;
	let segName=seg.idVal.val;
	let exportDebug=this.isExportDebug();

	segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
	coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
	coder.indentMore();
	coder.newLine();
	{
		coder.maybeNewLine();
		coder.packText(`let result=input;`);coder.newLine();
		coder.packText(`let client=`);this.genAttrStatement(seg.getAttr("client"));coder.packText(`;`);coder.newLine();
		packExtraCodes(coder,seg,"PreCodes");
		coder.packText(`AAE.closePage(client);`);coder.newLine();
		packExtraCodes(coder,seg,"PostCodes");
		packResult(coder,seg,seg.outlet,"result");
	}
	coder.indentLess();
	coder.newLine();
	coder.packText(`};`);
	coder.newLine();
	if(exportDebug){
		coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
	}
	coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
	//coder.packText(`${segName}.desc=`);this.genAttrStatement(seg.getAttr("desc"));coder.packText(`;`);coder.newLine();
	coder.newLine();
};

//----------------------------------------------------------------------------
//:AISeg that read AAE client page:
EditAISeg.regDef({
	name:"readAAEPage",showName:(($ln==="CN")?("读取网页"):/*EN*/("Read Page")),icon:"lab.svg",catalog:["AAE"],
	attrs:{
		...SegObjShellAttr,
		"client":{
			name:"client",showName:(($ln==="CN")?("客户端"):/*EN*/("Client")),type:"auto",key:1,fixed:1,initValText:"#context.aaeClient",initVal:null
		},
		"mode":{
			name:"mode",showName:(($ln==="CN")?("读取类型"):/*EN*/("Read Mode")),type:"choice",key:1,fixed:1,initVal:"text",
			vals:[
				["article","Article","Article Conent"],
				["view","View","Dom Tree View"],
				["html","HTML","Document Inner HTML"],
				["text","Text","Document Inner Text"],
			],valueType:"string"
		},
		"outlet":{
			name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
		},
	},
	listHint:[
		"id","mkpInput","client","mode","codes","context","global","desc",
	],
	importSource:{path:"/@aae",name:"AAE"},
});

DocAIAgentExporter.segTypeExporters["readAAEPage"]=
function(seg){
	let coder=this.coder;
	let segName=seg.idVal.val;
	let exportDebug=this.isExportDebug();
	let readMode=seg.getAttrVal("mode");

	segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
	coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
	coder.indentMore();
	coder.newLine();
	{
		coder.maybeNewLine();
		coder.packText(`let result=null;`);coder.newLine();
		coder.packText(`let client=`);this.genAttrStatement(seg.getAttr("client"));coder.packText(`;`);coder.newLine();
		coder.packText(`let mode=`);this.genAttrStatement(seg.getAttr("mode"));coder.packText(`;`);coder.newLine();
		packExtraCodes(coder,seg,"PreCodes");
		coder.packText(`switch(mode){`);
		coder.indentMore();coder.newLine();
		{
			coder.packText(`case "article":`);
			coder.indentMore();coder.newLine();
				coder.packText(`result=await AAE.readPageArticle(client);`);coder.newLine();
				coder.packText(`break;`);
				coder.indentLess();coder.maybeNewLine();
			coder.packText(`case "view":`);
			coder.indentMore();coder.newLine();
				coder.packText(`result=await AAE.readPageView(client);`);coder.newLine();
				coder.packText(`break;`);
				coder.indentLess();coder.maybeNewLine();
			coder.packText(`case "html":`);
			coder.indentMore();coder.newLine();
				coder.packText(`result=await AAE.readPageHTML(client);`);coder.newLine();
				coder.packText(`break;`);
				coder.indentLess();coder.maybeNewLine();
			coder.packText(`case "text":`);
			coder.indentMore();coder.newLine();
				coder.packText(`result=await AAE.readPageInnerText(client);`);coder.newLine();
				coder.packText(`break;`);
				coder.indentLess();coder.maybeNewLine();
		}
		coder.indentLess();coder.maybeNewLine();
		coder.packText(`}`);coder.maybeNewLine();
		packExtraCodes(coder,seg,"PostCodes");
		packResult(coder,seg,seg.outlet,"result");
	}
	coder.indentLess();
	coder.newLine();
	coder.packText(`};`);
	coder.newLine();
	if(exportDebug){
		coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
	}
	coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
	//coder.packText(`${segName}.desc=`);this.genAttrStatement(seg.getAttr("desc"));coder.packText(`;`);coder.newLine();
	coder.newLine();
};

//----------------------------------------------------------------------------
//:AISeg that run querySelectors on AAE client page:
EditAISeg.regDef({
	name:"queryAAESelector",showName:(($ln==="CN")?("选取网页元素"):/*EN*/("Query Node(s)")),icon:"design.svg",catalog:["AAE"],
	attrs:{
		...SegObjShellAttr,
		"client":{
			name:"client",showName:(($ln==="CN")?("客户端"):/*EN*/("Client")),type:"auto",key:1,fixed:1,initValText:"#context.aaeClient",initVal:null
		},
		"root":{
			name:"root",showName:(($ln==="CN")?("查找源"):/*EN*/("Query root")),type:"auto",key:1,fixed:1,initVal:undefined
		},
		"selector":{
			name:"selector",showName:(($ln==="CN")?("选择表达式"):/*EN*/("Selector")),type:"string",key:1,fixed:1,initVal:""
		},
		"pick":{
			name:"pick",showName:(($ln==="CN")?("选取序号"):/*EN*/("Pick Index")),type:"auto",key:1,fixed:1,initVal:""
		},
		"outlet":{
			name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
		},
	},
	listHint:[
		"id","mkpInput","client","root","selector","pick","codes","context","global","desc",
	],
	importSource:{path:"/@aae",name:"AAE"},
});

DocAIAgentExporter.segTypeExporters["queryAAESelector"]=
function(seg){
	let coder=this.coder;
	let segName=seg.idVal.val;
	let exportDebug=this.isExportDebug();

	segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
	coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
	coder.indentMore();
	coder.newLine();
	{
		coder.maybeNewLine();
		coder.packText(`let result=null;`);coder.newLine();
		coder.packText(`let selector=`);this.genAttrStatement(seg.getAttr("selector"));coder.packText(`;`);coder.newLine();
		coder.packText(`let pick=`);this.genAttrStatement(seg.getAttr("pick"));coder.packText(`;`);coder.newLine();
		coder.packText(`let client=`);this.genAttrStatement(seg.getAttr("client"));coder.packText(`;`);coder.newLine();
		coder.packText(`let root=`);this.genAttrStatement(seg.getAttr("root"));coder.packText(`;`);coder.newLine();
		packExtraCodes(coder,seg,"PreCodes");
		coder.packText(`result=await AAE.queryNodes(client,selector,root);`);coder.newLine();
		//pick result?
		coder.packText(`if(pick>=0){`);
		coder.indentMore();coder.newLine();
		{
			coder.packText(`result=result[pick];`);coder.newLine();
		}
		coder.indentLess();coder.maybeNewLine();
		coder.packText(`}else if(pick<0){`);
		coder.indentMore();coder.newLine();
		{
			coder.packText(`result=result[result.length+pick];`);coder.newLine();
		}
		coder.indentLess();coder.maybeNewLine();
		coder.packText(`}`);

		packExtraCodes(coder,seg,"PostCodes");
		packResult(coder,seg,seg.outlet,"result");
	}
	coder.indentLess();
	coder.newLine();
	coder.packText(`};`);
	coder.newLine();
	if(exportDebug){
		coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
	}
	coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
	//coder.packText(`${segName}.desc=`);this.genAttrStatement(seg.getAttr("desc"));coder.packText(`;`);coder.newLine();
	coder.newLine();
};

//----------------------------------------------------------------------------
//:AISeg that run action on AAE node:
EditAISeg.regDef({
	name:"sendAAEAction",showName:(($ln==="CN")?("发送网页操作"):/*EN*/("Send Action")),icon:"send.svg",catalog:["AAE"],
	attrs:{
		...SegObjShellAttr,
		"client":{
			name:"client",showName:(($ln==="CN")?("客户端"):/*EN*/("Client")),type:"auto",key:1,fixed:1,initValText:"#context.aaeClient",initVal:null
		},
		"target":{
			name:"target",showName:(($ln==="CN")?("目标元素 AAEId"):/*EN*/("Node AAEId")),type:"string",key:1,fixed:1,initVal:""
		},
		"action":{
			name:"action",showName:(($ln==="CN")?("操作"):/*EN*/("Action")),type:"choice",key:1,fixed:1,initVal:"click",rawEdit:false,
			vals:[
				["click","Click","Click element"],
				["writeClipboard","writeClipboard","Set clipboard text"],
				["fill","Fill","Fill input"],
				["clickTip","ClickTip","Notify to click element"],
				["pasteTip","PasteTip","Notify to paste content"],
			],valueType:"string"
		},
		"content":{
			name:"content",showName:(($ln==="CN")?("填充内容"):/*EN*/("Conent")),type:"string",key:1,fixed:1,initVal:""
		},
		"tip":{
			name:"content",showName:(($ln==="CN")?("操作提示"):/*EN*/("Action tip")),type:"string",key:1,fixed:1,initVal:""
		},
		"outlet":{
			name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
		},
	},
	listHint:[
		"id","mkpInput","client","target","action","content","tip","codes","context","global","desc",
	],
	importSource:{path:"/@aae",name:"AAE"},
});

DocAIAgentExporter.segTypeExporters["sendAAEAction"]=
function(seg){
	let coder=this.coder;
	let segName=seg.idVal.val;
	let exportDebug=this.isExportDebug();
	let action=seg.getAttrVal("action");

	segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
	coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
	coder.indentMore();
	coder.newLine();
	{
		coder.maybeNewLine();
		coder.packText(`let result=null;`);coder.newLine();
		coder.packText(`let target=`);this.genAttrStatement(seg.getAttr("target"));coder.packText(`;`);coder.newLine();
		coder.packText(`let client=`);this.genAttrStatement(seg.getAttr("client"));coder.packText(`;`);coder.newLine();
		coder.packText(`let content=`);this.genAttrStatement(seg.getAttr("content"));coder.packText(`;`);coder.newLine();
		coder.packText(`target=target.AAEId||target`);coder.newLine();
		packExtraCodes(coder,seg,"PreCodes");
		switch(action){
			case "click":
				coder.packText(`result=await AAE.runAction(client,{AAEId:target,type:"event",event:"click"});`);coder.newLine();
				break;
			case "writeClipboard":
				coder.packText(`result=await AAE.runAction(client,{AAEId:target,type:"event",event:"writeClipboard",content:content});`);coder.newLine();
				break;
			case "fill":
				coder.packText(`result=await AAE.runAction(client,{AAEId:target,type:"event",event:"input",content:content});`);coder.newLine();
				break;
			case "clickTip":
				coder.packText(`result=await AAE.runAction(client,{AAEId:target,type:"tip",mode:"click",tip:content});`);coder.newLine();
				break;
			case "pasteTip":
				coder.packText(`result=await AAE.runAction(client,{AAEId:target,type:"tip",mode:"paste",tip:content});`);coder.newLine();
				break;
		}

		packExtraCodes(coder,seg,"PostCodes");
		packResult(coder,seg,seg.outlet,"result");
	}
	coder.indentLess();
	coder.newLine();
	coder.packText(`};`);
	coder.newLine();
	if(exportDebug){
		coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
	}
	coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
	//coder.packText(`${segName}.desc=`);this.genAttrStatement(seg.getAttr("desc"));coder.packText(`;`);coder.newLine();
	coder.newLine();
};

//----------------------------------------------------------------------------
//:AISeg that find tab:
EditAISeg.regDef({
	name:"findTabs",showName:(($ln==="CN")?("选择Tab"):/*EN*/("Select Tab")),icon:"/@aae/assets/findtab.svg",catalog:["AAE"],
	attrs:{
		...SegObjShellAttr,
		"url":{
			name:"url",showName:(($ln==="CN")?("查找URL"):/*EN*/("URL to find")),type:"string",key:1,fixed:1,initVal:"",
		},
		"title":{
			name:"title",showName:(($ln==="CN")?("查找标题"):/*EN*/("Title to find")),type:"string",key:1,fixed:1,initVal:"",
		},
		"one":{
			name:"one",showName:(($ln==="CN")?("仅需单个Tab"):/*EN*/("Only one tab needed")),type:"bool",key:1,fixed:1,initVal:true,rawEdit:false
		},
		"outlet":{
			name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
		},
	},
	listHint:[
		"id","mkpInput","url","title","one","codes","context","global","desc",
	],
	importSource:{path:"/@aae",name:"AAE"},
});

DocAIAgentExporter.segTypeExporters["findTabs"]=
function(seg){
	let coder=this.coder;
	let segName=seg.idVal.val;
	let exportDebug=this.isExportDebug();
	let oneTab=seg.getAttrVal("one");

	segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
	coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
	coder.indentMore();
	coder.newLine();
	{
		coder.maybeNewLine();
		coder.packText(`let result=null;`);coder.newLine();
		coder.packText(`let query={};`);coder.newLine();
		coder.packText(`let url=`);this.genAttrStatement(seg.getAttr("url"));coder.packText(`;`);coder.newLine();
		coder.packText(`let title=`);this.genAttrStatement(seg.getAttr("title"));coder.packText(`;`);coder.newLine();
		if(seg.getAttrValText("url")){
			coder.packText(`query.url=url;`);coder.newLine();
		}
		if(seg.getAttrValText("title")){
			coder.packText(`query.title=title;`);coder.newLine();
		}
		packExtraCodes(coder,seg,"PreCodes");
		coder.packText(`result=await AAE.findTabs(query);`);coder.newLine();
		if(oneTab){
			coder.packText(`result=result[0];`);coder.newLine();
		}
		packExtraCodes(coder,seg,"PostCodes");
		packResult(coder,seg,seg.outlet,"result");
	}
	coder.indentLess();
	coder.newLine();
	coder.packText(`};`);
	coder.newLine();
	if(exportDebug){
		coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
	}
	coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
	//coder.packText(`${segName}.desc=`);this.genAttrStatement(seg.getAttr("desc"));coder.packText(`;`);coder.newLine();
	coder.newLine();
};

//----------------------------------------------------------------------------
//:AISeg that select active tab:
EditAISeg.regDef({
	name:"activeTab",showName:(($ln==="CN")?("选择Tab"):/*EN*/("Select Tab")),icon:"picktab.svg",catalog:["AAE"],
	attrs:{
		...SegObjShellAttr,
		"client":{
			name:"client",showName:(($ln==="CN")?("客户端"):/*EN*/("Client")),type:"auto",key:1,fixed:1,initValText:"#context.aaeClient",initVal:null,
			info:"Empty client means active host tab."
		},
		"outlet":{
			name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
		},
	},
	listHint:[
		"id","mkpInput","client","codes","context","global","desc",
	],
	importSource:{path:"/@aae",name:"AAE"},
});

DocAIAgentExporter.segTypeExporters["activeTab"]=
function(seg){
	let coder=this.coder;
	let segName=seg.idVal.val;
	let exportDebug=this.isExportDebug();

	segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
	coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
	coder.indentMore();
	coder.newLine();
	{
		coder.maybeNewLine();
		coder.packText(`let result=null;`);coder.newLine();
		coder.packText(`let client=`);this.genAttrStatement(seg.getAttr("client"));coder.packText(`;`);coder.newLine();
		packExtraCodes(coder,seg,"PreCodes");
		coder.packText(`result=await AAE.activeTab(client);`);coder.newLine();
		packExtraCodes(coder,seg,"PostCodes");
		packResult(coder,seg,seg.outlet,"result");
	}
	coder.indentLess();
	coder.newLine();
	coder.packText(`};`);
	coder.newLine();
	if(exportDebug){
		coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
	}
	coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
	//coder.packText(`${segName}.desc=`);this.genAttrStatement(seg.getAttr("desc"));coder.packText(`;`);coder.newLine();
	coder.newLine();
};

//----------------------------------------------------------------------------
//:AISeg that run scripts on tab:
EditAISeg.regDef({
	name:"execScriptsOnTab",showName:(($ln==="CN")?("执行脚本"):/*EN*/("Run scripts")),icon:"/@aae/assets/tab_code.svg",catalog:["AAE"],
	attrs:{
		...SegObjShellAttr,
		"tabId":{
			name:"tabId",showName:(($ln==="CN")?("Tab Id"):/*EN*/("Tab Id")),type:"auto",key:1,fixed:1,initValText:"#input",initVal:"$$input$$",
		},
		"frameId":{
			name:"frameId",showName:(($ln==="CN")?("Frame Id"):/*EN*/("Frame Id")),type:"auto",key:0,fixed:1,initVal:"",
		},
		"files":{
			name:"files",showName:(($ln==="CN")?("脚本列表"):/*EN*/("Scripts")),type:"auto",key:1,fixed:1,initVal:["scripts/readPage.js","action/action.js"],
		},
		"outlet":{
			name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
		},
	},
	listHint:[
		"id","mkpInput","tabId","frameId","files","codes","context","global","desc",
	],
	importSource:{path:"/@aae",name:"AAE"},
});

DocAIAgentExporter.segTypeExporters["execScriptsOnTab"]=
function(seg){
	let coder=this.coder;
	let segName=seg.idVal.val;
	let exportDebug=this.isExportDebug();
	let frameIdAttr=seg.getAttr("frameId");

	segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
	coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
	coder.indentMore();
	coder.newLine();
	{
		coder.maybeNewLine();
		coder.packText(`let result=null;`);coder.newLine();
		coder.packText(`let files=`);this.genAttrStatement(seg.getAttr("files"));coder.packText(`;`);coder.newLine();
		coder.packText(`let tabId=`);this.genAttrStatement(seg.getAttr("tabId"));coder.packText(`;`);coder.newLine();
		if(frameIdAttr){
			coder.packText(`let frameId=`);this.genAttrStatement();coder.packText(`;`);coder.newLine();
		}else{
			coder.packText(`let frameId=undefined;`);coder.newLine();
		}
		packExtraCodes(coder,seg,"PreCodes");
		coder.packText(`result=await AAE.execScripts(files,tabId,frameId);`);coder.newLine();
		packExtraCodes(coder,seg,"PostCodes");
		packResult(coder,seg,seg.outlet,"result");
	}
	coder.indentLess();
	coder.newLine();
	coder.packText(`};`);
	coder.newLine();
	if(exportDebug){
		coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
	}
	coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
	//coder.packText(`${segName}.desc=`);this.genAttrStatement(seg.getAttr("desc"));coder.packText(`;`);coder.newLine();
	coder.newLine();
};

//----------------------------------------------------------------------------
//:AISeg that wait a user click:
EditAISeg.regDef({
	name:"waitClick",showName:(($ln==="CN")?("等待点击"):/*EN*/("Wait click")),icon:"/@aae/assets/wait_click.svg",catalog:["AAE"],
	attrs:{
		...SegObjShellAttr,
		"client":{
			name:"client",showName:(($ln==="CN")?("客户端"):/*EN*/("Client")),type:"auto",key:1,fixed:1,initValText:"#context.aaeClient",initVal:null,
			info:"Empty client means active host tab."
		},
		"target":{
			name:"target",showName:(($ln==="CN")?("目标元素"):/*EN*/("Target")),type:"auto",key:1,fixed:1,initVal:undefined,
			info:"Empty target means any element."
		},
		"outlet":{
			name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
		},
	},
	listHint:[
		"id","mkpInput","client","target","codes","context","global","desc",
	],
	importSource:{path:"/@aae",name:"AAE"},
});

DocAIAgentExporter.segTypeExporters["waitClick"]=
function(seg){
	let coder=this.coder;
	let segName=seg.idVal.val;
	let exportDebug=this.isExportDebug();

	segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
	coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
	coder.indentMore();
	coder.newLine();
	{
		coder.maybeNewLine();
		coder.packText(`let result=null;`);coder.newLine();
		coder.packText(`let pms=null;`);coder.newLine();
		coder.packText(`let resolve=null;`);coder.newLine();
		coder.packText(`let reject=null;`);coder.newLine();
		coder.packText(`let wid=null;`);coder.newLine();
		coder.packText(`let callback=null;`);coder.newLine();
		coder.packText(`let client=`);this.genAttrStatement(seg.getAttr("client"));coder.packText(`;`);coder.newLine();
		coder.packText(`let target=`);this.genAttrStatement(seg.getAttr("target"));coder.packText(`;`);coder.newLine();
		coder.packText(`target=target?(target.AAEId||target):null;`);coder.newLine();
		packExtraCodes(coder,seg,"PreCodes");
		coder.packText(`pms=new Promise((_resolve,_reject)=>{resolve=_resolve;reject=_reject;});`);coder.newLine();
		coder.packText(`callback=function(action){`);
		coder.indentMore();coder.newLine();
		{
			coder.packText(`if(target && action.target.AAEId===target && action.type==="event" && action.event==="click"){`);
			coder.indentMore();coder.newLine();
			{
				coder.beginDocObjTagBlcok(seg,"ExCheck");
				coder.endDocObjTagBlcok(seg,"ExCheck",0);
				coder.packText(`resolve(true);`);
			}
			coder.indentLess();coder.maybeNewLine();
			coder.packText(`}`);coder.maybeNewLine();
			coder.beginDocObjTagBlcok(seg,"FinCheck");
			coder.endDocObjTagBlcok(seg,"FinCheck",0);
		}
		coder.indentLess();coder.maybeNewLine();
		coder.packText(`}`);coder.maybeNewLine();
		coder.packText(`wid=await AAE.watchUserAction(client,callback);`);coder.newLine();
		coder.packText(`result=await pms;`);coder.newLine();
		coder.packText(`await AAE.cancelWatch(client,wid);`);coder.newLine();
		packExtraCodes(coder,seg,"PostCodes");
		packResult(coder,seg,seg.outlet,"result");
	}
	coder.indentLess();
	coder.newLine();
	coder.packText(`};`);
	coder.newLine();
	if(exportDebug){
		coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
	}
	coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
	//coder.packText(`${segName}.desc=`);this.genAttrStatement(seg.getAttr("desc"));coder.packText(`;`);coder.newLine();
	coder.newLine();
};

//----------------------------------------------------------------------------
//:AISeg that wait a user active a tab:
EditAISeg.regDef({
	name:"waitTabActive",showName:(($ln==="CN")?("等待切换Tab"):/*EN*/("Wait Tab")),icon:"/@aae/assets/wait_tab.svg",catalog:["AAE"],
	attrs:{
		...SegObjShellAttr,
		"outlet":{
			name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
		},
	},
	listHint:[
		"id","mkpInput","codes","context","global","desc",
	],
	importSource:{path:"/@aae",name:"AAE"},
});

DocAIAgentExporter.segTypeExporters["waitTabActive"]=
function(seg){
	let coder=this.coder;
	let segName=seg.idVal.val;
	let exportDebug=this.isExportDebug();

	segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
	coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
	coder.indentMore();
	coder.newLine();
	{
		coder.maybeNewLine();
		coder.packText(`let result=null;`);coder.newLine();
		packExtraCodes(coder,seg,"PreCodes");
		coder.packText(`result=await AAE.waitTabActive();`);coder.newLine();
		packExtraCodes(coder,seg,"PostCodes");
		packResult(coder,seg,seg.outlet,"result");
	}
	coder.indentLess();
	coder.newLine();
	coder.packText(`};`);
	coder.newLine();
	if(exportDebug){
		coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
	}
	coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
	//coder.packText(`${segName}.desc=`);this.genAttrStatement(seg.getAttr("desc"));coder.packText(`;`);coder.newLine();
	coder.newLine();
};

//----------------------------------------------------------------------------
//:AAE+>>AISeg that press key using AAE+
EditAISeg.regDef({
	name:"NativeKey",showName:(($ln==="CN")?("通过系统按键"):/*EN*/("Native Key Press")),icon:"keybtn.svg",catalog:["AAE+"],
	attrs:{
		...SegObjShellAttr,
		"client":{
			name:"client",showName:(($ln==="CN")?("页面"):/*EN*/("Client Page")),type:"auto",key:1,fixed:1,initValText:"#context.aaeClient",initVal:null,
		},
		"query":{
			name:"query",showName:(($ln==="CN")?("目标元素"):/*EN*/("Target Query")),type:"string",key:1,fixed:1,initVal:"",
		},
		"wait":{
			name:"wait",showName:(($ln==="CN")?("等待"):/*EN*/("Wait")),type:"int",key:1,fixed:1,initVal:500,
		},
		"action":{
			name:"action",showName:(($ln==="CN")?("操作"):/*EN*/("Action")),type:"choice",key:1,fixed:1,initVal:"paste",rawEdit:false,
			vals:[
				["paste","Paste","Paste"],
				["paste","Paste","Paste"],
				["enter","Enter","Press enter"],
				["key","Key","Press key"],
			],valueType:"string"
		},
		"content":{
			name:"content",showName:(($ln==="CN")?("内容"):/*EN*/("Content")),type:"string",key:1,fixed:1,initVal:"",
		},
		"delay":{
			name:"query",showName:(($ln==="CN")?("按键间隔(毫秒)"):/*EN*/("Press gap (ms)")),type:"int",key:1,fixed:1,initVal:0,
		},
		"outlet":{
			name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
		},
	},
	listHint:[
		"id","mkpInput","client","action","query","wait","content","delay","codes","context","global","desc",
	]
});

DocAIAgentExporter.segTypeExporters["NativeKey"]=
function(seg){
	let coder=this.coder;
	let segName=seg.idVal.val;
	let exportDebug=this.isExportDebug();
	let action=seg.getAttrVal("action");

	segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
	coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
	coder.indentMore();
	coder.newLine();
	{
		coder.maybeNewLine();
		coder.packText(`let arg,result=null;`);coder.newLine();
		coder.packText(`let client=`);this.genAttrStatement(seg.getAttr("client"));coder.packText(`;`);coder.newLine();
		coder.packText(`let query=`);this.genAttrStatement(seg.getAttr("query"));coder.packText(`;`);coder.newLine();
		coder.packText(`let wait=`);this.genAttrStatement(seg.getAttr("wait"));coder.packText(`;`);coder.newLine();
		coder.packText(`let content=`);this.genAttrStatement(seg.getAttr("content"));coder.packText(`;`);coder.newLine();
		packExtraCodes(coder,seg,"PreCodes");
		//coder.packText(`arg={action:"${action}",query:query, content:content, wait:wait, delay:delay};`);coder.newLine();
		//coder.packText(`result=await AAE.nativeAction(client,arg);`);coder.newLine();
		
		switch(action){
			case "paste":{
				if(seg.getAttrValText("content")){
					coder.packText(`content=`);this.genAttrStatement(seg.getAttr("content"));coder.packText(`;`);coder.newLine();
					coder.packText(`arg="paste/"+content;`);coder.newLine();
				}else{
					coder.packText(`arg="paste";`);coder.newLine();
				}
				break;
			}
			case "enter":{
				coder.packText(`arg="enter";`);coder.newLine();
				break;
			}
			case "key":{
				coder.packText(`arg="key/"+content;`);coder.newLine();
				break;
			}
		}
		coder.packText(`result=await session.pipeChat("/@aae/ai/presskey.js",arg,false);`);coder.newLine();
		packExtraCodes(coder,seg,"PostCodes");
		packResult(coder,seg,seg.outlet,"result");
	}
	coder.indentLess();
	coder.newLine();
	coder.packText(`};`);
	coder.newLine();
	if(exportDebug){
		coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
	}
	coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
	//coder.packText(`${segName}.desc=`);this.genAttrStatement(seg.getAttr("desc"));coder.packText(`;`);coder.newLine();
	coder.newLine();
};

//----------------------------------------------------------------------------
//:AAE+>>AISeg that perform native mouse actionusing AAE+
EditAISeg.regDef({
	name:"NativeMouse",showName:(($ln==="CN")?("鼠标动作"):/*EN*/("Mouse Action")),icon:"mouse.svg",catalog:["AAE+"],
	attrs:{
		...SegObjShellAttr,
		"client":{
			name:"client",showName:(($ln==="CN")?("页面"):/*EN*/("Client Page")),type:"auto",key:1,fixed:1,initValText:"#context.aaeClient",initVal:null,
		},
		"query":{
			name:"query",showName:(($ln==="CN")?("目标元素"):/*EN*/("Target Query")),type:"string",key:1,fixed:1,initVal:"",
		},
		"wait":{
			name:"wait",showName:(($ln==="CN")?("等待"):/*EN*/("Wait")),type:"int",key:1,fixed:1,initVal:500,
		},
		"action":{
			name:"action",showName:(($ln==="CN")?("操作"):/*EN*/("Action")),type:"choice",key:1,fixed:1,initVal:"init",rawEdit:false,
			vals:[
				["init","Init","Init"],
				["click","Click","Click"],
				["move","Move","Move"],
				["drag","Drag","Drag"],
			],valueType:"string"
		},
		"x1":{
			name:"x1",showName:(($ln==="CN")?("X坐标"):/*EN*/("Action X")),type:"number",key:1,fixed:1,initVal:0,
		},
		"y1":{
			name:"y1",showName:(($ln==="CN")?("Y坐标"):/*EN*/("Action Y")),type:"number",key:1,fixed:1,initVal:0,
		},
		"x2":{
			name:"x2",showName:(($ln==="CN")?("X坐标2"):/*EN*/("Action X2")),type:"number",key:1,fixed:1,initVal:0,
		},
		"y2":{
			name:"y2",showName:(($ln==="CN")?("Y坐标2"):/*EN*/("Action Y2")),type:"number",key:1,fixed:1,initVal:0,
		},
		"outlet":{
			name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
		},
	},
	listHint:[
		"id","mkpInput","client","query","action","wait","x1","y1","x2","y2","codes","context","global","desc",
	]
});

DocAIAgentExporter.segTypeExporters["NativeMouse"]=
function(seg){
	let coder=this.coder;
	let segName=seg.idVal.val;
	let exportDebug=this.isExportDebug();
	let action=seg.getAttrVal("action");

	segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
	coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
	coder.indentMore();
	coder.newLine();
	{
		coder.maybeNewLine();
		coder.packText(`let content,arg,result=null;`);coder.newLine();
		coder.packText(`let client=`);this.genAttrStatement(seg.getAttr("client"));coder.packText(`;`);coder.newLine();
		coder.packText(`let query=`);this.genAttrStatement(seg.getAttr("query"));coder.packText(`;`);coder.newLine();
		coder.packText(`let wait=`);this.genAttrStatement(seg.getAttr("wait"));coder.packText(`;`);coder.newLine();
		coder.packText(`let x=`);this.genAttrStatement(seg.getAttr("x1"));coder.packText(`;`);coder.newLine();
		coder.packText(`let y=`);this.genAttrStatement(seg.getAttr("y1"));coder.packText(`;`);coder.newLine();
		coder.packText(`let x2=`);this.genAttrStatement(seg.getAttr("x2"));coder.packText(`;`);coder.newLine();
		coder.packText(`let y2=`);this.genAttrStatement(seg.getAttr("y2"));coder.packText(`;`);coder.newLine();
		coder.packText(`let target=`);this.genAttrStatement(seg.getAttr("target"));coder.packText(`;`);coder.newLine();
		packExtraCodes(coder,seg,"PreCodes");
		//coder.packText(`arg={action:"${action}",query:query, content:content, wait:wait};`);coder.newLine();
		//coder.packText(`result=await AAE.nativeAction(client,arg);`);coder.newLine();
		switch(action){
			case "init":{
				coder.packText(`arg={action:"init"};`);coder.newLine();
				break;
			}
			case "click":{
				coder.packText(`arg={action:"click",x:x,y:y,target:target};`);coder.newLine();
				break;
			}
			case "move":{
				coder.packText(`arg={action:"move",x:x,y:y,target:target};`);coder.newLine();
				break;
			}
			case "drag":{
				coder.packText(`arg={action:"drag",x:x,y:y,x2:x2,y2:y2,target:target};`);coder.newLine();
				break;
			}
		}
		coder.packText(`result=await session.pipeChat("/@aae/ai/mouse.js",arg,false);`);coder.newLine();
		packExtraCodes(coder,seg,"PostCodes");
		packResult(coder,seg,seg.outlet,"result");
	}
	coder.indentLess();
	coder.newLine();
	coder.packText(`};`);
	coder.newLine();
	if(exportDebug){
		coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
	}
	coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
	//coder.packText(`${segName}.desc=`);this.genAttrStatement(seg.getAttr("desc"));coder.packText(`;`);coder.newLine();
	coder.newLine();
};

//----------------------------------------------------------------------------
//:AAE+>>AISeg that open a page to read content then close it
EditAISeg.regDef({
	name:"OpenAndReadPage",showName:(($ln==="CN")?("读取页面内容"):/*EN*/("Read Page")),icon:"read.svg",catalog:["AAE+"],
	attrs:{
		...SegObjShellAttr,
		"url":{
			name:"url",showName:(($ln==="CN")?("网页URL"):/*EN*/("Page URL")),type:"string",key:1,fixed:1,initVal:"",
		},
		"mode":{
			name:"mode",showName:(($ln==="CN")?("读取模式"):/*EN*/("Read mode")),type:"choice",key:1,fixed:1,initVal:"article",rawEdit:false,
			vals:[
				["article","Article","Article content"],
				["html","HTML","Page view html"],
			],valueType:"string"
		},
		"delay":{
			name:"delay",showName:(($ln==="CN")?("延迟时间"):/*EN*/("Read delay")),type:"int",key:1,fixed:1,initVal:500,
		},
		"maxContent":{
			name:"maxContent",showName:(($ln==="CN")?("文章最大尺寸"):/*EN*/("Max article size")),type:"int",key:1,fixed:1,initVal:50*1024,
		},
		"outlet":{
			name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc",
		},
	},
	listHint:[
		"id","mkpInput","url","mode","delay","maxContent","codes","context","global","desc",
	],
	importSource:{path:"/@aae",name:"AAE"},
});

DocAIAgentExporter.segTypeExporters["OpenAndReadPage"]=
function(seg){
	let coder=this.coder;
	let segName=seg.idVal.val;
	let exportDebug=this.isExportDebug();
	let action=seg.getAttrVal("action");

	segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
	coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
	coder.indentMore();
	coder.newLine();
	{
		coder.maybeNewLine();
		coder.packText(`let content,arg,result=null;`);coder.newLine();
		coder.packText(`let url=`);this.genAttrStatement(seg.getAttr("url"));coder.packText(`;`);coder.newLine();
		coder.packText(`let mode=`);this.genAttrStatement(seg.getAttr("mode"));coder.packText(`;`);coder.newLine();
		coder.packText(`let delay=`);this.genAttrStatement(seg.getAttr("delay"));coder.packText(`;`);coder.newLine();
		coder.packText(`let maxContent=`);this.genAttrStatement(seg.getAttr("maxContent"));coder.packText(`;`);coder.newLine();
		packExtraCodes(coder,seg,"PreCodes");
		coder.packText(`arg={url,mode,delay,maxContent};`);coder.newLine();
		coder.packText(`result=await session.pipeChat("/@aae/ai/readpage.js",arg,false);`);coder.newLine();
		packExtraCodes(coder,seg,"PostCodes");
		packResult(coder,seg,seg.outlet,"result");
	}
	coder.indentLess();
	coder.newLine();
	coder.packText(`};`);
	coder.newLine();
	if(exportDebug){
		coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
	}
	coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
	//coder.packText(`${segName}.desc=`);this.genAttrStatement(seg.getAttr("desc"));coder.packText(`;`);coder.newLine();
	coder.newLine();
};
