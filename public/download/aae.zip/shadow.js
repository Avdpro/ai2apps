//Auto genterated by Cody
import {tabOS,tabFS,tabTask} from "/@tabos";
import {VFACT} from "/@vfact";
import {} from "/@vfact/vfact_app.js";
import{appCfg} from "./cfg/appCfg.js";
/*#{MoreImports*/
import {AppLib} from "/@homekit/data/AppLib.js";
import pathLib from "/@path";
import {UIShadowApp} from "./ui/UIShadowApp.js";
import {DlgTask} from "/@homekit/ui/DlgTask.js";
/*}#MoreImports*/
VFACT.appCfg=appCfg;
/*#{StartApp*/
/*}#StartApp*/
//----------------------------------------------------------------------------
//Start the app:
async function startApp() {
	/*#{AppCode*/
	let app,uiDef;
	//监控虚拟键盘弹出
	{
		let originalHeight = window.visualViewport?.height || window.innerHeight;

		function checkKeyboard() {
			const currentHeight = window.visualViewport?.height || window.innerHeight;
			const fullHeight = window.innerHeight; // 理论上未缩小时的高度

			const heightDiff = fullHeight - currentHeight;

			if (heightDiff > 100) {
				app?.emit("DeviceKeyboardUp",heightDiff,currentHeight,fullHeight);
			} else {
				app?.emit("DeviceKeyboardDown",fullHeight);
			}
		}

		if (window.visualViewport) {
			window.visualViewport.addEventListener("resize", checkKeyboard);
		} else {
			window.addEventListener("resize", checkKeyboard); // fallback
		}

		// 初始化时记录真实高度（适配安卓）
		window.addEventListener("load", () => {
			originalHeight = window.visualViewport?.height || window.innerHeight;
		});
	}
	document.title="AI2Apps";
	//------------------------------------------------------------------------
	//Check if we are in appFrame:
	let appFrame=null;
	//CheckAppFrame:
	{
		let pw;
		appFrame=null;
		pw=window.parent;
		if(pw!==window){
			if(pw.getAppFrame){
				appFrame=window.appFrame=pw.getAppFrame(window);
			}
		}
	}
	window.tabOSApp=app=await VFACT.createApp();
	
	//setup open (openPath, openMeta...) API:
	await AppLib.setupOpenAPI(app,appFrame);
	
	uiDef=UIShadowApp(app,appFrame);
	if(!appFrame){
		//uiDef=AppLib.setupMiniDocker(app,uiDef);
	}
	//init app, create app UI tree:
	await VFACT.initApp(app,uiDef,{
		wait:1,
		shortcuts:appCfg.shortcuts,
		DlgTask:DlgTask,
		appFrame:appFrame,
	});
	/*}#AppCode*/
}
tabOS.setup().then(()=>{startApp();});
/*#{EndDoc*/
/*}#EndDoc*/
