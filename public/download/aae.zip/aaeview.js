//----------------------------------------------------------------------------
function aaeNode2DOM=function(aaeNode,onlyVisible=true){
	let domNode,attrs,rect,key,children,sub,subDomNode;
	if(aaeNode.nodeType===3){
		domNode=document.createTextNode(aaeNode.text);
		return domNode;
	}
	if(aaeNode.tagName){
		domNode=document.createElement(aaeNode.tagName);
		attrs=aaeNode.attrs;
		if(attrs){
			for(key in attrs){
				domNode.setAttribute(key,attrs[key]);
			}
		}else{
			if(aaeNode.AAEDId){
				domNode.setAttribute("aaeid",aaeNode.AAEDId);
			}
		}
	}
	rect=aaeNode.rect;
	if(rect){
		domNode.setAttribute("aae-rect",`x=${rect.x};y=${rect.y};width=${rect.width};height=${rect.height}`);
	}
	children=aaeNode.children;
	for(sub of children){
		if(onlyVisible && (!sub.rect)){
			continue;
		}
		subDomNode=aaeNode2DOM(sub,onlyVisible);
		domNode.appendChild(subDomNode);
	}
	return domNode;
};

export {aaeNode2DOM};