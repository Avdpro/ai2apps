
const stdExcludeTags=new Set(["SCRIPPT","STYLE"]);
const stdExcludeTypes=new Set([4,7,8,11]);

//----------------------------------------------------------------------------
//Remove HTML Nodes of tag-types defined in excludes, from the node's tree:
function _excludeNodes(node,exTags,exTypes){
	let children,i,n,sub,nodeType,nodeTag;
	children=[...node.childNodes];
	n=children.length;
	for(i=0;i<n;i++){
		sub=children[i];
		nodeType=sub.nodeType;
		if(exTypes && exTypes.has(nodeType)){
			node.removeChild(sub);
		}else if(exTags){ 
			if(nodeType===1){
				nodeTag=sub.tagName;
				if(exTags && exTags.has(nodeTag)){
					node.removeChild(sub);
				}else if(nodeType!==3){
					_excludeNodes(sub,exTags,exTypes);
				}
			}else{
				_excludeNodes(sub,exTags,nodeTag);
			}
		}
	}
}
//----------------------------------------------------------------------------
function excludeNodes(rootNode,exTags,exTypes){
	if(exTags){
		if(exTags===true){
			exTags=stdExcludeTags;
		}else if(!(exTags instanceof Set)){
			if(Array.isArray(exTags)){
				exTags=new Set(exTags);
			}else if(typeof(exTags)==="string"){
				exTags=exTags.toUpperCase().split(",");
				exTags=new Set(exTags);
			}else{
				exTags=null;
			}
		}
	}
	if(exTypes){
		if(exTypes===true){
			exTypes=stdExcludeTypes;
		}else if(!(exTypes instanceof Set)){
			if(Array.isArray(exTypes)){
				exTypes=new Set(exTypes);
			}else if(typeof(exTypes)==="string"){
				exTypes=exTypes.toUpperCase().split(",");
				exTypes=exTypes.map((item)=>{
					return parseInt(item);
				});
				exTypes=new Set(exTypes);
			}else{
				exTypes=null;
			}
		}
	}
	_excludeNodes(rootNode,exTags,exTypes);
}

//----------------------------------------------------------------------------
function shortNodesText(node,maxLen=20){
	let children,i,n,sub,nodeType,text;
	children=[...node.childNodes];
	n=children.length;
	for(i=0;i<n;i++){
		sub=children[i];
		nodeType=sub.nodeType;
		if(nodeType===3){
			text=""+sub.nodeValue;
			if(text.length>maxLen+3){
				sub.nodeValue=text.substring(0,maxLen)+"...";
			}
		}else if(nodeType===1){
			shortNodesText(sub,maxLen);
		}
	}
}

//----------------------------------------------------------------------------
function removeAttributes(node,attrs,tree){
	let attr,children,i,n,sub;
	if(node.removeAttribute){
		for(attr of attrs){
			node.removeAttribute(attr);
		}
	}
	if(!tree){
		return;
	}
	children=node.childNodes;
	n=children.length;
	for(i=0;i<n;i++){
		sub=children[i];
		removeAttributes(sub,attrs,true);
	}
};

//----------------------------------------------------------------------------
function removeHiddenNodes(node){
	let children,i,n,sub,nodeType,nodeTag,rect,style;
	children=node.childNodes;
	n=children.length;
	for(i=0;i<n;i++){
		sub=children[i];
		removeHiddenNodes(sub);
		nodeType=sub.nodeType;
		if(nodeType===1){
			nodeTag=sub.tagName;
			rect=sub.getAttribute("aaerect");
			style=sub.getAttribute("aaestyle");
			if(style){
				try{
					style=JSON.parse(style);
				}catch(err){
					style=null;
				}
			}
			if(rect){
				try{
					rect=JSON.parse(`[${rect}]`);
					rect={x:rect[0]||0,y:rect[1]||0,width:rect[2]||0,height:rect[3]||0}
				}catch(err){
					rect=null;
				}
			}
			style=style||{};
			rect=rect||{x:0,y:0,width:0,height:0};
			//Condition 1, alpha=0 or display=none
			if(style.opacity==="0" || style.display==="none"){
				node.removeChild(sub);
				n--;i--;
				continue;
			}
			//Condition 2: no offset parent:
			if(style.position!=="fixed" && !style.offsetParent){
				node.removeChild(sub);
				n--;i--;
				continue;
			}
			//Condition 3: size<1 and clip subs:
			if(rect.width<=1 || rect.height<=1){
				if(style.overflow==="hidden"||style.overflow==="clip"){
					node.removeChild(sub);
					n--;i--;
					continue;
				}
			}
		}
	}
}

//----------------------------------------------------------------------------
function mergeNodeTree(node){
	let children,i,n,sub,nodeType,nodeTag,subSubs,subTop,rect;
	children=node.childNodes;
	n=children.length;
	for(i=0;i<n;i++){
		sub=children[i];
		mergeNodeTree(sub);
		nodeType=sub.nodeType;
		rect=sub.getAttribute("aaerect");
		if(nodeType===1 && sub.tagName==="DIV" && rect){
			subSubs=sub.childNodes;
			if(subSubs.length===1){
				subTop=subSubs[0];
				if(subTop.nodeType===1 && subTop.tagName==="DIV"){
					rect=subTop.getAttribute("aaerect");
					if(rect){
						node.insertBefore(subTop,sub);
						node.removeChild(sub);
					}
				}
			}
		}
	}
};

//----------------------------------------------------------------------------
function cleanNodeMarks(node){
	let children,i,n,sub;
	children=node.childNodes;
	n=children.length;
	for(i=0;i<n;i++){
		sub=children[i];
		cleanNodeMarks(sub);
	}
	if(node.removeAttribute){
		node.removeAttribute("aaerect");
		node.removeAttribute("aaestyle");
	}
};

//----------------------------------------------------------------------------
function filterNodes(node,filter){
	let children,i,n,sub,nodeType,nodeTag;
	children=node.childNodes;
	n=children.length;
	for(i=0;i<n;i++){
		sub=children[i];
		if(filter(sub)===false){
			node.removeChild(sub);
			n--;i--;
		}
	}
}

const ReadView={
	excludeNodes,
	removeHiddenNodes,
	mergeNodeTree,
	filterNodes,
	cleanNodeMarks,
	removeAttributes,
	shortNodesText
};

export default ReadView;