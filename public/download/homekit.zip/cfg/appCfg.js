//Auto genterated by Cody
import {VFACT} from "/@vfact";
/*#{Imports*/
/*}#Imports*/
var cfgURL=import.meta.url+"1G8FNJVFK0;"
/*#{StartDoc*/
if(VFACT.lanCode===null){
	let userLanguages = navigator.languages || [navigator.language || navigator.userLanguage];
	let userLanguage = userLanguages[0];
	let languageCode = userLanguage.substring(0, 2).toUpperCase();
	switch(languageCode){
		case "ZH":
			languageCode="CN";
			break;
	}
	VFACT.lanCode=languageCode;
}
/*}#StartDoc*/
let darkMode=false;
let colors={
	"primary":[13,110,253,1],"secondary":[108,117,125,1],"success":[0,128,0,1],"warning":[255,128,12,1],"error":[240,0,0,1],"disable":[200,200,200,1],"tool":[240,240,240,1]
};
darkMode=VFACT.darkMode===null?darkMode:VFACT.darkMode;
VFACT.darkMode=darkMode;
if(!window.codyAppCfgs){
	window.codyAppCfgs={};
}
/*#{StartObj*/
/*}#StartObj*/
//----------------------------------------------------------------------------
let appCfg=window.codyAppCfgs[cfgURL]||{//"jaxId":"1G8FNJVFK2"
	"darkMode":darkMode,"version":"0.0.1",
	"txtSize":{
		"small":12,"smallMid":14,"mid":16,"smallBig":18,"big":20,"smallLarge":24,"large":28,"smallLarger":32,"larger":36,"smallHuge":42,"huge":48,"bigHuge":56,
		"smallHuger":64,"huger":72,"bigHuger":80
	},
	"size":{
		"menuLineH":24,"pathLineH":24,"dockerW":90,"dockerWMini":50,"dlgHeaderH":20
	},
	"color":{
		"body":[255,255,255,1],"primary":colors.primary,"fontPrimary":[255,255,255,1],"fontPrimarySub":[...colors.primary,80],"fontPrimaryLit":[...colors.primary,50],
		"secondary":colors.secondary,"fontSecondary":[255,255,255,1],"fontSecondarySub":[...colors.secondary,80],"fontSecondaryLit":[...colors.secondary,50],
		"fontBody":[0,0,0,1],"fontBodySub":[80,80,80,1],"fontBodyLit":[180,180,180,1],"lineBody":[0,0,0,1],"lineBodySub":[80,80,80,1],"lineBodyLit":[180,180,180,1],
		"success":colors.success,"fontSuccess":[255,255,255,1],"fontSuccessSub":[...colors.success,80],"fontSuccessLit":[...colors.success,50],"warning":colors.warning,
		"fontWarning":[255,255,255,1],"fontWarningSub":[...colors.warning,80],"fontWarningLit":[...colors.warning,50],"disable":colors.disable,"fontDisable":[255,255,255,1],
		"fontDisableSub":[...colors.disable,80],"fontDisableLit":[...colors.disable,50],"error":colors.error,"fontError":[255,255,255,1],"fontErrorSub":[...colors.error,80],
		"fontErrorLit":[...colors.error,50],"iconBtnOver":[...colors.primary,80],"iconBtnDown":[...colors.primary,60],"iconBtnUp":[255,255,255,0],"hot":[220,240,255,1],
		"iconFace":[50,50,50,1],"gntFocus":"linear-gradient(to right, rgba(190,220,2550,1), 50%, rgba(220,240,255,0.5))","gntSelected":"linear-gradient(to right, rgba(220,220,220,1), 50%, rgba(220,220,220,0.1))",
		"gntSelect":"linear-gradient(to right, rgba(220,220,220,1), 50%, rgba(220,220,220,0.1))","gntDlgHeader":"linear-gradient(to right, rgba(35,105,200,1), 60%, rgba(220,240,255,1.0), 95%, rgba(220,240,255,1.0))",
		"gntHotText":"linear-gradient(to right, rgba(190,220,255,0),rgba(190,220,255,1), rgba(190,220,255,1),rgba(220,240,255,0.0))","tool":colors.tool,"fontTool":[...colors.tool,-100],
		"fontToolSub":[...colors.tool,-60],"fontToolLit":[...colors.tool,-30],"gntLineBreak":"linear-gradient(to right, rgba(0,0,0,1),rgba(0,0,0,1), rgba(0,0,0,0))"
	},
	"sharedAssets":"/~/-tabos/shared/assets","assetsDir":"/@homekit/assets",
	"desktopColors":[
		[220,220,220,1],[50,100,160,1],[220,150,80,1],[50,110,55,1],[255,255,255,1]
	],
	"desktopColorIdx":0,
	"dockerColors":[
		[82,94,107,1],[147,52,77,1],[15,107,34,11]
	],
	"dockerColor":[82,94,107,1],
	/*#{ExAttrs*/
	/*}#ExAttrs*/
};
window.codyAppCfgs[cfgURL]=appCfg;
appCfg.lanCode=VFACT.lanCode===null?"EN":(VFACT.lanCode||"EN");
VFACT.lanCode=appCfg.lanCode;
if(!VFACT.appCfg){
	VFACT.appCfg=appCfg;
	window.jaxAppCfg=appCfg;
}
appCfg.applyCfg=function(){
	let majorCfg,attrName,cAttr,mAttr;
	majorCfg=VFACT.appCfg||window.jaxAppCfg;
	if(majorCfg && majorCfg!==appCfg){
		for(attrName in appCfg){
			if(attrName in majorCfg){
				cAttr=appCfg[attrName];
				mAttr=majorCfg[attrName];
				if(typeof(cAttr)==="object"){
					if(typeof(mAttr)==="object"){
						Object.assign(cAttr,mAttr);
					}
				}else if(attrName!=="applyCfg" && attrName!=="proxyCfg"){
					appCfg[attrName]=mAttr;
				}
			}
		}
	}
};
appCfg.proxyCfg=function(proxy){
	if(window.codyAppCfgs[cfgURL]===appCfg){
		window.codyAppCfgs[cfgURL]=proxy;
	}
	appCfg=proxy;
};

/*#{EndDoc*/
appCfg.getFileIcon=function(extName){
	return "/~/-tabos/shared/assets/filetype/file.svg";
};
/*}#EndDoc*/

export{appCfg};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "appCfg",
//	"jaxId": "1G8FNJVFK0",
//	"editVersion": 3,
//	"attrs": {
//		"localVars": {
//			"type": "object",
//			"jaxId": "1G8H0GUB50",
//			"editVersion": 9,
//			"attrs": {
//				"darkMode": "false",
//				"colors": {
//					"type": "object",
//					"def": "Object",
//					"jaxId": "1G8H0GUB51",
//					"editVersion": 18,
//					"attrs": {
//						"primary": {
//							"type": "colorRGBA",
//							"valText": "[13,110,253,1]"
//						},
//						"secondary": {
//							"type": "colorRGBA",
//							"valText": "[108,117,125,1]"
//						},
//						"success": {
//							"type": "colorRGBA",
//							"valText": "[0,128,0,1.00]"
//						},
//						"warning": {
//							"type": "colorRGBA",
//							"valText": "[255,128,12,1]"
//						},
//						"error": {
//							"type": "colorRGBA",
//							"valText": "[240,0,0,1.00]"
//						},
//						"disable": {
//							"type": "colorRGBA",
//							"valText": "[200,200,200,1.00]"
//						},
//						"tool": {
//							"type": "colorRGBA",
//							"valText": "[240,240,240,1.00]"
//						}
//					}
//				}
//			}
//		},
//		"editObjs": {
//			"type": "object",
//			"jaxId": "1G8FNJVFK1",
//			"editVersion": 1,
//			"attrs": {
//				"appCfg": {
//					"type": "object",
//					"jaxId": "1G8FNJVFK2",
//					"editVersion": 69,
//					"attrs": {
//						"darkMode": "#darkMode",
//						"version": "0.0.1",
//						"txtSize": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1G8FNJVFK3",
//							"editVersion": 30,
//							"attrs": {
//								"small": {
//									"type": "int",
//									"valText": "12"
//								},
//								"smallMid": {
//									"type": "int",
//									"valText": "14"
//								},
//								"mid": {
//									"type": "int",
//									"valText": "16"
//								},
//								"smallBig": {
//									"type": "int",
//									"valText": "18"
//								},
//								"big": {
//									"type": "int",
//									"valText": "20"
//								},
//								"smallLarge": {
//									"type": "int",
//									"valText": "24"
//								},
//								"large": {
//									"type": "int",
//									"valText": "28"
//								},
//								"smallLarger": {
//									"type": "int",
//									"valText": "32"
//								},
//								"larger": {
//									"type": "int",
//									"valText": "36"
//								},
//								"smallHuge": {
//									"type": "int",
//									"valText": "42"
//								},
//								"huge": {
//									"type": "int",
//									"valText": "48"
//								},
//								"bigHuge": {
//									"type": "int",
//									"valText": "56"
//								},
//								"smallHuger": {
//									"type": "int",
//									"valText": "64"
//								},
//								"huger": {
//									"type": "int",
//									"valText": "72"
//								},
//								"bigHuger": {
//									"type": "int",
//									"valText": "80"
//								}
//							}
//						},
//						"size": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1G8FNJVFK4",
//							"editVersion": 12,
//							"attrs": {
//								"menuLineH": {
//									"type": "int",
//									"valText": "24"
//								},
//								"pathLineH": {
//									"type": "int",
//									"valText": "24"
//								},
//								"dockerW": {
//									"type": "int",
//									"valText": "90"
//								},
//								"dockerWMini": {
//									"type": "int",
//									"valText": "50"
//								},
//								"dlgHeaderH": {
//									"type": "int",
//									"valText": "20"
//								}
//							}
//						},
//						"color": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1G8FNJVFK5",
//							"editVersion": 507,
//							"attrs": {
//								"body": {
//									"type": "colorRGBA",
//									"valText": "[255,255,255,1.00]"
//								},
//								"primary": {
//									"type": "colorRGBA",
//									"valText": "#colors.primary"
//								},
//								"fontPrimary": {
//									"type": "colorRGBA",
//									"valText": "[255,255,255,1]"
//								},
//								"fontPrimarySub": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.primary,80]"
//								},
//								"fontPrimaryLit": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.primary,50]"
//								},
//								"secondary": {
//									"type": "colorRGBA",
//									"valText": "#colors.secondary"
//								},
//								"fontSecondary": {
//									"type": "colorRGBA",
//									"valText": "[255,255,255,1]"
//								},
//								"fontSecondarySub": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.secondary,80]"
//								},
//								"fontSecondaryLit": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.secondary,50]"
//								},
//								"fontBody": {
//									"type": "colorRGBA",
//									"valText": "[0,0,0,1]"
//								},
//								"fontBodySub": {
//									"type": "colorRGBA",
//									"valText": "[80,80,80,1]"
//								},
//								"fontBodyLit": {
//									"type": "colorRGBA",
//									"valText": "[180,180,180,1]"
//								},
//								"lineBody": {
//									"type": "colorRGBA",
//									"valText": "[0,0,0,1.00]"
//								},
//								"lineBodySub": {
//									"type": "colorRGBA",
//									"valText": "[80,80,80,1.00]"
//								},
//								"lineBodyLit": {
//									"type": "colorRGBA",
//									"valText": "[180,180,180,1.00]"
//								},
//								"success": {
//									"type": "colorRGBA",
//									"valText": "#colors.success"
//								},
//								"fontSuccess": {
//									"type": "colorRGBA",
//									"valText": "[255,255,255,1]"
//								},
//								"fontSuccessSub": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.success,80]"
//								},
//								"fontSuccessLit": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.success,50]"
//								},
//								"warning": {
//									"type": "colorRGBA",
//									"valText": "#colors.warning"
//								},
//								"fontWarning": {
//									"type": "colorRGBA",
//									"valText": "[255,255,255,1]"
//								},
//								"fontWarningSub": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.warning,80]"
//								},
//								"fontWarningLit": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.warning,50]"
//								},
//								"disable": {
//									"type": "colorRGBA",
//									"valText": "#colors.disable"
//								},
//								"fontDisable": {
//									"type": "colorRGBA",
//									"valText": "[255,255,255,1.00]"
//								},
//								"fontDisableSub": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.disable,80]"
//								},
//								"fontDisableLit": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.disable,50]"
//								},
//								"error": {
//									"type": "colorRGBA",
//									"valText": "#colors.error"
//								},
//								"fontError": {
//									"type": "colorRGBA",
//									"valText": "[255,255,255,1.00]"
//								},
//								"fontErrorSub": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.error,80]"
//								},
//								"fontErrorLit": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.error,50]"
//								},
//								"iconBtnOver": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.primary,80]"
//								},
//								"iconBtnDown": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.primary,60]"
//								},
//								"iconBtnUp": {
//									"type": "colorRGBA",
//									"valText": "[255,255,255,0.0]"
//								},
//								"hot": {
//									"type": "colorRGBA",
//									"valText": "[220,240,255,1]"
//								},
//								"iconFace": {
//									"type": "colorRGBA",
//									"valText": "[50,50,50,1.00]"
//								},
//								"gntFocus": {
//									"type": "colorRGBA",
//									"valText": "linear-gradient(to right, rgba(190,220,2550,1), 50%, rgba(220,240,255,0.5))"
//								},
//								"gntSelected": {
//									"type": "colorRGBA",
//									"valText": "linear-gradient(to right, rgba(220,220,220,1), 50%, rgba(220,220,220,0.1))"
//								},
//								"gntSelect": {
//									"type": "colorRGBA",
//									"valText": "linear-gradient(to right, rgba(220,220,220,1), 50%, rgba(220,220,220,0.1))"
//								},
//								"gntDlgHeader": {
//									"type": "colorRGBA",
//									"valText": "linear-gradient(to right, rgba(35,105,200,1), 60%, rgba(220,240,255,1.0), 95%, rgba(220,240,255,1.0))"
//								},
//								"gntHotText": {
//									"type": "colorRGBA",
//									"valText": "linear-gradient(to right, rgba(190,220,255,0),rgba(190,220,255,1), rgba(190,220,255,1),rgba(220,240,255,0.0))"
//								},
//								"tool": {
//									"type": "colorRGBA",
//									"valText": "#colors.tool"
//								},
//								"fontTool": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.tool,-100]"
//								},
//								"fontToolSub": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.tool,-60]"
//								},
//								"fontToolLit": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.tool,-30]"
//								},
//								"gntLineBreak": {
//									"type": "colorRGBA",
//									"valText": "linear-gradient(to right, rgba(0,0,0,1),rgba(0,0,0,1), rgba(0,0,0,0))"
//								}
//							}
//						},
//						"sharedAssets": {
//							"type": "string",
//							"valText": "/~/-tabos/shared/assets"
//						},
//						"assetsDir": {
//							"type": "string",
//							"valText": "/@homekit/assets"
//						},
//						"desktopColors": {
//							"type": "array",
//							"def": "RGBAArray",
//							"attrs": [
//								{
//									"type": "colorRGBA",
//									"valText": "[220,220,220,1.00]"
//								},
//								{
//									"type": "colorRGBA",
//									"valText": "rgba(50,100,160,1.00)"
//								},
//								{
//									"type": "colorRGBA",
//									"valText": "rgba(220,150,80,1.00)"
//								},
//								{
//									"type": "colorRGBA",
//									"valText": "rgba(50,110,55,1.00)"
//								},
//								{
//									"type": "colorRGBA",
//									"valText": "[255,255,255,1.00]"
//								}
//							]
//						},
//						"desktopColorIdx": {
//							"type": "int",
//							"valText": "0"
//						},
//						"dockerColors": {
//							"type": "array",
//							"def": "RGBAArray",
//							"attrs": [
//								{
//									"type": "colorRGBA",
//									"valText": "[82, 94, 107,1]"
//								},
//								{
//									"type": "colorRGBA",
//									"valText": "[147,52,77,1]"
//								},
//								{
//									"type": "colorRGBA",
//									"valText": "[15,107,34,11]"
//								}
//							]
//						},
//						"dockerColor": {
//							"type": "colorRGBA",
//							"valText": "[82, 94, 107,1]"
//						}
//					}
//				}
//			}
//		}
//	}
//}