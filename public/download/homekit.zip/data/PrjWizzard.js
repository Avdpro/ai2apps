import {VFACT} from "/@vfact";
const $ln=VFACT.lanCode;

let wizzardDef=[
	{
		icon:"aichat.svg",
		title:{"EN":"AI Agent App","CN":"AI 代理应用"},
		info:{
			"EN":"Develop AI Agent applicaitons. Application will use VACT framework.",
			"CN":"开发AI代理应用程序。应用程序将使用VACT框架。"
		},
		subs:[
			{
				icon:"aichat.svg",
				title:{EN:"Simple AI Agent App",CN:"简单的AI Agent应用"},
				info:{
					EN:"AI Agent that just chat with user. Support both English and Chinese. User can send 'exit' to exit chat.",
					CN:"简单用户聊天的AI代理。支持英文和中文。用户可以发送'exit'退出聊天。"
				},
				diskId:"prj_aiagent@avdpro@me.com",
				editPrj:{
					"version": "1.0.0","indent": 4,
					"tabDocs": ["ai/agent.js","ui/MainUI.js","cfg/appCfg.js","app.html","app.js"],
					"liveDocs": ["cfg/appCfg.js","app.html","app.js","ui/MainUI.js","ai/agent.js"]
				}
			},
			{
				icon:"dummy.svg",
				title:{EN:"Empty AI Agent App",CN:"空白的AI Agent应用"},
				info:{
					EN:" Empty AI Agent.",
					CN:"空白的 AI Agent。"
				},
				diskId:"prj_ai_empty@avdpro@me.com",
				editPrj:{
					"version": "0.0.5","indent": 4,
					"tabDocs": ["ai/agent.js","ui/MainUI.js","cfg/appCfg.js","app.html","app.js"],
					"liveDocs": ["cfg/appCfg.js","app.html","app.js","ui/MainUI.js","ai/agent.js"]
				}
			},
			{
				icon:"menu.svg",
				title:{EN:"AI Agent App with Menu Interactive",CN:"使用菜单与用户交互的 AI Agent"},
				info:{
					EN:"AI Agent that interacts with users using a menu control. Enter 'menu' during the conversation to bring up the menu.",
					CN:"使用菜单控件与用户交互的 AI Agent。在对话的时候输入 menu 可叫出菜单。"
				},
				diskId:"prj_ai_menu@avdpro@me.com",
				editPrj:{
					"version": "1.0.0","indent": 4,
					"tabDocs": ["ai/agent.js","ai/api.js","ui/MainUI.js","cfg/appCfg.js","app.html","app.js"],
					"liveDocs": ["cfg/appCfg.js","app.html","app.js","ui/MainUI.js","ai/api.js","ai/agent.js"]
				}
			},
			{
				icon:"func.svg",
				title:{EN:"AI Agent App with API-Call",CN:"会调用API的 AI Agent"},
				info:{
					EN:"AI Agent that uses the function call mechanism of ChatGPT. By adding a function API, the Agent is able to know the current date and time.",
					CN:"使用ChatGPT的函数调用机制的 AI Agent。通过增加一个函数 API 使 Agent 能够知道当前的日期和时间。"
				},
				diskId:"prj_ai_api@avdpro@me.com",
				editPrj:{
					"version": "1.0.0","indent": 4,
					"tabDocs": ["ai/agent.js","ai/api.js","ui/MainUI.js","cfg/appCfg.js","app.html","app.js"],
					"liveDocs": ["cfg/appCfg.js","app.html","app.js","ui/MainUI.js","ai/api.js","ai/agent.js"]
				}
			},
			{
				icon:"memory.svg",
				title:{EN:"AI Agent App with Memory",CN:"具有记忆的 AI Agent"},
				info:{
					EN:"Generate memory content by extracting key points from the dialogue to support more rounds of conversation and significantly reduce the usage of tokens, saving costs.",
					CN:"通过提炼对话要点生成记忆内容来支持更多轮的对话，并大幅节省 token 的使用量，节省成本。"
				},
				diskId:"prj_ai_mem@avdpro@me.com",
				editPrj:{
					"version": "1.0.0","indent": 4,
					"tabDocs": ["ai/agent.js","ai/mem.js","ui/MainUI.js","cfg/appCfg.js","app.html","app.js"],
					"liveDocs": ["cfg/appCfg.js","app.html","app.js","ui/MainUI.js","ai/mem.js","ai/agent.js"]
				}
			},
			{
				icon:"db.svg",
				title:{EN:"AI Agent App with Knowledge Base",CN:"基于知识库的AI助理应用"},
				info:{
					EN:"Build and update the knowledge base by scanning the document directory, and select the documents that match the topic as the background knowledge for AI during conversations with users.",
					CN:"通过扫描文档目录建立、更新知识库，在与用户对话的时候，选择与话题匹配的文档作为AI的对话背景知识。"
				},
				diskId:"prj_ai_kb@avdpro@me.com",
				editPrj:{
					"version": "1.0.0","indent": 4,
					"tabDocs": ["ai/agent.js","ai/docinfo.js","ai/kb.js","ui/MainUI.js","cfg/appCfg.js","app.html","app.js"],
					"liveDocs": ["cfg/appCfg.js","app.html","app.js","ui/MainUI.js","ai/kb.js","ai/docinfo.js","ai/agent.js"]
				}
			},
			{
				icon:"rename.svg",
				title:{EN:"AI Agent App chating with Data-View",CN:"使用数据视图对话的 AI Agent"},
				info:{
					EN:"Using Data-View component gether data / information. Then chat with user based on the data.",
					CN:"使用数据视图收集信息，然后基于收集到的信息与用户对话。"
				},
				diskId:"prj_ai_dataview@avdpro@me.com",
				editPrj:{
					"version": "1.0.0","indent": 4,
					"tabDocs": ["data/AppData.js","ai/agent.js","ai/docinfo.js","ai/kb.js","ui/MainUI.js","cfg/appCfg.js","app.html","app.js"],
					"liveDocs": ["cfg/appCfg.js","app.html","app.js","ui/MainUI.js","ai/kb.js","ai/docinfo.js","data/AppData.js","ai/agent.js"]
				}
			},
			{
				icon:"hudimg.svg",
				title:{EN:"AI Agent draw and view image.",CN:"画图且识图的 AI Agent"},
				info:{
					EN:"AI draws a picture based on the user's prompts and then analyzes the picture to provide analysis results.",
					CN:"AI 根据用户的提示词绘制一幅图片，然后分析这幅图片给出分析结果。"
				},
				diskId:"prj_ai_draw@avdpro@me.com",
				editPrj:{
					"version": "1.0.0","indent": 4,
					"tabDocs": ["ai/agent.js","ai/docinfo.js","ai/kb.js","ui/MainUI.js","cfg/appCfg.js","app.html","app.js"],
					"liveDocs": ["cfg/appCfg.js","app.html","app.js","ui/MainUI.js","ai/kb.js","ai/docinfo.js","ai/agent.js"]
				}
			},
			{
				icon:"file.svg",
				title:{EN:"Chat with your PDF",CN:"基于PDF文件的对话AI"},
				info:{
					EN:"AI engages in a conversation with the user based on the specified content of the PDF document.",
					CN:"AI 根据指定的 PDF 文档内容与用户对话。"
				},
				diskId:"prj_ai_pdf@avdpro@me.com",
				editPrj:{
					"version": "1.0.0","indent": 4,
					"tabDocs": ["ai/agent.js","ui/MainUI.js","cfg/appCfg.js","app.html","app.js"],
					"liveDocs": ["cfg/appCfg.js","app.html","app.js","ui/MainUI.js","ai/agent.js"]
				}
			},
			{
				icon:"py.svg",
				title:{EN:"Agent project that call Python RAG API",CN:"调用使用 Python 编写的 RAG API 的工程。"},
				info:{
					EN:"Agent that call Python RAG API as knowledge base. Make sure you have the Python API server running.",
					CN:"调用 Python RAG API 作为知识库的 Agent。请确认 Python API 服务器 是可用的。"
				},
				diskId:"prj_ai_callpython@avdpro@me.com",
				editPrj:{
					"version": "1.0.0","indent": 4,
					"tabDocs": ["ai/agent.js","ui/MainUI.js","cfg/appCfg.js","app.html","app.js"],
					"liveDocs": ["cfg/appCfg.js","app.html","app.js","ui/MainUI.js","ai/agent.js"]
				}
			},
			{
				icon:"edit.svg",
				title:{EN:"AI-assisted writing of short stories",CN:"AI辅助撰写短文小说"},
				info:{
					EN:"AI writes short articles or novels based on user guidance. It provides a good user experience, powerful editing capabilities, and allows for accurate modifications to the written content.",
					CN:"AI 按照用户指导撰写短篇文章或者小说。拥有良好的用户交互体验，强大的编辑功能，可以对已撰写的文章进行准确的修改。"
				},
				diskId:"StoryWrite@avdpro@me.com",
				editPrj:{
					"version": "1.0.0","indent": 4,
					"tabDocs": ["ai/agent.js","ai/EditStory.js","ai/WriteSeg.js","ai/kb.js","ui/MainUI.js","cfg/appCfg.js","app.html","app.js"],
					"liveDocs": ["cfg/appCfg.js","app.html","app.js","ui/MainUI.js","ai/kb.js","ai/WriteSeg.js","ai/EditStory.js","ai/agent.js"]
				}
			},
			{
				icon:"labadd.svg",
				title:{EN:"Experimental: Creating AI Agent with AI",CN:"实验：由AI创建AI Agent应用"},
				info:{
					EN:"Experimental: Create an AI agent. In the agent editing canvas mode, press Cmd+J or Ctrl+J to launch the assistant for writing AI agents.",
					CN:"实验项目：用AI创建智能体。在智能体编辑画布模式下，按Cmd+J或者Ctrl+J，启动编写AI智能体的助手。"
				},
				diskId:"prj_ai_aab@avdpro@me.com",
				editPrj:{
					"version": "0.0.5","indent": 4,
					"tabDocs": ["ai/agent.js","ui/MainUI.js","cfg/appCfg.js","app.html","app.js"],
					"liveDocs": ["cfg/appCfg.js","app.html","app.js","ui/MainUI.js","ai/agent.js"]
				}
			},
			{
				icon:"find.svg",
				title:{EN:"AI Agent Helping Searching Web Pages",CN:"搜索网络助理"},
				info:{
					EN:"Incomming: Help users search for information on the web, help users summarize and generalize, and engage in conversations with users based on the information found.",
					CN:"即将推出：帮助用户通过网络搜索信息，帮助用户进行总结和归纳，并基于搜索到的信息与用户对话。"
				},
			},
			{
				icon:"faces.svg",
				title:{EN:"Customer Service Chatbot Framework",CN:"客服机器人框架"},
				info:{
					EN:"Incomming: Website/App chatbot that can interact with users, answer questions about the platform, and decide whether to transfer to human customer service based on the situation.",
					CN:"即将推出：网站/App的客服机器人，可以与用户对话，解答用户关于平台的问题，根据情况决定是否转为人工客服。"
				},
			},
			{
				icon:"game.svg",
				title:{EN:"AI RPG NPC",CN:"AI驱动的角色扮演游戏NPC"},
				info:{
					EN:"Incomming: NPC in role-playing games that updates the NPC's state through AI, drives NPC behavior, and can interact with users",
					CN:"即将推出：角色扮演游戏的NPC，通过AI更新NPC的状态，驱动NPC行为，并可以与用户对话"
				},
			},
		]
	},
	{
		icon:"aichat.svg",
		title:{"EN":"Python AI Agent (Experimental preview)","CN":"Python AI 代理 (实验预览)"},
		info:{
			"EN":"Develop AI Agent with Python. Sync dir with native-OS and agent will run in native-OS' terminal.",
			"CN":"用 Python 开发AI代理。将目录与本地操作系统目录同步。Agent 需要在本地操作系统的终端中运行。"
		},
		subs:[
			{
				icon:"dummy.svg",
				title:{EN:"Empty Pyhton AI Agent",CN:"空的 Python AI Agent"},
				info:{
					EN:"Empty Python agent project.",
					CN:"空白的 Python Agent 工程。"
				},
				diskId:"prj_py_empty@avdpro@me.com",
				editPrj:{
					"version": "1.0.0","indent": 4,
					"tabDocs": ["ai/agent.py"],
					"liveDocs": ["ai/agent.js"]
				}
			},
			{
				icon:"aichat.svg",
				title:{EN:"Pyhton AI Agent Playground",CN:"Python 的 AI Agent 实验"},
				info:{
					EN:"Python AI Agent that include several features you can config to test and learn Python AI Agent components.",
					CN:"一些用于测试和学习 Python Agent 的组件组合。"
				},
				diskId:"prj_py_play@avdpro@me.com",
				editPrj:{
					"version": "1.0.0","indent": 4,
					"tabDocs": ["ai/agent.py","ai/session.py","ai/main.py"],
					"liveDocs": ["ai/session.py","ai/main.py","ai/agent.js"]
				}
			},
			{
				icon:"db.svg",
				title:{EN:"Pyhton API Server",CN:"Python API 服务器"},
				info:{
					EN:"Pyhton API Server that provides API for AI2Apps server to call.",
					CN:"Python API 服务器。提供 API 函数供 AI2Apps 服务器调用。"
				},
				diskId:"prj_py_apiserver@avdpro@me.com",
				editPrj:{
					"version": "1.0.0","indent": 4,
					"tabDocs": ["ai/server.py","ai/rag.py"],
					"liveDocs": ["ai/rag.py","ai/server.js"]
				}
			},
		]
	},
	{
		icon:"aaelogo.svg",
		title:{"EN":"Container AI Agent (Experimental preview)","CN":"容器内 AI 智能体 (实验预览)"},
		info:{
			"EN":"Develop AI Agent runs in AI2Apps agent-container.",
			"CN":"开发在 AI2Apps 智能体容器内运行的 AI 智能体。"
		},
		subs:[
			{
				icon:"aaelogo.svg",
				title:{EN:"Web RPA agent",CN:"浏览器RPA智能体"},
				info:{
					EN:"AI Agent that control web browser to perform actions.",
					CN:"控制浏览器完成事物的AI智能体。"
				},
				diskId:"prj_webrpa@avdpro@me.com",
				editPrj:{
					"version": "1.0.0","indent": 4,
					"tabDocs": ["ai/agent.js"],
					"liveDocs": ["ai/agent.js"]
				}
			},
			{
				icon:"aaelogo.svg",
				title:{EN:"Browser Control Playground",CN:"浏览器控制试验田"},
				info:{
					EN:"AI Agent that control web browser to play with agent-container features.",
					CN:"在智能体容器内，控制浏览器的 AI 的实验智能体。"
				},
				diskId:"prj_aaf_empty@avdpro@me.com",
				editPrj:{
					"version": "1.0.0","indent": 4,
					"tabDocs": ["ai/agent.js"],
					"liveDocs": ["ai/agent.js"]
				}
			}
		]
	},
	{
		icon:"db.svg",
		title:{"EN":"Server API Handlers","CN":"服务器 API"},
		info:{
			"EN":"Server API handlers project.",
			"CN":"服务器端的API请求处理器。"
		},
		subs:[
			{
				icon:"db.svg",
				title:{EN:"Simple Handlers Project",CN:"简单的请求处理工程"},
				info:{
					EN:`Simple request handler that return a JSON object with a code and and info "hello".`,
					CN:`简单的服务器端请求处理器工程，返回一个 JSON 对象，其中包括一个 code 和 info: "hello"。`,
				},
				diskId:"prj_sv_handler@avdpro@me.com",
				editPrj:{
					"version": "1.0.0","indent": 4,
					"tabDocs": ["handlers/handler.js"],
					"liveDocs": ["handlers/handler.js"]
				}
			},
			{
				icon:"dummy.svg",
				title:{EN:"Empty Handlers Project",CN:"空的 Handlers 工程"},
				info:{
					EN:"Empty handlers project.",
					CN:"空白的服务器端请求处理器工程。"
				},
				diskId:"prj_sv_empty@avdpro@me.com",
				editPrj:{
					"version": "1.0.0","indent": 4,
					"tabDocs": ["handlers/handler.js"],
					"liveDocs": ["handlers/handler.js"]
				}
			},
		]
	},
	{
		icon:"web.svg",
		title:{"EN":"Web / SPA","CN":"Web网页或单页面App"},
		info:{
			"EN":"Develop web pages or single-page web applications for modern browsers based on the VFACT framework.",
			"CN":"基于VFACT框架开发适用于现代浏览器的Web网页或单页面Web应用。"
		},
		subs:[
			{
				icon:"web.svg",
				title:{EN:"Blank VFACT Web Page",CN:"空白VFACT页面"},
				info:{
					EN:"Blank web page, with greating and a VFACT data-binding-demo texts.",
					CN:"空白网页，包含一行打招呼的文本和一段演示VFACT数据绑定的文本。"
				},
				diskId:"prj_spa_empty@avdpro@me.com",
				editPrj:{
					"version": "1.0.0","indent": 4,
					"tabDocs": ["ui/MainUI.js","cfg/appCfg.js","app.html","app.js"],
					"liveDocs": ["cfg/appCfg.js","app.html","app.js","ui/MainUI.js"]
				}
			},
			{
				icon:"home.svg",
				title:{EN:"Home Page",CN:"主页"},
				info:{
					EN:"Orgnaztion/project homepage, including a top-navi-bar, simple contents and menu. Support 'Dark Mode' and two languages.",
					CN:"组织/项目主页，包含顶部导航条，简单内容和菜单。支持暗夜模式和两种语言切换。"
				},
				diskId:"prj_spa_m_home@avdpro@me.com",
				editPrj:{
					"version": "1.0.0","indent": 4,
					"tabDocs": ["ui/MainUI.js","cfg/appCfg.js","app.html","app.js"],
					"liveDocs": ["app.html","app.js","cfg/appCfg.js","ui/MainUI.js"]
				}
			},
			{
				icon:"user.svg",
				title:{EN:"Personal web page",CN:"个人页面"},
				info:{
					EN:"Personal web page.",
					CN:"个人页面"
				},
				diskId:"prj_spa_m_personal@avdpro@me.com",
				editPrj:{
					"version": "1.0.0","indent": 4,
					"tabDocs": ["ui/UIMobile.js","ui/UIDesktop.js","cfg/appCfg.js","app.html","app.js"],
					"liveDocs": ["cfg/appCfg.js","app.html","app.js","ui/UIMobile.js","ui/UIDesktop.js"]
				}
			},
			{
				icon:"tip.svg",
				title:{EN:"Intro Page",CN:"产品介绍"},
				info:{
					EN:"(Comming sooning...)Product introduce page, with scroll-interacting.",
					CN:"（即将到来）滑动展示的产品互动介绍页面。"
				},
			},
			{
				icon:"game.svg",
				title:{EN:"Game",CN:"游戏"},
				info:{
					EN:"(Comming sooning...)Web game utilize canvas and WebGL.",
					CN:"（即将到来）网页游戏, 使用Canvas和WebGL技术开发.",
				},
			},
			{
				icon:"lint.svg",
				title:{"EN":"Internal Tool","CN":"内部工具"},
				info:{
					"EN":"(Coming soon) Internal tool page for enterprises/teams used to inspect data and monitor status, etc.",
					"CN":"（即将到来）企业/团队内部工具，通常用来检视数据和运行状态等。"
				},
			}
		]
	},
	{
		icon:"app.svg",
		title:{"EN":"Application","CN":"应用程序"},
		info:{
			"EN":"Application runs in native OS or inside Tab-OS.",
			"CN":"在本机操作系统中运行或在Tab-OS中运行的应用程序。"
		},
		subs:[
			{
				icon:"phone.svg",
				title:{"EN":"Mobile App","CN":"移动应用程序"},
				info:{
					"EN":"App will run in mobile devices.",
					"CN":"应用以移动设备作为运行目标。"
				},
				subs:[
					{
						icon:"phone.svg",
						title:{"EN":"Blank App","CN":"空白应用"},
						info:{
							"EN":"Blank app with hello world and data-binding-demo texts.",
							"CN":"空白应用，有一段问候文字和一段演示数据绑定机制的文字。"
						},
						diskId:"prj_app_m_empty@avdpro@me.com",
						editPrj:{
							"version": "1.0.0","indent": 4,
							"tabDocs": ["ui/MainUI.js","cfg/appCfg.js","app.html","app.js"],
							"liveDocs": ["cfg/appCfg.js","app.html","app.js","ui/MainUI.js"]
						}
					},
					{
						icon:"app.svg",
						title:{"EN":"Bottom Navigation App","CN":"底部导航应用"},
						info:{
							"EN":"Application with a bottom navi-bar. Support two languages and dark mode.",
							"CN":"带有底部导航栏的应用程序。支持两种语言和暗黑模式。"
						},
						diskId:"prj_app_m_tab@avdpro@me.com",
						editPrj:{
							"version": "1.0.0","indent": 4,
							"tabDocs": ["ui/MainUI.js","ui/UIAccount.js","cfg/appCfg.js","app.html","app.js"],
							"liveDocs": ["cfg/appCfg.js","app.html","app.js","ui/UIAccount.js","ui/MainUI.js"]
						}
					},
					{
						icon:"game.svg",
						title:{"EN":"Game","CN":"游戏"},
						info:{
							"EN":"(Incoming) Mobile game app via WebGL.",
							"CN":"(即将到来) 基于WebGL技术的移动游戏。"
						},
					},
					{
						icon:"lint.svg",
						title:{"EN":"Internal Tool","CN":"企业/团队内部工具。"},
						info:{
							"EN":"(Incoming...) Internal utility tool, with user login, data-dashboard",
							"CN":"（即将到来）企业/团队内部工具应用模版，包含用户登录和数据面板功能。"
						},
					},
				]
			},
			{
				icon:"cklogo.svg",
				title:{"EN":"Tab-OS App","CN":"Tab-OS专用应用程序"},
				info:{
					"EN":"Application for Tab-OS.",
					"CN":"以Tab-OS系统为目标的应用程序。"
				},
				subs:[
					{
						icon:"hudhud.svg",
						title:{"EN":"Blank Tab-OS App","CN":"空白的Tab-OS应用"},
						info:{
							"EN":"Blank Tab-OS App.",
							"CN":"空白的Tab-OS应用。"
						},
						diskId:"prj_app_t_empty@avdpro@me.com",
						editPrj:{
							"version": "1.0.0","indent": 4,
							"tabDocs": ["ui/MainUI.js","cfg/appCfg.js","app.html","app.js"],
							"liveDocs": ["cfg/appCfg.js","app.html","app.js","ui/MainUI.js"]
						}
					},
					{
						icon:"cklogo.svg",
						title:{"EN":"Tab-based application","CN":"分栏目的应用程序"},
						info:{
							"EN":"Tab-OS application that select different functions through tabs.",
							"CN":"通过栏目选择不同功能的Tab-OS应用程序。"
						},
					},
					{
						icon:"terminal.svg",
						title:{"EN":"Commamd Line Tool","CN":"命令行工具"},
						info:{
							"EN":"Command line app runs in Tab-OS terminal.",
							"CN":"在Tab-OS终端中运行的命令行应用程序。"
						},
						diskId:"prj_cmd@avdpro@me.com",
						editPrj:{
							"version": "1.0.0","indent": 4,
							"tabDocs": ["cmd.js","readme.md"],
							"liveDocs": ["readme.md","cmd.js"]
						}
					},
					{
						icon:"db.svg",
						title:{"EN":"REST Server","CN":"REST服务器"},
						info:{
							"EN":"Create a REST server that can be accessed via HTTP and uses JSON as the data request and response format. It can be used to simulate an actual server locally.",
							"CN":"建立一个通过HTTP访问的的REST服务器，使用JSON作为数据请求、应答格式。可以用来在本地模拟实际的服务器。"
						},
						diskId:"prj_api@avdpro@me.com",
						editPrj:{
							"version": "1.0.0","indent": 4,
							"tabDocs": ["readme.md","server.js","test.html"],
							"liveDocs": ["test.html","server.js","readme.md"]
						}
					},
					{
						icon:"gears.svg",
						title:{"EN":"Tab-OS IDE Add-On","CN":"Tab-OS开发工具IDE扩展"},
						info:{
							"EN":"(Incomming)Add-On running in Tab-OS IDE development tool, providing new features to the IDE.",
							"CN":"（即将推出）在Tab-OS的IDE开发工具中运行的插件，为IDE提供新的功能。"
						},
					},
				]
			},
			{
				icon:"desktop.svg",
				title:{"EN":"Desktop","CN":"桌面应用程序"},
				info:{
					"EN":"Application for desktop devices.",
					"CN":"以桌面系统为目标的应用程序。"
				},
				subs:[
					{
						icon:"desktop.svg",
						title:{"EN":"Blank native App","CN":"空白桌面应用"},
						info:{
							"EN":"Blank desktop app, with simple hello-world and data-binding-demo texts.",
							"CN":"空白桌面应用，有一段问候文字和一段演示数据绑定机制的文字。"
						},
						diskId:"prj_app_d_empty@avdpro@me.com",
						editPrj:{
							"version": "1.0.0","indent": 4,
							"tabDocs": ["ui/MainUI.js","cfg/appCfg.js","app.html","app.js"],
							"liveDocs": ["cfg/appCfg.js","app.html","app.js","ui/MainUI.js"]
						}
					},
					{
						icon:"app.svg",
						title:{
							"EN":"Documents App",
							"CN":"文档应用"
						},
						info:{
							"EN":"Simple app demo how to open, view and edit documents.",
							"CN":"包含打开、展示、编辑文档功能的简单桌面应用。"
						}
					},
					{
						icon:"game.svg",
						title:{"EN":"Game","CN":"游戏"},
						info:{
							"EN":"(Incoming...) Desktop webGL game.",
							"CN":"(即将到来)桌面WebGL游戏。"
						},
					},
					{
						icon:"lint.svg",
						title:{"EN":"Internal Tool","CN":"企业/团队内部工具"},
						info:{
							"EN":"(Incoming...) Internal utility tool, with user login, data-dashboard",
							"CN":"(即将到来)内部工具应用模版，包含用户登录和数据面板功能。"
						},
					},
				]
			},
		]
	},
	{
		icon:"./assets/prj/react.svg",
		title:{"EN":"Pages by Other Frameworks","CN":"其他框架制作的页面"},
		info:{
			"EN":"Web pages developed by other frameworks. Like: React, VUE, Bootstrap, etc.",
			"CN":"由其他框架开发的网页。比如：React，VUE，Bootstrap等等。"
		},
		subs:[
			{
				icon:"browser.svg",
				title:"HTML",
				info:{
					"EN":"Simple HTML webpage",
					"CN":"简单HTML网页"
				},
				diskId:"prj_html@avdpro@me.com",
				editPrj:{
					"version": "1.0.0","indent": 4,
					"tabDocs": ["index.html","style.css","code.js"],
					"liveDocs": ["code.js","style.css","index.html"]
				}
			},
			{
				icon:"./assets/prj/react.svg",
				title:"React",
				info:{
					"EN":"Web pages developed by React framework",
					"CN":"由React框架开发的网页"
				},
				subs:[
					{
						icon:"./assets/prj/react.svg",
						title:{"EN":"React Hello world","CN":"React 问候页面"},
						info:{
							"EN":"React page, with data-binding text.",
							"CN":"React页面，带有数据绑定文本。"
						},
						diskId:"prj_react@avdpro@me.com",
						editPrj:{
							"version": "1.0.0","indent": 4,
							"tabDocs": ["ui.js","app.js","dev.html","readme.md"],
							"liveDocs": ["readme.md","dev.html","app.js","ui.js"]
						}
					},
					{
						icon:"./assets/prj/react.svg",
						title:{"EN":"React HMR","CN":"React热更新"},
						info:{
							"EN":"(BETA)Develop React pages using HMR technology.",
							"CN":"（测试版）使用热更新技术开发React页面。"
						},
						diskId:"prj_reacthmr@avdpro@me.com",
						editPrj:{
							"version": "1.0.0","indent": 4,
							"tabDocs": ["readme.md","src/app.jsx","src/app.css","public/index.html"],
							"liveDocs": ["public/index.html","src/app.css","src/app.jsx","readme.md"]
						}
					},
					{
						icon:"faces.svg",
						title:{"EN":"Visual Faces React","CN":"可视化React"},
						info:{
							"EN":"(BETA)Develop React pages using WYSWYG IDE and support faces technology.",
							"CN":"（测试版）使用可视化IDE开发支持“表情”技术的React页面。"
						},
						diskId:"prj_vreact@avdpro@me.com",
						editPrj:{
							"version": "1.0.0","indent": 4,
							"tabDocs": ["readme.md","ui/MainUI.jsx","ui/BoxColor.jsx","app.js","app.html"],
							"liveDocs": ["app.html","app.js","ui/BoxColor.jsx","ui/MainUI.jsx","readme.md"]
						}
						
					},
				]
			},
			{
				icon:"./assets/prj/vue.svg",
				title:"VUE",
				info:{
					"EN":"(Comming soon) Web pages developed by VUE framework",
					"CN":"（即将到来）使用VUE框架开发的网页"
				},
			},
			{
				icon:"web.svg",
				title:"Bootstrap",
				info:{
					"EN":"(Comming soon) Web pages developed by Bootstrap 5 framework",
					"CN":"（即将到来）使用 Bootstrap 5 框架开发的网页"
				},
			},
		]
	},
];

export default wizzardDef;
export {wizzardDef};