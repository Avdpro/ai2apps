import {VFACT} from "/@vfact";
const $ln=VFACT.lanCode;

let wizzardDef=[
	{
		icon:"aichat.svg",
		title:{"EN":"AI Agent App (Experimental preview)","CN":"AI 代理应用 (实验预览)"},
		info:{
			"EN":"Develop AI Agent applicaitons. Application will use VACT framework.",
			"CN":"开发AI代理应用程序。应用程序将使用VACT框架。"
		},
		subs:[
			{
				icon:"aichat.svg",
				title:{EN:"Simple AI Agent app",CN:"简单的AI Agent应用"},
				info:{
					EN:"AI Agent that just chat with user. Support both English and Chinese. User can send 'exit' to exit chat.",
					CN:"简单用户聊天的AI代理。支持英文和中文。用户可以发送'exit'退出聊天。"
				},
				diskId:"prj_aiagent@avdpro@me.com",
				editPrj:{
					"version": "1.0.0","indent": 4,
					"tabDocs": ["ai/agent.js","ui/MainUI.js","cfg/appCfg.js","app.html","app.js"],
					"liveDocs": ["cfg/appCfg.js","app.html","app.js","ui/MainUI.js","ai/agent.js"]
				}
			},
			{
				icon:"help.svg",
				title:{EN:"AI Agent App with Knowledge Base",CN:"基于知识库的AI助理应用"},
				info:{
					EN:"Incomming: Build and update the knowledge base by scanning the document directory, and select the documents that match the topic as the background knowledge for AI during conversations with users.",
					CN:"即将推出：通过扫描文档目录建立、更新知识库，在与用户对话的时候，选择与话题匹配的文档作为AI的对话背景知识。"
				},
			},
			{
				icon:"find.svg",
				title:{EN:"AI Agent Helping Searching Web Pages",CN:"搜索网络助理"},
				info:{
					EN:"Incomming: Help users search for information on the web, help users summarize and generalize, and engage in conversations with users based on the information found.",
					CN:"即将推出：帮助用户通过网络搜索信息，帮助用户进行总结和归纳，并基于搜索到的信息与用户对话。"
				},
			},
			{
				icon:"faces.svg",
				title:{EN:"Customer Service Chatbot Framework",CN:"客服机器人框架"},
				info:{
					EN:"Incomming: Website/App chatbot that can interact with users, answer questions about the platform, and decide whether to transfer to human customer service based on the situation.",
					CN:"即将推出：网站/App的客服机器人，可以与用户对话，解答用户关于平台的问题，根据情况决定是否转为人工客服。"
				},
			},
			{
				icon:"game.svg",
				title:{EN:"AI RPG NPC",CN:"AI驱动的角色扮演游戏NPC"},
				info:{
					EN:"Incomming: NPC in role-playing games that updates the NPC's state through AI, drives NPC behavior, and can interact with users",
					CN:"即将推出：角色扮演游戏的NPC，通过AI更新NPC的状态，驱动NPC行为，并可以与用户对话"
				},
			},
		]
	},
	{
		icon:"web.svg",
		title:{"EN":"Web / SPA","CN":"Web网页或单页面App"},
		info:{
			"EN":"Develop web pages or single-page web applications for modern browsers based on the VFACT framework.",
			"CN":"基于VFACT框架开发适用于现代浏览器的Web网页或单页面Web应用。"
		},
		subs:[
			{
				icon:"web.svg",
				title:{EN:"Blank VFACT Web Page",CN:"空白VFACT页面"},
				info:{
					EN:"Blank web page, with greating and a VFACT data-binding-demo texts.",
					CN:"空白网页，包含一行打招呼的文本和一段演示VFACT数据绑定的文本。"
				},
				diskId:"prj_spa_empty@avdpro@me.com",
				editPrj:{
					"version": "1.0.0","indent": 4,
					"tabDocs": ["ui/MainUI.js","cfg/appCfg.js","app.html","app.js"],
					"liveDocs": ["cfg/appCfg.js","app.html","app.js","ui/MainUI.js"]
				}
			},
			{
				icon:"home.svg",
				title:{EN:"Home Page",CN:"主页"},
				info:{
					EN:"Orgnaztion/project homepage, including a top-navi-bar, simple contents and menu. Support 'Dark Mode' and two languages.",
					CN:"组织/项目主页，包含顶部导航条，简单内容和菜单。支持暗夜模式和两种语言切换。"
				},
				diskId:"prj_spa_m_home@avdpro@me.com",
				editPrj:{
					"version": "1.0.0","indent": 4,
					"tabDocs": ["ui/MainUI.js","cfg/appCfg.js","app.html","app.js"],
					"liveDocs": ["app.html","app.js","cfg/appCfg.js","ui/MainUI.js"]
				}
			},
			{
				icon:"user.svg",
				title:{EN:"Personal web page",CN:"个人页面"},
				info:{
					EN:"Personal web page.",
					CN:"个人页面"
				},
				diskId:"prj_spa_m_personal@avdpro@me.com",
				editPrj:{
					"version": "1.0.0","indent": 4,
					"tabDocs": ["ui/UIMobile.js","ui/UIDesktop.js","cfg/appCfg.js","app.html","app.js"],
					"liveDocs": ["cfg/appCfg.js","app.html","app.js","ui/UIMobile.js","ui/UIDesktop.js"]
				}
			},
			{
				icon:"tip.svg",
				title:{EN:"Intro Page",CN:"产品介绍"},
				info:{
					EN:"(Comming sooning...)Product introduce page, with scroll-interacting.",
					CN:"（即将到来）滑动展示的产品互动介绍页面。"
				},
			},
			{
				icon:"game.svg",
				title:{EN:"Game",CN:"游戏"},
				info:{
					EN:"(Comming sooning...)Web game utilize canvas and WebGL.",
					CN:"（即将到来）网页游戏, 使用Canvas和WebGL技术开发.",
				},
			},
			{
				icon:"lint.svg",
				title:{"EN":"Internal Tool","CN":"内部工具"},
				info:{
					"EN":"(Coming soon) Internal tool page for enterprises/teams used to inspect data and monitor status, etc.",
					"CN":"（即将到来）企业/团队内部工具，通常用来检视数据和运行状态等。"
				},
			}
		]
	},
	{
		icon:"app.svg",
		title:{"EN":"Application","CN":"应用程序"},
		info:{
			"EN":"Application runs in native OS or inside Tab-OS.",
			"CN":"在本机操作系统中运行或在Tab-OS中运行的应用程序。"
		},
		subs:[
			{
				icon:"phone.svg",
				title:{"EN":"Mobile App","CN":"移动应用程序"},
				info:{
					"EN":"App will run in mobile devices.",
					"CN":"应用以移动设备作为运行目标。"
				},
				subs:[
					{
						icon:"phone.svg",
						title:{"EN":"Blank App","CN":"空白应用"},
						info:{
							"EN":"Blank app with hello world and data-binding-demo texts.",
							"CN":"空白应用，有一段问候文字和一段演示数据绑定机制的文字。"
						},
						diskId:"prj_app_m_empty@avdpro@me.com",
						editPrj:{
							"version": "1.0.0","indent": 4,
							"tabDocs": ["ui/MainUI.js","cfg/appCfg.js","app.html","app.js"],
							"liveDocs": ["cfg/appCfg.js","app.html","app.js","ui/MainUI.js"]
						}
					},
					{
						icon:"app.svg",
						title:{"EN":"Bottom Navigation App","CN":"底部导航应用"},
						info:{
							"EN":"Application with a bottom navi-bar. Support two languages and dark mode.",
							"CN":"带有底部导航栏的应用程序。支持两种语言和暗黑模式。"
						},
						diskId:"prj_app_m_tab@avdpro@me.com",
						editPrj:{
							"version": "1.0.0","indent": 4,
							"tabDocs": ["ui/MainUI.js","ui/UIAccount.js","cfg/appCfg.js","app.html","app.js"],
							"liveDocs": ["cfg/appCfg.js","app.html","app.js","ui/UIAccount.js","ui/MainUI.js"]
						}
					},
					{
						icon:"game.svg",
						title:{"EN":"Game","CN":"游戏"},
						info:{
							"EN":"(Incoming) Mobile game app via WebGL.",
							"CN":"(即将到来) 基于WebGL技术的移动游戏。"
						},
					},
					{
						icon:"lint.svg",
						title:{"EN":"Internal Tool","CN":"企业/团队内部工具。"},
						info:{
							"EN":"(Incoming...) Internal utility tool, with user login, data-dashboard",
							"CN":"（即将到来）企业/团队内部工具应用模版，包含用户登录和数据面板功能。"
						},
					},
				]
			},
			{
				icon:"cklogo.svg",
				title:{"EN":"Tab-OS App","CN":"Tab-OS专用应用程序"},
				info:{
					"EN":"Application for Tab-OS.",
					"CN":"以Tab-OS系统为目标的应用程序。"
				},
				subs:[
					{
						icon:"hudhud.svg",
						title:{"EN":"Blank Tab-OS App","CN":"空白的Tab-OS应用"},
						info:{
							"EN":"Blank Tab-OS App.",
							"CN":"空白的Tab-OS应用。"
						},
						diskId:"prj_app_t_empty@avdpro@me.com",
						editPrj:{
							"version": "1.0.0","indent": 4,
							"tabDocs": ["ui/MainUI.js","cfg/appCfg.js","app.html","app.js"],
							"liveDocs": ["cfg/appCfg.js","app.html","app.js","ui/MainUI.js"]
						}
					},
					{
						icon:"cklogo.svg",
						title:{"EN":"Tab-based application","CN":"分栏目的应用程序"},
						info:{
							"EN":"Tab-OS application that select different functions through tabs.",
							"CN":"通过栏目选择不同功能的Tab-OS应用程序。"
						},
					},
					{
						icon:"terminal.svg",
						title:{"EN":"Commamd Line Tool","CN":"命令行工具"},
						info:{
							"EN":"Command line app runs in Tab-OS terminal.",
							"CN":"在Tab-OS终端中运行的命令行应用程序。"
						},
						diskId:"prj_cmd@avdpro@me.com",
						editPrj:{
							"version": "1.0.0","indent": 4,
							"tabDocs": ["cmd.js","readme.md"],
							"liveDocs": ["readme.md","cmd.js"]
						}
					},
					{
						icon:"db.svg",
						title:{"EN":"REST Server","CN":"REST服务器"},
						info:{
							"EN":"Create a REST server that can be accessed via HTTP and uses JSON as the data request and response format. It can be used to simulate an actual server locally.",
							"CN":"建立一个通过HTTP访问的的REST服务器，使用JSON作为数据请求、应答格式。可以用来在本地模拟实际的服务器。"
						},
						diskId:"prj_api@avdpro@me.com",
						editPrj:{
							"version": "1.0.0","indent": 4,
							"tabDocs": ["readme.md","server.js","test.html"],
							"liveDocs": ["test.html","server.js","readme.md"]
						}
					},
					{
						icon:"gears.svg",
						title:{"EN":"Tab-OS IDE Add-On","CN":"Tab-OS开发工具IDE扩展"},
						info:{
							"EN":"(Incomming)Add-On running in Tab-OS IDE development tool, providing new features to the IDE.",
							"CN":"（即将推出）在Tab-OS的IDE开发工具中运行的插件，为IDE提供新的功能。"
						},
					},
				]
			},
			{
				icon:"desktop.svg",
				title:{"EN":"Desktop","CN":"桌面应用程序"},
				info:{
					"EN":"Application for desktop devices.",
					"CN":"以桌面系统为目标的应用程序。"
				},
				subs:[
					{
						icon:"desktop.svg",
						title:{"EN":"Blank native App","CN":"空白桌面应用"},
						info:{
							"EN":"Blank desktop app, with simple hello-world and data-binding-demo texts.",
							"CN":"空白桌面应用，有一段问候文字和一段演示数据绑定机制的文字。"
						},
						diskId:"prj_app_d_empty@avdpro@me.com",
						editPrj:{
							"version": "1.0.0","indent": 4,
							"tabDocs": ["ui/MainUI.js","cfg/appCfg.js","app.html","app.js"],
							"liveDocs": ["cfg/appCfg.js","app.html","app.js","ui/MainUI.js"]
						}
					},
					{
						icon:"app.svg",
						title:{
							"EN":"Documents App",
							"CN":"文档应用"
						},
						info:{
							"EN":"Simple app demo how to open, view and edit documents.",
							"CN":"包含打开、展示、编辑文档功能的简单桌面应用。"
						}
					},
					{
						icon:"game.svg",
						title:{"EN":"Game","CN":"游戏"},
						info:{
							"EN":"(Incoming...) Desktop webGL game.",
							"CN":"(即将到来)桌面WebGL游戏。"
						},
					},
					{
						icon:"lint.svg",
						title:{"EN":"Internal Tool","CN":"企业/团队内部工具"},
						info:{
							"EN":"(Incoming...) Internal utility tool, with user login, data-dashboard",
							"CN":"(即将到来)内部工具应用模版，包含用户登录和数据面板功能。"
						},
					},
				]
			},
		]
	},
	{
		icon:"./assets/prj/react.svg",
		title:{"EN":"Pages by Other Frameworks","CN":"其他框架制作的页面"},
		info:{
			"EN":"Web pages developed by other frameworks. Like: React, VUE, Bootstrap, etc.",
			"CN":"由其他框架开发的网页。比如：React，VUE，Bootstrap等等。"
		},
		subs:[
			{
				icon:"browser.svg",
				title:"HTML",
				info:{
					"EN":"Simple HTML webpage",
					"CN":"简单HTML网页"
				},
				diskId:"prj_html@avdpro@me.com",
				editPrj:{
					"version": "1.0.0","indent": 4,
					"tabDocs": ["index.html","style.css","code.js"],
					"liveDocs": ["code.js","style.css","index.html"]
				}
			},
			{
				icon:"./assets/prj/react.svg",
				title:"React",
				info:{
					"EN":"Web pages developed by React framework",
					"CN":"由React框架开发的网页"
				},
				subs:[
					{
						icon:"./assets/prj/react.svg",
						title:{"EN":"React Hello world","CN":"React 问候页面"},
						info:{
							"EN":"React page, with data-binding text.",
							"CN":"React页面，带有数据绑定文本。"
						},
						diskId:"prj_react@avdpro@me.com",
						editPrj:{
							"version": "1.0.0","indent": 4,
							"tabDocs": ["ui.js","app.js","dev.html","readme.md"],
							"liveDocs": ["readme.md","dev.html","app.js","ui.js"]
						}
					},
					{
						icon:"./assets/prj/react.svg",
						title:{"EN":"React HMR","CN":"React热更新"},
						info:{
							"EN":"(BETA)Develop React pages using HMR technology.",
							"CN":"（测试版）使用热更新技术开发React页面。"
						},
						diskId:"prj_reacthmr@avdpro@me.com",
						editPrj:{
							"version": "1.0.0","indent": 4,
							"tabDocs": ["readme.md","src/app.jsx","src/app.css","public/index.html"],
							"liveDocs": ["public/index.html","src/app.css","src/app.jsx","readme.md"]
						}
					},
					{
						icon:"faces.svg",
						title:{"EN":"Visual Faces React","CN":"可视化React"},
						info:{
							"EN":"(BETA)Develop React pages using WYSWYG IDE and support faces technology.",
							"CN":"（测试版）使用可视化IDE开发支持“表情”技术的React页面。"
						},
						diskId:"prj_vreact@avdpro@me.com",
						editPrj:{
							"version": "1.0.0","indent": 4,
							"tabDocs": ["readme.md","ui/MainUI.jsx","ui/BoxColor.jsx","app.js","app.html"],
							"liveDocs": ["app.html","app.js","ui/BoxColor.jsx","ui/MainUI.jsx","readme.md"]
						}
						
					},
				]
			},
			{
				icon:"./assets/prj/vue.svg",
				title:"VUE",
				info:{
					"EN":"(Comming soon) Web pages developed by VUE framework",
					"CN":"（即将到来）使用VUE框架开发的网页"
				},
			},
			{
				icon:"web.svg",
				title:"Bootstrap",
				info:{
					"EN":"(Comming soon) Web pages developed by Bootstrap 5 framework",
					"CN":"（即将到来）使用 Bootstrap 5 框架开发的网页"
				},
			},
		]
	}
];

export default wizzardDef;
export {wizzardDef};