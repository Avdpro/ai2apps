//Auto genterated by Cody
import VFACT from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1G5TFHD9F0StartDoc*/
import {tabFS} from "/@tabos";
import pathLib from "/@path";
import {AppFrame} from "../ui/AppFrame.js";
import {UIDocker} from "../ui/UIDocker.js";
import {makeObjEventEmitter,makeNotify} from "/@events";
import {AATools} from "/@tabos/AATools.js";
//import {isPkgInstalled} from "/@pkg/pkgUtil.js";
const $ln=VFACT.lanCode;
/*}#1G5TFHD9F0StartDoc*/
//----------------------------------------------------------------------------
/*#{1G5TFI2350Constructor+*/
let AppLib=function(){
/*}#1G5TFI2350Constructor+*/
	/*#{1G5TFI2350PreConstruct*/
	/*}#1G5TFI2350PreConstruct*/
	/*#{1G5TFI2350Properties+*/
	this.appHash=new Map();;
	this.catalogs={};
	/*}#1G5TFI2350Properties+*/
	/*#{1G5TFI2350PostConstruct*/
	this.tools=null;
	this.toolsTime=0;
	this.toolMetaMap=new Map();
	this.fileHandles={
	"edit":{},
	"open":{},
	};
	/*}#1G5TFI2350PostConstruct*/
};
AppLib.prototype={};
let _AppLib=AppLib.prototype;
/*#{1G5TFI2350ExCodes*/
const APPSTATUS_READY="Ready";
const APPSTATUS_INSTALL="Install";

const APPMARK_INSTALL="Install";
const APPMARK_WEB="Web";
const APPMARK_LINK="Link";
const APPMARK_FULLPAGE="FullPage";
let appLib=_AppLib;
let DlgCloud=null;
//----------------------------------------------------------------------------
appLib.init=async function(){
	let dirs,dir,vo;
	//Scan installed disk-package for apps:
	//await this.scanApps();
	await this.ensureToolsVersion();
	return;
};

//----------------------------------------------------------------------------
appLib.scanAppDir=async function(dirName){
	let vo,defMeta;
	let path=`${document.location.origin}//${dirName}/app.config.js`;
	let mod=await import(path);
	let cfg=mod.default;
	defMeta=null;
	if(Array.isArray(cfg)){
		for(let sub of cfg){
			vo={...sub,status:APPSTATUS_READY};
			vo.path=path;
			this.regAppInfo(vo);
			if(!defMeta){
				defMeta=vo;
			}
		}
	}else if(cfg){
		vo={...cfg,status:APPSTATUS_READY};
		vo.path=path;
		this.regAppInfo(vo);
		defMeta=vo;
	}
	return defMeta;
};

//----------------------------------------------------------------------------
appLib.scanApps=async function(){
	//Do nothing now
};

//----------------------------------------------------------------------------
appLib.checkApps=async function(){
	let hash,name,appVO,res;
	hash=this.appHash;
	for(name in hash){
		appVO=hash[name];
		if(appVO.path){
			res=await fetch(appVO.path);
			if(!res.ok){
				//App is uninstalled?
			}
		}
	}
	//TODO: Code this:
};

//----------------------------------------------------------------------------
appLib.getAppMeta=function(name){
	return this.appHash[name];
};

//----------------------------------------------------------------------------
appLib.loadAppFeed=async function(){
	//TODO: Code this:
};


//----------------------------------------------------------------------------
appLib.loadAppInfo=async function(path){
	//TODO: Code this:
};

//----------------------------------------------------------------------------
appLib.regCatalog=function(vo){
	this.catalogs[vo.name]=vo;
	vo.apps=[];
};

//----------------------------------------------------------------------------
appLib.regAppMeta=function(appInfo,regName=""){
	let codeName,names,catalogName,catalog;
	let fileTypes,method,typeList,fileType,handleList,stub;
	if(appInfo.status===APPSTATUS_READY){
		if(appInfo.url){
			if(appInfo.appFrame){
				appInfo.mark=APPMARK_LINK;
			}else{
				appInfo.mark=APPMARK_WEB;
			}
		}else{
			if(appInfo.appFrame){
				//TODO: Mark as only home?
				appInfo.mark=null;
			}else{
				appInfo.mark=APPMARK_FULLPAGE;
			}
		}
	}else{
		appInfo.mark=APPMARK_INSTALL;
	}
	if(regName){
		codeName=regName;
	}else if(appInfo.package){
		codeName=appInfo.name+"@"+appInfo.package;
	}else{
		codeName=appInfo.name;
	}
	this.appHash[codeName]=appInfo;
	names=appInfo.catalog;
	if(names){
		if(!Array.isArray(names)){
			names=[names];
		}
		for(catalogName of names){
			catalog=this.catalogs[catalogName];
			if(!catalog){
				this.catalogs[catalogName]=catalog={
					name:catalogName,
					caption:catalogName,
					apps:[]
				};
			}
			catalog.apps[codeName]=appInfo;
		}
	}
	fileTypes=appInfo.acceptFileType;
	if(fileTypes){
		for(method in fileTypes){
			typeList=fileTypes[method];
			handleList=this.fileHandles[method];
			if(!handleList){
				handleList=this.fileHandles[method]={};
			}
			for(fileType of typeList){
				stub=handleList[fileType];
				if(!stub){
					stub=handleList[fileType]=[];
				}
				stub.push(appInfo.name+"@"+appInfo.package);
			}
		}
	}
};

//----------------------------------------------------------------------------
appLib.regAppInfo=async function(appInfo){
	this.regAppMeta(appInfo);
};

//----------------------------------------------------------------------------
appLib.ensureToolsVersion=async function(){
	let tools,tool,list,meta,tmMap,orgMeta;
	if(this.tools){
		let entry;
		entry=await tabFS.getEntry("/coke/ToolIndex.json");
		if(entry.modifyTime<this.toolsTime){
			return this.tools;
		}
	}
	tools=this.tools=new AATools();
	await this.tools.load();
	this.toolsTime=Date.now();

	//Update app metas:
	tmMap=this.toolMetaMap;
	list=tools.tools.values();
	for(tool of list){
		if(tool.type==="App" || tool.type==="Page"){
			meta=tmMap.get(tool.filePath);
			meta=tool.genAppMeta($ln,meta);
			if(meta){
				tmMap.set(tool.filePath,meta);
				if(tool.metaName){
					this.regAppMeta(meta,tool.metaName);
				}
			}
		}
	}
	
	//Update app catalog:
	{
		let group,catalog,grpName,subTools;
		list=tools.groups.values();
		for(group of list){
			grpName=group.getName();
			catalog=this.catalogs[grpName];
			if(!catalog){
				this.catalogs[grpName]=catalog={
					name:grpName,
					caption:grpName,
					apps:[]
				};
			}
			subTools=group.tools;
			for(tool of subTools){
				if(tool.appMeta){
					catalog.apps[tool.metaName||tool.filePath]=tool.appMeta;
				}
			}
		}
	}
	return this.tools;
};

//----------------------------------------------------------------------------
appLib.chooseFileHandler=function(fileName,method){
	let tools,tool;
	//tools=await this.ensureToolsVersion();
	tools=this.tools;
	tool=tools.getFileHandler(fileName,method);
	if(tool){
		return tool.appMeta;
	}
	return null;
};
/*}#1G5TFI2350ExCodes*/

let FavLib={
	name:"FavLib",//1G5VTG2EF0
	type:"object",
	label:undefined,
	properties:{
		/*#{1G5VTG2EF0MoreProperties*/
		/*}#1G5VTG2EF0MoreProperties*/
	},
	newObject(){return VFACT.newUITemplateObj(this)},
	/*#{1G5VTG2EF0MoreFunctions*/
	/*}#1G5VTG2EF0MoreFunctions*/
};
VFACT.regUITemplate("1G5VTG2EF0",FavLib);
VFACT.regUITemplate("FavLib",FavLib);
/*#{1G5VTG2EF0MoreCodes*/
/*}#1G5VTG2EF0MoreCodes*/

/*#{1G5TFHD9F0EndDoc*/
//----------------------------------------------------------------------------
//Setup app for open path/meata features:
AppLib.setupOpenAPI=async function(app,appFrame){
	if(appFrame){
		let parentApp;
		parentApp=appFrame.app;
		appFrame.appInFrame=app;
		//--------------------------------------------------------------------
		app.openPath=async function(path,method="open"){
			return await parentApp.openPath(path,method);
		};

		//--------------------------------------------------------------------
		//Open a meta's content, maybe app, web page, dir path or file
		app.openMeta=function(meta,param,evt){
			return parentApp.openMeta(meta,param,evt);
		};

		//--------------------------------------------------------------------
		//Open a appMeta:
		app.openAppMeta=function(meta,param,evt){
			return parentApp.openAppMeta(meta,param,evt);
		};

		//--------------------------------------------------------------------
		app.setTitle=function(text){
			appFrame.setTitle(text);
		};
		
		//--------------------------------------------------------------------
		app.closeApp=function(){
			appFrame.app.closeFrameApp(appFrame);
		};
	}else{
		let appLib;
		app.appLib=appLib=new AppLib();
		appLib.regCatalog({name:"Dev.",caption:{"EN":"Development","CN":"项目开发"}});
		appLib.regCatalog({name:"System",caption:{"EN":"System Tools","CN":"系统工具"}});
		appLib.regCatalog({name:"Utils",caption:{"EN":"Utilities","CN":"辅助工具"}});
		appLib.regCatalog({name:"Relaxing",caption:{"EN":"Relaxing","CN":"轻松一下"}});
		await appLib.init();

		//------------------------------------------------------------------------
		app.openPath=async function(path,method="open"){
			let ext,entry,meta;
			ext=pathLib.extname(path).toLowerCase();
			entry=await tabFS.getEntry(path);
			if(entry){
				if(entry.dir){
					//Open new Files app instance:
					meta=appLib.getAppMeta("Files@files");
					if(meta){
						app.newFrameApp(meta,`dir=${encodeURIComponent(path)}`);
					}
					return;
				}else{
					meta=appLib.chooseFileHandler(path,method);
					if(meta){
						let list,frame;
						//Check existed app can open this file?
						list=app.getAppFramesByMeta(meta);
						list.reverse();
						if(list){
							for(frame of list){
								if(frame.openFileInFrame && frame.openFileInFrame(path,method)){
									app.focusFrameApp(frame);
									return frame;
								}
							}
						}
						//Create a app for this file:
						frame=app.newFrameApp(meta,`file=${encodeURIComponent(path)}`);
						return;
					}
				}
				//Open file URL:
				switch(ext){
					case ".conflict":{
						let diskName,diskPath;
						[diskName,diskPath]=tabFS.parsePath(path);
						window.open(document.location.origin+"/@ccedit?disk="+encodeURIComponent(diskName)+"&file="+encodeURIComponent(diskPath),"CCEdit_"+diskName);
						break;
					}
					case ".svg":
					case ".html":
					default:						
						window.open(document.location.origin+"//"+path);
						break;
				}
			}else{
				meta=appLib.chooseFileHandler(path,method);
				if(meta){
					let list,frame;
					//Check existed app can open this file?
					list=app.getAppFramesByMeta(meta);
					list.reverse();
					if(list){
						for(frame of list){
							if(frame.openFileInFrame && frame.openFileInFrame(path,method)){
								app.focusFrameApp(frame);
								return frame;
							}
						}
					}
					//Create a app for this file:
					frame=app.newFrameApp(meta,`file=${encodeURIComponent(path)}`);
					return;
				}
			}
		};

		//------------------------------------------------------------------------
		//Open a meta's content, maybe app, web page, dir path or file
		app.openMeta=async function(meta,param,evt){
			let metaType;
			metaType=meta.type;
			switch(metaType){
				case "app":{
					app.openAppMeta(meta,param||"",evt);
					break;
				}
				case "path":{
					app.openPath(meta.path,"open");
					break;
				}
				case "weblink":{
					break;
				}
				case "install":{
					if(!DlgCloud){
						DlgCloud=(await import("../ui/DlgCloud.js")).DlgCloud;
					}
					app.showDlg(DlgCloud,{
						mode:"InstallPackage",
						autoInstall:true,
						package:meta.package
					});
					break;
				}
			}
		};
		
		async function isPkgInstalled(pkgName){
			let res;
			try{
				res=await fetch(`/@${pkgName}`);
				if(res.ok){
					return true;
				}
			}catch(err){
			}
			try{
				res=await fetch(`/~/-${pkgName}/disk.json`);
				if(res.ok){
					return true;
				}
			}catch(err){
			}
			return false;
		};

		//------------------------------------------------------------------------
		//Open a appMeta:
		app.openAppMeta=async function(meta,param,evt){
			let apFrmInf,pkgName,pkgVO;
			let list,frame;
			if(typeof(meta)==="string"){
				meta=appLib.getAppMeta(meta);
				if(!meta){
					return null;
				}
			}
			//Check existed app can open this file?
			list=app.getAppFramesByMeta(meta);
			list.reverse();
			if(list){
				for(frame of list){
					if(frame.openNewParam && frame.openNewParam(param)){
						app.focusFrameApp(frame);
						return frame;
					}
				}
			}
			//Will open a new instance of the App:
			pkgName=meta.package;
			if(pkgName && meta.checkInstall){
				//Check if package is instlled?
				pkgVO=await isPkgInstalled(pkgName);
				if(pkgVO){
					meta.checkInstall=false;
				}else{
					if(!DlgCloud){
						DlgCloud=(await import("../ui/DlgCloud.js")).DlgCloud;
					}
					app.showDlg(DlgCloud,{
						mode:"InstallPackage",
						package:pkgName,
						autoInstall:true,
						callback:function(){
							app.openAppMeta(meta,param,evt);
						}
					});
					return;
				}
			}
			apFrmInf=meta.appFrame;
			if(apFrmInf){
				//Open in home:
				if(apFrmInf.multiInstance===false){
					let frames=app.getAppFramesByMeta(meta);
					if(frames && frames[0]){
						app.focusAppFrame(frames[0]);
						return;
					}
				}
				return app.newFrameApp(meta,param);
			}else{
				//Open page:
				if(!evt || (!evt.ctrlKey&&!evt.shiftKey)){
					if(window.openTabOSAppPage){
						window.openTabOSAppPage(meta.main,`TabOS-${meta.name}-${Date.now()}`);
					}else{
						window.open(meta.main,`TabOS-${meta.name}-${Date.now()}`);
					}
				}else{
					if(window.openTabOSAppPage){
						window.openTabOSAppPage(meta.main);
					}else{
						window.open(meta.main);
					}
				}
			}
		};

		//--------------------------------------------------------------------
		app.setTitle=function(text){
			document.title=text;
		};
		
		//------------------------------------------------------------------------
		app.closeApp=function(){
			window.close();
		};
		
		//------------------------------------------------------------------------
		//Focus gain callback:
		window.addEventListener("focus",()=>{
			if(app.docker){
				app.docker.checkUpdate();
			}
		});
	}
};

//----------------------------------------------------------------------------
AppLib.setupMiniDocker=function(app,mainUI,hideDocker=true){
	let dockerUI;
	if(hideDocker){
		mainUI.x=5;mainUI.w="FW-5";
	}
	dockerUI=UIDocker(app,hideDocker);
	return [mainUI,dockerUI];
};

//----------------------------------------------------------------------------
AppLib.setupMobileDocker=async function(app,mainUI){
	let dockerUI;
	mainUI.x=0;mainUI.w="100%";
	mainUI.y=36;mainUI.h=">calc(100% - 36px)";
	dockerUI=(await import("../ui/UIMobile.js")).UIMobile;
	dockerUI=dockerUI(app);
	return [mainUI,dockerUI];
};

let newFrameX=120,newFrameY=100;
//----------------------------------------------------------------------------
//Setup the UI with docker for appFrame features:
AppLib.setupAppFramesAPI=function(app,isMini,autoHide=true){
	let appFrames=[];
	let boxHideAni=null;
	let boxHideIcon=null;
	let isShowAppFrame=isMini?0:1;
	let docker,dockerUI,boxApp,boxAni;
	
	dockerUI=app.dockerUI;
	docker=app.docker;
	boxApp=docker.appLayer;
	boxAni=docker.aniLayer;
	
	if(boxAni){
		let css={
			"id":"BoxHideAni","x":0,"y":0,"w":330,"h":193,"display":0,"type":"box","color":[255,255,255,0.3],"border":2,"borderStyle":1,
			"borderColor":[0,0,0,0.46],"coner":3,
			children:[{
				"id":"BoxHideIcon","x":"FW/2","y":"FH/2","w":100,"h":100,"anchorH":1,"anchorV":1,"autoLayout":true,"type":"box","color":[0,0,0,0.4],"border":1,
			}],
		};
		boxHideAni=boxAni.appendNewChild(css);
		boxHideIcon=boxHideAni.children[0];
	}
	
	//************************************************************************
	//MainUI/App functions for appFrames:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		app.newFrameApp=function(meta,param="",opts={}){
			let frame,x,y,w,h,topFrame,pos;
			if(typeof(meta)==="string"){
				meta=this.appLib.getAppMeta(meta);
				if(!meta){
					return null;
				}
			}
			//caculate pos:
			w=meta.appFrame.width||360;
			h=meta.appFrame.height||600;
			pos=opts.pos||meta.appFrame.pos;
			if(pos){
				if(pos instanceof Function){
					pos=pos(boxApp);
				}
				x=pos[0]||10;
				y=pos[1]||10;
				x+=docker.w;
			}else{
				x=newFrameX;y=newFrameY;
				newFrameX+=20;newFrameY+=20;
			}
			//adjust x,y based by width/height:
			if(x+w>app.clientW){
				newFrameX=x=100;
			}
			if(y+h>app.clientH){
				newFrameY=y=100;
			}
			//create frame:
			frame=boxApp.appendNewChild({
				type:AppFrame(app,meta,param),x:x,y:y
			});
			topFrame=appFrames[appFrames.length-1];
			if(topFrame){
				topFrame.blur();
				docker.blurLiveFrame(topFrame);
			}
			appFrames.push(frame);
			docker.addLiveFrame(frame);
			docker.focusLiveFrame(frame);
			if(!isShowAppFrame){
				app.showAppFrames();
			}
			return frame;
		};

		//--------------------------------------------------------------------
		app.closeFrameApp=function(frame){
			let idx,topFrame;
			idx=appFrames.indexOf(frame);
			if(idx<0){
				return;//Error?
			}
			docker.removeLiveFrame(frame);
			topFrame=appFrames[appFrames.length-1];
			appFrames.splice(idx,1);
			boxApp.removeChild(frame);
			if(topFrame===frame){
				topFrame=appFrames[appFrames.length-1];
				if(topFrame){
					topFrame.focus();
					app.focusFrameApp(topFrame);
				}else if(isMini){
					app.hideAppFrames();
				}
			}
		};

		//--------------------------------------------------------------------
		app.getAppFrames=function(){
			return [...appFrames];
		};
		
		//--------------------------------------------------------------------
		window.getAppFrame=
		app.getAppFrameByWindow=function(win){
			let i,n,af,frame;
			n=appFrames.length;
			for(i=0;i<n;i++){
				af=appFrames[i];
				frame=af.getPageFrame();
				if(frame && frame.contentWindow===win){
					return af;
				}
			}
			return null;
		};

		//--------------------------------------------------------------------
		app.getAppFramesByGroup=function(group){
			let i,n,af,frame,list;
			list=[];
			n=appFrames.length;
			for(i=0;i<n;i++){
				af=appFrames[i];
				if(af.meta && af.meta.appFrame && af.meta.appFrame.group==group){
					list.push(af);
				}
			}
			return list;
		};

		//--------------------------------------------------------------------
		app.getAppFramesByMeta=function(meta){
			let i,n,af,frame,list;
			list=[];
			n=appFrames.length;
			for(i=0;i<n;i++){
				af=appFrames[i];
				if(af.meta===meta){
					list.push(af);
				}
			}
			return list;
		};

		//--------------------------------------------------------------------
		app.orderFrames=function(){
			let i,n;
			n=appFrames.length;
			for(i=0;i<n;i++){
				appFrames[i].zIndex=i;
			}
		};

		//--------------------------------------------------------------------
		app.focusAppFrame=app.focusFrameApp=function(frame){
			let idx,n,topFrame;
			idx=appFrames.indexOf(frame);
			if(idx<0){
				return;
			}
			n=appFrames.length;
			if(idx===n-1){
				app.orderFrames();
				frame.focus();
				docker.focusLiveFrame(frame);
				if(!isShowAppFrame){
					app.showAppFrames();
				}
				return 1;
			}
			topFrame=appFrames[n-1];
			topFrame.blur();
			frame.hold();
			frame.focus();
			appFrames.splice(idx,1);
			appFrames.push(frame);
			app.orderFrames();
			frame.release();
			docker.focusLiveFrame(frame);
			if(!isShowAppFrame){
				app.showAppFrames();
			}
		};
		
		//--------------------------------------------------------------------
		app.blurTopFrame=function(){
			let topFrame,n;
			n=appFrames.length;
			topFrame=appFrames[n-1];
			if(topFrame){
				topFrame.blur();
				docker.blurLiveFrame(topFrame);
			}
		};

		//--------------------------------------------------------------------
		app.hideFrameApp=function(frame){
			let w,icon,n,topFrame,idx;
			if(frame.hidden){
				return;
			}
			frame.hidden=1;
			frame.uiEvent=-1;
			boxHideAni.alpha=1;
			boxHideAni.scale=1;
			frame.hideX=boxHideAni.x=frame.x;
			frame.hideY=boxHideAni.y=frame.y;
			frame.hideW=boxHideAni.w=frame.w;
			frame.hideH=boxHideAni.h=frame.h;
			boxHideAni.display=1;
			w=frame.w>frame.h?frame.h:frame.w;
			w*=0.5;
			boxHideIcon.w=w;
			boxHideIcon.h=w;
			boxHideAni.animate({type:"pose",x:50,y:app.h-30,alpha:0.5,scale:0,time:300});
			icon=frame.meta.icon;
			if(icon){
				boxHideIcon.display=1;
				boxHideIcon.maskImage=frame.meta.icon;
			}else{
				boxHideIcon.display=0;
			}
			frame.animate({type:"out",dx:0,dy:0,time:150});
			docker.blurLiveFrame(frame);
			idx=appFrames.indexOf(frame);
			if(idx>=0){
				n=appFrames.length;
				topFrame=appFrames[n-1];
				appFrames.splice(idx,1);
				if(topFrame===frame){
					topFrame=appFrames[n-2];
					if(topFrame){
						app.focusFrameApp(topFrame);
					}else{
						if(isMini){
							app.hideAppFrames();
						}
					}
				}
			}
			docker.addHideIcon(frame);
		};

		//--------------------------------------------------------------------
		app.unhideFrameApp=function(frame){
			let w,icon;
			if(!frame.hidden){
				return;
			}
			frame.hidden=0;
			frame.uiEvent=1;

			boxHideAni.alpha=1;
			boxHideAni.scale=0;
			boxHideAni.x=50;
			boxHideAni.y=app.h-30;
			boxHideAni.w=frame.hideW||300;
			boxHideAni.h=frame.hideH||200;
			boxHideAni.display=1;
			w=frame.hideW>frame.hideH?frame.hideH:frame.hideW;
			w*=0.5;
			boxHideIcon.w=w;
			boxHideIcon.h=w;
			icon=frame.meta.icon;
			if(icon){
				boxHideIcon.display=1;
				boxHideIcon.maskImage=frame.meta.icon;
			}else{
				boxHideIcon.display=0;
			}
			boxHideAni.animate({
				type:"pose",x:frame.hideX,y:frame.hideY,alpha:0.5,scale:1,time:300,
				OnFinish(){
					boxHideAni.display=0;
				}
			});
			//frame.display=1;
			setTimeout(()=>{
				frame.animate({
					type:"in",dx:0,dy:0,time:150,
					OnFinish(){
						appFrames.unshift(frame);
						app.focusFrameApp(frame);
					}
				});
			},150);
		};

		//--------------------------------------------------------------------
		app.focusFrameGroup=function(group){
			let frame,i,n,oldTopFrame,switched,dirty,minIdx,cnt;
			n=appFrames.length;
			switched=0;
			dirty=0;
			minIdx=0;
			oldTopFrame=appFrames[n-1];
			cnt=0;
			for(i=0;i<n;i++){
				frame=appFrames[i];
				if(frame.groupStub===group){
					appFrames.splice(i,1);
					appFrames.push(frame);
					if(!switched){
						minIdx=i;
						switched=1;
					}
					cnt++;
					n--;i--;
				}else if(switched){
					dirty=1;
				}
			}
			if(!dirty){
				if(cnt>1){
					frame=appFrames[appFrames.length-1];
					if(frame){
						frame.blur();
						appFrames.pop();
						appFrames.splice(minIdx,0,frame);
					}						
				}
				frame=appFrames[appFrames.length-1];
				if(frame){
					if(!frame.focused){
						app.focusFrameApp(frame);
					}
				}
			}else{
				if(oldTopFrame && oldTopFrame.groupStub!==group){
					oldTopFrame.blur();
				}
				frame=appFrames[appFrames.length-1];
				if(frame){
					app.focusFrameApp(frame);
				}
			}
			if(!isShowAppFrame){
				app.showAppFrames();
			}
		};

		//--------------------------------------------------------------------
		app.closeFrameGroup=async function(group){
			let frame,i,n,dirty,list;
			n=appFrames.length;
			list=appFrames.filter((frame)=>frame.groupStub===group);
			for(frame of list){
				frame.close();
			}
			frame=appFrames[appFrames.length-1];
			if(frame){
				app.focusFrameApp(frame);
			}
		};
	}
	
	//************************************************************************
	//Mini docker related:
	//************************************************************************
	if(isMini){
		//--------------------------------------------------------------------
		app.showAppFrames=function(){
			let frames;
			if(isShowAppFrame){
				return;
			}
			frames=this.getAppFrames();
			if(!frames.length){
			}
			dockerUI.w="100%";//TODO: code this:
			boxApp.w="100%";
			boxApp.h="100%";
			boxApp.display=1;
			isShowAppFrame=1;
			if(autoHide){
				docker.showFace("show");
				docker.showFace("hover");
			}else{
				docker.showFace("hover");
			}
		};
		
		//--------------------------------------------------------------------
		app.hideAppFrames=function(){
			if(!isShowAppFrame){
				return;
			}
			dockerUI.w=5;//TODO: code this:
			boxApp.display=0;
			boxApp.w=0;
			boxApp.h=0;
			isShowAppFrame=0;
			if(autoHide){
				docker.showFace("hide");
				docker.showFace("hover");
			}else{
				docker.showFace("stay");
			}
			app.blurTopFrame();
		};
	
		docker.showFace("mini");
		app.hideAppFrames();
	}
};

//----------------------------------------------------------------------------
AppLib.ensurePackageInstalled=async function(app,pkgName,run=false){
	let res,meta;
	//Check if package is already installed:
	try{
		res=await fetch(`/~/-${pkgName}/disk.json`);
		if(res.ok){
			if(run){//Run app:
				meta=await app.appLib.scanAppDir(`-${pkgName}`);
				app.newFrameApp(meta);
			}
			return true;
		}
	}catch(err){
	}
	try{
		res=await fetch(`/@${pkgName}`);
		if(res.ok){
			return true;
		}
	}catch(err){
	}
	//So we need to install this package:
	await app.modalDlg("/@StdUI/ui/DlgTtyWork.js",{
		title:(($ln==="CN")?("安装功能包"):/*EN*/("Install package")),
		x:window.innerWidth*0.5,alignX:1,y:50,w:380,h:280,autoClose:true,
		work:async function(tty,dlg){
			let workFunc;
			try{
				workFunc=(await import("/@pkg/pkgUtil.js")).installPkgOnDisk;
				return await workFunc(tty,"coke",pkgName,{mode:"install"});
			}catch(e){
				tty.textOut((($ln==="CN")?(`安装功能包出错: ${e}\n`):/*EN*/(`Install package error: ${e}\n`)));
				return false;
			}
		}
	});
	await app.appLib.ensureToolsVersion();
	try{
		res=await fetch(`/~/-${pkgName}/disk.json`);
		if(res.ok){
			return true;
		}
	}catch(err){
	}
};

/*}#1G5TFHD9F0EndDoc*/

export{AppLib,FavLib};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DataDoc",
//	"jaxId": "1G5TFHD9F0",
//	"attrs": {
//		"editObjs": {
//			"jaxId": "1G5TFHD9F1",
//			"attrs": {
//				"AppLib": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1G5TFI2350",
//					"attrs": {
//						"constructArgs": {
//							"jaxId": "1G5TFI24A0",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1G5TFI24A1",
//							"attrs": {
//								"appHash": {
//									"type": "auto",
//									"valText": "#{}#>new Map();"
//								},
//								"catalogs": {
//									"type": "auto",
//									"valText": "#{}"
//								}
//							}
//						},
//						"functions": {
//							"jaxId": "1G5TFI24A2",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false",
//						"exportType": "Data Class"
//					},
//					"mockups": {
//						"testApp": {
//							"type": "object",
//							"jaxId": "1GMA9QAII0",
//							"attrs": {
//								"appHash": "{}",
//								"catalogs": "{}"
//							}
//						}
//					}
//				},
//				"FavLib": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1G5VTG2EF0",
//					"attrs": {
//						"constructArgs": {
//							"jaxId": "1G5VTG2FH0",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1G5VTG2FH1",
//							"attrs": {
//								"this.catalogs": {
//									"type": "auto",
//									"valText": "#{}"
//								}
//							}
//						},
//						"functions": {
//							"jaxId": "1G5VTG2FH2",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false",
//						"exportType": "UI Data Template"
//					},
//					"mockups": {}
//				}
//			}
//		}
//	}
//}