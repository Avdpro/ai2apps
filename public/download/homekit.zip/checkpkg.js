import {tabFS} from "/@tabos";

async function checkPackages(callback){
	let pkgHash,pkgList;
	let entryList;
	pkgHash={};
	pkgList=[];
	
	//------------------------------------------------------------------------
	//Check a coke lib dir for package(s)
	async function checkPkgDir(entry){
		let pkgName,pkgTag,pkgVersion,pkgPath,pkgDesc,pkgMain,cloudName,diskId,importsBy,depends;
		let libJson,tags,tagVO,name,tagJson,extraTags,tagPkgVO,packageVO;
		extraTags=[];
		if(entry.dir){
			pkgName=entry.name;
			try{
				libJson=await tabFS.readFile(`/coke/lib/${entry.name}/coke.json`,"utf8");
				libJson=JSON.parse(libJson);
				pkgName=libJson.name;
				if(!pkgName){
					return;//A mounted local lib?
				}
				pkgTag=libJson.tag;
				tags=libJson.tags;
				tagVO=tags[pkgTag];
				cloudName=libJson.cloudName;
				if(tagVO){
					pkgVersion=tagVO.version;
					try{
						tagJson=await tabFS.readFile(`/coke/lib/${entry.name}/${pkgTag}/disk.json`,"utf8");
						tagJson=JSON.parse(tagJson);
						pkgDesc=tagJson.description||"";
						pkgPath=`/coke/lib/${entry.name}/${pkgTag}/${tagJson.path||""}`;
						pkgMain=`/coke/lib/${entry.name}/${pkgTag}/${tagJson.main||""}`;
					}catch(err){
						return;
					}
				}else{
					//TODO: Report error?
					return;
				}
				//Deal with more tags?
				for(name in tags){
					if(name!==pkgTag){
						tagPkgVO={
							type:"subTag"
						};
						tagJson=await tabFS.readFile(`/coke/lib/${entry.name}/${name}/disk.json`,"utf8");
						tagJson=JSON.parse(tagJson);
						tagPkgVO.name=pkgName;
						tagPkgVO.tag=name;
						tagPkgVO.version=tagVO.version;
						tagPkgVO.description=tagJson.description||"";
						tagPkgVO.path=`/coke/lib/${entry.name}/${name}/${tagJson.path||""}`;
						tagPkgVO.main=`/coke/lib/${entry.name}/${name}/${tagJson.main||""}`;
						extraTags.push(tagPkgVO);
					}
				}
				packageVO={
					type:"dir",
					name:pkgName,
					tag:pkgTag,
					version:pkgVersion,
					path:pkgPath,
					main:pkgMain,
					description:pkgDesc,
				};
				if(extraTags.length>0){
					packageVO.extraTagPkgs=extraTags;
				}
				callback(packageVO);
			}catch(err){
			}
		}else if(entry.name.endsWith(".json")){
			return;//We skip this kind here, check disks starts with "-" later:
			try{
				libJson=await tabFS.readFile(`/coke/lib/${entry.name}`,"utf8");
				libJson=JSON.parse(libJson);
				pkgName=libJson.name;
				if(!pkgName){
					return;//A mounted local lib:
				}
			}catch(err){
			}
		}
	}
	
	//------------------------------------------------------------------------
	async function checkPkgDisk(entry){
		let diskJson,packageVO;
		try{
			diskJson=await tabFS.readFile(`/${entry.name}/disk.json`,"utf8");
			diskJson=JSON.parse(diskJson);
			packageVO={
				type:"disk",
				name:diskJson.name,
				version:diskJson.version,
				tag:diskJson.tag||"",
				description:diskJson.description||"",
				path:`/${entry.name}/${diskJson.path||""}`,
				main:`/${entry.name}/${diskJson.main||""}`,
			};
			callback(packageVO);
		}catch(err){
		}
	};
	
	entryList=await tabFS.getEntries("/coke/lib");
	entryList.sort((a,b)=>{
		if(a.name>b.name){
			return 1;
		}
		if(a.name<b.name){
			return -1;
		}
		return 0;
	})
	for(let entry of entryList){
		await checkPkgDir(entry);
	}

	entryList=await tabFS.getEntries("/");
	entryList=entryList.filter((dir)=>{return dir.name.startsWith("-")});
	entryList.sort((a,b)=>{
		if(a.name>b.name){
			return 1;
		}
		if(a.name<b.name){
			return -1;
		}
		return 0;
	})
	for(let entry of entryList){
		await checkPkgDisk(entry);
	}
};

export {checkPackages};
