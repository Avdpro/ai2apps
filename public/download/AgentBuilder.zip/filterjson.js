import {tabFS} from "/@tabos";

function filterJSON(jsonText,vals){
	let pos1,pos2,key,value;
	let orgText=jsonText;
	pos1=0;
	do{
		pos1=jsonText.indexOf("%<",pos1);
		if(pos1>0){
			pos2=jsonText.indexOf(">%",pos1);
			if(pos2<0){
				//Error
				return orgText;
			}
			key=jsonText.substring(pos1+2,pos2);
			value=vals[key]||"null";
			jsonText=jsonText.substring(0,pos1)+value+jsonText.substring(pos2+2);
			pos1+=1;
		}
	}while(pos1>0);
	return jsonText;
}

async function filterJSONFile(path,vals){
	let jsonText;
	try{
		jsonText=await tabFS.readFile(path,"utf8");
		if(!jsonText){
			return;
		}
		jsonText=filterJSON(jsonText,vals);
		await tabFS.writeFile(path,jsonText);
	}catch(err){
	}
}

async function filterJSONPath(path,vals){
	let items,item;
	items=await tabFS.getEntries(path);
	for(item of items){
		try{
			if(item.dir){
				await filterJSONPath(path+"/"+item.name,vals);
			}else if(item.name.endsWith(".json")){
				await filterJSONFile(path+"/"+item.name,vals);
			}
		}catch(err){
		}
	}
}

export {filterJSONPath,filterJSONFile,filterJSON};