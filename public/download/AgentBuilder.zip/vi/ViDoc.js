import ViSeg from "./ViSeg.js";
import pathLib from "/@path";
//****************************************************************************
//Visual Inference doc
//****************************************************************************
let ViDoc,viDoc;
{
	//------------------------------------------------------------------------
	ViDoc=function(url,def){
		let seg;
		this.url=url;
		this.name=pathLib.basename(url);
		this.jaxId=def.jaxId;
		this.def=def;
		this.segs={};
		this.segList=[];
		this.initSegs();		
		for(seg of this.segList){
			seg.postLink();
		}
		this.canvas=null;
		this.hudObj=null;
		this.hotSeg=null;
		this.hotOutlet=null;
	};
	viDoc=ViDoc.prototype={};

	//------------------------------------------------------------------------
	viDoc.initSegs=function(){
		let def,defSegs,segDef,seg;
		def=this.def;
		defSegs=def.attrs.segs.attrs;
		for(segDef of defSegs){
			seg=new ViSeg(this,segDef);
		}
	};
	//------------------------------------------------------------------------
	viDoc.regSeg=function(seg){
		this.segs[seg.jaxId]=seg;
		this.segList.push(seg);
	};
	
	//------------------------------------------------------------------------
	viDoc.getSeg=function(jaxId){
		return this.segs[jaxId];
	};

	//------------------------------------------------------------------------
	viDoc.render=function(canvas){
		let segs,seg,segsBox,hudObj;
		hudObj=this.hudObj;
		if(hudObj){
			canvas.appendChild(hudObj);
		}else{
			let rect;
			rect=canvas.getBoundingClientRect();
			if(rect.width>10 && rect.height>10){
				hudObj=canvas.appendNewChild({type:"hud",x:0,y:0,w:0,h:0});
				segs=this.segList;
				for(seg of segs){
					seg.render(hudObj);
				}
				hudObj.hold();
				this.hudObj=hudObj;
				hudObj.zoom=1;
			}
		}
		this.canvas=canvas;
		if(hudObj){
			segs=this.segList;
			for(seg of segs){
				seg.hudObj.adjustSize(canvas);
			}
			for(seg of segs){
				seg.hudObj.renderPath(canvas);
			}
		}
	};
	
	//------------------------------------------------------------------------
	viDoc.hide=function(canvas){
		if((!canvas && this.canvas)|| this.canvas===canvas){
			if(this.hudObj){
				this.canvas.removeChild(this.hudObj);
			}
			this.canvas=null;
		}
	};
	
	//------------------------------------------------------------------------
	viDoc.showSeg=function(segJaxId,fromSeg=null,fromOutlet=null,slowMo=false){
		let seg,cvsRect,segRect,hudObj,segHud;
		let dx,dy,tx,ty,zoom;
		hudObj=this.hudObj;
		if(!hudObj){
			return;			
		}
		seg=this.segs[segJaxId];
		if(!seg){
			return;
		}
		this.focusSeg(seg,slowMo);
		if(fromSeg){
			if(this.hotOutlet){
				this.hotOutlet.hudObj.trace(false);
				this.hotOutlet=null;
			}
			seg=this.segs[fromSeg];
			if(seg && seg.hudObj){
				fromOutlet=seg.hudObj.traceOutlet(fromOutlet);
				this.hotOutlet=fromOutlet||null;
			}
		}
	};
	
	//-----------------------------------------------------------------------
	viDoc.focusSeg=function(seg,slowMo){
		let cvsRect,segRect,hudObj,segHud;
		let dx,dy,tx,ty,zoom;
		if(this.hotSeg){
			this.hotSeg.hudObj.showFace("blur");
			this.hotSeg=null;
		}
		hudObj=this.hudObj;
		if(!this.canvas || !hudObj){
			return;
		}
		zoom=this.canvas.zoom||1;
		segHud=seg.hudObj;
		cvsRect=this.canvas.getBoundingClientRect();
		segRect=segHud.getBoundingClientRect();
		dx=segRect.x;
		dy=segRect.y;
		tx=cvsRect.x+cvsRect.width*0.5-segRect.width*0.5;
		ty=cvsRect.y+cvsRect.height*0.5-segRect.height*0.5;
		dx=tx-dx;
		dy=ty-dy;
		dx/=zoom;
		dy/=zoom;
		if(this.hudObj.parent){
			hudObj.animate({type:"pose",x:hudObj.x+dx,y:hudObj.y+dy,time:slowMo?150:30});
		}
		this.hotSeg=seg;
		segHud.showFace("focus");
	};
	
	//---------------------------------------------------------------------------
	viDoc.clearTrace=function(){
		let segs,seg,hudObj;
		hudObj=this.hudObj;
		if(!hudObj){
			return;
		}
		segs=this.segList;
		for(seg of segs){
			seg.hudObj.clearTrace();
		}
		this.hotOutlet=null;
	};
}
export default ViDoc;
export {ViDoc,viDoc};
