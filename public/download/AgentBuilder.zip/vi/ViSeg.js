import BoxViSeg from "../ui/BoxViSeg.js";
//****************************************************************************
//Visual Inference Seg-outlet:
//****************************************************************************
let ViSegOutlet,viSegOutlet;
{
	//------------------------------------------------------------------------
	ViSegOutlet=function(seg,def){
		let attrs;
		attrs=def.attrs;
		this.seg=seg;
		this.def=def;
		this.jaxId=def.jaxId;
		this.id=attrs.id;
		this.linkedSeg=def.linkedSeg;
		this.hudObj=null;
		this.pathDir=[1,0];
	};
	viSegOutlet=ViSegOutlet.prototype={};
	
	//------------------------------------------------------------------------
	viSegOutlet.postLink=function(){
		let doc,seg;
		doc=this.seg.doc;
		seg=this.linkedSeg;
		if(typeof(seg)==="string"){
			seg=doc.getSeg(seg);
			if(seg){
				this.linkedSeg=seg;
			}
		}
		//TODO: Code this:
	};

	//------------------------------------------------------------------------
	viSegOutlet.renderPath=function(canvas){
		if(this.hudObj){
			this.hudObj.renderPath(canvas);
		}
	};
}

//****************************************************************************
//Visual Inference Seg:
//****************************************************************************
let ViSeg,viSeg;
{
	//------------------------------------------------------------------------
	ViSeg=function(doc,def){
		let attrs,outs;
		attrs=def.attrs;
		this.doc=doc;
		this.jaxId=def.jaxId;
		this.id=attrs.id;
		this.viewName=attrs.viewName;
		this.icon=def.icon;
		this.segDef=def.def;
		this.x=Number(attrs.x);
		this.y=Number(attrs.y);
		this.pathDir=[-1,0];
		if(attrs.outlet){
			this.outlet=new ViSegOutlet(this,attrs.outlet);
		}else{
			this.outlet=null;
		}
		if(attrs.catchlet){
			this.catchlet=new ViSegOutlet(this,attrs.catchlet);
		}else{
			this.catchlet=null;
		}
		this.outlets=[];
		outs=attrs.outlets;
		if(outs && outs.attrs){
			outs=outs.attrs;
			let od;
			for(od of outs){
				this.outlets.push(new ViSegOutlet(this,od));
			}
		}
		this.reverseOutlets=def.reverseOutlets;
		this.hudObj=null;
		this.isNote=!!def.isNote;
		this.isConnector=!!def.isConnector;
		if(this.isConnector){
			if(attrs.dir){
				this.dir=attrs.dir;
				switch(this.dir){
					case "L2R":
						this.pathDir=[-1,0];
						break;
					case "R2L":
						this.pathDir=[1,0];
						break;
					case "T2B":
						this.pathDir=[0,-1];
						break;
					case "B2T":
						this.pathDir=[0,1];
						break;
				}
			}
		}
		doc.regSeg(this);
	};
	viSeg=ViSeg.prototype={};
	
	//------------------------------------------------------------------------
	viSeg.postLink=function(){
		let outlet;
		this.outlet && this.outlet.postLink();
		this.catchlet && this.catchlet.postLink();
		for(outlet of this.outlets){
			outlet.postLink();
		}
	};
	
	//------------------------------------------------------------------------
	viSeg.render=function(canvas){
		let css;
		css=BoxViSeg(this);
		canvas.appendNewChild(css);
	};
	
	//------------------------------------------------------------------------
	viSeg.renderPath=function(canvas){
		let outlet;
		this.outlet && this.outlet.renderPath(canvas);
		this.catchlet && this.catchlet.renderPath(canvas);
		for(outlet of this.outlets){
			outlet.renderPath(canvas);
		}
	};
	
}
export default ViSeg;
export {ViSeg};