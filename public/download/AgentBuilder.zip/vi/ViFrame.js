
//****************************************************************************
//ViFrame
//****************************************************************************
let ViFrame,viFrame;
{
	//------------------------------------------------------------------------
	ViFrame=function(owner,agent,log){
		this.owner=owner;
		if(owner){
			this.deep=owner.deep+1;
		}else{
			this.deep=0;
		}
		this.entryLog=log;
		this.jaxId=log.agent;
		this.agentJaxId=log.agent;
		this.frameId=log.frameId;
		this.agentURL=log.url;
		this.agent=agent;
		this.name=agent.name;
		this.logs=[];
		
		this.segs=agent.segs;
		this.segList=agent.segList;
		
		this.hotSeg=null;
		this.hotOutlet=null;
		this.tracedSegs=[];
		this.tracedOutlets=[];

		this.finished=false;
		this.result=null;
	};
	viFrame=ViFrame.prototype={};
	
	//------------------------------------------------------------------------
	viFrame.addLog=function(log){
		this.logs.push(log);
	};
	
	//------------------------------------------------------------------------
	viFrame.render=viFrame.enter=function(canvas){
		this.agent.render(canvas)
		this.renderTrace();
		if(this.hotSeg){
			this.focusSeg(this.hotSeg);
		}
		if(this.hotOutlet){
			this.hotOutlet.hudObj.trace(true);
		}
	};

	//------------------------------------------------------------------------
	viFrame.end=function(result){
		this.leave();
		this.finished=true;
		this.result=result;
	};
	

	//------------------------------------------------------------------------
	viFrame.leave=function(result){
		this.agent.hide();
	};
	
	//------------------------------------------------------------------------
	viFrame.renderTrace=function(){
		let outlet;
		this.agent.clearTrace();
		for(outlet of this.tracedOutlets){
			outlet.hudObj.trace(false);
		}
		if(this.hotOutlet){
			this.hotOutlet.hudObj.trace(true);
		}
	};

	//------------------------------------------------------------------------
	viFrame.showSeg=function(segJaxId,fromSeg=null,fromOutlet=null,slowMo=false){
		let seg,cvsRect,segRect,hudObj,segHud;
		let dx,dy,tx,ty,zoom;
		seg=this.segs[segJaxId];
		if(!seg){
			return;
		}
		this.focusSeg(seg,slowMo);
		if(fromSeg){
			if(this.hotOutlet){
				this.hotOutlet.hudObj.trace(false);
				this.hotOutlet=null;
			}
			seg=this.segs[fromSeg];
			if(seg && seg.hudObj){
				fromOutlet=seg.hudObj.traceOutlet(fromOutlet);
				this.hotOutlet=fromOutlet||null;
				this.tracedOutlets.push(this.hotOutlet);
			}
		}
	};

	//-----------------------------------------------------------------------
	viFrame.focusSeg=function(seg,slowMo){
		this.agent.focusSeg(seg,slowMo);
		this.hotSeg=seg;
	};
}
export default ViFrame;
export {ViFrame};
