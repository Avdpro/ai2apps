# Agent Kind / 注册 / 查找机制手册（v0.6.1）

> v0.6.1 修正：补回 `FindVO.prefer`（v0.6 示例里漏写了）。  
> v0.6 仍保留：`FindVO.filter` 支持 **对象** 与 **数组** 两种形态，并规定统一的归一化与重复 key 语义（默认 AND）。  
> v0.5 仍保留：`KindDef.defaultRank(s)` 作为 find 未指定 rank 的默认排序策略。

---

## 0. 总体设计（两级路由）

1) **按 kind 粗筛**：先确定功能大类  
2) **按能力点 caps 精筛**：Agent 侧用字符串数组（运行时转 Set）  
3) **按 filter 表达期望值/上下文**：支持“专用优先 → 通用降级”  
4) **按 prefer 加分**：偏好能力命中越多越优  
5) **按 rank 排序**：由 `KindDef.ranks` 驱动；未指定 rank 时走 `defaultRank(s)`

---

## 1. FindVO（查找请求对象）

FindVO 支持：

- `kind`：必填
- `must`：必填/可空数组（cap/arg 都可）
- `prefer`：可选（cap/arg 都可，命中加分，不硬过滤）
- `filter`：可选（只能写 arg key，支持 object/array 双形态）
- `rank`：可选（缺省走 KindDef.defaultRanks/defaultRank/全局默认）

### 1.1 推荐结构（完整）

```js
{
  kind: "tts",

  must: ["prosody.emotion","prosody.speed","output.format"],
  prefer: ["prosody.style","voice.clone"],

  filter: {
    "prosody.emotion": "calm",
    "output.format": "wav",
    "prosody.speed": 1.2
  },

  // rank 可省略：省略则用 KindDef.defaultRanks
  // rank: "size"
}
```

### 1.2 filter 数组形态（仍然支持）

```js
{
  kind: "rpa",
  must: ["extract.articleUrls","blockers.cookieDismiss","scope.domain"],
  prefer: ["extract.images"],

  filter: [
    { key:"scope.domain", value:["www.openai.com","*"] },
    { key:"blockers.paywall", value:"soft" }
  ]
}
```

---

## 2. filter 的双形态支持与归一化（v0.6 延续）

### 2.1 归一化为 FilterMap

- object → `key -> [value]`
- array  → `key -> [value1, value2, ...]`

归一化后示例：

```js
{
  "scope.domain": [ ["www.openai.com","*"] ],
  "blockers.paywall": [ "soft" ]
}
```

### 2.2 重复 key 语义：默认 AND

同一 key 多次出现时，逐条应用筛选（都要满足）。

### 2.3 tiered filter（降级）

对 `arg.type === "domain_list"` 且 `allowWildcard:true` 的 key（如 `scope.domain`）：

- 若 value 是 `["specific","*"]`，则按顺序分层筛选：
  1) 尝试 `specific`（若候选非空即停止降级）
  2) 否则尝试 `*`
  3) 仍为空 → 失败

---

## 3. rank 缺省行为（v0.5 延续）

当 `FindVO.rank` 缺失时，排序 key 的选择顺序：

1) `FindVO.rank`  
2) `KindDef.defaultRanks`  
3) `KindDef.defaultRank`  
4) 全局默认：`["successRate","latency","size"]`（跳过未定义的 rankKey）  
5) 永远追加稳定 tie-break：`id` 升序

---

## 4. 路由流程要点（含 prefer）

1) kind 粗筛：`agent.kinds` 包含 `vo.kind` 且 `status=active`  
2) must 硬过滤：`agent._capsSetByKind[vo.kind].has(mustKey)`  
3) filter 校验 + 筛选：  
   - 先归一化为 FilterMap  
   - key 必须为 `arg`；value 按 `arg.type` 校验  
   - 同 key 多值按 AND；tiered filter 按层降级  
4) prefer 打分：对每个 preferKey，若 `agent._capsSetByKind[vo.kind].has(preferKey)` 则加分（例如 +1）  
5) rank 排序：按 `KindDef.ranks` 取值排序（多级），最后 `id` 升序  
6) 输出 TopK

---

## 5. 参考：filter 归一化函数（伪代码）

```js
function normFilter(f){
  if(!f) return {};
  if(Array.isArray(f)){
    const out = {};
    for(const it of f){
      if(!it || !it.key) continue;
      const k = String(it.key).trim();
      if(!k) continue;
      (out[k] ||= []).push(it.value);
    }
    return out;
  }
  if(typeof f === "object"){
    const out = {};
    for(const [k,v] of Object.entries(f)){
      const kk = String(k).trim();
      if(!kk) continue;
      out[kk] = [v];
    }
    return out;
  }
  return {};
}
```

---

## 6. 最佳实践

- `prefer` 只影响排序/打分，不应改变“可用性”判断（那是 must/filter 的职责）。  
- 保持 `preferScore` 的规则简单、稳定（比如命中一个 +1），避免难以解释。  
- 路由结果返回 `reason`：列出 must 命中/缺失、filter 降级层级、prefer 命中列表、rank 关键指标值。
