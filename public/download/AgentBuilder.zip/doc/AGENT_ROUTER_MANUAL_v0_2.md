# Agent Kind / 注册 / 查找机制手册（v0.2）

> v0.2 更新点：`KindDef.caps` 改为 **带 desc 的定义表**（cap -> meta），更利于文档、UI、自动补全与校验。  
> 设计目标：在 Agent 数量增多后，仍能 **快速、可控、可降级** 地找到最合适的 Agent。

---

## 0. 总体设计（两级路由）

1. **按 kind 粗筛**：先确定功能大类（例如：TTS / RPA / Image / Chat…）
2. **按能力点 caps 精筛**：用字符串数组描述“支持什么能力/控制项”
3. **按 filter 适用范围/期望值**：支持“专用优先 → 通用降级”（典型：按网站域名 domain）
4. **按 rank 排序**：比如 prefer smaller model

> 约定：**Agent 的 caps 是字符串数组**（用于高效匹配）；  
> `KindDef` 负责定义这些 caps 的 **含义/说明(desc)/可用性**。

---

## 1. 术语与命名约定

### 1.1 kind
- 功能大类，用于粗筛。
- 示例：`tts` / `image` / `video` / `chat` / `rpa`

### 1.2 caps（能力点）
- Agent 侧：**字符串数组**（运行时会转成 `Set` 加速判断）。
- caps 表示“支持某能力/控制项”，不表达范围精度。
- caps 采用 **局部 key**（不带 kind 前缀），命名建议 `group.name`：
  - TTS 示例：`prosody.speed` / `prosody.emotion` / `output.format`
  - RPA 示例：`extract.articleUrls` / `blockers.cookieDismiss` / `scope.domain`

> 命名空间由 `FindVO.kind` 决定；同名 key 在不同 kind 下的语义由各自 `KindDef` 管理。

### 1.3 filter（适用范围/期望值）
- 由 key → value 构成（key 为局部 key，不带 kind 前缀）。
- 支持“专用优先 → 通用降级”的写法：**value 为数组**，从最具体到最通用。
  - 典型：`scope.domain: ["www.openai.com", "*"]`

### 1.4 rank（排序规则）
- 用于排序候选 Agent，例如：
  - `size`：prefer smaller model（越小越优先）
  - `successRate`：更稳定优先
  - `latency`：更快优先
  - `cost`：更便宜优先

---

## 2. 如何编写 kind 定义（Kind Spec）

### 2.1 文件组织建议

```
/agent-spec/
  index.js                 // 汇总并导出 KindDefs
  kinds/
    tts.js
    rpa.js
    image.js
    chat.js
```

### 2.2 KindDef 的结构（v0.2）

`KindDef` 至少包含：

- `kind`: 名称
- `caps`: **cap 定义表**（对象：`capKey -> meta`，meta 至少含 `desc`）
- `filters`: 允许的 filter key（以及类型/是否允许 wildcard 降级）
- `ranks`: 支持的 rank key

> 说明：虽然 `KindDef.caps` 是对象表，但你依然可以通过 `Object.keys(KindDef.caps)` 得到 caps 列表，用于校验/补全。

#### cap meta 推荐字段

- `desc`：一句话说明（强烈建议）
- `kind`：可选，标记语义角色（`cap|param|scope|metric`），便于 UI/路由解释
- `examples`：可选，给 UI/文档用

---

### 2.3 示例：`kinds/tts.js`

```js
export const ttsKind = {
  kind: "tts",

  // cap 定义表（局部 key + desc）
  caps: {
    "prosody.speed": {
      desc: "支持语速控制（是否能调节 speaking rate）",
      kind: "cap",
      examples: ["must: ['prosody.speed']"]
    },
    "prosody.emotion": {
      desc: "支持情绪/语气控制（如 calm/happy 等）",
      kind: "cap",
    },
    "prosody.style": {
      desc: "支持风格/场景预设（如 narration/customer_service）",
      kind: "cap",
    },
    "prosody.pauseControl": {
      desc: "支持停顿/断句控制（例如 SSML break 或等价能力）",
      kind: "cap",
    },
    "voice.clone": {
      desc: "支持音色克隆/声音复刻",
      kind: "cap",
    },
    "output.format": {
      desc: "支持指定输出音频格式（wav/mp3 等）",
      kind: "cap",
    },
    "output.sampleRate": {
      desc: "支持指定输出采样率（如 24000/48000）",
      kind: "cap",
    },
  },

  // filter：表达期望值/上下文（TTS 通常不需要 wildcard 降级）
  filters: {
    lang: { type: "enum_or_list", values: ["zh","en","ja"], desc:"期望语言" },
    "output.format": { type: "enum_or_list", values: ["wav","mp3"], desc:"期望输出格式" },
    "prosody.speed": { type: "number_or_range", desc:"期望语速（执行时由 agent 自行解析/夹逼）" },
    "prosody.emotion": { type: "enum", values: ["neutral","calm","happy","sad","angry"], desc:"期望情绪" },
    "prosody.style": { type: "enum_or_list", desc:"期望风格" },
  },

  ranks: ["size","successRate","latency","cost"],
};
```

---

### 2.4 示例：`kinds/rpa.js`

```js
export const rpaKind = {
  kind: "rpa",

  caps: {
    "extract.articleUrls": { desc:"从信息源页面提取文章 URL 列表", kind:"cap" },
    "extract.images": { desc:"提取图片/封面等媒体资源", kind:"cap" },
    "blockers.cookieDismiss": { desc:"处理 cookie/弹窗同意等拦截", kind:"cap" },
    "blockers.paywall": { desc:"处理（或识别）付费墙/订阅拦截", kind:"cap" },
    "auth.login": { desc:"需要/支持登录流程的处理", kind:"cap" },
    "scope.domain": { desc:"按域名适配（专用/通用）", kind:"scope" },
  },

  // RPA 的 scope/filter 常需要降级（domain 专用 -> *）
  filters: {
    "scope.domain": { type:"domain_list", allowWildcard:true, desc:"目标域名，支持 ['a.com','*'] 降级" },
    "blockers.paywall": { type:"enum", values:["none","soft","hard"], desc:"期望处理的付费墙等级" },
  },

  ranks: ["size","successRate","latency","cost"],
};
```

---

### 2.5 汇总：`agent-spec/index.js`

```js
import { ttsKind } from "./kinds/tts.js";
import { rpaKind } from "./kinds/rpa.js";

export const KindDefs = {
  [ttsKind.kind]: ttsKind,
  [rpaKind.kind]: rpaKind,
};
```

---

## 3. 如何注册 Agent（Agent Meta）

### 3.1 Agent 注册对象（JSON）规范

```js
{
  id: "tts_say@1.2.0",
  name: "SayTTS",

  kinds: ["tts"],
  primaryKind: "tts",

  desc: "高自然度中文 TTS，支持情绪与语速控制",
  tags: ["zh", "natural", "emotion"],

  // 能力点：每个 kind 一份字符串数组（避免多 kind 歧义）
  caps: {
    tts: ["prosody.speed", "prosody.emotion", "output.format", "prosody.style"]
  },

  // 适用范围/专用信息（可选；RPA 强烈建议）
  filters: {
    rpa: { "scope.domain": ["www.openai.com"] }  // 或 ["*"]
  },

  // 路由排序/指标（可选，但强烈建议填）
  metrics: {
    size: 120,
    successRate: 0.93,
    latencyMsP95: 900,
    costPer1k: 0.8
  },

  impl: {
    kind: "local_js|http|python|worker",
    entry: "./agents/xxx.mjs",
    endpoint: "http://127.0.0.1:9001/xxx",
    timeoutMs: 12000
  },

  status: "active|disabled|deprecated",
  weight: 1.0
}
```

### 3.2 Registry 加载时归一化（建议强制）

加载 Agent 列表后，执行 `normalizeAgent()`：

- 忽略 `status !== "active"`（默认不参与路由）
- `caps[kind]`：`trim`、去重
- 构建：`agent._capsSetByKind[kind] = new Set(caps[kind])`
- 可选：对 `filters[kind]["scope.domain"]` 等构建 Set 加速匹配

> 校验建议：`caps[k]` 的每一项必须存在于 `KindDefs[k].caps`（否则拒绝注册或报警）。

---

## 4. 如何给出 find 的 VO（FindVO）

### 4.1 推荐结构（清晰版本）

```js
{
  kind: "tts",

  must: ["prosody.emotion","prosody.speed","output.format"],
  prefer: ["prosody.style"],

  filter: {
    "prosody.emotion": "calm",
    "output.format": "wav"
  },

  rank: "size"
}
```

### 4.2 语法糖版本（可选支持；入口归一化为 4.1）

```js
{
  kind:"tts",
  must:["prosody.emotion:calm","prosody.speed","output.format"],
  prefer:["prosody.style"],
  rank:"size"
}
```

若支持语法糖：入口 parse 时将 `"k:v"` 抽到 `filter[k]=v`，并确保 `k` 在 `must` 内（若未包含则补上）。

---

## 5. filter 的降级机制（专用优先 → 通用降级）

### 5.1 典型：RPA 信息源读取按域名降级

```js
{
  kind:"rpa",
  must:["extract.articleUrls","blockers.cookieDismiss"],
  filter:{ "scope.domain":["www.openai.com","*"] },
  rank:"successRate"
}
```

路由语义：
1. 先尝试匹配 `scope.domain=www.openai.com` 的候选集（若非空→停在该层）
2. 若为空→尝试 `scope.domain=*`（通用）
3. 仍为空→失败或走全局兜底

> 降级只对 `KindDef.filters[key].allowWildcard === true` 的 key 开启。

---

## 6. 路由语义（v0.2）

1) **kind 粗筛**：保留 `agent.kinds` 含 `vo.kind` 且 `status=active`  
2) **must 硬过滤**：对每个 must key，要求 `agent._capsSetByKind[vo.kind].has(key)`  
3) **filter 分层过滤（若该 key 支持降级）**：如 `scope.domain`  
4) **prefer 打分**：prefer 命中越多越好（简单 +1 即可）  
5) **rank 排序**：按 `rank` 指标排序（例如 size 升序）  
6) 输出 TopK（默认 1 或 3）

rank 参考规则：
- `size`：`metrics.size` 升序
- `successRate`：`metrics.successRate` 降序
- `latency`：`metrics.latencyMsP95` 升序
- `cost`：`metrics.costPer1k` 升序

---

## 7. 推荐工程约束（强烈建议）

1) **注册校验**：`caps[kind]` 的 key 必须在 `KindDefs[kind].caps` 中  
2) **查询校验**：FindVO 的 `must/prefer/filter` key 必须在 `KindDefs[kind]` 中（否则拒绝或忽略并记录日志）  
3) **路由解释**：建议返回 `reason`（用于 debug / UI）：
   - 未命中的 must（来自 KindDef.caps[cap].desc 可读化）
   - prefer 命中情况
   - filter 命中/降级层级（专用 vs 通用）
   - rank 的关键指标值

---

## 8. 兼容与扩展建议

- 若未来需要“按支持范围精确路由”（如 speed 覆盖范围），可新增可选字段 `support`，但不破坏本手册：
  - `caps` 仍用于存在性筛选
  - `support` 用于精确能力覆盖判断/更细粒度排序
