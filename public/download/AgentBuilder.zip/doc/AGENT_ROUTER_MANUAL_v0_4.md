# Agent Kind / 注册 / 查找机制手册（v0.4）

> v0.4 更新点：`KindDef.ranks` 改为 **带 meta 的定义表**（rankKey -> meta），使排序规则“可配置、可解释、可校验”。  
> v0.3 仍保留：`KindDef.caps` 中 `kind: "cap" | "arg"`，且 `arg` 必须定义 `type`。

---

## 0. 总体设计（两级路由）

1) **按 kind 粗筛**：先确定功能大类（TTS / RPA / Image / Chat…）  
2) **按能力点 caps 精筛**：Agent 侧仍用字符串数组（运行时转 Set 加速）  
3) **按 filter 表达期望值/上下文**：支持“专用优先 → 通用降级”  
4) **按 rank 排序**：rank 规则由 `KindDef.ranks` 驱动（不 hardcode）

---

## 1. 术语与命名约定

### 1.1 kind
- 功能大类，用于粗筛。
- 示例：`tts` / `image` / `video` / `chat` / `rpa`

### 1.2 caps（能力点）
- Agent 侧：**字符串数组**（运行时会转成 `Set` 加速判断）。
- caps 表示“支持某能力/控制项”，不表达范围精度。
- caps 采用 **局部 key**（不带 kind 前缀），命名建议 `group.name`：
  - TTS 示例：`prosody.speed` / `prosody.emotion` / `output.format`
  - RPA 示例：`extract.articleUrls` / `blockers.cookieDismiss` / `scope.domain`

> 命名空间由 `FindVO.kind` 决定；同名 key 在不同 kind 下的语义由各自 `KindDef` 管理。

### 1.3 filter（适用范围/期望值）
- key → value（key 为局部 key）。
- **只能用于 `KindDef.caps[key].kind === "arg"` 的 key**，并按其 `type` 校验 value。
- 支持“专用优先 → 通用降级”：value 允许数组，从最具体到最通用。
  - 典型：`scope.domain: ["www.openai.com", "*"]`

### 1.4 rank（排序规则）
- FindVO 的 `rank` 为 rankKey（例如 `size` / `successRate` / `latency` / `cost`）
- rankKey 必须存在于 `KindDef.ranks`，路由器根据 meta 实施排序。

---

## 2. KindDef（kind 规范定义）

### 2.1 KindDef 结构（v0.4）

`KindDef` 至少包含：

- `kind`: 名称
- `caps`: 定义表（key -> meta，meta 至少含 `desc` 与 `kind`）
- `ranks`: **排序定义表**（rankKey -> meta）

---

## 3. caps：cap / arg 规范（v0.3 延续）

### 3.1 cap meta（能力开关）

```js
{
  kind: "cap",
  desc: "一句话说明"
}
```

### 3.2 arg meta（参数能力）

```js
{
  kind: "arg",
  type: "enum | enum_or_list | number | number_or_range | domain_list | string | string_or_list",
  values: ["..."],        // enum/enum_or_list 需要
  allowWildcard: true,    // domain_list 常用，允许 "*" 作为通用
  desc: "一句话说明"
}
```

---

## 4. ranks：排序定义表（v0.4 新增）

### 4.1 rank meta 推荐字段

- `desc`：一句话说明
- `order`：`"asc"` / `"desc"`
- `valueFrom`：从 agent 对象取值的路径（推荐以 `metrics.xxx` 为主）
- `type`：`"number"`（v0.4 先支持 number 足够）
- `missing`：缺失值策略：
  - `"last"`：缺失排到最后（推荐默认）
  - `"default"`：使用 `defaultValue`
  - `"reject"`：缺失即不参与候选
- `defaultValue`：仅 `missing:"default"` 时需要

#### 示例
```js
{
  desc: "成功率（越高越优先）",
  order: "desc",
  valueFrom: "metrics.successRate",
  type: "number",
  missing: "last"
}
```

---

## 5. 示例 KindDef（含 caps + ranks）

### 5.1 `kinds/tts.js`

```js
export const ttsKind = {
  kind: "tts",

  caps: {
    // cap
    "prosody.pauseControl": { kind:"cap", desc:"支持停顿/断句控制（例如 SSML break 或等价能力）" },
    "voice.clone": { kind:"cap", desc:"支持音色克隆/声音复刻" },

    // arg
    "lang": { kind:"arg", type:"enum_or_list", values:["zh","en","ja"], desc:"语言（或语言列表）" },
    "prosody.speed": { kind:"arg", type:"number_or_range", desc:"语速（1.0 为正常语速）" },
    "prosody.emotion": { kind:"arg", type:"enum", values:["neutral","calm","happy","sad","angry"], desc:"情绪/语气" },
    "prosody.style": { kind:"arg", type:"string_or_list", desc:"风格/场景预设（如 narration/customer_service）" },
    "output.format": { kind:"arg", type:"enum_or_list", values:["wav","mp3"], desc:"输出格式" },
    "output.sampleRate": { kind:"arg", type:"number", desc:"采样率（如 24000/48000）" },
  },

  ranks: {
    size: {
      desc: "模型/Agent 体积（越小越优先）",
      order: "asc",
      valueFrom: "metrics.size",
      type: "number",
      missing: "last"
    },
    successRate: {
      desc: "成功率（越高越优先）",
      order: "desc",
      valueFrom: "metrics.successRate",
      type: "number",
      missing: "last"
    },
    latency: {
      desc: "延迟 P95（越低越优先）",
      order: "asc",
      valueFrom: "metrics.latencyMsP95",
      type: "number",
      missing: "last"
    },
    cost: {
      desc: "成本（越低越优先）",
      order: "asc",
      valueFrom: "metrics.costPer1k",
      type: "number",
      missing: "last"
    }
  }
};
```

### 5.2 `kinds/rpa.js`

```js
export const rpaKind = {
  kind: "rpa",

  caps: {
    // cap
    "extract.articleUrls": { kind:"cap", desc:"从信息源页面提取文章 URL 列表" },
    "extract.images": { kind:"cap", desc:"提取图片/封面等媒体资源" },
    "blockers.cookieDismiss": { kind:"cap", desc:"处理 cookie/弹窗同意等拦截" },

    // arg
    "scope.domain": { kind:"arg", type:"domain_list", allowWildcard:true, desc:"目标域名，支持 ['a.com','*'] 降级" },
    "blockers.paywall": { kind:"arg", type:"enum", values:["none","soft","hard"], desc:"期望处理的付费墙等级" },
  },

  ranks: {
    size: { desc:"体积越小越优先", order:"asc", valueFrom:"metrics.size", type:"number", missing:"last" },
    successRate: { desc:"成功率越高越优先", order:"desc", valueFrom:"metrics.successRate", type:"number", missing:"last" },
    latency: { desc:"延迟越低越优先", order:"asc", valueFrom:"metrics.latencyMsP95", type:"number", missing:"last" }
  }
};
```

---

## 6. 注册 Agent（Agent Meta）

### 6.1 Agent JSON 规范

```js
{
  id: "rpa_source_openai@1.0.0",
  name: "OpenAI Source Reader",

  kinds: ["rpa"],
  primaryKind: "rpa",

  desc: "适配 openai.com 的信息源列表提取",
  tags: ["source","openai","extract_urls"],

  // caps：字符串数组（包含 cap 与 arg key）
  caps: {
    rpa: ["extract.articleUrls", "blockers.cookieDismiss", "scope.domain"]
  },

  // filters：Agent 自己的适用范围声明（通常只写少数 scope 类 arg）
  filters: {
    rpa: { "scope.domain": ["www.openai.com"] } // 通用则写 ["*"]
  },

  metrics: {
    size: 180,
    successRate: 0.96,
    latencyMsP95: 1200,
    costPer1k: 0.4
  },

  impl: { kind:"local_js", entry:"./agents/rpa_openai_reader.mjs" },

  status: "active",
  weight: 1.0
}
```

### 6.2 注册校验规则（建议强制）

对每个 kind：

1) `caps[kind][i]` 必须存在于 `KindDefs[kind].caps`  
2) 若 `filters[kind]` 存在，则其 key 必须为 `arg`（通常是 `scope.*`），value 按 `arg.type` 校验  
3) 若 agent 声明支持 `arg`，则执行期允许接收该参数（来自 FindVO.filter）

---

## 7. FindVO（查找请求）

### 7.1 推荐结构

```js
{
  kind: "tts",

  // must/prefer：cap 或 arg 都可以（arg 表示必须/偏好“支持该参数”）
  must: ["prosody.emotion","prosody.speed","output.format"],
  prefer: ["prosody.style"],

  // filter：只能写 arg key，并按 KindDef.caps[key].type 校验值
  filter: {
    "prosody.emotion": "calm",
    "output.format": "wav",
    "prosody.speed": 1.2
  },

  // rank：必须在 KindDef.ranks 中
  rank: "size"
}
```

### 7.2 filter 的降级（专用优先 → 通用降级）

对 `arg.allowWildcard:true` 的 `domain_list`（如 `scope.domain`）：

```js
{
  kind:"rpa",
  must:["extract.articleUrls","blockers.cookieDismiss","scope.domain"],
  filter:{ "scope.domain":["www.openai.com","*"] },
  rank:"successRate"
}
```

---

## 8. 路由要点（v0.4）

1) **kind 粗筛**：`agent.kinds` 包含 `vo.kind`，且 `status=active`  
2) **must 硬过滤**：`agent._capsSetByKind[vo.kind].has(mustKey)`  
3) **filter 校验 + 分层筛选**：  
   - key 必须为 `arg`  
   - value 按 `arg.type` 校验  
   - domain_list + allowWildcard 时支持 `["specific","*"]` 分层  
4) **prefer 打分**：prefer 命中越多越好  
5) **rank 排序**：按 `KindDef.ranks[vo.rank]` 取值排序（无 hardcode）  
6) 输出 TopK

---

## 9. 最佳实践（强烈建议）

- `KindDef.caps` 与 `KindDef.ranks` 是权威来源（desc/type/order/valueFrom/missing）  
- Agent 只声明：支持哪些 cap/arg（caps）以及适用范围（filters）  
- FindVO 入口先做校验与归一化（尤其是 filter 的 type 校验）  
- 返回结果附带 reason：用 `desc` 自动生成人类可读解释。
