# Agent Kind / 注册 / 查找机制手册（v0.1）

> 本手册描述：如何定义 **kind（功能大类）**、如何注册 Agent、以及如何给出 `find()` 的查询 VO（Value Object）。  
> 设计目标：在 Agent 数量增多后，仍能 **快速、可控、可降级** 地找到最合适的 Agent。

---

## 0. 总体设计（两级路由）

1. **按 kind 粗筛**：先确定功能大类（例如：TTS / RPA / Image / Chat…）
2. **按能力点 caps 精筛**：用字符串数组描述“支持什么能力/控制项”
3. **按 filter 适用范围/期望值**：支持“专用优先 → 通用降级”（典型：按网站域名 domain）
4. **按 rank 排序**：比如 prefer smaller model

> 约定：**caps 只描述“是否支持某能力点”**；  
> 具体取值、上下文、专用/通用选择走 `filter`。

---

## 1. 术语与命名约定

### 1.1 kind
- 功能大类，用于粗筛。
- 示例：`tts` / `image` / `video` / `chat` / `rpa`

### 1.2 caps（能力点）
- **字符串数组**（运行时会转成 `Set` 加速判断）。
- caps 表示“支持某能力/控制项”，不表达范围精度。
- caps 采用 **局部 key**（不带 kind 前缀），命名建议 `group.name`：
  - TTS 示例：`prosody.speed` / `prosody.emotion` / `output.format`
  - RPA 示例：`extract.articleUrls` / `blockers.cookieDismiss` / `scope.domain`

> 命名空间由 `FindVO.kind` 决定；同名 key 在不同 kind 下的语义由各自 kind spec 管理。

### 1.3 filter（适用范围/期望值）
- 由 key → value 构成（key 为局部 key，不带 kind 前缀）。
- 支持“专用优先 → 通用降级”的写法：**value 为数组**，从最具体到最通用。
  - 典型：`scope.domain: ["www.openai.com", "*"]`

### 1.4 rank（排序规则）
- 用于排序候选 Agent，例如：
  - `size`：prefer smaller model（越小越优先）
  - `successRate`：更稳定优先
  - `latency`：更快优先
  - `cost`：更便宜优先

---

## 2. 如何编写 kind 定义（Kind Spec）

### 2.1 文件组织建议

```
/agent-spec/
  index.js                 // 汇总并导出 KindDefs
  kinds/
    tts.js
    rpa.js
    image.js
    chat.js
```

### 2.2 单个 kind 文件内容（最小集合）

每个 kind 文件导出一个 `KindDef` 对象：

- `kind`: 名称
- `caps`: 允许/推荐的 caps key 列表（用于文档、校验、自动补全）
- `filters`: 允许的 filter key（以及类型/是否允许 wildcard 降级）
- `ranks`: 支持的 rank key

#### 示例：`kinds/tts.js`

```js
export const ttsKind = {
  kind: "tts",

  // 允许的 caps（局部 key）
  caps: [
	"text",
	"prosodyText",
	"gender",
    "prosody.speed",
    "prosody.emotion",
    "prosody.style",
    "voice.source",
    "voice.sourceText",
    "output.format",
    "output.sampleRate",
  ],

  // 可用 filter（局部 key）
  // TTS 的 filter 多为“期望值”，不常见降级，但也可支持
  filters: {
    lang: { type: "enum_or_list", values: ["zh","en","ja"] },
    "output.format": { type: "enum_or_list", values: ["wav","mp3"] },
    "prosody.speed": { type: "number_or_range" },
    "prosody.emotion": { type: "enum", values: ["neutral","calm","happy","sad","angry"] },
    "prosody.style": { type: "enum_or_list" },
  },

  ranks: ["size","successRate","latency","cost"],
};
```

#### 示例：`kinds/rpa.js`

```js
export const rpaKind = {
  kind: "rpa",

  caps: [
    "extract.articleUrls",
    "extract.images",
    "blockers.cookieDismiss",
    "blockers.paywall",
    "auth.login",
    "scope.domain",
  ],

  // RPA 的 scope/filter 常需要降级（domain 专用 -> *）
  filters: {
    "scope.domain": { type: "domain_list", allowWildcard: true }, // ["www.xx.com","*"]
    "blockers.paywall": { type:"enum", values:["none","soft","hard"] },
  },

  ranks: ["size","successRate","latency","cost"],
};
```

### 2.3 汇总：`agent-spec/index.js`

```js
import { ttsKind } from "./kinds/tts.js";
import { rpaKind } from "./kinds/rpa.js";

export const KindDefs = {
  [ttsKind.kind]: ttsKind,
  [rpaKind.kind]: rpaKind,
};
```

---

## 3. 如何注册 Agent（Agent Meta）

### 3.1 Agent 注册对象（JSON）规范

```js
{
  // identity
  id: "tts_say@1.2.0",         // 全局唯一（建议 name@semver）
  name: "SayTTS",

  // kind
  kinds: ["tts"],              // 支持的 kind
  primaryKind: "tts",          // 推荐填写

  // 文档/检索
  desc: "高自然度中文 TTS，支持情绪与语速控制",
  tags: ["zh", "natural", "emotion"],

  // 能力点：每个 kind 一份字符串数组（避免多 kind 歧义）
  caps: {
    tts: ["prosody.speed", "prosody.emotion", "output.format", "prosody.style"]
  },

  // 适用范围/专用信息（可选；RPA 强烈建议）
  // value 支持 ["specific", "*"] 这种降级语法时，一般由 query 的 filter 来触发；
  // agent 侧通常声明自己支持哪些域（专用/通用）
  filters: {
    rpa: { "scope.domain": ["www.openai.com"] }  // 或 ["*"]
  },

  // 路由排序/指标（可选，但强烈建议填）
  metrics: {
    size: 120,                 // prefer smaller
    successRate: 0.93,
    latencyMsP95: 900,
    costPer1k: 0.8
  },

  // 实现信息（按你系统实际需要）
  impl: {
    kind: "local_js|http|python|worker",
    entry: "./agents/xxx.mjs",
    endpoint: "http://127.0.0.1:9001/xxx",
    timeoutMs: 12000
  },

  status: "active|disabled|deprecated",
  weight: 1.0                  // 可选：灰度/偏好权重
}
```

### 3.2 Registry 加载时的归一化（建议强制）

加载 Agent 列表后，执行 `normalizeAgent()`，把数据转换为更适合路由的内存形态：

- 忽略 `status !== "active"`（默认不参与路由）
- `caps[kind]` 做：`trim`、去重
- 构建：`agent._capsSetByKind[kind] = new Set(caps[kind])`（提升 must/prefer 判断效率）
- `filters` 做规范化（比如域名转小写、去空格）

推荐的内存字段（非持久化）：
- `agent._capsSetByKind`
- `agent._filterIndex`（可选：比如把 domain 也做 Set 以加速）

---

## 4. 如何给出 find 的 VO（FindVO）

> FindVO 是一次“找 Agent”的标准输入对象。

### 4.1 推荐结构（清晰版本）

```js
{
  kind: "tts",

  must: ["prosody.emotion","prosody.speed","output.format"],
  prefer: ["prosody.style"],

  // filter 表达期望值/上下文；降级列表用数组（专用优先 -> 通用）
  filter: {
    "prosody.emotion": "calm",
    "output.format": "wav"
  },

  rank: "size" // prefer smaller model
}
```

### 4.2 语法糖版本（可选支持；入口先归一化为 4.1）

```js
{
  kind:"tts",
  must:["prosody.emotion:calm","prosody.speed","output.format"],
  prefer:["prosody.style"],
  rank:"size"
}
```

如果支持语法糖：入口 parse 时将 `"k:v"` 抽到 `filter[k]=v`，并保证 `k` 在 `must` 内（若未包含则补上）。

---

## 5. filter 的降级机制（专用优先 → 通用降级）

### 5.1 典型：RPA 信息源读取按域名降级

```js
{
  kind:"rpa",
  must:["extract.articleUrls","blockers.cookieDismiss"],
  filter:{ "scope.domain":["www.openai.com","*"] },
  rank:"successRate"
}
```

路由语义：
1. 尝试匹配 domain=`www.openai.com` 的候选集（若非空 → 直接使用这层候选继续排序）
2. 若为空 → 尝试 domain=`*`（通用）
3. 仍为空 → 返回失败或触发全局兜底策略

> 降级只对那些标记为 `allowWildcard:true` 的 filter key（在 Kind Spec 中定义）开启。

---

## 6. 路由语义（v0.1）

### 6.1 路由步骤

1) **kind 粗筛**：保留 `agent.kinds` 包含 `vo.kind` 且 `status=active`  
2) **must 硬过滤**：对每个 must key，要求 `agent._capsSetByKind[vo.kind].has(key)`  
3) **filter 分层过滤（若该 key 支持降级）**：如 `scope.domain`  
4) **prefer 打分**：prefer 命中越多越好（简单 +1 即可）  
5) **rank 排序**：按 `rank` 指标排序（例如 size 升序）  
6) 输出 TopK（默认 1 或 3）

### 6.2 rank 参考规则

- `rank:"size"`：按 `agent.metrics.size` 升序（越小越优先）
- `rank:"successRate"`：按 `agent.metrics.successRate` 降序
- `rank:"latency"`：按 `agent.metrics.latencyMsP95` 升序
- `rank:"cost"`：按 `agent.metrics.costPer1k` 升序

缺失指标的处理（建议固定策略）：
- 给一个“较差”的默认值，或者放到队尾（避免随机）

---

## 7. 示例

### 7.1 查找 TTS（calm + 支持语速 + wav）
```js
const vo = {
  kind:"tts",
  must:["prosody.emotion","prosody.speed","output.format"],
  prefer:["prosody.style"],
  filter:{ "prosody.emotion":"calm", "output.format":"wav" },
  rank:"size"
};
```

### 7.2 查找 RPA 信息源读取（openai 专用优先，否则通用）
```js
const vo = {
  kind:"rpa",
  must:["extract.articleUrls","blockers.cookieDismiss"],
  filter:{ "scope.domain":["www.openai.com","*"] },
  rank:"successRate"
};
```

---

## 8. 推荐工程约束（强烈建议）

1) **注册校验**：`caps[kind]` 的 key 必须属于对应 `KindDef.caps`（否则拒绝或报警）  
2) **查询校验**：FindVO 的 `must/prefer/filter` key 必须属于对应 `KindDef`（否则拒绝或忽略并记录日志）  
3) **路由解释**：返回结果建议带 `reason`：
   - 未命中的 must
   - prefer 命中情况
   - filter 走了哪一层（专用 vs 通用）
   - rank 的关键指标值

---

## 9. 版本与扩展（建议）

- 手册版本：v0.1（当前以 caps=字符串数组为主，filter 支持降级列表）
- 后续若需要“按支持范围精确路由”（比如 speed 覆盖范围），建议新增可选 `support` 字段，但不破坏本手册的基本结构。
