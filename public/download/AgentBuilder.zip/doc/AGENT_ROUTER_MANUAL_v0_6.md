# Agent Kind / 注册 / 查找机制手册（v0.6）

> v0.6 更新点：`FindVO.filter` 支持 **对象** 与 **数组** 两种形态，并规定统一的归一化与重复 key 语义（默认 AND）。  
> v0.5 仍保留：`KindDef.defaultRank(s)` 作为 find 未指定 rank 的默认排序策略。  
> v0.4 仍保留：`KindDef.ranks` 为带 meta 的对象表；v0.3 保留：`caps` 中 `kind: "cap" | "arg"`，且 `arg` 必须定义 `type`。

---

## 0. 总体设计（两级路由）

1) **按 kind 粗筛**：先确定功能大类（TTS / RPA / Image / Chat…）  
2) **按能力点 caps 精筛**：Agent 侧仍用字符串数组（运行时转 Set 加速）  
3) **按 filter 表达期望值/上下文**：支持“专用优先 → 通用降级”  
4) **按 rank 排序**：rank 规则由 `KindDef.ranks` 驱动；未指定 rank 时由 `KindDef.defaultRank(s)` 决定

---

## 1. 术语与命名约定

### 1.1 kind
- 功能大类，用于粗筛。
- 示例：`tts` / `image` / `video` / `chat` / `rpa`

### 1.2 caps（能力点）
- Agent 侧：**字符串数组**（运行时会转成 `Set` 加速判断）。
- caps 表示“支持某能力/控制项”，不表达范围精度。
- caps 采用 **局部 key**（不带 kind 前缀），命名建议 `group.name`。

### 1.3 filter（适用范围/期望值）
- key → value（key 为局部 key）。
- **只能用于 `KindDef.caps[key].kind === "arg"` 的 key**，并按其 `type` 校验 value。
- 支持降级列表：例如 `scope.domain: ["www.openai.com", "*"]`
- v0.6：支持对象或数组两种输入（见第 7 节）

### 1.4 rank（排序规则）
- FindVO 的 `rank` 为 rankKey（例如 `size` / `successRate` / `latency` / `cost`）或 rankKey 数组（可选扩展）。
- rankKey 必须存在于 `KindDef.ranks`，路由器根据 meta 实施排序。

---

## 2. KindDef（kind 规范定义）

`KindDef` 至少包含：

- `kind`: 名称
- `caps`: 定义表（key -> meta，meta 至少含 `desc` 与 `kind`）
- `ranks`: 排序定义表（rankKey -> meta）
- `defaultRank`: （可选）FindVO 未指定 rank 时使用的默认 rankKey  
- `defaultRanks`:（可选）默认多级排序（建议优先于 defaultRank）

---

## 3. caps：cap / arg 规范（v0.3 延续）

### 3.1 cap meta（能力开关）

```js
{
  kind: "cap",
  desc: "一句话说明"
}
```

### 3.2 arg meta（参数能力）

```js
{
  kind: "arg",
  type: "enum | enum_or_list | number | number_or_range | domain_list | string | string_or_list",
  values: ["..."],        // enum/enum_or_list 需要
  allowWildcard: true,    // domain_list 常用，允许 "*" 作为通用
  desc: "一句话说明"
}
```

---

## 4. ranks：排序定义表（v0.4 延续）

rank meta 推荐字段：

- `desc`
- `order`: `"asc"` / `"desc"`
- `valueFrom`: `"metrics.xxx"`
- `type`: `"number"`
- `missing`: `"last" | "default" | "reject"`
- `defaultValue`（missing=default 时）

---

## 5. 未指定 rank 的默认行为（v0.5 延续）

当 `FindVO.rank` 缺失时，默认排序策略：

1) `FindVO.rank` 存在 → 使用它  
2) 否则 `KindDef.defaultRanks` 存在 → 使用它  
3) 否则 `KindDef.defaultRank` 存在 → 使用它  
4) 否则全局默认：`["successRate","latency","size"]`（跳过未定义的 rankKey）  
5) 永远追加 tie-break：`id` 升序

---

## 6. 注册 Agent（简述）

Agent 侧：

- `caps[kind]`: 字符串数组（包含 cap 与 arg key）
- `filters[kind]`: Agent 自己的适用范围声明（通常只写少数 scope 类 arg，如 `scope.domain`）
- Registry 加载时把 `caps[kind]` 构建为 `Set`：`agent._capsSetByKind[kind]`

---

## 7. FindVO.filter 的双形态支持（v0.6 新增）

### 7.1 FindVO 基本结构（filter 可为 object 或 array）

```js
{
  kind: "rpa",
  must: ["extract.articleUrls","blockers.cookieDismiss","scope.domain"],
  filter: { "scope.domain":["www.openai.com","*"] }   // object 形态
  // rank 可省略
}
```

或：

```js
{
  kind: "rpa",
  must: ["extract.articleUrls","blockers.cookieDismiss","scope.domain"],
  filter: [
    { key:"scope.domain", value:["www.openai.com","*"] },   // array 形态
    { key:"blockers.paywall", value:"soft" }
  ]
}
```

### 7.2 归一化规则（强烈建议：入口统一归一化，路由只处理一种结构）

将两种形态统一为：

- `FilterMap`: `key -> values[]`（每个 key 对应一个 value 列表）
- object 形态会被视为每个 key 只有 1 个 value：`values=[v]`
- array 形态允许同一个 key 出现多次，会收集到同一个 `values[]` 中

归一化后示例：

```js
{
  "scope.domain": [ ["www.openai.com","*"] ],
  "blockers.paywall": [ "soft" ]
}
```

### 7.3 重复 key 的默认语义（AND）

当同一个 key 在 filter 中出现多次（array 形态常见）：

- **默认语义：AND**  
  即：同一个 key 的多条约束需要逐条应用筛选（都要满足）。

> 如果未来需要 OR，可在 value 内表达（例如枚举列表），或扩展 `{op:"or"}`，但 v0.6 默认先不引入。

### 7.4 降级列表（tiered filter）

对于 `arg.type === "domain_list"` 且 `allowWildcard:true` 的 key（例如 `scope.domain`）：

- 如果某次约束的 value 是数组 `["specific","*"]`，则按顺序分层筛选：
  1) 尝试 `specific`（若候选非空即停止降级）
  2) 否则尝试 `*`
  3) 仍为空 → 失败（候选为空）

---

## 8. 路由流程要点（v0.6）

1) kind 粗筛：`agent.kinds` 包含 `vo.kind` 且 `status=active`  
2) must 硬过滤：`agent._capsSetByKind[vo.kind].has(mustKey)`  
3) filter 校验 + 筛选：  
   - filter 先归一化为 FilterMap  
   - key 必须为 `arg`  
   - value 按 `arg.type` 校验  
   - 对每个 key 的 values[] 逐条应用（AND）  
   - tiered filter（降级数组）按层筛选  
4) prefer 打分：prefer 命中越多越好  
5) rank 排序：使用 `vo.rank` 或 `KindDef.defaultRank(s)` 或全局默认；永远追加 tie-break：`id`  
6) 输出 TopK

---

## 9. 参考：filter 归一化函数（伪代码）

```js
function normFilter(f){
  if(!f) return {};
  if(Array.isArray(f)){
    const out = {};
    for(const it of f){
      if(!it || !it.key) continue;
      const k = String(it.key).trim();
      if(!k) continue;
      (out[k] ||= []).push(it.value);
    }
    return out;
  }
  if(typeof f === "object"){
    const out = {};
    for(const [k,v] of Object.entries(f)){
      const kk = String(k).trim();
      if(!kk) continue;
      out[kk] = [v];
    }
    return out;
  }
  return {};
}
```

---

## 10. 最佳实践

- `KindDef.caps` 与 `KindDef.ranks` 是权威来源（desc/type/order/valueFrom/missing/defaultRanks）  
- Agent 只声明：支持哪些 cap/arg（caps）以及适用范围（filters）  
- FindVO 入口先做校验与归一化（尤其 filter 的 type 校验与归一化）  
- 返回结果附带 reason：用 `desc` 自动生成人类可读解释。
