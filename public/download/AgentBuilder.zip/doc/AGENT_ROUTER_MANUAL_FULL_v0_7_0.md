# Agent Router Manual (FULL) — Kind / Specs / Registry / FindVO / Routing (v0.7.0)

本文件是一份 **可独立阅读的完整手册**。  
目标：在 Agent 数量变多后，仍能用 **统一规范** 快速、稳定、可解释地找到最合适的 Agent。

---

## 0. 总体设计

路由分 5 层：

1) **kind 粗筛**：先确定功能大类（TTS / RPA / Image / …）  
2) **must 硬过滤**：必须支持的能力点（cap/arg）  
3) **filter 约束与降级**：对参数（arg）进行值约束，并支持“专用优先 → 通用降级”  
4) **prefer 加分**：偏好能力点命中越多越好  
5) **rank 排序**：按系统统一的 rankKey（从 agent.ranks 取 0~10 分）排序；未指定 rank 时使用默认排序，并保证稳定 tie-break

---

## 1. 术语与约定

### 1.1 kind
- 功能大类，用于粗筛。
- 示例：`tts` / `rpa` / `image` / `chat` / `asr` / `video` …

### 1.2 cap key（能力点 key）
- **局部 key**：不带 kind 前缀，命名建议 `group.name`
- 例：
  - TTS：`prosody.speed` / `prosody.emotion` / `output.format`
  - RPA：`extract.articleUrls` / `blockers.cookieDismiss` / `scope.domain`

> key 的语义由 `KindDef` 管理；同名 key 在不同 kind 下可能语义不同，但只在各自 kind 内使用。

### 1.3 cap vs arg
在 `KindDef.caps` 中，每个 key 必须声明为两种之一：

- `kind:"cap"`：开关型能力（存在即支持）
- `kind:"arg"`：参数能力（支持该参数的传入），并必须带 `type`（用于 filter 校验）

### 1.4 filter
- 表达期望参数值/上下文约束。
- **只能约束 `arg` key**（即 `KindDef.caps[key].kind === "arg"`）。
- v0.6.1：支持两种输入形态：
  - `filter: {key:value, ...}`（对象）
  - `filter: [{key, value}, ...]`（数组，允许重复 key）

### 1.5 rank
- 表示“怎么排序候选 Agent”。
- `FindVO.rank` 只提供 **rankKey 或 rankKey 列表**，系统按顺序进行多级排序。
- 排序值来自 `agent.ranks[rankKey]`，其为 **0~10 的分数**，且 **10 最好**（统一按 desc 排序）。
- 系统内置统一的基础 rankKey：
  - `overallScore`：综合评分（推荐默认）
  - `quality`：质量/精度/稳定性等综合质量
  - `speed`：速度（由 metrics.speed 等 raw 指标换算）
  - `cost`：成本（由 costPerCall / costPer1M 等 raw 指标折算）
  - `size`：体积（越小越好，换算成 size 分）

---


## 2. 文件组织建议

```
/agent-spec/
  index.js                 // 汇总并导出 KindDefs
  kinds/
    tts.js
    rpa.js
    image.js
    ...
/agents/
  ...                      // agent 实现
```

---

## 3. KindDef 规范（权威定义）

### 3.1 KindDef 结构

`KindDef` 至少包含：

- `kind: string`
- `caps: { [capKey]: CapMeta }`
- `defaultRank?: string`
- `defaultRanks?: string[]`

> 推荐：优先使用 `defaultRanks`（多级排序更稳定）。

### 3.2 CapMeta（cap/arg）

#### cap
```js
{
  kind: "cap",
  desc: "一句话说明"
}
```

#### arg（必须带 type）
```js
{
  kind: "arg",
  type: "enum | enum_or_list | number | number_or_range | domain_list | string | string_or_list",
  values?: string[],       // enum/enum_or_list 需要
  allowWildcard?: boolean, // domain_list 常用，允许 "*" 作为通用
  desc: "一句话说明"
}
```

### 3.3 推荐的 type 集合

- `enum`：单个枚举值（string）
- `enum_or_list`：枚举值或枚举数组
- `number`：数字
- `number_or_range`：数字或 `{min,max}`（执行期可夹逼）
- `string`：字符串
- `string_or_list`：字符串或字符串数组
- `domain_list`：域名列表（通常配 `allowWildcard:true`，允许 `*`）

---

## 4. Metrics & Ranks（统一指标与评分）

本版本将“排序指标”拆成两层：

- `agent.metrics`：**raw 指标（由 Agent 上报）**，用于系统换算。
- `agent.ranks`：**0~10 分（由系统计算）**，用于路由排序。全部是 **10 最好**。

### 4.1 agent.metrics（raw，扁平，不嵌套）

字段（建议）：

- `quality: number`  
  原始质量信号（口径由系统约定，例如 0~1 或 0~100；建议全局统一）。

- `speed: number`  
  **原始速度指标**，推荐定义为：**P95 响应时延（ms）**。  
  > 注意：字段名叫 speed，但数值语义是“耗时（ms）”，因此 **越小越好**。

- `size: number`  
  原始体积指标（建议统一用 bytes；或统一用 paramsCount，但只能选一种）。

- `costPerCall?: number`  
  每次调用成本（例如 USD / call）。

- `costPer1M?: number`  
  每 1M token（或等价单位）的成本（例如 USD / 1M tokens）。

> 兼容扩展：如果你需要区分输入/输出成本，也可加 `costPer1MIn` / `costPer1MOut`（仍保持扁平）。

### 4.2 agent.ranks（score，扁平，不嵌套）

字段（系统写入）：

- `quality: number`（0~10）
- `speed: number`（0~10）
- `cost: number`（0~10）
- `size: number`（0~10）
- `overallScore: number`（0~10）
- `ver: string`（评分算法版本，例如 `"v1"`）

规则：

- **所有 ranks 分数：10 最好，0 最差**。
- 路由排序一律按 **desc**（无需每个 rankKey 单独声明 asc/desc）。
- missing 策略：缺失分数按 `last` 处理（排在后面），并记录 reason 便于 debug。

### 4.3 评分计算（建议语义）

系统在以下时机计算/更新 ranks：

- Agent 注册/更新后（或定时批处理）
- metrics 发生变化（成本/延迟/成功率统计更新）后

评分思路（建议）：

- raw 指标 → 分数：用固定阈值或分位数归一化到 0~10  
  - 例如 `speed(ms)`：越小分越高  
  - `size(bytes)`：越小分越高  
  - `cost(perCall/per1M)`：越小分越高  
  - `quality`：越大分越高
- `overallScore`：对 `quality/speed/cost/size` 加权平均（权重可全局默认，也可按 kind 配置）

> 重要：`overallScore` 的意义是“系统综合偏好”，而不是单纯质量；它应综合考虑 quality / speed / cost / size。

---

## 5. 示例 KindDef

### 5.1 `kinds/tts.js`

```js
export const ttsKind = {
  kind: "tts",

  caps: {
    // cap
    "prosody.pauseControl": { kind:"cap", desc:"支持停顿/断句控制（SSML break 或等价能力）" },
    "voice.clone": { kind:"cap", desc:"支持音色克隆/声音复刻" },

    // arg
    "lang": { kind:"arg", type:"enum_or_list", values:["zh","en","ja"], desc:"语言（或语言列表）" },
    "prosody.speed": { kind:"arg", type:"number_or_range", desc:"语速（1.0 为正常语速）" },
    "prosody.emotion": { kind:"arg", type:"enum", values:["neutral","calm","happy","sad","angry"], desc:"情绪/语气" },
    "prosody.style": { kind:"arg", type:"string_or_list", desc:"风格/场景预设（如 narration/customer_service）" },
    "output.format": { kind:"arg", type:"enum_or_list", values:["wav","mp3"], desc:"输出格式" },
    "output.sampleRate": { kind:"arg", type:"number", desc:"采样率（如 24000/48000）" },
  },

  // find 未指定 rank 时使用（rankKey 统一来自 agent.ranks）
  defaultRanks: ["overallScore", "quality", "speed"]
};
```

---

## 6. Agent 注册对象（Agent Meta）

### 6.1 持久化字段（建议）

```js
{
  id: "rpa_source_openai@1.0.0",
  name: "OpenAI Source Reader",

  kinds: ["rpa"],
  primaryKind: "rpa",

  desc: "适配 openai.com 的信息源列表提取",
  tags: ["source","openai","extract_urls"],

  // 能力点：每个 kind 一份字符串数组（包含 cap 与 arg key）
  caps: {
    rpa: ["extract.articleUrls", "blockers.cookieDismiss", "scope.domain"]
  },

  // 适用范围声明（Agent 自己的范围，不是查询 filter）
  // 通用 agent 写 ["*"]，专用 agent 写具体域
  filters: {
    rpa: { "scope.domain": ["www.openai.com"] } // 通用则 ["*"]
  },

  // raw 指标（可选但推荐；用于系统计算 ranks）
  metrics: {
    quality: 0.93,
    speed: 220,       // P95 响应时延（ms，越小越好）
    size: 350000000,  // bytes（或 paramsCount，但需全局统一）
    costPerCall: 0.002,
    costPer1M: 3.0
  },

  // 系统计算后的分数（0~10，10最好；可为空，系统写入/刷新）
  ranks: {
    quality: 9.2,
    speed: 6.1,
    cost: 8.8,
    size: 7.4,
    overallScore: 8.0,
    ver: "v1"
  },

  // 实现信息（按你的系统需要）
  impl: { kind:"local_js|http|python|worker", entry:"./agents/rpa_openai_reader.mjs", endpoint:"...", timeoutMs:12000 },

  status: "active|disabled|deprecated",
  weight: 1.0
}
```

### 6.2 注册校验（建议强制）

对每个 kind：

1) `caps[kind][i]` 必须存在于 `KindDefs[kind].caps`  
2) `filters[kind]` 的 key 必须是 `arg`（通常是 `scope.*`），其 value 按 `arg.type` 校验  
3) 若 Agent 宣称支持某个 `arg`（caps 包含该 key），执行期才允许把该参数传给该 Agent

---

## 7. FindVO（查找请求对象）

### 7.1 FindVO 字段

- `kind: string`（必填）
- `must?: string[]`（可空数组；cap/arg 都可）
- `prefer?: string[]`（可选；cap/arg 都可，命中加分）
- `filter?: object | Array<{key:string,value:any}>`（可选；只能约束 arg key）
- `rank?: string | string[]`（可选；缺省使用 KindDef.defaultRank(s)）

### 7.2 示例（完整）

```js
{
  kind: "tts",
  must: ["prosody.emotion","prosody.speed","output.format"],
  prefer: ["prosody.style","voice.clone"],
  filter: { "prosody.emotion":"calm", "output.format":"wav", "prosody.speed": 1.2 }
  // rank 可省略
}
```

### 7.3 filter 数组形态（允许重复 key）

```js
{
  kind: "rpa",
  must: ["extract.articleUrls","blockers.cookieDismiss","scope.domain"],
  prefer: ["extract.images"],
  filter: [
    { key:"scope.domain", value:["www.openai.com","*"] },
    { key:"blockers.paywall", value:"soft" }
  ],
  rank: "overallScore"
}
```

---

## 8. filter 归一化与语义（v0.6.1）

### 8.1 为什么要归一化
路由核心逻辑建议只处理一种结构，因此入口先把 filter 统一成 `FilterMap`：

- `FilterMap`: `key -> values[]`

### 8.2 归一化规则
- object → `key -> [value]`
- array  → `key -> [value1, value2, ...]`

示例：
```js
// 输入（数组）
filter: [
  {key:"scope.domain", value:["www.openai.com","*"]},
  {key:"blockers.paywall", value:"soft"}
]

// 归一化后
{
  "scope.domain": [ ["www.openai.com","*"] ],
  "blockers.paywall": [ "soft" ]
}
```

### 8.3 重复 key 的默认语义：AND
同一 key 出现多次时，逐条应用筛选（都要满足）。

> OR 暂不内置；如需 OR，优先通过 value 表达（例如枚举列表），或未来扩展 `{op:"or"}`。

### 8.4 tiered filter（降级列表）
对 `arg.type === "domain_list"` 且 `allowWildcard:true` 的 key（如 `scope.domain`）：

- 如果某条约束的 value 是数组 `["specific","*"]`，按顺序分层筛选：
  1) 先用 `specific` 筛选（若候选非空就停）
  2) 否则用 `*`（通用）
  3) 若仍为空 → 返回空候选（失败）

---

## 9. rank 缺省策略（v0.5）

当 `FindVO.rank` 缺失时，排序 key 选择顺序：

1) `FindVO.rank`  
2) `KindDef.defaultRanks`  
3) `KindDef.defaultRank`  
4) 全局默认：`["overallScore","quality","speed","cost","size"]`（缺失分数按 last 处理）  
5) 永远追加稳定 tie-break：`id` 升序（避免抖动）

---

## 10. 路由流程（建议实现语义）

对一次 FindVO，路由器按以下流程：

1) **kind 粗筛**：保留 `agent.kinds` 包含 `vo.kind` 且 `status=active`  
2) **must 硬过滤**：每个 mustKey 需 `agent._capsSetByKind[kind].has(mustKey)`  
3) **filter 校验 + 筛选**：  
   - `filter` 归一化为 FilterMap  
   - key 必须为 `arg`（否则拒绝/忽略并记录）  
   - value 按 `arg.type` 校验（不通过则拒绝/忽略并记录）  
   - 同 key 的 values[] 按 AND 逐条应用  
   - tiered filter 按层降级筛选  
4) **prefer 加分**：对每个 preferKey，若命中则 +1（或固定权重）  
5) **rank 排序**：  
   - 根据 rankKey(s) 依次取 `agent.ranks[rankKey]`（0~10，10最好）做 desc 排序；缺失按 last  
   - 最后追加 `id` 升序作为 tie-break  
6) 输出 TopK（默认 1 或 3）

---

## 11. 执行期参数构造（建议）

路由选出 agent 后，执行器构造 canonical 参数：

- 取 `FindVO.filter` 中所有参数（归一化后）
- 仅保留该 agent 支持的 `arg`（即 agent.caps[kind] 包含该 arg key）
- 交由 agent 的 adapter 将 canonical 参数映射到具体引擎/服务参数

这样：
- `KindDef` 负责：参数定义（type/desc）  
- `FindVO.filter` 负责：需求表达  
- `Agent.caps` 负责：是否支持该参数  
- adapter 负责：参数翻译

---

## 12. Debug / reason（强烈建议）

路由结果建议返回 `{agent, score, reason}`，其中 reason 至少包含：

- must 未命中的 key（可用 `KindDef.caps[key].desc` 转成人话）
- filter 使用了哪一层（例如 domain 命中 specific 还是降级到 `*`）
- prefer 命中列表与得分
- rank 关键分数取值（agent.ranks）与 raw 指标（agent.metrics，便于解释换算）

---

## 13. 附：filter 归一化伪代码

```js
function normFilter(f){
  if(!f) return {};
  if(Array.isArray(f)){
    const out = {};
    for(const it of f){
      if(!it || !it.key) continue;
      const k = String(it.key).trim();
      if(!k) continue;
      (out[k] ||= []).push(it.value);
    }
    return out;
  }
  if(typeof f === "object"){
    const out = {};
    for(const [k,v] of Object.entries(f)){
      const kk = String(k).trim();
      if(!kk) continue;
      out[kk] = [v];
    }
    return out;
  }
  return {};
}
```
