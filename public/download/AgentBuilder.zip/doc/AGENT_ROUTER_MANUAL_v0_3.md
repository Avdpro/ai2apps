# Agent Kind / 注册 / 查找机制手册（v0.3）

> v0.3 更新点：`KindDef.caps` 里的条目引入两种语义：`kind: "cap" | "arg"`  
> - `cap`：是否具备某种能力（开关型能力）  
> - `arg`：是否支持某种“可传入的参数”（也是能力），并 **携带参数类型定义 type（与 filter 一致）**  
>
> 目的：把“能力点”与“可用参数”同时定义清楚，便于校验、UI、自动补全、路由解释与执行期参数构造。

---

## 0. 总体设计（两级路由）

1) **按 kind 粗筛**：先确定功能大类（TTS / RPA / Image / Chat…）  
2) **按能力点 caps 精筛**：Agent 侧仍用字符串数组（运行时转 Set 加速）  
3) **按 filter 表达期望值/上下文**：支持“专用优先 → 通用降级”  
4) **按 rank 排序**：例如 prefer smaller model

> 约定（关键）：
> - Agent 的 `caps[kind]` 是字符串数组：既可以包含 `cap`，也可以包含 `arg`（表示该 Agent 支持这些参数）。
> - 查询端的 `filter` 只能写 **在 KindDef 中声明为 `arg` 的 key**，并按其 `type` 校验值。

---

## 1. KindDef（kind 规范定义）

### 1.1 KindDef 结构

`KindDef` 至少包含：

- `kind`: 名称
- `caps`: **定义表**（对象：`key -> meta`，meta 至少含 `desc` 与 `kind`）
- `ranks`: 支持的 rank key

其中 `caps[key].kind` 只有两种：

- `"cap"`：能力开关（存在即支持）
- `"arg"`：参数能力（支持该参数，并定义参数类型 `type`）

> v0.3 建议：**不再单独维护 `filters` 字段**。  
> 因为 `filter` 的 key/value 校验直接基于 `caps` 里 `kind:"arg"` 的 `type` 完成。

---

## 2. cap / arg 的 meta 规范

### 2.1 cap meta（能力开关）

```js
{
  kind: "cap",
  desc: "一句话说明",
  examples: ["must: ['blockers.cookieDismiss']"]
}
```

### 2.2 arg meta（参数能力）

arg 额外必须包含 `type`，其语义与查询 `filter` 里允许的值保持一致：

```js
{
  kind: "arg",
  type: "enum | enum_or_list | number | number_or_range | domain_list | string | string_or_list",
  values: ["..."],        // 仅 enum/enum_or_list 需要
  allowWildcard: true,    // 仅 domain_list 常用；允许 "*" 作为通用
  desc: "一句话说明",
  examples: ["filter: {'prosody.speed': 1.2}"]
}
```

### 2.3 推荐的 type 集合（足够覆盖大多数）

- `enum`：单个枚举值（string）
- `enum_or_list`：枚举值或枚举列表
- `number`：数字
- `number_or_range`：数字或 `{min,max}`（执行期可夹逼）
- `string`：字符串
- `string_or_list`：字符串或字符串数组
- `domain_list`：域名列表（常配 `allowWildcard:true`，支持 `["a.com","*"]`）

---

## 3. 示例 KindDef

### 3.1 `kinds/tts.js`

```js
export const ttsKind = {
  kind: "tts",
  caps: {
    // ---- cap：开关能力 ----
    "prosody.pauseControl": { kind:"cap", desc:"支持停顿/断句控制（例如 SSML break 或等价能力）" },
    "voice.clone": { kind:"cap", desc:"支持音色克隆/声音复刻" },

    // ---- arg：参数能力（支持参数 + 参数类型）----
    "lang": { kind:"arg", type:"enum_or_list", values:["zh","en","ja"], desc:"语言（或语言列表）" },
    "prosody.speed": { kind:"arg", type:"number_or_range", desc:"语速（1.0 为正常语速）" },
    "prosody.emotion": { kind:"arg", type:"enum", values:["neutral","calm","happy","sad","angry"], desc:"情绪/语气" },
    "prosody.style": { kind:"arg", type:"string_or_list", desc:"风格/场景预设（如 narration/customer_service）" },
    "output.format": { kind:"arg", type:"enum_or_list", values:["wav","mp3"], desc:"输出格式" },
    "output.sampleRate": { kind:"arg", type:"number", desc:"采样率（如 24000/48000）" },
  },
  ranks: ["size","successRate","latency","cost"],
};
```

### 3.2 `kinds/rpa.js`

```js
export const rpaKind = {
  kind: "rpa",
  caps: {
    // cap
    "extract.articleUrls": { kind:"cap", desc:"从信息源页面提取文章 URL 列表" },
    "extract.images": { kind:"cap", desc:"提取图片/封面等媒体资源" },
    "blockers.cookieDismiss": { kind:"cap", desc:"处理 cookie/弹窗同意等拦截" },

    // arg（scope/上下文参数也归入 arg，方便 filter 校验与降级）
    "scope.domain": { kind:"arg", type:"domain_list", allowWildcard:true, desc:"目标域名，支持 ['a.com','*'] 降级" },
    "blockers.paywall": { kind:"arg", type:"enum", values:["none","soft","hard"], desc:"期望处理的付费墙等级" },
  },
  ranks: ["size","successRate","latency","cost"],
};
```

---

## 4. 注册 Agent（Agent Meta）

### 4.1 Agent JSON 规范

```js
{
  id: "rpa_source_openai@1.0.0",
  name: "OpenAI Source Reader",

  kinds: ["rpa"],
  primaryKind: "rpa",

  desc: "适配 openai.com 的信息源列表提取",
  tags: ["source","openai","extract_urls"],

  // caps：字符串数组（同时包含 cap 与 arg key）
  // 规则：Agent 声明自己支持哪些能力与哪些参数
  caps: {
    rpa: ["extract.articleUrls", "blockers.cookieDismiss", "scope.domain"]
  },

  // filters：Agent 自己的“适用范围声明”（不是查询 filter）
  // 常用于专用/通用区分；domain 专用 agent 填具体域名，通用 agent 填 "*"
  filters: {
    rpa: { "scope.domain": ["www.openai.com"] } // 或 ["*"]
  },

  metrics: {
    size: 180,
    successRate: 0.96,
    latencyMsP95: 1200
  },

  impl: { kind:"local_js", entry:"./agents/rpa_openai_reader.mjs" },

  status: "active",
  weight: 1.0
}
```

### 4.2 注册校验规则（建议强制）

对每个 kind：

1) `caps[kind][i]` 必须存在于 `KindDefs[kind].caps`  
2) 若 `caps[kind][i]` 对应 `kind:"arg"`，表示该 Agent **支持接收该参数**  
3) `filters[kind]` 的 key 也必须存在于 `KindDefs[kind].caps` 且为 `arg`（例如 `scope.domain`）

---

## 5. FindVO（查找请求）

### 5.1 FindVO 基本结构（推荐）

```js
{
  kind: "tts",

  // must/prefer：仍然是能力 key 列表（可包含 cap 或 arg）
  // - cap：必须具备能力
  // - arg：必须支持该参数（即 agent.caps 中必须包含该 arg key）
  must: ["prosody.emotion","prosody.speed","output.format"],
  prefer: ["prosody.style"],

  // filter：只能写 arg key，并且按 KindDef.caps[key].type 校验值
  filter: {
    "prosody.emotion": "calm",
    "output.format": "wav",
    "prosody.speed": 1.2
  },

  rank: "size"
}
```

### 5.2 filter 的降级（专用优先 → 通用降级）

对 `allowWildcard:true` 的 `arg`（例如 `scope.domain`）允许数组表达：

```js
{
  kind:"rpa",
  must:["extract.articleUrls","blockers.cookieDismiss","scope.domain"],
  filter:{ "scope.domain":["www.openai.com","*"] },
  rank:"successRate"
}
```

语义：
1) 先尝试匹配 `www.openai.com` 的候选（若非空就停在该层）  
2) 否则降级到 `*`（通用）

---

## 6. 路由要点（v0.3）

### 6.1 must / prefer 的语义

- `must`：必须命中 `agent.caps[kind]`（用 Set.has 加速）
- `prefer`：命中越多越好（+1 打分即可）

> 因为 arg 也是能力：`must` 里写 arg key 等价于“必须支持这个参数”。

### 6.2 filter 的语义

- filter 的 key 必须是 `KindDef.caps[key].kind === "arg"`  
- filter 的 value 按 `type` 进行校验（避免错误参数进入执行层）
- 对于 `domain_list` 且 `allowWildcard:true`：支持值为数组进行分层降级筛选

### 6.3 执行期参数构造（把“参数定义明白”）

路由选出 agent 后，执行器可以用以下规则构造“给 agent 的参数对象”：

- 取 `filter` 中所有 key
- 仅保留该 agent 支持的 arg（即 `agent.caps[kind]` 包含该 arg key）
- 将它们作为 canonical 参数传给 `agent.impl` 的 adapter

这样：
- KindDef 负责：**参数定义、类型、描述**
- Agent 负责：**arg 是否支持（caps 包含与否）** + **如何把 canonical 参数映射到自己的引擎参数**

---

## 7. rank 规则（建议）

- `size`：`metrics.size` 升序（越小越优先）
- `successRate`：`metrics.successRate` 降序
- `latency`：`metrics.latencyMsP95` 升序
- `cost`：`metrics.costPer1k` 升序

缺失指标：建议固定策略（例如默认排到后面）。

---

## 8. 最佳实践（强烈建议）

1) `KindDef.caps` 永远是“权威来源”（desc/type/allowWildcard 在这里）  
2) Agent 只声明自己支持哪些 key（caps）以及适用范围（filters）  
3) FindVO 入口先做校验与归一化：
   - must/prefer key 存在性校验
   - filter key 必须为 arg
   - filter value 按 type 校验
4) 返回结果附带 reason，路由解释可用 KindDef 的 desc 自动生成。

