//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {UIChat} from "/@aichat/ui/UIChat.js";
/*#{1IUO8DALG0StartDoc*/
/*}#1IUO8DALG0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let ShadowUI=function(app,appFrame){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let boxAIChat;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let chatThread=null;
	let chatClient=null;
	
	/*#{1IUO8DALG1LocalVals*/
	/*}#1IUO8DALG1LocalVals*/
	
	/*#{1IUO8DALG1PreState*/
	/*}#1IUO8DALG1PreState*/
	/*#{1IUO8DALG1PostState*/
	/*}#1IUO8DALG1PostState*/
	cssVO={
		"hash":"1IUO8DALG1",nameHost:true,
		"type":"hud","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y","itemsAlign":1,
		children:[
			{
				"hash":"1IUO8EIBB0",
				"type":UIChat({"bubble":false,"ai":{"blkColor":[0,0,0,0],"bgColor":cfgColor["success"],"icon":appCfg.sharedAssets+"/faces.svg","pic":"","textColor":cfgColor["fontBody"],"iconColor":cfgColor["fontSuccess"],"side":"left"},"user":{"blkColor":[0,0,0,0],"bgColor":cfgColor.primary,"icon":appCfg.sharedAssets+"/user.svg","pic":"","textColor":cfgColor["fontBody"],"iconColor":cfgColor["fontPrimary"],"side":"right"},"wait":{"blkColor":[0,0,0,0],"bgColor":cfgColor["secondary"],"icon":appCfg.sharedAssets+"/faces.svg","pic":"","textColor":cfgColor["fontBody"],"iconColor":cfgColor["fontSecondary"],"side":"left"},"event":{"blkColor":[0,0,0,0],"bgColor":cfgColor["warning"],"icon":appCfg.sharedAssets+"/event.svg","pic":"","textColor":cfgColor["fontBody"],"iconColor":cfgColor["fontWarning"],"side":"left"},"error":{"blkColor":[0,0,0,0],"bgColor":cfgColor["error"],"icon":appCfg.sharedAssets+"/fat_right.svg","pic":"","textColor":[155,0,0,1],"iconColor":cfgColor["fontError"],"side":"left"},"ask":{"blkColor":[0,0,0,0],"bgColor":cfgColor["success"],"icon":appCfg.sharedAssets+"/help.svg","pic":"","textColor":cfgColor["fontBody"],"iconColor":cfgColor["fontSuccess"],"side":"left"},"allowFile":false}),
				"id":"BoxAIChat","x":0,"y":0,"maxW":1200,
			}
		],
		/*#{1IUO8DALG1ExtraCSS*/
		/*}#1IUO8DALG1ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			self=this;
			boxAIChat=self.BoxAIChat;
			/*#{1IUO8DALG1Create*/
			let params;
			params=app.appParams;
			chatThread=params.chatThread;
			chatClient=chatThread.client;
			self.showThread();
			/*}#1IUO8DALG1Create*/
		},
		/*#{1IUO8DALG1EndCSS*/
		/*}#1IUO8DALG1EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.showThread=async function(){
		/*#{1IUO8FP340Start*/
		boxAIChat.initChatThread(chatThread);
		/*}#1IUO8FP340Start*/
	};
	//------------------------------------------------------------------------
	cssVO.addNewMessage=async function(){
		/*#{1IUO8NHVO0Start*/
		/*}#1IUO8NHVO0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.askUser=async function(){
		/*#{1IUO8NSH30Start*/
		/*}#1IUO8NSH30Start*/
	};
	//------------------------------------------------------------------------
	cssVO.userReply=async function(){
		/*#{1IUO8OJ9P0Start*/
		/*}#1IUO8OJ9P0Start*/
	};
	/*#{1IUO8DALG1PostCSSVO*/
	/*}#1IUO8DALG1PostCSSVO*/
	cssVO.constructor=ShadowUI;
	return cssVO;
};
/*#{1IUO8DALG1ExCodes*/
/*}#1IUO8DALG1ExCodes*/

//----------------------------------------------------------------------------
ShadowUI.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1IUO8DALG1PreAISpot*/
	/*}#1IUO8DALG1PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1IUO8DALG1PostAISpot*/
	/*}#1IUO8DALG1PostAISpot*/
	return exposeVO;
};

/*#{1IUO8DALG0EndDoc*/
/*}#1IUO8DALG0EndDoc*/

export default ShadowUI;
export{ShadowUI};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1IUO8DALG0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1IUO8DALH0",
//			"attrs": {
//				"device": "Desktop 800x600",
//				"screenW": "800",
//				"screenH": "600",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1IUO8DALH1",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1IUO8DALH2",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1IUO8DALH3",
//			"attrs": {
//				"app": {
//					"type": "auto",
//					"valText": ""
//				},
//				"appFrame": {
//					"type": "auto",
//					"valText": ""
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1IUO8DALH4",
//			"attrs": {
//				"chatThread": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"chatClient": {
//					"type": "auto",
//					"valText": "null"
//				}
//			}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1IUO8DALH5",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IUO8FP340",
//					"attrs": {
//						"id": "showThread",
//						"label": "New AI Seg",
//						"x": "90",
//						"y": "95",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IUO8ODCF0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IUO8ODCF1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IUO8ODCF2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IUO8NHVO0",
//					"attrs": {
//						"id": "addNewMessage",
//						"label": "New AI Seg",
//						"x": "90",
//						"y": "185",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IUO8ODCF3",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IUO8ODCF4",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IUO8ODCF5",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IUO8NSH30",
//					"attrs": {
//						"id": "askUser",
//						"label": "New AI Seg",
//						"x": "90",
//						"y": "285",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IUO8ODCF6",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IUO8ODCF7",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IUO8ODCF8",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IUO8OJ9P0",
//					"attrs": {
//						"id": "userReply",
//						"label": "New AI Seg",
//						"x": "300",
//						"y": "285",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IUO8OSSR0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IUO8OSSR1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IUO8OSSR2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				}
//			]
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1IUO8DALH6",
//			"attrs": {}
//		},
//		"mockupStates": {
//			"jaxId": "1IUO8DALH7",
//			"attrs": {}
//		},
//		"exposeToAI": "true",
//		"descAI": "",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1IUO8DALG1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1IUO8DALH8",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "100%",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Flex Y",
//						"subAlign": "Start",
//						"itemsAlign": "Center"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "Gear/@aichat/ui/UIChat.js",
//							"jaxId": "1IUO8EIBB0",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1IUO8F2UD0",
//									"attrs": {
//										"opts": {
//											"jaxId": "1IUO8F2UD1",
//											"attrs": {
//												"bubble": "false",
//												"ai": {
//													"jaxId": "1IUO8F2UD2",
//													"attrs": {
//														"blkColor": "[0,0,0,0.00]",
//														"bgColor": "#cfgColor[\"success\"]",
//														"icon": "#appCfg.sharedAssets+\"/faces.svg\"",
//														"pic": "",
//														"textColor": "#cfgColor[\"fontBody\"]",
//														"iconColor": "#cfgColor[\"fontSuccess\"]",
//														"side": "left"
//													}
//												},
//												"user": {
//													"jaxId": "1IUO8F2UD3",
//													"attrs": {
//														"blkColor": "[0,0,0,0.00]",
//														"bgColor": "#cfgColor.primary",
//														"icon": "#appCfg.sharedAssets+\"/user.svg\"",
//														"pic": "",
//														"textColor": "#cfgColor[\"fontBody\"]",
//														"iconColor": "#cfgColor[\"fontPrimary\"]",
//														"side": "right"
//													}
//												},
//												"wait": {
//													"jaxId": "1IUO8F2UD4",
//													"attrs": {
//														"blkColor": "[0,0,0,0.00]",
//														"bgColor": "#cfgColor[\"secondary\"]",
//														"icon": "#appCfg.sharedAssets+\"/faces.svg\"",
//														"pic": "",
//														"textColor": "#cfgColor[\"fontBody\"]",
//														"iconColor": "#cfgColor[\"fontSecondary\"]",
//														"side": "left"
//													}
//												},
//												"event": {
//													"jaxId": "1IUO8F2UD5",
//													"attrs": {
//														"blkColor": "[0,0,0,0.00]",
//														"bgColor": "#cfgColor[\"warning\"]",
//														"icon": "#appCfg.sharedAssets+\"/event.svg\"",
//														"pic": "",
//														"textColor": "#cfgColor[\"fontBody\"]",
//														"iconColor": "#cfgColor[\"fontWarning\"]",
//														"side": "left"
//													}
//												},
//												"error": {
//													"jaxId": "1IUO8F2UD6",
//													"attrs": {
//														"blkColor": "[0,0,0,0.00]",
//														"bgColor": "#cfgColor[\"error\"]",
//														"icon": "#appCfg.sharedAssets+\"/fat_right.svg\"",
//														"pic": "",
//														"textColor": "[155,0,0,1.00]",
//														"iconColor": "#cfgColor[\"fontError\"]",
//														"side": "left"
//													}
//												},
//												"ask": {
//													"jaxId": "1IUO8F2UD7",
//													"attrs": {
//														"blkColor": "[0,0,0,0.00]",
//														"bgColor": "#cfgColor[\"success\"]",
//														"icon": "#appCfg.sharedAssets+\"/help.svg\"",
//														"pic": "",
//														"textColor": "#cfgColor[\"fontBody\"]",
//														"iconColor": "#cfgColor[\"fontSuccess\"]",
//														"side": "left"
//													}
//												},
//												"allowFile": "false"
//											}
//										}
//									}
//								},
//								"properties": {
//									"jaxId": "1IUO8F2UD8",
//									"attrs": {
//										"type": "#null#>UIChat({\"bubble\":false,\"ai\":{\"blkColor\":[0,0,0,0],\"bgColor\":cfgColor[\"success\"],\"icon\":appCfg.sharedAssets+\"/faces.svg\",\"pic\":\"\",\"textColor\":cfgColor[\"fontBody\"],\"iconColor\":cfgColor[\"fontSuccess\"],\"side\":\"left\"},\"user\":{\"blkColor\":[0,0,0,0],\"bgColor\":cfgColor.primary,\"icon\":appCfg.sharedAssets+\"/user.svg\",\"pic\":\"\",\"textColor\":cfgColor[\"fontBody\"],\"iconColor\":cfgColor[\"fontPrimary\"],\"side\":\"right\"},\"wait\":{\"blkColor\":[0,0,0,0],\"bgColor\":cfgColor[\"secondary\"],\"icon\":appCfg.sharedAssets+\"/faces.svg\",\"pic\":\"\",\"textColor\":cfgColor[\"fontBody\"],\"iconColor\":cfgColor[\"fontSecondary\"],\"side\":\"left\"},\"event\":{\"blkColor\":[0,0,0,0],\"bgColor\":cfgColor[\"warning\"],\"icon\":appCfg.sharedAssets+\"/event.svg\",\"pic\":\"\",\"textColor\":cfgColor[\"fontBody\"],\"iconColor\":cfgColor[\"fontWarning\"],\"side\":\"left\"},\"error\":{\"blkColor\":[0,0,0,0],\"bgColor\":cfgColor[\"error\"],\"icon\":appCfg.sharedAssets+\"/fat_right.svg\",\"pic\":\"\",\"textColor\":[155,0,0,1],\"iconColor\":cfgColor[\"fontError\"],\"side\":\"left\"},\"ask\":{\"blkColor\":[0,0,0,0],\"bgColor\":cfgColor[\"success\"],\"icon\":appCfg.sharedAssets+\"/help.svg\",\"pic\":\"\",\"textColor\":cfgColor[\"fontBody\"],\"iconColor\":cfgColor[\"fontSuccess\"],\"side\":\"left\"},\"allowFile\":false})",
//										"id": "BoxAIChat",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"display": "On",
//										"face": "",
//										"maxW": "1200"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1IUO8F2UD9",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1IUO8F2UD10",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IUO8F2UD11",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true",
//								"containerSlots": {
//									"jaxId": "1IUO8F2UD12",
//									"attrs": {}
//								}
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1IUO8DALH9",
//					"attrs": {}
//				},
//				"functions": {
//					"jaxId": "1IUO8DALH10",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1IUO8DALH11",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1IUO8DALH12",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}