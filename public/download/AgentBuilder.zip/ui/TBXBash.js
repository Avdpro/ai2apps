//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
import {NaviToolBar} from "/@StdUI/ui/NaviToolBar.js";
import {BtnNaviItem} from "/@StdUI/ui/BtnNaviItem.js";
/*#{1IHRTSOVV0StartDoc*/
import tabTTY from "/@tabos/tabos_tty.js";
import tabEnv from "/@tabos/tabos_env.js";
import RemoteTerminal from '../RemoteTerm.js';
/*}#1IHRTSOVV0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let TBXBash=function(){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let boxXTerm,boxTTY;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1IHRTSOVV1LocalVals*/
	let app,sessionId,terminal,hasTTY,hasBash,tty;
	app=VFACT.app;
	hasTTY=false;
	hasBash=false;
	/*}#1IHRTSOVV1LocalVals*/
	
	/*#{1IHRTSOVV1PreState*/
	/*}#1IHRTSOVV1PreState*/
	/*#{1IHRTSOVV1PostState*/
	/*}#1IHRTSOVV1PostState*/
	cssVO={
		"hash":"1IHRTSOVV1",nameHost:true,
		"type":"hud","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
		children:[
			{
				"hash":"1IHRV5JOP0",
				"type":"box","id":"BoxHeader","x":0,"y":0,"w":"100%","h":25,"padding":[0,3,0,3],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["body"],
				"border":[0,0,1,0],"borderColor":cfgColor["fontBodyLit"],"contentLayout":"flex-x","itemsAlign":1,
				children:[
					{
						"hash":"1IHRV6SHC0",
						"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/copy.svg",null),"id":"BtnCopy","position":"relative","x":0,"y":0,"padding":1,
						"tip":"Copy",
					},
					{
						"hash":"1IHRV99QB0",
						"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/trash.svg",null),"id":"BtnClear","position":"relative","x":0,"y":0,
						"tip":"Clear",
					}
				],
			},
			{
				"hash":"1IHRVCLT20",
				"type":"hud","id":"BoxBash","x":0,"y":30,"w":"100%","h":">calc(100% - 30px)","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				children:[
					{
						"hash":"1IHRVKHIH0",
						"type":"hud","id":"BoxXTerm","x":5,"y":0,"w":">calc(100% - 5px)","h":"100%","display":0,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
					},
					{
						"hash":"1IK2PJ7ND0",
						"type":"hud","id":"BoxTTY","x":5,"y":0,"w":">calc(100% - 5px)","h":"100%","display":0,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
					},
					{
						"hash":"1IHRVLKRK0",
						"type":"text","id":"TxtState","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodyLit"],
						"text":"Terminal is not connected","fontSize":txtSize.midPlus,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignH":1,"alignV":1,
					}
				],
			},
			{
				"hash":"1IK2PLQ120",
				"type":"box","id":"BoxNavi","x":0,"y":0,"w":"100%","h":30,"display":0,"styleClass":"","background":[255,255,255,1],"border":[0,0,1,0],
				children:[
					{
						"hash":"1IK2PMG1K0",
						"type":NaviToolBar(true),"x":0,"y":1,"face":"top",
						subContainers:{
							"1HL4P0I9P0":[
								{
									"hash":"1IK2PR3V40",
									"type":BtnNaviItem("Home","Tab OS",[0,0,0,1],appCfg.sharedAssets+"/cklogo.svg",undefined,txtSize.smallPlus,false,0,true),"position":"relative",
									"x":0,"y":0,
								},
								{
									"hash":"1IK2PSMVU0",
									"type":BtnNaviItem("Home","Native OS",[0,0,0,1],appCfg.sharedAssets+"/phone.svg",undefined,txtSize.smallPlus,false,0,true),"position":"relative",
									"x":0,"y":0,
								}
							]
						},
					}
				],
			}
		],
		/*#{1IHRTSOVV1ExtraCSS*/
		/*}#1IHRTSOVV1ExtraCSS*/
		faces:{
			"offline":{
				/*BtnCopy*/"#1IHRV6SHC0":{
					"enable":false
				},
				/*BtnClear*/"#1IHRV99QB0":{
					"enable":false
				},
				/*BoxXTerm*/"#1IHRVKHIH0":{
					"display":0
				},
				/*BoxTTY*/"#1IK2PJ7ND0":{
					"display":0
				},
				/*TxtState*/"#1IHRVLKRK0":{
					"display":1
				}
			},"online":{
				/*BtnCopy*/"#1IHRV6SHC0":{
					"enable":true
				},
				/*BtnClear*/"#1IHRV99QB0":{
					"enable":true
				},
				/*BoxXTerm*/"#1IHRVKHIH0":{
					"display":1
				},
				/*BoxTTY*/"#1IK2PJ7ND0":{
					"display":0
				},
				/*TxtState*/"#1IHRVLKRK0":{
					"display":0
				}
			},"tty":{
				/*BoxXTerm*/"#1IHRVKHIH0":{
					"display":0
				},
				/*BoxTTY*/"#1IK2PJ7ND0":{
					"display":1
				},
				/*TxtState*/"#1IHRVLKRK0":{
					"display":0
				}
			},"single":{
				/*BoxHeader*/"#1IHRV5JOP0":{
					"y":0
				},
				/*BoxBash*/"#1IHRVCLT20":{
					"h":">calc(100% - 30px)","y":30
				},
				/*BoxNavi*/"#1IK2PLQ120":{
					"display":0
				}
			},"both":{
				/*BoxHeader*/"#1IHRV5JOP0":{
					"y":30
				},
				/*BoxBash*/"#1IHRVCLT20":{
					"h":">calc(100% - 60px)","y":60
				},
				/*BoxNavi*/"#1IK2PLQ120":{
					"display":1
				}
			}
		},
		OnCreate:function(){
			self=this;
			boxXTerm=self.BoxXTerm;boxTTY=self.BoxTTY;
			/*#{1IHRTSOVV1Create*/
			// 创建终端实例
			app.uiTerminal=self;
			self.showFace("offline");
			/*}#1IHRTSOVV1Create*/
		},
		/*#{1IHRTSOVV1EndCSS*/
		/*}#1IHRTSOVV1EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.connectBash=async function(sid){
		/*#{1IHRVHDVL0Start*/
		sessionId=sid;
		boxXTerm.webObj.innerHTML="";
		terminal=new RemoteTerminal(sessionId,boxXTerm.webObj);
		terminal.onNotify("Data",()=>{
			if(!self.display){
				app.mainUI.notifyBash();
			}
		});
		await terminal.start();
		hasBash=true;
		if(hasTTY){
			//TODO: Update tab-size?
			self.showFace("both");
		}
		self.showFace("online");
		/*}#1IHRVHDVL0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.copyContent=async function(){
		/*#{1IHRVGQMS0Start*/
		/*}#1IHRVGQMS0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.clearContent=async function(){
		/*#{1IHRVH3EO0Start*/
		/*}#1IHRVH3EO0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.createTTY=function(){
		/*#{1IK2Q9M6J0Start*/
		if(!tty){
			tty=new tabTTY(boxTTY.webObj,null);
			if(hasBash){
				self.showFace("both")
				//TODO: Update tab-size?
			}
			tty.on("data",(text)=>{
				if(!self.display){
					app.mainUI.notifyBash();
				}
			});
		}
		tty.clear();
		hasTTY=true;
		self.showFace("tty");
		return tty;
		/*}#1IK2Q9M6J0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.showTTY=async function(){
		/*#{1IK2QA9HE0Start*/
		self.showFace("tty");
		/*}#1IK2QA9HE0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.showBash=async function(){
		/*#{1IK2QAHLH0Start*/
		self.showFace("online");
		/*}#1IK2QAHLH0Start*/
	};
	/*#{1IHRTSOVV1PostCSSVO*/
	/*}#1IHRTSOVV1PostCSSVO*/
	cssVO.constructor=TBXBash;
	return cssVO;
};
/*#{1IHRTSOVV1ExCodes*/
/*}#1IHRTSOVV1ExCodes*/

//----------------------------------------------------------------------------
TBXBash.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1IHRTSOVV1PreAISpot*/
	/*}#1IHRTSOVV1PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="TBXBash";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1IHRTSOVV1PostAISpot*/
	/*}#1IHRTSOVV1PostAISpot*/
	return exposeVO;
};

//----------------------------------------------------------------------------
TBXBash.gearExport={
	framework: "jax",
	hudType: "hud",
	"showName":"TBXBash",icon:"gears.svg",previewImg:false,
	fixPose:false,initW:100,initH:100,
	catalog:"",
	args: {},
	state:{
	},
	properties:["id","position","x","y","display"],
	faces:["offline","online","tty","single","both"],
	subContainers:{
	},
	/*#{1IHRTSOVV0ExGearInfo*/
	/*}#1IHRTSOVV0ExGearInfo*/
};
/*#{1IHRTSOVV0EndDoc*/
/*}#1IHRTSOVV0EndDoc*/

export default TBXBash;
export{TBXBash};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1IHRTSOVV0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1IHRTSOVV2",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1IHRTSOVV3",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1IHRTSOVV4",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1IHRTSOVV5",
//			"attrs": {}
//		},
//		"localVars": {
//			"jaxId": "1IHRTSOVV6",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1IHRTSOVV7",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IHRVHDVL0",
//					"attrs": {
//						"id": "connectBash",
//						"label": "New AI Seg",
//						"x": "90",
//						"y": "90",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IHRVIGM06",
//							"attrs": {
//								"sid": {
//									"type": "string",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IHRVIGM07",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IHRVIGM08",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IHRVGQMS0",
//					"attrs": {
//						"id": "copyContent",
//						"label": "New AI Seg",
//						"x": "90",
//						"y": "175",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IHRVIGM00",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IHRVIGM01",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IHRVIGM02",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IHRVH3EO0",
//					"attrs": {
//						"id": "clearContent",
//						"label": "New AI Seg",
//						"x": "90",
//						"y": "260",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IHRVIGM03",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IHRVIGM04",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IHRVIGM05",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IK2Q9M6J0",
//					"attrs": {
//						"id": "createTTY",
//						"label": "New AI Seg",
//						"x": "90",
//						"y": "345",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IK2QAQK30",
//							"attrs": {}
//						},
//						"async": "false",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IK2QAQK31",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IK2QAQK32",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IK2QA9HE0",
//					"attrs": {
//						"id": "showTTY",
//						"label": "New AI Seg",
//						"x": "90",
//						"y": "430",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IK2QAQK33",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IK2QAQK34",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IK2QAQK35",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IK2QAHLH0",
//					"attrs": {
//						"id": "showBash",
//						"label": "New AI Seg",
//						"x": "90",
//						"y": "510",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IK2QAQK36",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IK2QAQK37",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IK2QAQK38",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				}
//			]
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "TBXBash",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1IHRTSOVV8",
//			"attrs": {
//				"offline": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IHS04BQR0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IHS05FB50",
//							"attrs": {}
//						}
//					}
//				},
//				"online": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IHS04NEN0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IHS05FB51",
//							"attrs": {}
//						}
//					}
//				},
//				"tty": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IK2Q0K8R0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IK2Q18CI0",
//							"attrs": {}
//						}
//					}
//				},
//				"single": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IK2Q4H3G0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IK2Q7CPI0",
//							"attrs": {}
//						}
//					}
//				},
//				"both": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IK2Q4RRV0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IK2Q7CPI1",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1IHRTSOVV9",
//			"attrs": {}
//		},
//		"exposeToAI": "true",
//		"descAI": "",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1IHRTSOVV1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1IHRTSOVV10",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "100%",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": ""
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1IHRV5JOP0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IHRVB5SP0",
//									"attrs": {
//										"type": "box",
//										"id": "BoxHeader",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "25",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "0",
//										"padding": "[0,3,0,3]",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"body\"]",
//										"border": "[0,0,1,0]",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor[\"fontBodyLit\"]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"contentLayout": "Flex X",
//										"itemsAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1IHRV6SHC0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1IHRV98BE0",
//													"attrs": {
//														"style": "\"front\"",
//														"w": "24",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/copy.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1IHRV98BE1",
//													"attrs": {
//														"type": "#null#>BtnIcon(\"front\",24,0,appCfg.sharedAssets+\"/copy.svg\",null)",
//														"id": "BtnCopy",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"padding": "1"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IHRV98BE2",
//													"attrs": {
//														"1IHS04NEN0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IHS05FB52",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IHS05FB53",
//																	"attrs": {
//																		"enable": {
//																			"type": "bool",
//																			"valText": "true"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IHS04NEN0",
//															"faceTagName": "online"
//														},
//														"1IHS04BQR0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IHS05FB54",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IHS05FB55",
//																	"attrs": {
//																		"enable": {
//																			"type": "bool",
//																			"valText": "false"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IHS04BQR0",
//															"faceTagName": "offline"
//														},
//														"1IK2Q0K8R0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IK2Q7CPI2",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IK2Q7CPI3",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IK2Q0K8R0",
//															"faceTagName": "tty"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IHRV98BE3",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IHRV98BE4",
//													"attrs": {
//														"tip": {
//															"type": "string",
//															"valText": "Copy",
//															"localizable": true
//														}
//													}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1IHRV98BE5",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1IHRV99QB0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1IHRV99QB1",
//													"attrs": {
//														"style": "\"front\"",
//														"w": "24",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/trash.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1IHRV99QB2",
//													"attrs": {
//														"type": "#null#>BtnIcon(\"front\",24,0,appCfg.sharedAssets+\"/trash.svg\",null)",
//														"id": "BtnClear",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": ""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IHRV99QB3",
//													"attrs": {
//														"1IHS04NEN0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IHS05FB56",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IHS05FB57",
//																	"attrs": {
//																		"enable": {
//																			"type": "bool",
//																			"valText": "true"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IHS04NEN0",
//															"faceTagName": "online"
//														},
//														"1IHS04BQR0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IHS05FB58",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IHS05FB59",
//																	"attrs": {
//																		"enable": {
//																			"type": "bool",
//																			"valText": "false"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IHS04BQR0",
//															"faceTagName": "offline"
//														},
//														"1IK2Q0K8R0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IK2Q7CPI6",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IK2Q7CPI7",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IK2Q0K8R0",
//															"faceTagName": "tty"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IHRV99QB4",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IHRV99QB5",
//													"attrs": {
//														"tip": {
//															"type": "string",
//															"valText": "Clear",
//															"localizable": true
//														}
//													}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1IHRV99QB6",
//													"attrs": {}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1IHRVB5SP1",
//									"attrs": {
//										"1IHS04NEN0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IK2Q7CPI10",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IK2Q7CPI11",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IHS04NEN0",
//											"faceTagName": "online"
//										},
//										"1IK2Q0K8R0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IK2Q7CPI12",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IK2Q7CPI13",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IK2Q0K8R0",
//											"faceTagName": "tty"
//										},
//										"1IK2Q4RRV0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IK2Q7CPI14",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IK2Q7CPI15",
//													"attrs": {
//														"y": "30"
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IK2Q4RRV0",
//											"faceTagName": "both"
//										},
//										"1IK2Q4H3G0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IK2Q7CPI16",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IK2Q7CPI17",
//													"attrs": {
//														"y": "0"
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IK2Q4H3G0",
//											"faceTagName": "single"
//										},
//										"1IHS04BQR0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IK2QEQ2I0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IK2QEQ2I1",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IHS04BQR0",
//											"faceTagName": "offline"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1IHRVB5SP2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IHRVB5SP3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1IHRVCLT20",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IHRVDA0P0",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxBash",
//										"position": "Absolute",
//										"x": "0",
//										"y": "30",
//										"w": "100%",
//										"h": "100%-30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": ""
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1IHRVKHIH0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IHRVN2P60",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxXTerm",
//														"position": "Absolute",
//														"x": "5",
//														"y": "0",
//														"w": "100%-5",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "Off",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": ""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IHRVN2P61",
//													"attrs": {
//														"1IHS04BQR0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IK2Q05AT4",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IK2Q05AT5",
//																	"attrs": {
//																		"display": "Off"
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IHS04BQR0",
//															"faceTagName": "offline"
//														},
//														"1IHS04NEN0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IK2Q05AT6",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IK2Q05AT7",
//																	"attrs": {
//																		"display": "On"
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IHS04NEN0",
//															"faceTagName": "online"
//														},
//														"1IK2Q0K8R0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IK2Q18CI9",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IK2Q18CI10",
//																	"attrs": {
//																		"display": "Off"
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IK2Q0K8R0",
//															"faceTagName": "tty"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IHRVN2P62",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IHRVN2P63",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1IK2PJ7ND0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IK2PJ7ND1",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxTTY",
//														"position": "Absolute",
//														"x": "5",
//														"y": "0",
//														"w": "100%-5",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "Off",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": ""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IK2PJ7ND2",
//													"attrs": {
//														"1IHS04BQR0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IK2Q05AT8",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IK2Q05AT9",
//																	"attrs": {
//																		"display": "Off"
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IHS04BQR0",
//															"faceTagName": "offline"
//														},
//														"1IHS04NEN0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IK2Q05AT10",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IK2Q05AT11",
//																	"attrs": {
//																		"display": "Off"
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IHS04NEN0",
//															"faceTagName": "online"
//														},
//														"1IK2Q0K8R0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IK2Q18CI11",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IK2Q18CI12",
//																	"attrs": {
//																		"display": "On"
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IK2Q0K8R0",
//															"faceTagName": "tty"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IK2PJ7ND5",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IK2PJ7ND6",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1IHRVLKRK0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IHRVN2P64",
//													"attrs": {
//														"type": "text",
//														"id": "TxtState",
//														"position": "Absolute",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBodyLit\"]",
//														"text": "Terminal is not connected",
//														"font": "",
//														"fontSize": "#txtSize.midPlus",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Center",
//														"alignV": "Center",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IHRVN2P65",
//													"attrs": {
//														"1IHS04BQR0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IHS05FB518",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IHS05FB519",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IHS04BQR0",
//															"faceTagName": "offline"
//														},
//														"1IHS04NEN0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IHS05FB60",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IHS05FB61",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IHS04NEN0",
//															"faceTagName": "online"
//														},
//														"1IK2Q0K8R0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IK2Q18CI13",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IK2Q18CI14",
//																	"attrs": {
//																		"display": "Off"
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IK2Q0K8R0",
//															"faceTagName": "tty"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IHRVN2P66",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IHRVN2P67",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1IHRVDA0P1",
//									"attrs": {
//										"1IHS04NEN0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IK2Q7CPJ2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IK2Q7CPJ3",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IHS04NEN0",
//											"faceTagName": "online"
//										},
//										"1IK2Q0K8R0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IK2Q7CPJ4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IK2Q7CPJ5",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IK2Q0K8R0",
//											"faceTagName": "tty"
//										},
//										"1IK2Q4RRV0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IK2Q7CPJ6",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IK2Q7CPJ7",
//													"attrs": {
//														"h": "100%-60",
//														"y": "60"
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IK2Q4RRV0",
//											"faceTagName": "both"
//										},
//										"1IK2Q4H3G0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IK2Q7CPJ8",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IK2Q7CPJ9",
//													"attrs": {
//														"h": "100%-30",
//														"y": "30"
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IK2Q4H3G0",
//											"faceTagName": "single"
//										},
//										"1IHS04BQR0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IK2QEQ2I2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IK2QEQ2I3",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IHS04BQR0",
//											"faceTagName": "offline"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1IHRVDA0P2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IHRVDA0P3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1IK2PLQ120",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IK2PSTPR0",
//									"attrs": {
//										"type": "box",
//										"id": "BoxNavi",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "Off",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "[255,255,255,1.00]",
//										"border": "[0,0,1,0]",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/NaviToolBar.js",
//											"jaxId": "1IK2PMG1K0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1IK2PSTPR1",
//													"attrs": {
//														"tabBG": "true"
//													}
//												},
//												"properties": {
//													"jaxId": "1IK2PSTPR2",
//													"attrs": {
//														"type": "#null#>NaviToolBar(true)",
//														"id": "",
//														"position": "Absolute",
//														"x": "0",
//														"y": "1",
//														"display": "On",
//														"face": "\"top\""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IK2PSTPR3",
//													"attrs": {
//														"1IHS04NEN0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IK2Q7CPJ10",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IK2Q7CPJ11",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IHS04NEN0",
//															"faceTagName": "online"
//														},
//														"1IK2Q0K8R0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IK2Q7CPJ12",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IK2Q7CPJ13",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IK2Q0K8R0",
//															"faceTagName": "tty"
//														},
//														"1IHS04BQR0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IK2QEQ2I4",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IK2QEQ2I5",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IHS04BQR0",
//															"faceTagName": "offline"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IK2PSTPR4",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IK2PSTPR5",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1IK2PSTPR6",
//													"attrs": {
//														"Slot1HL4P0I9P0": {
//															"jaxId": "1IK2PQHAC0",
//															"attrs": {
//																"subHuds": {
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "Gear/@StdUI/ui/BtnNaviItem.js",
//																			"jaxId": "1IK2PR3V40",
//																			"attrs": {
//																				"createArgs": {
//																					"jaxId": "1IK2PSDJS0",
//																					"attrs": {
//																						"code": "Home",
//																						"text": "Tab OS",
//																						"color": "[0,0,0,1.00]",
//																						"icon": "#appCfg.sharedAssets+\"/cklogo.svg\"",
//																						"items": "",
//																						"fontSize": "#txtSize.smallPlus",
//																						"hasClose": "false",
//																						"iconSize": "0",
//																						"mark": "true"
//																					}
//																				},
//																				"properties": {
//																					"jaxId": "1IK2PSDJS1",
//																					"attrs": {
//																						"type": "#null#>BtnNaviItem(\"Home\",\"Tab OS\",[0,0,0,1],appCfg.sharedAssets+\"/cklogo.svg\",undefined,txtSize.smallPlus,false,0,true)",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"display": "On",
//																						"face": ""
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1IK2PSDJS2",
//																					"attrs": {
//																						"1IHS04NEN0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IK2Q7CPJ16",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IK2Q7CPJ17",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IHS04NEN0",
//																							"faceTagName": "online"
//																						},
//																						"1IK2Q0K8R0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IK2Q7CPJ18",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IK2Q7CPJ19",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IK2Q0K8R0",
//																							"faceTagName": "tty"
//																						},
//																						"1IHS04BQR0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IK2QEQ2I6",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IK2QEQ2I7",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IHS04BQR0",
//																							"faceTagName": "offline"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1IK2PSDJS3",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1IK2PSDJS4",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false",
//																				"containerSlots": {
//																					"jaxId": "1IK2PSDJS5",
//																					"attrs": {}
//																				}
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "Gear/@StdUI/ui/BtnNaviItem.js",
//																			"jaxId": "1IK2PSMVU0",
//																			"attrs": {
//																				"createArgs": {
//																					"jaxId": "1IK2PSMVU1",
//																					"attrs": {
//																						"code": "Home",
//																						"text": "Native OS",
//																						"color": "[0,0,0,1.00]",
//																						"icon": "#appCfg.sharedAssets+\"/phone.svg\"",
//																						"items": "",
//																						"fontSize": "#txtSize.smallPlus",
//																						"hasClose": "false",
//																						"iconSize": "0",
//																						"mark": "true"
//																					}
//																				},
//																				"properties": {
//																					"jaxId": "1IK2PSMVU2",
//																					"attrs": {
//																						"type": "#null#>BtnNaviItem(\"Home\",\"Native OS\",[0,0,0,1],appCfg.sharedAssets+\"/phone.svg\",undefined,txtSize.smallPlus,false,0,true)",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"display": "On",
//																						"face": ""
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1IK2PSMVU3",
//																					"attrs": {
//																						"1IHS04NEN0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IK2Q7CPJ22",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IK2Q7CPJ23",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IHS04NEN0",
//																							"faceTagName": "online"
//																						},
//																						"1IK2Q0K8R0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IK2Q7CPJ24",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IK2Q7CPJ25",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IK2Q0K8R0",
//																							"faceTagName": "tty"
//																						},
//																						"1IHS04BQR0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IK2QEQ2I8",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IK2QEQ2I9",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IHS04BQR0",
//																							"faceTagName": "offline"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1IK2PSMVU4",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1IK2PSMVU5",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false",
//																				"containerSlots": {
//																					"jaxId": "1IK2PSMVU6",
//																					"attrs": {}
//																				}
//																			}
//																		}
//																	]
//																},
//																"container": "true"
//															}
//														}
//													}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1IK2PSTPR7",
//									"attrs": {
//										"1IHS04NEN0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IK2Q7CPJ28",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IK2Q7CPJ29",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IHS04NEN0",
//											"faceTagName": "online"
//										},
//										"1IK2Q0K8R0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IK2Q7CPJ30",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IK2Q7CPJ31",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IK2Q0K8R0",
//											"faceTagName": "tty"
//										},
//										"1IK2Q4RRV0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IK2Q7CPJ32",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IK2Q7CPJ33",
//													"attrs": {
//														"display": "On"
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IK2Q4RRV0",
//											"faceTagName": "both"
//										},
//										"1IK2Q4H3G0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IK2Q7CPJ34",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IK2Q7CPJ35",
//													"attrs": {
//														"display": "Off"
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IK2Q4H3G0",
//											"faceTagName": "single"
//										},
//										"1IHS04BQR0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IK2QEQ2I10",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IK2QEQ2I11",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IHS04BQR0",
//											"faceTagName": "offline"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1IK2PSTPR8",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IK2PSTPR9",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1IHRTSOVV11",
//					"attrs": {
//						"1IHS04NEN0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1IK2Q7CPJ36",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IK2Q7CPJ37",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1IHS04NEN0",
//							"faceTagName": "online"
//						},
//						"1IK2Q0K8R0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1IK2Q7CPJ38",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IK2Q7CPJ39",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1IK2Q0K8R0",
//							"faceTagName": "tty"
//						},
//						"1IHS04BQR0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1IK2QEQ2J0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IK2QEQ2J1",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1IHS04BQR0",
//							"faceTagName": "offline"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1IHRTSOVV12",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1IHRTSOVV13",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1IHRTSOVV14",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}