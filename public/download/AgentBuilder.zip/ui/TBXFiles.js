//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnObject} from "/@StdUI/ui/BtnObject.js";
/*#{1IJI7V08Q0StartDoc*/
import {HubFileLib} from "/@aichat/hubfile.js";
/*}#1IJI7V08Q0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let TBXFiles=function(){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let boxFiles;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1IJI7V08Q1LocalVals*/
	const app=VFACT.app;
	/*}#1IJI7V08Q1LocalVals*/
	
	/*#{1IJI7V08Q1PreState*/
	/*}#1IJI7V08Q1PreState*/
	/*#{1IJI7V08Q1PostState*/
	/*}#1IJI7V08Q1PostState*/
	cssVO={
		"hash":"1IJI7V08Q1",nameHost:true,
		"type":"hud","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
		children:[
			{
				"hash":"1IJI96A4H0",
				"type":"box","x":0,"y":0,"w":"100%","h":30,"padding":[0,5,0,5],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":[255,255,255,1],
				"border":[0,0,1,0],"contentLayout":"flex-x","itemsAlign":1,
				children:[
					{
						"hash":"1IJI9887R0",
						"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":[0,0,0],"text":(($ln==="CN")?("当前会话中的文件"):("Files in session")),
						"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
					}
				],
			},
			{
				"hash":"1IJI9AIOD0",
				"type":"hud","id":"BoxFiles","x":0,"y":30,"w":"100%","h":">calc(100% - 30px)","overflow":"auto-y","padding":5,"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","contentLayout":"flex-y",
				children:[
				],
			}
		],
		/*#{1IJI7V08Q1ExtraCSS*/
		/*}#1IJI7V08Q1ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			self=this;
			boxFiles=self.BoxFiles;
			/*#{1IJI7V08Q1Create*/
			/*}#1IJI7V08Q1Create*/
		},
		/*#{1IJI7V08Q1EndCSS*/
		/*}#1IJI7V08Q1EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.addFile=async function(hubUrl){
		/*#{1IJIAOONI0Start*/
		let css,line;
		css={
			"type":BtnObject({"text":hubUrl,"icon":appCfg.sharedAssets+"/download.svg","iconColor":cfgColor.fontBody},null),"position":"relative",
			"x":0,"y":0,"fontSize":txtSize.midPlus,fileURL:hubUrl,margin:[5,0,5,0],
			OnClick(){
				self.downloadFile(hubUrl);
			}
		};
		line=boxFiles.appendNewChild(css);
		if(!self.display){
			app.mainUI.notifyFile();
		}
		/*}#1IJIAOONI0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.downloadFile=async function(hubUrl){
		/*#{1IJIAQMJC0Start*/
		if(hubUrl.startsWith("hub://")){
			hubUrl=hubUrl.substring(6);
		}
		let dataURL=await HubFileLib.readDataURL(hubUrl);
		const a = document.createElement("a");
		a.href = dataURL;
		a.download = hubUrl;
		a.click();
		/*}#1IJIAQMJC0Start*/
	};
	/*#{1IJI7V08Q1PostCSSVO*/
	/*}#1IJI7V08Q1PostCSSVO*/
	cssVO.constructor=TBXFiles;
	return cssVO;
};
/*#{1IJI7V08Q1ExCodes*/
/*}#1IJI7V08Q1ExCodes*/

//----------------------------------------------------------------------------
TBXFiles.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1IJI7V08Q1PreAISpot*/
	/*}#1IJI7V08Q1PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1IJI7V08Q1PostAISpot*/
	/*}#1IJI7V08Q1PostAISpot*/
	return exposeVO;
};

//----------------------------------------------------------------------------
TBXFiles.gearExport={
	framework: "jax",
	hudType: "hud",
	"showName":"",icon:"gears.svg",previewImg:false,
	fixPose:false,initW:100,initH:100,
	catalog:"",
	args: {},
	state:{
	},
	properties:["id","position","x","y","display"],
	faces:[],
	subContainers:{
	},
	/*#{1IJI7V08Q0ExGearInfo*/
	/*}#1IJI7V08Q0ExGearInfo*/
};
/*#{1IJI7V08Q0EndDoc*/
/*}#1IJI7V08Q0EndDoc*/

export default TBXFiles;
export{TBXFiles};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1IJI7V08Q0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1IJI7V08Q2",
//			"attrs": {
//				"device": "Desktop 800x600",
//				"screenW": "800",
//				"screenH": "600",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1IJI7V08Q3",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1IJI7V08Q4",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1IJI7V08Q5",
//			"attrs": {}
//		},
//		"localVars": {
//			"jaxId": "1IJI7V08Q6",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1IJI7V08Q7",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IJIAOONI0",
//					"attrs": {
//						"id": "addFile",
//						"label": "New AI Seg",
//						"x": "95",
//						"y": "80",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IJIAQCOE0",
//							"attrs": {
//								"hubUrl": {
//									"type": "string",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IJIAQCOE1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IJIAQCOE2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IJIAQMJC0",
//					"attrs": {
//						"id": "downloadFile",
//						"label": "New AI Seg",
//						"x": "95",
//						"y": "160",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IJIAREKN0",
//							"attrs": {
//								"hubUrl": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IJIAREKN1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IJIAREKN2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				}
//			]
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1IJI7V08Q8",
//			"attrs": {}
//		},
//		"mockupStates": {
//			"jaxId": "1IJI7V08Q9",
//			"attrs": {}
//		},
//		"exposeToAI": "true",
//		"descAI": "",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1IJI7V08Q1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1IJI7V08Q10",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "100%",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": ""
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1IJI96A4H0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IJI979OT0",
//									"attrs": {
//										"type": "box",
//										"id": "",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "[0,5,0,5]",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "[255,255,255,1.00]",
//										"border": "[0,0,1,0]",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"contentLayout": "Flex X",
//										"flex": "false",
//										"itemsAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1IJI9887R0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IJI994PG0",
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "[0,0,0]",
//														"text": {
//															"type": "string",
//															"valText": "Files in session",
//															"localize": {
//																"EN": "Files in session",
//																"CN": "当前会话中的文件"
//															},
//															"localizable": true
//														},
//														"font": "",
//														"fontSize": "16",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IJI994PG1",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1IJI994PG2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IJI994PG3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1IJI979OT1",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1IJI979OT2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IJI979OT3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1IJI9AIOD0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IJIAODFS0",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxFiles",
//										"position": "Absolute",
//										"x": "0",
//										"y": "30",
//										"w": "100%",
//										"h": "100%-30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Auto Scroll Y",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "5",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex Y"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnObject.js",
//											"jaxId": "1IJIAKUPE0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1IJIAODFS1",
//													"attrs": {
//														"obj": "#{\"text\":\"hub://File001.svg\",\"icon\":appCfg.sharedAssets+\"/prj.svg\",\"iconColor\":[0,0,0,1],emoji:\"⬇️\"}",
//														"converter": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1IJIAODFS2",
//													"attrs": {
//														"type": "#null#>BtnObject({\"text\":\"hub://File001.svg\",\"icon\":appCfg.sharedAssets+\"/prj.svg\",\"iconColor\":[0,0,0,1],emoji:\"⬇️\"},null)",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"fontSize": "#txtSize.midPlus"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IJIAODFS3",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1IJIAODFS4",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IJIAODFS5",
//													"attrs": {}
//												},
//												"mockup": "true",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1IJIAODFS6",
//													"attrs": {}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1IJIAODFS7",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1IJIAODFS8",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IJIAODFS9",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1IJI7V08Q11",
//					"attrs": {}
//				},
//				"functions": {
//					"jaxId": "1IJI7V08Q12",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1IJI7V08Q13",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1IJI7V08Q14",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}