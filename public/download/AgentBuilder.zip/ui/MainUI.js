//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BoxTokenGas} from "/@aichat/ui/BoxTokenGas.js";
import {UIChat} from "/@aichat/ui/UIChat.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
import {NaviToolBar} from "/@StdUI/ui/NaviToolBar.js";
import {BtnNaviItem} from "/@StdUI/ui/BtnNaviItem.js";
import {TBXInference} from "./TBXInference.js";
import {TBXBash} from "./TBXBash.js";
import {TBXNotes} from "./TBXNotes.js";
import {TBXLogs} from "./TBXLogs.js";
import {TBXFiles} from "./TBXFiles.js";
import {TBXSandbox} from "./TBXSandbox.js";
/*#{1GGJKM84D0StartDoc*/
import pathLib from "/@path";
import {AIConfig} from "../data/AIConfig.js";
import {tabNT} from "/@tabos";

function getElementScreenPosition(el) {
	if (!el) return null;

	let rect = el.getBoundingClientRect(); // 获取元素在当前视口中的坐标
	let win = el.ownerDocument.defaultView; // 获取元素所在的 window
	let x = rect.left, y = rect.top;

	// 如果元素在 iframe 内，累加所有父级 iframe 的偏移
	while (win !== window.top) {
		let iframe = win.frameElement; // 获取当前 iframe 元素
		if (!iframe) break;

		let iframeRect = iframe.getBoundingClientRect();
		x += iframeRect.left;
		y += iframeRect.top;

		win = win.parent; // 继续向上遍历
	}

	// 添加当前浏览器窗口在屏幕上的位置
	let screenX = window.screenX;
	let screenY = window.screenY;
	let dpr = 1;//window.devicePixelRatio;
	let browserFrameHeight = 35;//window.outerHeight - window.innerHeight
	return {
		x: (screenX + x) * dpr,
		y: (screenY + y+browserFrameHeight) * dpr,
		width: rect.width * dpr,
		height: rect.height * dpr
	};
}
/*}#1GGJKM84D0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let MainUI=function(app,appFrame){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let boxAIChat,boxTools,naviTabs,tabNotes,tabSandbox,tabBash,tabFiles,tabProcess,boxToolView,tbxInference,tbxBash,tbxNotes,tbxFiles,tbxSandbox;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let title=(($ln==="CN")?("项目向导"):("Project Wizard"));
	let appendProcessBlock=undefined;
	
	/*#{1GGJKM84D1LocalVals*/
	app.aiNotifyApp=app;//Make sure all AI-Emit goes to current app, not the IDE's app.
	let session=null;
	app.appFrame=appFrame;
	const rootApp=appFrame?appFrame.app:app;
	let debugSockets=[];
	let slowMo=false;
	let stepRun=false;
	let execPaused=false;
	let localExecCallback=null;
	let callback=null;
	let callerror=null;
	
	let chatClient=null;
	let chatThread=null;
	/*}#1GGJKM84D1LocalVals*/
	
	/*#{1GGJKM84D1PreState*/
	title=appFrame?(appFrame.appParams.title||title):title;
	/*}#1GGJKM84D1PreState*/
	state={
		"counter":0,
		/*#{1GGJKM84D6ExState*/
		/*}#1GGJKM84D6ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1GGJKM84D1PostState*/
	appendProcessBlock=function(vo){
		self.appendProcessBlock(vo);
	}
	/*}#1GGJKM84D1PostState*/
	cssVO={
		"hash":"1GGJKM84D1",nameHost:true,
		"type":"view","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
		children:[
			{
				"hash":"1HHAMBFU40",
				"type":BoxTokenGas(30,cfgColor["secondary"],cfgColor["fontSecondary"],24,16,false,false,appCfg.sharedAssets+"/ablogo.svg",30),"position":"relative",
				"x":0,"y":0,"caption":title,
			},
			{
				"hash":"1HDBT1RJN0",
				"type":"hud","id":"BoxChat","x":0,"y":30,"w":480,"h":">calc(100% - 30px)","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				children:[
					{
						"hash":"1HDBT34IS0",
						"type":UIChat({"bubble":false,"ai":{"blkColor":[0,0,0,0],"bgColor":cfgColor["success"],"icon":appCfg.sharedAssets+"/faces.svg","pic":"","textColor":cfgColor["fontBody"],"iconColor":cfgColor["fontSuccess"],"side":"left"},"user":{"blkColor":[0,0,0,0],"bgColor":cfgColor.primary,"icon":appCfg.sharedAssets+"/user.svg","pic":"","textColor":cfgColor["fontBody"],"iconColor":cfgColor["fontPrimary"],"side":"right"},"wait":{"blkColor":[0,0,0,0],"bgColor":cfgColor["secondary"],"icon":appCfg.sharedAssets+"/faces.svg","pic":"","textColor":cfgColor["fontBody"],"iconColor":cfgColor["fontSecondary"],"side":"left"},"event":{"blkColor":[0,0,0,0],"bgColor":cfgColor["warning"],"icon":appCfg.sharedAssets+"/event.svg","pic":"","textColor":cfgColor["fontBody"],"iconColor":cfgColor["fontWarning"],"side":"left"},"error":{"blkColor":[0,0,0,0],"bgColor":cfgColor["error"],"icon":appCfg.sharedAssets+"/fat_right.svg","pic":"","textColor":[155,0,0,1],"iconColor":cfgColor["fontError"],"side":"left"},"ask":{"blkColor":[0,0,0,0],"bgColor":cfgColor["success"],"icon":appCfg.sharedAssets+"/help.svg","pic":"","textColor":cfgColor["fontBody"],"iconColor":cfgColor["fontSuccess"],"side":"left"},"allowFile":false,"appendProcessBlock":appendProcessBlock}),
						"id":"BoxAIChat","x":0,"y":30,"h":">calc(100% - 30px)",
					},
					{
						"hash":"1IHRRMK5D0",
						"type":"box","id":"BoxChatHeader","x":0,"y":0,"w":"100%","h":30,"padding":[0,13,0,5],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["body"],
						"border":[0,0,1,0],"borderColor":cfgColor["fontBodySub"],"contentLayout":"flex-x","itemsAlign":1,
						children:[
							{
								"hash":"1IHRRSCOS0",
								"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
								"text":"Agent chats","fontWeight":"normal","fontStyle":"normal","textDecoration":"","flex":true,
							},
							{
								"hash":"1INGIS8QL0",
								"type":BtnIcon("front",26,0,appCfg.sharedAssets+"/settings.svg",null),"id":"BtnClearChat","position":"relative","x":0,"y":0,"margin":[0,5,0,0],
								"tip":(($ln==="CN")?("AI 设置"):("AI config")),
							},
							{
								"hash":"1IHRRO8470",
								"type":BtnIcon("front",26,0,appCfg.sharedAssets+"/trash.svg",null),"id":"BtnClearChat","position":"relative","x":0,"y":0,"enable":false,
								"tip":(($ln==="CN")?("清除"):("Clear")),
							}
						],
					},
					{
						"hash":"1IHROFSPO0",
						"type":"box","x":">calc(100% - 1px)","y":0,"w":1,"h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["fontBodySub"],
					}
				],
			},
			{
				"hash":"1IHRSFUAP0",
				"type":"hud","id":"BoxTools","x":480,"y":30,"w":">calc(100% - 480px)","h":">calc(100% - 30px)","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				children:[
					{
						"hash":"1IHRSON170",
						"type":"box","id":"BoxToolFooter","x":0,"y":">calc(100% - 30px)","w":"100%","h":30,"padding":[0,2,0,2],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						"background":cfgColor["body"],"border":[1,0,0,0],"borderColor":cfgColor["fontBodySub"],
						children:[
							{
								"hash":"1IHRT3E2S0",
								"type":NaviToolBar(true),"id":"NaviTabs","position":"relative","x":0,"y":0,"w":"100%",
								subContainers:{
									"1HL4P0I9P0":[
										{
											"hash":"1II4R1QQ40",
											"type":BtnNaviItem("Notes",(($ln==="CN")?("推理视图"):("Inference")),[0,0,0,1],appCfg.sharedAssets+"/memory.svg",undefined,txtSize.smallPlus,false,0,true),
											"id":"TabNotes","position":"relative","x":0,"y":0,"margin":[0,3,0,3],
											"OnClick":function(event){
												self.showTbxInference(this,event);
											},
										},
										{
											"hash":"1ILSAPHN50",
											"type":BtnNaviItem("Path",(($ln==="CN")?("画布"):("Canvas")),[0,0,0,1],appCfg.sharedAssets+"/canvas.svg",undefined,txtSize.smallPlus,false,0,true),
											"id":"TabCanvas","position":"relative","x":0,"y":0,"display":0,"margin":[0,3,0,3],"enable":false,
											"OnClick":function(event){
												self.showTbxLogs(this,event);
											},
										},
										{
											"hash":"1IN3JKQGT0",
											"type":BtnNaviItem("Path",(($ln==="CN")?("沙箱"):("Sandbox")),[0,0,0,1],appCfg.sharedAssets+"/dojo.svg",undefined,txtSize.smallPlus,false,0,true),
											"id":"TabSandbox","position":"relative","x":0,"y":0,"display":0,"margin":[0,3,0,3],
											"OnClick":function(event){
												self.showTbxSandbox(this,event);
											},
										},
										{
											"hash":"1IIQD8VE20",
											"type":BtnNaviItem("Path","Logs",[0,0,0,1],appCfg.sharedAssets+"/read.svg",undefined,txtSize.smallPlus,false,0,true),"id":"TabLogs","position":"relative",
											"x":0,"y":0,"margin":[0,3,0,3],
											"OnClick":function(event){
												self.showTbxLogs(this,event);
											},
										},
										{
											"hash":"1IHRT56I80",
											"type":BtnNaviItem("Home","Terminal",[0,0,0,1],appCfg.sharedAssets+"/terminal.svg",undefined,txtSize.smallPlus,false,0,true),"id":"TabBash",
											"position":"relative","x":0,"y":0,"display":0,"margin":[0,3,0,3],
											"OnClick":function(event){
												self.showTbxBash(this,event);
											},
										},
										{
											"hash":"1IHUFRISN0",
											"type":BtnNaviItem("Notes",("Notes"),[0,0,0,1],appCfg.sharedAssets+"/rename.svg",undefined,txtSize.smallPlus,false,0,true),"id":"TabNotes",
											"position":"relative","x":0,"y":0,"display":0,"margin":[0,3,0,3],
											"OnClick":function(event){
												self.showTbxNotes(this,event);
											},
										},
										{
											"hash":"1IHRTJCOJ0",
											"type":BtnNaviItem("Path","Files",[0,0,0,1],appCfg.sharedAssets+"/folder.svg",undefined,txtSize.smallPlus,false,0,true),"id":"TabFiles","position":"relative",
											"x":0,"y":0,"display":0,"margin":[0,3,0,3],
											"OnClick":function(event){
												self.showTbxFiles(this,event);
											},
										},
										{
											"hash":"1J12BTG220",
											"type":BtnNaviItem("Notes",(($ln==="CN")?("流程"):("Process")),[0,0,0,1],appCfg.sharedAssets+"/hudstate.svg",undefined,txtSize.smallPlus,false,0,true),
											"id":"TabProcess","position":"relative","x":0,"y":0,"display":0,"margin":[0,3,0,3],
											"OnClick":function(event){
												self.showTbxInference(this,event);
											},
										}
									]
								},
								/*#{1IHRT3E2S0Codes*/
								/*}#1IHRT3E2S0Codes*/
							}
						],
					},
					{
						"hash":"1IHRTEID20",
						"type":"hud","id":"BoxToolView","x":0,"y":0,"w":"100%","h":">calc(100% - 30px)","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						children:[
							{
								"hash":"1II6BGSOG0",
								"type":TBXInference(),"id":"TbxInference","x":0,"y":0,
							},
							{
								"hash":"1IHRVOUT90",
								"type":TBXBash(),"id":"TbxBash","x":0,"y":0,"display":0,
							},
							{
								"hash":"1IHUJ32310",
								"type":TBXNotes(),"id":"TbxNotes","x":0,"y":0,"display":0,
							},
							{
								"hash":"1IIQDF03V0",
								"type":TBXLogs(),"id":"TbxLogs","x":0,"y":0,"display":0,
							},
							{
								"hash":"1IJID01680",
								"type":TBXFiles(),"id":"TbxFiles","x":0,"y":0,"display":0,
							},
							{
								"hash":"1IN8DO8620",
								"type":TBXSandbox(),"id":"TbxSandbox","x":0,"y":0,"display":0,
							}
						],
					}
				],
			}
		],
		/*#{1GGJKM84D1ExtraCSS*/
		/*}#1GGJKM84D1ExtraCSS*/
		faces:{
			"embed":{
				"#1HHAMBFU40":{
					"y":"100%","anchorY":2,"display":0
				},
				/*BoxChat*/"#1HDBT1RJN0":{
					"y":0,"h":"100%"
				},
				/*BoxAIChat*/"#1HDBT34IS0":{
					"y":0,"h":"100%"
				},
				/*BoxChatHeader*/"#1IHRRMK5D0":{
					"display":0
				},
				/*BoxTools*/"#1IHRSFUAP0":{
					"y":0,"h":"100%"
				}
			},"wideChat":{
				/*BoxChat*/"#1HDBT1RJN0":{
					"w":600
				},
				/*BoxTools*/"#1IHRSFUAP0":{
					"w":">calc(100% - 600px)","x":600,"minW":250
				}
			},"tbxBash":{
				/*TbxInference*/"#1II6BGSOG0":{
					"display":0
				},
				/*TbxBash*/"#1IHRVOUT90":{
					"display":1
				},
				/*TbxNotes*/"#1IHUJ32310":{
					"display":0
				},
				/*TbxLogs*/"#1IIQDF03V0":{
					"display":0
				},
				/*TbxFiles*/"#1IJID01680":{
					"display":0
				},
				/*TbxSandbox*/"#1IN8DO8620":{
					"display":0
				}
			},"tbxNotes":{
				/*TbxInference*/"#1II6BGSOG0":{
					"display":0
				},
				/*TbxBash*/"#1IHRVOUT90":{
					"display":0
				},
				/*TbxNotes*/"#1IHUJ32310":{
					"display":1
				},
				/*TbxLogs*/"#1IIQDF03V0":{
					"display":0
				},
				/*TbxFiles*/"#1IJID01680":{
					"display":0
				},
				/*TbxSandbox*/"#1IN8DO8620":{
					"display":0
				}
			},"tbxInference":{
				/*TbxInference*/"#1II6BGSOG0":{
					"display":1
				},
				/*TbxBash*/"#1IHRVOUT90":{
					"display":0
				},
				/*TbxNotes*/"#1IHUJ32310":{
					"display":0
				},
				/*TbxLogs*/"#1IIQDF03V0":{
					"display":0
				},
				/*TbxFiles*/"#1IJID01680":{
					"display":0
				},
				/*TbxSandbox*/"#1IN8DO8620":{
					"display":0
				}
			},"tbxLogs":{
				/*TbxInference*/"#1II6BGSOG0":{
					"display":0
				},
				/*TbxBash*/"#1IHRVOUT90":{
					"display":0
				},
				/*TbxNotes*/"#1IHUJ32310":{
					"display":0
				},
				/*TbxLogs*/"#1IIQDF03V0":{
					"display":1
				},
				/*TbxFiles*/"#1IJID01680":{
					"display":0
				},
				/*TbxSandbox*/"#1IN8DO8620":{
					"display":0
				}
			},"tbxFiles":{
				/*TbxInference*/"#1II6BGSOG0":{
					"display":0
				},
				/*TbxBash*/"#1IHRVOUT90":{
					"display":0
				},
				/*TbxNotes*/"#1IHUJ32310":{
					"display":0
				},
				/*TbxLogs*/"#1IIQDF03V0":{
					"display":0
				},
				/*TbxFiles*/"#1IJID01680":{
					"display":1
				},
				/*TbxSandbox*/"#1IN8DO8620":{
					"display":0
				}
			},"tbxSandbox":{
				/*TbxInference*/"#1II6BGSOG0":{
					"display":0
				},
				/*TbxBash*/"#1IHRVOUT90":{
					"display":0
				},
				/*TbxNotes*/"#1IHUJ32310":{
					"display":0
				},
				/*TbxLogs*/"#1IIQDF03V0":{
					"display":0
				},
				/*TbxFiles*/"#1IJID01680":{
					"display":0
				},
				/*TbxSandbox*/"#1IN8DO8620":{
					"display":1
				}
			}
		},
		OnCreate:function(){
			self=this;
			boxAIChat=self.BoxAIChat;boxTools=self.BoxTools;naviTabs=self.NaviTabs;tabNotes=self.TabNotes;tabSandbox=self.TabSandbox;tabBash=self.TabBash;tabNotes=self.TabNotes;tabFiles=self.TabFiles;tabProcess=self.TabProcess;boxToolView=self.BoxToolView;tbxInference=self.TbxInference;tbxBash=self.TbxBash;tbxNotes=self.TbxNotes;tbxFiles=self.TbxFiles;tbxSandbox=self.TbxSandbox;
			/*#{1GGJKM84D1Create*/
			let entry,params,args;
			params=app.appParams;
			entry=params.agentURL||params.file;
			args=params.arguments||params.argument||"";
			callback=params.callback||null;
			callerror=params.callerror||null;
			chatClient=params.chatClient;
			chatThread=params.chatThread;
			if(params.wideChat){
				self.showFace("wideChat");
			}
			app.mainUI=self;
			if(chatThread){
				chatThread.onNotify("ThreadFocused",()=>{
					console.log("Thread focused");
					naviTabs.moveTab(false);
					tbxInference.showCanvas();
				});
			}
			if(chatThread && !entry){
				// Set minimal session so code block run buttons work when loading dead thread:
				app.boxChats.session={
					WSCall_WebSandbox:async function(code,opts){
						if(tbxSandbox){
							self.notifySandbox();
							return await tbxSandbox.runCode(null,code,opts);
						}
					}
				};
				boxAIChat.initChatThread(chatThread);
				const savedSessionId=localStorage.getItem("dbgSession:"+chatThread.id);
				console.log("[restore] chatThread.id=",chatThread.id," savedSessionId=",savedSessionId," uiInference=",!!app.uiInference);
				if(savedSessionId){
					if(app.uiInference){
						self.restoreDebugLogs(savedSessionId);
					}else{
						app._pendingRestoreSessionId=savedSessionId;
						console.log("[restore] set _pendingRestoreSessionId=",savedSessionId," (uiInference not ready yet)");
					}
				}
			}else{
				self.openChatFile(entry||"ai/UxEntry.js",args);
			}
			if(appFrame && appFrame.isEmbeded){
				self.showFace("embed");
			}else if(entry){
			}
			if(appFrame && !appFrame.isEmbeded){
				appFrame.onNotify("FrameFocused",()=>{
					window.dispatchEvent(new Event('resize'));
				});
			}
			/*}#1GGJKM84D1Create*/
		},
		/*#{1GGJKM84D1EndCSS*/
		/*}#1GGJKM84D1EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.connectDebug=async function(address,sessionId){
		/*#{1IIPJ51GL0Start*/
		let addr,connecting,pms,connected,ws;
		let callback,callerror;
		addr=address;
		if(!addr.startsWith("ws://")){
			addr="ws://"+addr;
		}
		connecting=true;
		ws=new WebSocket(addr);
		pms=new Promise((resolve,reject)=>{
			callback=resolve;
			callerror=reject;
		});
		ws.addEventListener('open',()=>{
			connected=true;
			connecting=false;
			debugSockets.push(ws);
			console.log("Agent Debug WS connected.");
			if(sessionId){
				ws.send(JSON.stringify({cmd:"Register",sessionId:sessionId}));
			}
			ws.send(JSON.stringify({cmd:"SlowMo",enable:slowMo}));
			if(stepRun){
				ws.send(JSON.stringify({cmd:"StepRunOn"}));
			}
			self.showFace("online");
			if(callback){
				callback();
				callback=null;
				callerror=null;
			}
		});
		ws.addEventListener('message', (msg) => {
			let log,msgCode,css,icon;
			log=JSON.parse(msg.data);
			console.log("Log from debug server:");
			console.log(log)
			if(chatThread){
				chatThread.emit("AGENT_EVENT",log)
			}
			icon=null;
			switch(log.type){
				case "StepRunOn":
					app.emit("AIStepRunOn");
					break;
				case "StepRunOff":
					if(execPaused){
						execPaused=false;
						ws.stepPaused=false;
						app.emit("AIExecResume");
						app.emit("AIStepRunOff");
					}
					break;
				case "StepPaused":
					execPaused=true;
					ws.stepPaused=true;
					app.emit("AIExecPaused");
					break;
				case "StepRun":
					execPaused=false;
					ws.stepPaused=false;
					app.emit("AIExecResume");
					break;
				case "StartAgent":
				case "EndAgent":
				case "StartSeg":
				case "EndSeg":
				case "DebugLog":
				case "CatchError":{
					if(app.uiInference){ app.uiInference.handleLog(log); }
					if(app.uiLogs){ app.uiLogs.addLog(log); }
					// 持久化结构性 log 到 localStorage，用于重启后恢复
					if(log.session){
						try{
							const lsKey='dbgLogs:'+log.session;
							const arr=JSON.parse(localStorage.getItem(lsKey)||'[]');
							arr.push(log);
							localStorage.setItem(lsKey,JSON.stringify(arr));
						}catch(e){ /* storage full, ignore */ }
					}
					break;
				}
				case "LlmCall":
				case "LlmResult":{
					// 显示但不持久化（包含完整消息历史，体积过大）
					if(app.uiInference){ app.uiInference.handleLog(log); }
					if(app.uiLogs){ app.uiLogs.addLog(log); }
					break;
				}
			}
		});
		ws.addEventListener('close', (msg) => {
			if(connected){
				connected=false;
				self.showFace("offline");
				this.isConnected=false;
				let idx=debugSockets.indexOf(ws);
				if(idx>=0){
					debugSockets.splice(idx,1);
				}
				console.log("Agent Debug WS closed.");
			}else{
				self.showFace("offline");
			}
			if(callerror){
				callback=null;
				callerror();
				callerror=null;
			}
			ws=null;
		});
		ws.addEventListener('error', (msg) => {
			if(connecting){
				self.showFace("offline");
				if(callerror){
					callback=null;
					callerror();
					callerror=null;
				}
			}else if(connected){
				console.log("Agent Debug WS error.");
				console.error(msg);
			}
		});
		let result=await pms;
		console.log(result);
		return true;
		/*}#1IIPJ51GL0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.showTbxBash=async function(){
		/*#{1IHUJE1HL0Start*/
		tabBash.markNum=0;
		/*}#1IHUJE1HL0Start*/
		self.showFace("tbxBash");
		
		//RefreshTab
		/*#{1IQ7Q55DT0*/
		tbxBash.refreshTab();
		/*}#1IQ7Q55DT0*/
	};
	//------------------------------------------------------------------------
	cssVO.showTbxNotes=async function(){
		/*#{1IHUJELCJ0Start*/
		tabNotes.markNum=0;
		/*}#1IHUJELCJ0Start*/
		self.showFace("tbxNotes");
	};
	//------------------------------------------------------------------------
	cssVO.restoreDebugLogs=async function(sessionId){
		console.log("[restore] restoreDebugLogs called, sessionId=",sessionId);
		try{
			const res=await fetch("/ws",{
				method:"POST",
				headers:{"Content-Type":"application/json"},
				body:JSON.stringify({msg:"AhGetDebugLogs",vo:{sessionId}})
			});
			const data=await res.json();
			console.log("[restore] AhGetDebugLogs response, code=",data.code," logs.length=",data.logs?data.logs.length:0);
			if(data.code===200 && data.logs && data.logs.length>0){
				for(const log of data.logs){
					if(app.uiInference){ app.uiInference.handleLog(log); }
					if(app.uiLogs){ app.uiLogs.addLog(log); }
				}
				console.log("[restore] done replaying logs from server");
			}else{
				// 服务器无数据（重启场景），从 localStorage fallback 恢复
				try{
					const lsLogs=JSON.parse(localStorage.getItem('dbgLogs:'+sessionId)||'[]');
					if(lsLogs.length>0){
						for(const log of lsLogs){
							if(app.uiInference){ app.uiInference.handleLog(log); }
							if(app.uiLogs){ app.uiLogs.addLog(log); }
						}
						console.log("[restore] done replaying logs from localStorage, count=",lsLogs.length);
					}
				}catch(e){
					console.warn("[restore] localStorage fallback failed:",e);
				}
			}
		}catch(err){
			console.warn("restoreDebugLogs failed:",err);
		}
	};
	//------------------------------------------------------------------------
	cssVO.showTbxInference=async function(){
		/*#{1II6CP44V0Start*/
		/*}#1II6CP44V0Start*/
		self.showFace("tbxInference");
		
		//Render
		/*#{1II6Q1MCO0*/
		tbxInference.showCanvas();
		/*}#1II6Q1MCO0*/
	};
	//------------------------------------------------------------------------
	cssVO.showTbxLogs=async function(){
		/*#{1IIQDJIM60Start*/
		/*}#1IIQDJIM60Start*/
		self.showFace("tbxLogs");
	};
	//------------------------------------------------------------------------
	cssVO.showTbxFiles=async function(){
		/*#{1IJJ337E60Start*/
		tabFiles.markNum=0;
		/*}#1IJJ337E60Start*/
		self.showFace("tbxFiles");
	};
	//------------------------------------------------------------------------
	cssVO.showTbxSandbox=async function(){
		/*#{1IN8GKLIC0Start*/
		tabSandbox.markNum=0;
		/*}#1IN8GKLIC0Start*/
		self.showFace("tbxSandbox");
	};
	//------------------------------------------------------------------------
	cssVO.notifyBash=async function(){
		/*#{1IJI6LE7N0Start*/
		tabBash.incMark();
		tabBash.display=true;
		/*}#1IJI6LE7N0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.notifyFile=async function(){
		/*#{1IJI6LMIG0Start*/
		tabFiles.incMark();
		tabFiles.display=true;
		/*}#1IJI6LMIG0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.notifyNote=async function(){
		/*#{1IJI6M3L80Start*/
		tabNotes.incMark();
		tabNotes.display=true;
		/*}#1IJI6M3L80Start*/
	};
	//------------------------------------------------------------------------
	cssVO.notifySandbox=async function(){
		/*#{1IN8GPG290Start*/
		//tabSandbox.incMark();
		//tabSandbox.enable=true;
		tabSandbox.display=true;
		naviTabs.focusOn(tabSandbox);
		self.showFace("tbxSandbox");
		/*}#1IN8GPG290Start*/
	};
	//------------------------------------------------------------------------
	cssVO.checkLogin=async function(){
		/*#{1IRPPJ39C0Start*/
		if(!(await tabNT.checkLogin(true,true))){
			if(!(await rootApp.modalDlg("/@homekit/ui/DlgLogin.js",{x:rootApp.width/2,y:100,alignH:1}))){
				return;
			}
		}
		/*}#1IRPPJ39C0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.appendProcessBlock=async function(vo){
		/*#{1J12TU51T0Start*/
		tbxInference.appendProcessBlock(vo);
		/*}#1J12TU51T0Start*/
	};
	/*#{1GGJKM84D1PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.openChatFile=async function(path,args){
		let ext,params,gc;
		params=app.appParams;
		gc=params.globalContext;
		let config;
		try{
			config=await (await fetch("/~/coke/ai.config.json")).json();
		}catch(err){
			config={
				models:{
					"default":{
						"platform": "OpenAI",
						"model": "gpt-4o"
					},
					"lite":{
						"platform": "OpenAI",
						"model": "gpt-4o-mini"
					},
					"fast":{
						"platform": "OpenAI",
						"model": "gpt-4o-mini"
					},
					"expert":{
						"platform": "OpenAI",
						"model": "gpt-4o"
					},
					"coding":{
						"platform": "OpenAI",
						"model": "gpt-4o"
					},
					"planning":{
						"platform": "OpenAI",
						"model": "gpt-4o"
					},
					"view":{
						"platform": "OpenAI",
						"model": "gpt-4o"
					},
				}
			};
		}
		
		let setup=async (sn)=>{
			//Setup before session really start:
			session=sn;
			//Apply globalContext:
			if(gc){
				Object.assign(session.globalContext,gc);
			}
			gc=session.globalContext;
			if(config){
				if(gc.models){
					gc.models={...config.models,...gc.models};
				}else{
					gc.models=config.models;
				}
			}
	
			//Connect debug client callback:
			session.WSCall_ConnectAgentDebug=async function(message){
				if(chatThread && message.sessionId){
					// 新 session 开始时清除旧 session 的 localStorage logs
					const oldSessionId=localStorage.getItem("dbgSession:"+chatThread.id);
					if(oldSessionId && oldSessionId!==message.sessionId){
						localStorage.removeItem('dbgLogs:'+oldSessionId);
					}
					localStorage.setItem("dbgSession:"+chatThread.id, message.sessionId);
					console.log("[restore] saved to localStorage: key=dbgSession:"+chatThread.id+" val="+message.sessionId);
				}
				if(app.uiInference){
					let address=`${window.location.hostname}:${message.port}`;
					let result=await self.connectDebug(address,message.sessionId);
					//let result=await app.uiInference.connect(address,message.entryURL,message.entryAgent);
					console.log("MainUI.connectDebug result: "+result);
				}
				return false;
			}
	
			//Connect agent terminal:
			session.WSCall_CreateXTerm=async function(message){
				let sessionId=message.session||message.sessionId;
				if(tbxBash){
					tbxBash.connectBash(sessionId);
					// 显示Terminal标签并自动跳转到终端页面
					tabBash.display=true;
					naviTabs.focusOn(tabBash);
					self.showFace("tbxBash");
				}
			};
			
			session.WSCall_SwitchXTerm = async function(message){                                                                                                                                                                                                                           
				let sid = message.session || message.sessionId;                                                                                                                                                                                                                             
				let app = VFACT.app;
				if(app.uiTerminal){                                                                                                                                                                                                                                                         
					app.uiTerminal.switchTerm(sid);
				}
			};

			//Connect agent terminal-env:
			session.WSCall_CreateCokeEnv=async function(){
				if(tbxBash){
					let cokeEnv=await tbxBash.createCokeEnv();
					let tty=cokeEnv.tty;
					tty.session=session;
					cokeEnv.session=session;
					return cokeEnv;
				}
				return null;
			};
			
			//Connect agent terminal-tty:
			session.WSCall_CreateTTY=async function(){
				if(tbxBash){
					let tty=await tbxBash.createTTY();
					tty.session=session;
					return tty;
				}
				return null;
			};
			
			//Add note:
			session.WSCall_AddNote=function(message){
				if(tbxNotes){
					tbxNotes.addNote(message.note);
				}
			};
	
			//Report project env/project info:
			session.WSCall_RegEnvProjectInfo=function(message){
				if(tbxNotes){
					tbxNotes.regEnv(message.env,message.project);
				}
			};
			
			//Add a file:
			session.WSCall_NewHubFile=function(fileName){
				if(tbxFiles){
					tbxFiles.addFile(fileName);
				}
			};
			
			//Run a html code inside client-side web sandbox:
			session.WSCall_WebSandbox=async function(code,opts){
				if(tbxSandbox){
					//naviTabs.focusOn(tabSandbox);
					//self.showFace("tbxSandbox");
					self.notifySandbox();
					return await tbxSandbox.runCode(session,code,opts);
				}
			};
			
			//GetClient rect:
			session.WSCall_GetClientRect=function(){
				return getElementScreenPosition(self.webObj);
			};
	
			//GetClient rect:
			session.WSCall_GetToolDockRect=function(){
				return getElementScreenPosition(boxTools.webObj);
			};
			
			if(slowMo){
				session.setSlowMo(true);
			}
			if(stepRun){
				session.setStepRun(true,self.showLocalPaused);
			}
		};
		
		//Convert file system path to URL:
		self.showFace("init");
		ext=pathLib.extname(path);
		if(ext===".py" || VFACT.appParams.isServer|| VFACT.appParams.agentNode){
			let nodeName=VFACT.appParams.agentNode||VFACT.appParams.node;
			let localPath,result;
			if(!nodeName){
				//nodeName=window.prompt("Input debug agent node name:",VFACT.appParams.prjName||"");
				nodeName=await app.modalDlg("/@StdUI/ui/DlgPrompt.js",{title:(($ln==="CN")?("输入调试智能体节点名称:"):/*EN*/("Input debug agent node name:")),text:VFACT.appParams.prjName||""});
			}
			localPath="/@aichat/ai/RemoteChat.js";
			try{
				result=await boxAIChat.initChat({
					url:localPath,argument:{nodeName:nodeName,callAgent:pathLib.basename(path),callArg:args,checkUpdate:true},
					setup:setup,chatClient:chatClient,chatThread:chatThread,
				});
				if(callback){
					callback(result);
				}
			}catch(error){
				//Show error:
				boxAIChat.BoxChats.appendChatBlock({type:"error",text:""+error});
				console.error(error);				
				if(callerror){
					callerror(error);
				}
			}
		}else if(ext===".js"){
			let result;
			//Fix URL if needed:
			if(path[0]==="/" && path[1]!=="/" && path[1]!=="~" && path[1]!=="@"){
				path="/~"+path;
			}
			if(path[0]!=="/" && (!path.startsWith("http://")) &&(!path.startsWith("https://"))){
				path=app.path2AppURL(path);
			}
	
			//Init/setup the agent and start chat:
			try{
				result=await boxAIChat.initChat({
					url:path,arguments:args,setup:setup,chatClient:chatClient,chatThread:chatThread,
				});
				if(callback){
					callback(result);
				}
			}catch(error){
				//Show error:
				boxAIChat.BoxChats.appendChatBlock({type:"error",text:""+error});
				console.error(error);				
				if(callerror){
					callerror(error);
				}
			}
		}else if(ext===".aichat"){
			//No longer support this.
			//Show error:
			let error;
			error=Error("Sorry, '.aichat' files are no longer supported for debug.");
			boxAIChat.BoxChats.appendChatBlock({type:"error",text:""+error});
			console.error(error);				
			if(callerror){
				callerror(error);
			}
		}else{
			let error;
			error=Error(`Unsupport agent file ext type: ${ext} for url: ${path}.`);
			boxAIChat.BoxChats.appendChatBlock({type:"error",text:""+error});
			console.error(error);				
			if(callerror){
				callerror(error);
			}
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.showLocalPaused=async function(input,phase,cmd){
		let pms;
		pms=new Promise((resolve,reject)=>{
			localExecCallback=resolve;
		});
		execPaused=true;
		app.emit("AIExecPaused");
		await pms;
		return input;
	};
	
	//------------------------------------------------------------------------
	app.setSlowMo=async function(enable){
		let ws;
		if(session){
			session.setSlowMo(enable);
		}
		for(ws of debugSockets){
			ws.send(JSON.stringify({cmd:"SlowMo",enable:enable}));
		}
		slowMo=enable;
	};
	
	//------------------------------------------------------------------------
	app.setStepRun=async function(enable){
		let ws;
		if(session){
			session.setStepRun(enable,self.showLocalPaused);
		}
		for(ws of debugSockets){
			if(enable){
				ws.send(JSON.stringify({cmd:"StepRunOn"}));
			}else{
				ws.send(JSON.stringify({cmd:"StepRunOff"}));
			}
		}
		stepRun=!!enable;
	};
	
	//------------------------------------------------------------------------
	app.resumeAIRun=async function(enable){
		let ws,callback;
		callback=localExecCallback;
		if(callback){
			localExecCallback=false;
			callback();
		}
		for(ws of debugSockets){
			if(ws.stepPaused){
				ws.send(JSON.stringify({cmd:"RunStep"}));
			}
		}
	};
	
	//------------------------------------------------------------------------
	app.editConfig=async function(){
		let models,config;
		models=session.globalContext.models||{};
		config={models:models};
		config=await app.modalDlg("/@StdUI/ui/DlgDataView.js",{
			template:AIConfig,object:config,title:(($ln==="CN")?("智能体会话设置"):/*EN*/("Agent Session Settings")),width:500,
		});
		if(config && config.models){
			Object.assign(session.globalContext.models,config.models);
		}
	};
	/*}#1GGJKM84D1PostCSSVO*/
	cssVO.constructor=MainUI;
	return cssVO;
};
/*#{1GGJKM84D1ExCodes*/
/*}#1GGJKM84D1ExCodes*/

//----------------------------------------------------------------------------
MainUI.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1GGJKM84D1PreAISpot*/
	/*}#1GGJKM84D1PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1GGJKM84D1PostAISpot*/
	/*}#1GGJKM84D1PostAISpot*/
	return exposeVO;
};

/*#{1GGJKM84D0EndDoc*/
/*}#1GGJKM84D0EndDoc*/

export default MainUI;
export{MainUI};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "UIView",
//	"jaxId": "1GGJKM84D0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1GGJKM84D2",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "900",
//				"screenH": "600",
//				"bgColor": "#cfgColor.body",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1GGJKM84D3",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1H90TKKV70",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1GGJKM84D4",
//			"attrs": {
//				"app": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"appFrame": {
//					"type": "auto",
//					"valText": "null"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1GGJKM84D5",
//			"attrs": {
//				"title": {
//					"type": "string",
//					"valText": "Project Wizard",
//					"localize": {
//						"EN": "Project Wizard",
//						"CN": "项目向导"
//					},
//					"localizable": true
//				},
//				"appendProcessBlock": {
//					"type": "auto",
//					"valText": ""
//				}
//			}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1GGJKM84D6",
//			"attrs": {
//				"counter": {
//					"type": "int",
//					"valText": "0"
//				}
//			}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IIPJ51GL0",
//					"attrs": {
//						"id": "connectDebug",
//						"label": "New AI Seg",
//						"x": "90",
//						"y": "55",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IIPJ5JKT0",
//							"attrs": {
//								"address": {
//									"type": "string",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IIPJ5JKT1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IIPJ5JKT2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IHUJE1HL0",
//					"attrs": {
//						"id": "showTbxBash",
//						"label": "New AI Seg",
//						"x": "90",
//						"y": "125",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IHUJFPU80",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IHUJFPU81",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": [
//								{
//									"type": "flowseg",
//									"def": "SetFace",
//									"jaxId": "1IHUJFPU82",
//									"attrs": {
//										"id": "SetFace",
//										"label": "New AI Seg",
//										"x": "345",
//										"y": "125",
//										"desc": "",
//										"codes": "false",
//										"component": "self",
//										"face": "tbxBash",
//										"outlet": {
//											"jaxId": "1IHUJFPU83",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											},
//											"linkedSeg": "1IQ7Q55DT0"
//										}
//									},
//									"icon": "faces.svg"
//								},
//								{
//									"type": "flowseg",
//									"def": "Code",
//									"jaxId": "1IQ7Q55DT0",
//									"attrs": {
//										"id": "RefreshTab",
//										"label": "New AI Seg",
//										"x": "545",
//										"y": "125",
//										"desc": "",
//										"codes": "false",
//										"outlet": {
//											"jaxId": "1IQ7Q55E00",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											}
//										}
//									},
//									"icon": "tab_css.svg"
//								}
//							]
//						},
//						"outlet": {
//							"jaxId": "1IHUJFPU84",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1IHUJFPU82"
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IHUJELCJ0",
//					"attrs": {
//						"id": "showTbxNotes",
//						"label": "New AI Seg",
//						"x": "90",
//						"y": "205",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IHUJFPU85",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IHUJFPU86",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": [
//								{
//									"type": "flowseg",
//									"def": "SetFace",
//									"jaxId": "1IHUJFPU87",
//									"attrs": {
//										"id": "SetFace",
//										"label": "New AI Seg",
//										"x": "345",
//										"y": "205",
//										"desc": "",
//										"codes": "false",
//										"component": "self",
//										"face": "tbxNotes",
//										"outlet": {
//											"jaxId": "1IHUJFPU88",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											}
//										}
//									},
//									"icon": "faces.svg"
//								}
//							]
//						},
//						"outlet": {
//							"jaxId": "1IHUJFPU89",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1IHUJFPU87"
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1II6CP44V0",
//					"attrs": {
//						"id": "showTbxInference",
//						"label": "New AI Seg",
//						"x": "90",
//						"y": "290",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1II6CPNOK0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1II6CPNOK1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": [
//								{
//									"type": "flowseg",
//									"def": "SetFace",
//									"jaxId": "1II6CPNOK2",
//									"attrs": {
//										"id": "SetFace",
//										"label": "New AI Seg",
//										"x": "345",
//										"y": "290",
//										"desc": "",
//										"codes": "false",
//										"component": "self",
//										"face": "tbxInference",
//										"outlet": {
//											"jaxId": "1II6CPNOK3",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											},
//											"linkedSeg": "1II6Q1MCO0"
//										}
//									},
//									"icon": "faces.svg"
//								},
//								{
//									"type": "flowseg",
//									"def": "Code",
//									"jaxId": "1II6Q1MCO0",
//									"attrs": {
//										"id": "Render",
//										"label": "New AI Seg",
//										"x": "540",
//										"y": "290",
//										"desc": "",
//										"codes": "false",
//										"outlet": {
//											"jaxId": "1II6Q1MCS0",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											}
//										}
//									},
//									"icon": "tab_css.svg"
//								}
//							]
//						},
//						"outlet": {
//							"jaxId": "1II6CPNOK4",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1II6CPNOK2"
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IIQDJIM60",
//					"attrs": {
//						"id": "showTbxLogs",
//						"label": "New AI Seg",
//						"x": "90",
//						"y": "390",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IIQDK3MG0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IIQDK3MG1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": [
//								{
//									"type": "flowseg",
//									"def": "SetFace",
//									"jaxId": "1IIQDK3MG2",
//									"attrs": {
//										"id": "SetFace",
//										"label": "New AI Seg",
//										"x": "340",
//										"y": "390",
//										"desc": "",
//										"codes": "false",
//										"component": "self",
//										"face": "tbxLogs",
//										"outlet": {
//											"jaxId": "1IIQDK3MG3",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											}
//										}
//									},
//									"icon": "faces.svg"
//								}
//							]
//						},
//						"outlet": {
//							"jaxId": "1IIQDK3MG4",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1IIQDK3MG2"
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IJJ337E60",
//					"attrs": {
//						"id": "showTbxFiles",
//						"label": "New AI Seg",
//						"x": "90",
//						"y": "480",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IJJ33VUA0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IJJ33VUA1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": [
//								{
//									"type": "flowseg",
//									"def": "SetFace",
//									"jaxId": "1IJJ33VUA2",
//									"attrs": {
//										"id": "SetFace",
//										"label": "New AI Seg",
//										"x": "345",
//										"y": "480",
//										"desc": "",
//										"codes": "false",
//										"component": "self",
//										"face": "tbxFiles",
//										"outlet": {
//											"jaxId": "1IJJ33VUA3",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											}
//										}
//									},
//									"icon": "faces.svg"
//								}
//							]
//						},
//						"outlet": {
//							"jaxId": "1IJJ33VUA4",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1IJJ33VUA2"
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IN8GKLIC0",
//					"attrs": {
//						"id": "showTbxSandbox",
//						"label": "New AI Seg",
//						"x": "90",
//						"y": "580",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IN8GLD1D0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IN8GLD1D1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": [
//								{
//									"type": "flowseg",
//									"def": "SetFace",
//									"jaxId": "1IN8GLD1D2",
//									"attrs": {
//										"id": "SetFace",
//										"label": "New AI Seg",
//										"x": "350",
//										"y": "580",
//										"desc": "",
//										"codes": "false",
//										"component": "self",
//										"face": "tbxSandbox",
//										"outlet": {
//											"jaxId": "1IN8GLD1D3",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											}
//										}
//									},
//									"icon": "faces.svg"
//								}
//							]
//						},
//						"outlet": {
//							"jaxId": "1IN8GLD1D4",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1IN8GLD1D2"
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IJI6LE7N0",
//					"attrs": {
//						"id": "notifyBash",
//						"label": "New AI Seg",
//						"x": "90",
//						"y": "665",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IJI6N1MO0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IJI6N1MO1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IJI6N1MO2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IJI6LMIG0",
//					"attrs": {
//						"id": "notifyFile",
//						"label": "New AI Seg",
//						"x": "340",
//						"y": "665",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IJI6N1MO3",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IJI6N1MO4",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IJI6N1MO5",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IJI6M3L80",
//					"attrs": {
//						"id": "notifyNote",
//						"label": "New AI Seg",
//						"x": "580",
//						"y": "665",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IJI6N1MO6",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IJI6N1MO7",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IJI6N1MO8",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IN8GPG290",
//					"attrs": {
//						"id": "notifySandbox",
//						"label": "New AI Seg",
//						"x": "810",
//						"y": "665",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IN8GPRG00",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IN8GPRG01",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IN8GPRG02",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IRPPJ39C0",
//					"attrs": {
//						"id": "checkLogin",
//						"label": "New AI Seg",
//						"x": "345",
//						"y": "55",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IRPPJA2P0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IRPPJA2P1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IRPPJA2P2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1J12TU51T0",
//					"attrs": {
//						"id": "appendProcessBlock",
//						"label": "New AI Seg",
//						"x": "730",
//						"y": "290",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1J12TV3150",
//							"attrs": {
//								"vo": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1J12TV3151",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1J12TV3152",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				}
//			]
//		},
//		"exportTarget": "VFACT document",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1GGJKM84D7",
//			"attrs": {
//				"embed": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1ILNRS8JT0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1ILNRTQC60",
//							"attrs": {}
//						}
//					}
//				},
//				"wideChat": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1J3BS13HE0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1J3BS3GP00",
//							"attrs": {}
//						}
//					}
//				},
//				"tbxBash": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IHUJ66RM0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IHUJ6S5C0",
//							"attrs": {}
//						}
//					}
//				},
//				"tbxNotes": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IHUJ6BT40",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IHUJ6S5C1",
//							"attrs": {}
//						}
//					}
//				},
//				"tbxInference": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1II6BHM6B0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1II6BIG4G0",
//							"attrs": {}
//						}
//					}
//				},
//				"tbxLogs": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IIQDG1070",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IIQDHHU40",
//							"attrs": {}
//						}
//					}
//				},
//				"tbxFiles": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IJID11VL0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IJID2C9U0",
//							"attrs": {}
//						}
//					}
//				},
//				"tbxSandbox": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IN8GGK0D0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IN8GJRCE0",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1HDBOJDB10",
//			"attrs": {}
//		},
//		"exposeToAI": "true",
//		"descAI": "",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "view",
//			"jaxId": "1GGJKM84D1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1GGJKM84D8",
//					"attrs": {
//						"type": "view",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "100%",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Block"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "Gear/@aichat/ui/BoxTokenGas.js",
//							"jaxId": "1HHAMBFU40",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1HHAMC8EB0",
//									"attrs": {
//										"h": "30",
//										"bgColor": "#cfgColor[\"secondary\"]",
//										"textColor": "#cfgColor[\"fontSecondary\"]",
//										"iconSize": "24",
//										"fontSize": "16",
//										"menu": "false",
//										"thin": "false",
//										"chatIcon": "#appCfg.sharedAssets+\"/ablogo.svg\"",
//										"chatIconSize": "30"
//									}
//								},
//								"properties": {
//									"jaxId": "1HHAMC8EB1",
//									"attrs": {
//										"type": "#null#>BoxTokenGas(30,cfgColor[\"secondary\"],cfgColor[\"fontSecondary\"],24,16,false,false,appCfg.sharedAssets+\"/ablogo.svg\",30)",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"display": "On",
//										"face": "",
//										"caption": "#title"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HHAMC8EB2",
//									"attrs": {
//										"1II6BHM6B0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IIQDHHU43",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IIQDHHU44",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1II6BHM6B0",
//											"faceTagName": "tbxInference"
//										},
//										"1IIQDG1070": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IJID2C9U5",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IJID2C9U6",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IIQDG1070",
//											"faceTagName": "tbxLogs"
//										},
//										"1ILNRS8JT0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1ILNRTQC61",
//											"attrs": {
//												"properties": {
//													"jaxId": "1ILNRTQC62",
//													"attrs": {
//														"y": {
//															"type": "length",
//															"valText": "100%"
//														},
//														"anchorV": {
//															"type": "choice",
//															"valText": "Bottom"
//														},
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1ILNRS8JT0",
//											"faceTagName": "embed"
//										},
//										"1IN8GGK0D0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IN8GJRCE1",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IN8GJRCE2",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IN8GGK0D0",
//											"faceTagName": "tbxSandbox"
//										},
//										"1IHUJ6BT40": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IN8GJRCE3",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IN8GJRCE4",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IHUJ6BT40",
//											"faceTagName": "tbxNotes"
//										},
//										"1IJID11VL0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IN8GJRCE5",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IN8GJRCE6",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IJID11VL0",
//											"faceTagName": "tbxFiles"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HHAMC8EB3",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HHAMC8EB4",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false",
//								"containerSlots": {
//									"jaxId": "1HHAMC8EB5",
//									"attrs": {}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1HDBT1RJN0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HDBT8BEP8",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxChat",
//										"position": "Absolute",
//										"x": "0",
//										"y": "30",
//										"w": "480",
//										"h": "100%-30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": ""
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "Gear/@aichat/ui/UIChat.js",
//											"jaxId": "1HDBT34IS0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1HDBT8BEP9",
//													"attrs": {
//														"opts": {
//															"jaxId": "1HDBT8BEP10",
//															"attrs": {
//																"bubble": "false",
//																"ai": {
//																	"jaxId": "1HDBT8BEP11",
//																	"attrs": {
//																		"blkColor": "[0,0,0,0.00]",
//																		"bgColor": "#cfgColor[\"success\"]",
//																		"icon": "#appCfg.sharedAssets+\"/faces.svg\"",
//																		"pic": "",
//																		"textColor": "#cfgColor[\"fontBody\"]",
//																		"iconColor": "#cfgColor[\"fontSuccess\"]",
//																		"side": "left"
//																	}
//																},
//																"user": {
//																	"jaxId": "1HDBT8BEP12",
//																	"attrs": {
//																		"blkColor": "[0,0,0,0.00]",
//																		"bgColor": "#cfgColor.primary",
//																		"icon": "#appCfg.sharedAssets+\"/user.svg\"",
//																		"pic": "",
//																		"textColor": "#cfgColor[\"fontBody\"]",
//																		"iconColor": "#cfgColor[\"fontPrimary\"]",
//																		"side": "right"
//																	}
//																},
//																"wait": {
//																	"jaxId": "1HDBT8BEP13",
//																	"attrs": {
//																		"blkColor": "[0,0,0,0.00]",
//																		"bgColor": "#cfgColor[\"secondary\"]",
//																		"icon": "#appCfg.sharedAssets+\"/faces.svg\"",
//																		"pic": "",
//																		"textColor": "#cfgColor[\"fontBody\"]",
//																		"iconColor": "#cfgColor[\"fontSecondary\"]",
//																		"side": "left"
//																	}
//																},
//																"event": {
//																	"jaxId": "1HDBT8BEP14",
//																	"attrs": {
//																		"blkColor": "[0,0,0,0.00]",
//																		"bgColor": "#cfgColor[\"warning\"]",
//																		"icon": "#appCfg.sharedAssets+\"/event.svg\"",
//																		"pic": "",
//																		"textColor": "#cfgColor[\"fontBody\"]",
//																		"iconColor": "#cfgColor[\"fontWarning\"]",
//																		"side": "left"
//																	}
//																},
//																"error": {
//																	"jaxId": "1HDBT8BEP15",
//																	"attrs": {
//																		"blkColor": "[0,0,0,0.00]",
//																		"bgColor": "#cfgColor[\"error\"]",
//																		"icon": "#appCfg.sharedAssets+\"/fat_right.svg\"",
//																		"pic": "",
//																		"textColor": "[155,0,0,1.00]",
//																		"iconColor": "#cfgColor[\"fontError\"]",
//																		"side": "left"
//																	}
//																},
//																"ask": {
//																	"jaxId": "1HDBT8BEP16",
//																	"attrs": {
//																		"blkColor": "[0,0,0,0.00]",
//																		"bgColor": "#cfgColor[\"success\"]",
//																		"icon": "#appCfg.sharedAssets+\"/help.svg\"",
//																		"pic": "",
//																		"textColor": "#cfgColor[\"fontBody\"]",
//																		"iconColor": "#cfgColor[\"fontSuccess\"]",
//																		"side": "left"
//																	}
//																},
//																"allowFile": "false",
//																"appendProcessBlock": "#appendProcessBlock"
//															}
//														}
//													}
//												},
//												"properties": {
//													"jaxId": "1HDBT8BEP17",
//													"attrs": {
//														"type": "#null#>UIChat({\"bubble\":false,\"ai\":{\"blkColor\":[0,0,0,0],\"bgColor\":cfgColor[\"success\"],\"icon\":appCfg.sharedAssets+\"/faces.svg\",\"pic\":\"\",\"textColor\":cfgColor[\"fontBody\"],\"iconColor\":cfgColor[\"fontSuccess\"],\"side\":\"left\"},\"user\":{\"blkColor\":[0,0,0,0],\"bgColor\":cfgColor.primary,\"icon\":appCfg.sharedAssets+\"/user.svg\",\"pic\":\"\",\"textColor\":cfgColor[\"fontBody\"],\"iconColor\":cfgColor[\"fontPrimary\"],\"side\":\"right\"},\"wait\":{\"blkColor\":[0,0,0,0],\"bgColor\":cfgColor[\"secondary\"],\"icon\":appCfg.sharedAssets+\"/faces.svg\",\"pic\":\"\",\"textColor\":cfgColor[\"fontBody\"],\"iconColor\":cfgColor[\"fontSecondary\"],\"side\":\"left\"},\"event\":{\"blkColor\":[0,0,0,0],\"bgColor\":cfgColor[\"warning\"],\"icon\":appCfg.sharedAssets+\"/event.svg\",\"pic\":\"\",\"textColor\":cfgColor[\"fontBody\"],\"iconColor\":cfgColor[\"fontWarning\"],\"side\":\"left\"},\"error\":{\"blkColor\":[0,0,0,0],\"bgColor\":cfgColor[\"error\"],\"icon\":appCfg.sharedAssets+\"/fat_right.svg\",\"pic\":\"\",\"textColor\":[155,0,0,1],\"iconColor\":cfgColor[\"fontError\"],\"side\":\"left\"},\"ask\":{\"blkColor\":[0,0,0,0],\"bgColor\":cfgColor[\"success\"],\"icon\":appCfg.sharedAssets+\"/help.svg\",\"pic\":\"\",\"textColor\":cfgColor[\"fontBody\"],\"iconColor\":cfgColor[\"fontSuccess\"],\"side\":\"left\"},\"allowFile\":false,\"appendProcessBlock\":appendProcessBlock})",
//														"id": "BoxAIChat",
//														"position": "Absolute",
//														"x": "0",
//														"y": "30",
//														"display": "On",
//														"face": "",
//														"h": "100%-30"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HDBT8BEP18",
//													"attrs": {
//														"1II6BHM6B0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IIQDHHU47",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IIQDHHU48",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II6BHM6B0",
//															"faceTagName": "tbxInference"
//														},
//														"1IIQDG1070": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IJID2C9V0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IJID2C9V1",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IIQDG1070",
//															"faceTagName": "tbxLogs"
//														},
//														"1ILNRS8JT0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1ILOBI4860",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1ILOBI4861",
//																	"attrs": {
//																		"y": {
//																			"type": "length",
//																			"valText": "0"
//																		},
//																		"h": {
//																			"type": "length",
//																			"valText": "100%"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1ILNRS8JT0",
//															"faceTagName": "embed"
//														},
//														"1IN8GGK0D0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IN8GJRCE7",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IN8GJRCE8",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IN8GGK0D0",
//															"faceTagName": "tbxSandbox"
//														},
//														"1IHUJ6BT40": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IN8GJRCE9",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IN8GJRCE10",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IHUJ6BT40",
//															"faceTagName": "tbxNotes"
//														},
//														"1IJID11VL0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IN8GJRCE11",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IN8GJRCE12",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IJID11VL0",
//															"faceTagName": "tbxFiles"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HDBT8BEP19",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HDBT8BEP20",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "true",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1HDBT8BEP21",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1IHRRMK5D0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IHRRNEVK0",
//													"attrs": {
//														"type": "box",
//														"id": "BoxChatHeader",
//														"position": "Absolute",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "30",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "[0,13,0,5]",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "#cfgColor[\"body\"]",
//														"border": "[0,0,1,0]",
//														"borderStyle": "Solid",
//														"borderColor": "#cfgColor[\"fontBodySub\"]",
//														"corner": "0",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]",
//														"contentLayout": "Flex X",
//														"itemsAlign": "Center"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1IHRRSCOS0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IHRRTRA20",
//																	"attrs": {
//																		"type": "text",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[0,0,0,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontBody\"]",
//																		"text": "Agent chats",
//																		"font": "",
//																		"fontSize": "16",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Top",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"lineClamp": "0",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0",
//																		"flex": "true"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IHRRTRA21",
//																	"attrs": {
//																		"1II6BHM6B0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IIQDHHU411",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IIQDHHU412",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1II6BHM6B0",
//																			"faceTagName": "tbxInference"
//																		},
//																		"1IIQDG1070": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJID2C9V6",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJID2C9V7",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IIQDG1070",
//																			"faceTagName": "tbxLogs"
//																		},
//																		"1IN8GGK0D0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IN8GJRCE13",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IN8GJRCE14",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IN8GGK0D0",
//																			"faceTagName": "tbxSandbox"
//																		},
//																		"1IHUJ6BT40": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IN8GJRCE15",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IN8GJRCE16",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IHUJ6BT40",
//																			"faceTagName": "tbxNotes"
//																		},
//																		"1IJID11VL0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IN8GJRCE17",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IN8GJRCE18",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IJID11VL0",
//																			"faceTagName": "tbxFiles"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1IHRRTRA22",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1IHRRTRA23",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1INGIS8QL0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1INGIS8QL1",
//																	"attrs": {
//																		"style": "\"front\"",
//																		"w": "26",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/settings.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1INGIS8QL2",
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"front\",26,0,appCfg.sharedAssets+\"/settings.svg\",null)",
//																		"id": "BtnClearChat",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"enable": "true",
//																		"margin": "[0,5,0,0]"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1INGIS8QM0",
//																	"attrs": {
//																		"1II6BHM6B0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1INGIS8QM1",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1INGIS8QM2",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1II6BHM6B0",
//																			"faceTagName": "tbxInference"
//																		},
//																		"1IIQDG1070": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1INGIS8QM3",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1INGIS8QM4",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IIQDG1070",
//																			"faceTagName": "tbxLogs"
//																		},
//																		"1IN8GGK0D0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1INGIS8QM5",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1INGIS8QM6",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IN8GGK0D0",
//																			"faceTagName": "tbxSandbox"
//																		},
//																		"1IHUJ6BT40": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1INGIS8QM7",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1INGIS8QM8",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IHUJ6BT40",
//																			"faceTagName": "tbxNotes"
//																		},
//																		"1IJID11VL0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1INGIS8QM9",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1INGIS8QM10",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IJID11VL0",
//																			"faceTagName": "tbxFiles"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1INGIS8QM11",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1INGIS8QM12",
//																	"attrs": {
//																		"tip": {
//																			"type": "string",
//																			"valText": "AI config",
//																			"localize": {
//																				"EN": "AI config",
//																				"CN": "AI 设置"
//																			},
//																			"localizable": true
//																		}
//																	}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1INGIS8QM13",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1IHRRO8470",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1IHRRQRKQ0",
//																	"attrs": {
//																		"style": "\"front\"",
//																		"w": "26",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/trash.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1IHRRQRKQ1",
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"front\",26,0,appCfg.sharedAssets+\"/trash.svg\",null)",
//																		"id": "BtnClearChat",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"enable": "false"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IHRRQRKQ2",
//																	"attrs": {
//																		"1II6BHM6B0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IIQDHHU415",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IIQDHHU416",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1II6BHM6B0",
//																			"faceTagName": "tbxInference"
//																		},
//																		"1IIQDG1070": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJID2C9V12",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJID2C9V13",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IIQDG1070",
//																			"faceTagName": "tbxLogs"
//																		},
//																		"1IN8GGK0D0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IN8GJRCE19",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IN8GJRCE20",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IN8GGK0D0",
//																			"faceTagName": "tbxSandbox"
//																		},
//																		"1IHUJ6BT40": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IN8GJRCE21",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IN8GJRCE22",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IHUJ6BT40",
//																			"faceTagName": "tbxNotes"
//																		},
//																		"1IJID11VL0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IN8GJRCE23",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IN8GJRCE24",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IJID11VL0",
//																			"faceTagName": "tbxFiles"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1IHRRQRKQ3",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1IHRRQRKQ4",
//																	"attrs": {
//																		"tip": {
//																			"type": "string",
//																			"valText": "Clear",
//																			"localize": {
//																				"EN": "Clear",
//																				"CN": "清除"
//																			},
//																			"localizable": true
//																		}
//																	}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1IHRRQRKQ5",
//																	"attrs": {}
//																}
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1IHRRNEVK1",
//													"attrs": {
//														"1II6BHM6B0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IIQDHHU419",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IIQDHHU420",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II6BHM6B0",
//															"faceTagName": "tbxInference"
//														},
//														"1IIQDG1070": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IJID2C9V18",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IJID2C9V19",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IIQDG1070",
//															"faceTagName": "tbxLogs"
//														},
//														"1ILNRS8JT0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1ILOBI4866",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1ILOBI4867",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1ILNRS8JT0",
//															"faceTagName": "embed"
//														},
//														"1IN8GGK0D0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IN8GJRCE25",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IN8GJRCE26",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IN8GGK0D0",
//															"faceTagName": "tbxSandbox"
//														},
//														"1IHUJ6BT40": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IN8GJRCE27",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IN8GJRCE28",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IHUJ6BT40",
//															"faceTagName": "tbxNotes"
//														},
//														"1IJID11VL0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IN8GJRCE29",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IN8GJRCE30",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IJID11VL0",
//															"faceTagName": "tbxFiles"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IHRRNEVK2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IHRRNEVK3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1IHROFSPO0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IHROGNGN0",
//													"attrs": {
//														"type": "box",
//														"id": "",
//														"position": "Absolute",
//														"x": "100%-1",
//														"y": "0",
//														"w": "1",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "#cfgColor[\"fontBodySub\"]",
//														"border": "0",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IHROGNGN1",
//													"attrs": {
//														"1II6BHM6B0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IIQDHHU423",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IIQDHHU424",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II6BHM6B0",
//															"faceTagName": "tbxInference"
//														},
//														"1IIQDG1070": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IJID2C9V24",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IJID2C9V25",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IIQDG1070",
//															"faceTagName": "tbxLogs"
//														},
//														"1IN8GGK0D0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IN8GJRCE31",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IN8GJRCE32",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IN8GGK0D0",
//															"faceTagName": "tbxSandbox"
//														},
//														"1IHUJ6BT40": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IN8GJRCE33",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IN8GJRCE34",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IHUJ6BT40",
//															"faceTagName": "tbxNotes"
//														},
//														"1IJID11VL0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IN8GJRCE35",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IN8GJRCE36",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IJID11VL0",
//															"faceTagName": "tbxFiles"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IHROGNGN2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IHROGNGN3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1HDBT8BEP22",
//									"attrs": {
//										"1II6BHM6B0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IIQDHHU427",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IIQDHHU428",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1II6BHM6B0",
//											"faceTagName": "tbxInference"
//										},
//										"1IIQDG1070": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IJID2C9V30",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IJID2C9V31",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IIQDG1070",
//											"faceTagName": "tbxLogs"
//										},
//										"1ILNRS8JT0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1ILNRTQC710",
//											"attrs": {
//												"properties": {
//													"jaxId": "1ILNRTQC711",
//													"attrs": {
//														"y": {
//															"type": "length",
//															"valText": "0"
//														},
//														"h": {
//															"type": "length",
//															"valText": "100%"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1ILNRS8JT0",
//											"faceTagName": "embed"
//										},
//										"1IN8GGK0D0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IN8GJRCE37",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IN8GJRCE38",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IN8GGK0D0",
//											"faceTagName": "tbxSandbox"
//										},
//										"1IHUJ6BT40": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IN8GJRCE39",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IN8GJRCE40",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IHUJ6BT40",
//											"faceTagName": "tbxNotes"
//										},
//										"1IJID11VL0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IN8GJRCE41",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IN8GJRCE42",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IJID11VL0",
//											"faceTagName": "tbxFiles"
//										},
//										"1J3BS13HE0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1J3BS3GP12",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J3BS3GP13",
//													"attrs": {
//														"w": "600"
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1J3BS13HE0",
//											"faceTagName": "wideChat"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HDBT8BEP23",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HDBT8BEP24",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1IHRSFUAP0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IHRSK5840",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxTools",
//										"position": "Absolute",
//										"x": "480",
//										"y": "30",
//										"w": "100%-480",
//										"h": "100%-30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": ""
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1IHRSON170",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IHRSON171",
//													"attrs": {
//														"type": "box",
//														"id": "BoxToolFooter",
//														"position": "Absolute",
//														"x": "0",
//														"y": "100%-30",
//														"w": "100%",
//														"h": "30",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "[0,2,0,2]",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "#cfgColor[\"body\"]",
//														"border": "[1,0,0,0]",
//														"borderStyle": "Solid",
//														"borderColor": "#cfgColor[\"fontBodySub\"]",
//														"corner": "0",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/NaviToolBar.js",
//															"jaxId": "1IHRT3E2S0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1IHRT61GM0",
//																	"attrs": {
//																		"tabBG": "true"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1IHRT61GM1",
//																	"attrs": {
//																		"type": "#null#>NaviToolBar(true)",
//																		"id": "NaviTabs",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"w": "100%"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IHRT61GM2",
//																	"attrs": {
//																		"1II6BHM6B0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IIQDHHU431",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IIQDHHU432",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1II6BHM6B0",
//																			"faceTagName": "tbxInference"
//																		},
//																		"1IIQDG1070": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJID2C9V36",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJID2C9V37",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IIQDG1070",
//																			"faceTagName": "tbxLogs"
//																		},
//																		"1IN8GGK0D0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IN8GJRCE43",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IN8GJRCE44",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IN8GGK0D0",
//																			"faceTagName": "tbxSandbox"
//																		},
//																		"1IHUJ6BT40": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IN8GJRCE45",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IN8GJRCE46",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IHUJ6BT40",
//																			"faceTagName": "tbxNotes"
//																		},
//																		"1IJID11VL0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IN8GJRCE47",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IN8GJRCE48",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IJID11VL0",
//																			"faceTagName": "tbxFiles"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1IHRT61GM3",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1IHRT61GM4",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "true",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1IHRT61GM5",
//																	"attrs": {
//																		"Slot1HL4P0I9P0": {
//																			"jaxId": "1IHRT61GM6",
//																			"attrs": {
//																				"subHuds": {
//																					"attrs": [
//																						{
//																							"type": "hudobj",
//																							"def": "Gear/@StdUI/ui/BtnNaviItem.js",
//																							"jaxId": "1II4R1QQ40",
//																							"attrs": {
//																								"createArgs": {
//																									"jaxId": "1II4R1QQ41",
//																									"attrs": {
//																										"code": "Notes",
//																										"text": {
//																											"type": "string",
//																											"valText": "Inference",
//																											"localize": {
//																												"EN": "Inference",
//																												"CN": "推理视图"
//																											},
//																											"localizable": true
//																										},
//																										"color": "[0,0,0,1.00]",
//																										"icon": "#appCfg.sharedAssets+\"/memory.svg\"",
//																										"items": "",
//																										"fontSize": "#txtSize.smallPlus",
//																										"hasClose": "false",
//																										"iconSize": "0",
//																										"mark": "true"
//																									}
//																								},
//																								"properties": {
//																									"jaxId": "1II4R1QQ42",
//																									"attrs": {
//																										"type": "#null#>BtnNaviItem(\"Notes\",(($ln===\"CN\")?(\"推理视图\"):(\"Inference\")),[0,0,0,1],appCfg.sharedAssets+\"/memory.svg\",undefined,txtSize.smallPlus,false,0,true)",
//																										"id": "TabNotes",
//																										"position": "relative",
//																										"x": "0",
//																										"y": "0",
//																										"display": "On",
//																										"face": "",
//																										"margin": "[0,3,0,3]"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1II4R1QQ50",
//																									"attrs": {
//																										"1II6BHM6B0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1II6BIG4G39",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1II6BIG4G40",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1II6BHM6B0",
//																											"faceTagName": "tbxInference"
//																										},
//																										"1IIQDG1070": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IIQDHHU50",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IIQDHHU51",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IIQDG1070",
//																											"faceTagName": "tbxLogs"
//																										},
//																										"1IJID11VL0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IJID2C9V38",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IJID2C9V39",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IJID11VL0",
//																											"faceTagName": "tbxFiles"
//																										},
//																										"1IN8GGK0D0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IN8GJRCE49",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IN8GJRCE50",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IN8GGK0D0",
//																											"faceTagName": "tbxSandbox"
//																										},
//																										"1IHUJ6BT40": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IN8GJRCE51",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IN8GJRCE52",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IHUJ6BT40",
//																											"faceTagName": "tbxNotes"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1II4R1QQ55",
//																									"attrs": {
//																										"OnClick": {
//																											"type": "fixedFunc",
//																											"jaxId": "1II4R1QQ56",
//																											"attrs": {
//																												"callArgs": {
//																													"jaxId": "1II4R1QQ57",
//																													"attrs": {
//																														"event": ""
//																													}
//																												},
//																												"seg": "1II6CP44V0"
//																											}
//																										}
//																									}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1II4R1QQ58",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "true",
//																								"containerSlots": {
//																									"jaxId": "1II4R1QQ59",
//																									"attrs": {}
//																								}
//																							}
//																						},
//																						{
//																							"type": "hudobj",
//																							"def": "Gear/@StdUI/ui/BtnNaviItem.js",
//																							"jaxId": "1ILSAPHN50",
//																							"attrs": {
//																								"createArgs": {
//																									"jaxId": "1ILSAPHN51",
//																									"attrs": {
//																										"code": "Path",
//																										"text": {
//																											"type": "string",
//																											"valText": "Canvas",
//																											"localize": {
//																												"EN": "Canvas",
//																												"CN": "画布"
//																											},
//																											"localizable": true
//																										},
//																										"color": "[0,0,0,1.00]",
//																										"icon": "#appCfg.sharedAssets+\"/canvas.svg\"",
//																										"items": "",
//																										"fontSize": "#txtSize.smallPlus",
//																										"hasClose": "false",
//																										"iconSize": "0",
//																										"mark": "true"
//																									}
//																								},
//																								"properties": {
//																									"jaxId": "1ILSAPHN52",
//																									"attrs": {
//																										"type": "#null#>BtnNaviItem(\"Path\",(($ln===\"CN\")?(\"画布\"):(\"Canvas\")),[0,0,0,1],appCfg.sharedAssets+\"/canvas.svg\",undefined,txtSize.smallPlus,false,0,true)",
//																										"id": "TabCanvas",
//																										"position": "relative",
//																										"x": "0",
//																										"y": "0",
//																										"display": "Off",
//																										"face": "",
//																										"margin": "[0,3,0,3]",
//																										"enable": "false"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1ILSAPHN53",
//																									"attrs": {
//																										"1II6BHM6B0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1ILSAPHN56",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1ILSAPHN57",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1II6BHM6B0",
//																											"faceTagName": "tbxInference"
//																										},
//																										"1IIQDG1070": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1ILSAPHN58",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1ILSAPHN59",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IIQDG1070",
//																											"faceTagName": "tbxLogs"
//																										},
//																										"1IJID11VL0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1ILSAPHN510",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1ILSAPHN511",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IJID11VL0",
//																											"faceTagName": "tbxFiles"
//																										},
//																										"1IN8GGK0D0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IN8GJRCE53",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IN8GJRCE54",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IN8GGK0D0",
//																											"faceTagName": "tbxSandbox"
//																										},
//																										"1IHUJ6BT40": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IN8GJRCE55",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IN8GJRCE56",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IHUJ6BT40",
//																											"faceTagName": "tbxNotes"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1ILSAPHN512",
//																									"attrs": {
//																										"OnClick": {
//																											"type": "fixedFunc",
//																											"jaxId": "1ILSAPHN513",
//																											"attrs": {
//																												"callArgs": {
//																													"jaxId": "1ILSAPHN514",
//																													"attrs": {
//																														"event": ""
//																													}
//																												},
//																												"seg": "1IIQDJIM60"
//																											}
//																										}
//																									}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1ILSAPHN515",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "false",
//																								"containerSlots": {
//																									"jaxId": "1ILSAPHN516",
//																									"attrs": {}
//																								}
//																							}
//																						},
//																						{
//																							"type": "hudobj",
//																							"def": "Gear/@StdUI/ui/BtnNaviItem.js",
//																							"jaxId": "1IN3JKQGT0",
//																							"attrs": {
//																								"createArgs": {
//																									"jaxId": "1IN3JKQGT1",
//																									"attrs": {
//																										"code": "Path",
//																										"text": {
//																											"type": "string",
//																											"valText": "Sandbox",
//																											"localize": {
//																												"EN": "Sandbox",
//																												"CN": "沙箱"
//																											},
//																											"localizable": true
//																										},
//																										"color": "[0,0,0,1.00]",
//																										"icon": "#appCfg.sharedAssets+\"/dojo.svg\"",
//																										"items": "",
//																										"fontSize": "#txtSize.smallPlus",
//																										"hasClose": "false",
//																										"iconSize": "0",
//																										"mark": "true"
//																									}
//																								},
//																								"properties": {
//																									"jaxId": "1IN3JKQGT2",
//																									"attrs": {
//																										"type": "#null#>BtnNaviItem(\"Path\",(($ln===\"CN\")?(\"沙箱\"):(\"Sandbox\")),[0,0,0,1],appCfg.sharedAssets+\"/dojo.svg\",undefined,txtSize.smallPlus,false,0,true)",
//																										"id": "TabSandbox",
//																										"position": "relative",
//																										"x": "0",
//																										"y": "0",
//																										"display": "Off",
//																										"face": "",
//																										"margin": "[0,3,0,3]",
//																										"enable": "true"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1IN3JKQGT3",
//																									"attrs": {
//																										"1II6BHM6B0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IN3JKQGT6",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IN3JKQGT7",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1II6BHM6B0",
//																											"faceTagName": "tbxInference"
//																										},
//																										"1IIQDG1070": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IN3JKQGT8",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IN3JKQGT9",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IIQDG1070",
//																											"faceTagName": "tbxLogs"
//																										},
//																										"1IJID11VL0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IN3JKQGT10",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IN3JKQGT11",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IJID11VL0",
//																											"faceTagName": "tbxFiles"
//																										},
//																										"1IN8GGK0D0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IN8GJRCE57",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IN8GJRCE58",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IN8GGK0D0",
//																											"faceTagName": "tbxSandbox"
//																										},
//																										"1IHUJ6BT40": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IN8GJRCE59",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IN8GJRCE60",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IHUJ6BT40",
//																											"faceTagName": "tbxNotes"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1IN3JKQGT12",
//																									"attrs": {
//																										"OnClick": {
//																											"type": "fixedFunc",
//																											"jaxId": "1IN3JKQGT13",
//																											"attrs": {
//																												"callArgs": {
//																													"jaxId": "1IN3JKQGT14",
//																													"attrs": {
//																														"event": ""
//																													}
//																												},
//																												"seg": "1IN8GKLIC0"
//																											}
//																										}
//																									}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1IN3JKQGT15",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "true",
//																								"containerSlots": {
//																									"jaxId": "1IN3JKQGT16",
//																									"attrs": {}
//																								}
//																							}
//																						},
//																						{
//																							"type": "hudobj",
//																							"def": "Gear/@StdUI/ui/BtnNaviItem.js",
//																							"jaxId": "1IIQD8VE20",
//																							"attrs": {
//																								"createArgs": {
//																									"jaxId": "1IIQD8VE21",
//																									"attrs": {
//																										"code": "Path",
//																										"text": "Logs",
//																										"color": "[0,0,0,1.00]",
//																										"icon": "#appCfg.sharedAssets+\"/read.svg\"",
//																										"items": "",
//																										"fontSize": "#txtSize.smallPlus",
//																										"hasClose": "false",
//																										"iconSize": "0",
//																										"mark": "true"
//																									}
//																								},
//																								"properties": {
//																									"jaxId": "1IIQD8VE22",
//																									"attrs": {
//																										"type": "#null#>BtnNaviItem(\"Path\",\"Logs\",[0,0,0,1],appCfg.sharedAssets+\"/read.svg\",undefined,txtSize.smallPlus,false,0,true)",
//																										"id": "TabLogs",
//																										"position": "relative",
//																										"x": "0",
//																										"y": "0",
//																										"display": "On",
//																										"face": "",
//																										"margin": "[0,3,0,3]",
//																										"enable": "true"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1IIQD8VE23",
//																									"attrs": {
//																										"1II6BHM6B0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IIQD8VE30",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IIQD8VE31",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1II6BHM6B0",
//																											"faceTagName": "tbxInference"
//																										},
//																										"1IIQDG1070": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IIQDHHU52",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IIQDHHU53",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IIQDG1070",
//																											"faceTagName": "tbxLogs"
//																										},
//																										"1IJID11VL0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IJID2C9V40",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IJID2C9V41",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IJID11VL0",
//																											"faceTagName": "tbxFiles"
//																										},
//																										"1IN8GGK0D0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IN8GJRCE61",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IN8GJRCE62",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IN8GGK0D0",
//																											"faceTagName": "tbxSandbox"
//																										},
//																										"1IHUJ6BT40": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IN8GJRCE63",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IN8GJRCE64",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IHUJ6BT40",
//																											"faceTagName": "tbxNotes"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1IIQD8VE32",
//																									"attrs": {
//																										"OnClick": {
//																											"type": "fixedFunc",
//																											"jaxId": "1IIQDKI350",
//																											"attrs": {
//																												"callArgs": {
//																													"jaxId": "1IIQDKI351",
//																													"attrs": {
//																														"event": ""
//																													}
//																												},
//																												"seg": "1IIQDJIM60"
//																											}
//																										}
//																									}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1IIQD8VE33",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "false",
//																								"containerSlots": {
//																									"jaxId": "1IIQD8VE34",
//																									"attrs": {}
//																								}
//																							}
//																						},
//																						{
//																							"type": "hudobj",
//																							"def": "Gear/@StdUI/ui/BtnNaviItem.js",
//																							"jaxId": "1IHRT56I80",
//																							"attrs": {
//																								"createArgs": {
//																									"jaxId": "1IHRT61GM7",
//																									"attrs": {
//																										"code": "Home",
//																										"text": "Terminal",
//																										"color": "[0,0,0,1.00]",
//																										"icon": "#appCfg.sharedAssets+\"/terminal.svg\"",
//																										"items": "",
//																										"fontSize": "#txtSize.smallPlus",
//																										"hasClose": "false",
//																										"iconSize": "0",
//																										"mark": "true"
//																									}
//																								},
//																								"properties": {
//																									"jaxId": "1IHRT61GM8",
//																									"attrs": {
//																										"type": "#null#>BtnNaviItem(\"Home\",\"Terminal\",[0,0,0,1],appCfg.sharedAssets+\"/terminal.svg\",undefined,txtSize.smallPlus,false,0,true)",
//																										"id": "TabBash",
//																										"position": "relative",
//																										"x": "0",
//																										"y": "0",
//																										"display": "Off",
//																										"face": "",
//																										"margin": "[0,3,0,3]"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1IHRT61GM9",
//																									"attrs": {
//																										"1II6BHM6B0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1II6BIG4G33",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1II6BIG4G34",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1II6BHM6B0",
//																											"faceTagName": "tbxInference"
//																										},
//																										"1IIQDG1070": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IIQDHHU54",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IIQDHHU55",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IIQDG1070",
//																											"faceTagName": "tbxLogs"
//																										},
//																										"1IJID11VL0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IJID2C9V42",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IJID2C9V43",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IJID11VL0",
//																											"faceTagName": "tbxFiles"
//																										},
//																										"1IN8GGK0D0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IN8GJRCF0",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IN8GJRCF1",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IN8GGK0D0",
//																											"faceTagName": "tbxSandbox"
//																										},
//																										"1IHUJ6BT40": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IN8GJRCF2",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IN8GJRCF3",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IHUJ6BT40",
//																											"faceTagName": "tbxNotes"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1IHRT61GM10",
//																									"attrs": {
//																										"OnClick": {
//																											"type": "fixedFunc",
//																											"jaxId": "1IHUJFPU50",
//																											"attrs": {
//																												"callArgs": {
//																													"jaxId": "1IHUJFPU90",
//																													"attrs": {
//																														"event": ""
//																													}
//																												},
//																												"seg": "1IHUJE1HL0"
//																											}
//																										}
//																									}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1IHRT61GM11",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "true",
//																								"containerSlots": {
//																									"jaxId": "1IHRT61GM12",
//																									"attrs": {}
//																								}
//																							}
//																						},
//																						{
//																							"type": "hudobj",
//																							"def": "Gear/@StdUI/ui/BtnNaviItem.js",
//																							"jaxId": "1IHUFRISN0",
//																							"attrs": {
//																								"createArgs": {
//																									"jaxId": "1IHUFVVQO0",
//																									"attrs": {
//																										"code": "Notes",
//																										"text": {
//																											"type": "string",
//																											"valText": "Notes",
//																											"localize": {
//																												"EN": "Notes"
//																											},
//																											"localizable": true
//																										},
//																										"color": "[0,0,0,1.00]",
//																										"icon": "#appCfg.sharedAssets+\"/rename.svg\"",
//																										"items": "",
//																										"fontSize": "#txtSize.smallPlus",
//																										"hasClose": "false",
//																										"iconSize": "0",
//																										"mark": "true"
//																									}
//																								},
//																								"properties": {
//																									"jaxId": "1IHUFVVQO1",
//																									"attrs": {
//																										"type": "#null#>BtnNaviItem(\"Notes\",(\"Notes\"),[0,0,0,1],appCfg.sharedAssets+\"/rename.svg\",undefined,txtSize.smallPlus,false,0,true)",
//																										"id": "TabNotes",
//																										"position": "relative",
//																										"x": "0",
//																										"y": "0",
//																										"display": "Off",
//																										"face": "",
//																										"margin": "[0,3,0,3]"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1IHUFVVQO2",
//																									"attrs": {
//																										"1II6BHM6B0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1II6BIG4G35",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1II6BIG4G36",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1II6BHM6B0",
//																											"faceTagName": "tbxInference"
//																										},
//																										"1IIQDG1070": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IIQDHHU56",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IIQDHHU57",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IIQDG1070",
//																											"faceTagName": "tbxLogs"
//																										},
//																										"1IJID11VL0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IJID2C9V44",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IJID2C9V45",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IJID11VL0",
//																											"faceTagName": "tbxFiles"
//																										},
//																										"1IN8GGK0D0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IN8GJRCF4",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IN8GJRCF5",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IN8GGK0D0",
//																											"faceTagName": "tbxSandbox"
//																										},
//																										"1IHUJ6BT40": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IN8GJRCF6",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IN8GJRCF7",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IHUJ6BT40",
//																											"faceTagName": "tbxNotes"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1IHUFVVQO3",
//																									"attrs": {
//																										"OnClick": {
//																											"type": "fixedFunc",
//																											"jaxId": "1IHUJGC250",
//																											"attrs": {
//																												"callArgs": {
//																													"jaxId": "1IHUJGC251",
//																													"attrs": {
//																														"event": ""
//																													}
//																												},
//																												"seg": "1IHUJELCJ0"
//																											}
//																										}
//																									}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1IHUFVVQO4",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "true",
//																								"containerSlots": {
//																									"jaxId": "1IHUFVVQO5",
//																									"attrs": {}
//																								}
//																							}
//																						},
//																						{
//																							"type": "hudobj",
//																							"def": "Gear/@StdUI/ui/BtnNaviItem.js",
//																							"jaxId": "1IHRTJCOJ0",
//																							"attrs": {
//																								"createArgs": {
//																									"jaxId": "1IHRTKQPH0",
//																									"attrs": {
//																										"code": "Path",
//																										"text": "Files",
//																										"color": "[0,0,0,1.00]",
//																										"icon": "#appCfg.sharedAssets+\"/folder.svg\"",
//																										"items": "",
//																										"fontSize": "#txtSize.smallPlus",
//																										"hasClose": "false",
//																										"iconSize": "0",
//																										"mark": "true"
//																									}
//																								},
//																								"properties": {
//																									"jaxId": "1IHRTKQPH1",
//																									"attrs": {
//																										"type": "#null#>BtnNaviItem(\"Path\",\"Files\",[0,0,0,1],appCfg.sharedAssets+\"/folder.svg\",undefined,txtSize.smallPlus,false,0,true)",
//																										"id": "TabFiles",
//																										"position": "relative",
//																										"x": "0",
//																										"y": "0",
//																										"display": "Off",
//																										"face": "",
//																										"margin": "[0,3,0,3]",
//																										"enable": "true"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1IHRTKQPI0",
//																									"attrs": {
//																										"1II6BHM6B0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1II6BIG4G37",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1II6BIG4G38",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1II6BHM6B0",
//																											"faceTagName": "tbxInference"
//																										},
//																										"1IIQDG1070": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IIQDHHU58",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IIQDHHU59",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IIQDG1070",
//																											"faceTagName": "tbxLogs"
//																										},
//																										"1IJID11VL0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IJID2C9V46",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IJID2C9V47",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IJID11VL0",
//																											"faceTagName": "tbxFiles"
//																										},
//																										"1IN8GGK0D0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IN8GJRCF8",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IN8GJRCF9",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IN8GGK0D0",
//																											"faceTagName": "tbxSandbox"
//																										},
//																										"1IHUJ6BT40": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IN8GJRCF10",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IN8GJRCF11",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IHUJ6BT40",
//																											"faceTagName": "tbxNotes"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1IHRTKQPI1",
//																									"attrs": {
//																										"OnClick": {
//																											"type": "fixedFunc",
//																											"jaxId": "1IJJ35CQO0",
//																											"attrs": {
//																												"callArgs": {
//																													"jaxId": "1IJJ35CQO1",
//																													"attrs": {
//																														"event": ""
//																													}
//																												},
//																												"seg": "1IJJ337E60"
//																											}
//																										}
//																									}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1IHRTKQPI2",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "true",
//																								"containerSlots": {
//																									"jaxId": "1IHRTKQPI3",
//																									"attrs": {}
//																								}
//																							}
//																						},
//																						{
//																							"type": "hudobj",
//																							"def": "Gear/@StdUI/ui/BtnNaviItem.js",
//																							"jaxId": "1J12BTG220",
//																							"attrs": {
//																								"createArgs": {
//																									"jaxId": "1J12BTG221",
//																									"attrs": {
//																										"code": "Notes",
//																										"text": {
//																											"type": "string",
//																											"valText": "Process",
//																											"localize": {
//																												"EN": "Process",
//																												"CN": "流程"
//																											},
//																											"localizable": true
//																										},
//																										"color": "[0,0,0,1.00]",
//																										"icon": "#appCfg.sharedAssets+\"/hudstate.svg\"",
//																										"items": "",
//																										"fontSize": "#txtSize.smallPlus",
//																										"hasClose": "false",
//																										"iconSize": "0",
//																										"mark": "true"
//																									}
//																								},
//																								"properties": {
//																									"jaxId": "1J12BTG222",
//																									"attrs": {
//																										"type": "#null#>BtnNaviItem(\"Notes\",(($ln===\"CN\")?(\"流程\"):(\"Process\")),[0,0,0,1],appCfg.sharedAssets+\"/hudstate.svg\",undefined,txtSize.smallPlus,false,0,true)",
//																										"id": "TabProcess",
//																										"position": "relative",
//																										"x": "0",
//																										"y": "0",
//																										"display": "Off",
//																										"face": "",
//																										"margin": "[0,3,0,3]"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1J12BTG223",
//																									"attrs": {
//																										"1II6BHM6B0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1J12BTG230",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1J12BTG231",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1II6BHM6B0",
//																											"faceTagName": "tbxInference"
//																										},
//																										"1IIQDG1070": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1J12BTG232",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1J12BTG233",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IIQDG1070",
//																											"faceTagName": "tbxLogs"
//																										},
//																										"1IJID11VL0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1J12BTG234",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1J12BTG235",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IJID11VL0",
//																											"faceTagName": "tbxFiles"
//																										},
//																										"1IN8GGK0D0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1J12BTG236",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1J12BTG237",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IN8GGK0D0",
//																											"faceTagName": "tbxSandbox"
//																										},
//																										"1IHUJ6BT40": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1J12BTG238",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1J12BTG239",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IHUJ6BT40",
//																											"faceTagName": "tbxNotes"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1J12BTG2310",
//																									"attrs": {
//																										"OnClick": {
//																											"type": "fixedFunc",
//																											"jaxId": "1J12BTG2311",
//																											"attrs": {
//																												"callArgs": {
//																													"jaxId": "1J12BTG2312",
//																													"attrs": {
//																														"event": ""
//																													}
//																												},
//																												"seg": "1II6CP44V0"
//																											}
//																										}
//																									}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1J12BTG2313",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "true",
//																								"containerSlots": {
//																									"jaxId": "1J12BTG2314",
//																									"attrs": {}
//																								}
//																							}
//																						}
//																					]
//																				},
//																				"container": "true"
//																			}
//																		}
//																	}
//																}
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1IHRSON172",
//													"attrs": {
//														"1II6BHM6B0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IIQDHHU512",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IIQDHHU513",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II6BHM6B0",
//															"faceTagName": "tbxInference"
//														},
//														"1IIQDG1070": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IJID2C9V52",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IJID2C9V53",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IIQDG1070",
//															"faceTagName": "tbxLogs"
//														},
//														"1IN8GGK0D0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IN8GJRCF12",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IN8GJRCF13",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IN8GGK0D0",
//															"faceTagName": "tbxSandbox"
//														},
//														"1IHUJ6BT40": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IN8GJRCF14",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IN8GJRCF15",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IHUJ6BT40",
//															"faceTagName": "tbxNotes"
//														},
//														"1IJID11VL0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IN8GJRCF16",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IN8GJRCF17",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IJID11VL0",
//															"faceTagName": "tbxFiles"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IHRSON173",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IHRSON174",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1IHRTEID20",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IHRTFHDK0",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxToolView",
//														"position": "Absolute",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "100%-30",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": ""
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "Gear1II4RB79B0",
//															"jaxId": "1II6BGSOG0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1II6BHD360",
//																	"attrs": {}
//																},
//																"properties": {
//																	"jaxId": "1II6BHD361",
//																	"attrs": {
//																		"type": "#null#>TBXInference()",
//																		"id": "TbxInference",
//																		"position": "Absolute",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1II6BHD362",
//																	"attrs": {
//																		"1II6BHM6B0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1II6BIG4G49",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1II6BIG4G50",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1II6BHM6B0",
//																			"faceTagName": "tbxInference"
//																		},
//																		"1IHUJ66RM0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1II6BIG4G51",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1II6BIG4G52",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IHUJ66RM0",
//																			"faceTagName": "tbxBash"
//																		},
//																		"1IHUJ6BT40": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1II6BIG4G53",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1II6BIG4G54",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IHUJ6BT40",
//																			"faceTagName": "tbxNotes"
//																		},
//																		"1IIQDG1070": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IIQDHHU514",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IIQDHHU515",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IIQDG1070",
//																			"faceTagName": "tbxLogs"
//																		},
//																		"1IJID11VL0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJID2C9V54",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJID2C9V55",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IJID11VL0",
//																			"faceTagName": "tbxFiles"
//																		},
//																		"1IN8GGK0D0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IN8GJRCF18",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IN8GJRCF19",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IN8GGK0D0",
//																			"faceTagName": "tbxSandbox"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1II6BHD363",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1II6BHD364",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1II6BHD365",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear1IHRTSOVV0",
//															"jaxId": "1IHRVOUT90",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1IHRVP8RM0",
//																	"attrs": {}
//																},
//																"properties": {
//																	"jaxId": "1IHRVP8RM1",
//																	"attrs": {
//																		"type": "#null#>TBXBash()",
//																		"id": "TbxBash",
//																		"position": "Absolute",
//																		"x": "0",
//																		"y": "0",
//																		"display": "Off",
//																		"face": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IHRVP8RM2",
//																	"attrs": {
//																		"1IHUJ6BT40": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IHUJ6S5D16",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IHUJ6S5D17",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IHUJ6BT40",
//																			"faceTagName": "tbxNotes"
//																		},
//																		"1IHUJ66RM0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IHUJ6S5D18",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IHUJ6S5D19",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IHUJ66RM0",
//																			"faceTagName": "tbxBash"
//																		},
//																		"1II6BHM6B0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1II6BIG4G45",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1II6BIG4G46",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1II6BHM6B0",
//																			"faceTagName": "tbxInference"
//																		},
//																		"1IIQDG1070": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IIQDHHU516",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IIQDHHU517",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IIQDG1070",
//																			"faceTagName": "tbxLogs"
//																		},
//																		"1IJID11VL0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJID2C9V56",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJID2C9V57",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IJID11VL0",
//																			"faceTagName": "tbxFiles"
//																		},
//																		"1IN8GGK0D0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IN8GJRCF20",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IN8GJRCF21",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IN8GGK0D0",
//																			"faceTagName": "tbxSandbox"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1IHRVP8RM3",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1IHRVP8RM4",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1IHRVP8RM5",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear1IHUIJFMD0",
//															"jaxId": "1IHUJ32310",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1IHUJ5U0B0",
//																	"attrs": {}
//																},
//																"properties": {
//																	"jaxId": "1IHUJ5U0B1",
//																	"attrs": {
//																		"type": "#null#>TBXNotes()",
//																		"id": "TbxNotes",
//																		"position": "Absolute",
//																		"x": "0",
//																		"y": "0",
//																		"display": "Off",
//																		"face": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IHUJ5U0B2",
//																	"attrs": {
//																		"1IHUJ6BT40": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IHUJ6S5D20",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IHUJ6S5D21",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IHUJ6BT40",
//																			"faceTagName": "tbxNotes"
//																		},
//																		"1IHUJ66RM0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IHUJ6S5D22",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IHUJ6S5D23",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IHUJ66RM0",
//																			"faceTagName": "tbxBash"
//																		},
//																		"1II6BHM6B0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1II6BIG4G47",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1II6BIG4G48",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1II6BHM6B0",
//																			"faceTagName": "tbxInference"
//																		},
//																		"1IIQDG1070": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IIQDHHU518",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IIQDHHU519",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IIQDG1070",
//																			"faceTagName": "tbxLogs"
//																		},
//																		"1IJID11VL0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJID2C9V58",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJID2C9V59",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IJID11VL0",
//																			"faceTagName": "tbxFiles"
//																		},
//																		"1IN8GGK0D0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IN8GJRCF22",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IN8GJRCF23",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IN8GGK0D0",
//																			"faceTagName": "tbxSandbox"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1IHUJ5U0B3",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1IHUJ5U0B4",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1IHUJ5U0B5",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear1IIQA7CBF0",
//															"jaxId": "1IIQDF03V0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1IIQDFR570",
//																	"attrs": {}
//																},
//																"properties": {
//																	"jaxId": "1IIQDFR571",
//																	"attrs": {
//																		"type": "#null#>TBXLogs()",
//																		"id": "TbxLogs",
//																		"position": "Absolute",
//																		"x": "0",
//																		"y": "0",
//																		"display": "Off",
//																		"face": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IIQDFR572",
//																	"attrs": {
//																		"1IIQDG1070": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IIQDHHU520",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IIQDHHU521",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IIQDG1070",
//																			"faceTagName": "tbxLogs"
//																		},
//																		"1IHUJ66RM0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IIQDHHU522",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IIQDHHU523",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IHUJ66RM0",
//																			"faceTagName": "tbxBash"
//																		},
//																		"1IHUJ6BT40": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IIQDHHU524",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IIQDHHU525",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IHUJ6BT40",
//																			"faceTagName": "tbxNotes"
//																		},
//																		"1II6BHM6B0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IIQDHHU526",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IIQDHHU527",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1II6BHM6B0",
//																			"faceTagName": "tbxInference"
//																		},
//																		"1IJID11VL0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJID2C9V60",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJID2C9V61",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IJID11VL0",
//																			"faceTagName": "tbxFiles"
//																		},
//																		"1IN8GGK0D0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IN8GJRCF24",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IN8GJRCF25",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IN8GGK0D0",
//																			"faceTagName": "tbxSandbox"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1IIQDFR573",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1IIQDFR574",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1IIQDFR575",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear1IJI7V08Q0",
//															"jaxId": "1IJID01680",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1IJID2C9V62",
//																	"attrs": {}
//																},
//																"properties": {
//																	"jaxId": "1IJID2C9V63",
//																	"attrs": {
//																		"type": "#null#>TBXFiles()",
//																		"id": "TbxFiles",
//																		"position": "Absolute",
//																		"x": "0",
//																		"y": "0",
//																		"display": "Off",
//																		"face": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IJID2C9V64",
//																	"attrs": {
//																		"1IJID11VL0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJID2C9V65",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJID2C9V66",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IJID11VL0",
//																			"faceTagName": "tbxFiles"
//																		},
//																		"1IHUJ66RM0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJID2C9V67",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJID2C9V68",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IHUJ66RM0",
//																			"faceTagName": "tbxBash"
//																		},
//																		"1IHUJ6BT40": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJID2C9V69",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJID2C9V70",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IHUJ6BT40",
//																			"faceTagName": "tbxNotes"
//																		},
//																		"1II6BHM6B0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJID2C9V71",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJID2C9V72",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1II6BHM6B0",
//																			"faceTagName": "tbxInference"
//																		},
//																		"1IIQDG1070": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJID2C9V73",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJID2C9V74",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IIQDG1070",
//																			"faceTagName": "tbxLogs"
//																		},
//																		"1IN8GGK0D0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IN8GJRCF26",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IN8GJRCF27",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IN8GGK0D0",
//																			"faceTagName": "tbxSandbox"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1IJID2C9V75",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1IJID2C9V76",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1IJID2C9V77",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear1IN750NA00",
//															"jaxId": "1IN8DO8620",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1IN8DOUPJ0",
//																	"attrs": {}
//																},
//																"properties": {
//																	"jaxId": "1IN8DOUPJ1",
//																	"attrs": {
//																		"type": "#null#>TBXSandbox()",
//																		"id": "TbxSandbox",
//																		"position": "Absolute",
//																		"x": "0",
//																		"y": "0",
//																		"display": "Off",
//																		"face": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IN8DOUPJ2",
//																	"attrs": {
//																		"1IN8GGK0D0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IN8GJRCF28",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IN8GJRCF29",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IN8GGK0D0",
//																			"faceTagName": "tbxSandbox"
//																		},
//																		"1IHUJ66RM0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IN8GJRCF30",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IN8GJRCF31",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IHUJ66RM0",
//																			"faceTagName": "tbxBash"
//																		},
//																		"1IHUJ6BT40": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IN8GJRCF32",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IN8GJRCF33",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IHUJ6BT40",
//																			"faceTagName": "tbxNotes"
//																		},
//																		"1II6BHM6B0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IN8GJRCF34",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IN8GJRCF35",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1II6BHM6B0",
//																			"faceTagName": "tbxInference"
//																		},
//																		"1IIQDG1070": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IN8GJRCF36",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IN8GJRCF37",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IIQDG1070",
//																			"faceTagName": "tbxLogs"
//																		},
//																		"1IJID11VL0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IN8GJRCF38",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IN8GJRCF39",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IJID11VL0",
//																			"faceTagName": "tbxFiles"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1IN8DOUPJ3",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1IN8DOUPJ4",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1IN8DOUPJ5",
//																	"attrs": {}
//																}
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1IHRTFHDK1",
//													"attrs": {
//														"1II6BHM6B0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IIQDHHU530",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IIQDHHU531",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II6BHM6B0",
//															"faceTagName": "tbxInference"
//														},
//														"1IIQDG1070": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IJID2C9V82",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IJID2C9V83",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IIQDG1070",
//															"faceTagName": "tbxLogs"
//														},
//														"1IN8GGK0D0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IN8GJRCF40",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IN8GJRCF41",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IN8GGK0D0",
//															"faceTagName": "tbxSandbox"
//														},
//														"1IHUJ6BT40": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IN8GJRCF42",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IN8GJRCF43",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IHUJ6BT40",
//															"faceTagName": "tbxNotes"
//														},
//														"1IJID11VL0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IN8GJRCF44",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IN8GJRCF45",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IJID11VL0",
//															"faceTagName": "tbxFiles"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IHRTFHDK2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IHRTFHDK3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "true",
//												"exposeContainer": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1IHRSK5841",
//									"attrs": {
//										"1II6BHM6B0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IIQDHHU534",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IIQDHHU535",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1II6BHM6B0",
//											"faceTagName": "tbxInference"
//										},
//										"1IIQDG1070": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IJID2C9V88",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IJID2C9V89",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IIQDG1070",
//											"faceTagName": "tbxLogs"
//										},
//										"1ILNRS8JT0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1ILNRTQC738",
//											"attrs": {
//												"properties": {
//													"jaxId": "1ILNRTQC739",
//													"attrs": {
//														"y": {
//															"type": "length",
//															"valText": "0"
//														},
//														"h": {
//															"type": "length",
//															"valText": "100%"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1ILNRS8JT0",
//											"faceTagName": "embed"
//										},
//										"1IN8GGK0D0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IN8GJRCF46",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IN8GJRCF47",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IN8GGK0D0",
//											"faceTagName": "tbxSandbox"
//										},
//										"1IHUJ6BT40": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IN8GJRCF48",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IN8GJRCF49",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IHUJ6BT40",
//											"faceTagName": "tbxNotes"
//										},
//										"1IJID11VL0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IN8GJRCF50",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IN8GJRCF51",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IJID11VL0",
//											"faceTagName": "tbxFiles"
//										},
//										"1J3BS13HE0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1J3BS3GP138",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J3BS3GP139",
//													"attrs": {
//														"w": "100%-600",
//														"x": "600",
//														"minW": "250"
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1J3BS13HE0",
//											"faceTagName": "wideChat"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1IHRSK5842",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IHRSK5843",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1GGJKM84D9",
//					"attrs": {
//						"1II6BHM6B0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1IIQDHHU538",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IIQDHHU539",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1II6BHM6B0",
//							"faceTagName": "tbxInference"
//						},
//						"1IIQDG1070": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1IJID2C9V94",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IJID2C9V95",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1IIQDG1070",
//							"faceTagName": "tbxLogs"
//						},
//						"1IN8GGK0D0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1IN8GJRCF52",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IN8GJRCF53",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1IN8GGK0D0",
//							"faceTagName": "tbxSandbox"
//						},
//						"1IHUJ6BT40": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1IN8GJRCF54",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IN8GJRCF55",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1IHUJ6BT40",
//							"faceTagName": "tbxNotes"
//						},
//						"1IJID11VL0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1IN8GJRCF56",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IN8GJRCF57",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1IJID11VL0",
//							"faceTagName": "tbxFiles"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1GGJKM84D10",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1GGJKM84D11",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1GGJKM84D12",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false",
//				"innerLayout": {
//					"valText": "false"
//				},
//				"marginL": {
//					"valText": "false"
//				},
//				"marginR": {
//					"valText": "false"
//				},
//				"marginT": {
//					"valText": "false"
//				},
//				"marginB": {
//					"valText": "false"
//				},
//				"paddingL": {
//					"valText": "false"
//				},
//				"paddingR": {
//					"valText": "false"
//				},
//				"paddingT": {
//					"valText": "false"
//				},
//				"paddingB": {
//					"valText": "false"
//				},
//				"attach": {
//					"valText": "false"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}