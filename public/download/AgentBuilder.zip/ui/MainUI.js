//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BoxTokenGas} from "/@aichat/ui/BoxTokenGas.js";
import {UIChat} from "/@aichat/ui/UIChat.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
import {NaviToolBar} from "/@StdUI/ui/NaviToolBar.js";
import {BtnNaviItem} from "/@StdUI/ui/BtnNaviItem.js";
import {TBXInference} from "./TBXInference.js";
import {TBXBash} from "./TBXBash.js";
import {TBXNotes} from "./TBXNotes.js";
import {TBXLogs} from "./TBXLogs.js";
import {TBXFiles} from "./TBXFiles.js";
/*#{1GGJKM84D0StartDoc*/
import pathLib from "/@path";

function getElementScreenPosition(el) {
	if (!el) return null;

	let rect = el.getBoundingClientRect(); // 获取元素在当前视口中的坐标
	let win = el.ownerDocument.defaultView; // 获取元素所在的 window
	let x = rect.left, y = rect.top;

	// 如果元素在 iframe 内，累加所有父级 iframe 的偏移
	while (win !== window.top) {
		let iframe = win.frameElement; // 获取当前 iframe 元素
		if (!iframe) break;

		let iframeRect = iframe.getBoundingClientRect();
		x += iframeRect.left;
		y += iframeRect.top;

		win = win.parent; // 继续向上遍历
	}

	// 添加当前浏览器窗口在屏幕上的位置
	let screenX = window.screenX;
	let screenY = window.screenY;
	let dpr = 1;//window.devicePixelRatio;
	let browserFrameHeight = 35;//window.outerHeight - window.innerHeight
	return {
		x: (screenX + x) * dpr,
		y: (screenY + y+browserFrameHeight) * dpr,
		width: rect.width * dpr,
		height: rect.height * dpr
	};
}
/*}#1GGJKM84D0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let MainUI=function(app,appFrame){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let boxAIChat,boxTools,tabNotes,tabBash,tabFiles,boxToolView,tbxInference,tbxBash,tbxNotes,tbxFiles;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let title=(($ln==="CN")?("项目向导"):("Project Wizard"));
	
	/*#{1GGJKM84D1LocalVals*/
	app.aiNotifyApp=app;//Make sure all AI-Emit goes to current app, not the IDE's app.
	let session=null;
	app.appFrame=appFrame;
	const rootApp=appFrame?appFrame.app:app;
	let debugSockets=[];
	let slowMo=false;
	let stepRun=false;
	let execPaused=false;
	let localExecCallback=null;
	let callback=null;
	let callerror=null;
	/*}#1GGJKM84D1LocalVals*/
	
	/*#{1GGJKM84D1PreState*/
	title=appFrame?(appFrame.appParams.title||title):title;
	/*}#1GGJKM84D1PreState*/
	state={
		"counter":0,
		/*#{1GGJKM84D6ExState*/
		/*}#1GGJKM84D6ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1GGJKM84D1PostState*/
	/*}#1GGJKM84D1PostState*/
	cssVO={
		"hash":"1GGJKM84D1",nameHost:true,
		"type":"view","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
		children:[
			{
				"hash":"1HHAMBFU40",
				"type":BoxTokenGas(30,cfgColor["secondary"],cfgColor["fontSecondary"],24,16,false,false,appCfg.sharedAssets+"/ablogo.svg",30),"position":"relative",
				"x":0,"y":0,"caption":title,
			},
			{
				"hash":"1HDBT1RJN0",
				"type":"hud","id":"BoxChat","x":0,"y":30,"w":480,"h":">calc(100% - 30px)","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				children:[
					{
						"hash":"1HDBT34IS0",
						"type":UIChat({"bubble":false,"ai":{"blkColor":[0,0,0,0],"bgColor":cfgColor["success"],"icon":appCfg.sharedAssets+"/faces.svg","pic":"","textColor":cfgColor["fontBody"],"iconColor":cfgColor["fontSuccess"],"side":"left"},"user":{"blkColor":[0,0,0,0],"bgColor":cfgColor.primary,"icon":appCfg.sharedAssets+"/user.svg","pic":"","textColor":cfgColor["fontBody"],"iconColor":cfgColor["fontPrimary"],"side":"right"},"wait":{"blkColor":[0,0,0,0],"bgColor":cfgColor["secondary"],"icon":appCfg.sharedAssets+"/faces.svg","pic":"","textColor":cfgColor["fontBody"],"iconColor":cfgColor["fontSecondary"],"side":"left"},"event":{"blkColor":[0,0,0,0],"bgColor":cfgColor["warning"],"icon":appCfg.sharedAssets+"/event.svg","pic":"","textColor":cfgColor["fontBody"],"iconColor":cfgColor["fontWarning"],"side":"left"},"error":{"blkColor":[0,0,0,0],"bgColor":cfgColor["error"],"icon":appCfg.sharedAssets+"/fat_right.svg","pic":"","textColor":[155,0,0,1],"iconColor":cfgColor["fontError"],"side":"left"},"ask":{"blkColor":[0,0,0,0],"bgColor":cfgColor["success"],"icon":appCfg.sharedAssets+"/help.svg","pic":"","textColor":cfgColor["fontBody"],"iconColor":cfgColor["fontSuccess"],"side":"left"},"allowFile":false}),
						"id":"BoxAIChat","x":0,"y":30,"h":">calc(100% - 30px)",
					},
					{
						"hash":"1IHRRMK5D0",
						"type":"box","id":"BoxChatHeader","x":0,"y":0,"w":"100%","h":30,"padding":[0,13,0,5],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["body"],
						"border":[0,0,1,0],"borderColor":cfgColor["fontBodySub"],"contentLayout":"flex-x","itemsAlign":1,
						children:[
							{
								"hash":"1IHRRSCOS0",
								"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
								"text":"Agent chats","fontWeight":"normal","fontStyle":"normal","textDecoration":"","flex":true,
							},
							{
								"hash":"1IHRRO8470",
								"type":BtnIcon("front",26,0,appCfg.sharedAssets+"/trash.svg",null),"id":"BtnClearChat","position":"relative","x":0,"y":0,"enable":false,
								"tip":(($ln==="CN")?("清除"):("Clear")),
							}
						],
					},
					{
						"hash":"1IHROFSPO0",
						"type":"box","x":">calc(100% - 1px)","y":0,"w":1,"h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["fontBodySub"],
					}
				],
			},
			{
				"hash":"1IHRSFUAP0",
				"type":"hud","id":"BoxTools","x":480,"y":30,"w":">calc(100% - 480px)","h":">calc(100% - 30px)","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				children:[
					{
						"hash":"1IHRSON170",
						"type":"box","id":"BoxToolFooter","x":0,"y":">calc(100% - 30px)","w":"100%","h":30,"padding":[0,2,0,2],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						"background":cfgColor["body"],"border":[1,0,0,0],"borderColor":cfgColor["fontBodySub"],
						children:[
							{
								"hash":"1IHRT3E2S0",
								"type":NaviToolBar(true),"position":"relative","x":0,"y":0,
								subContainers:{
									"1HL4P0I9P0":[
										{
											"hash":"1II4R1QQ40",
											"type":BtnNaviItem("Notes",(($ln==="CN")?("推理视图"):("Inference")),[0,0,0,1],appCfg.sharedAssets+"/memory.svg",undefined,txtSize.smallPlus,false,0,true),
											"id":"TabNotes","position":"relative","x":0,"y":0,"margin":[0,3,0,3],
											"OnClick":function(event){
												self.showTbxInference(this,event);
											},
										},
										{
											"hash":"1ILSAPHN50",
											"type":BtnNaviItem("Path",(($ln==="CN")?("画布"):("Canvas")),[0,0,0,1],appCfg.sharedAssets+"/canvas.svg",undefined,txtSize.smallPlus,false,0,true),
											"id":"TabCanvas","position":"relative","x":0,"y":0,"margin":[0,3,0,3],"enable":false,
											"OnClick":function(event){
												self.showTbxLogs(this,event);
											},
										},
										{
											"hash":"1IIQD8VE20",
											"type":BtnNaviItem("Path","Logs",[0,0,0,1],appCfg.sharedAssets+"/read.svg",undefined,txtSize.smallPlus,false,0,true),"id":"TabLogs","position":"relative",
											"x":0,"y":0,"margin":[0,3,0,3],
											"OnClick":function(event){
												self.showTbxLogs(this,event);
											},
										},
										{
											"hash":"1IHRT56I80",
											"type":BtnNaviItem("Home","Terminal",[0,0,0,1],appCfg.sharedAssets+"/terminal.svg",undefined,txtSize.smallPlus,false,0,true),"id":"TabBash",
											"position":"relative","x":0,"y":0,"display":0,"margin":[0,3,0,3],
											"OnClick":function(event){
												self.showTbxBash(this,event);
											},
										},
										{
											"hash":"1IHUFRISN0",
											"type":BtnNaviItem("Notes",("Notes"),[0,0,0,1],appCfg.sharedAssets+"/rename.svg",undefined,txtSize.smallPlus,false,0,true),"id":"TabNotes",
											"position":"relative","x":0,"y":0,"display":0,"margin":[0,3,0,3],
											"OnClick":function(event){
												self.showTbxNotes(this,event);
											},
										},
										{
											"hash":"1IHRTJCOJ0",
											"type":BtnNaviItem("Path","Files",[0,0,0,1],appCfg.sharedAssets+"/folder.svg",undefined,txtSize.smallPlus,false,0,true),"id":"TabFiles","position":"relative",
											"x":0,"y":0,"display":0,"margin":[0,3,0,3],
											"OnClick":function(event){
												self.showTbxFiles(this,event);
											},
										}
									]
								},
								/*#{1IHRT3E2S0Codes*/
								/*}#1IHRT3E2S0Codes*/
							}
						],
					},
					{
						"hash":"1IHRTEID20",
						"type":"hud","id":"BoxToolView","x":0,"y":0,"w":"100%","h":">calc(100% - 30px)","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						children:[
							{
								"hash":"1II6BGSOG0",
								"type":TBXInference(),"id":"TbxInference","x":0,"y":0,
							},
							{
								"hash":"1IHRVOUT90",
								"type":TBXBash(),"id":"TbxBash","x":0,"y":0,"display":0,
							},
							{
								"hash":"1IHUJ32310",
								"type":TBXNotes(),"id":"TbxNotes","x":0,"y":0,"display":0,
							},
							{
								"hash":"1IIQDF03V0",
								"type":TBXLogs(),"id":"TbxLogs","x":0,"y":0,"display":0,
							},
							{
								"hash":"1IJID01680",
								"type":TBXFiles(),"id":"TbxFiles","x":0,"y":0,"display":0,
							}
						],
					}
				],
			}
		],
		/*#{1GGJKM84D1ExtraCSS*/
		/*}#1GGJKM84D1ExtraCSS*/
		faces:{
			"tbxBash":{
				/*TbxInference*/"#1II6BGSOG0":{
					"display":0
				},
				/*TbxBash*/"#1IHRVOUT90":{
					"display":1
				},
				/*TbxNotes*/"#1IHUJ32310":{
					"display":0
				},
				/*TbxLogs*/"#1IIQDF03V0":{
					"display":0
				},
				/*TbxFiles*/"#1IJID01680":{
					"display":0
				}
			},"tbxNotes":{
				/*TbxInference*/"#1II6BGSOG0":{
					"display":0
				},
				/*TbxBash*/"#1IHRVOUT90":{
					"display":0
				},
				/*TbxNotes*/"#1IHUJ32310":{
					"display":1
				},
				/*TbxLogs*/"#1IIQDF03V0":{
					"display":0
				},
				/*TbxFiles*/"#1IJID01680":{
					"display":0
				}
			},"tbxInference":{
				/*TbxInference*/"#1II6BGSOG0":{
					"display":1
				},
				/*TbxBash*/"#1IHRVOUT90":{
					"display":0
				},
				/*TbxNotes*/"#1IHUJ32310":{
					"display":0
				},
				/*TbxLogs*/"#1IIQDF03V0":{
					"display":0
				},
				/*TbxFiles*/"#1IJID01680":{
					"display":0
				}
			},"tbxLogs":{
				/*TbxInference*/"#1II6BGSOG0":{
					"display":0
				},
				/*TbxBash*/"#1IHRVOUT90":{
					"display":0
				},
				/*TbxNotes*/"#1IHUJ32310":{
					"display":0
				},
				/*TbxLogs*/"#1IIQDF03V0":{
					"display":1
				},
				/*TbxFiles*/"#1IJID01680":{
					"display":0
				}
			},"tbxFiles":{
				/*TbxInference*/"#1II6BGSOG0":{
					"display":0
				},
				/*TbxBash*/"#1IHRVOUT90":{
					"display":0
				},
				/*TbxNotes*/"#1IHUJ32310":{
					"display":0
				},
				/*TbxLogs*/"#1IIQDF03V0":{
					"display":0
				},
				/*TbxFiles*/"#1IJID01680":{
					"display":1
				}
			},"embed":{
				"#1HHAMBFU40":{
					"y":"100%","anchorY":2,"display":0
				},
				/*BoxChat*/"#1HDBT1RJN0":{
					"y":0,"h":"100%"
				},
				/*BoxAIChat*/"#1HDBT34IS0":{
					"y":0,"h":"100%"
				},
				/*BoxChatHeader*/"#1IHRRMK5D0":{
					"display":0
				},
				/*BoxTools*/"#1IHRSFUAP0":{
					"y":0,"h":"100%"
				}
			}
		},
		OnCreate:function(){
			self=this;
			boxAIChat=self.BoxAIChat;boxTools=self.BoxTools;tabNotes=self.TabNotes;tabBash=self.TabBash;tabNotes=self.TabNotes;tabFiles=self.TabFiles;boxToolView=self.BoxToolView;tbxInference=self.TbxInference;tbxBash=self.TbxBash;tbxNotes=self.TbxNotes;tbxFiles=self.TbxFiles;
			/*#{1GGJKM84D1Create*/
			let entry,params,args;
			params=app.appParams;
			entry=params.agentURL||params.file||"ai/UxEntry.js";
			args=params.arguments||params.argument||"";
			callback=params.callback||null;
			callerror=params.callerror||null;
			app.mainUI=self;
			self.openChatFile(entry,args);
			if(appFrame && appFrame.isEmbeded){
				self.showFace("embed");
			}
			/*}#1GGJKM84D1Create*/
		},
		/*#{1GGJKM84D1EndCSS*/
		/*}#1GGJKM84D1EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.connectDebug=async function(address){
		/*#{1IIPJ51GL0Start*/
		let addr,connecting,pms,connected,ws;
		let callback,callerror;
		addr=address;
		if(!addr.startsWith("ws://")){
			addr="ws://"+addr;
		}
		connecting=true;
		ws=new WebSocket(addr);
		pms=new Promise((resolve,reject)=>{
			callback=resolve;
			callerror=reject;
		});
		ws.addEventListener('open',()=>{
			connected=true;
			connecting=false;
			debugSockets.push(ws);
			console.log("Agent Debug WS connected.");
			ws.send(JSON.stringify({cmd:"SlowMo",enable:slowMo}));
			if(stepRun){
				ws.send(JSON.stringify({cmd:"StepRunOn"}));
			}
			self.showFace("online");
			if(callback){
				callback();
				callback=null;
				callerror=null;
			}
		});
		ws.addEventListener('message', (msg) => {
			let log,msgCode,css,icon;
			log=JSON.parse(msg.data);
			console.log("Log from debug server:");
			console.log(log)
			icon=null;
			switch(log.type){
				case "StepRunOn":
					app.emit("AIStepRunOn");
					break;
				case "StepRunOff":
					if(execPaused){
						execPaused=false;
						ws.stepPaused=false;
						app.emit("AIExecResume");
						app.emit("AIStepRunOff");
					}
					break;
				case "StepPaused":
					execPaused=true;
					ws.stepPaused=true;
					app.emit("AIExecPaused");
					break;
				case "StepRun":
					execPaused=false;
					ws.stepPaused=false;
					app.emit("AIExecResume");
					break;
				case "StartAgent":
				case "EndAgent":
				case "StartSeg":
				case "EndSeg":
				case "DebugLog":
				case "CatchError":
				case "LlmCall":
				case "LlmResult":{
					if(app.uiInference){
						app.uiInference.handleLog(log);
					}
					if(app.uiLogs){
						app.uiLogs.addLog(log);
					}
					break;
				}
			}
		});
		ws.addEventListener('close', (msg) => {
			if(connected){
				connected=false;
				self.showFace("offline");
				this.isConnected=false;
				let idx=debugSockets.indexOf(ws);
				if(idx>=0){
					debugSockets.splice(idx,1);
				}
				console.log("Agent Debug WS closed.");
			}else{
				self.showFace("offline");
			}
			if(callerror){
				callback=null;
				callerror();
				callerror=null;
			}
			ws=null;
		});
		ws.addEventListener('error', (msg) => {
			if(connecting){
				self.showFace("offline");
				if(callerror){
					callback=null;
					callerror();
					callerror=null;
				}
			}else if(connected){
				console.log("Agent Debug WS error.");
				console.error(msg);
			}
		});
		let result=await pms;
		console.log(result);
		return true;
		/*}#1IIPJ51GL0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.showTbxBash=async function(){
		/*#{1IHUJE1HL0Start*/
		tabBash.markNum=0;
		/*}#1IHUJE1HL0Start*/
		self.showFace("tbxBash");
	};
	//------------------------------------------------------------------------
	cssVO.showTbxNotes=async function(){
		/*#{1IHUJELCJ0Start*/
		tabNotes.markNum=0;
		/*}#1IHUJELCJ0Start*/
		self.showFace("tbxNotes");
	};
	//------------------------------------------------------------------------
	cssVO.showTbxInference=async function(){
		/*#{1II6CP44V0Start*/
		/*}#1II6CP44V0Start*/
		self.showFace("tbxInference");
		
		//Render
		/*#{1II6Q1MCO0*/
		tbxInference.showCanvas();
		/*}#1II6Q1MCO0*/
	};
	//------------------------------------------------------------------------
	cssVO.showTbxLogs=async function(){
		/*#{1IIQDJIM60Start*/
		/*}#1IIQDJIM60Start*/
		self.showFace("tbxLogs");
	};
	//------------------------------------------------------------------------
	cssVO.showTbxFiles=async function(){
		/*#{1IJJ337E60Start*/
		tabFiles.markNum=0;
		/*}#1IJJ337E60Start*/
		self.showFace("tbxFiles");
	};
	//------------------------------------------------------------------------
	cssVO.notifyBash=async function(){
		/*#{1IJI6LE7N0Start*/
		tabBash.incMark();
		tabBash.display=true;
		/*}#1IJI6LE7N0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.notifyFile=async function(){
		/*#{1IJI6LMIG0Start*/
		tabFiles.incMark();
		tabFiles.display=true;
		/*}#1IJI6LMIG0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.notifyNote=async function(){
		/*#{1IJI6M3L80Start*/
		tabNotes.incMark();
		tabNotes.display=true;
		/*}#1IJI6M3L80Start*/
	};
	/*#{1GGJKM84D1PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.openChatFile=async function(path,args){
		let ext;
		let setup=async (sn)=>{
			//Setup before session really start:
			session=sn;
			//Connect debug client callback:
			session.WSCall_ConnectAgentDebug=async function(message){
				if(app.uiInference){
					let address=`${window.location.hostname}:${message.port}`;
					let result=await self.connectDebug(address);
					//let result=await app.uiInference.connect(address,message.entryURL,message.entryAgent);
					console.log("MainUI.connectDebug result: "+result);
				}
				return false;
			}
	
			//Connect agent terminal:
			session.WSCall_CreateXTerm=async function(message){
				let sessionId=message.session||message.sessionId;
				if(tbxBash){
					tbxBash.connectBash(sessionId);
				}
			};
	
			//Connect agent terminal-env:
			session.WSCall_CreateCokeEnv=async function(){
				if(tbxBash){
					let cokeEnv=await tbxBash.createCokeEnv();
					let tty=cokeEnv.tty;
					tty.session=session;
					cokeEnv.session=session;
					return cokeEnv;
				}
				return null;
			};
			
			//Connect agent terminal-tty:
			session.WSCall_CreateTTY=async function(){
				if(tbxBash){
					let tty=await tbxBash.createTTY();
					tty.session=session;
					return tty;
				}
				return null;
			};
			
			//Add note:
			session.WSCall_AddNote=function(message){
				if(tbxNotes){
					tbxNotes.addNote(message.note);
				}
			};
	
			//Report project env/project info:
			session.WSCall_RegEnvProjectInfo=function(message){
				if(tbxNotes){
					tbxNotes.regEnv(message.env,message.project);
				}
			};
			
			//Add a file:
			session.WSCall_NewHubFile=function(fileName){
				if(tbxFiles){
					tbxFiles.addFile(fileName);
				}
			};
			
			//GetClient rect:
			session.WSCall_GetClientRect=function(){
				return getElementScreenPosition(self.webObj);
			};
	
			//GetClient rect:
			session.WSCall_GetToolDockRect=function(){
				return getElementScreenPosition(boxTools.webObj);
			};
			
			if(slowMo){
				session.setSlowMo(true);
			}
			if(stepRun){
				session.setStepRun(true,self.showLocalPaused);
			}
		};
		//Convert file system path to URL:
		self.showFace("init");
		ext=pathLib.extname(path);
		if(ext===".py" || app.appParams.isServer){
			let nodeName=VFACT.appParams.node;
			let localPath,result;
			if(!nodeName){
				nodeName=window.prompt("Input debug agent node name:",VFACT.appParams.prjName||"");
			}
			localPath="/@aichat/ai/RemoteChat.js";
			try{
				result=await boxAIChat.initChat({
					url:localPath,argument:{nodeName:nodeName,callAgent:pathLib.basename(path),callArg:args,checkUpdate:true},
					setup:setup				
				});
				if(callback){
					callback(result);
				}
			}catch(error){
				//Show error:
				boxAIChat.BoxChats.appendChatBlock({type:"error",text:""+error});
				console.error(error);				
				if(callerror){
					callerror(error);
				}
			}
		}else if(ext===".js"){
			let result;
			//Fix URL if needed:
			if(path[0]==="/" && path[1]!=="/" && path[1]!=="~" && path[1]!=="@"){
				path="/~"+path;
			}
			if(path[0]!=="/" && (!path.startsWith("http://")) &&(!path.startsWith("https://"))){
				path=app.path2AppURL(path);
			}
	
			//Init/setup the agent and start chat:
			try{
				result=await boxAIChat.initChat({url:path,arguments:args,setup:setup});
				if(callback){
					callback(result);
				}
			}catch(error){
				//Show error:
				boxAIChat.BoxChats.appendChatBlock({type:"error",text:""+error});
				console.error(error);				
				if(callerror){
					callerror(error);
				}
			}
		}else if(ext===".aichat"){
			//No longer support this.
			//Show error:
			let error;
			error=Error("Sorry, '.aichat' files are no longer supported for debug.");
			boxAIChat.BoxChats.appendChatBlock({type:"error",text:""+error});
			console.error(error);				
			if(callerror){
				callerror(error);
			}
		}else{
			let error;
			error=Error(`Unsupport agent file ext type: ${ext} for url: ${path}.`);
			boxAIChat.BoxChats.appendChatBlock({type:"error",text:""+error});
			console.error(error);				
			if(callerror){
				callerror(error);
			}
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.showLocalPaused=async function(input,phase,cmd){
		let pms;
		pms=new Promise((resolve,reject)=>{
			localExecCallback=resolve;
		});
		execPaused=true;
		app.emit("AIExecPaused");
		await pms;
		return input;
	};
	
	//------------------------------------------------------------------------
	app.setSlowMo=async function(enable){
		let ws;
		if(session){
			session.setSlowMo(enable);
		}
		for(ws of debugSockets){
			ws.send(JSON.stringify({cmd:"SlowMo",enable:enable}));
		}
		slowMo=enable;
	};
	
	//------------------------------------------------------------------------
	app.setStepRun=async function(enable){
		let ws;
		if(session){
			session.setStepRun(enable,self.showLocalPaused);
		}
		for(ws of debugSockets){
			if(enable){
				ws.send(JSON.stringify({cmd:"StepRunOn"}));
			}else{
				ws.send(JSON.stringify({cmd:"StepRunOff"}));
			}
		}
		stepRun=!!enable;
	};
	
	//------------------------------------------------------------------------
	app.resumeAIRun=async function(enable){
		let ws,callback;
		callback=localExecCallback;
		if(callback){
			localExecCallback=false;
			callback();
		}
		for(ws of debugSockets){
			if(ws.stepPaused){
				ws.send(JSON.stringify({cmd:"RunStep"}));
			}
		}
	};
	/*}#1GGJKM84D1PostCSSVO*/
	cssVO.constructor=MainUI;
	return cssVO;
};
/*#{1GGJKM84D1ExCodes*/
/*}#1GGJKM84D1ExCodes*/

//----------------------------------------------------------------------------
MainUI.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1GGJKM84D1PreAISpot*/
	/*}#1GGJKM84D1PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1GGJKM84D1PostAISpot*/
	/*}#1GGJKM84D1PostAISpot*/
	return exposeVO;
};

/*#{1GGJKM84D0EndDoc*/
/*}#1GGJKM84D0EndDoc*/

export default MainUI;
export{MainUI};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "UIView",
//	"jaxId": "1GGJKM84D0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1GGJKM84D2",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "900",
//				"screenH": "600",
//				"bgColor": "#cfgColor.body",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1GGJKM84D3",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1H90TKKV70",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1GGJKM84D4",
//			"attrs": {
//				"app": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"appFrame": {
//					"type": "auto",
//					"valText": "null"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1GGJKM84D5",
//			"attrs": {
//				"title": {
//					"type": "string",
//					"valText": "Project Wizard",
//					"localize": {
//						"EN": "Project Wizard",
//						"CN": "项目向导"
//					},
//					"localizable": true
//				}
//			}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1GGJKM84D6",
//			"attrs": {
//				"counter": {
//					"type": "int",
//					"valText": "0"
//				}
//			}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IIPJ51GL0",
//					"attrs": {
//						"id": "connectDebug",
//						"label": "New AI Seg",
//						"x": "90",
//						"y": "55",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IIPJ5JKT0",
//							"attrs": {
//								"address": {
//									"type": "string",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IIPJ5JKT1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IIPJ5JKT2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IHUJE1HL0",
//					"attrs": {
//						"id": "showTbxBash",
//						"label": "New AI Seg",
//						"x": "90",
//						"y": "125",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IHUJFPU80",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IHUJFPU81",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": [
//								{
//									"type": "flowseg",
//									"def": "SetFace",
//									"jaxId": "1IHUJFPU82",
//									"attrs": {
//										"id": "SetFace",
//										"label": "New AI Seg",
//										"x": "345",
//										"y": "125",
//										"desc": "",
//										"codes": "false",
//										"component": "self",
//										"face": "tbxBash",
//										"outlet": {
//											"jaxId": "1IHUJFPU83",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											}
//										}
//									},
//									"icon": "faces.svg"
//								}
//							]
//						},
//						"outlet": {
//							"jaxId": "1IHUJFPU84",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1IHUJFPU82"
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IHUJELCJ0",
//					"attrs": {
//						"id": "showTbxNotes",
//						"label": "New AI Seg",
//						"x": "90",
//						"y": "205",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IHUJFPU85",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IHUJFPU86",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": [
//								{
//									"type": "flowseg",
//									"def": "SetFace",
//									"jaxId": "1IHUJFPU87",
//									"attrs": {
//										"id": "SetFace",
//										"label": "New AI Seg",
//										"x": "345",
//										"y": "205",
//										"desc": "",
//										"codes": "false",
//										"component": "self",
//										"face": "tbxNotes",
//										"outlet": {
//											"jaxId": "1IHUJFPU88",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											}
//										}
//									},
//									"icon": "faces.svg"
//								}
//							]
//						},
//						"outlet": {
//							"jaxId": "1IHUJFPU89",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1IHUJFPU87"
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1II6CP44V0",
//					"attrs": {
//						"id": "showTbxInference",
//						"label": "New AI Seg",
//						"x": "90",
//						"y": "290",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1II6CPNOK0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1II6CPNOK1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": [
//								{
//									"type": "flowseg",
//									"def": "SetFace",
//									"jaxId": "1II6CPNOK2",
//									"attrs": {
//										"id": "SetFace",
//										"label": "New AI Seg",
//										"x": "345",
//										"y": "290",
//										"desc": "",
//										"codes": "false",
//										"component": "self",
//										"face": "tbxInference",
//										"outlet": {
//											"jaxId": "1II6CPNOK3",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											},
//											"linkedSeg": "1II6Q1MCO0"
//										}
//									},
//									"icon": "faces.svg"
//								},
//								{
//									"type": "flowseg",
//									"def": "Code",
//									"jaxId": "1II6Q1MCO0",
//									"attrs": {
//										"id": "Render",
//										"label": "New AI Seg",
//										"x": "540",
//										"y": "290",
//										"desc": "",
//										"codes": "false",
//										"outlet": {
//											"jaxId": "1II6Q1MCS0",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											}
//										}
//									},
//									"icon": "tab_css.svg"
//								}
//							]
//						},
//						"outlet": {
//							"jaxId": "1II6CPNOK4",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1II6CPNOK2"
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IIQDJIM60",
//					"attrs": {
//						"id": "showTbxLogs",
//						"label": "New AI Seg",
//						"x": "90",
//						"y": "390",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IIQDK3MG0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IIQDK3MG1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": [
//								{
//									"type": "flowseg",
//									"def": "SetFace",
//									"jaxId": "1IIQDK3MG2",
//									"attrs": {
//										"id": "SetFace",
//										"label": "New AI Seg",
//										"x": "340",
//										"y": "390",
//										"desc": "",
//										"codes": "false",
//										"component": "self",
//										"face": "tbxLogs",
//										"outlet": {
//											"jaxId": "1IIQDK3MG3",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											}
//										}
//									},
//									"icon": "faces.svg"
//								}
//							]
//						},
//						"outlet": {
//							"jaxId": "1IIQDK3MG4",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1IIQDK3MG2"
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IJJ337E60",
//					"attrs": {
//						"id": "showTbxFiles",
//						"label": "New AI Seg",
//						"x": "90",
//						"y": "480",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IJJ33VUA0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IJJ33VUA1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": [
//								{
//									"type": "flowseg",
//									"def": "SetFace",
//									"jaxId": "1IJJ33VUA2",
//									"attrs": {
//										"id": "SetFace",
//										"label": "New AI Seg",
//										"x": "345",
//										"y": "480",
//										"desc": "",
//										"codes": "false",
//										"component": "self",
//										"face": "tbxFiles",
//										"outlet": {
//											"jaxId": "1IJJ33VUA3",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											}
//										}
//									},
//									"icon": "faces.svg"
//								}
//							]
//						},
//						"outlet": {
//							"jaxId": "1IJJ33VUA4",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1IJJ33VUA2"
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IJI6LE7N0",
//					"attrs": {
//						"id": "notifyBash",
//						"label": "New AI Seg",
//						"x": "90",
//						"y": "560",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IJI6N1MO0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IJI6N1MO1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IJI6N1MO2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IJI6LMIG0",
//					"attrs": {
//						"id": "notifyFile",
//						"label": "New AI Seg",
//						"x": "310",
//						"y": "560",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IJI6N1MO3",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IJI6N1MO4",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IJI6N1MO5",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IJI6M3L80",
//					"attrs": {
//						"id": "notifyNote",
//						"label": "New AI Seg",
//						"x": "510",
//						"y": "560",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IJI6N1MO6",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IJI6N1MO7",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IJI6N1MO8",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				}
//			]
//		},
//		"exportTarget": "VFACT document",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1GGJKM84D7",
//			"attrs": {
//				"tbxBash": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IHUJ66RM0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IHUJ6S5C0",
//							"attrs": {}
//						}
//					}
//				},
//				"tbxNotes": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IHUJ6BT40",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IHUJ6S5C1",
//							"attrs": {}
//						}
//					}
//				},
//				"tbxInference": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1II6BHM6B0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1II6BIG4G0",
//							"attrs": {}
//						}
//					}
//				},
//				"tbxLogs": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IIQDG1070",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IIQDHHU40",
//							"attrs": {}
//						}
//					}
//				},
//				"tbxFiles": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IJID11VL0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IJID2C9U0",
//							"attrs": {}
//						}
//					}
//				},
//				"embed": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1ILNRS8JT0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1ILNRTQC60",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1HDBOJDB10",
//			"attrs": {}
//		},
//		"exposeToAI": "true",
//		"descAI": "",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "view",
//			"jaxId": "1GGJKM84D1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1GGJKM84D8",
//					"attrs": {
//						"type": "view",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "100%",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Block"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "Gear/@aichat/ui/BoxTokenGas.js",
//							"jaxId": "1HHAMBFU40",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1HHAMC8EB0",
//									"attrs": {
//										"h": "30",
//										"bgColor": "#cfgColor[\"secondary\"]",
//										"textColor": "#cfgColor[\"fontSecondary\"]",
//										"iconSize": "24",
//										"fontSize": "16",
//										"menu": "false",
//										"thin": "false",
//										"chatIcon": "#appCfg.sharedAssets+\"/ablogo.svg\"",
//										"chatIconSize": "30"
//									}
//								},
//								"properties": {
//									"jaxId": "1HHAMC8EB1",
//									"attrs": {
//										"type": "#null#>BoxTokenGas(30,cfgColor[\"secondary\"],cfgColor[\"fontSecondary\"],24,16,false,false,appCfg.sharedAssets+\"/ablogo.svg\",30)",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"display": "On",
//										"face": "",
//										"caption": "#title"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HHAMC8EB2",
//									"attrs": {
//										"1II6BHM6B0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IIQDHHU43",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IIQDHHU44",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1II6BHM6B0",
//											"faceTagName": "tbxInference"
//										},
//										"1IHUJ66RM0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IJID2C9U3",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IJID2C9U4",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IHUJ66RM0",
//											"faceTagName": "tbxBash"
//										},
//										"1IIQDG1070": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IJID2C9U5",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IJID2C9U6",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IIQDG1070",
//											"faceTagName": "tbxLogs"
//										},
//										"1ILNRS8JT0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1ILNRTQC61",
//											"attrs": {
//												"properties": {
//													"jaxId": "1ILNRTQC62",
//													"attrs": {
//														"y": {
//															"type": "length",
//															"valText": "100%"
//														},
//														"anchorV": {
//															"type": "choice",
//															"valText": "Bottom"
//														},
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1ILNRS8JT0",
//											"faceTagName": "embed"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HHAMC8EB3",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HHAMC8EB4",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false",
//								"containerSlots": {
//									"jaxId": "1HHAMC8EB5",
//									"attrs": {}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1HDBT1RJN0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HDBT8BEP8",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxChat",
//										"position": "Absolute",
//										"x": "0",
//										"y": "30",
//										"w": "480",
//										"h": "100%-30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": ""
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "Gear/@aichat/ui/UIChat.js",
//											"jaxId": "1HDBT34IS0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1HDBT8BEP9",
//													"attrs": {
//														"opts": {
//															"jaxId": "1HDBT8BEP10",
//															"attrs": {
//																"bubble": "false",
//																"ai": {
//																	"jaxId": "1HDBT8BEP11",
//																	"attrs": {
//																		"blkColor": "[0,0,0,0.00]",
//																		"bgColor": "#cfgColor[\"success\"]",
//																		"icon": "#appCfg.sharedAssets+\"/faces.svg\"",
//																		"pic": "",
//																		"textColor": "#cfgColor[\"fontBody\"]",
//																		"iconColor": "#cfgColor[\"fontSuccess\"]",
//																		"side": "left"
//																	}
//																},
//																"user": {
//																	"jaxId": "1HDBT8BEP12",
//																	"attrs": {
//																		"blkColor": "[0,0,0,0.00]",
//																		"bgColor": "#cfgColor.primary",
//																		"icon": "#appCfg.sharedAssets+\"/user.svg\"",
//																		"pic": "",
//																		"textColor": "#cfgColor[\"fontBody\"]",
//																		"iconColor": "#cfgColor[\"fontPrimary\"]",
//																		"side": "right"
//																	}
//																},
//																"wait": {
//																	"jaxId": "1HDBT8BEP13",
//																	"attrs": {
//																		"blkColor": "[0,0,0,0.00]",
//																		"bgColor": "#cfgColor[\"secondary\"]",
//																		"icon": "#appCfg.sharedAssets+\"/faces.svg\"",
//																		"pic": "",
//																		"textColor": "#cfgColor[\"fontBody\"]",
//																		"iconColor": "#cfgColor[\"fontSecondary\"]",
//																		"side": "left"
//																	}
//																},
//																"event": {
//																	"jaxId": "1HDBT8BEP14",
//																	"attrs": {
//																		"blkColor": "[0,0,0,0.00]",
//																		"bgColor": "#cfgColor[\"warning\"]",
//																		"icon": "#appCfg.sharedAssets+\"/event.svg\"",
//																		"pic": "",
//																		"textColor": "#cfgColor[\"fontBody\"]",
//																		"iconColor": "#cfgColor[\"fontWarning\"]",
//																		"side": "left"
//																	}
//																},
//																"error": {
//																	"jaxId": "1HDBT8BEP15",
//																	"attrs": {
//																		"blkColor": "[0,0,0,0.00]",
//																		"bgColor": "#cfgColor[\"error\"]",
//																		"icon": "#appCfg.sharedAssets+\"/fat_right.svg\"",
//																		"pic": "",
//																		"textColor": "[155,0,0,1.00]",
//																		"iconColor": "#cfgColor[\"fontError\"]",
//																		"side": "left"
//																	}
//																},
//																"ask": {
//																	"jaxId": "1HDBT8BEP16",
//																	"attrs": {
//																		"blkColor": "[0,0,0,0.00]",
//																		"bgColor": "#cfgColor[\"success\"]",
//																		"icon": "#appCfg.sharedAssets+\"/help.svg\"",
//																		"pic": "",
//																		"textColor": "#cfgColor[\"fontBody\"]",
//																		"iconColor": "#cfgColor[\"fontSuccess\"]",
//																		"side": "left"
//																	}
//																},
//																"allowFile": "false"
//															}
//														}
//													}
//												},
//												"properties": {
//													"jaxId": "1HDBT8BEP17",
//													"attrs": {
//														"type": "#null#>UIChat({\"bubble\":false,\"ai\":{\"blkColor\":[0,0,0,0],\"bgColor\":cfgColor[\"success\"],\"icon\":appCfg.sharedAssets+\"/faces.svg\",\"pic\":\"\",\"textColor\":cfgColor[\"fontBody\"],\"iconColor\":cfgColor[\"fontSuccess\"],\"side\":\"left\"},\"user\":{\"blkColor\":[0,0,0,0],\"bgColor\":cfgColor.primary,\"icon\":appCfg.sharedAssets+\"/user.svg\",\"pic\":\"\",\"textColor\":cfgColor[\"fontBody\"],\"iconColor\":cfgColor[\"fontPrimary\"],\"side\":\"right\"},\"wait\":{\"blkColor\":[0,0,0,0],\"bgColor\":cfgColor[\"secondary\"],\"icon\":appCfg.sharedAssets+\"/faces.svg\",\"pic\":\"\",\"textColor\":cfgColor[\"fontBody\"],\"iconColor\":cfgColor[\"fontSecondary\"],\"side\":\"left\"},\"event\":{\"blkColor\":[0,0,0,0],\"bgColor\":cfgColor[\"warning\"],\"icon\":appCfg.sharedAssets+\"/event.svg\",\"pic\":\"\",\"textColor\":cfgColor[\"fontBody\"],\"iconColor\":cfgColor[\"fontWarning\"],\"side\":\"left\"},\"error\":{\"blkColor\":[0,0,0,0],\"bgColor\":cfgColor[\"error\"],\"icon\":appCfg.sharedAssets+\"/fat_right.svg\",\"pic\":\"\",\"textColor\":[155,0,0,1],\"iconColor\":cfgColor[\"fontError\"],\"side\":\"left\"},\"ask\":{\"blkColor\":[0,0,0,0],\"bgColor\":cfgColor[\"success\"],\"icon\":appCfg.sharedAssets+\"/help.svg\",\"pic\":\"\",\"textColor\":cfgColor[\"fontBody\"],\"iconColor\":cfgColor[\"fontSuccess\"],\"side\":\"left\"},\"allowFile\":false})",
//														"id": "BoxAIChat",
//														"position": "Absolute",
//														"x": "0",
//														"y": "30",
//														"display": "On",
//														"face": "",
//														"h": "100%-30"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HDBT8BEP18",
//													"attrs": {
//														"1II6BHM6B0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IIQDHHU47",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IIQDHHU48",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II6BHM6B0",
//															"faceTagName": "tbxInference"
//														},
//														"1IHUJ66RM0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IJID2C9U9",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IJID2C9U10",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IHUJ66RM0",
//															"faceTagName": "tbxBash"
//														},
//														"1IIQDG1070": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IJID2C9V0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IJID2C9V1",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IIQDG1070",
//															"faceTagName": "tbxLogs"
//														},
//														"1ILNRS8JT0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1ILOBI4860",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1ILOBI4861",
//																	"attrs": {
//																		"y": {
//																			"type": "length",
//																			"valText": "0"
//																		},
//																		"h": {
//																			"type": "length",
//																			"valText": "100%"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1ILNRS8JT0",
//															"faceTagName": "embed"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HDBT8BEP19",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HDBT8BEP20",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "true",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1HDBT8BEP21",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1IHRRMK5D0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IHRRNEVK0",
//													"attrs": {
//														"type": "box",
//														"id": "BoxChatHeader",
//														"position": "Absolute",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "30",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "[0,13,0,5]",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "#cfgColor[\"body\"]",
//														"border": "[0,0,1,0]",
//														"borderStyle": "Solid",
//														"borderColor": "#cfgColor[\"fontBodySub\"]",
//														"corner": "0",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]",
//														"contentLayout": "Flex X",
//														"itemsAlign": "Center"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1IHRRSCOS0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IHRRTRA20",
//																	"attrs": {
//																		"type": "text",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[0,0,0,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontBody\"]",
//																		"text": "Agent chats",
//																		"font": "",
//																		"fontSize": "16",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Top",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"lineClamp": "0",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0",
//																		"flex": "true"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IHRRTRA21",
//																	"attrs": {
//																		"1II6BHM6B0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IIQDHHU411",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IIQDHHU412",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1II6BHM6B0",
//																			"faceTagName": "tbxInference"
//																		},
//																		"1IHUJ66RM0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJID2C9V4",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJID2C9V5",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IHUJ66RM0",
//																			"faceTagName": "tbxBash"
//																		},
//																		"1IIQDG1070": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJID2C9V6",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJID2C9V7",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IIQDG1070",
//																			"faceTagName": "tbxLogs"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1IHRRTRA22",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1IHRRTRA23",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1IHRRO8470",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1IHRRQRKQ0",
//																	"attrs": {
//																		"style": "\"front\"",
//																		"w": "26",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/trash.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1IHRRQRKQ1",
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"front\",26,0,appCfg.sharedAssets+\"/trash.svg\",null)",
//																		"id": "BtnClearChat",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"enable": "false"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IHRRQRKQ2",
//																	"attrs": {
//																		"1II6BHM6B0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IIQDHHU415",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IIQDHHU416",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1II6BHM6B0",
//																			"faceTagName": "tbxInference"
//																		},
//																		"1IHUJ66RM0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJID2C9V10",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJID2C9V11",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IHUJ66RM0",
//																			"faceTagName": "tbxBash"
//																		},
//																		"1IIQDG1070": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJID2C9V12",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJID2C9V13",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IIQDG1070",
//																			"faceTagName": "tbxLogs"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1IHRRQRKQ3",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1IHRRQRKQ4",
//																	"attrs": {
//																		"tip": {
//																			"type": "string",
//																			"valText": "Clear",
//																			"localize": {
//																				"EN": "Clear",
//																				"CN": "清除"
//																			},
//																			"localizable": true
//																		}
//																	}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1IHRRQRKQ5",
//																	"attrs": {}
//																}
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1IHRRNEVK1",
//													"attrs": {
//														"1II6BHM6B0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IIQDHHU419",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IIQDHHU420",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II6BHM6B0",
//															"faceTagName": "tbxInference"
//														},
//														"1IHUJ66RM0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IJID2C9V16",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IJID2C9V17",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IHUJ66RM0",
//															"faceTagName": "tbxBash"
//														},
//														"1IIQDG1070": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IJID2C9V18",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IJID2C9V19",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IIQDG1070",
//															"faceTagName": "tbxLogs"
//														},
//														"1ILNRS8JT0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1ILOBI4866",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1ILOBI4867",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1ILNRS8JT0",
//															"faceTagName": "embed"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IHRRNEVK2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IHRRNEVK3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1IHROFSPO0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IHROGNGN0",
//													"attrs": {
//														"type": "box",
//														"id": "",
//														"position": "Absolute",
//														"x": "100%-1",
//														"y": "0",
//														"w": "1",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "#cfgColor[\"fontBodySub\"]",
//														"border": "0",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IHROGNGN1",
//													"attrs": {
//														"1II6BHM6B0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IIQDHHU423",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IIQDHHU424",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II6BHM6B0",
//															"faceTagName": "tbxInference"
//														},
//														"1IHUJ66RM0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IJID2C9V22",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IJID2C9V23",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IHUJ66RM0",
//															"faceTagName": "tbxBash"
//														},
//														"1IIQDG1070": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IJID2C9V24",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IJID2C9V25",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IIQDG1070",
//															"faceTagName": "tbxLogs"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IHROGNGN2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IHROGNGN3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1HDBT8BEP22",
//									"attrs": {
//										"1II6BHM6B0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IIQDHHU427",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IIQDHHU428",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1II6BHM6B0",
//											"faceTagName": "tbxInference"
//										},
//										"1IHUJ66RM0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IJID2C9V28",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IJID2C9V29",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IHUJ66RM0",
//											"faceTagName": "tbxBash"
//										},
//										"1IIQDG1070": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IJID2C9V30",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IJID2C9V31",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IIQDG1070",
//											"faceTagName": "tbxLogs"
//										},
//										"1ILNRS8JT0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1ILNRTQC710",
//											"attrs": {
//												"properties": {
//													"jaxId": "1ILNRTQC711",
//													"attrs": {
//														"y": {
//															"type": "length",
//															"valText": "0"
//														},
//														"h": {
//															"type": "length",
//															"valText": "100%"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1ILNRS8JT0",
//											"faceTagName": "embed"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HDBT8BEP23",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HDBT8BEP24",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1IHRSFUAP0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IHRSK5840",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxTools",
//										"position": "Absolute",
//										"x": "480",
//										"y": "30",
//										"w": "100%-480",
//										"h": "100%-30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": ""
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1IHRSON170",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IHRSON171",
//													"attrs": {
//														"type": "box",
//														"id": "BoxToolFooter",
//														"position": "Absolute",
//														"x": "0",
//														"y": "100%-30",
//														"w": "100%",
//														"h": "30",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "[0,2,0,2]",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "#cfgColor[\"body\"]",
//														"border": "[1,0,0,0]",
//														"borderStyle": "Solid",
//														"borderColor": "#cfgColor[\"fontBodySub\"]",
//														"corner": "0",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/NaviToolBar.js",
//															"jaxId": "1IHRT3E2S0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1IHRT61GM0",
//																	"attrs": {
//																		"tabBG": "true"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1IHRT61GM1",
//																	"attrs": {
//																		"type": "#null#>NaviToolBar(true)",
//																		"id": "",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IHRT61GM2",
//																	"attrs": {
//																		"1II6BHM6B0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IIQDHHU431",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IIQDHHU432",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1II6BHM6B0",
//																			"faceTagName": "tbxInference"
//																		},
//																		"1IHUJ66RM0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJID2C9V34",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJID2C9V35",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IHUJ66RM0",
//																			"faceTagName": "tbxBash"
//																		},
//																		"1IIQDG1070": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJID2C9V36",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJID2C9V37",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IIQDG1070",
//																			"faceTagName": "tbxLogs"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1IHRT61GM3",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1IHRT61GM4",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "true",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1IHRT61GM5",
//																	"attrs": {
//																		"Slot1HL4P0I9P0": {
//																			"jaxId": "1IHRT61GM6",
//																			"attrs": {
//																				"subHuds": {
//																					"attrs": [
//																						{
//																							"type": "hudobj",
//																							"def": "Gear/@StdUI/ui/BtnNaviItem.js",
//																							"jaxId": "1II4R1QQ40",
//																							"attrs": {
//																								"createArgs": {
//																									"jaxId": "1II4R1QQ41",
//																									"attrs": {
//																										"code": "Notes",
//																										"text": {
//																											"type": "string",
//																											"valText": "Inference",
//																											"localize": {
//																												"EN": "Inference",
//																												"CN": "推理视图"
//																											},
//																											"localizable": true
//																										},
//																										"color": "[0,0,0,1.00]",
//																										"icon": "#appCfg.sharedAssets+\"/memory.svg\"",
//																										"items": "",
//																										"fontSize": "#txtSize.smallPlus",
//																										"hasClose": "false",
//																										"iconSize": "0",
//																										"mark": "true"
//																									}
//																								},
//																								"properties": {
//																									"jaxId": "1II4R1QQ42",
//																									"attrs": {
//																										"type": "#null#>BtnNaviItem(\"Notes\",(($ln===\"CN\")?(\"推理视图\"):(\"Inference\")),[0,0,0,1],appCfg.sharedAssets+\"/memory.svg\",undefined,txtSize.smallPlus,false,0,true)",
//																										"id": "TabNotes",
//																										"position": "relative",
//																										"x": "0",
//																										"y": "0",
//																										"display": "On",
//																										"face": "",
//																										"margin": "[0,3,0,3]"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1II4R1QQ50",
//																									"attrs": {
//																										"1IHUJ66RM0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1II4R1QQ51",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1II4R1QQ52",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IHUJ66RM0",
//																											"faceTagName": "tbxBash"
//																										},
//																										"1II6BHM6B0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1II6BIG4G39",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1II6BIG4G40",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1II6BHM6B0",
//																											"faceTagName": "tbxInference"
//																										},
//																										"1IIQDG1070": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IIQDHHU50",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IIQDHHU51",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IIQDG1070",
//																											"faceTagName": "tbxLogs"
//																										},
//																										"1IJID11VL0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IJID2C9V38",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IJID2C9V39",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IJID11VL0",
//																											"faceTagName": "tbxFiles"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1II4R1QQ55",
//																									"attrs": {
//																										"OnClick": {
//																											"type": "fixedFunc",
//																											"jaxId": "1II4R1QQ56",
//																											"attrs": {
//																												"callArgs": {
//																													"jaxId": "1II4R1QQ57",
//																													"attrs": {
//																														"event": ""
//																													}
//																												},
//																												"seg": "1II6CP44V0"
//																											}
//																										}
//																									}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1II4R1QQ58",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "true",
//																								"containerSlots": {
//																									"jaxId": "1II4R1QQ59",
//																									"attrs": {}
//																								}
//																							}
//																						},
//																						{
//																							"type": "hudobj",
//																							"def": "Gear/@StdUI/ui/BtnNaviItem.js",
//																							"jaxId": "1ILSAPHN50",
//																							"attrs": {
//																								"createArgs": {
//																									"jaxId": "1ILSAPHN51",
//																									"attrs": {
//																										"code": "Path",
//																										"text": {
//																											"type": "string",
//																											"valText": "Canvas",
//																											"localize": {
//																												"EN": "Canvas",
//																												"CN": "画布"
//																											},
//																											"localizable": true
//																										},
//																										"color": "[0,0,0,1.00]",
//																										"icon": "#appCfg.sharedAssets+\"/canvas.svg\"",
//																										"items": "",
//																										"fontSize": "#txtSize.smallPlus",
//																										"hasClose": "false",
//																										"iconSize": "0",
//																										"mark": "true"
//																									}
//																								},
//																								"properties": {
//																									"jaxId": "1ILSAPHN52",
//																									"attrs": {
//																										"type": "#null#>BtnNaviItem(\"Path\",(($ln===\"CN\")?(\"画布\"):(\"Canvas\")),[0,0,0,1],appCfg.sharedAssets+\"/canvas.svg\",undefined,txtSize.smallPlus,false,0,true)",
//																										"id": "TabCanvas",
//																										"position": "relative",
//																										"x": "0",
//																										"y": "0",
//																										"display": "On",
//																										"face": "",
//																										"margin": "[0,3,0,3]",
//																										"enable": "false"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1ILSAPHN53",
//																									"attrs": {
//																										"1IHUJ66RM0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1ILSAPHN54",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1ILSAPHN55",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IHUJ66RM0",
//																											"faceTagName": "tbxBash"
//																										},
//																										"1II6BHM6B0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1ILSAPHN56",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1ILSAPHN57",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1II6BHM6B0",
//																											"faceTagName": "tbxInference"
//																										},
//																										"1IIQDG1070": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1ILSAPHN58",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1ILSAPHN59",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IIQDG1070",
//																											"faceTagName": "tbxLogs"
//																										},
//																										"1IJID11VL0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1ILSAPHN510",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1ILSAPHN511",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IJID11VL0",
//																											"faceTagName": "tbxFiles"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1ILSAPHN512",
//																									"attrs": {
//																										"OnClick": {
//																											"type": "fixedFunc",
//																											"jaxId": "1ILSAPHN513",
//																											"attrs": {
//																												"callArgs": {
//																													"jaxId": "1ILSAPHN514",
//																													"attrs": {
//																														"event": ""
//																													}
//																												},
//																												"seg": "1IIQDJIM60"
//																											}
//																										}
//																									}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1ILSAPHN515",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "false",
//																								"containerSlots": {
//																									"jaxId": "1ILSAPHN516",
//																									"attrs": {}
//																								}
//																							}
//																						},
//																						{
//																							"type": "hudobj",
//																							"def": "Gear/@StdUI/ui/BtnNaviItem.js",
//																							"jaxId": "1IIQD8VE20",
//																							"attrs": {
//																								"createArgs": {
//																									"jaxId": "1IIQD8VE21",
//																									"attrs": {
//																										"code": "Path",
//																										"text": "Logs",
//																										"color": "[0,0,0,1.00]",
//																										"icon": "#appCfg.sharedAssets+\"/read.svg\"",
//																										"items": "",
//																										"fontSize": "#txtSize.smallPlus",
//																										"hasClose": "false",
//																										"iconSize": "0",
//																										"mark": "true"
//																									}
//																								},
//																								"properties": {
//																									"jaxId": "1IIQD8VE22",
//																									"attrs": {
//																										"type": "#null#>BtnNaviItem(\"Path\",\"Logs\",[0,0,0,1],appCfg.sharedAssets+\"/read.svg\",undefined,txtSize.smallPlus,false,0,true)",
//																										"id": "TabLogs",
//																										"position": "relative",
//																										"x": "0",
//																										"y": "0",
//																										"display": "On",
//																										"face": "",
//																										"margin": "[0,3,0,3]",
//																										"enable": "true"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1IIQD8VE23",
//																									"attrs": {
//																										"1IHUJ66RM0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IIQD8VE24",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IIQD8VE25",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IHUJ66RM0",
//																											"faceTagName": "tbxBash"
//																										},
//																										"1II6BHM6B0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IIQD8VE30",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IIQD8VE31",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1II6BHM6B0",
//																											"faceTagName": "tbxInference"
//																										},
//																										"1IIQDG1070": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IIQDHHU52",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IIQDHHU53",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IIQDG1070",
//																											"faceTagName": "tbxLogs"
//																										},
//																										"1IJID11VL0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IJID2C9V40",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IJID2C9V41",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IJID11VL0",
//																											"faceTagName": "tbxFiles"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1IIQD8VE32",
//																									"attrs": {
//																										"OnClick": {
//																											"type": "fixedFunc",
//																											"jaxId": "1IIQDKI350",
//																											"attrs": {
//																												"callArgs": {
//																													"jaxId": "1IIQDKI351",
//																													"attrs": {
//																														"event": ""
//																													}
//																												},
//																												"seg": "1IIQDJIM60"
//																											}
//																										}
//																									}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1IIQD8VE33",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "false",
//																								"containerSlots": {
//																									"jaxId": "1IIQD8VE34",
//																									"attrs": {}
//																								}
//																							}
//																						},
//																						{
//																							"type": "hudobj",
//																							"def": "Gear/@StdUI/ui/BtnNaviItem.js",
//																							"jaxId": "1IHRT56I80",
//																							"attrs": {
//																								"createArgs": {
//																									"jaxId": "1IHRT61GM7",
//																									"attrs": {
//																										"code": "Home",
//																										"text": "Terminal",
//																										"color": "[0,0,0,1.00]",
//																										"icon": "#appCfg.sharedAssets+\"/terminal.svg\"",
//																										"items": "",
//																										"fontSize": "#txtSize.smallPlus",
//																										"hasClose": "false",
//																										"iconSize": "0",
//																										"mark": "true"
//																									}
//																								},
//																								"properties": {
//																									"jaxId": "1IHRT61GM8",
//																									"attrs": {
//																										"type": "#null#>BtnNaviItem(\"Home\",\"Terminal\",[0,0,0,1],appCfg.sharedAssets+\"/terminal.svg\",undefined,txtSize.smallPlus,false,0,true)",
//																										"id": "TabBash",
//																										"position": "relative",
//																										"x": "0",
//																										"y": "0",
//																										"display": "Off",
//																										"face": "",
//																										"margin": "[0,3,0,3]"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1IHRT61GM9",
//																									"attrs": {
//																										"1IHUJ66RM0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IHUJ6S5D0",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IHUJ6S5D1",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IHUJ66RM0",
//																											"faceTagName": "tbxBash"
//																										},
//																										"1II6BHM6B0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1II6BIG4G33",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1II6BIG4G34",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1II6BHM6B0",
//																											"faceTagName": "tbxInference"
//																										},
//																										"1IIQDG1070": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IIQDHHU54",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IIQDHHU55",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IIQDG1070",
//																											"faceTagName": "tbxLogs"
//																										},
//																										"1IJID11VL0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IJID2C9V42",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IJID2C9V43",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IJID11VL0",
//																											"faceTagName": "tbxFiles"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1IHRT61GM10",
//																									"attrs": {
//																										"OnClick": {
//																											"type": "fixedFunc",
//																											"jaxId": "1IHUJFPU50",
//																											"attrs": {
//																												"callArgs": {
//																													"jaxId": "1IHUJFPU90",
//																													"attrs": {
//																														"event": ""
//																													}
//																												},
//																												"seg": "1IHUJE1HL0"
//																											}
//																										}
//																									}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1IHRT61GM11",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "true",
//																								"containerSlots": {
//																									"jaxId": "1IHRT61GM12",
//																									"attrs": {}
//																								}
//																							}
//																						},
//																						{
//																							"type": "hudobj",
//																							"def": "Gear/@StdUI/ui/BtnNaviItem.js",
//																							"jaxId": "1IHUFRISN0",
//																							"attrs": {
//																								"createArgs": {
//																									"jaxId": "1IHUFVVQO0",
//																									"attrs": {
//																										"code": "Notes",
//																										"text": {
//																											"type": "string",
//																											"valText": "Notes",
//																											"localize": {
//																												"EN": "Notes"
//																											},
//																											"localizable": true
//																										},
//																										"color": "[0,0,0,1.00]",
//																										"icon": "#appCfg.sharedAssets+\"/rename.svg\"",
//																										"items": "",
//																										"fontSize": "#txtSize.smallPlus",
//																										"hasClose": "false",
//																										"iconSize": "0",
//																										"mark": "true"
//																									}
//																								},
//																								"properties": {
//																									"jaxId": "1IHUFVVQO1",
//																									"attrs": {
//																										"type": "#null#>BtnNaviItem(\"Notes\",(\"Notes\"),[0,0,0,1],appCfg.sharedAssets+\"/rename.svg\",undefined,txtSize.smallPlus,false,0,true)",
//																										"id": "TabNotes",
//																										"position": "relative",
//																										"x": "0",
//																										"y": "0",
//																										"display": "Off",
//																										"face": "",
//																										"margin": "[0,3,0,3]"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1IHUFVVQO2",
//																									"attrs": {
//																										"1IHUJ66RM0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IHUJ6S5D4",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IHUJ6S5D5",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IHUJ66RM0",
//																											"faceTagName": "tbxBash"
//																										},
//																										"1II6BHM6B0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1II6BIG4G35",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1II6BIG4G36",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1II6BHM6B0",
//																											"faceTagName": "tbxInference"
//																										},
//																										"1IIQDG1070": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IIQDHHU56",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IIQDHHU57",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IIQDG1070",
//																											"faceTagName": "tbxLogs"
//																										},
//																										"1IJID11VL0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IJID2C9V44",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IJID2C9V45",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IJID11VL0",
//																											"faceTagName": "tbxFiles"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1IHUFVVQO3",
//																									"attrs": {
//																										"OnClick": {
//																											"type": "fixedFunc",
//																											"jaxId": "1IHUJGC250",
//																											"attrs": {
//																												"callArgs": {
//																													"jaxId": "1IHUJGC251",
//																													"attrs": {
//																														"event": ""
//																													}
//																												},
//																												"seg": "1IHUJELCJ0"
//																											}
//																										}
//																									}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1IHUFVVQO4",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "true",
//																								"containerSlots": {
//																									"jaxId": "1IHUFVVQO5",
//																									"attrs": {}
//																								}
//																							}
//																						},
//																						{
//																							"type": "hudobj",
//																							"def": "Gear/@StdUI/ui/BtnNaviItem.js",
//																							"jaxId": "1IHRTJCOJ0",
//																							"attrs": {
//																								"createArgs": {
//																									"jaxId": "1IHRTKQPH0",
//																									"attrs": {
//																										"code": "Path",
//																										"text": "Files",
//																										"color": "[0,0,0,1.00]",
//																										"icon": "#appCfg.sharedAssets+\"/folder.svg\"",
//																										"items": "",
//																										"fontSize": "#txtSize.smallPlus",
//																										"hasClose": "false",
//																										"iconSize": "0",
//																										"mark": "true"
//																									}
//																								},
//																								"properties": {
//																									"jaxId": "1IHRTKQPH1",
//																									"attrs": {
//																										"type": "#null#>BtnNaviItem(\"Path\",\"Files\",[0,0,0,1],appCfg.sharedAssets+\"/folder.svg\",undefined,txtSize.smallPlus,false,0,true)",
//																										"id": "TabFiles",
//																										"position": "relative",
//																										"x": "0",
//																										"y": "0",
//																										"display": "Off",
//																										"face": "",
//																										"margin": "[0,3,0,3]",
//																										"enable": "true"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1IHRTKQPI0",
//																									"attrs": {
//																										"1IHUJ66RM0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IHUJ6S5D8",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IHUJ6S5D9",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IHUJ66RM0",
//																											"faceTagName": "tbxBash"
//																										},
//																										"1II6BHM6B0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1II6BIG4G37",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1II6BIG4G38",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1II6BHM6B0",
//																											"faceTagName": "tbxInference"
//																										},
//																										"1IIQDG1070": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IIQDHHU58",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IIQDHHU59",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IIQDG1070",
//																											"faceTagName": "tbxLogs"
//																										},
//																										"1IJID11VL0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IJID2C9V46",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IJID2C9V47",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1IJID11VL0",
//																											"faceTagName": "tbxFiles"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1IHRTKQPI1",
//																									"attrs": {
//																										"OnClick": {
//																											"type": "fixedFunc",
//																											"jaxId": "1IJJ35CQO0",
//																											"attrs": {
//																												"callArgs": {
//																													"jaxId": "1IJJ35CQO1",
//																													"attrs": {
//																														"event": ""
//																													}
//																												},
//																												"seg": "1IJJ337E60"
//																											}
//																										}
//																									}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1IHRTKQPI2",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "true",
//																								"containerSlots": {
//																									"jaxId": "1IHRTKQPI3",
//																									"attrs": {}
//																								}
//																							}
//																						}
//																					]
//																				},
//																				"container": "true"
//																			}
//																		}
//																	}
//																}
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1IHRSON172",
//													"attrs": {
//														"1II6BHM6B0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IIQDHHU512",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IIQDHHU513",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II6BHM6B0",
//															"faceTagName": "tbxInference"
//														},
//														"1IHUJ66RM0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IJID2C9V50",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IJID2C9V51",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IHUJ66RM0",
//															"faceTagName": "tbxBash"
//														},
//														"1IIQDG1070": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IJID2C9V52",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IJID2C9V53",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IIQDG1070",
//															"faceTagName": "tbxLogs"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IHRSON173",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IHRSON174",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1IHRTEID20",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IHRTFHDK0",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxToolView",
//														"position": "Absolute",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "100%-30",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": ""
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "Gear1II4RB79B0",
//															"jaxId": "1II6BGSOG0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1II6BHD360",
//																	"attrs": {}
//																},
//																"properties": {
//																	"jaxId": "1II6BHD361",
//																	"attrs": {
//																		"type": "#null#>TBXInference()",
//																		"id": "TbxInference",
//																		"position": "Absolute",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1II6BHD362",
//																	"attrs": {
//																		"1II6BHM6B0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1II6BIG4G49",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1II6BIG4G50",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1II6BHM6B0",
//																			"faceTagName": "tbxInference"
//																		},
//																		"1IHUJ66RM0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1II6BIG4G51",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1II6BIG4G52",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IHUJ66RM0",
//																			"faceTagName": "tbxBash"
//																		},
//																		"1IHUJ6BT40": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1II6BIG4G53",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1II6BIG4G54",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IHUJ6BT40",
//																			"faceTagName": "tbxNotes"
//																		},
//																		"1IIQDG1070": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IIQDHHU514",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IIQDHHU515",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IIQDG1070",
//																			"faceTagName": "tbxLogs"
//																		},
//																		"1IJID11VL0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJID2C9V54",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJID2C9V55",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IJID11VL0",
//																			"faceTagName": "tbxFiles"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1II6BHD363",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1II6BHD364",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1II6BHD365",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear1IHRTSOVV0",
//															"jaxId": "1IHRVOUT90",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1IHRVP8RM0",
//																	"attrs": {}
//																},
//																"properties": {
//																	"jaxId": "1IHRVP8RM1",
//																	"attrs": {
//																		"type": "#null#>TBXBash()",
//																		"id": "TbxBash",
//																		"position": "Absolute",
//																		"x": "0",
//																		"y": "0",
//																		"display": "Off",
//																		"face": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IHRVP8RM2",
//																	"attrs": {
//																		"1IHUJ6BT40": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IHUJ6S5D16",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IHUJ6S5D17",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IHUJ6BT40",
//																			"faceTagName": "tbxNotes"
//																		},
//																		"1IHUJ66RM0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IHUJ6S5D18",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IHUJ6S5D19",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IHUJ66RM0",
//																			"faceTagName": "tbxBash"
//																		},
//																		"1II6BHM6B0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1II6BIG4G45",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1II6BIG4G46",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1II6BHM6B0",
//																			"faceTagName": "tbxInference"
//																		},
//																		"1IIQDG1070": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IIQDHHU516",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IIQDHHU517",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IIQDG1070",
//																			"faceTagName": "tbxLogs"
//																		},
//																		"1IJID11VL0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJID2C9V56",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJID2C9V57",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IJID11VL0",
//																			"faceTagName": "tbxFiles"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1IHRVP8RM3",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1IHRVP8RM4",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1IHRVP8RM5",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear1IHUIJFMD0",
//															"jaxId": "1IHUJ32310",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1IHUJ5U0B0",
//																	"attrs": {}
//																},
//																"properties": {
//																	"jaxId": "1IHUJ5U0B1",
//																	"attrs": {
//																		"type": "#null#>TBXNotes()",
//																		"id": "TbxNotes",
//																		"position": "Absolute",
//																		"x": "0",
//																		"y": "0",
//																		"display": "Off",
//																		"face": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IHUJ5U0B2",
//																	"attrs": {
//																		"1IHUJ6BT40": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IHUJ6S5D20",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IHUJ6S5D21",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IHUJ6BT40",
//																			"faceTagName": "tbxNotes"
//																		},
//																		"1IHUJ66RM0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IHUJ6S5D22",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IHUJ6S5D23",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IHUJ66RM0",
//																			"faceTagName": "tbxBash"
//																		},
//																		"1II6BHM6B0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1II6BIG4G47",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1II6BIG4G48",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1II6BHM6B0",
//																			"faceTagName": "tbxInference"
//																		},
//																		"1IIQDG1070": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IIQDHHU518",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IIQDHHU519",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IIQDG1070",
//																			"faceTagName": "tbxLogs"
//																		},
//																		"1IJID11VL0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJID2C9V58",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJID2C9V59",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IJID11VL0",
//																			"faceTagName": "tbxFiles"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1IHUJ5U0B3",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1IHUJ5U0B4",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1IHUJ5U0B5",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear1IIQA7CBF0",
//															"jaxId": "1IIQDF03V0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1IIQDFR570",
//																	"attrs": {}
//																},
//																"properties": {
//																	"jaxId": "1IIQDFR571",
//																	"attrs": {
//																		"type": "#null#>TBXLogs()",
//																		"id": "TbxLogs",
//																		"position": "Absolute",
//																		"x": "0",
//																		"y": "0",
//																		"display": "Off",
//																		"face": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IIQDFR572",
//																	"attrs": {
//																		"1IIQDG1070": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IIQDHHU520",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IIQDHHU521",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IIQDG1070",
//																			"faceTagName": "tbxLogs"
//																		},
//																		"1IHUJ66RM0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IIQDHHU522",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IIQDHHU523",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IHUJ66RM0",
//																			"faceTagName": "tbxBash"
//																		},
//																		"1IHUJ6BT40": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IIQDHHU524",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IIQDHHU525",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IHUJ6BT40",
//																			"faceTagName": "tbxNotes"
//																		},
//																		"1II6BHM6B0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IIQDHHU526",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IIQDHHU527",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1II6BHM6B0",
//																			"faceTagName": "tbxInference"
//																		},
//																		"1IJID11VL0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJID2C9V60",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJID2C9V61",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IJID11VL0",
//																			"faceTagName": "tbxFiles"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1IIQDFR573",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1IIQDFR574",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1IIQDFR575",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear1IJI7V08Q0",
//															"jaxId": "1IJID01680",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1IJID2C9V62",
//																	"attrs": {}
//																},
//																"properties": {
//																	"jaxId": "1IJID2C9V63",
//																	"attrs": {
//																		"type": "#null#>TBXFiles()",
//																		"id": "TbxFiles",
//																		"position": "Absolute",
//																		"x": "0",
//																		"y": "0",
//																		"display": "Off",
//																		"face": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IJID2C9V64",
//																	"attrs": {
//																		"1IJID11VL0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJID2C9V65",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJID2C9V66",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IJID11VL0",
//																			"faceTagName": "tbxFiles"
//																		},
//																		"1IHUJ66RM0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJID2C9V67",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJID2C9V68",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IHUJ66RM0",
//																			"faceTagName": "tbxBash"
//																		},
//																		"1IHUJ6BT40": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJID2C9V69",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJID2C9V70",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IHUJ6BT40",
//																			"faceTagName": "tbxNotes"
//																		},
//																		"1II6BHM6B0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJID2C9V71",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJID2C9V72",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1II6BHM6B0",
//																			"faceTagName": "tbxInference"
//																		},
//																		"1IIQDG1070": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJID2C9V73",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJID2C9V74",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IIQDG1070",
//																			"faceTagName": "tbxLogs"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1IJID2C9V75",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1IJID2C9V76",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1IJID2C9V77",
//																	"attrs": {}
//																}
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1IHRTFHDK1",
//													"attrs": {
//														"1II6BHM6B0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IIQDHHU530",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IIQDHHU531",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II6BHM6B0",
//															"faceTagName": "tbxInference"
//														},
//														"1IHUJ66RM0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IJID2C9V80",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IJID2C9V81",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IHUJ66RM0",
//															"faceTagName": "tbxBash"
//														},
//														"1IIQDG1070": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IJID2C9V82",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IJID2C9V83",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IIQDG1070",
//															"faceTagName": "tbxLogs"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IHRTFHDK2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IHRTFHDK3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "true",
//												"exposeContainer": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1IHRSK5841",
//									"attrs": {
//										"1II6BHM6B0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IIQDHHU534",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IIQDHHU535",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1II6BHM6B0",
//											"faceTagName": "tbxInference"
//										},
//										"1IHUJ66RM0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IJID2C9V86",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IJID2C9V87",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IHUJ66RM0",
//											"faceTagName": "tbxBash"
//										},
//										"1IIQDG1070": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IJID2C9V88",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IJID2C9V89",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IIQDG1070",
//											"faceTagName": "tbxLogs"
//										},
//										"1ILNRS8JT0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1ILNRTQC738",
//											"attrs": {
//												"properties": {
//													"jaxId": "1ILNRTQC739",
//													"attrs": {
//														"y": {
//															"type": "length",
//															"valText": "0"
//														},
//														"h": {
//															"type": "length",
//															"valText": "100%"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1ILNRS8JT0",
//											"faceTagName": "embed"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1IHRSK5842",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IHRSK5843",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1GGJKM84D9",
//					"attrs": {
//						"1II6BHM6B0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1IIQDHHU538",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IIQDHHU539",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1II6BHM6B0",
//							"faceTagName": "tbxInference"
//						},
//						"1IHUJ66RM0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1IJID2C9V92",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IJID2C9V93",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1IHUJ66RM0",
//							"faceTagName": "tbxBash"
//						},
//						"1IIQDG1070": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1IJID2C9V94",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IJID2C9V95",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1IIQDG1070",
//							"faceTagName": "tbxLogs"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1GGJKM84D10",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1GGJKM84D11",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1GGJKM84D12",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false",
//				"innerLayout": {
//					"valText": "false"
//				},
//				"marginL": {
//					"valText": "false"
//				},
//				"marginR": {
//					"valText": "false"
//				},
//				"marginT": {
//					"valText": "false"
//				},
//				"marginB": {
//					"valText": "false"
//				},
//				"paddingL": {
//					"valText": "false"
//				},
//				"paddingR": {
//					"valText": "false"
//				},
//				"paddingT": {
//					"valText": "false"
//				},
//				"paddingB": {
//					"valText": "false"
//				},
//				"attach": {
//					"valText": "false"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}