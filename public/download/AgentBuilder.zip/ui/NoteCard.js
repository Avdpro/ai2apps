//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
/*#{1IHUKF6970StartDoc*/
import {tabFS} from "/@tabos";
import markdownit from "/@markdownit";
/*}#1IHUKF6970StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let NoteCard=function(doc){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let txtTitle,boxMD,txtTags;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1IHUKF6971LocalVals*/
	const app=VFACT.app;
	/*}#1IHUKF6971LocalVals*/
	
	/*#{1IHUKF6971PreState*/
	/*}#1IHUKF6971PreState*/
	/*#{1IHUKF6971PostState*/
	/*}#1IHUKF6971PostState*/
	cssVO={
		"hash":"1IHUKF6971",nameHost:true,
		"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":"","margin":[0,0,20,0],"minW":"","minH":100,"maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
		children:[
			{
				"hash":"1IHUKRU5B0",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":[255,255,255,1],"border":2,
				"borderColor":cfgColor["fontBodySub"],"corner":6,"shadow":true,"shadowSpread":3,"shadowColor":[0,0,0,0.15],
			},
			{
				"hash":"1IHUKHHJL0",
				"type":"hud","id":"BoxHeader","position":"relative","x":0,"y":0,"w":"100%","h":30,"padding":[0,5,0,5],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"contentLayout":"flex-x","itemsAlign":1,
				children:[
					{
						"hash":"1IHUKJETF0",
						"type":"box","position":"relative","x":0,"y":0,"w":28,"h":28,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["fontBodySub"],
						"maskImage":appCfg.sharedAssets+"/rename.svg",
					},
					{
						"hash":"1IHUKIDKC0",
						"type":"text","id":"TxtTitle","position":"relative","x":0,"y":0,"w":"","h":"","cursor":"pointer","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						"color":cfgColor["fontBody"],"text":doc.desc,"fontSize":txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","ellipsis":true,
						"flex":true,
						"OnClick":function(event){
							self.editTitle(this,event);
						},
					}
				],
			},
			{
				"hash":"1IHUKO6PB0",
				"type":"box","id":"BoxDoc","position":"relative","x":5,"y":0,"w":">calc(100% - 10px)","h":200,"overflow":"auto","minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","background":[255,255,255,1],"border":[1,0,1,0],
				children:[
					{
						"hash":"1IHUL7KUU0",
						"type":"hud","id":"BoxMD","x":5,"y":0,"w":">calc(100% - 5px)","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
					}
				],
			},
			{
				"hash":"1IHUKPIOB0",
				"type":"hud","id":"BoxFooter","position":"relative","x":0,"y":0,"w":"100%","h":30,"padding":[0,10,0,10],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"contentLayout":"flex-x","itemsAlign":1,"subAlign":2,
				children:[
					{
						"hash":"1IHVJ4MOB0",
						"type":"text","id":"TxtTags","position":"relative","x":0,"y":0,"w":"","h":"","cursor":"pointer","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						"color":cfgColor["fontBodySub"],"text":"Tags: "+doc.tags,"fontSize":txtSize.small,"fontWeight":"bold","fontStyle":"normal","textDecoration":"","flex":true,
						"OnClick":function(event){
							self.editTags(this,event);
						},
						/*#{1IHVJ4MOB0Codes*/
						/*}#1IHVJ4MOB0Codes*/
					},
					{
						"hash":"1IHUL0JM90",
						"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/edit.svg",null),"id":"BtnEdit","position":"relative","x":0,"y":0,"margin":[0,2,0,2],
						"tip":(($ln==="CN")?("编辑"):("Edit")),
						"OnClick":function(event){
							self.editNote(this,event);
						},
					},
					{
						"hash":"1II2T67P50",
						"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/save.svg",null),"id":"BtnSave","position":"relative","x":0,"y":0,"margin":[0,2,0,2],
						"tip":(($ln==="CN")?("提交到知识库"):("Push to RAG")),
						"OnClick":function(event){
							self.saveDoc(this,event);
						},
					},
					{
						"hash":"1IHUL34CJ0",
						"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/dbload.svg",null),"id":"BtnEdit","position":"relative","x":0,"y":0,"margin":[0,2,0,2],
						"tip":(($ln==="CN")?("提交到知识库"):("Push to RAG")),
						"OnClick":function(event){
							self.pushNote(this,event);
						},
					}
				],
			}
		],
		/*#{1IHUKF6971ExtraCSS*/
		/*}#1IHUKF6971ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			self=this;
			txtTitle=self.TxtTitle;boxMD=self.BoxMD;txtTags=self.TxtTags;
			/*#{1IHUKF6971Create*/
			self.showDoc();
			/*}#1IHUKF6971Create*/
		},
		/*#{1IHUKF6971EndCSS*/
		/*}#1IHUKF6971EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.showDoc=async function(){
		/*#{1IHV5FAHB0Start*/
		let htmlCode,webObj;
		htmlCode=markdownit().render(""+doc.doc);
		webObj=boxMD.webObj;
		webObj.style.fontSize="14px";
		webObj.innerHTML=htmlCode;
		/*}#1IHV5FAHB0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.editNote=async function(){
		/*#{1IHV5AVK30Start*/
		let text;
		text=await app.modalDlg("/@editkit/ui/DlgLongText.js",{
			title:(($ln==="CN")?("编辑笔记"):/*EN*/("Edit Note")),
			text:doc.doc
		});
		if(text){
			doc.doc=text;
			self.showDoc();
		}
		/*}#1IHV5AVK30Start*/
	};
	//------------------------------------------------------------------------
	cssVO.editTitle=async function(){
		/*#{1IHVJBTCR0Start*/
		let text;
		text=await app.modalDlg("/@editkit/ui/DlgLongText.js",{
			title:(($ln==="CN")?("编辑标题"):/*EN*/("Edit Title")),
			text:doc.desc
		});
		if(text){
			doc.desc=text;
			txtTitle.text=text;
		}
		/*}#1IHVJBTCR0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.editTags=async function(){
		/*#{1IHVJC85L0Start*/
		let newTags;
		//newTags=window.prompt((($ln==="CN")?("编辑标签"):/*EN*/("Edit tags")),doc.tags||""); 
		newTags=await app.modalDlg("/@StdUI/ui/DlgPrompt.js",{title:(($ln==="CN")?("编辑标签"):/*EN*/("Edit tags")),text:doc.tags||""});
		if(newTags===null){
			return;
		}
		doc.tags=newTags;
		txtTags.text="Tags: "+newTags;
		/*}#1IHVJC85L0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.saveDoc=async function(){
		/*#{1II2T82KI0Start*/
		let path;
		path=app.modalDlg("/@StdUI/ui/DlgFile.js",{
			mode:"save",
			path:"/doc",
			fileName:"guide.md",
			options:{
				multiSelect:1,
				preview:1,
			},
			callback:async function(filePath){
				if(!filePath){
					return;
				}
				await tabFS.writeFile(filePath,doc.doc,"utf8");
			}
		});
		/*}#1II2T82KI0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.pushNote=async function(sender,event){
		/*#{1IIA75GFU0Start*/
		sender.enable=false;
		self.pushRAG && (await self.pushRAG(doc,sender));
		sender.enable=true;
		/*}#1IIA75GFU0Start*/
	};
	/*#{1IHUKF6971PostCSSVO*/
	/*}#1IHUKF6971PostCSSVO*/
	cssVO.constructor=NoteCard;
	return cssVO;
};
/*#{1IHUKF6971ExCodes*/
/*}#1IHUKF6971ExCodes*/

//----------------------------------------------------------------------------
NoteCard.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1IHUKF6971PreAISpot*/
	/*}#1IHUKF6971PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1IHUKF6971PostAISpot*/
	/*}#1IHUKF6971PostAISpot*/
	return exposeVO;
};

//----------------------------------------------------------------------------
NoteCard.gearExport={
	framework: "jax",
	hudType: "hud",
	"showName":"",icon:"gears.svg",previewImg:false,
	fixPose:false,initW:100,initH:100,
	catalog:"",
	args: {
		"doc": {
			"type": "object", "name": "doc", "showName": "doc", "icon": undefined, 
			"def": {
				"attrs": {
					"desc": {
						"name": "desc", "showName": "desc", "type": "string", "key": true, "fixed": true, "initVal": "github.com/lihxxx/DisPose安装指南"
					}, 
					"doc": {
						"name": "doc", "showName": "doc", "type": "string", "key": true, "fixed": true, "initVal": "1234"
					}, 
					"env": {"name":"env","showName":"env","type":"auto","key":true,"fixed":true}, 
					"project": {
						"name": "project", "showName": "project", "type": "auto", "key": true, "fixed": true, "initVal": undefined
					}, 
					"tags": {
						"name": "tags", "showName": "tags", "type": "string", "key": true, "fixed": true, "initVal": "github,setup"
					}
				}
			}, 
			"key": true, "fixed": true
		}
	},
	state:{
	},
	properties:["id","position","x","y","display"],
	faces:[],
	subContainers:{
	},
	/*#{1IHUKF6970ExGearInfo*/
	/*}#1IHUKF6970ExGearInfo*/
};
/*#{1IHUKF6970EndDoc*/
/*}#1IHUKF6970EndDoc*/

export default NoteCard;
export{NoteCard};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1IHUKF6970",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1IHUKF6972",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1IHUKF6973",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1IHUKF6974",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1IHUKF6975",
//			"attrs": {
//				"doc": {
//					"type": "object",
//					"def": "FlatObj",
//					"jaxId": "1IHULC7KF0",
//					"attrs": {
//						"desc": {
//							"type": "string",
//							"valText": "github.com/lihxxx/DisPose安装指南"
//						},
//						"doc": {
//							"type": "string",
//							"valText": "1234"
//						},
//						"env": {
//							"type": "auto",
//							"valText": ""
//						},
//						"project": {
//							"type": "auto",
//							"valText": ""
//						},
//						"tags": {
//							"type": "string",
//							"valText": "github,setup"
//						}
//					}
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1IHUKF6976",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1IHUKF6977",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IHV5FAHB0",
//					"attrs": {
//						"id": "showDoc",
//						"label": "New AI Seg",
//						"x": "75",
//						"y": "105",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IHV5G5T10",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IHV5G5T20",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IHV5G5T21",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IHV5AVK30",
//					"attrs": {
//						"id": "editNote",
//						"label": "New AI Seg",
//						"x": "75",
//						"y": "185",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IHV5BBB10",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IHV5BBB11",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IHV5BBB12",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IHVJBTCR0",
//					"attrs": {
//						"id": "editTitle",
//						"label": "New AI Seg",
//						"x": "75",
//						"y": "265",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IHVJCEA80",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IHVJCEA81",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IHVJCEA82",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IHVJC85L0",
//					"attrs": {
//						"id": "editTags",
//						"label": "New AI Seg",
//						"x": "75",
//						"y": "345",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IHVJCEA83",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IHVJCEA84",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IHVJCEA85",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1II2T82KI0",
//					"attrs": {
//						"id": "saveDoc",
//						"label": "New AI Seg",
//						"x": "75",
//						"y": "430",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1II2T8A3J0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1II2T8A3J1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1II2T8A3J2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IIA75GFU0",
//					"attrs": {
//						"id": "pushNote",
//						"label": "New AI Seg",
//						"x": "75",
//						"y": "525",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IIA76R0E0",
//							"attrs": {
//								"sender": {
//									"valText": "null"
//								},
//								"event": {
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IIA76R0E1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IIA76R0E2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				}
//			]
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1IHUKF6978",
//			"attrs": {}
//		},
//		"mockupStates": {
//			"jaxId": "1IHUKF6979",
//			"attrs": {}
//		},
//		"exposeToAI": "true",
//		"descAI": "",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1IHUKF6971",
//			"attrs": {
//				"properties": {
//					"jaxId": "1IHUKF69710",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Relative",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "[0,0,20,0]",
//						"padding": "",
//						"minW": "",
//						"minH": "100",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Flex Y"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1IHUKRU5B0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IHUL07EC0",
//									"attrs": {
//										"type": "box",
//										"id": "BoxBG",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "[255,255,255,1.00]",
//										"border": "2",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor[\"fontBodySub\"]",
//										"corner": "6",
//										"shadow": "true",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "3",
//										"shadowColor": "[0,0,0,0.15]"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1IHUL07EC1",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1IHUL07EC2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IHUL07EC3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1IHUKHHJL0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IHUKNS210",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxHeader",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "[0,5,0,5]",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex X",
//										"itemsAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1IHUKJETF0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IHUKNS211",
//													"attrs": {
//														"type": "box",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "28",
//														"h": "28",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "#cfgColor[\"fontBodySub\"]",
//														"border": "0",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]",
//														"maskImage": "#appCfg.sharedAssets+\"/rename.svg\""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IHUKNS212",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1IHUKNS213",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IHUKNS214",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1IHUKIDKC0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IHUKNS215",
//													"attrs": {
//														"type": "text",
//														"id": "TxtTitle",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "pointer",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBody\"]",
//														"text": "#doc.desc",
//														"font": "",
//														"fontSize": "#txtSize.smallPlus",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "true",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0",
//														"flex": "true"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IHUKNS216",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1IHUKNS217",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1IHVJI0N80",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1IHVJI0N81",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": "1IHVJBTCR0"
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1IHUKNS218",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1IHUKNS219",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1IHUKNS2110",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IHUKNS2111",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1IHUKO6PB0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IHUKOVN60",
//									"attrs": {
//										"type": "box",
//										"id": "BoxDoc",
//										"position": "relative",
//										"x": "5",
//										"y": "0",
//										"w": "100%-10",
//										"h": "200",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Auto Scroll",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "[255,255,255,1.00]",
//										"border": "[1,0,1,0]",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1IHUL7KUU0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IHUL7TD40",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxMD",
//														"position": "Absolute",
//														"x": "5",
//														"y": "0",
//														"w": "100%-5",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": ""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IHUL7TD41",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1IHUL7TD42",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IHUL7TD43",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "true",
//												"exposeContainer": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1IHUKOVN61",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1IHUKOVN62",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IHUKOVN63",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1IHUKPIOB0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IHUKQ70N0",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxFooter",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "[0,10,0,10]",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex X",
//										"itemsAlign": "Center",
//										"subAlign": "End"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1IHVJ4MOB0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IHVJ7FQO0",
//													"attrs": {
//														"type": "text",
//														"id": "TxtTags",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "pointer",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBodySub\"]",
//														"text": "#\"Tags: \"+doc.tags",
//														"font": "",
//														"fontSize": "#txtSize.small",
//														"bold": "true",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0",
//														"flex": "true"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IHVJ7FQO1",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1IHVJ7FQO2",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1IHVJI0N82",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1IHVJI0N83",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": "1IHVJC85L0"
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1IHVJ7FQO3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "true",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1IHUL0JM90",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1IHUL2K1R0",
//													"attrs": {
//														"style": "\"front\"",
//														"w": "24",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/edit.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1IHUL2K1R1",
//													"attrs": {
//														"type": "#null#>BtnIcon(\"front\",24,0,appCfg.sharedAssets+\"/edit.svg\",null)",
//														"id": "BtnEdit",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"margin": "[0,2,0,2]"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IHUL2K1R2",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1IHUL2K1R3",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1IHV5BJM80",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1IHV5BJM81",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": "1IHV5AVK30"
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1IHUL2K1R4",
//													"attrs": {
//														"tip": {
//															"type": "string",
//															"valText": "Edit",
//															"localize": {
//																"EN": "Edit",
//																"CN": "编辑"
//															},
//															"localizable": true
//														}
//													}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1IHUL2K1R5",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1II2T67P50",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1II2T67P51",
//													"attrs": {
//														"style": "\"front\"",
//														"w": "24",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/save.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1II2T67P52",
//													"attrs": {
//														"type": "#null#>BtnIcon(\"front\",24,0,appCfg.sharedAssets+\"/save.svg\",null)",
//														"id": "BtnSave",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"margin": "[0,2,0,2]"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1II2T67P60",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1II2T67P61",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1II2UA0LB0",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1II2UA0LB1",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": "1II2T82KI0"
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1II2T67P62",
//													"attrs": {
//														"tip": {
//															"type": "string",
//															"valText": "Push to RAG",
//															"localize": {
//																"EN": "Push to RAG",
//																"CN": "提交到知识库"
//															},
//															"localizable": true
//														}
//													}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1II2T67P63",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1IHUL34CJ0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1IHUL34CJ1",
//													"attrs": {
//														"style": "\"front\"",
//														"w": "24",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/dbload.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1IHUL34CK0",
//													"attrs": {
//														"type": "#null#>BtnIcon(\"front\",24,0,appCfg.sharedAssets+\"/dbload.svg\",null)",
//														"id": "BtnEdit",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"margin": "[0,2,0,2]"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IHUL34CK1",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1IHUL34CK2",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1IIA76R0F0",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1IIA76R0F1",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": "1IIA75GFU0"
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1IHUL34CK3",
//													"attrs": {
//														"tip": {
//															"type": "string",
//															"valText": "Push to RAG",
//															"localize": {
//																"EN": "Push to RAG",
//																"CN": "提交到知识库"
//															},
//															"localizable": true
//														}
//													}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1IHUL34CK4",
//													"attrs": {}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1IHUKQ70N1",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1IHUKQ70N2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IHUKQ70N3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1IHUKF69711",
//					"attrs": {}
//				},
//				"functions": {
//					"jaxId": "1IHUKF69712",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1IHUKF69713",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1IHUKF69714",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}