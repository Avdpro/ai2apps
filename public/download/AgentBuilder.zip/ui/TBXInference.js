//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
import {BtnSwitch} from "/@StdUI/ui/BtnSwitch.js";
/*#{1II4RB79B0StartDoc*/
import {InfoCard} from "/@StdUI/ui/InfoCard.js";
import {ViDoc} from "../vi/ViDoc.js";
import {ViFrame} from "../vi/ViFrame.js";
/*}#1II4RB79B0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let TBXInference=function(){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let boxCanvas,boxLogs,txtAgent,btnStepRun,btnSlowMo;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1II4RB79B1LocalVals*/
	const app=VFACT.app;
	const rootApp=app.appFrame?app.appFrame.app:app;
	let ws=null;
	let connected=false;
	let agents=new Map();
	let curFrame=null;
	let dragMeta=null;
	let anis=[];
	let aniPlaying=false;
	let frameStack=[];
	let allFrames=[];
	let slowMo=false;
	/*}#1II4RB79B1LocalVals*/
	
	/*#{1II4RB79B1PreState*/
	/*}#1II4RB79B1PreState*/
	/*#{1II4RB79B1PostState*/
	/*}#1II4RB79B1PostState*/
	cssVO={
		"hash":"1II4RB79B1",nameHost:true,
		"type":"hud","x":0,"y":0,"w":"100%","h":"100%","overflow":1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
		children:[
			{
				"hash":"1II693S5F0",
				"type":"hud","id":"BoxView","x":2,"y":30,"w":"100%","h":">calc(100% - 30px)","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				children:[
					{
						"hash":"1II6ARL530",
						"type":"hud","id":"BoxCanvas","x":0,"y":0,"w":"125%","h":"125%","scale":0.8,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
					},
					{
						"hash":"1IIS2LUKI0",
						"type":"box","id":"BoxPaused","x":20,"y":20,"w":"","h":60,"display":0,"padding":10,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["body"],
						"border":2,"borderColor":cfgColor["fontBody"],"corner":6,"shadow":true,"shadowX":4,"shadowY":6,"shadowBlur":6,"shadowColor":[0,0,0,0.25],"contentLayout":"flex-x",
						"itemsAlign":1,
						children:[
							{
								"hash":"1IIS2R7H40",
								"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","margin":[0,10,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
								"text":(($ln==="CN")?("已暂停"):("Paused")),"fontSize":txtSize.big,"fontWeight":"bold","fontStyle":"normal","textDecoration":"",
							},
							{
								"hash":"1IIS2U1MB0",
								"type":BtnIcon("front",36,0,appCfg.sharedAssets+"/run.svg",null),"id":"BtnRunStep","position":"relative","x":0,"y":0,
								"OnClick":function(event){
									self.resumeRun(this,event);
								},
							}
						],
					},
					{
						"hash":"1II696I8U0",
						"type":"box","id":"BoxLogs","x":">calc(100% - 300px)","y":0,"w":300,"h":"100%","overflow":"auto-y","padding":[5,5,50,5],"minW":"","minH":"","maxW":"",
						"maxH":"","styleClass":"","background":cfgColor["body"],"border":[0,0,0,1],"shadow":true,"shadowX":-2,"shadowY":0,"shadowColor":[0,0,0,0.2],
					}
				],
			},
			{
				"hash":"1II690HL30",
				"type":"box","id":"BoxHeader","x":0,"y":0,"w":"100%","h":30,"padding":[0,5,0,5],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["body"],
				"border":[0,0,1,0],"contentLayout":"flex-x","itemsAlign":1,
				children:[
					{
						"hash":"1II7RNLS00",
						"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/btncombo.svg",null),"id":"BtnShowFrames","position":"relative","x":0,"y":0,
						"tip":(($ln==="CN")?("智能体调用帧"):("Agent call frames")),
						"OnClick":function(event){
							self.showFrames(this,event);
						},
					},
					{
						"hash":"1II69BUVM0",
						"type":"text","id":"TxtAgent","position":"relative","x":0,"y":0,"w":"","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
						"text":(($ln==="CN")?("暂无智能体调试帧"):("No agent frames")),"fontSize":txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
						"flex":true,
					},
					{
						"hash":"1IIS131RH0",
						"type":BtnSwitch(16,false),"id":"BtnStepRun","position":"relative","x":0,"y":0,
						/*#{1IIS131RH0Codes*/
						OnCheck(checked){
							self.setStepRun(checked);
						}
						/*}#1IIS131RH0Codes*/
					},
					{
						"hash":"1IIS13KEA0",
						"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","margin":[0,10,0,3],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
						"text":"Step run","fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
					},
					{
						"hash":"1IIADUQTJ0",
						"type":BtnSwitch(16,false),"id":"BtnSlowMo","position":"relative","x":0,"y":0,
						/*#{1IIADUQTJ0Codes*/
						OnCheck(checked){
							self.setSlowMo(checked);
						}
						/*}#1IIADUQTJ0Codes*/
					},
					{
						"hash":"1IIADV7DT0",
						"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","margin":[0,10,0,3],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
						"text":"SlowMo","fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
					},
					{
						"hash":"1INIC7SFL0",
						"type":BtnIcon("front",28,0,appCfg.sharedAssets+"/settings.svg",null),"id":"BtnConfig","position":"relative","x":0,"y":0,"margin":[0,5,0,0],
						"OnClick":function(event){
							self.editConfig(this,event);
						},
					},
					{
						"hash":"1II69PTRE0",
						"type":BtnIcon("front",28,0,appCfg.sharedAssets+"/uirighthide.svg",null),"id":"BtnHideLog","position":"relative","x":0,"y":0,
						"tip":(($ln==="CN")?("隐藏日志"):("Hide logs")),
						"OnClick":function(event){
							self.hideLogs(this,event);
						},
					},
					{
						"hash":"1II69S5L70",
						"type":BtnIcon("front",28,0,appCfg.sharedAssets+"/uiright.svg",null),"id":"BtnShowLog","position":"relative","x":0,"y":0,
						"tip":(($ln==="CN")?("显示日志"):("Show logs")),
						"OnClick":function(event){
							self.showLogs(this,event);
						},
					}
				],
			}
		],
		/*#{1II4RB79B1ExtraCSS*/
		/*}#1II4RB79B1ExtraCSS*/
		faces:{
			"logs":{
				/*BoxLogs*/"#1II696I8U0":{
					"display":1
				},
				/*BtnHideLog*/"#1II69PTRE0":{
					"display":1
				},
				/*BtnShowLog*/"#1II69S5L70":{
					"display":0
				}
			},"!logs":{
				/*BoxLogs*/"#1II696I8U0":{
					"display":0
				},
				/*BtnHideLog*/"#1II69PTRE0":{
					"display":0
				},
				/*BtnShowLog*/"#1II69S5L70":{
					"display":1
				}
			},"online":{
				/*BtnStepRun*/"#1IIS131RH0":{
					"display":1
				},
				"#1IIS13KEA0":{
					"display":1
				},
				/*BtnSlowMo*/"#1IIADUQTJ0":{
					"display":1
				},
				"#1IIADV7DT0":{
					"display":1
				}
			},"offline":{
				/*BtnStepRun*/"#1IIS131RH0":{
					"display":1
				},
				"#1IIS13KEA0":{
					"display":1
				},
				/*BtnSlowMo*/"#1IIADUQTJ0":{
					"display":1
				},
				"#1IIADV7DT0":{
					"display":1
				}
			},"paused":{
				/*BoxPaused*/"#1IIS2LUKI0":{
					"display":1
				}
			},"!paused":{
				/*BoxPaused*/"#1IIS2LUKI0":{
					"display":0
				}
			}
		},
		OnCreate:function(){
			self=this;
			boxCanvas=self.BoxCanvas;boxLogs=self.BoxLogs;txtAgent=self.TxtAgent;btnStepRun=self.BtnStepRun;btnSlowMo=self.BtnSlowMo;
			/*#{1II4RB79B1Create*/
			let params;
			boxCanvas.zoom=boxCanvas.scale;
			app.uiInference=self;
			self.showFace("!logs");
			dragMeta=VFACT.applyMoveDrag(boxCanvas,null);
			
			params=app.appParams;
			if(params.slowMo){
				slowMo=true;
				app.setSlowMo(true);
				btnSlowMo.checked=true;
			}
			if(params.stepRun){
				app.setStepRun(true);
				btnStepRun.checked=true;
			}
			
			app.on("AIAgentExec",(agentJaxId,agent,input)=>{
				let log={
					type: "StartAgent",
					agent: agent?agent.jaxId:agentJaxId,
					name:agent.name,
					url:agent.url,
					input:input,
					frameId:agent.agentFrameId,
					sourceDef:agent.sourceDef
				};
				self.handleLog(log);
			});
			app.on("AIAgentEnd",(agentJaxId,agent,result)=>{
				let log={
					type: "EndAgent",
					agent: agent?agent.jaxId:agentJaxId,
					name:agent.name,
					url:agent.url,
					frameId:agent.agentFrameId,
					result:result
				};
				self.handleLog(log);
			});
			app.on("AISegExec",(agentJaxId,fromSegId,outletId,segJaxId,input,callId,seg)=>{
				let log={
					type: "StartSeg",
					agent: agentJaxId,
					jaxId:segJaxId,
					seg:seg,
					name:seg?seg.name:"seg",
					url:seg?seg.url:"",
					input:input,
					fromSeg:fromSegId,
					fromOutlet:outletId
				};
				self.handleLog(log);
			});
			app.on("AISegEnd",(seg)=>{
				let log={
					type: "EndSeg",
					seg:seg
				};
				self.handleLog(log);
			});
			app.on("AIDebugLog",(agentId,segId,log)=>{
				let applog={
					type: "DebugLog",
					agent:agentId,
					seg:segId,
					log:log
				};
				self.handleLog(applog);
			});
			app.on("AISegCatch",(agentId,frameId,error)=>{
				let applog={
					type: "CatchError",
					agent:agentId,
					frameId:frameId,
					error:error
				};
				self.handleLog(applog);
			});
			app.on("AISegCallLLMInput",(agentJaxId,segJaxId,prompt,callId,opts,messages)=>{
				let applog={
					type: "LlmCall",
					agent:agentJaxId,
					seg:segJaxId,
					code:prompt,
					options:opts,
					messages:messages
				};
				self.handleLog(applog);
			});
			app.on("AISegCallLLMResult",(agentJaxId,segJaxId,result,callId,tokenUsage,opts,messages)=>{
				let applog={
					type: "LlmResult",
					agent:agentJaxId,
					seg:segJaxId,
					options:opts,
					code:result,
					messages:messages,
					result:result
				};
				self.handleLog(applog);
			});
			app.on("AIStepRunOn",()=>{
				//TODO: Code this:
			});
			app.on("AIStepRunOff",()=>{
				//TODO: Code this:
			});
			app.on("AIExecPaused",()=>{
				self.showFace("paused");
			});
			app.on("AIExecResume",()=>{
				self.showFace("!paused");
			});
			/*}#1II4RB79B1Create*/
		},
		/*#{1II4RB79B1EndCSS*/
		/*}#1II4RB79B1EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.handleLog=async function(log){
		/*#{1IIOCQC7Q0Start*/
		switch(log.type){
			case "StartAgent":{
				let info;
				if(rootApp){
					rootApp.emit("AIAgentExec",log.agent);
				}
				self.canvasAni("addLog",[log],0);
				if(log.sourceDef){
					self.canvasAni("newFrame",[log],0);
				}
				self.canvasAni("addLog",[log],0);
				break;
			}
			case "EndAgent":{
				let info;
				if(rootApp){
					rootApp.emit("AIAgentEnd",log.agent);
				}
				self.canvasAni("addLog",[log],0);
				self.canvasAni("leaveAgent",[log.agent],0);
				self.canvasAni("addLog",[log],0);
				break;
			}
			case "StartSeg":{
				let seg,info;
				seg=log.seg;
				if(seg && seg.jaxId){
					if(rootApp){
						rootApp.emit("AISegExec",seg.agent,seg.fromSeg,seg.fromOutlet,seg.jaxId,seg.input,seg.id);
					}
					self.canvasAni("addLog",[log],0);
					self.canvasAni("focusSeg",[seg.agent,seg.jaxId,seg.fromSeg,seg.fromOutlet,log],200);
				}
				break;
			}
			case "EndSeg":{
				let seg,info;
				seg=log.seg;
				if(seg && seg.jaxId){
					self.canvasAni("addLog",[log],0);
					if(rootApp){
						rootApp.emit("AISegEnd",seg.agent,seg.jaxId,seg.result,seg.id);
					}
				}
				break;
			}
			case "CatchError":{
				self.canvasAni("catchError",[log],0);
				break;
			}
			case "LlmCall":{
				let options;
				options=log.options;
				//self.addLog(log); //this log is added with animation
				self.canvasAni("addLog",[log],0);
				if(rootApp){
					let seg;
					seg=log.seg;
					if(seg && seg.jaxId){
						let messages,text;
						text="OPTIONS-----------------------------\n";
						text+=JSON.stringify(log.options,null,"\t");
						text+="\n\nMESSAGES:------------------------------\n\nMESSAGE---------------------------\n\n";
						messages=log.messages.map(item=>(item.content||"NO-CONTENT"));
						text+=messages.join("\n\nMESSAGE---------------------------\n\n");
						rootApp.emit("AISegCallLLMInput",log.agent,seg.jaxId,text,log.callId);
					}
				}
				break;
			}
			case "LlmResult":{
				let options;
				options=log.options;
				//self.addLog(log); //this log is added with animation
				self.canvasAni("addLog",[log],0);
				//Emit app message
				if(rootApp){
					let seg;
					seg=log.seg;
					if(seg && seg.jaxId){
						rootApp.emit("AISegCallLLMResult",log.agent,seg.jaxId,log.result,log.callId);
					}
				}
				break;
			}
			case "DebugLog":{
				//Emit app message
				self.canvasAni("addLog",[log],0);
				if(rootApp){
					rootApp.emit("AIDebugLog",log.agent,log.seg,log.log);
				}
				break;
			}
		}
		/*}#1IIOCQC7Q0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.addLog=async function(log){
		/*#{1IIOBJIH30Start*/
		let topFrame;
		topFrame=frameStack[frameStack.length-1];
		if(topFrame){
			topFrame.addLog(log);
			if(topFrame===curFrame){
				self.showLog(log);
				self.scrollLogs();
			}
		}
		/*}#1IIOBJIH30Start*/
	};
	//------------------------------------------------------------------------
	cssVO.showLog=async function(log){
		/*#{1IIR3PTMS0Start*/
		switch(log.type){
			case "StartAgent":{
				let info,icon,css;
				icon=appCfg.sharedAssets+("/fat_down.svg");
				info=JSON.stringify(log.input)||"";
				css={
					type:InfoCard(`${log.name}: [${log.frameId}]`,info.substring(0,128),null,icon,24,24),position:"relative",x:0,y:0,w:"100%",
					border:1,sizeCap:14,sizeLabel:12,margin:[5,0,5,0],log:log
				};
				boxLogs.appendNewChild(css);
				break;
			}
			case "EndAgent":{
				let info,icon,css;
				icon=appCfg.sharedAssets+("/fat_up.svg");
				info=JSON.stringify(log.result)||"";
				css={
					type:InfoCard(log.name,info.substring(0,128),null,icon,24,24),position:"relative",x:0,y:0,w:"100%",
					border:1,sizeCap:14,sizeLabel:12,margin:[5,0,5,0],log:log
				};
				boxLogs.appendNewChild(css);
				break;
			}
			case "StartSeg":{
				let seg,info,icon,css;
				seg=log.seg;
				if(seg && seg.jaxId){
					icon=appCfg.sharedAssets+("/arrowright.svg");
					info=JSON.stringify(seg.input)||"";
					css={
						type:InfoCard(seg.name,info.substring(0,128),null,icon,24,24),position:"relative",x:0,y:0,w:"100%",
						border:1,sizeCap:14,sizeLabel:12,margin:[5,0,5,0],log:log,
						OnClick(){
							self.showAISegLog(log);
						}
					};
					boxLogs.appendNewChild(css);
				}
				break;
			}
			case "CatchError":{
				let jaxId,url,icon,info,css;
				jaxId=log.agent;
				icon=appCfg.sharedAssets+("/help.svg");
				info=log.error;
				css={
					type:InfoCard("Catched Error",info.substring(0,128),null,icon,24,24),position:"relative",x:0,y:0,w:"100%",
					border:1,sizeCap:14,sizeLabel:12,margin:[5,0,5,0],log:log,
					OnClick(){
					}
				};
				boxLogs.appendNewChild(css);
				break;
			}
			case "EndSeg":{
				let seg,info,icon,css;
				seg=log.seg;
				if(seg && seg.jaxId){
					icon=appCfg.sharedAssets+("/arrowleft.svg");
					info=JSON.stringify(seg.result)||"";
					css={
						type:InfoCard(seg.name,info.substring(0,128),null,icon,24,24),position:"relative",x:0,y:0,w:"100%",
						border:1,sizeCap:14,sizeLabel:12,margin:[5,0,5,0],log:log,
						OnClick(){
							self.showAISegLog(log);
						}
					};
					boxLogs.appendNewChild(css);
				}
				break;
			}
			case "LlmCall":{
				let options,icon,css;
				options=log.options;
				icon=appCfg.sharedAssets+("/aichat.svg");
				css={
					type:InfoCard(options.mode||options.model,log.code,null,icon,24,24),position:"relative",x:0,y:0,w:"100%",
					border:1,sizeCap:14,sizeLabel:12,margin:[5,0,5,0],log:log,
					OnClick(){
						self.showCallLLMLog(log);
					}
				};
				//Emit app message
				boxLogs.appendNewChild(css);
				break;
			}
			case "LlmResult":{
				let options,icon,css;
				options=log.options;
				icon=appCfg.sharedAssets+("/agent.svg");
				css={
					type:InfoCard(options.mode||options.model,log.code,null,icon,24,24),position:"relative",x:0,y:0,w:"100%",
					border:1,sizeCap:14,sizeLabel:12,margin:[5,0,5,0],log:log,
					OnClick(){
						self.showCallLLMLog(log);
					}
				};
				boxLogs.appendNewChild(css);
				break;
			}
			case "DebugLog":{
				let icon,css,info;
				icon=appCfg.sharedAssets+("/read.svg");
				info=JSON.stringify(log.log)||"";
				css={
					type:InfoCard("Log",info,null,icon,24,24),position:"relative",x:0,y:0,w:"100%",
					border:1,sizeCap:14,sizeLabel:12,margin:[5,0,5,0],log:log,
					OnClick(){
						self.showAIDebugLog(log);
						return false;
					}
				};
				boxLogs.appendNewChild(css);
				break;
			}
		}
		/*}#1IIR3PTMS0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.showLogs=function(){
		/*#{1II6D01F40Start*/
		/*}#1II6D01F40Start*/
		self.showFace("logs");
	};
	//------------------------------------------------------------------------
	cssVO.showFrameLogs=async function(){
		/*#{1IIR5JT4S0Start*/
		let logs,log;
		logs=curFrame.logs;
		self.clearLogs();
		for(log of logs){
			self.showLog(log);
			self.scrollLogs();
		}
		/*}#1IIR5JT4S0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.hideLogs=function(){
		/*#{1II6D062E0Start*/
		/*}#1II6D062E0Start*/
		self.showFace("!logs");
	};
	//------------------------------------------------------------------------
	cssVO.clearLogs=function(){
		/*#{1II6D2PS80Start*/
		boxLogs.clearChildren();
		/*}#1II6D2PS80Start*/
	};
	//------------------------------------------------------------------------
	cssVO.newFrame=async function(log){
		/*#{1IIMEJNUE0Start*/
		let jaxId,url,def,agent,newFrame,topFrame;
		jaxId=log.agent;
		url=log.url;
		def=log.sourceDef;
		agent=agents.get(jaxId);
		if(curFrame){
			curFrame.leave();
			dragMeta.setTarget(null);
			curFrame=null;
		}
		if(!agent){
			if(!def){
				return false;
			}
			agent=new ViDoc(url,def);
			agents.set(jaxId,agent);
		}
		topFrame=frameStack[frameStack.length-1];
		newFrame=new ViFrame(topFrame||curFrame,agent,log);
		newFrame.enter(boxCanvas);
		txtAgent.text=agent.name;
		frameStack.push(newFrame);
		allFrames.push(newFrame);
		curFrame=newFrame;
		dragMeta.setTarget(curFrame.agent.hudObj);
		self.clearLogs();
		return true;
		/*}#1IIMEJNUE0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.enterFrame=function(frame){
		/*#{1II6FR05C0Start*/
		let agent;
		agent=frame.agent;
		if(curFrame && curFrame!==frame){
			curFrame.leave();
			curFrame=null;
		}
		txtAgent.text=agent.name;
		frame.enter(boxCanvas);
		curFrame=frame;
		dragMeta.setTarget(curFrame.agent.hudObj);
		self.showFrameLogs();
		/*}#1II6FR05C0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.leaveAgent=function(jaxId){
		/*#{1II7S0C3A0Start*/
		let topFrame,topAgent;
		topFrame=frameStack[frameStack.length-1];
		if(!topFrame){
			return;
		}
		topAgent=topFrame.agent;
		if(topAgent.jaxId===jaxId){
			topFrame.end();
			frameStack.pop();
			if(curFrame===topFrame){
				curFrame=null;
				topFrame=frameStack[frameStack.length-1];
				if(topFrame){
					self.enterFrame(topFrame);
				}else{
					txtAgent.text=(($ln==="CN")?("暂无智能体调试帧"):("No agent frames"));
				}
			}
		}
		/*}#1II7S0C3A0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.focusSeg=function(agent,seg,fromSeg,fromOutlet,log){
		/*#{1II78NFSF0Start*/
		let topFrame;
		topFrame=frameStack[frameStack.length-1];
		if(agent && seg && topFrame){
			if(topFrame.jaxId===agent){
				topFrame.showSeg(seg,fromSeg,fromOutlet,slowMo);
			}else{
				//TODO: find handle frame:
			}
		}
		/*}#1II78NFSF0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.catchError=async function(log){
		/*#{1IJJALUO10Start*/
		let topFrame,agentJaxId,agentUrl,frameId,error,frame,i,n,j;
		topFrame=frameStack[frameStack.length-1];
		agentJaxId=log.agent;
		agentUrl=log.url;
		frameId=log.frameId;
		error=log.error;
		if(topFrame.jaxId!==agentJaxId){
			n=frameStack.length;
			for(i=0;i<n;i++){
				frame=frameStack[i];
				if(frame.agentJaxId===agentJaxId && frame.frameId===frameId){
					let poped;
					for(j=i+1;j<n;j++){
						poped=frameStack[j];
						poped.end(error);
						poped.leave();
					}
					frameStack.splice(i+1);
					self.enterFrame(frame);
					return;
				}
			}
			console.error(`Can't find error-catch frame: ${agentUrl} with frame-id: ${frameId}`);
		}
		/*}#1IJJALUO10Start*/
	};
	//------------------------------------------------------------------------
	cssVO.showCanvas=async function(){
		/*#{1II6NO2FH0Start*/
		if(curFrame){
			curFrame.render(boxCanvas);
		}
		/*}#1II6NO2FH0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.canvasAni=async function(action,args,time){
		/*#{1II7JI1OS0Start*/
		function callAni(action,args,time){
			aniPlaying=true;
			self[action].call(self,...args);
			setTimeout(()=>{
				let ani;
				ani=anis.shift();
				if(ani){
					time=ani.time;
					if(anis.length>2){
						time=50;
					}
					time=self.display?time:0;
					callAni(ani.action,ani.args,time);
				}else{
					aniPlaying=false;
				}
			},time);
		}
		if(aniPlaying){
			anis.push({action:action,args:args,time:self.display?time:0});
		}else{
			callAni(action,args,time);
		}
		/*}#1II7JI1OS0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.showFrames=async function(sender){
		/*#{1II7S96CP0Start*/
		let items,item;
		if(!frameStack.length && allFrames.length){
			return await self.showAllFrames(sender);
		}
		items=frameStack.map((frame)=>{
			return {text:frame.name,frame:frame};
		});
		items.push("_");
		items.push({text:(($ln==="CN")?("全部调试帧"):/*EN*/("All frames")),frame:null});
		item=await app.modalDlg("/@StdUI/ui/DlgMenu.js",{
			hud:sender,items:items
		});
		if(item){
			if(item.frame){
				self.enterFrame(item.frame);
			}else{
				await self.showAllFrames(sender);
			}
		}
		/*}#1II7S96CP0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.showAllFrames=async function(sender){
		/*#{1IJBGC9NI0Start*/
		let items,item;
		items=allFrames.map((frame)=>{
			let prefix;
			prefix="→".repeat(frame.deep);
			return {text:prefix+(frame.finished?"[END]"+frame.name:frame.name),frame:frame};
		});
		item=await app.modalDlg("/@StdUI/ui/DlgMenu.js",{
			hud:sender,items:items
		});
		if(item){
			self.enterFrame(item.frame);
		}
		/*}#1IJBGC9NI0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.setSlowMo=async function(enable){
		/*#{1IIAE3GMN0Start*/
		app.setSlowMo(enable);
		if(ws){
			ws.send(JSON.stringify({cmd:"SlowMo",enable:enable}));
		}
		slowMo=enable;
		/*}#1IIAE3GMN0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.setStepRun=async function(enable){
		/*#{1IIS17LMV0Start*/
		app.setStepRun(enable);
		/*}#1IIS17LMV0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.resumeRun=async function(sender,event){
		/*#{1IIS39J0R0Start*/
		app.resumeAIRun();
		/*}#1IIS39J0R0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.editConfig=async function(){
		/*#{1INIC9PDF0Start*/
		app.editConfig();
		/*}#1INIC9PDF0Start*/
	};
	/*#{1II4RB79B1PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.showCallLLMLog=async function(log){
		/*#{1IEP2QO7G0Start*/
		let opts,messages,result;
		let codes,msg;
		opts=log.options;
		messages=log.messages;
		codes="[LLM-call options]\n";
		codes+=JSON.stringify(opts,null,"\t");codes+="\n\n";
		codes+="[LLM-call Messages]\n";
		for(msg of messages){
			codes+=`<${msg.role}>\n`;
			codes+=msg.content+"\n";
			if(msg.image){
				codes+="[Image]\n"
			}
			codes+="\n"
		}
		result=log.result;
		if(result){
			codes+="\n[LLM-call result]\n"
			codes+=log.result;
		}
		//Show dlg:
		await app.modalDlg("/@StdUI/ui/DlgLLMCall.js",{title:"Call LLM",log:log});
		//await app.modalDlg("/@editkit/ui/DlgLongText.js",{title:"LLM Call Log",text:codes});
		/*}#1IEP2QO7G0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.showAISegLog=async function(log){
		/*#{1IEP2RAUM0Start*/
		let codes,seg;
		seg=log.seg;
		codes=`[AISeg]:\n${seg.url}\n`;
		if(seg.input){
			codes+=`[Input]\n`;
			codes+=JSON.stringify(seg.input,null,"\t")+"\n";
		}
		if(seg.result){
			codes+=`[Result]\n`;
			codes+=JSON.stringify(seg.result,null,"\t")+"\n";
		}
		//Show dlg:
		await app.modalDlg("/@editkit/ui/DlgLongText.js",{title:"Run AI-Seg",text:codes});
		/*}#1IEP2RAUM0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.showAIDebugLog=async function(log){
		let codes,seg;
		codes=`[Log]\n`;
		if(typeof(log.log)==="string"){
			codes+=log.log;
		}else{
			codes+=JSON.stringify(log.log,null,"\t")+"\n";
		}
		await app.modalDlg("/@editkit/ui/DlgLongText.js",{title:"Run AI-Seg",text:codes});
	};
	//------------------------------------------------------------------------
	cssVO.scrollLogs=function(){
		/*#{1IEP7HRCB0Start*/
		let webObj;
		webObj=boxLogs.webObj;
		webObj.scrollTop = webObj.scrollHeight;		
		/*}#1IEP7HRCB0Start*/
	};
	/*}#1II4RB79B1PostCSSVO*/
	cssVO.constructor=TBXInference;
	return cssVO;
};
/*#{1II4RB79B1ExCodes*/
/*}#1II4RB79B1ExCodes*/

//----------------------------------------------------------------------------
TBXInference.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1II4RB79B1PreAISpot*/
	/*}#1II4RB79B1PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1II4RB79B1PostAISpot*/
	/*}#1II4RB79B1PostAISpot*/
	return exposeVO;
};

//----------------------------------------------------------------------------
TBXInference.gearExport={
	framework: "jax",
	hudType: "hud",
	"showName":"",icon:"gears.svg",previewImg:false,
	fixPose:false,initW:100,initH:100,
	catalog:"",
	args: {},
	state:{
	},
	properties:["id","position","x","y","display"],
	faces:["logs","!logs","online","offline","paused","!paused"],
	subContainers:{
	},
	/*#{1II4RB79B0ExGearInfo*/
	/*}#1II4RB79B0ExGearInfo*/
};
/*#{1II4RB79B0EndDoc*/
/*}#1II4RB79B0EndDoc*/

export default TBXInference;
export{TBXInference};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1II4RB79B0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1II4RB79B2",
//			"attrs": {
//				"device": "Desktop 800x600",
//				"screenW": "800",
//				"screenH": "600",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1II4RB79B3",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1II4RB79B4",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1II4RB79B5",
//			"attrs": {}
//		},
//		"localVars": {
//			"jaxId": "1II4RB79B6",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1II4RB79B7",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IIOCQC7Q0",
//					"attrs": {
//						"id": "handleLog",
//						"label": "New AI Seg",
//						"x": "80",
//						"y": "635",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IIOCR10U0",
//							"attrs": {
//								"log": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IIOCR10U1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IIOCR10U2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IIOBJIH30",
//					"attrs": {
//						"id": "addLog",
//						"label": "New AI Seg",
//						"x": "315",
//						"y": "635",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IIOBKA9T0",
//							"attrs": {
//								"log": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IIOBKA9T1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IIOBKA9T2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IIR3PTMS0",
//					"attrs": {
//						"id": "showLog",
//						"label": "New AI Seg",
//						"x": "535",
//						"y": "635",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IIR3S4FO0",
//							"attrs": {
//								"log": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IIR3S4FO1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IIR3S4FO2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1II6D01F40",
//					"attrs": {
//						"id": "showLogs",
//						"label": "New AI Seg",
//						"x": "80",
//						"y": "85",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1II6D10O60",
//							"attrs": {}
//						},
//						"async": "false",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1II6D10O61",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": [
//								{
//									"type": "flowseg",
//									"def": "SetFace",
//									"jaxId": "1II6D10O62",
//									"attrs": {
//										"id": "SetFace",
//										"label": "New AI Seg",
//										"x": "305",
//										"y": "85",
//										"desc": "",
//										"codes": "false",
//										"component": "self",
//										"face": "logs",
//										"outlet": {
//											"jaxId": "1II6D10O63",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											}
//										}
//									},
//									"icon": "faces.svg"
//								}
//							]
//						},
//						"outlet": {
//							"jaxId": "1II6D10O64",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1II6D10O62"
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IIR5JT4S0",
//					"attrs": {
//						"id": "showFrameLogs",
//						"label": "New AI Seg",
//						"x": "740",
//						"y": "635",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IIR5K9CV0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IIR5K9CV1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IIR5K9CV2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1II6D062E0",
//					"attrs": {
//						"id": "hideLogs",
//						"label": "New AI Seg",
//						"x": "80",
//						"y": "180",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1II6D10O65",
//							"attrs": {}
//						},
//						"async": "false",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1II6D10O66",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": [
//								{
//									"type": "flowseg",
//									"def": "SetFace",
//									"jaxId": "1II6D10O67",
//									"attrs": {
//										"id": "SeetFace",
//										"label": "New AI Seg",
//										"x": "305",
//										"y": "180",
//										"desc": "",
//										"codes": "false",
//										"component": "self",
//										"face": "!logs",
//										"outlet": {
//											"jaxId": "1II6D10O68",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											}
//										}
//									},
//									"icon": "faces.svg"
//								}
//							]
//						},
//						"outlet": {
//							"jaxId": "1II6D10O69",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1II6D10O67"
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1II6D2PS80",
//					"attrs": {
//						"id": "clearLogs",
//						"label": "New AI Seg",
//						"x": "80",
//						"y": "275",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1II6D3GPC0",
//							"attrs": {}
//						},
//						"async": "false",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1II6D3GPC1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1II6D3GPC2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IIMEJNUE0",
//					"attrs": {
//						"id": "newFrame",
//						"label": "New AI Seg",
//						"x": "80",
//						"y": "375",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IIMEKPD50",
//							"attrs": {
//								"log": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IIMEKPD51",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IIMEKPD52",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1II6FR05C0",
//					"attrs": {
//						"id": "enterFrame",
//						"label": "New AI Seg",
//						"x": "315",
//						"y": "375",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1II6FRHBJ0",
//							"attrs": {
//								"frame": {
//									"type": "string",
//									"valText": ""
//								}
//							}
//						},
//						"async": "false",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1II6FRHBJ1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1II6FRHBJ2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1II7S0C3A0",
//					"attrs": {
//						"id": "leaveAgent",
//						"label": "New AI Seg",
//						"x": "535",
//						"y": "375",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1II7S0VOO0",
//							"attrs": {
//								"jaxId": {
//									"type": "string",
//									"valText": ""
//								}
//							}
//						},
//						"async": "false",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1II7S0VOO1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1II7S0VOO2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1II78NFSF0",
//					"attrs": {
//						"id": "focusSeg",
//						"label": "New AI Seg",
//						"x": "80",
//						"y": "455",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1II78P72F0",
//							"attrs": {
//								"agent": {
//									"type": "string",
//									"valText": ""
//								},
//								"seg": {
//									"type": "string",
//									"valText": ""
//								},
//								"fromSeg": {
//									"type": "auto",
//									"valText": ""
//								},
//								"fromOutlet": {
//									"type": "auto",
//									"valText": ""
//								},
//								"log": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "false",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1II78P72F1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1II78P72F2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IJJALUO10",
//					"attrs": {
//						"id": "catchError",
//						"label": "New AI Seg",
//						"x": "755",
//						"y": "375",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IJJANF7A0",
//							"attrs": {
//								"log": {
//									"type": "string",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IJJANF7A1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IJJANF7A2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1II6NO2FH0",
//					"attrs": {
//						"id": "showCanvas",
//						"label": "New AI Seg",
//						"x": "80",
//						"y": "550",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1II6NOBVP0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1II6NOBVP1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1II6NOBVP2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1II7JI1OS0",
//					"attrs": {
//						"id": "canvasAni",
//						"label": "New AI Seg",
//						"x": "315",
//						"y": "455",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1II7JJN5T0",
//							"attrs": {
//								"action": {
//									"type": "string",
//									"valText": ""
//								},
//								"args": {
//									"type": "auto",
//									"valText": ""
//								},
//								"time": {
//									"type": "int",
//									"valText": "0"
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1II7JJN5T1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1II7JJN5T2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1II7S96CP0",
//					"attrs": {
//						"id": "showFrames",
//						"label": "New AI Seg",
//						"x": "315",
//						"y": "275",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1II7SA20S0",
//							"attrs": {
//								"sender": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1II7SA20S1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1II7SA20S2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IJBGC9NI0",
//					"attrs": {
//						"id": "showAllFrames",
//						"label": "New AI Seg",
//						"x": "535",
//						"y": "275",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IJBGCO8A0",
//							"attrs": {
//								"sender": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IJBGCO8A1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IJBGCO8A2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IIAE3GMN0",
//					"attrs": {
//						"id": "setSlowMo",
//						"label": "New AI Seg",
//						"x": "80",
//						"y": "725",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IIAE4GQ10",
//							"attrs": {
//								"enable": {
//									"type": "bool",
//									"valText": "false"
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IIAE4GQ11",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IIAE4GQ12",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IIS17LMV0",
//					"attrs": {
//						"id": "setStepRun",
//						"label": "New AI Seg",
//						"x": "315",
//						"y": "725",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IIS17SQG0",
//							"attrs": {
//								"enable": {
//									"type": "bool",
//									"valText": "false"
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IIS17SQG1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IIS17SQG2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IIS39J0R0",
//					"attrs": {
//						"id": "resumeRun",
//						"label": "New AI Seg",
//						"x": "535",
//						"y": "725",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IIS3B1RA0",
//							"attrs": {
//								"sender": {
//									"valText": "null"
//								},
//								"event": {
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IIS3B1RA1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IIS3B1RA2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1INIC9PDF0",
//					"attrs": {
//						"id": "editConfig",
//						"label": "New AI Seg",
//						"x": "80",
//						"y": "800",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1INICA5MC0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1INICA5MC1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1INICA5MC2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				}
//			]
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1II4RB79B8",
//			"attrs": {
//				"logs": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1II6A4LI60",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1II6A5NGQ0",
//							"attrs": {}
//						}
//					}
//				},
//				"!logs": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1II6A4RL40",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1II6A5NGQ1",
//							"attrs": {}
//						}
//					}
//				},
//				"online": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1II7ROS070",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1II7RPGMT0",
//							"attrs": {}
//						}
//					}
//				},
//				"offline": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1II7RP0KJ0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1II7RPGMT1",
//							"attrs": {}
//						}
//					}
//				},
//				"paused": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IIS33KNG0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IIS345T20",
//							"attrs": {}
//						}
//					}
//				},
//				"!paused": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IIS33RKA0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IIS345T21",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1II4RB79B9",
//			"attrs": {}
//		},
//		"exposeToAI": "true",
//		"descAI": "",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1II4RB79B1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1II4RB79B10",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "100%",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "On",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": ""
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1II693S5F0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1II695OG20",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxView",
//										"position": "Absolute",
//										"x": "2",
//										"y": "30",
//										"w": "100%",
//										"h": "100%-30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": ""
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1II6ARL530",
//											"attrs": {
//												"properties": {
//													"jaxId": "1II6AUF240",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxCanvas",
//														"position": "Absolute",
//														"x": "0",
//														"y": "0",
//														"w": "125%",
//														"h": "125%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "0.8",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": ""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1II6AUF241",
//													"attrs": {
//														"1II6A4LI60": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1II6D6B3J2",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1II6D6B3J3",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II6A4LI60",
//															"faceTagName": "logs"
//														},
//														"1II7RP0KJ0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IIPIIQ0O0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IIPIIQ0O1",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II7RP0KJ0",
//															"faceTagName": "offline"
//														},
//														"1IIS33RKA0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IIS345T214",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IIS345T215",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IIS33RKA0",
//															"faceTagName": "!paused"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1II6AUF242",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1II6AUF243",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "true",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1IIS2LUKI0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IIS2VM1H0",
//													"attrs": {
//														"type": "box",
//														"id": "BoxPaused",
//														"position": "Absolute",
//														"x": "20",
//														"y": "20",
//														"w": "",
//														"h": "60",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "Off",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "10",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "#cfgColor[\"body\"]",
//														"border": "2",
//														"borderStyle": "Solid",
//														"borderColor": "#cfgColor[\"fontBody\"]",
//														"corner": "6",
//														"shadow": "true",
//														"shadowX": "4",
//														"shadowY": "6",
//														"shadowBlur": "6",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.25]",
//														"contentLayout": "Flex X",
//														"itemsAlign": "Center"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1IIS2R7H40",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IIS2VM1H1",
//																	"attrs": {
//																		"type": "text",
//																		"id": "",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[0,10,0,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontBody\"]",
//																		"text": {
//																			"type": "string",
//																			"valText": "Paused",
//																			"localize": {
//																				"EN": "Paused",
//																				"CN": "已暂停"
//																			},
//																			"localizable": true
//																		},
//																		"font": "",
//																		"fontSize": "#txtSize.big",
//																		"bold": "true",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Top",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"lineClamp": "0",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IIS2VM1H2",
//																	"attrs": {
//																		"1IIS33RKA0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IIS345T22",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IIS345T23",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IIS33RKA0",
//																			"faceTagName": "!paused"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1IIS2VM1H3",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1IIS2VM1H4",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1IIS2U1MB0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1IIS2VM1H5",
//																	"attrs": {
//																		"style": "\"front\"",
//																		"w": "36",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/run.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1IIS2VM1H6",
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"front\",36,0,appCfg.sharedAssets+\"/run.svg\",null)",
//																		"id": "BtnRunStep",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IIS2VM1H7",
//																	"attrs": {
//																		"1IIS33RKA0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IIS345T26",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IIS345T27",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IIS33RKA0",
//																			"faceTagName": "!paused"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1IIS2VM1H8",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1IIS3B1RB0",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1IIS3B1RB1",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": "1IIS39J0R0"
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1IIS2VM1H9",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1IIS2VM1H10",
//																	"attrs": {}
//																}
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1IIS2VM1H11",
//													"attrs": {
//														"1IIS33RKA0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IIS345T210",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IIS345T211",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IIS33RKA0",
//															"faceTagName": "!paused"
//														},
//														"1IIS33KNG0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IIS345T212",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IIS345T213",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IIS33KNG0",
//															"faceTagName": "paused"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IIS2VM1H12",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IIS2VM1H13",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1II696I8U0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1II69BRL30",
//													"attrs": {
//														"type": "box",
//														"id": "BoxLogs",
//														"position": "Absolute",
//														"x": "100%-300",
//														"y": "0",
//														"w": "300",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Auto Scroll Y",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "[5,5,50,5]",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "#cfgColor[\"body\"]",
//														"border": "[0,0,0,1]",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"shadow": "true",
//														"shadowX": "-2",
//														"shadowY": "0",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.20]"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1II69BRL31",
//													"attrs": {
//														"1II6A4LI60": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1II6A5NGQ4",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1II6A5NGQ5",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II6A4LI60",
//															"faceTagName": "logs"
//														},
//														"1II6A4RL40": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1II6A6LK50",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1II6A6LK51",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II6A4RL40",
//															"faceTagName": "!logs"
//														},
//														"1II7RP0KJ0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IIPIIQ0O2",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IIPIIQ0O3",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II7RP0KJ0",
//															"faceTagName": "offline"
//														},
//														"1IIS33RKA0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IIS345T218",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IIS345T219",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IIS33RKA0",
//															"faceTagName": "!paused"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1II69BRL32",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1II69BRL33",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "true"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1II695OG21",
//									"attrs": {
//										"1II6A4LI60": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1II6A5NGR2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1II6A5NGR3",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1II6A4LI60",
//											"faceTagName": "logs"
//										},
//										"1II7RP0KJ0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IIPIIQ0O4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IIPIIQ0O5",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1II7RP0KJ0",
//											"faceTagName": "offline"
//										},
//										"1IIS33RKA0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IIS345T222",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IIS345T223",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IIS33RKA0",
//											"faceTagName": "!paused"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1II695OG22",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1II695OG23",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1II690HL30",
//							"attrs": {
//								"properties": {
//									"jaxId": "1II691FGJ0",
//									"attrs": {
//										"type": "box",
//										"id": "BoxHeader",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "[0,5,0,5]",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"body\"]",
//										"border": "[0,0,1,0]",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"contentLayout": "Flex X",
//										"itemsAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1II7RNLS00",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1II7RNLS01",
//													"attrs": {
//														"style": "\"front\"",
//														"w": "24",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/btncombo.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1II7RNLS02",
//													"attrs": {
//														"type": "#null#>BtnIcon(\"front\",24,0,appCfg.sharedAssets+\"/btncombo.svg\",null)",
//														"id": "BtnShowFrames",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"enable": "true"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1II7RNLS03",
//													"attrs": {
//														"1II6A4LI60": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1II7RNLS04",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1II7RNLS05",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II6A4LI60",
//															"faceTagName": "logs"
//														},
//														"1II7RP0KJ0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1II7RPGMT8",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1II7RPGMT9",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II7RP0KJ0",
//															"faceTagName": "offline"
//														},
//														"1IIS33RKA0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IIS345T226",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IIS345T227",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IIS33RKA0",
//															"faceTagName": "!paused"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1II7RNLS12",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1II7RNLS13",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1II7RNLS14",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": "1II7S96CP0"
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1II7RNLS15",
//													"attrs": {
//														"tip": {
//															"type": "string",
//															"valText": "Agent call frames",
//															"localize": {
//																"EN": "Agent call frames",
//																"CN": "智能体调用帧"
//															},
//															"localizable": true
//														}
//													}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1II7RNLS16",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1II69BUVM0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1II69CRVU0",
//													"attrs": {
//														"type": "text",
//														"id": "TxtAgent",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBody\"]",
//														"text": {
//															"type": "string",
//															"valText": "No agent frames",
//															"localize": {
//																"EN": "No agent frames",
//																"CN": "暂无智能体调试帧"
//															},
//															"localizable": true
//														},
//														"font": "",
//														"fontSize": "#txtSize.smallPlus",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0",
//														"flex": "true"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1II69CRVU1",
//													"attrs": {
//														"1II6A4LI60": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1II6A5NGR6",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1II6A5NGR7",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II6A4LI60",
//															"faceTagName": "logs"
//														},
//														"1II7RP0KJ0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IIPIIQ0P0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IIPIIQ0P1",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II7RP0KJ0",
//															"faceTagName": "offline"
//														},
//														"1IIS33RKA0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IIS345T230",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IIS345T231",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IIS33RKA0",
//															"faceTagName": "!paused"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1II69CRVU2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1II69CRVU3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnSwitch.js",
//											"jaxId": "1IIS131RH0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1IIS131RH1",
//													"attrs": {
//														"size": "16",
//														"check": "false"
//													}
//												},
//												"properties": {
//													"jaxId": "1IIS131RH2",
//													"attrs": {
//														"type": "#null#>BtnSwitch(16,false)",
//														"id": "BtnStepRun",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": ""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IIS131RH3",
//													"attrs": {
//														"1II7RP0KJ0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IIS131RH4",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IIS131RH5",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II7RP0KJ0",
//															"faceTagName": "offline"
//														},
//														"1II7ROS070": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IIS131RH6",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IIS131RH7",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II7ROS070",
//															"faceTagName": "online"
//														},
//														"1IIS33RKA0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IIS345T234",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IIS345T235",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IIS33RKA0",
//															"faceTagName": "!paused"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IIS131RH8",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IIS131RH9",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "true",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1IIS131RH10",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1IIS13KEA0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IIS13KEA1",
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[0,10,0,3]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBody\"]",
//														"text": "Step run",
//														"font": "",
//														"fontSize": "#txtSize.small",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IIS13KEB0",
//													"attrs": {
//														"1II7RP0KJ0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IIS13KEB1",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IIS13KEB2",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II7RP0KJ0",
//															"faceTagName": "offline"
//														},
//														"1II7ROS070": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IIS13KEB3",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IIS13KEB4",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II7ROS070",
//															"faceTagName": "online"
//														},
//														"1IIS33RKA0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IIS345T32",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IIS345T33",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IIS33RKA0",
//															"faceTagName": "!paused"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IIS13KEB5",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IIS13KEB6",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnSwitch.js",
//											"jaxId": "1IIADUQTJ0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1IIAE0QVM0",
//													"attrs": {
//														"size": "16",
//														"check": "false"
//													}
//												},
//												"properties": {
//													"jaxId": "1IIAE0QVM1",
//													"attrs": {
//														"type": "#null#>BtnSwitch(16,false)",
//														"id": "BtnSlowMo",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": ""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IIAE0QVM2",
//													"attrs": {
//														"1II7RP0KJ0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IIAE2J1L8",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IIAE2J1L9",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II7RP0KJ0",
//															"faceTagName": "offline"
//														},
//														"1II7ROS070": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IIAE2J1L10",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IIAE2J1L11",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II7ROS070",
//															"faceTagName": "online"
//														},
//														"1IIS33RKA0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IIS345T36",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IIS345T37",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IIS33RKA0",
//															"faceTagName": "!paused"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IIAE0QVM3",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IIAE0QVM4",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "true",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1IIAE0QVM5",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1IIADV7DT0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IIAE0QVM6",
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[0,10,0,3]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBody\"]",
//														"text": "SlowMo",
//														"font": "",
//														"fontSize": "#txtSize.small",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IIAE0QVM7",
//													"attrs": {
//														"1II7RP0KJ0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IIAE2J1L12",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IIAE2J1L13",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II7RP0KJ0",
//															"faceTagName": "offline"
//														},
//														"1II7ROS070": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IIAE2J1L14",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IIAE2J1L15",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II7ROS070",
//															"faceTagName": "online"
//														},
//														"1IIS33RKA0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IIS345T310",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IIS345T311",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IIS33RKA0",
//															"faceTagName": "!paused"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IIAE0QVM8",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IIAE0QVM9",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1INIC7SFL0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1INIC980Q0",
//													"attrs": {
//														"style": "\"front\"",
//														"w": "28",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/settings.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1INIC980Q1",
//													"attrs": {
//														"type": "#null#>BtnIcon(\"front\",28,0,appCfg.sharedAssets+\"/settings.svg\",null)",
//														"id": "BtnConfig",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"margin": "[0,5,0,0]"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1INIC980Q2",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1INIC980Q3",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1INICREPU0",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1INICREPU1",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": "1INIC9PDF0"
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1INIC980Q4",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1INIC980Q5",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1II69PTRE0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1II69S17C0",
//													"attrs": {
//														"style": "\"front\"",
//														"w": "28",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/uirighthide.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1II69S17C1",
//													"attrs": {
//														"type": "#null#>BtnIcon(\"front\",28,0,appCfg.sharedAssets+\"/uirighthide.svg\",null)",
//														"id": "BtnHideLog",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": ""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1II69S17C2",
//													"attrs": {
//														"1II6A4LI60": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1II6A5NGR10",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1II6A5NGR11",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II6A4LI60",
//															"faceTagName": "logs"
//														},
//														"1II6A4RL40": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1II6A6LK64",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1II6A6LK65",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II6A4RL40",
//															"faceTagName": "!logs"
//														},
//														"1II7RP0KJ0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IIPIIQ0P4",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IIPIIQ0P5",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II7RP0KJ0",
//															"faceTagName": "offline"
//														},
//														"1IIS33RKA0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IIS345T314",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IIS345T315",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IIS33RKA0",
//															"faceTagName": "!paused"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1II69S17C3",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1II6D1EAI0",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1II6D1EAI1",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": "1II6D062E0"
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1II69S17C4",
//													"attrs": {
//														"tip": {
//															"type": "string",
//															"valText": "Hide logs",
//															"localize": {
//																"EN": "Hide logs",
//																"CN": "隐藏日志"
//															},
//															"localizable": true
//														}
//													}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1II69S17C5",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1II69S5L70",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1II69S5L71",
//													"attrs": {
//														"style": "\"front\"",
//														"w": "28",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/uiright.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1II69S5L80",
//													"attrs": {
//														"type": "#null#>BtnIcon(\"front\",28,0,appCfg.sharedAssets+\"/uiright.svg\",null)",
//														"id": "BtnShowLog",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": ""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1II69S5L81",
//													"attrs": {
//														"1II6A4LI60": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1II6A5NGR14",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1II6A5NGR15",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II6A4LI60",
//															"faceTagName": "logs"
//														},
//														"1II6A4RL40": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1II6D6B3J8",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1II6D6B3J9",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II6A4RL40",
//															"faceTagName": "!logs"
//														},
//														"1II7RP0KJ0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IIPIIQ0P6",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IIPIIQ0P7",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II7RP0KJ0",
//															"faceTagName": "offline"
//														},
//														"1IIS33RKA0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IIS345T318",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IIS345T319",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IIS33RKA0",
//															"faceTagName": "!paused"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1II69S5L82",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1II6D1EAI2",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1II6D1EAI3",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": "1II6D01F40"
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1II69S5L83",
//													"attrs": {
//														"tip": {
//															"type": "string",
//															"valText": "Show logs",
//															"localize": {
//																"EN": "Show logs",
//																"CN": "显示日志"
//															},
//															"localizable": true
//														}
//													}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1II69S5L84",
//													"attrs": {}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1II691FGJ1",
//									"attrs": {
//										"1II6A4LI60": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1II6A5NGR18",
//											"attrs": {
//												"properties": {
//													"jaxId": "1II6A5NGR19",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1II6A4LI60",
//											"faceTagName": "logs"
//										},
//										"1II7RP0KJ0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IIPIIQ0P8",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IIPIIQ0P9",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1II7RP0KJ0",
//											"faceTagName": "offline"
//										},
//										"1IIS33RKA0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IIS345T322",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IIS345T323",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IIS33RKA0",
//											"faceTagName": "!paused"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1II691FGJ2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1II691FGJ3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1II4RB79B11",
//					"attrs": {
//						"1II6A4LI60": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1II6A5NGR22",
//							"attrs": {
//								"properties": {
//									"jaxId": "1II6A5NGR23",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1II6A4LI60",
//							"faceTagName": "logs"
//						},
//						"1II7RP0KJ0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1IIPIIQ0P10",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IIPIIQ0P11",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1II7RP0KJ0",
//							"faceTagName": "offline"
//						},
//						"1IIS33RKA0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1IIS345T326",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IIS345T327",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1IIS33RKA0",
//							"faceTagName": "!paused"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1II4RB79B12",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1II4RB79B13",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1II4RB79B14",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}