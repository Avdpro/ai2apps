//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {NoteCard} from "./NoteCard.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
/*#{1IHUIJFMD0StartDoc*/
import {tabNT} from "/@tabos";
/*}#1IHUIJFMD0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let TBXNotes=function(){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let boxNotes;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1IHUIJFMD1LocalVals*/
	const app=VFACT.app;
	let envInfo=null;
	let projectMeta=null;
	/*}#1IHUIJFMD1LocalVals*/
	
	/*#{1IHUIJFMD1PreState*/
	/*}#1IHUIJFMD1PreState*/
	/*#{1IHUIJFMD1PostState*/
	/*}#1IHUIJFMD1PostState*/
	cssVO={
		"hash":"1IHUIJFMD1",nameHost:true,
		"type":"hud","x":0,"y":0,"w":"100%","h":"100%","padding":10,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
		children:[
			{
				"hash":"1IHUIRRCM0",
				"type":"hud","id":"BoxNotes","x":0,"y":30,"w":"100%","h":">calc(100% - 30px)","overflow":"auto","padding":10,"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","contentLayout":"flex-y",
				children:[
				],
			},
			{
				"hash":"1IHUITSK70",
				"type":"text","id":"TxtEmpty","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodyLit"],
				"text":(($ln==="CN")?("暂时没有笔记"):("No notes at the moment")),"fontSize":txtSize.midPlus,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
				"alignH":1,"alignV":1,
			},
			{
				"hash":"1IIA09FBK0",
				"type":"box","id":"BoxHeader","x":0,"y":0,"w":"100%","h":30,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":[255,255,255,1],"border":[0,0,1,0],
				"contentLayout":"flex-x","itemsAlign":1,
				children:[
					{
						"hash":"1IIA0C0VB0",
						"type":BtnIcon("front",28,0,appCfg.sharedAssets+"/additem.svg",null),"id":"BtnNewNote","position":"relative","x":0,"y":0,
						"OnClick":function(event){
							self.newNote(this,event);
						},
					}
				],
			}
		],
		/*#{1IHUIJFMD1ExtraCSS*/
		/*}#1IHUIJFMD1ExtraCSS*/
		faces:{
			"empty":{
				/*BoxNotes*/"#1IHUIRRCM0":{
					"display":0
				},
				/*TxtEmpty*/"#1IHUITSK70":{
					"display":1
				}
			},"!empty":{
				/*BoxNotes*/"#1IHUIRRCM0":{
					"display":1
				},
				/*TxtEmpty*/"#1IHUITSK70":{
					"display":0
				}
			},"envOK":{
				/*BtnNewNote*/"#1IIA0C0VB0":{
					"enable":true
				}
			},"!envOK":{
				/*BtnNewNote*/"#1IIA0C0VB0":{
					"enable":false
				}
			}
		},
		OnCreate:function(){
			self=this;
			boxNotes=self.BoxNotes;
			/*#{1IHUIJFMD1Create*/
			app.tbxNotes=self;
			self.showFace("empty");
			self.showFace("!envOK");
			/*}#1IHUIJFMD1Create*/
		},
		/*#{1IHUIJFMD1EndCSS*/
		/*}#1IHUIJFMD1EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.addNote=async function(note){
		/*#{1IHUU9GJD0Start*/
		let css;
		css={
			type:NoteCard(note),
			pushRAG(note,btn){
				return self.pushRAG(note,btn);
			}
		};
		boxNotes.appendNewChild(css);
		self.showFace("!empty");
		if(!self.display){
			app.mainUI.notifyNote();
		}
		/*}#1IHUU9GJD0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.newNote=async function(){
		/*#{1IIA0F2I80Start*/
		let css,note;
		note={
			desc:"New note",
			doc:"Write something...",
			env:envInfo,
			project:projectMeta,
			tags:""
		};
		css={
			type:NoteCard(note),
			pushRAG(note,btn){
				return self.pushRAG(note,btn);
			}
		};
		boxNotes.appendNewChild(css);
		self.showFace("!empty");
		if(!self.display){
			app.mainUI.notifyNote();
		}
		/*}#1IIA0F2I80Start*/
	};
	//------------------------------------------------------------------------
	cssVO.regEnv=async function(env,project){
		/*#{1IIA1BC6S0Start*/
		envInfo=env;
		projectMeta=project;
		self.showFace("envOK");
		/*}#1IIA1BC6S0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.pushRAG=async function(note,btn){
		/*#{1IIA6NKBC0Start*/
		let res;
		let env={
			platform:note.env.platform,
			arch:note.env.arch
		};
		let project={
			name:note.project.name,
			url:note.project.url
		};
		res=await tabNT.makeCall("RAGIndex",{index:{
			env_info:env,
			project_meta:project,
			procedure:note.doc
		}});
		if(res && res.code===200){
			if(btn){
				app.showTip(btn,(($ln==="CN")?("RAG推送成功！"):/*EN*/("RAG push success!")));
			}else{
				window.alert((($ln==="CN")?("RAG推送成功！"):/*EN*/("RAG push success!")));
			}
		}else{
			if(btn){
				app.showTip(btn,(($ln==="CN")?("RAG推送失败！"):/*EN*/("RAG push failed!")));
			}else{
				window.alert((($ln==="CN")?("RAG推送失败！"):/*EN*/("RAG push failed!")));
			}
		}
		/*}#1IIA6NKBC0Start*/
	};
	/*#{1IHUIJFMD1PostCSSVO*/
	/*}#1IHUIJFMD1PostCSSVO*/
	cssVO.constructor=TBXNotes;
	return cssVO;
};
/*#{1IHUIJFMD1ExCodes*/
/*}#1IHUIJFMD1ExCodes*/

//----------------------------------------------------------------------------
TBXNotes.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1IHUIJFMD1PreAISpot*/
	/*}#1IHUIJFMD1PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1IHUIJFMD1PostAISpot*/
	/*}#1IHUIJFMD1PostAISpot*/
	return exposeVO;
};

//----------------------------------------------------------------------------
TBXNotes.gearExport={
	framework: "jax",
	hudType: "hud",
	"showName":"",icon:"gears.svg",previewImg:false,
	fixPose:false,initW:100,initH:100,
	catalog:"",
	args: {},
	state:{
	},
	properties:["id","position","x","y","display"],
	faces:["empty","!empty","envOK","!envOK"],
	subContainers:{
	},
	/*#{1IHUIJFMD0ExGearInfo*/
	/*}#1IHUIJFMD0ExGearInfo*/
};
/*#{1IHUIJFMD0EndDoc*/
/*}#1IHUIJFMD0EndDoc*/

export default TBXNotes;
export{TBXNotes};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1IHUIJFMD0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1IHUIJFMD2",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1IHUIJFMD3",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1IHUIJFMD4",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1IHUIJFMD5",
//			"attrs": {}
//		},
//		"localVars": {
//			"jaxId": "1IHUIJFMD6",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1IHUIJFMD7",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IHUU9GJD0",
//					"attrs": {
//						"id": "addNote",
//						"label": "New AI Seg",
//						"x": "90",
//						"y": "95",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IHUUCK2D0",
//							"attrs": {
//								"note": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IHUUCK2D1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IHUUCK2D2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IIA0F2I80",
//					"attrs": {
//						"id": "newNote",
//						"label": "New AI Seg",
//						"x": "90",
//						"y": "180",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IIA0F93H0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IIA0F93H1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IIA0F93H2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IIA1BC6S0",
//					"attrs": {
//						"id": "regEnv",
//						"label": "New AI Seg",
//						"x": "90",
//						"y": "265",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IIA1CHRM0",
//							"attrs": {
//								"env": {
//									"type": "auto",
//									"valText": ""
//								},
//								"project": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IIA1CHRM1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IIA1CHRM2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IIA6NKBC0",
//					"attrs": {
//						"id": "pushRAG",
//						"label": "New AI Seg",
//						"x": "90",
//						"y": "355",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IIA6OQJG0",
//							"attrs": {
//								"note": {
//									"type": "auto",
//									"valText": ""
//								},
//								"btn": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IIA6OQJG1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IIA6OQJG2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				}
//			]
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1IHUIJFMD8",
//			"attrs": {
//				"empty": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IHUJ0BQL0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IHUJ181R0",
//							"attrs": {}
//						}
//					}
//				},
//				"!empty": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IHUJ0JSQ0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IHUJ181R1",
//							"attrs": {}
//						}
//					}
//				},
//				"envOK": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IIA56U6F0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IIA57K8B0",
//							"attrs": {}
//						}
//					}
//				},
//				"!envOK": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IIA576QO0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IIA57K8B1",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1IHUIJFMD9",
//			"attrs": {}
//		},
//		"exposeToAI": "true",
//		"descAI": "",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1IHUIJFMD1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1IHUIJFMD10",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "100%",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "10",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": ""
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1IHUIRRCM0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IHUITE7R0",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxNotes",
//										"position": "Absolute",
//										"x": "0",
//										"y": "30",
//										"w": "100%",
//										"h": "100%-30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Auto Scroll",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "10",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex Y"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "Gear1IHUKF6970",
//											"jaxId": "1IHUU3QCT0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1IHUU54QV0",
//													"attrs": {
//														"doc": {
//															"jaxId": "1IHUU54QV1",
//															"attrs": {
//																"desc": "github.com/lihxxx/DisPose安装指南",
//																"doc": "1234",
//																"env": "",
//																"project": "",
//																"tags": "github,setup"
//															}
//														}
//													}
//												},
//												"properties": {
//													"jaxId": "1IHUU54QV2",
//													"attrs": {
//														"type": "#null#>NoteCard({\"desc\":\"github.com/lihxxx/DisPose安装指南\",\"doc\":\"1234\",\"tags\":\"github,setup\"})",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": ""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IHUU54QV3",
//													"attrs": {
//														"1IIA576QO0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IIA57K8B2",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IIA57K8B3",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IIA576QO0",
//															"faceTagName": "!envOK"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IHUU54QV4",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IHUU54QV5",
//													"attrs": {}
//												},
//												"mockup": "true",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1IHUU54QV6",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear1IHUKF6970",
//											"jaxId": "1IHUU3U5A0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1IHUU54QV7",
//													"attrs": {
//														"doc": {
//															"jaxId": "1IHUU54QV8",
//															"attrs": {
//																"desc": "github.com/lihxxx/DisPose安装指南",
//																"doc": "1234",
//																"env": "",
//																"project": "",
//																"tags": "github,setup"
//															}
//														}
//													}
//												},
//												"properties": {
//													"jaxId": "1IHUU54QV9",
//													"attrs": {
//														"type": "#null#>NoteCard({\"desc\":\"github.com/lihxxx/DisPose安装指南\",\"doc\":\"1234\",\"tags\":\"github,setup\"})",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": ""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IHUU54QV10",
//													"attrs": {
//														"1IIA576QO0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IIA57K8B6",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IIA57K8B7",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IIA576QO0",
//															"faceTagName": "!envOK"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IHUU54QV11",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IHUU54QV12",
//													"attrs": {}
//												},
//												"mockup": "true",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1IHUU54QV13",
//													"attrs": {}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1IHUITE7R1",
//									"attrs": {
//										"1IHUJ0JSQ0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IHUJ181R2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IHUJ181R3",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IHUJ0JSQ0",
//											"faceTagName": "!empty"
//										},
//										"1IHUJ0BQL0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IHUJ181R4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IHUJ181R5",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IHUJ0BQL0",
//											"faceTagName": "empty"
//										},
//										"1IIA576QO0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IIA57K8B10",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IIA57K8B11",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IIA576QO0",
//											"faceTagName": "!envOK"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1IHUITE7R2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IHUITE7R3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1IHUITSK70",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IHUJ01NL0",
//									"attrs": {
//										"type": "text",
//										"id": "TxtEmpty",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#cfgColor[\"fontBodyLit\"]",
//										"text": {
//											"type": "string",
//											"valText": "No notes at the moment",
//											"localize": {
//												"EN": "No notes at the moment",
//												"CN": "暂时没有笔记"
//											},
//											"localizable": true
//										},
//										"font": "",
//										"fontSize": "#txtSize.midPlus",
//										"bold": "false",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Center",
//										"alignV": "Center",
//										"wrap": "false",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1IHUJ01NL1",
//									"attrs": {
//										"1IHUJ0JSQ0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IHUJ181R6",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IHUJ181R7",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IHUJ0JSQ0",
//											"faceTagName": "!empty"
//										},
//										"1IHUJ0BQL0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IHUJ181R8",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IHUJ181R9",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IHUJ0BQL0",
//											"faceTagName": "empty"
//										},
//										"1IIA576QO0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IIA57K8B14",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IIA57K8B15",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IIA576QO0",
//											"faceTagName": "!envOK"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1IHUJ01NL2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IHUJ01NL3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1IIA09FBK0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IIA09TH70",
//									"attrs": {
//										"type": "box",
//										"id": "BoxHeader",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "[255,255,255,1.00]",
//										"border": "[0,0,1,0]",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"contentLayout": "Flex X",
//										"itemsAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1IIA0C0VB0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1IIA0CFNT0",
//													"attrs": {
//														"style": "\"front\"",
//														"w": "28",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/additem.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1IIA0CFNT1",
//													"attrs": {
//														"type": "#null#>BtnIcon(\"front\",28,0,appCfg.sharedAssets+\"/additem.svg\",null)",
//														"id": "BtnNewNote",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": ""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IIA0CFNT2",
//													"attrs": {
//														"1IIA576QO0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IIA57K8B18",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IIA57K8B19",
//																	"attrs": {
//																		"enable": {
//																			"type": "bool",
//																			"valText": "false"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IIA576QO0",
//															"faceTagName": "!envOK"
//														},
//														"1IIA56U6F0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IIA57K8B20",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IIA57K8B21",
//																	"attrs": {
//																		"enable": {
//																			"type": "bool",
//																			"valText": "true"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IIA56U6F0",
//															"faceTagName": "envOK"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IIA0CFNT3",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1IIA0FHMF0",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1IIA0FHMF1",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": "1IIA0F2I80"
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1IIA0CFNT4",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1IIA0CFNT5",
//													"attrs": {}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1IIA09TH71",
//									"attrs": {
//										"1IIA576QO0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IIA57K8B22",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IIA57K8B23",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IIA576QO0",
//											"faceTagName": "!envOK"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1IIA09TH72",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IIA09TH73",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "true",
//								"container": "true",
//								"nameVal": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1IHUIJFMD11",
//					"attrs": {
//						"1IHUJ0BQL0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1IHUJ181R12",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IHUJ181R13",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1IHUJ0BQL0",
//							"faceTagName": "empty"
//						},
//						"1IIA576QO0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1IIA57K8B26",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IIA57K8B27",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1IIA576QO0",
//							"faceTagName": "!envOK"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1IHUIJFMD12",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1IHUIJFMD13",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1IHUIJFMD14",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}