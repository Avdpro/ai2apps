//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BoxViOutlet} from "./BoxViOutlet.js";
/*#{1II51EUUJ0StartDoc*/
/*}#1II51EUUJ0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BoxViSeg=function(seg){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let boxNames,boxOutlets,boxHeader;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let icon=appCfg.sharedAssets+"/faces.svg";
	let app=VFACT.app;
	
	/*#{1II51EUUJ1LocalVals*/
	icon=seg.icon||"faces.svg";
	if(icon[0]!=="/"){
		icon=appCfg.sharedAssets+"/"+icon;
	}
	let dirVal=null;
	let mini=false;
	let note=false;
	let reverseOutlets=seg.reverseOutlets;
	let headerRect={x:0,y:0,width:0,height:0};
	/*}#1II51EUUJ1LocalVals*/
	
	/*#{1II51EUUJ1PreState*/
	/*}#1II51EUUJ1PreState*/
	state={
		"segId":"CallLLM",
		/*#{1II51EUUK5ExState*/
		/*}#1II51EUUK5ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1II51EUUJ1PostState*/
	state.segId=seg.id||"- - -";//TODO: use view name?
	/*}#1II51EUUJ1PostState*/
	cssVO={
		"hash":"1II51EUUJ1",nameHost:true,
		"type":"hud","x":seg.x||"20%","y":seg.y||"50%","w":"","h":"","anchorY":1,"padding":[5,5,5,20],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
		"contentLayout":"flex-x","itemsAlign":1,"traceSize":true,
		children:[
			{
				"hash":"1II51FVB40",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["body"],
				"border":2,"borderColor":cfgColor["fontBody"],"corner":[60,8,8,60],
			},
			{
				"hash":"1II51ORFJ0",
				"type":"hud","id":"BoxNames","position":"relative","x":0,"y":0,"w":"","h":"","margin":[0,5,0,0],"minW":2,"minH":"","maxW":"","maxH":"","styleClass":"",
				"contentLayout":"flex-y","subAlign":1,
				children:[
					{
						"hash":"1II51PAV20",
						"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","minW":30,"minH":"","maxW":100,"maxH":"","styleClass":"","color":[0,0,0],"text":$P(()=>(state.segId),state),
						"fontSize":txtSize.small,"fontWeight":"bold","fontStyle":"normal","textDecoration":"","ellipsis":true,
					}
				],
			},
			{
				"hash":"1II51S6MS0",
				"type":"hud","id":"BoxOutlets","position":"relative","x":0,"y":0,"w":"","h":"","minW":5,"minH":16,"maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
				children:[
				],
			},
			{
				"hash":"1II51M2JL0",
				"type":"box","id":"BoxHeader","x":0,"y":"50%","w":38,"h":38,"anchorX":1,"anchorY":1,"padding":3,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"background":[255,255,255,1],"border":2,"borderColor":cfgColor["fontBody"],"corner":20,
				children:[
					{
						"hash":"1II521HD70",
						"type":"box","position":"relative","x":"50%","y":"50%","w":"100%","h":"100%","anchorX":1,"anchorY":1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						"background":cfgColor["fontBody"],"maskImage":icon,
					}
				],
			}
		],
		/*#{1II51EUUJ1ExtraCSS*/
		seg:seg,
		headerRect:headerRect,
		/*}#1II51EUUJ1ExtraCSS*/
		faces:{
			"blur":{
				/*BoxBG*/"#1II51FVB40":{
					"background":cfgColor["body"],"border":2
				},
				"#1II51PAV20":{
					"color":cfgColor["fontBody"]
				}
			},"focus":{
				/*BoxBG*/"#1II51FVB40":{
					"background":cfgColor["fontPrimarySub"],"border":3
				}
			},"mini":{
				"#self":{
					"padding":[5,5,5,0]
				},
				"#1II51PAV20":{
					"display":0
				},
				"#1II52V7US0":{
					"face":"mini"
				},
				/*BoxHeader*/"#1II51M2JL0":{
					"w":28,"h":28
				},
				/*#{1II53VFK10Code*/
				$(){
					let box=boxOutlets.children[0];
					mini=true;
					if(box){
						box.showFace("mini");
					}
				},
				/*}#1II53VFK10Code*/
			},"note":{
				"#self":{
					"minH":30
				},
				/*BoxOutlets*/"#1II51S6MS0":{
					"display":0
				}
			},"traced":{
				/*BoxHeader*/"#1II51M2JL0":{
					"background":cfgColor["primary"]
				},
				"#1II521HD70":{
					"background":cfgColor["fontPrimary"]
				}
			},"!traced":{
				/*BoxHeader*/"#1II51M2JL0":{
					"background":cfgColor["body"]
				},
				"#1II521HD70":{
					"background":cfgColor["fontBody"]
				}
			},"L2R":{
				"#self":{
					"rotate":0
				},
				"#1II52V7US0":{
					"face":"L2R"
				},
				/*#{1II540VD70Code*/
				$(){
					let box=boxOutlets.children[0];
					if(box){
						box.showFace("L2R");
					}
					seg.pathDir=[-1,0];
				}
				/*}#1II540VD70Code*/
			},"R2L":{
				"#self":{
					"rotate":180
				},
				"#1II52V7US0":{
					"face":"R2L"
				},
				/*#{1II5416B20Code*/
				$(){
					let box=boxOutlets.children[0];
					if(box){
						box.showFace("R2L");
					}
					seg.pathDir=[1,0];
				},
				/*}#1II5416B20Code*/
			},"T2B":{
				"#self":{
					"rotate":90
				},
				/*#{1II541ETG0Code*/
				$(){
					let box=boxOutlets.children[0];
					if(box){
						box.showFace("T2B");
					}
					seg.pathDir=[0,-1];
				},
				/*}#1II541ETG0Code*/
			},"B2T":{
				"#self":{
					"rotate":270
				},
				/*#{1II542LN20Code*/
				$(){
					let box=boxOutlets.children[0];
					if(box){
						box.showFace("B2T");
					}
					seg.pathDir=[0,1];
				},
				/*}#1II542LN20Code*/
			}
		},
		OnCreate:function(){
			self=this;
			boxNames=self.BoxNames;boxOutlets=self.BoxOutlets;boxHeader=self.BoxHeader;
			/*#{1II51EUUJ1Create*/
			seg.hudObj=self;//Bind on seg:
			self.initOutlets();
			if(seg.isConnector){
				self.showFace("mini");
				self.showFace(seg.dir);
			}else if(seg.isNote){
				self.showFace("note");
			}
			if(seg.traced){
				self.showFace("traced");
			}else{
				self.showFace("!traced");
			}
			/*}#1II51EUUJ1Create*/
		},
		/*#{1II51EUUJ1EndCSS*/
		/*}#1II51EUUJ1EndCSS*/
	};
	/*#{1II51EUUJ1PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.initOutlets=function(){
		if(!reverseOutlets){
			if(seg.outlet){
				boxOutlets.appendNewChild({
					type:BoxViOutlet(seg.outlet,self),position:"relative",x:0,y:0,
					OnClick:function(evt){
						self.OnOutletClick(this,evt);
					}
				});
			}
			if(seg.catchlet){
				boxOutlets.appendNewChild({
					type:BoxViOutlet(seg.catchlet,self),position:"relative",x:0,y:0,
					OnClick:function(evt){
						self.OnOutletClick(this,evt);
					}
				});
			}
		}
		if(seg.outlets){
			let i,n,list,outlet;
			list=seg.outlets;
			n=list.length;
			for(i=0;i<n;i++){
				outlet=list[i];
				boxOutlets.appendNewChild({
					type:BoxViOutlet(outlet,self),position:"relative",x:0,y:0,
					OnClick:function(evt){
						self.OnOutletClick(this,evt);
					}
				});
			}
		}
		if(reverseOutlets){
			if(seg.catchlet){
				boxOutlets.appendNewChild({
					type:BoxViOutlet(seg.catchlet,self),position:"relative",x:0,y:0,
					OnClick:function(evt){
						self.OnOutletClick(this,evt);
					}
				});
			}
			if(seg.outlet){
				boxOutlets.appendNewChild({
					type:BoxViOutlet(seg.outlet,self),position:"relative",x:0,y:0,
					OnClick:function(evt){
						self.OnOutletClick(this,evt);
					}
				});
			}
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.adjustSize=function(canvas){
		let rect;
		rect=boxOutlets.getBoundingClientRect();
		if(!rect.width||!rect.height){
			return;
		}
		if(mini){
			self.w=boxNames.w+boxOutlets.w+10;
		}else if(note){
			self.w=boxNames.w+30;
		}else{
			self.w=boxNames.w+boxOutlets.w+30;
		}
		self.syncHeaderPose(canvas);
	};
	
	//------------------------------------------------------------------------
	cssVO.syncHeaderPose=function(canvas,force=false){
		let webRect,cvsRect,x,y,boxSegs;
		boxSegs=self.parent;
		cvsRect=boxSegs.getBoundingClientRect();
		webRect=boxHeader.getBoundingClientRect();
		x=webRect.x-cvsRect.x;
		y=webRect.y-cvsRect.y;
		if(force || x!==headerRect.x || y!==headerRect.y){
			headerRect.x=x;
			headerRect.y=y;
			headerRect.width=webRect.width;
			headerRect.height=webRect.height;
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.renderPath=function(canvas){
		let list,i,n,outlet;
		list=seg.linkedOutlets;
		if(list){
			for(outlet of list){
				outlet.renderPath(canvas);
			}
		}
		list=boxOutlets.children;
		n=list.length;
		for(i=0;i<n;i++){
			outlet=list[i].outlet;
			if(outlet){
				outlet.renderPath(canvas);
			}
		}
	};
	
	//-----------------------------------------------------------------------
	cssVO.traceOutlet=function(jaxId){
		let list,i,n,outlet;
		list=boxOutlets.children;
		n=list.length;
		for(i=0;i<n;i++){
			outlet=list[i].outlet;
			if(outlet.jaxId===jaxId && outlet.hudObj){
				outlet.hudObj.trace(true);
				return outlet;
			}
		}
		return null;
	};
	
	//-----------------------------------------------------------------------
	cssVO.clearTrace=function(){
		let list,i,n,outlet;
		list=boxOutlets.children;
		n=list.length;
		for(i=0;i<n;i++){
			outlet=list[i].outlet;
			if(outlet && outlet.hudObj){
				outlet.hudObj.clearTrace();
			}
		}
	};
	
	/*}#1II51EUUJ1PostCSSVO*/
	cssVO.constructor=BoxViSeg;
	return cssVO;
};
/*#{1II51EUUJ1ExCodes*/
/*}#1II51EUUJ1ExCodes*/

//----------------------------------------------------------------------------
BoxViSeg.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1II51EUUJ1PreAISpot*/
	/*}#1II51EUUJ1PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1II51EUUJ1PostAISpot*/
	/*}#1II51EUUJ1PostAISpot*/
	return exposeVO;
};

/*#{1II51EUUJ0EndDoc*/
/*}#1II51EUUJ0EndDoc*/

export default BoxViSeg;
export{BoxViSeg};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1II51EUUJ0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1II51EUUK0",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1II51EUUK1",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1II51EUUK2",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1II51EUUK3",
//			"attrs": {
//				"seg": {
//					"type": "auto",
//					"valText": "{}"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1II51EUUK4",
//			"attrs": {
//				"icon": {
//					"type": "string",
//					"valText": "#appCfg.sharedAssets+\"/faces.svg\""
//				},
//				"app": {
//					"type": "auto",
//					"valText": "#null#>VFACT.app"
//				}
//			}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1II51EUUK5",
//			"attrs": {
//				"segId": {
//					"type": "string",
//					"valText": "CallLLM"
//				}
//			}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1II51EUUK6",
//			"attrs": {
//				"blur": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1II53V8JA0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1II546LLU0",
//							"attrs": {}
//						}
//					}
//				},
//				"focus": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1II53V3O80",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1II546LLU1",
//							"attrs": {}
//						}
//					}
//				},
//				"mini": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1II53VFK10",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1II546LLU2",
//							"attrs": {}
//						}
//					}
//				},
//				"note": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1II53VL2Q0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1II546LLU3",
//							"attrs": {}
//						}
//					}
//				},
//				"traced": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1II540EOF0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1II546LLU4",
//							"attrs": {}
//						}
//					}
//				},
//				"!traced": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1II540OPU0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1II546LLU5",
//							"attrs": {}
//						}
//					}
//				},
//				"L2R": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1II540VD70",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1II546LLU6",
//							"attrs": {}
//						}
//					}
//				},
//				"R2L": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1II5416B20",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1II546LLU7",
//							"attrs": {}
//						}
//					}
//				},
//				"T2B": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1II541ETG0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1II546LLU8",
//							"attrs": {}
//						}
//					}
//				},
//				"B2T": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1II542LN20",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1II546LLU9",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1II51EUUK7",
//			"attrs": {}
//		},
//		"exposeToAI": "true",
//		"descAI": "",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1II51EUUJ1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1II51EUUK8",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "#seg.x||\"20%\"",
//						"y": "#seg.y||\"50%\"",
//						"w": "",
//						"h": "",
//						"anchorH": "Left",
//						"anchorV": "Center",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "[5,5,5,20]",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Flex X",
//						"itemsAlign": "Center",
//						"traceSize": "true"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1II51FVB40",
//							"attrs": {
//								"properties": {
//									"jaxId": "1II51IL3L0",
//									"attrs": {
//										"type": "box",
//										"id": "BoxBG",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"body\"]",
//										"border": "2",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor[\"fontBody\"]",
//										"corner": "[60,8,8,60]",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1II51IL3L1",
//									"attrs": {
//										"1II53V8JA0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1II546LLU12",
//											"attrs": {
//												"properties": {
//													"jaxId": "1II546LLU13",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor[\"body\"]"
//														},
//														"border": {
//															"type": "auto",
//															"valText": "2",
//															"editMode": "edges"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1II53V8JA0",
//											"faceTagName": "blur"
//										},
//										"1II53V3O80": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1II549R3B0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1II549R3B1",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor[\"fontPrimarySub\"]"
//														},
//														"border": {
//															"type": "auto",
//															"valText": "3",
//															"editMode": "edges"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1II53V3O80",
//											"faceTagName": "focus"
//										},
//										"1II540EOF0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1II54H07K0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1II54H07K1",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1II540EOF0",
//											"faceTagName": "traced"
//										},
//										"1II540OPU0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1II54H07K2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1II54H07K3",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1II540OPU0",
//											"faceTagName": "!traced"
//										},
//										"1II540VD70": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1II5500S80",
//											"attrs": {
//												"properties": {
//													"jaxId": "1II5500S81",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1II540VD70",
//											"faceTagName": "L2R"
//										},
//										"1II5416B20": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1II5500S82",
//											"attrs": {
//												"properties": {
//													"jaxId": "1II5500S83",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1II5416B20",
//											"faceTagName": "R2L"
//										},
//										"1II541ETG0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1II5500S84",
//											"attrs": {
//												"properties": {
//													"jaxId": "1II5500S85",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1II541ETG0",
//											"faceTagName": "T2B"
//										},
//										"1II53VFK10": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1II554TPM0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1II554TPM1",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1II53VFK10",
//											"faceTagName": "mini"
//										},
//										"1II53VL2Q0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1II554TPM2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1II554TPM3",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1II53VL2Q0",
//											"faceTagName": "note"
//										},
//										"1II542LN20": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1II7EKKR00",
//											"attrs": {
//												"properties": {
//													"jaxId": "1II7EKKR01",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1II542LN20",
//											"faceTagName": "B2T"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1II51IL3L2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1II51IL3L3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "true",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1II51ORFJ0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1II51T3J80",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxNames",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,5,0,0]",
//										"padding": "",
//										"minW": "2",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex Y",
//										"subAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1II51PAV20",
//											"attrs": {
//												"properties": {
//													"jaxId": "1II51T3J81",
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"w": "",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "30",
//														"minH": "",
//														"maxW": "100",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "[0,0,0]",
//														"text": "${state.segId},state",
//														"font": "",
//														"fontSize": "#txtSize.small",
//														"bold": "true",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "true",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1II51T3J82",
//													"attrs": {
//														"1II53V8JA0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1II546LLU16",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1II546LLU17",
//																	"attrs": {
//																		"color": {
//																			"type": "colorRGB",
//																			"valText": "#cfgColor[\"fontBody\"]"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II53V8JA0",
//															"faceTagName": "blur"
//														},
//														"1II53V3O80": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1II549R3B2",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1II549R3B3",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II53V3O80",
//															"faceTagName": "focus"
//														},
//														"1II540EOF0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1II54H07K4",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1II54H07K5",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II540EOF0",
//															"faceTagName": "traced"
//														},
//														"1II540OPU0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1II54H07K6",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1II54H07K7",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II540OPU0",
//															"faceTagName": "!traced"
//														},
//														"1II53VFK10": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1II54I3AP2",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1II54I3AP3",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II53VFK10",
//															"faceTagName": "mini"
//														},
//														"1II540VD70": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1II5500S86",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1II5500S87",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II540VD70",
//															"faceTagName": "L2R"
//														},
//														"1II5416B20": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1II5500S88",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1II5500S89",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II5416B20",
//															"faceTagName": "R2L"
//														},
//														"1II541ETG0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1II5500S810",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1II5500S811",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II541ETG0",
//															"faceTagName": "T2B"
//														},
//														"1II53VL2Q0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1II554TPM4",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1II554TPM5",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II53VL2Q0",
//															"faceTagName": "note"
//														},
//														"1II542LN20": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1II7EKKR10",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1II7EKKR11",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II542LN20",
//															"faceTagName": "B2T"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1II51T3J83",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1II51T3J84",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1II51T3J85",
//									"attrs": {
//										"1II53V3O80": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1II549R3B6",
//											"attrs": {
//												"properties": {
//													"jaxId": "1II549R3B7",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1II53V3O80",
//											"faceTagName": "focus"
//										},
//										"1II540EOF0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1II54H07K8",
//											"attrs": {
//												"properties": {
//													"jaxId": "1II54H07K9",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1II540EOF0",
//											"faceTagName": "traced"
//										},
//										"1II540OPU0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1II54H07K10",
//											"attrs": {
//												"properties": {
//													"jaxId": "1II54H07K11",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1II540OPU0",
//											"faceTagName": "!traced"
//										},
//										"1II540VD70": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1II5500S812",
//											"attrs": {
//												"properties": {
//													"jaxId": "1II5500S813",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1II540VD70",
//											"faceTagName": "L2R"
//										},
//										"1II5416B20": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1II5500S814",
//											"attrs": {
//												"properties": {
//													"jaxId": "1II5500S815",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1II5416B20",
//											"faceTagName": "R2L"
//										},
//										"1II541ETG0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1II5500S816",
//											"attrs": {
//												"properties": {
//													"jaxId": "1II5500S817",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1II541ETG0",
//											"faceTagName": "T2B"
//										},
//										"1II53VFK10": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1II554TPM6",
//											"attrs": {
//												"properties": {
//													"jaxId": "1II554TPM7",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1II53VFK10",
//											"faceTagName": "mini"
//										},
//										"1II53VL2Q0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1II554TPM8",
//											"attrs": {
//												"properties": {
//													"jaxId": "1II554TPN0",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1II53VL2Q0",
//											"faceTagName": "note"
//										},
//										"1II542LN20": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1II7EKKR12",
//											"attrs": {
//												"properties": {
//													"jaxId": "1II7EKKR13",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1II542LN20",
//											"faceTagName": "B2T"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1II51T3J86",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1II51T3J87",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1II51S6MS0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1II51T3J88",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxOutlets",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "5",
//										"minH": "16",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex Y"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "Gear1II529G3P0",
//											"jaxId": "1II52V7US0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1II52V7US1",
//													"attrs": {
//														"outlet": "{}",
//														"segBox": ""
//													}
//												},
//												"properties": {
//													"jaxId": "1II52V7US2",
//													"attrs": {
//														"type": "#null#>BoxViOutlet({},undefined)",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": ""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1II52V7US3",
//													"attrs": {
//														"1II53V3O80": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1II549R3B10",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1II549R3B11",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II53V3O80",
//															"faceTagName": "focus"
//														},
//														"1II540EOF0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1II54H07K12",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1II54H07K13",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II540EOF0",
//															"faceTagName": "traced"
//														},
//														"1II540OPU0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1II54H07K14",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1II54H07K15",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II540OPU0",
//															"faceTagName": "!traced"
//														},
//														"1II53VFK10": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1II54SE0H0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1II54SE0H1",
//																	"attrs": {
//																		"face": {
//																			"type": "auto",
//																			"valText": "\"mini\"",
//																			"editType": "face"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II53VFK10",
//															"faceTagName": "mini"
//														},
//														"1II540VD70": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1II5500S818",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1II5500S819",
//																	"attrs": {
//																		"face": {
//																			"type": "auto",
//																			"valText": "\"L2R\"",
//																			"editType": "face"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II540VD70",
//															"faceTagName": "L2R"
//														},
//														"1II5416B20": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1II5500S820",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1II5500S821",
//																	"attrs": {
//																		"face": {
//																			"type": "auto",
//																			"valText": "\"R2L\"",
//																			"editType": "face"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II5416B20",
//															"faceTagName": "R2L"
//														},
//														"1II541ETG0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1II5500S822",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1II5500S823",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II541ETG0",
//															"faceTagName": "T2B"
//														},
//														"1II53VL2Q0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1II554TPN1",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1II554TPN2",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II53VL2Q0",
//															"faceTagName": "note"
//														},
//														"1II542LN20": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1II7EKKR14",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1II7EKKR15",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II542LN20",
//															"faceTagName": "B2T"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1II52V7US4",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1II52V7US5",
//													"attrs": {}
//												},
//												"mockup": "true",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1II52V7US6",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear1II529G3P0",
//											"jaxId": "1II52VCOO0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1II52VCOO1",
//													"attrs": {
//														"outlet": "{}",
//														"segBox": ""
//													}
//												},
//												"properties": {
//													"jaxId": "1II52VCOO2",
//													"attrs": {
//														"type": "#null#>BoxViOutlet({},undefined)",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "Off",
//														"face": ""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1II52VCOO3",
//													"attrs": {
//														"1II53V3O80": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1II549R3C0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1II549R3C1",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II53V3O80",
//															"faceTagName": "focus"
//														},
//														"1II540EOF0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1II54H07K16",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1II54H07K17",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II540EOF0",
//															"faceTagName": "traced"
//														},
//														"1II540OPU0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1II54H07K18",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1II54H07K19",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II540OPU0",
//															"faceTagName": "!traced"
//														},
//														"1II540VD70": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1II5500S824",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1II5500S825",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II540VD70",
//															"faceTagName": "L2R"
//														},
//														"1II5416B20": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1II5500S826",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1II5500S827",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II5416B20",
//															"faceTagName": "R2L"
//														},
//														"1II541ETG0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1II5500S828",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1II5500S829",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II541ETG0",
//															"faceTagName": "T2B"
//														},
//														"1II53VFK10": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1II554TPN3",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1II554TPN4",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II53VFK10",
//															"faceTagName": "mini"
//														},
//														"1II53VL2Q0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1II554TPN5",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1II554TPN6",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II53VL2Q0",
//															"faceTagName": "note"
//														},
//														"1II542LN20": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1II7EKKR16",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1II7EKKR17",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II542LN20",
//															"faceTagName": "B2T"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1II52VCOO4",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1II52VCOO5",
//													"attrs": {}
//												},
//												"mockup": "true",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1II52VCOO6",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear1II529G3P0",
//											"jaxId": "1II53C78A0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1II53HR2B0",
//													"attrs": {
//														"outlet": "{}",
//														"segBox": ""
//													}
//												},
//												"properties": {
//													"jaxId": "1II53HR2B1",
//													"attrs": {
//														"type": "#null#>BoxViOutlet({},undefined)",
//														"id": "",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"display": "Off",
//														"face": ""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1II53HR2B2",
//													"attrs": {
//														"1II53V3O80": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1II549R3C4",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1II549R3C5",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II53V3O80",
//															"faceTagName": "focus"
//														},
//														"1II540EOF0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1II54H07K20",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1II54H07K21",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II540EOF0",
//															"faceTagName": "traced"
//														},
//														"1II540OPU0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1II54H07K22",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1II54H07K23",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II540OPU0",
//															"faceTagName": "!traced"
//														},
//														"1II540VD70": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1II5500S830",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1II5500S831",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II540VD70",
//															"faceTagName": "L2R"
//														},
//														"1II5416B20": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1II5500S832",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1II5500S833",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II5416B20",
//															"faceTagName": "R2L"
//														},
//														"1II541ETG0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1II5500S834",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1II5500S835",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II541ETG0",
//															"faceTagName": "T2B"
//														},
//														"1II53VFK10": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1II554TPN7",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1II554TPN8",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II53VFK10",
//															"faceTagName": "mini"
//														},
//														"1II53VL2Q0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1II554TPN9",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1II554TPN10",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II53VL2Q0",
//															"faceTagName": "note"
//														},
//														"1II542LN20": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1II7EKKR18",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1II7EKKR19",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II542LN20",
//															"faceTagName": "B2T"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1II53HR2B3",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1II53HR2B4",
//													"attrs": {}
//												},
//												"mockup": "true",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1II53HR2B5",
//													"attrs": {}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1II51T3J90",
//									"attrs": {
//										"1II53V3O80": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1II549R3C8",
//											"attrs": {
//												"properties": {
//													"jaxId": "1II549R3C9",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1II53V3O80",
//											"faceTagName": "focus"
//										},
//										"1II53VL2Q0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1II54BT8F12",
//											"attrs": {
//												"properties": {
//													"jaxId": "1II54BT8F13",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1II53VL2Q0",
//											"faceTagName": "note"
//										},
//										"1II540EOF0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1II54H07K24",
//											"attrs": {
//												"properties": {
//													"jaxId": "1II54H07K25",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1II540EOF0",
//											"faceTagName": "traced"
//										},
//										"1II540OPU0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1II54H07K26",
//											"attrs": {
//												"properties": {
//													"jaxId": "1II54H07K27",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1II540OPU0",
//											"faceTagName": "!traced"
//										},
//										"1II540VD70": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1II5500S836",
//											"attrs": {
//												"properties": {
//													"jaxId": "1II5500S837",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1II540VD70",
//											"faceTagName": "L2R"
//										},
//										"1II5416B20": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1II5500S838",
//											"attrs": {
//												"properties": {
//													"jaxId": "1II5500S839",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1II5416B20",
//											"faceTagName": "R2L"
//										},
//										"1II541ETG0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1II5500S840",
//											"attrs": {
//												"properties": {
//													"jaxId": "1II5500S841",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1II541ETG0",
//											"faceTagName": "T2B"
//										},
//										"1II53VFK10": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1II554TPN11",
//											"attrs": {
//												"properties": {
//													"jaxId": "1II554TPN12",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1II53VFK10",
//											"faceTagName": "mini"
//										},
//										"1II542LN20": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1II7EKKR110",
//											"attrs": {
//												"properties": {
//													"jaxId": "1II7EKKR111",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1II542LN20",
//											"faceTagName": "B2T"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1II51T3J91",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1II51T3J92",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1II51M2JL0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1II51NK770",
//									"attrs": {
//										"type": "box",
//										"id": "BoxHeader",
//										"position": "Absolute",
//										"x": "0",
//										"y": "50%",
//										"w": "38",
//										"h": "38",
//										"anchorH": "Center",
//										"anchorV": "Center",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "3",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "[255,255,255,1.00]",
//										"border": "2",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor[\"fontBody\"]",
//										"corner": "20",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1II521HD70",
//											"attrs": {
//												"properties": {
//													"jaxId": "1II522J590",
//													"attrs": {
//														"type": "box",
//														"id": "",
//														"position": "Relative",
//														"x": "50%",
//														"y": "50%",
//														"w": "100%",
//														"h": "100%",
//														"anchorH": "Center",
//														"anchorV": "Center",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "#cfgColor[\"fontBody\"]",
//														"border": "0",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]",
//														"maskImage": "#icon"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1II522J591",
//													"attrs": {
//														"1II53V3O80": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1II549R3C12",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1II549R3C13",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II53V3O80",
//															"faceTagName": "focus"
//														},
//														"1II540EOF0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1II54H07K28",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1II54H07K29",
//																	"attrs": {
//																		"background": {
//																			"type": "colorRGBA",
//																			"valText": "#cfgColor[\"fontPrimary\"]"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II540EOF0",
//															"faceTagName": "traced"
//														},
//														"1II540OPU0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1II54H07K30",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1II54H07K31",
//																	"attrs": {
//																		"background": {
//																			"type": "colorRGBA",
//																			"valText": "#cfgColor[\"fontBody\"]"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II540OPU0",
//															"faceTagName": "!traced"
//														},
//														"1II540VD70": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1II5500S842",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1II5500S843",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II540VD70",
//															"faceTagName": "L2R"
//														},
//														"1II5416B20": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1II5500S844",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1II5500S845",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II5416B20",
//															"faceTagName": "R2L"
//														},
//														"1II541ETG0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1II5500S846",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1II5500S847",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II541ETG0",
//															"faceTagName": "T2B"
//														},
//														"1II53VFK10": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1II554TPN13",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1II554TPN14",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II53VFK10",
//															"faceTagName": "mini"
//														},
//														"1II53VL2Q0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1II554TPN15",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1II554TPN16",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II53VL2Q0",
//															"faceTagName": "note"
//														},
//														"1II542LN20": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1II7EKKR112",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1II7EKKR113",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1II542LN20",
//															"faceTagName": "B2T"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1II522J592",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1II522J593",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1II51NK771",
//									"attrs": {
//										"1II53V3O80": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1II549R3C16",
//											"attrs": {
//												"properties": {
//													"jaxId": "1II549R3C17",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1II53V3O80",
//											"faceTagName": "focus"
//										},
//										"1II540EOF0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1II54H07K32",
//											"attrs": {
//												"properties": {
//													"jaxId": "1II54H07K33",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor[\"primary\"]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1II540EOF0",
//											"faceTagName": "traced"
//										},
//										"1II540OPU0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1II54H07K34",
//											"attrs": {
//												"properties": {
//													"jaxId": "1II54H07K35",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor[\"body\"]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1II540OPU0",
//											"faceTagName": "!traced"
//										},
//										"1II53VFK10": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1II54L98M10",
//											"attrs": {
//												"properties": {
//													"jaxId": "1II54L98M11",
//													"attrs": {
//														"w": {
//															"type": "length",
//															"valText": "28"
//														},
//														"h": {
//															"type": "length",
//															"valText": "28"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1II53VFK10",
//											"faceTagName": "mini"
//										},
//										"1II540VD70": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1II5500S848",
//											"attrs": {
//												"properties": {
//													"jaxId": "1II5500S849",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1II540VD70",
//											"faceTagName": "L2R"
//										},
//										"1II5416B20": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1II5500S850",
//											"attrs": {
//												"properties": {
//													"jaxId": "1II5500S851",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1II5416B20",
//											"faceTagName": "R2L"
//										},
//										"1II541ETG0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1II5500S852",
//											"attrs": {
//												"properties": {
//													"jaxId": "1II5500S853",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1II541ETG0",
//											"faceTagName": "T2B"
//										},
//										"1II53VL2Q0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1II554TPN17",
//											"attrs": {
//												"properties": {
//													"jaxId": "1II554TPN18",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1II53VL2Q0",
//											"faceTagName": "note"
//										},
//										"1II542LN20": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1II7EKKR114",
//											"attrs": {
//												"properties": {
//													"jaxId": "1II7EKKR115",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1II542LN20",
//											"faceTagName": "B2T"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1II51NK772",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1II51NK773",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1II51EUUK9",
//					"attrs": {
//						"1II542LN20": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1II546LLU32",
//							"attrs": {
//								"properties": {
//									"jaxId": "1II546LLU33",
//									"attrs": {
//										"rotate": {
//											"type": "number",
//											"valText": "270"
//										}
//									}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1II542LN20",
//							"faceTagName": "B2T"
//						},
//						"1II53V3O80": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1II549R3C20",
//							"attrs": {
//								"properties": {
//									"jaxId": "1II549R3C21",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1II53V3O80",
//							"faceTagName": "focus"
//						},
//						"1II53VL2Q0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1II54H07K36",
//							"attrs": {
//								"properties": {
//									"jaxId": "1II54H07K37",
//									"attrs": {
//										"minH": {
//											"type": "length",
//											"valText": "30"
//										}
//									}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1II53VL2Q0",
//							"faceTagName": "note"
//						},
//						"1II540EOF0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1II54H07K38",
//							"attrs": {
//								"properties": {
//									"jaxId": "1II54H07K39",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1II540EOF0",
//							"faceTagName": "traced"
//						},
//						"1II540OPU0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1II54H07K40",
//							"attrs": {
//								"properties": {
//									"jaxId": "1II54H07K41",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1II540OPU0",
//							"faceTagName": "!traced"
//						},
//						"1II53VFK10": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1II54L98M12",
//							"attrs": {
//								"properties": {
//									"jaxId": "1II54L98M13",
//									"attrs": {
//										"padding": {
//											"type": "auto",
//											"valText": "[5,5,5,0]",
//											"editMode": "edges"
//										}
//									}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1II53VFK10",
//							"faceTagName": "mini"
//						},
//						"1II540VD70": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1II5500S854",
//							"attrs": {
//								"properties": {
//									"jaxId": "1II5500S855",
//									"attrs": {
//										"rotate": {
//											"type": "number",
//											"valText": "0"
//										}
//									}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1II540VD70",
//							"faceTagName": "L2R"
//						},
//						"1II5416B20": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1II5500S856",
//							"attrs": {
//								"properties": {
//									"jaxId": "1II5500S857",
//									"attrs": {
//										"rotate": {
//											"type": "number",
//											"valText": "180"
//										}
//									}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1II5416B20",
//							"faceTagName": "R2L"
//						},
//						"1II541ETG0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1II5500S858",
//							"attrs": {
//								"properties": {
//									"jaxId": "1II5500S859",
//									"attrs": {
//										"rotate": {
//											"type": "number",
//											"valText": "90"
//										}
//									}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1II541ETG0",
//							"faceTagName": "T2B"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1II51EUUK10",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1II51EUUK11",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1II51EUUK12",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}