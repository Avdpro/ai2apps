//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1II529G3P0StartDoc*/
/*}#1II529G3P0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BoxViOutlet=function(outlet,segBox){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let boxJointOrg;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1II529G3P1LocalVals*/
	let svg=null;
	let svgPath=null;
	let focused=false;
	let traced=false;
	let isRendered=false;
	/*}#1II529G3P1LocalVals*/
	
	/*#{1II529G3P1PreState*/
	/*}#1II529G3P1PreState*/
	state={
		"label":"outlet",
		/*#{1II529G3P7ExState*/
		/*}#1II529G3P7ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1II529G3P1PostState*/
	state.label=outlet.id||"result";
	/*}#1II529G3P1PostState*/
	cssVO={
		"hash":"1II529G3P1",nameHost:true,
		"type":"hud","x":75,"y":87,"w":"","h":"","margin":[3,0,3,0],"padding":[5,15,5,12],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
		"subAlign":1,
		children:[
			{
				"hash":"1II52APNK0",
				"type":"box","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["secondary"],"border":2,
				"corner":[10,0,0,10],
			},
			{
				"hash":"1II52FUV20",
				"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","minW":20,"minH":12,"maxW":70,"maxH":"","styleClass":"","color":cfgColor["fontSecondary"],
				"text":$P(()=>(state.label),state),"fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","ellipsis":true,
			},
			{
				"hash":"1II52KK850",
				"type":"box","id":"BoxLine","x":"100%","y":"50%","w":10,"h":4,"anchorY":1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["fontBody"],
			},
			{
				"hash":"1II52Q5BU0",
				"type":"box","id":"BoxJointOrg","x":">calc(100% + 11px)","y":"50%","w":12,"h":12,"anchorX":1,"anchorY":1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"background":cfgColor["body"],"border":3,"borderColor":cfgColor["fontBody"],"corner":12,
			}
		],
		/*#{1II529G3P1ExtraCSS*/
		outlet:outlet,
		/*}#1II529G3P1ExtraCSS*/
		faces:{
			"mini":{
				"#self":{
					"h":16
				},
				"#1II52FUV20":{
					"display":0
				}
			},"L2R":{
				/*BoxJointOrg*/"#1II52Q5BU0":{
					"rotate":0
				},
				/*#{1II54PJA30Code*/
				$(){
					outlet.pathDir=[1,0];
					svg.style.left="6px";
					svg.style.top="3px";
				},
				/*}#1II54PJA30Code*/
			},"R2L":{
				/*BoxJointOrg*/"#1II52Q5BU0":{
					"rotate":-180
				},
				/*#{1II54POTQ0Code*/
				$(){
					outlet.pathDir=[-1,0];
					svg.style.left="0px";
					svg.style.top="3px";
				},
				/*}#1II54POTQ0Code*/
			},"T2B":{
				/*BoxJointOrg*/"#1II52Q5BU0":{
					"rotate":-90
				},
				/*#{1II54PVFV0Code*/
				$(){
					outlet.pathDir=[0,1];
					svg.style.left="3px";
					svg.style.top="6px";
				},
				/*}#1II54PVFV0Code*/
			},"B2T":{
				/*BoxJointOrg*/"#1II52Q5BU0":{
					"rotate":90
				},
				/*#{1II54Q3JG0Code*/
				$(){
					outlet.pathDir=[0,-1];
					svg.style.left="3px";
					svg.style.top="0px";
				},
				/*}#1II54Q3JG0Code*/
			}
		},
		OnCreate:function(){
			self=this;
			boxJointOrg=self.BoxJointOrg;
			/*#{1II529G3P1Create*/
			outlet.hudObj=self;
			
			//:Test svg:
			svg= document.createElementNS("http://www.w3.org/2000/svg", "svg");
			svg.style.position="absolute";
			svg.style.left="6px";
			svg.style.top="3px";
			svg.style.width="1px";
			svg.style.height="1px";
			svg.style.overflow="unset";
			svgPath = document.createElementNS("http://www.w3.org/2000/svg", "path");
			svgPath.setAttribute("fill", "none");
			traced=outlet.traced;
			if(traced){
				svgPath.setAttribute("stroke-width", "3");
				svgPath.setAttribute("stroke", "blue");
				svgPath.setAttribute("stroke-dasharray","");
			}else{
				svgPath.setAttribute("stroke-width", "2");
				svgPath.setAttribute("stroke", "black");
				svgPath.setAttribute("stroke-dasharray","3 3");
			}
			//poly.setAttribute("points", "-50,-50 100,100 150,50 200,100 250,50");
			svg.appendChild(svgPath);
			boxJointOrg.webObj.appendChild(svg);
			/*}#1II529G3P1Create*/
		},
		/*#{1II529G3P1EndCSS*/
		/*}#1II529G3P1EndCSS*/
	};
	/*#{1II529G3P1PostCSSVO*/

	//------------------------------------------------------------------------
	cssVO.clearTrace=function(){
		traced=false;
		svgPath.setAttribute("stroke-width", "2");
		svgPath.setAttribute("stroke", "black");
		svgPath.setAttribute("stroke-dasharray","3 3");
	};

	//------------------------------------------------------------------------
	cssVO.trace=function(hot){
		let seg;		
		traced=true;
		if(hot){
			svgPath.setAttribute("stroke-width", "5");
			svgPath.setAttribute("stroke", "orange");
		}else{
			svgPath.setAttribute("stroke-width", "3");
			svgPath.setAttribute("stroke", "blue");
		}
		svgPath.setAttribute("stroke-dasharray","");
		//TODO: Check connector?
		seg=outlet.linkedSeg;
		if(seg && seg.isConnector && seg.outlet && seg.outlet.hudObj){
			seg.outlet.hudObj.trace(hot);
		}
	};

	//------------------------------------------------------------------------
	cssVO.syncOutlet=function(){
		state.label=outlet.idVal.val||"Result";
		if(traced!==outlet.traced){
			traced=outlet.traced;
			if(traced){
				svgPath.setAttribute("stroke-width", "3");
				svgPath.setAttribute("stroke", "blue");
				svgPath.setAttribute("stroke-dasharray","");
			}else{
				svgPath.setAttribute("stroke-width", "2");
				svgPath.setAttribute("stroke", "black");
				svgPath.setAttribute("stroke-dasharray","3 3");
			}
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.renderPath=function(canvas){
		let kx1,ky1,kx2,ky2,rect,dir;
		let tgtSeg,x,y,points,dot;
		let factor=1.0/canvas.zoom;
		if(!isRendered){
			let boxSegsX,boxSegsY,orgX,orgY;
			let boxSegs=canvas;
			let pickedSeg=outlet.linkedSeg;
			if(pickedSeg && (pickedSeg=pickedSeg.hudObj)){
				let isShort,dx,dy,len;
				rect=boxSegs.getBoundingClientRect();
				if(!rect.width){
					return;
				}
				boxSegsX=rect.x;
				boxSegsY=rect.y;
				rect=boxJointOrg.getBoundingClientRect();
				if(!rect.width){
					return;
				}
				orgX=rect.x+rect.width*0.5-boxSegsX;
				orgY=rect.y+rect.height*0.5-boxSegsY;
				svg.style.display="";
				rect=pickedSeg.headerRect;
				dir=pickedSeg.seg.pathDir;
				x=rect.x+(dir[1]?rect.width*0.5:0)-orgX;
				y=rect.y+(dir[0]?rect.height*0.5:0)-orgY;
				x+=dir[0]===1?rect.width:0;
				y+=dir[1]===1?rect.height:0;
				dir=outlet.pathDir;
				dot=x*dir[0]+y*dir[1];
				dx=(x<0?-x:x);
				dy=(y<0?-y:y);
				len=dx+dy;
				if(dir[1]==0){
					if(dy<50 && dx<50){
						isShort=true;
					}
				}else{
					if(dx<50 && dy<50){
						isShort=true;
					}
				}
				if(isShort){//dot>0){
					//kx1=x;ky1=0;
					kx1=dir[0]*(20/factor);
					ky1=dir[1]*(20/factor);
				}else{
					kx1=dir[0]*(50/factor);
					ky1=dir[1]*(50/factor);
				}

				dir=pickedSeg.seg.pathDir;
				dot=x*dir[0]+y*dir[1];
				if(isShort){//dot<0){
					//kx2=0;ky2=y;
					kx2=x+dir[0]*(20/factor);
					ky2=y+dir[1]*(20/factor);
				}else{
					kx2=x+dir[0]*(50/factor);
					ky2=y+dir[1]*(50/factor);
				}
				points=`M 0,0 C ${kx1*factor},${ky1*factor} ${kx2*factor},${ky2*factor} ${x*factor},${y*factor}`;
				svgPath.setAttribute("d", points);
			}
			isRendered=true;
		}
	};
	
	/*}#1II529G3P1PostCSSVO*/
	cssVO.constructor=BoxViOutlet;
	return cssVO;
};
/*#{1II529G3P1ExCodes*/
/*}#1II529G3P1ExCodes*/

//----------------------------------------------------------------------------
BoxViOutlet.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1II529G3P1PreAISpot*/
	/*}#1II529G3P1PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1II529G3P1PostAISpot*/
	/*}#1II529G3P1PostAISpot*/
	return exposeVO;
};

//----------------------------------------------------------------------------
BoxViOutlet.gearExport={
	framework: "jax",
	hudType: "hud",
	"showName":"",icon:"gears.svg",previewImg:false,
	fixPose:false,initW:100,initH:100,
	catalog:"",
	args: {
		"outlet": {
			"name": "outlet", "showName": "outlet", "type": "auto", "key": true, "fixed": true, 
			"initVal": {}
		}, 
		"segBox": {
			"name": "segBox", "showName": "segBox", "type": "auto", "key": true, "fixed": true, "initVal": undefined
		}
	},
	state:{
	},
	properties:["id","position","x","y","display"],
	faces:["mini","L2R","R2L","T2B","B2T"],
	subContainers:{
	},
	/*#{1II529G3P0ExGearInfo*/
	/*}#1II529G3P0ExGearInfo*/
};
/*#{1II529G3P0EndDoc*/
/*}#1II529G3P0EndDoc*/

export default BoxViOutlet;
export{BoxViOutlet};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1II529G3P0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1II529G3P2",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1II529G3P3",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1II529G3P4",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1II529G3P5",
//			"attrs": {
//				"outlet": {
//					"type": "auto",
//					"valText": "{}"
//				},
//				"segBox": {
//					"type": "auto",
//					"valText": ""
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1II529G3P6",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1II529G3P7",
//			"attrs": {
//				"label": {
//					"type": "string",
//					"valText": "outlet"
//				}
//			}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1II529G3P8",
//			"attrs": {
//				"mini": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1II54NMF90",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1II54NQCA0",
//							"attrs": {}
//						}
//					}
//				},
//				"L2R": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1II54PJA30",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1II54QM170",
//							"attrs": {}
//						}
//					}
//				},
//				"R2L": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1II54POTQ0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1II54QM171",
//							"attrs": {}
//						}
//					}
//				},
//				"T2B": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1II54PVFV0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1II54QM172",
//							"attrs": {}
//						}
//					}
//				},
//				"B2T": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1II54Q3JG0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1II54QM173",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1II529G3P9",
//			"attrs": {}
//		},
//		"exposeToAI": "true",
//		"descAI": "",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1II529G3P1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1II529G3P10",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "75",
//						"y": "87",
//						"w": "",
//						"h": "",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "[3,0,3,0]",
//						"padding": "[5,15,5,12]",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Flex Y",
//						"itemsAlign": "Start",
//						"subAlign": "Center"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1II52APNK0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1II52DRGK0",
//									"attrs": {
//										"type": "box",
//										"id": "",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"secondary\"]",
//										"border": "2",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "[10,0,0,10]",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1II52DRGK1",
//									"attrs": {
//										"1II54POTQ0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1II54QM178",
//											"attrs": {
//												"properties": {
//													"jaxId": "1II54QM179",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1II54POTQ0",
//											"faceTagName": "R2L"
//										},
//										"1II54PVFV0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1II54ROJ60",
//											"attrs": {
//												"properties": {
//													"jaxId": "1II54ROJ61",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1II54PVFV0",
//											"faceTagName": "T2B"
//										},
//										"1II54Q3JG0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1II7EQDAU0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1II7EQDAU1",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1II54Q3JG0",
//											"faceTagName": "B2T"
//										},
//										"1II54PJA30": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1II7R38NO0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1II7R38NO1",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1II54PJA30",
//											"faceTagName": "L2R"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1II52DRGK2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1II52DRGK3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1II52FUV20",
//							"attrs": {
//								"properties": {
//									"jaxId": "1II52IM9H0",
//									"attrs": {
//										"type": "text",
//										"id": "",
//										"position": "Relative",
//										"x": "0",
//										"y": "0",
//										"w": "",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "20",
//										"minH": "12",
//										"maxW": "70",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#cfgColor[\"fontSecondary\"]",
//										"text": "${state.label},state",
//										"font": "",
//										"fontSize": "#txtSize.small",
//										"bold": "false",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Top",
//										"wrap": "false",
//										"ellipsis": "true",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1II52IM9I0",
//									"attrs": {
//										"1II54NMF90": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1II54NQCA3",
//											"attrs": {
//												"properties": {
//													"jaxId": "1II54NQCA4",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1II54NMF90",
//											"faceTagName": "mini"
//										},
//										"1II54POTQ0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1II54QM1714",
//											"attrs": {
//												"properties": {
//													"jaxId": "1II54QM1715",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1II54POTQ0",
//											"faceTagName": "R2L"
//										},
//										"1II54PVFV0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1II54ROJ62",
//											"attrs": {
//												"properties": {
//													"jaxId": "1II54ROJ63",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1II54PVFV0",
//											"faceTagName": "T2B"
//										},
//										"1II54Q3JG0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1II7EQDAU2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1II7EQDAU3",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1II54Q3JG0",
//											"faceTagName": "B2T"
//										},
//										"1II54PJA30": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1II7R38NO2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1II7R38NO3",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1II54PJA30",
//											"faceTagName": "L2R"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1II52IM9I1",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1II52IM9I2",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1II52KK850",
//							"attrs": {
//								"properties": {
//									"jaxId": "1II52P8TU0",
//									"attrs": {
//										"type": "box",
//										"id": "BoxLine",
//										"position": "Absolute",
//										"x": "100%",
//										"y": "50%",
//										"w": "10",
//										"h": "4",
//										"anchorH": "Left",
//										"anchorV": "Center",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"fontBody\"]",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1II52P8TU1",
//									"attrs": {
//										"1II54POTQ0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1II54QM1720",
//											"attrs": {
//												"properties": {
//													"jaxId": "1II54QM1721",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1II54POTQ0",
//											"faceTagName": "R2L"
//										},
//										"1II54PVFV0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1II54ROJ70",
//											"attrs": {
//												"properties": {
//													"jaxId": "1II54ROJ71",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1II54PVFV0",
//											"faceTagName": "T2B"
//										},
//										"1II54Q3JG0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1II7EQDAU4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1II7EQDAU5",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1II54Q3JG0",
//											"faceTagName": "B2T"
//										},
//										"1II54PJA30": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1II7R38NO4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1II7R38NO5",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1II54PJA30",
//											"faceTagName": "L2R"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1II52P8TU2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1II52P8TU3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1II52Q5BU0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1II52RHP30",
//									"attrs": {
//										"type": "box",
//										"id": "BoxJointOrg",
//										"position": "Absolute",
//										"x": "100%+11",
//										"y": "50%",
//										"w": "12",
//										"h": "12",
//										"anchorH": "Center",
//										"anchorV": "Center",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"body\"]",
//										"border": "3",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor[\"fontBody\"]",
//										"corner": "12",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1II52RHP31",
//									"attrs": {
//										"1II54PJA30": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1II54QM1722",
//											"attrs": {
//												"properties": {
//													"jaxId": "1II54QM1723",
//													"attrs": {
//														"rotate": {
//															"type": "number",
//															"valText": "0"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1II54PJA30",
//											"faceTagName": "L2R"
//										},
//										"1II54Q3JG0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1II54QM1724",
//											"attrs": {
//												"properties": {
//													"jaxId": "1II54QM1725",
//													"attrs": {
//														"rotate": {
//															"type": "number",
//															"valText": "90"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1II54Q3JG0",
//											"faceTagName": "B2T"
//										},
//										"1II54POTQ0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1II54QM1726",
//											"attrs": {
//												"properties": {
//													"jaxId": "1II54QM1727",
//													"attrs": {
//														"rotate": {
//															"type": "number",
//															"valText": "-180"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1II54POTQ0",
//											"faceTagName": "R2L"
//										},
//										"1II54PVFV0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1II54ROJ72",
//											"attrs": {
//												"properties": {
//													"jaxId": "1II54ROJ73",
//													"attrs": {
//														"rotate": {
//															"type": "number",
//															"valText": "-90"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1II54PVFV0",
//											"faceTagName": "T2B"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1II52RHP32",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1II52RHP33",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1II529G3P11",
//					"attrs": {
//						"1II54NMF90": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1II54NQCA9",
//							"attrs": {
//								"properties": {
//									"jaxId": "1II54NQCA10",
//									"attrs": {
//										"h": {
//											"type": "length",
//											"valText": "16"
//										}
//									}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1II54NMF90",
//							"faceTagName": "mini"
//						},
//						"1II54POTQ0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1II54QM1732",
//							"attrs": {
//								"properties": {
//									"jaxId": "1II54QM1733",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1II54POTQ0",
//							"faceTagName": "R2L"
//						},
//						"1II54PVFV0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1II54ROJ74",
//							"attrs": {
//								"properties": {
//									"jaxId": "1II54ROJ75",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1II54PVFV0",
//							"faceTagName": "T2B"
//						},
//						"1II54Q3JG0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1II7EQDAU6",
//							"attrs": {
//								"properties": {
//									"jaxId": "1II7EQDAU7",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1II54Q3JG0",
//							"faceTagName": "B2T"
//						},
//						"1II54PJA30": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1II7R38NO6",
//							"attrs": {
//								"properties": {
//									"jaxId": "1II7R38NO7",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1II54PJA30",
//							"faceTagName": "L2R"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1II529G3P12",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1II529G3P13",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "true",
//				"container": "false",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1II529G3P14",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}