//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
import {NaviToolBar} from "/@StdUI/ui/NaviToolBar.js";
import {BtnNaviItem} from "/@StdUI/ui/BtnNaviItem.js";
/*#{1IN750NA00StartDoc*/
import Base64 from "/@tabos/utils/base64.js";
import {tabOS,tabFS} from "/@tabos";
/*}#1IN750NA00StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let TBXSandbox=function(){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let boxHeader,btnSnap,btnSaveCode,txtTitle,boxHtml,naviMode,tabHtml,tabCode,boxLogs;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1IN750NA01LocalVals*/
	const app=VFACT.app;
	let orgPageCode=null;
	let pageCode=null;
	let pageFrame=null;
	let sandboxId=""+Date.now()+"-"+Math.floor(Math.random()*1000);
	let resultCallback=null;
	let errorCallback=null;
	let pageLogs=null;
	let loadTimeout=null;
	let execTimeout=null;
	let curSession=null;
	
	async function getSanboxPage(req){
		let ret;
		ret={code:200,body:pageCode,headers:{"content-type":"text/html; charset=UTF-8"}};
		return ret;
	}
	
	function injectHookScript(html) {
		const hookScript = `
		<script>
		(function() {
			const log = console.log;
			const error = console.error;
			const orgFetch = window.orgFetch=window.fetch;
	
			let fetchHub=async function(url){
				let callVo,res,ext;
				if(url.startsWith("hub://")){
					url=url.substring(6);
				}
				{
					ext=url.indexOf(".");
					if(ext>=0){
						ext=url.substring(ext);
					}else{
						ext="";
					}
				}
				callVo={
					msg:"AhFileRead",vo:{fileName:url},seq:1
				};
				res=await (await orgFetch("/ws/",{
					method: 'POST',
					cache: 'no-cache',
					headers: {
						'Content-Type': 'application/json'
					},
					body:JSON.stringify(callVo)
				})).json();
				if(res.code===200){
					let data;
					data=res.data;
					switch(ext){
						case ".jpg":
						case ".jpeg":
							data="data:image/jpeg;base64,"+data;
							break;
						case ".png":
							data="data:image/png;base64,"+data;
							break;
						case ".txt":
							data="data:text/plain;base64,"+data;
							break;
						case ".csv":
							data="data:text/csv;base64,"+data;
							break;
						case ".mp3":
							data="data:audio/mpeg;base64,"+data;
							break;
						case ".json":
							data="data:application/json;base64,"+data;
							break;
						case ".js":
						case ".mjs":
							data="data:application/javascript;base64,"+data;
							break;
						default:
							data="data:application/octet-stream;base64,"+data;
							break;
					}
					return orgFetch(data);
				}else{
					return new Response('Not Found', {
						status: 404,
						statusText: 'Not Found',
						headers: {
							'Content-Type': 'text/plain',
						},
					});
				}
			};
	
			function isSameOrigin(url) {
				try {
					const targetUrl = new URL(url, window.location.href);
					return (
						targetUrl.protocol === window.location.protocol &&
						targetUrl.hostname === window.location.hostname &&
						targetUrl.port === window.location.port
					);
				} catch (e) {
					return false; // 无法解析URL
				}
			}		
	
			window.fetch=async function(url,options){
				let msgVO,callVO,text,body;
				if(url.startsWith("data:")){
					return orgFetch(url,options);
				}
				if(url.startsWith("hub:")){
					return fetchHub(url);
				}
				if(isSameOrigin(url)){
					return orgFetch(url,options);
				}
				callVO={
					url:url,
					...options
				};
				msgVO={
					msg:"WebFetch",vo:callVO,seq:1
				};
				body=callVO.body;
				if(body){
					if(body instanceof Uint8Array){
						body=Base64.encode(body);
					}else if(typeof(body)==="string"){
						body=Base64.encode(body);
					}else if(body instanceof ArrayBuffer){
						body=Base64.encode(body);
					}else if(typeof(body)==="object"){
						body=JSON.stringify(body);
						body=Base64.encode(body);
					}
					callVO.body=body;
				}
				text=JSON.stringify(msgVO);
				return orgFetch("/ws/",{
					method: 'POST',
					cache: 'no-cache',
					headers: {
						'Content-Type': 'application/json'
					},
					body:text
				})
			};
	
			console.log = function(...args) {
				let sandbox=parent["sandbox-${sandboxId}"];
				if(sandbox){
					log.call(this,"LOG found sandbox");
					sandbox.iframeLog(args);
				}else{
					log.call(this,"LOG missing sandbox: sandbox-${sandboxId}");
				}
				log.apply(this, args);
			};
	
			console.result=function(arg){
				let sandbox=parent["sandbox-${sandboxId}"];
				if(sandbox){
					sandbox.iframeResult(arg);
				}
			}
	
			console.error = function(...args) {
				let sandbox=parent["sandbox-${sandboxId}"];
				if(sandbox){
					sandbox.iframeError(args);
				}
				error.apply(this, args);
			};
	
			window.onerror = function(msg, url, line, col, err) {
				parent.postMessage({
					type: 'iframe-onerror',
					msg, url, line, col,
					stack: err?.stack || null
				}, '*');
			};
		})();
		</script>
		`.trim();
		// 插入位置优先找 <head>，没有就插到 <html> 后面，没有 <html> 也直接插开头
		if (html.includes('<head>')) {
			return html.replace('<head>', `<head>\n${hookScript}`);
		} else if (html.includes('<html>')) {
			return html.replace('<html>', `<html>\n<head>\n${hookScript}\n</head>`);
		} else {
			return `<head>\n${hookScript}\n</head>\n` + html;
		}
	}
	
	async function captureSandbox() {
		let sandboxRect;
		const stream = await navigator.mediaDevices.getDisplayMedia({
			video: { cursor: "always" },
			audio: false
		});
		self.showFace("!logs");
		sandboxRect=boxHtml.getBoundingClientRect();
		const track = stream.getVideoTracks()[0];
		const imageCapture = new ImageCapture(track);
		const bitmap = await imageCapture.grabFrame();
	
		const canvas = document.createElement('canvas');
		canvas.width = bitmap.width;
		canvas.height = bitmap.height;
	
		const ctx = canvas.getContext('2d');
		ctx.drawImage(bitmap, 0, 0);
	
		//Save as image
		canvas.toBlob(blob => {
			const url = URL.createObjectURL(blob);
			const a = document.createElement('a');
			a.href = url;
			a.download = 'screenshot.png';
			a.click();
		});
	
		//Release capture:
		track.stop();
	}
	function getElementScreenPosition(el) {
		if (!el) return null;
	
		let rect = el.getBoundingClientRect(); // 获取元素在当前视口中的坐标
		let win = el.ownerDocument.defaultView; // 获取元素所在的 window
		let x = rect.left, y = rect.top;
	
		// 如果元素在 iframe 内，累加所有父级 iframe 的偏移
		while (win !== window.top) {
			let iframe = win.frameElement; // 获取当前 iframe 元素
			if (!iframe) break;
	
			let iframeRect = iframe.getBoundingClientRect();
			x += iframeRect.left;
			y += iframeRect.top;
	
			win = win.parent; // 继续向上遍历
		}
	
		// 添加当前浏览器窗口在屏幕上的位置
		let screenX = 0;
		let screenY = 0;
		let dpr = 1;//window.devicePixelRatio;
		let browserFrameHeight = 0;//window.outerHeight - window.innerHeight
		return {
			x: (screenX + x) * dpr,
			y: (screenY + y+browserFrameHeight) * dpr,
			width: rect.width * dpr,
			height: rect.height * dpr
		};
	}
	/*}#1IN750NA01LocalVals*/
	
	/*#{1IN750NA01PreState*/
	/*}#1IN750NA01PreState*/
	/*#{1IN750NA01PostState*/
	/*}#1IN750NA01PostState*/
	cssVO={
		"hash":"1IN750NA01",nameHost:true,
		"type":"hud","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
		children:[
			{
				"hash":"1IN75RLIG0",
				"type":"box","id":"BoxHeader","x":0,"y":0,"w":"100%","h":30,"padding":[0,5,0,5],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":[255,255,255,1],
				"border":[0,0,1,0],"borderColor":cfgColor["fontBodySub"],"contentLayout":"flex-x","itemsAlign":1,
				children:[
					{
						"hash":"1INNKOLF30",
						"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/undo.svg",null),"id":"BtnSnap","position":"relative","x":0,"y":0,
						"tip":(($ln==="CN")?("重新载入"):("Reload")),
						"OnClick":function(event){
							self.ReloadPage(this,event);
						},
					},
					{
						"hash":"1INAO6K6H0",
						"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/hudimg.svg",null),"id":"BtnSnap","position":"relative","x":0,"y":0,"margin":[0,0,0,5],
						"tip":(($ln==="CN")?("保存沙盒截图"):("Save sandbox screenshot ")),
						"OnClick":function(event){
							self.snapPage(this,event);
						},
					},
					{
						"hash":"1INAGT85I0",
						"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/save.svg",null),"id":"BtnSaveCode","position":"relative","x":0,"y":0,"enable":false,"margin":[0,0,0,5],
						"tip":(($ln==="CN")?("保存代码"):("Save code(s)")),
						"OnClick":function(event){
							self.saveCode(this,event);
						},
					},
					{
						"hash":"1IN76D81S0",
						"type":"text","id":"TxtTitle","position":"relative","x":0,"y":0,"w":"","h":"","padding":[0,0,0,5],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						"color":cfgColor["fontBody"],"text":"Web Sandbox","fontSize":txtSize.mid,"fontWeight":"bold","fontStyle":"normal","textDecoration":"","flex":true,
					},
					{
						"hash":"1IN76G2TB0",
						"type":BtnIcon("front",28,0,appCfg.sharedAssets+"/uiright.svg",null),"id":"BtnShowLog","position":"relative","x":0,"y":0,
						"tip":(($ln==="CN")?("显示日志"):("Show logs")),
						"OnClick":function(event){
							self.showLogs(this,event);
						},
					},
					{
						"hash":"1IN76GDJI0",
						"type":BtnIcon("front",28,0,appCfg.sharedAssets+"/uirighthide.svg",null),"id":"BtnHideLog","position":"relative","x":0,"y":0,"display":0,
						"tip":(($ln==="CN")?("隐藏日志"):("Hide logs")),
						"OnClick":function(event){
							self.hideLogs(this,event);
						},
					}
				],
			},
			{
				"hash":"1IN75U18I0",
				"type":"hud","id":"BoxHtml","x":0,"y":30,"w":"100%","h":">calc(100% - 30px)","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
			},
			{
				"hash":"1INJ2MMI20",
				"type":"box","id":"BoxMode","x":0,"y":30,"w":"100%","h":30,"display":0,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":[255,255,255,1],
				"border":[0,0,1,0],
				children:[
					{
						"hash":"1INJ2NTVK0",
						"type":NaviToolBar(true),"id":"NaviMode","x":0,"y":1,"face":"top",
						subContainers:{
							"1HL4P0I9P0":[
								{
									"hash":"1INJ2PMRR0",
									"type":BtnNaviItem("Html","HTML Page",[0,0,0,1],"",undefined,txtSize.small,false,0,true),"id":"TabHtml","position":"relative","x":0,"y":0,"margin":[0,6,0,0],
								},
								{
									"hash":"1INJ2RARK0",
									"type":BtnNaviItem("Code","HTML Code",[0,0,0,1],"",undefined,txtSize.small,false,0,true),"id":"TabCode","position":"relative","x":0,"y":0,
								}
							]
						},
					}
				],
			},
			{
				"hash":"1IN76GPTP0",
				"type":"box","id":"BoxLogs","x":">calc(100% - 320px)","y":30,"w":320,"h":">calc(100% - 30px)","display":0,"overflow":"auto","padding":5,"minW":"",
				"minH":"","maxW":"","maxH":"","styleClass":"","background":[255,255,255,1],"border":[0,0,0,1],"contentLayout":"flex-y",
			}
		],
		/*#{1IN750NA01ExtraCSS*/
		/*}#1IN750NA01ExtraCSS*/
		faces:{
			"logs":{
				/*BtnShowLog*/"#1IN76G2TB0":{
					"display":0
				},
				/*BtnHideLog*/"#1IN76GDJI0":{
					"display":1
				},
				/*BoxLogs*/"#1IN76GPTP0":{
					"display":1
				}
			},"!logs":{
				/*BtnShowLog*/"#1IN76G2TB0":{
					"display":1
				},
				/*BtnHideLog*/"#1IN76GDJI0":{
					"display":0
				},
				/*BoxLogs*/"#1IN76GPTP0":{
					"display":0
				}
			}
		},
		OnCreate:function(){
			self=this;
			boxHeader=self.BoxHeader;btnSnap=self.BtnSnap;btnSnap=self.BtnSnap;btnSaveCode=self.BtnSaveCode;txtTitle=self.TxtTitle;boxHtml=self.BoxHtml;naviMode=self.NaviMode;tabHtml=self.TabHtml;tabCode=self.TabCode;boxLogs=self.BoxLogs;
			/*#{1IN750NA01Create*/
			//Register sandbox callback and http-route:
			window["sandbox-"+sandboxId]=self;
			tabOS.regRoute(`+sandbox-${sandboxId}`,getSanboxPage);
			/*}#1IN750NA01Create*/
		},
		/*#{1IN750NA01EndCSS*/
		OnFree:function(){
			delete window["sandbox-"+sandboxId];
			tabOS.stopRoute(`+sandbox-${sandboxId}`,getSanboxPage);
		}
		/*}#1IN750NA01EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.runCode=async function(session,code){
		/*#{1IN78C21F0Start*/
		let pms,result;
		naviMode.focusOn(tabHtml);
		curSession=session;
		btnSaveCode.enable=false;
		pms=new Promise((resolve,reject)=>{
			resultCallback=resolve;
			errorCallback=reject;
		});
		txtTitle.text=(($ln==="CN")?("正在加载沙箱页面内容..."):/*EN*/("Loading sandbox page..."));
		orgPageCode=code;
		pageCode=injectHookScript(orgPageCode);
		boxHtml.webObj.innerHTML="";//Clear old frame
		boxLogs.webObj.innerHTML="";//Clear logs
		pageLogs=[];
		self.iframeLog("Creating sandbox iframe.");
		pageFrame=document.createElement("iframe");
		pageFrame.style.position="absolute";
		pageFrame.style.left="0px";
		pageFrame.style.top="0px";
		pageFrame.style.width="100%";
		pageFrame.style.height="100%";
		pageFrame.style.border="none";
		pageFrame.setAttribute("tabindex", 0);
		boxHtml.webObj.appendChild(pageFrame);
		pageFrame.onerror=()=>{
			let callback;
			self.iframeError("Page load error.");
			callback=errorCallback;
			if(callback){
				errorCallback=null;
				resultCallback=null;
				callback("Page load error");
			}
		};
		self.iframeLog("Sandbox iframe created, loading page.");
		pageFrame.src=`/+sandbox-${sandboxId}`;
		pageFrame.onload=async ()=>{
			let frameWin,run,result,callback;
			clearTimeout(loadTimeout);
			self.iframeLog("Sandbox page loaded.");
			frameWin=pageFrame.contentWindow;
			txtTitle.text=pageFrame.contentDocument.title;
			run=frameWin.run;
			if(run){
				self.iframeLog("Found run function of sandbox page, executing run function.");
				try{
					result=await frameWin.run();
					self.iframeLog("Run function execute finished, result:");
					self.iframeLog([result]);
				}catch(err){
					console.error(err);
					self.iframeLog("Run function execute failed, error: "+err);
					self.iframeLog("Error call stack:\n"+err.stack);
					callback=resultCallback;
					if(callback){
						errorCallback=null;
						resultCallback=null;
						callback({error:err,logs:pageLogs});
					}
					return;
				}
				callback=resultCallback;
				if(callback){
					errorCallback=null;
					resultCallback=null;
					callback({result:result,logs:pageLogs});
				}
			}else{
				self.iframeLog("Can'f find page's run function. This is not a error. Sandbox finished.");
				callback=resultCallback;
				if(callback){
					errorCallback=null;
					resultCallback=null;
					callback({result:"Page load finished.",logs:pageLogs});
				}
			}
		};
		loadTimeout=setTimeout(()=>{
			self.iframeLog("Page load timeout, sandbox finished.");
			let callback;
			callback=errorCallback;
			if(callback){
				errorCallback=null;
				resultCallback=null;
				callback({error:"[Error] Page load timeout.",logs:pageLogs});
			}
		},20000);
		result=await pms;
		btnSaveCode.enable=true;
		return result;
		/*}#1IN78C21F0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.runTemplate=async function(){
		/*#{1IN78H58E0Start*/
		/*}#1IN78H58E0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.iframeLog=async function(args){
		/*#{1IN89I05F0Start*/
		let arg,pre;
		if(typeof(args)==="string"){
			args=[args];
		}
		for(arg of args){
			pre = document.createElement('pre');
			pre.textContent = ""+arg;
			pageLogs.push(""+arg);
			boxLogs.webObj.appendChild(pre);
		}
		//Scroll logs:
		boxLogs.webObj.scrollTop=boxLogs.webObj.scrollHeight;
		/*}#1IN89I05F0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.iframeError=async function(args){
		/*#{1IN89HFKA0Start*/
		let arg,pre;
		for(arg of args){
			pre = document.createElement('pre');
			pre.textContent = "[ERROR] "+arg;
			pageLogs.push("[ERROR] "+arg);
			boxLogs.webObj.appendChild(pre);
		}
		//Scroll logs:
		boxLogs.webObj.scrollTop=boxLogs.webObj.scrollHeight;
		/*}#1IN89HFKA0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.iframeResult=async function(arg){
		/*#{1IN8BIG340Start*/
		let callback=resultCallback;
		if(callback){
			resultCallback=null;
			callback({result:arg,logs:pageLogs});
		}
		/*}#1IN8BIG340Start*/
	};
	//------------------------------------------------------------------------
	cssVO.showLogs=async function(sender,event){
		/*#{1IN9IAJFE0Start*/
		/*}#1IN9IAJFE0Start*/
		self.showFace("logs");
	};
	//------------------------------------------------------------------------
	cssVO.hideLogs=async function(sender,event){
		/*#{1IN9IBNHC0Start*/
		/*}#1IN9IBNHC0Start*/
		self.showFace("!logs");
	};
	//------------------------------------------------------------------------
	cssVO.saveCode=async function(sender){
		/*#{1INAL475G0Start*/
		let items,item,path,data,dataUrl,a;
		items=[
			{text:"Download to device",code:"device"},
			{text:"Save in Tab-OS",code:"tabos"},
		];
		item=await app.modalDlg("/@StdUI/ui/DlgMenu.js",{
			items:items,hud:sender
		});
		if(!item){
			return;
		}
		if(item.code==="device"){
			data=Base64.encode(orgPageCode);
			dataUrl="data:text/html;base64,"+data;
			a = document.createElement("a");
			a.href = dataUrl;
			a.download = "sanbox.html";
			a.click();
		}else{
			path="/doc";
			path=await app.modalDlg("/@StdUI/ui/DlgFile.js",{
				mode:"save",
				path:path
			});
			if(path){
				await tabFS.writeFile(path,orgPageCode);
			}
		}
		/*}#1INAL475G0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.snapPage=async function(){
		/*#{1INANHICB0Start*/
		let items,item,topWin,oldTitle,capWin,sandboxRect,scale,saveMode;
		if(!curSession){
			return;
		}
		topWin=window;
		while(topWin.parent && topWin.parent!=topWin){
			topWin=topWin.parent;
		}
		if(curSession.isWaitingInput){
			items=[
				{text:(($ln==="CN")?("将快照插入到聊天会话中"):/*EN*/("Insert snapshot into chat session")),mode:"Chat"},
				{text:(($ln==="CN")?("下载快照图像"):/*EN*/("Download snapshot image")),mode:"Download"},
			];
			item=await app.modalDlg("/@StdUI/ui/DlgMenu.js",{
				items:items,hud:btnSnap
			});
			if(!item){
				return;
			}
			saveMode=item.mode;
		}else{
			saveMode="Download";
		}
		oldTitle=topWin.document.title;
		topWin.document.title=oldTitle+" [Asking Capture]";
		capWin=topWin.open("/@AgentBuilder/snappage.html");
		capWin.onload=()=>{
			capWin.capturePage((bitmap)=>{
				topWin.document.title=oldTitle;
				if(bitmap){
					const canvas = document.createElement('canvas');
					sandboxRect=getElementScreenPosition(boxHtml.webObj);
					scale=bitmap.width/topWin.innerWidth;
					
					canvas.width=sandboxRect.width*scale;
					canvas.height=sandboxRect.height*scale;
					//canvas.width = bitmap.width;
					//canvas.height = bitmap.height;
		
					const ctx = canvas.getContext('2d');
					ctx.drawImage(bitmap, sandboxRect.x*scale, sandboxRect.y*scale,canvas.width,canvas.height,0,0,canvas.width,canvas.height);
		
					//Save as image
					canvas.toBlob(async (blob) => {
						if(saveMode==="Chat"){
							let buffer,hubUrl;
							buffer = await blob.arrayBuffer();
							buffer=Base64.encode(buffer);
							hubUrl=await curSession.saveHubFile("sandbox.png",buffer);
							hubUrl="hub://"+hubUrl;
							await curSession.addChatInputAsset("snadbox.png",hubUrl,"图片为当前页面截图",buffer);
						}else{
							const url = URL.createObjectURL(blob);
							const a = document.createElement('a');
							a.href = url;
							a.download = 'sandbox.png';
							a.click();
						}
					});
				}
			})
		};
		//app.appFrame.capturePage();
		//captureSandbox();
		/*}#1INANHICB0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.ReloadPage=async function(){
		/*#{1INNKQG740Start*/
		self.runCode(curSession,orgPageCode);
		/*}#1INNKQG740Start*/
	};
	/*#{1IN750NA01PostCSSVO*/
	/*}#1IN750NA01PostCSSVO*/
	cssVO.constructor=TBXSandbox;
	return cssVO;
};
/*#{1IN750NA01ExCodes*/
/*}#1IN750NA01ExCodes*/

//----------------------------------------------------------------------------
TBXSandbox.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1IN750NA01PreAISpot*/
	/*}#1IN750NA01PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1IN750NA01PostAISpot*/
	/*}#1IN750NA01PostAISpot*/
	return exposeVO;
};

//----------------------------------------------------------------------------
TBXSandbox.gearExport={
	framework: "jax",
	hudType: "hud",
	"showName":"",icon:"gears.svg",previewImg:false,
	fixPose:false,initW:100,initH:100,
	catalog:"",
	args: {},
	state:{
	},
	properties:["id","position","x","y","display"],
	faces:["logs","!logs"],
	subContainers:{
	},
	/*#{1IN750NA00ExGearInfo*/
	/*}#1IN750NA00ExGearInfo*/
};
/*#{1IN750NA00EndDoc*/
/*}#1IN750NA00EndDoc*/

export default TBXSandbox;
export{TBXSandbox};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1IN750NA00",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1IN750NA10",
//			"attrs": {
//				"device": "Desktop 800x600",
//				"screenW": "800",
//				"screenH": "600",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1IN750NA11",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1IN750NA12",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1IN750NA13",
//			"attrs": {}
//		},
//		"localVars": {
//			"jaxId": "1IN750NA14",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1IN750NA15",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IN78C21F0",
//					"attrs": {
//						"id": "runCode",
//						"label": "New AI Seg",
//						"x": "110",
//						"y": "75",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IN78D2MB0",
//							"attrs": {
//								"session": {
//									"type": "auto",
//									"valText": ""
//								},
//								"code": {
//									"type": "string",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IN78D2MB1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IN78D2MB2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IN78H58E0",
//					"attrs": {
//						"id": "runTemplate",
//						"label": "New AI Seg",
//						"x": "110",
//						"y": "160",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IN78HTEK0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IN78HTEK1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IN78HTEK2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IN89I05F0",
//					"attrs": {
//						"id": "iframeLog",
//						"label": "New AI Seg",
//						"x": "110",
//						"y": "250",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IN89IG9B3",
//							"attrs": {
//								"args": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IN89IG9B4",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IN89IG9B5",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IN89HFKA0",
//					"attrs": {
//						"id": "iframeError",
//						"label": "New AI Seg",
//						"x": "110",
//						"y": "335",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IN89IG9B0",
//							"attrs": {
//								"args": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IN89IG9B1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IN89IG9B2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IN8BIG340",
//					"attrs": {
//						"id": "iframeResult",
//						"label": "New AI Seg",
//						"x": "110",
//						"y": "420",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IN8BKFHJ0",
//							"attrs": {
//								"arg": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IN8BKFHJ1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IN8BKFHJ2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IN9IAJFE0",
//					"attrs": {
//						"id": "showLogs",
//						"label": "New AI Seg",
//						"x": "110",
//						"y": "510",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IN9IBFTO0",
//							"attrs": {
//								"sender": {
//									"valText": "null"
//								},
//								"event": {
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IN9IBFTO1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": [
//								{
//									"type": "flowseg",
//									"def": "SetFace",
//									"jaxId": "1IN9IBFTO2",
//									"attrs": {
//										"id": "showFace",
//										"label": "New AI Seg",
//										"x": "315",
//										"y": "510",
//										"desc": "",
//										"codes": "false",
//										"component": "self",
//										"face": "logs",
//										"outlet": {
//											"jaxId": "1IN9IBFTO3",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											}
//										}
//									},
//									"icon": "faces.svg"
//								}
//							]
//						},
//						"outlet": {
//							"jaxId": "1IN9IBFTO4",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1IN9IBFTO2"
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IN9IBNHC0",
//					"attrs": {
//						"id": "hideLogs",
//						"label": "New AI Seg",
//						"x": "110",
//						"y": "600",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IN9INHC20",
//							"attrs": {
//								"sender": {
//									"valText": "null"
//								},
//								"event": {
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IN9INHC21",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": [
//								{
//									"type": "flowseg",
//									"def": "SetFace",
//									"jaxId": "1IN9INHC22",
//									"attrs": {
//										"id": "showFace",
//										"label": "New AI Seg",
//										"x": "315",
//										"y": "600",
//										"desc": "",
//										"codes": "false",
//										"component": "self",
//										"face": "!logs",
//										"outlet": {
//											"jaxId": "1IN9INHC23",
//											"attrs": {
//												"id": "Next",
//												"desc": "输出节点。"
//											}
//										}
//									},
//									"icon": "faces.svg"
//								}
//							]
//						},
//						"outlet": {
//							"jaxId": "1IN9INHC24",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1IN9INHC22"
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1INAL475G0",
//					"attrs": {
//						"id": "saveCode",
//						"label": "New AI Seg",
//						"x": "320",
//						"y": "75",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1INAL4DHQ0",
//							"attrs": {
//								"sender": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1INAL4DHQ1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1INAL4DHQ2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1INANHICB0",
//					"attrs": {
//						"id": "snapPage",
//						"label": "New AI Seg",
//						"x": "535",
//						"y": "75",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1INANI69E0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1INANI69E1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1INANI69E2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1INNKQG740",
//					"attrs": {
//						"id": "ReloadPage",
//						"label": "New AI Seg",
//						"x": "755",
//						"y": "75",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1INNKV00S0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1INNKV00S1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1INNKV00S2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				}
//			]
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1IN750NA16",
//			"attrs": {
//				"logs": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IN77GFPB0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IN77H8KT0",
//							"attrs": {}
//						}
//					}
//				},
//				"!logs": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IN77GKHM0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IN77H8KT1",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1IN750NA17",
//			"attrs": {}
//		},
//		"exposeToAI": "true",
//		"descAI": "",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1IN750NA01",
//			"attrs": {
//				"properties": {
//					"jaxId": "1IN750NA18",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "100%",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": ""
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1IN75RLIG0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IN75SB1L0",
//									"attrs": {
//										"type": "box",
//										"id": "BoxHeader",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "[0,5,0,5]",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "[255,255,255,1.00]",
//										"border": "[0,0,1,0]",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor[\"fontBodySub\"]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"contentLayout": "Flex X",
//										"itemsAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1INNKOLF30",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1INNKOLF31",
//													"attrs": {
//														"style": "\"front\"",
//														"w": "24",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/undo.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1INNKOLF32",
//													"attrs": {
//														"type": "#null#>BtnIcon(\"front\",24,0,appCfg.sharedAssets+\"/undo.svg\",null)",
//														"id": "BtnSnap",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"enable": "true"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1INNKOLF33",
//													"attrs": {
//														"1IN77GFPB0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1INNKOLF34",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1INNKOLF35",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IN77GFPB0",
//															"faceTagName": "logs"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1INNKOLF36",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1INNKOLF37",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1INNKOLF38",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": "1INNKQG740"
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1INNKOLF39",
//													"attrs": {
//														"tip": {
//															"type": "string",
//															"valText": "Reload",
//															"localize": {
//																"EN": "Reload",
//																"CN": "重新载入"
//															},
//															"localizable": true
//														}
//													}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1INNKOLF310",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1INAO6K6H0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1INAO6K6H1",
//													"attrs": {
//														"style": "\"front\"",
//														"w": "24",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/hudimg.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1INAO6K6H2",
//													"attrs": {
//														"type": "#null#>BtnIcon(\"front\",24,0,appCfg.sharedAssets+\"/hudimg.svg\",null)",
//														"id": "BtnSnap",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"enable": "true",
//														"margin": "[0,0,0,5]"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1INAO6K6H3",
//													"attrs": {
//														"1IN77GFPB0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1INJ31JKQ0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1INJ31JKQ1",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IN77GFPB0",
//															"faceTagName": "logs"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1INAO6K6H4",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1INAO6K6I0",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1INAO6K6I1",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": "1INANHICB0"
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1INAO6K6I2",
//													"attrs": {
//														"tip": {
//															"type": "string",
//															"valText": "Save sandbox screenshot ",
//															"localize": {
//																"EN": "Save sandbox screenshot ",
//																"CN": "保存沙盒截图"
//															},
//															"localizable": true
//														}
//													}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1INAO6K6I3",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1INAGT85I0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1INAKTJHF0",
//													"attrs": {
//														"style": "\"front\"",
//														"w": "24",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/save.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1INAKTJHF1",
//													"attrs": {
//														"type": "#null#>BtnIcon(\"front\",24,0,appCfg.sharedAssets+\"/save.svg\",null)",
//														"id": "BtnSaveCode",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"enable": "false",
//														"margin": "[0,0,0,5]"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1INAKTJHF2",
//													"attrs": {
//														"1IN77GFPB0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1INJ31JKQ2",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1INJ31JKQ3",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IN77GFPB0",
//															"faceTagName": "logs"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1INAKTJHF3",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1INAL6M2J0",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1INAL6M2J1",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": "1INAL475G0"
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1INAKTJHF4",
//													"attrs": {
//														"tip": {
//															"type": "string",
//															"valText": "Save code(s)",
//															"localize": {
//																"EN": "Save code(s)",
//																"CN": "保存代码"
//															},
//															"localizable": true
//														}
//													}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1INAKTJHF5",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1IN76D81S0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IN76EBII0",
//													"attrs": {
//														"type": "text",
//														"id": "TxtTitle",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "[0,0,0,5]",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBody\"]",
//														"text": "Web Sandbox",
//														"font": "",
//														"fontSize": "#txtSize.mid",
//														"bold": "true",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0",
//														"flex": "true"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IN76EBII1",
//													"attrs": {
//														"1IN77GFPB0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1INJ31JKQ4",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1INJ31JKQ5",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IN77GFPB0",
//															"faceTagName": "logs"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IN76EBII2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IN76EBII3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1IN76G2TB0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1IN76G2TB1",
//													"attrs": {
//														"style": "\"front\"",
//														"w": "28",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/uiright.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1IN76G2TB2",
//													"attrs": {
//														"type": "#null#>BtnIcon(\"front\",28,0,appCfg.sharedAssets+\"/uiright.svg\",null)",
//														"id": "BtnShowLog",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": ""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IN76G2TB3",
//													"attrs": {
//														"1IN77GFPB0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IN77H8KT8",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IN77H8KT9",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IN77GFPB0",
//															"faceTagName": "logs"
//														},
//														"1IN77GKHM0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IN77JDLQ0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IN77JDLQ1",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IN77GKHM0",
//															"faceTagName": "!logs"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IN76G2TC8",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1IN76G2TC9",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1IN76G2TC10",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": "1IN9IAJFE0"
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1IN76G2TC11",
//													"attrs": {
//														"tip": {
//															"type": "string",
//															"valText": "Show logs",
//															"localize": {
//																"EN": "Show logs",
//																"CN": "显示日志"
//															},
//															"localizable": true
//														}
//													}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1IN76G2TC12",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1IN76GDJI0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1IN76GDJI1",
//													"attrs": {
//														"style": "\"front\"",
//														"w": "28",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/uirighthide.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1IN76GDJI2",
//													"attrs": {
//														"type": "#null#>BtnIcon(\"front\",28,0,appCfg.sharedAssets+\"/uirighthide.svg\",null)",
//														"id": "BtnHideLog",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "Off",
//														"face": ""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IN76GDJI3",
//													"attrs": {
//														"1IN77GFPB0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IN77H8KT12",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IN77H8KT13",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IN77GFPB0",
//															"faceTagName": "logs"
//														},
//														"1IN77GKHM0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IN77JDLQ2",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IN77JDLQ3",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IN77GKHM0",
//															"faceTagName": "!logs"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IN76GDJI12",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1IN76GDJJ0",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1IN76GDJJ1",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": "1IN9IBNHC0"
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1IN76GDJJ2",
//													"attrs": {
//														"tip": {
//															"type": "string",
//															"valText": "Hide logs",
//															"localize": {
//																"EN": "Hide logs",
//																"CN": "隐藏日志"
//															},
//															"localizable": true
//														}
//													}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1IN76GDJJ3",
//													"attrs": {}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1IN75SB1L1",
//									"attrs": {
//										"1IN77GFPB0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1INJ31JKQ6",
//											"attrs": {
//												"properties": {
//													"jaxId": "1INJ31JKQ7",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IN77GFPB0",
//											"faceTagName": "logs"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1IN75SB1L2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IN75SB1L3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1IN75U18I0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IN76CHN50",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxHtml",
//										"position": "Absolute",
//										"x": "0",
//										"y": "30",
//										"w": "100%",
//										"h": "100%-30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Block"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1IN76CHN51",
//									"attrs": {
//										"1IN77GFPB0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1INJ31JKQ8",
//											"attrs": {
//												"properties": {
//													"jaxId": "1INJ31JKQ9",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IN77GFPB0",
//											"faceTagName": "logs"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1IN76CHN52",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IN76CHN53",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1INJ2MMI20",
//							"attrs": {
//								"properties": {
//									"jaxId": "1INJ2NCO80",
//									"attrs": {
//										"type": "box",
//										"id": "BoxMode",
//										"position": "Absolute",
//										"x": "0",
//										"y": "30",
//										"w": "100%",
//										"h": "30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "Off",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "[255,255,255,1.00]",
//										"border": "[0,0,1,0]",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"attach": "true"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/NaviToolBar.js",
//											"jaxId": "1INJ2NTVK0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1INJ2RE4B0",
//													"attrs": {
//														"tabBG": "true"
//													}
//												},
//												"properties": {
//													"jaxId": "1INJ2RE4B1",
//													"attrs": {
//														"type": "#null#>NaviToolBar(true)",
//														"id": "NaviMode",
//														"position": "Absolute",
//														"x": "0",
//														"y": "1",
//														"display": "On",
//														"face": "\"top\""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1INJ2RE4B2",
//													"attrs": {
//														"1IN77GFPB0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1INJ31JKQ10",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1INJ31JKQ11",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IN77GFPB0",
//															"faceTagName": "logs"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1INJ2RE4B3",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1INJ2RE4B4",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1INJ2RE4B5",
//													"attrs": {
//														"Slot1HL4P0I9P0": {
//															"jaxId": "1INJ2RE4B6",
//															"attrs": {
//																"subHuds": {
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "Gear/@StdUI/ui/BtnNaviItem.js",
//																			"jaxId": "1INJ2PMRR0",
//																			"attrs": {
//																				"createArgs": {
//																					"jaxId": "1INJ2R9PH0",
//																					"attrs": {
//																						"code": "Html",
//																						"text": "HTML Page",
//																						"color": "[0,0,0,1.00]",
//																						"icon": "",
//																						"items": "",
//																						"fontSize": "#txtSize.small",
//																						"hasClose": "false",
//																						"iconSize": "0",
//																						"mark": "true"
//																					}
//																				},
//																				"properties": {
//																					"jaxId": "1INJ2R9PH1",
//																					"attrs": {
//																						"type": "#null#>BtnNaviItem(\"Html\",\"HTML Page\",[0,0,0,1],\"\",undefined,txtSize.small,false,0,true)",
//																						"id": "TabHtml",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"display": "On",
//																						"face": "",
//																						"margin": "[0,6,0,0]"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1INJ2R9PH2",
//																					"attrs": {
//																						"1IN77GFPB0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1INJ31JKQ12",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1INJ31JKQ13",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IN77GFPB0",
//																							"faceTagName": "logs"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1INJ2R9PH3",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1INJ2R9PH4",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "true",
//																				"containerSlots": {
//																					"jaxId": "1INJ2R9PH5",
//																					"attrs": {}
//																				}
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "Gear/@StdUI/ui/BtnNaviItem.js",
//																			"jaxId": "1INJ2RARK0",
//																			"attrs": {
//																				"createArgs": {
//																					"jaxId": "1INJ2RARK1",
//																					"attrs": {
//																						"code": "Code",
//																						"text": "HTML Code",
//																						"color": "[0,0,0,1.00]",
//																						"icon": "",
//																						"items": "",
//																						"fontSize": "#txtSize.small",
//																						"hasClose": "false",
//																						"iconSize": "0",
//																						"mark": "true"
//																					}
//																				},
//																				"properties": {
//																					"jaxId": "1INJ2RARK2",
//																					"attrs": {
//																						"type": "#null#>BtnNaviItem(\"Code\",\"HTML Code\",[0,0,0,1],\"\",undefined,txtSize.small,false,0,true)",
//																						"id": "TabCode",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"display": "On",
//																						"face": ""
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1INJ2RARK3",
//																					"attrs": {
//																						"1IN77GFPB0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1INJ31JKQ14",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1INJ31JKQ15",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1IN77GFPB0",
//																							"faceTagName": "logs"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1INJ2RARK4",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1INJ2RARK5",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "true",
//																				"containerSlots": {
//																					"jaxId": "1INJ2RARK6",
//																					"attrs": {}
//																				}
//																			}
//																		}
//																	]
//																},
//																"container": "true"
//															}
//														}
//													}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1INJ2NCO81",
//									"attrs": {
//										"1IN77GFPB0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1INJ31JKQ16",
//											"attrs": {
//												"properties": {
//													"jaxId": "1INJ31JKQ17",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IN77GFPB0",
//											"faceTagName": "logs"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1INJ2NCO82",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1INJ2NCO83",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1IN76GPTP0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IN76HG1M0",
//									"attrs": {
//										"type": "box",
//										"id": "BoxLogs",
//										"position": "Absolute",
//										"x": "100%-320",
//										"y": "30",
//										"w": "320",
//										"h": "100%-30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "Off",
//										"clip": "Auto Scroll",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "5",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "[255,255,255,1.00]",
//										"border": "[0,0,0,1]",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"contentLayout": "Flex Y"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1IN76HG1M1",
//									"attrs": {
//										"1IN77GKHM0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IN77H8KT22",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IN77H8KT23",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IN77GKHM0",
//											"faceTagName": "!logs"
//										},
//										"1IN77GFPB0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IN77H8KT24",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IN77H8KT25",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IN77GFPB0",
//											"faceTagName": "logs"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1IN76HG1M2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IN76HG1M3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1IN750NA19",
//					"attrs": {
//						"1IN77GFPB0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1INJ31JKQ18",
//							"attrs": {
//								"properties": {
//									"jaxId": "1INJ31JKQ19",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1IN77GFPB0",
//							"faceTagName": "logs"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1IN750NA110",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1IN750NA111",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1IN750NA112",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}