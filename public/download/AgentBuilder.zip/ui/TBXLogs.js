//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnSwitch} from "/@StdUI/ui/BtnSwitch.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
/*#{1IIQA7CBF0StartDoc*/
import {InfoCard} from "/@StdUI/ui/InfoCard.js";
/*}#1IIQA7CBF0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let TBXLogs=function(){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let btnTestAI,boxLogs,boxCode;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1IIQA7CBF1LocalVals*/
	const app=VFACT.app;
	const rootApp=app.appFrame?app.appFrame.app:app;
	let hotLogCard=null;
	let cm=null;
	let cmDoc=null;
	let filterLLM=false;
	/*}#1IIQA7CBF1LocalVals*/
	
	/*#{1IIQA7CBF1PreState*/
	/*}#1IIQA7CBF1PreState*/
	/*#{1IIQA7CBF1PostState*/
	/*}#1IIQA7CBF1PostState*/
	cssVO={
		"hash":"1IIQA7CBF1",nameHost:true,
		"type":"hud","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
		children:[
			{
				"hash":"1IIQA81IB0",
				"type":"box","id":"BoxHeader","x":0,"y":0,"w":"100%","h":30,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["body"],
				"border":[0,0,1,0],"borderColor":cfgColor["fontBodySub"],"contentLayout":"flex-x","itemsAlign":1,
				children:[
					{
						"hash":"1IIQEBQ640",
						"type":"hud","id":"BoxHeaderL","position":"relative","x":0,"y":0,"w":320,"h":"100%","margin":[0,5,0,0],"padding":[0,0,0,5],"minW":"","minH":"","maxW":"",
						"maxH":"","styleClass":"","contentLayout":"flex-x","subAlign":2,"itemsAlign":1,
						children:[
							{
								"hash":"1IJIDDIJL0",
								"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","margin":[0,3,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
								"text":"Only LLM calls","fontSize":txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
							},
							{
								"hash":"1IJIDCN1O0",
								"type":BtnSwitch(18,false),"id":"BtnLLMOnly","position":"relative","x":0,"y":0,
								/*#{1IJIDCN1O0Codes*/
								OnCheck(checked){
									self.filterLLM(checked);
								}
								/*}#1IJIDCN1O0Codes*/
							},
							{
								"hash":"1IJIDF5D60",
								"type":"hud","position":"relative","x":0,"y":0,"w":1,"h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","flex":true,
							},
							{
								"hash":"1IIQECQ7I0",
								"type":BtnIcon("front",26,0,appCfg.sharedAssets+"/trash.svg",null),"id":"BtnClearLogs","position":"relative","x":0,"y":0,
								"tip":(($ln==="CN")?("清除日志"):("Clear logs")),
								"OnClick":function(event){
									self.clearLogs(this,event);
								},
							},
							{
								"hash":"1IIQEDG4J0",
								"type":"box","position":"relative","x":0,"y":0,"w":1,"h":"80%","margin":[0,0,0,5],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["fontBodyLit"],
							}
						],
					},
					{
						"hash":"1IIQEGORE0",
						"type":BtnIcon("front",26,0,appCfg.sharedAssets+"/gas_e.svg",null),"id":"BtnTestAI","position":"relative","x":0,"y":0,"padding":2,"enable":false,
						"tip":(($ln==="CN")?("测试AI调用"):("Test AI call")),
						"OnClick":function(event){
							self.testAICall(this,event);
						},
					}
				],
			},
			{
				"hash":"1IIQAAOPC0",
				"type":"box","id":"BoxLogs","x":0,"y":30,"w":320,"h":">calc(100% - 30px)","overflow":"auto-y","padding":5,"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","background":cfgColor["body"],"border":[0,1,0,0],"borderColor":cfgColor["fontBodySub"],"contentLayout":"flex-y",
			},
			{
				"hash":"1IIQAD6400",
				"type":"hud","id":"BoxCode","x":320,"y":30,"w":">calc(100% - 320px)","h":">calc(100% - 30px)","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"traceSize":true,
				"OnSize":function(){
					self.boxCodeOnSize(this);
				},
			}
		],
		/*#{1IIQA7CBF1ExtraCSS*/
		/*}#1IIQA7CBF1ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			self=this;
			btnTestAI=self.BtnTestAI;boxLogs=self.BoxLogs;boxCode=self.BoxCode;
			/*#{1IIQA7CBF1Create*/
			app.uiLogs=self;
			self.initCode();
			app.on("AIAgentExec",(agentJaxId,agent,input)=>{
				let log={
					type: "StartAgent",
					agent: agent?agent.jaxId:agentJaxId,
					name:agent.name,
					url:agent.url,
					input:input,
					sourceDef:agent.sourceDef
				};
				self.addLog(log);
			});
			app.on("AIAgentEnd",(agentJaxId,agent,result)=>{
				let log={
					type: "EndAgent",
					agent: agent?agent.jaxId:agentJaxId,
					name:agent.name,
					url:agent.url,
					result:result
				};
				self.addLog(log);
			});
			app.on("AISegExec",(agentJaxId,fromSegId,outletId,segJaxId,input,callId,seg)=>{
				let log={
					type: "StartSeg",
					agent: agentJaxId,
					jaxId:segJaxId,
					seg:seg,
					name:seg?seg.name:"seg",
					url:seg?seg.url:"",
					input:input,
					fromSeg:fromSegId,
					fromOutlet:outletId
				};
				self.addLog(log);
			});
			app.on("AISegEnd",(seg)=>{
				let log={
					type: "EndSeg",
					seg:seg
				};
				self.addLog(log);
			});
			app.on("AISegCatch",(agentId,frameId,error)=>{
				let applog={
					type: "CatchError",
					agent:agentId,
					frameId:frameId,
					error:error
				};
				self.addLog(applog);
			});
			app.on("AIDebugLog",(agentId,segId,log)=>{
				let applog={
					type: "DebugLog",
					agent:agentId,
					seg:segId,
					log:log
				};
				self.addLog(applog);
			});
			app.on("AISegCallLLMInput",(agentJaxId,segJaxId,prompt,callId,opts,messages)=>{
				let applog={
					type: "LlmCall",
					agent:agentJaxId,
					seg:segJaxId,
					code:prompt,
					options:opts,
					messages:messages
				};
				self.addLog(applog);
			});
			app.on("AISegCallLLMResult",(agentJaxId,segJaxId,result,callId,tokenUsage,opts,messages)=>{
				let applog={
					type: "LlmResult",
					agent:agentJaxId,
					seg:segJaxId,
					options:opts,
					code:result,
					messages:messages,
					result:result
				};
				self.addLog(applog);
			});
			/*}#1IIQA7CBF1Create*/
		},
		/*#{1IIQA7CBF1EndCSS*/
		/*}#1IIQA7CBF1EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.addLog=async function(log){
		/*#{1IIQAKARJ0Start*/
		switch(log.type){
			case "StartAgent":{
				let info,icon,css;
				icon=appCfg.sharedAssets+("/fat_down.svg");
				info=JSON.stringify(log.input)||"";
				css={
					type:InfoCard(`${log.name}: [${log.frameId}]`,info.substring(0,128),null,icon,24,24),position:"relative",x:0,y:0,w:"100%",display:filterLLM?false:true,
					border:1,sizeCap:14,sizeLabel:12,margin:[5,0,5,0],log:log,
					OnClick(){
						self.focusLog(this,log);
						return false;
					}
				};
				boxLogs.appendNewChild(css);
				break;
			}
			case "EndAgent":{
				let info,icon,css;
				icon=appCfg.sharedAssets+("/fat_up.svg");
				info=JSON.stringify(log.result)||"";
				css={
					type:InfoCard(log.name,info.substring(0,128),null,icon,24,24),position:"relative",x:0,y:0,w:"100%",display:filterLLM?false:true,
					border:1,sizeCap:14,sizeLabel:12,margin:[5,0,5,0],log:log,
					OnClick(){
						self.focusLog(this,log);
						return false;
					}
				};
				boxLogs.appendNewChild(css);
				break;
			}
			case "StartSeg":{
				let seg,info,icon,css;
				seg=log.seg;
				if(seg.jaxId){
					icon=appCfg.sharedAssets+("/arrowright.svg");
					info=JSON.stringify(seg.input)||"";
					css={
						type:InfoCard(seg.name,info.substring(0,128),null,icon,24,24),position:"relative",x:0,y:0,w:"100%",display:filterLLM?false:true,
						border:1,sizeCap:14,sizeLabel:12,margin:[5,0,5,0],log:log,
						OnClick(){
							self.focusLog(this,log);
							return false;
						}
					};
					boxLogs.appendNewChild(css);
				}
				break;
			}
			case "EndSeg":{
				let seg,info,icon,css;
				seg=log.seg;
				if(seg.jaxId){
					icon=appCfg.sharedAssets+("/arrowleft.svg");
					info=JSON.stringify(seg.result)||"";
					css={
						type:InfoCard(seg.name,info.substring(0,128),null,icon,24,24),position:"relative",x:0,y:0,w:"100%",display:filterLLM?false:true,
						border:1,sizeCap:14,sizeLabel:12,margin:[5,0,5,0],log:log,
						OnClick(){
							self.focusLog(this,log);
							return false;
						}
					};
					boxLogs.appendNewChild(css);
				}
				break;
			}
			case "CatchError":{
				let jaxId,url,icon,info,css;
				jaxId=log.agent;
				icon=appCfg.sharedAssets+("/help.svg");
				info=log.error;
				css={
					type:InfoCard("Catched Error",info.substring(0,128),null,icon,24,24),position:"relative",x:0,y:0,w:"100%",
					border:1,sizeCap:14,sizeLabel:12,margin:[5,0,5,0],log:log,
					OnClick(){
					}
				};
				boxLogs.appendNewChild(css);
				break;
			}
			case "LlmCall":{
				let options,icon,css;
				options=log.options;
				icon=appCfg.sharedAssets+("/aichat.svg");
				css={
					type:InfoCard(options.mode||options.model,log.code,null,icon,24,24),position:"relative",x:0,y:0,w:"100%",display:filterLLM?false:true,
					border:1,sizeCap:14,sizeLabel:12,margin:[5,0,5,0],log:log,
					OnClick(){
						self.focusLog(this,log);
						return false;
					}
				};
				//Emit app message
				boxLogs.appendNewChild(css);
				break;
			}
			case "LlmResult":{
				let options,icon,css;
				options=log.options;
				icon=appCfg.sharedAssets+("/agent.svg");
				css={
					type:InfoCard(options.mode||options.model,log.code,null,icon,24,24),position:"relative",x:0,y:0,w:"100%",
					border:1,sizeCap:14,sizeLabel:12,margin:[5,0,5,0],log:log,
					OnClick(){
						self.focusLog(this,log);
						return false;
					}
				};
				boxLogs.appendNewChild(css);
				break;
			}
			case "DebugLog":{
				let icon,css,info;
				icon=appCfg.sharedAssets+("/read.svg");
				info=JSON.stringify(log.log)||"";
				css={
					type:InfoCard("Log",info,null,icon,24,24),position:"relative",x:0,y:0,w:"100%",display:filterLLM?false:true,
					border:1,sizeCap:14,sizeLabel:12,margin:[5,0,5,0],log:log,
					OnClick(){
						self.focusLog(this,log);
						return false;
					}
				};
				boxLogs.appendNewChild(css);
				break;
			}
		}
		self.scrollLogs();
		/*}#1IIQAKARJ0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.scrollLogs=async function(){
		/*#{1IIQAKQPC0Start*/
		let webObj;
		webObj=boxLogs.webObj;
		webObj.scrollTop = webObj.scrollHeight;		
		/*}#1IIQAKQPC0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.focusLog=async function(card,log){
		/*#{1IIQALF4M0Start*/
		let codes;
		if(hotLogCard===card){
			return;
		}
		if(hotLogCard){
			hotLogCard.uiEvent=1;
			hotLogCard.showFace("blur");
		}
		hotLogCard=card;
		if(!card){
			if(cmDoc){
				cmDoc.setValue("");
			}
			return;
		}
		card.uiEvent=-1;
		card.showFace("focus");
		codes="";
		switch(log.type){
			case "StartAgent":{
				btnTestAI.enable=false;
				break;
			}
			case "EndAgent":{
				btnTestAI.enable=false;
				break;
			}
			case "EndSeg":
			case "StartSeg":{
				let seg;
				seg=log.seg;
				codes=`[AISeg]:\n${seg.url}\n`;
				if(seg.input){
					codes+=`[Input]\n`;
					codes+=JSON.stringify(seg.input,null,"\t")+"\n";
				}
				if(seg.result){
					codes+=`[Result]\n`;
					codes+=JSON.stringify(seg.result,null,"\t")+"\n";
				}
				btnTestAI.enable=false;
				break;
			}
			case "LlmCall":
			case "LlmResult":{
				let opts,messages,result;
				let msg;
				opts=log.options;
				messages=log.messages;
				codes="[LLM-call options]\n";
				codes+=JSON.stringify(opts,null,"\t");codes+="\n\n";
				codes+="[LLM-call Messages]\n";
				for(msg of messages){
					codes+=`<${msg.role}>\n`;
					codes+=msg.content+"\n";
					if(msg.image){
						codes+="[Image]\n";
					}
					codes+="\n";
				}
				result=log.result;
				if(result){
					codes+="\n[LLM-call result]\n";
					codes+=log.result;
				}
				btnTestAI.enable=true;
				break;
			}
			case "DebugLog":{
				codes+=`[Log]\n`;
				if(typeof(log.log)==="string"){
					codes+=log.log;
				}else{
					codes+=JSON.stringify(log.log,null,"\t")+"\n";
				}
				btnTestAI.enable=false;
				break;
			}
			default:{
				btnTestAI.enable=false;
			}
		}
		if(cmDoc){
			cmDoc.setValue(codes);
		}
		/*}#1IIQALF4M0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.clearLogs=async function(){
		/*#{1IIQC42PB0Start*/
		boxLogs.clearChildren();
		hotLogCard=null;
		if(cmDoc){
			cmDoc.setValue("");
		}
		/*}#1IIQC42PB0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.boxCodeOnSize=async function(sender){
		/*#{1IIQCNT2M0Start*/
		if(cm){
			cm.refresh();
		}
		/*}#1IIQCNT2M0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.initCode=async function(){
		/*#{1IIQCBU1Q0Start*/
		if(!window.CodeMirror){
			await VFACT.appendScript("/@codemirror/lib/codemirror.js");
			await VFACT.appendCSS("/@codemirror/lib/codemirror.css");
			setTimeout(()=>{
				self.initCode();
			},200);
			return;
		}
		cm=CodeMirror(boxCode.webObj, {
			value:"",
			mode:"text/plain",
			lineNumbers:true,
			undoDepth:20
		});
		cmDoc=cm.getDoc();
		/*}#1IIQCBU1Q0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.testAICall=async function(sender,event){
		/*#{1IIQEJFMM0Start*/
		await app.modalDlg("/@StdUI/ui/DlgLLMCall.js",{title:(($ln==="CN")?("测试AI调用"):/*EN*/("Test AI Call")),log:hotLogCard.log});
		/*}#1IIQEJFMM0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.filterLLM=async function(filter){
		/*#{1IJIDMARH0Start*/
		let list,i,n,line,log;
		filterLLM=filter;
		list=boxLogs.children;
		n=list.length;
		if(filter){
			for(i=0;i<n;i++){
				line=list[i];
				log=line.log;
				if(log && log.type==="LlmResult"){
					line.display=true;
				}else{
					line.display=false;
				}
			}
		}else{
			for(i=0;i<n;i++){
				line=list[i];
				line.display=true;
			}
		}
		/*}#1IJIDMARH0Start*/
	};
	/*#{1IIQA7CBF1PostCSSVO*/
	/*}#1IIQA7CBF1PostCSSVO*/
	cssVO.constructor=TBXLogs;
	return cssVO;
};
/*#{1IIQA7CBF1ExCodes*/
/*}#1IIQA7CBF1ExCodes*/

//----------------------------------------------------------------------------
TBXLogs.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1IIQA7CBF1PreAISpot*/
	/*}#1IIQA7CBF1PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1IIQA7CBF1PostAISpot*/
	/*}#1IIQA7CBF1PostAISpot*/
	return exposeVO;
};

//----------------------------------------------------------------------------
TBXLogs.gearExport={
	framework: "jax",
	hudType: "hud",
	"showName":"",icon:"gears.svg",previewImg:false,
	fixPose:false,initW:100,initH:100,
	catalog:"",
	args: {},
	state:{
	},
	properties:["id","position","x","y","display"],
	faces:[],
	subContainers:{
	},
	/*#{1IIQA7CBF0ExGearInfo*/
	/*}#1IIQA7CBF0ExGearInfo*/
};
/*#{1IIQA7CBF0EndDoc*/
/*}#1IIQA7CBF0EndDoc*/

export default TBXLogs;
export{TBXLogs};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1IIQA7CBF0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1IIQA7CBF2",
//			"attrs": {
//				"device": "Desktop 800x600",
//				"screenW": "800",
//				"screenH": "600",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1IIQA7CBF3",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1IIQA7CBF4",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1IIQA7CBF5",
//			"attrs": {}
//		},
//		"localVars": {
//			"jaxId": "1IIQA7CBF6",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1IIQA7CBF7",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IIQAKARJ0",
//					"attrs": {
//						"id": "addLog",
//						"label": "New AI Seg",
//						"x": "65",
//						"y": "70",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IIQAKP340",
//							"attrs": {
//								"log": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IIQAKP341",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IIQAKP342",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IIQAKQPC0",
//					"attrs": {
//						"id": "scrollLogs",
//						"label": "New AI Seg",
//						"x": "65",
//						"y": "150",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IIQAN16I0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IIQAN16I1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IIQAN16I2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IIQALF4M0",
//					"attrs": {
//						"id": "focusLog",
//						"label": "New AI Seg",
//						"x": "65",
//						"y": "235",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IIQAN16I3",
//							"attrs": {
//								"card": {
//									"type": "auto",
//									"valText": ""
//								},
//								"log": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IIQAN16I4",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IIQAN16I5",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IIQC42PB0",
//					"attrs": {
//						"id": "clearLogs",
//						"label": "New AI Seg",
//						"x": "65",
//						"y": "325",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IIQC49CJ0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IIQC49CJ1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IIQC49CJ2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IIQCNT2M0",
//					"attrs": {
//						"id": "boxCodeOnSize",
//						"label": "New AI Seg",
//						"x": "65",
//						"y": "495",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IIQCO9220",
//							"attrs": {
//								"sender": {
//									"valText": "null"
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IIQCO9221",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IIQCO9222",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IIQCBU1Q0",
//					"attrs": {
//						"id": "initCode",
//						"label": "New AI Seg",
//						"x": "65",
//						"y": "410",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IIQCCE670",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IIQCCE671",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IIQCCE672",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IIQEJFMM0",
//					"attrs": {
//						"id": "testAICall",
//						"label": "New AI Seg",
//						"x": "65",
//						"y": "580",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IIQEJVTE0",
//							"attrs": {
//								"sender": {
//									"valText": "null"
//								},
//								"event": {
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IIQEJVTE1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IIQEJVTE2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IJIDMARH0",
//					"attrs": {
//						"id": "filterLLM",
//						"label": "New AI Seg",
//						"x": "65",
//						"y": "660",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IJIDMRR00",
//							"attrs": {
//								"filter": {
//									"type": "bool",
//									"valText": "false"
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IJIDMRR01",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IJIDMRR02",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				}
//			]
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1IIQA7CBF8",
//			"attrs": {}
//		},
//		"mockupStates": {
//			"jaxId": "1IIQA7CBF9",
//			"attrs": {}
//		},
//		"exposeToAI": "true",
//		"descAI": "",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1IIQA7CBF1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1IIQA7CBF10",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "100%",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": ""
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1IIQA81IB0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IIQA8SF30",
//									"attrs": {
//										"type": "box",
//										"id": "BoxHeader",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"body\"]",
//										"border": "[0,0,1,0]",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor[\"fontBodySub\"]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"contentLayout": "Flex X",
//										"itemsAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1IIQEBQ640",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IIQEFIKH0",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxHeaderL",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "320",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[0,5,0,0]",
//														"padding": "[0,0,0,5]",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex X",
//														"subAlign": "End",
//														"itemsAlign": "Center"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1IJIDDIJL0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IJIDFTGC0",
//																	"attrs": {
//																		"type": "text",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[0,3,0,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontBody\"]",
//																		"text": "Only LLM calls",
//																		"font": "",
//																		"fontSize": "#txtSize.smallPlus",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Top",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"lineClamp": "0",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IJIDFTGC1",
//																	"attrs": {}
//																},
//																"functions": {
//																	"jaxId": "1IJIDFTGC2",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1IJIDFTGC3",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnSwitch.js",
//															"jaxId": "1IJIDCN1O0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1IJIDFTGC4",
//																	"attrs": {
//																		"size": "18",
//																		"check": "false"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1IJIDFTGC5",
//																	"attrs": {
//																		"type": "#null#>BtnSwitch(18,false)",
//																		"id": "BtnLLMOnly",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IJIDFTGC6",
//																	"attrs": {}
//																},
//																"functions": {
//																	"jaxId": "1IJIDFTGC7",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1IJIDFTGC8",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "true",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1IJIDFTGC9",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1IJIDF5D60",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IJIDFTGC10",
//																	"attrs": {
//																		"type": "hud",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "1",
//																		"h": "100%",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"flex": "true"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IJIDFTGC11",
//																	"attrs": {}
//																},
//																"functions": {
//																	"jaxId": "1IJIDFTGC12",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1IJIDFTGC13",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false",
//																"exposeContainer": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1IIQECQ7I0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1IIQECQ7I1",
//																	"attrs": {
//																		"style": "\"front\"",
//																		"w": "26",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/trash.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1IIQECQ7I2",
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"front\",26,0,appCfg.sharedAssets+\"/trash.svg\",null)",
//																		"id": "BtnClearLogs",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IIQECQ7I3",
//																	"attrs": {}
//																},
//																"functions": {
//																	"jaxId": "1IIQECQ7I4",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1IIQEGKTK0",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1IIQEGKTK1",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": "1IIQC42PB0"
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1IIQECQ7I5",
//																	"attrs": {
//																		"tip": {
//																			"type": "string",
//																			"valText": "Clear logs",
//																			"localize": {
//																				"EN": "Clear logs",
//																				"CN": "清除日志"
//																			},
//																			"localizable": true
//																		}
//																	}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1IIQECQ7I6",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "box",
//															"jaxId": "1IIQEDG4J0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IIQEFIKH1",
//																	"attrs": {
//																		"type": "box",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "1",
//																		"h": "80%",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[0,0,0,5]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"background": "#cfgColor[\"fontBodyLit\"]",
//																		"border": "0",
//																		"borderStyle": "Solid",
//																		"borderColor": "[0,0,0,1.00]",
//																		"corner": "0",
//																		"shadow": "false",
//																		"shadowX": "2",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowSpread": "0",
//																		"shadowColor": "[0,0,0,0.50]"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IIQEFIKH2",
//																	"attrs": {}
//																},
//																"functions": {
//																	"jaxId": "1IIQEFIKH3",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1IIQEFIKH4",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false"
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1IIQEFIKH5",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1IIQEFIKH6",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IIQEFIKH7",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1IIQEGORE0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1IIQEGORE1",
//													"attrs": {
//														"style": "\"front\"",
//														"w": "26",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/gas_e.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1IIQEGORF0",
//													"attrs": {
//														"type": "#null#>BtnIcon(\"front\",26,0,appCfg.sharedAssets+\"/gas_e.svg\",null)",
//														"id": "BtnTestAI",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"padding": "2",
//														"enable": "false"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IIQEGORF1",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1IIQEGORF2",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1IIQEGORF3",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1IIQEGORF4",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": "1IIQEJFMM0"
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1IIQEGORF5",
//													"attrs": {
//														"tip": {
//															"type": "string",
//															"valText": "Test AI call",
//															"localize": {
//																"EN": "Test AI call",
//																"CN": "测试AI调用"
//															},
//															"localizable": true
//														}
//													}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1IIQEGORF6",
//													"attrs": {}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1IIQA8SF31",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1IIQA8SF32",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IIQA8SF33",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1IIQAAOPC0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IIQAC2EI0",
//									"attrs": {
//										"type": "box",
//										"id": "BoxLogs",
//										"position": "Absolute",
//										"x": "0",
//										"y": "30",
//										"w": "320",
//										"h": "100%-30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Auto Scroll Y",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "5",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"body\"]",
//										"border": "[0,1,0,0]",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor[\"fontBodySub\"]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"contentLayout": "Flex Y"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1IIQAC2EI1",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1IIQAC2EI2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IIQAC2EI3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1IIQAD6400",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IIQAE0BL0",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxCode",
//										"position": "Absolute",
//										"x": "320",
//										"y": "30",
//										"w": "100%-320",
//										"h": "100%-30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"traceSize": "true"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1IIQAE0BL1",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1IIQAE0BL2",
//									"attrs": {
//										"OnSize": {
//											"type": "fixedFunc",
//											"jaxId": "1IIQCO9223",
//											"attrs": {
//												"callArgs": {
//													"jaxId": "1IIQCO9224",
//													"attrs": {}
//												},
//												"seg": "1IIQCNT2M0"
//											}
//										}
//									}
//								},
//								"extraPpts": {
//									"jaxId": "1IIQAE0BL3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1IIQA7CBF11",
//					"attrs": {}
//				},
//				"functions": {
//					"jaxId": "1IIQA7CBF12",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1IIQA7CBF13",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1IIQA7CBF14",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}