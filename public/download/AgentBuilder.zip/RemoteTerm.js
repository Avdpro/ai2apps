import {makeObjEventEmitter,makeNotify} from "/@events";
import {Terminal} from './xterm.js';

//****************************************************************************
//Remote terminal:
//****************************************************************************
let RemoteTerm,remoteTerm;
{
	RemoteTerm=function (sessionId,element,host){
		this.host=host||`ws://${document.location.host}`;
		this.sessionId=sessionId;
		this.element=element;
		this.terminal=null;
		makeNotify(this);
	};
	remoteTerm=RemoteTerm.prototype={};

	//----------------------------------------------------------------------------
	remoteTerm.start=async function(){
		let terminal,callback,callerror;
		const self = this;

		//Create terminal with default size first
		terminal=this.terminal = new Terminal({
			allowTransparency: true,
			fontSize: 12,
			convertEol: false,
			//cursorBlink:true,
			//mouseEvents: true,
			selectMode: true,
			theme: {
				background: '#ffffff',
				foreground: '#000000',
				cursor: '#000000',
				selectionBackground:'#00A0FF3A'
			},
		});
		terminal.open(this.element);

		// Function to calculate and resize terminal
		const calculateAndResize = () => {
			const charWidth = 7.2;
			const charHeight = 14.4;
			const elementWidth = this.element.clientWidth || 720;
			const elementHeight = this.element.clientHeight || 432;
			const cols = Math.max(80, Math.floor(elementWidth / charWidth));
			const rows = Math.max(24, Math.floor(elementHeight / charHeight));

			console.log(`Terminal size: ${cols}x${rows} (element: ${elementWidth}x${elementHeight}px)`);
			console.log(`Element computed style:`, window.getComputedStyle(this.element).width, 'x', window.getComputedStyle(this.element).height);
			console.log(`Window size:`, window.innerWidth, 'x', window.innerHeight);
			console.log(`Parent element:`, this.element.parentElement?.tagName, this.element.parentElement?.clientWidth, 'x', this.element.parentElement?.clientHeight);

			// Resize the terminal
			terminal.resize(cols, rows);

			// Send resize message to server if connected
			if(self.ws && self.ws.readyState === WebSocket.OPEN){
				self.ws.send(JSON.stringify({
					msg:"Resize",
					session:self.sessionId,
					cols: cols,
					rows: rows
				}));
			}

			return {cols, rows};
		};

		// Initial resize after DOM settles
		await new Promise(resolve => setTimeout(resolve, 50));
		const initialSize = calculateAndResize();

		// Listen for window resize events
		let resizeTimeout;
		const onResize = () => {
			clearTimeout(resizeTimeout);
			resizeTimeout = setTimeout(() => {
				calculateAndResize();
			}, 200); // Debounce resize events
		};
		window.addEventListener('resize', onResize);

		// Create WebSocket:
		const ws = self.ws = new WebSocket(this.host);
		ws.onopen = () => {
			console.log('Connected to the server');
			// 发送连接消息，包含终端尺寸信息
			ws.send(JSON.stringify({
				msg:"CONNECT",
				selector:this.sessionId,
				cols: initialSize.cols,
				rows: initialSize.rows
			}));
		};
		ws.onmessage = (msg) => {
			let msgVO,msgCode;
			console.log("Message from remote session:");
			console.log(msg)
			msgVO=JSON.parse(msg.data);
			msgCode=msgVO.msg;
			if(!this.isConnected){
				if(msgCode==="CONNECTED"){
					let call;
					this.isConnected=true;
					//Notify into chat session:
					call=callback;
					if(call){
						callback=null;
						callerror=null;
						call();
					}
					console.log("Remote terminal ready.");
					this.emitNotify("Connected");
				}
			}else{
				if(msgCode==="Data"){
					let data = msgVO.data;
					// 直接写入，不做任何修改
					terminal.write(data);
					this.emitNotify("Data");
				}
			}
		};

		ws.onclose = () => {
			console.log('Disconnected from the server');
			this.emitNotify("Disconnected");
		};
		terminal.onData((data)=>{
			let message;
			message={
				msg:"Data",
				data:data,
				session:this.sessionId
			};
			ws.send(JSON.stringify(message));
		});

	};
}
export default RemoteTerm;
export {RemoteTerm};