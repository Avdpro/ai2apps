import {makeObjEventEmitter,makeNotify} from "/@events";
import {Terminal} from './xterm.js';

//****************************************************************************
//Remote terminal:
//****************************************************************************
let RemoteTerm,remoteTerm;
{
	RemoteTerm=function (sessionId,element,host){
		this.host=host||`ws://${document.location.host}`;
		this.sessionId=sessionId;
		this.element=element;
		this.terminal=null;
		makeNotify(this);
	};
	remoteTerm=RemoteTerm.prototype={};

	//----------------------------------------------------------------------------
	remoteTerm.start=async function(){
		let terminal,callback,callerror;

		//Create terminal
		terminal=this.terminal = new Terminal({
			//cols: 380,
			//wordWrap: false,
			allowTransparency: true,
			fontSize: 12,
			//cursorBlink:true,
			//mouseEvents: true,
			selectMode: true,
			theme: {
				background: '#ffffff',
				foreground: '#000000',
				cursor: '#000000',
			},
		});
		terminal.open(this.element);

		// Create WebSocket:
		const ws = new WebSocket(this.host);
		ws.onopen = () => {
			console.log('Connected to the server');
			ws.send(JSON.stringify({msg:"CONNECT",selector:this.sessionId}));
		};
		ws.onmessage = (msg) => {
			let msgVO,msgCode;
			console.log("Message from remote session:");
			console.log(msg)
			msgVO=JSON.parse(msg.data);
			msgCode=msgVO.msg;
			if(!this.isConnected){
				if(msgCode==="CONNECTED"){
					let call;
					this.isConnected=true;
					//Notify into chat session:
					call=callback;
					if(call){
						callback=null;
						callerror=null;
						call();
					}
					console.log("Remote terminal ready.");
					this.emitNotify("Connected");
				}
			}else{
				if(msgCode==="Data"){
					terminal.write(msgVO.data);
					this.emitNotify("Data");
				}
			}
		};

		ws.onclose = () => {
			console.log('Disconnected from the server');
			this.emitNotify("Disconnected");
		};
		terminal.onData((data)=>{
			let message;
			message={
				msg:"Data",
				data:data,
				session:this.sessionId
			};
			ws.send(JSON.stringify(message));
		});

	};
}
export default RemoteTerm;
export {RemoteTerm};
