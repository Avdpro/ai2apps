import {makeObjEventEmitter,makeNotify} from "/@events";
import {Terminal} from './xterm.js';

//****************************************************************************
//Remote terminal:
//****************************************************************************
let RemoteTerm,remoteTerm;
{
	RemoteTerm=function (sessionId,element,host){
		this.host=host||`ws://${document.location.host}`;
		this.sessionId=sessionId;
		this.element=element;
		this.terminal=null;
		makeNotify(this);
	};
	remoteTerm=RemoteTerm.prototype={};

	//----------------------------------------------------------------------------
	remoteTerm.start=async function(){
		let terminal,callback,callerror;
		const self = this;

		//Create terminal with default size first
		terminal=this.terminal = new Terminal({
			allowTransparency: true,
			fontSize: 12,
			convertEol: false,
			//cursorBlink:true,
			//mouseEvents: true,
			selectMode: true,
			theme: {
				background: '#ffffff',
				foreground: '#000000',
				cursor: '#000000',
				selectionBackground:'#00A0FF3A'
			},
		});
		terminal.open(this.element);

		// Function to calculate and resize terminal
		const calculateAndResize = () => {
			const charWidth = 7.2;
			const charHeight = 14.4;
			const elementWidth = this.element.clientWidth || 720;
			const elementHeight = this.element.clientHeight || 432;
			const cols = Math.max(80, Math.floor(elementWidth / charWidth));
			const rows = Math.max(24, Math.floor(elementHeight / charHeight));

			console.log(`==> Terminal size: ${cols}x${rows} (element: ${elementWidth}x${elementHeight}px)`);

			// Resize the terminal
			terminal.resize(cols, rows);

			// Send resize message to server if connected
			if(self.ws && self.ws.readyState === WebSocket.OPEN){
				console.log(`==> Sending resize to server: ${cols}x${rows}`);
				self.ws.send(JSON.stringify({
					msg:"Resize",
					session:self.sessionId,
					cols: cols,
					rows: rows
				}));
			}

			return {cols, rows};
		};

		// Use ResizeObserver to watch for container size changes
		let resizeObserverTimeout;
		const resizeObserver = new ResizeObserver((entries) => {
			clearTimeout(resizeObserverTimeout);
			resizeObserverTimeout = setTimeout(() => {
				for (let entry of entries) {
					console.log('==> Container resized by ResizeObserver');
					calculateAndResize();
				}
			}, 100);
		});
		resizeObserver.observe(this.element);
		await new Promise(resolve => setTimeout(resolve, 100));
		let initialSize = calculateAndResize();
		const ws = self.ws = new WebSocket(this.host);
		ws.onopen = () => {
			ws.send(JSON.stringify({
				msg:"CONNECT",
				selector:this.sessionId
			}));
			setTimeout(() => {
				const currentCols = terminal.cols;
				const currentRows = terminal.rows;
				ws.send(JSON.stringify({
					msg:"Resize",
					session:self.sessionId,
					cols: currentCols,
					rows: currentRows
				}));
			}, 200);
		};

		ws.onmessage = (msg) => {
			let msgVO,msgCode;
			msgVO=JSON.parse(msg.data);
			msgCode=msgVO.msg;
			if(!this.isConnected){
				if(msgCode==="CONNECTED"){
					let call;
					this.isConnected=true;
					setTimeout(() => {
						calculateAndResize();
					}, 100);
					call=callback;
					if(call){
						callback=null;
						callerror=null;
						call();
					}
					this.emitNotify("Connected");
				}
			}else{
				if(msgCode==="Data"){
					let data = msgVO.data;
					terminal.write(data);
					this.emitNotify("Data");
				}
			}
		};

		ws.onclose = () => {
			console.log('==> Disconnected from the server');
			resizeObserver.disconnect();
			this.emitNotify("Disconnected");
		};

		terminal.onData((data)=>{
			let message;
			message={
				msg:"Data",
				data:data,
				session:this.sessionId
			};
			ws.send(JSON.stringify(message));
		});

	};
}
export default RemoteTerm;
export {RemoteTerm};