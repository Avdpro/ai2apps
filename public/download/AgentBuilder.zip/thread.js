//Auto genterated by Cody
import {tabOS,tabFS,tabTask} from "/@tabos";
import {VFACT} from "/@vfact";
import {} from "/@vfact/vfact_app.js";
import{appCfg} from "./cfg/appCfg.js";
/*#{MoreImports*/
import {AppLib} from "/@homekit/data/AppLib.js";
import pathLib from "/@path";
import {ShadowUI} from "./ui/ShadowUI.js";
/*}#MoreImports*/
VFACT.appCfg=appCfg;
/*#{StartApp*/
/*}#StartApp*/
//----------------------------------------------------------------------------
//Start the app:
async function startApp() {
	/*#{AppCode*/
	let app,uiDef;
	
	document.title="Tab-OS App";
	//------------------------------------------------------------------------
	//Check if we are in appFrame:
	let appFrame=null;
	//CheckAppFrame:
	{
		let pw;
		appFrame=null;
		pw=window.parent;
		if(pw!==window){
			if(pw.getAppFrame){
				appFrame=window.appFrame=pw.getAppFrame(window);
			}
		}
	}
	window.tabOSApp=app=await VFACT.createApp();
	
	//setup open (openPath, openMeta...) API:
	await AppLib.setupOpenAPI(app,appFrame);
	
	uiDef=ShadowUI(app,appFrame);
	if(!appFrame){
		//uiDef=AppLib.setupMiniDocker(app,uiDef);
	}
	//init app, create app UI tree:
	await VFACT.initApp(app,uiDef,{
		wait:1,
		shortcuts:appCfg.shortcuts,
		appFrame:appFrame,
	});
	/*}#AppCode*/
}
tabOS.setup().then(()=>{startApp();});
/*#{EndDoc*/
/*}#EndDoc*/
