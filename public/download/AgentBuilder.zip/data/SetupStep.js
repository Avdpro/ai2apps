//Auto genterated by Cody
import VFACT from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1IGIKACEN0StartDoc*/
/*}#1IGIKACEN0StartDoc*/
let SetupStep={
	name:"SetupStep",//1IGIKACEN2
	type:"object",
	label:"SetupStep",
	properties:{
		action:{
			name:"action",type:"string",
			choices:[
				"Command","LookUpIssue","Search","Abort","Finish"
			],
			desc:"下一步的步骤动作",
		},
		content:{
			name:"content",type:"string",
			required:false,
			desc:"该步骤的说明",
		},
		commands:{
			name:"commands",type:"array",
			initLength:0,
			element:{
				"type":"string","label":'###:'
			},
			desc:"这个步骤要执行的命令行指令数组，如果没有要执行的指令，设置为空数组。",
		},
		assets:{
			name:"assets",type:"array",
			initLength:0,
			element:{
				"type":"string","label":'###:'
			},
			desc:"如果该步骤包含给用户的附件文件，这个数组里是文件URL/路径列表。如果没有附件，设置为空数组。",
		},
		/*#{1IGIKACEN2MoreProperties*/
		/*}#1IGIKACEN2MoreProperties*/
	},
	desc:"执行安装配置工程项目的步骤/输出",
	newObject(){return VFACT.newUITemplateObj(this)},
	/*#{1IGIKACEN2MoreFunctions*/
	/*}#1IGIKACEN2MoreFunctions*/
};
VFACT.regUITemplate("1IGIKACEN2",SetupStep);
VFACT.regUITemplate("SetupStep",SetupStep);
/*#{1IGIKACEN2MoreCodes*/
/*}#1IGIKACEN2MoreCodes*/

/*#{1IGIKACEN0EndDoc*/
/*}#1IGIKACEN0EndDoc*/

export{SetupStep};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DataDoc",
//	"jaxId": "1IGIKACEN0",
//	"attrs": {
//		"editObjs": {
//			"jaxId": "1IGIKACEN1",
//			"attrs": {
//				"SetupStep": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1IGIKACEN2",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1IGIKACEO0",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1IGIKACEO1",
//							"attrs": {
//								"action": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1IGIMBSPP0",
//									"attrs": {
//										"type": "string",
//										"desc": "下一步的步骤动作",
//										"choices": {
//											"type": "array",
//											"def": "Array",
//											"attrs": [
//												{
//													"type": "string",
//													"valText": "Command"
//												},
//												{
//													"type": "string",
//													"valText": "LookUpIssue"
//												},
//												{
//													"type": "string",
//													"valText": "Search"
//												},
//												{
//													"type": "string",
//													"valText": "Abort"
//												},
//												{
//													"type": "string",
//													"valText": "Finish"
//												}
//											]
//										}
//									}
//								},
//								"content": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1IGIMBSPP1",
//									"attrs": {
//										"type": "string",
//										"required": "false",
//										"desc": "该步骤的说明"
//									}
//								},
//								"commands": {
//									"type": "object",
//									"def": "EditClassAryPpt",
//									"jaxId": "1IGIMBSPP2",
//									"attrs": {
//										"type": "array",
//										"element": {
//											"jaxId": "1IGIMBSPP3",
//											"attrs": {
//												"type": "String",
//												"label": "#'###:'"
//											}
//										},
//										"initLength": "0",
//										"desc": "这个步骤要执行的命令行指令数组，如果没有要执行的指令，设置为空数组。"
//									}
//								},
//								"assets": {
//									"type": "object",
//									"def": "EditClassAryPpt",
//									"jaxId": "1IGIMBSPP4",
//									"attrs": {
//										"type": "array",
//										"element": {
//											"jaxId": "1IGIMBSPP5",
//											"attrs": {
//												"type": "String",
//												"label": "#'###:'"
//											}
//										},
//										"initLength": "0",
//										"desc": "如果该步骤包含给用户的附件文件，这个数组里是文件URL/路径列表。如果没有附件，设置为空数组。"
//									}
//								}
//							}
//						},
//						"functions": {
//							"jaxId": "1IGIKACEO2",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false",
//						"exportClass": "false",
//						"label": "SetupStep",
//						"desc": "执行安装配置工程项目的步骤/输出"
//					},
//					"mockups": {}
//				}
//			}
//		}
//	}
//}