//Auto genterated by Cody
import VFACT from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1IH9Q82MC0StartDoc*/
/*}#1IH9Q82MC0StartDoc*/
let TaskStep={
	name:"TaskStep",//1IH9Q82MD0
	type:"object",
	label:undefined,
	properties:{
		action:{
			name:"action",type:"string",
			choices:[
				"Command","Tool","Chat","Issue","Finish","Abort"
			],
			desc:"下一步的步骤动作",
		},
		content:{
			name:"content",type:"string",
			desc:"该步骤的说明",
		},
		commands:{
			name:"commands",type:"array",
			initLength:0,
			element:{
				"type":"string","label":'###:'
			},
			desc:"这个步骤要执行的命令行指令数组，如果没有要执行的指令，设置为空数组。",
		},
		issue:{
			name:"issue",type:"string",
			required:false,
			desc:"当\"action\"属性为\"Issue\"时，对问题的详细描述和查询内容。",
		},
		issueBrief:{
			name:"issueBrief",type:"string",
			defaultValue:"当\"action\"属性为\"Issue\"时，对问题的简洁概括",
			required:false,
		},
		tool:{
			name:"tool",type:"string",
			required:false,
			desc:"要调用的外部工具/AI智能体名称",
		},
		toolArg:{
			name:"toolArg",type:"string",
			required:false,
			desc:"调用的外部工具的参数/自然语言任务描述",
		},
		assets:{
			name:"assets",type:"array",
			initLength:0,
			element:{
				"type":"string","label":'###:'
			},
			desc:"如果该步骤包含给用户的附件文件，这个数组里是文件URL/路径列表。如果没有附件，设置为空数组。",
		},
		/*#{1IH9Q82MD0MoreProperties*/
		/*}#1IH9Q82MD0MoreProperties*/
	},
	desc:"执行任务的步骤/输出",
	newObject(){return VFACT.newUITemplateObj(this)},
	/*#{1IH9Q82MD0MoreFunctions*/
	/*}#1IH9Q82MD0MoreFunctions*/
};
VFACT.regUITemplate("1IH9Q82MD0",TaskStep);
VFACT.regUITemplate("TaskStep",TaskStep);
/*#{1IH9Q82MD0MoreCodes*/
/*}#1IH9Q82MD0MoreCodes*/
let IssueStep={
	name:"IssueStep",//1IHDPJBJ90
	type:"object",
	label:undefined,
	properties:{
		action:{
			name:"action",type:"string",
			choices:[
				"Solution","Command","Finish","Abort","Tool","Chat"
			],
			desc:"下一步的步骤动作",
		},
		content:{
			name:"content",type:"string",
			desc:"该步骤的内容或说明",
		},
		commands:{
			name:"commands",type:"array",
			initLength:0,
			element:{
				"type":"string","label":'###:'
			},
			desc:"这个步骤要执行的命令行指令数组，如果没有要执行的指令，设置为空数组。",
		},
		tool:{
			name:"tool",type:"string",
			required:false,
			desc:"要调用的外部工具/AI智能体名称",
		},
		toolArg:{
			name:"toolArg",type:"string",
			required:false,
			desc:"调用的外部工具的参数/自然语言任务描述",
		},
		/*#{1IHDPJBJ90MoreProperties*/
		/*}#1IHDPJBJ90MoreProperties*/
	},
	desc:"分析问题的步骤/输出",
	newObject(){return VFACT.newUITemplateObj(this)},
	/*#{1IHDPJBJ90MoreFunctions*/
	/*}#1IHDPJBJ90MoreFunctions*/
};
VFACT.regUITemplate("1IHDPJBJ90",IssueStep);
VFACT.regUITemplate("IssueStep",IssueStep);
/*#{1IHDPJBJ90MoreCodes*/
/*}#1IHDPJBJ90MoreCodes*/

/*#{1IH9Q82MC0EndDoc*/
/*}#1IH9Q82MC0EndDoc*/

export{TaskStep,IssueStep};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DataDoc",
//	"jaxId": "1IH9Q82MC0",
//	"attrs": {
//		"editObjs": {
//			"jaxId": "1IH9Q82MC1",
//			"attrs": {
//				"TaskStep": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1IH9Q82MD0",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1IH9Q82MD1",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1IH9Q82MD2",
//							"attrs": {
//								"action": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1IHA1MSGA0",
//									"attrs": {
//										"type": "string",
//										"choices": {
//											"type": "array",
//											"def": "Array",
//											"attrs": [
//												{
//													"type": "string",
//													"valText": "Command"
//												},
//												{
//													"type": "string",
//													"valText": "Tool"
//												},
//												{
//													"type": "string",
//													"valText": "Chat"
//												},
//												{
//													"type": "string",
//													"valText": "Issue"
//												},
//												{
//													"type": "string",
//													"valText": "Finish"
//												},
//												{
//													"type": "string",
//													"valText": "Abort"
//												}
//											]
//										},
//										"desc": "下一步的步骤动作"
//									}
//								},
//								"content": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1IHA20SSH0",
//									"attrs": {
//										"type": "string",
//										"desc": "该步骤的说明"
//									}
//								},
//								"commands": {
//									"type": "object",
//									"def": "EditClassAryPpt",
//									"jaxId": "1IHA20SSH1",
//									"attrs": {
//										"type": "array",
//										"element": {
//											"jaxId": "1IHA20SSH2",
//											"attrs": {
//												"type": "String",
//												"label": "#'###:'"
//											}
//										},
//										"initLength": "0",
//										"desc": "这个步骤要执行的命令行指令数组，如果没有要执行的指令，设置为空数组。"
//									}
//								},
//								"issue": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1IHA31ARB0",
//									"attrs": {
//										"type": "string",
//										"required": "false",
//										"desc": "当\"action\"属性为\"Issue\"时，对问题的详细描述和查询内容。"
//									}
//								},
//								"issueBrief": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1IHVQPAIC0",
//									"attrs": {
//										"type": "string",
//										"defaultValue": "当\"action\"属性为\"Issue\"时，对问题的简洁概括",
//										"required": "false"
//									}
//								},
//								"tool": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1IHA2SBE10",
//									"attrs": {
//										"type": "string",
//										"required": "false",
//										"desc": "要调用的外部工具/AI智能体名称"
//									}
//								},
//								"toolArg": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1IHA2SBE11",
//									"attrs": {
//										"type": "string",
//										"desc": "调用的外部工具的参数/自然语言任务描述",
//										"required": "false"
//									}
//								},
//								"assets": {
//									"type": "object",
//									"def": "EditClassAryPpt",
//									"jaxId": "1IHA2SBE12",
//									"attrs": {
//										"type": "array",
//										"element": {
//											"jaxId": "1IHA2SBE13",
//											"attrs": {
//												"type": "String",
//												"label": "#'###:'"
//											}
//										},
//										"initLength": "0",
//										"desc": "如果该步骤包含给用户的附件文件，这个数组里是文件URL/路径列表。如果没有附件，设置为空数组。"
//									}
//								}
//							}
//						},
//						"functions": {
//							"jaxId": "1IH9Q82MD3",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false",
//						"exportClass": "false",
//						"desc": "执行任务的步骤/输出"
//					},
//					"mockups": {}
//				},
//				"IssueStep": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1IHDPJBJ90",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1IHDPPIKD0",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1IHDPPIKD1",
//							"attrs": {
//								"action": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1IHDPPIKD2",
//									"attrs": {
//										"type": "string",
//										"desc": "下一步的步骤动作",
//										"choices": {
//											"type": "array",
//											"def": "Array",
//											"attrs": [
//												{
//													"type": "string",
//													"valText": "Solution"
//												},
//												{
//													"type": "string",
//													"valText": "Command"
//												},
//												{
//													"type": "string",
//													"valText": "Finish"
//												},
//												{
//													"type": "string",
//													"valText": "Abort"
//												},
//												{
//													"type": "string",
//													"valText": "Tool"
//												},
//												{
//													"type": "string",
//													"valText": "Chat"
//												}
//											]
//										}
//									}
//								},
//								"content": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1IHDPPIKD3",
//									"attrs": {
//										"type": "string",
//										"desc": "该步骤的内容或说明"
//									}
//								},
//								"commands": {
//									"type": "object",
//									"def": "EditClassAryPpt",
//									"jaxId": "1IHDPPIKD4",
//									"attrs": {
//										"type": "array",
//										"element": {
//											"jaxId": "1IHDPPIKD5",
//											"attrs": {
//												"type": "String",
//												"label": "#'###:'"
//											}
//										},
//										"initLength": "0",
//										"desc": "这个步骤要执行的命令行指令数组，如果没有要执行的指令，设置为空数组。"
//									}
//								},
//								"tool": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1IHDPPIKD6",
//									"attrs": {
//										"type": "string",
//										"desc": "要调用的外部工具/AI智能体名称",
//										"required": "false"
//									}
//								},
//								"toolArg": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1IHDPPIKD7",
//									"attrs": {
//										"type": "string",
//										"required": "false",
//										"desc": "调用的外部工具的参数/自然语言任务描述"
//									}
//								}
//							}
//						},
//						"functions": {
//							"jaxId": "1IHDPPIKD8",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false",
//						"exportClass": "false",
//						"desc": "分析问题的步骤/输出"
//					},
//					"mockups": {}
//				}
//			}
//		}
//	}
//}