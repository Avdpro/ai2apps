//Auto genterated by Cody
import VFACT from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1IMUAC90L0StartDoc*/
const $ln=VFACT.lanCode||"EN";
/*}#1IMUAC90L0StartDoc*/
let RAGData={
	name:"RAGData",//1IMUAC90L2
	type:"object",
	label:undefined,
	properties:{
		/*#{1IMUAC90L2MoreProperties*/
		/*}#1IMUAC90L2MoreProperties*/
	},
	desc:undefined,
	newObject(){return VFACT.newUITemplateObj(this)},
	/*#{1IMUAC90L2MoreFunctions*/
	/*}#1IMUAC90L2MoreFunctions*/
};
VFACT.regUITemplate("1IMUAC90L2",RAGData);
VFACT.regUITemplate("RAGData",RAGData);
/*#{1IMUAC90L2MoreCodes*/
/*}#1IMUAC90L2MoreCodes*/
let RagSetupPrj={
	name:"RagSetupPrj",//1IMUACQDA0
	type:"object",
	label:undefined,
	properties:{
		platform:{
			name:"platform",type:"string",
			label:(($ln==="CN")?("硬件平台"):("Platform")),
			choices:[
				"darwin","linux","win32","android"
			],
		},
		arch:{
			name:"arch",type:"string",
			label:(($ln==="CN")?("硬件架构"):("Architecture")),
			choices:[
				"arm64","x64","riscv64","ia32","mips"
			],
		},
		project:{
			name:"project",type:"string",
			label:(($ln==="CN")?("项目"):("Project")),
		},
		postToRoot:{
			name:"postToRoot",type:"bool",
			label:(($ln==="CN")?("使用公有 RAG"):("Use public RAG")),
		},
		/*#{1IMUACQDA0MoreProperties*/
		/*}#1IMUACQDA0MoreProperties*/
	},
	desc:undefined,
	newObject(){return VFACT.newUITemplateObj(this)},
	/*#{1IMUACQDA0MoreFunctions*/
	/*}#1IMUACQDA0MoreFunctions*/
};
VFACT.regUITemplate("1IMUACQDA0",RagSetupPrj);
VFACT.regUITemplate("RagSetupPrj",RagSetupPrj);
/*#{1IMUACQDA0MoreCodes*/
/*}#1IMUACQDA0MoreCodes*/
let RagIssue={
	name:"RagIssue",//1IN0JHEB20
	type:"object",
	label:undefined,
	properties:{
		issue:{
			name:"issue",type:"string",
			label:(($ln==="CN")?("问题"):("Issue")),
			required:true,
			uiMode:"Note",
		},
		tags:{
			name:"tags",type:"string",
			label:(($ln==="CN")?("标签"):("Tags")),
		},
		postToRoot:{
			name:"postToRoot",type:"bool",
			label:(($ln==="CN")?("提交至公有云RAG"):("Submit to public RAG")),
		},
		/*#{1IN0JHEB20MoreProperties*/
		/*}#1IN0JHEB20MoreProperties*/
	},
	desc:undefined,
	newObject(){return VFACT.newUITemplateObj(this)},
	/*#{1IN0JHEB20MoreFunctions*/
	/*}#1IN0JHEB20MoreFunctions*/
};
VFACT.regUITemplate("1IN0JHEB20",RagIssue);
VFACT.regUITemplate("RagIssue",RagIssue);
/*#{1IN0JHEB20MoreCodes*/
/*}#1IN0JHEB20MoreCodes*/
let RagQueryIssue={
	name:"RagQueryIssue",//1IN0OGMTF0
	type:"object",
	label:undefined,
	properties:{
		issue:{
			name:"issue",type:"string",
			label:(($ln==="CN")?("问题"):("Issue")),
			required:true,
			uiMode:"Note",
		},
		tags:{
			name:"tags",type:"string",
			label:(($ln==="CN")?("标签"):("Tags")),
		},
		/*#{1IN0OGMTF0MoreProperties*/
		/*}#1IN0OGMTF0MoreProperties*/
	},
	desc:undefined,
	newObject(){return VFACT.newUITemplateObj(this)},
	/*#{1IN0OGMTF0MoreFunctions*/
	/*}#1IN0OGMTF0MoreFunctions*/
};
VFACT.regUITemplate("1IN0OGMTF0",RagQueryIssue);
VFACT.regUITemplate("RagQueryIssue",RagQueryIssue);
/*#{1IN0OGMTF0MoreCodes*/
/*}#1IN0OGMTF0MoreCodes*/
let RagKb={
	name:"RagKb",//1IN0TOFMS0
	type:"object",
	label:undefined,
	properties:{
		identifier:{
			name:"identifier",type:"string",
			label:(($ln==="CN")?("知识库帐号"):("Knowledge Base Account")),
			defaultValue:"personal",
			choices:[
				"public","personal"
			],
		},
		kbName:{
			name:"kbName",type:"string",
			label:(($ln==="CN")?("知识库名称"):("Knowledge Base Name")),
			defaultValue:"public",
		},
		postToRoot:{
			name:"postToRoot",type:"bool",
			label:(($ln==="CN")?("提交公有云 RAG"):("Submit to public RAG")),
		},
		/*#{1IN0TOFMS0MoreProperties*/
		/*}#1IN0TOFMS0MoreProperties*/
	},
	desc:undefined,
	newObject(){return VFACT.newUITemplateObj(this)},
	/*#{1IN0TOFMS0MoreFunctions*/
	/*}#1IN0TOFMS0MoreFunctions*/
};
VFACT.regUITemplate("1IN0TOFMS0",RagKb);
VFACT.regUITemplate("RagKb",RagKb);
/*#{1IN0TOFMS0MoreCodes*/
/*}#1IN0TOFMS0MoreCodes*/
let RagKbQuery={
	name:"RagKbQuery",//1ING5NJ7O0
	type:"object",
	label:undefined,
	properties:{
		identifier:{
			name:"identifier",type:"string",
			label:(($ln==="CN")?("知识库名称"):("Knowledge Base Name")),
			choices:[
				"personal","public"
			],
		},
		kbName:{
			name:"kbName",type:"string",
			label:(($ln==="CN")?("知识库名称"):("Knowledge Base Name")),
			defaultValue:"public",
		},
		postToRoot:{
			name:"postToRoot",type:"bool",
			label:(($ln==="CN")?("仅查询公有云RAG"):("Only query public RAG")),
		},
		/*#{1ING5NJ7O0MoreProperties*/
		/*}#1ING5NJ7O0MoreProperties*/
	},
	desc:undefined,
	newObject(){return VFACT.newUITemplateObj(this)},
	/*#{1ING5NJ7O0MoreFunctions*/
	/*}#1ING5NJ7O0MoreFunctions*/
};
VFACT.regUITemplate("1ING5NJ7O0",RagKbQuery);
VFACT.regUITemplate("RagKbQuery",RagKbQuery);
/*#{1ING5NJ7O0MoreCodes*/
/*}#1ING5NJ7O0MoreCodes*/

/*#{1IMUAC90L0EndDoc*/
/*}#1IMUAC90L0EndDoc*/

export{RAGData,RagSetupPrj,RagIssue,RagQueryIssue,RagKb,RagKbQuery};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DataDoc",
//	"jaxId": "1IMUAC90L0",
//	"attrs": {
//		"editObjs": {
//			"jaxId": "1IMUAC90L1",
//			"attrs": {
//				"RAGData": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1IMUAC90L2",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1IMUAC90M0",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1IMUAC90M1",
//							"attrs": {}
//						},
//						"functions": {
//							"jaxId": "1IMUAC90M2",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false",
//						"exportClass": "false"
//					},
//					"mockups": {}
//				},
//				"RagSetupPrj": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1IMUACQDA0",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1IMUAL4NO0",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1IMUAL4NO1",
//							"attrs": {
//								"platform": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1IMUAL4NO2",
//									"attrs": {
//										"type": "string",
//										"choices": {
//											"type": "array",
//											"def": "Array",
//											"attrs": [
//												{
//													"type": "string",
//													"valText": "darwin"
//												},
//												{
//													"type": "string",
//													"valText": "linux"
//												},
//												{
//													"type": "string",
//													"valText": "win32"
//												},
//												{
//													"type": "string",
//													"valText": "android"
//												}
//											]
//										},
//										"label": {
//											"type": "string",
//											"valText": "Platform",
//											"localize": {
//												"EN": "Platform",
//												"CN": "硬件平台"
//											},
//											"localizable": true
//										}
//									}
//								},
//								"arch": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1IMUAL4NO3",
//									"attrs": {
//										"type": "string",
//										"choices": {
//											"type": "array",
//											"def": "Array",
//											"attrs": [
//												{
//													"type": "string",
//													"valText": "arm64"
//												},
//												{
//													"type": "string",
//													"valText": "x64"
//												},
//												{
//													"type": "string",
//													"valText": "riscv64"
//												},
//												{
//													"type": "string",
//													"valText": "ia32"
//												},
//												{
//													"type": "string",
//													"valText": "mips"
//												}
//											]
//										},
//										"label": {
//											"type": "string",
//											"valText": "Architecture",
//											"localize": {
//												"EN": "Architecture",
//												"CN": "硬件架构"
//											},
//											"localizable": true
//										}
//									}
//								},
//								"project": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1IMUAL4NO4",
//									"attrs": {
//										"type": "string",
//										"label": {
//											"type": "string",
//											"valText": "Project",
//											"localize": {
//												"EN": "Project",
//												"CN": "项目"
//											},
//											"localizable": true
//										}
//									}
//								},
//								"postToRoot": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1IN092QG80",
//									"attrs": {
//										"type": "bool",
//										"label": {
//											"type": "string",
//											"valText": "Use public RAG",
//											"localize": {
//												"EN": "Use public RAG",
//												"CN": "使用公有 RAG"
//											},
//											"localizable": true
//										}
//									}
//								}
//							}
//						},
//						"functions": {
//							"jaxId": "1IMUAL4NO5",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false",
//						"exportClass": "false"
//					},
//					"mockups": {}
//				},
//				"RagIssue": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1IN0JHEB20",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1IN0JK0JM0",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1IN0JK0JM1",
//							"attrs": {
//								"issue": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1IN0JK0JM4",
//									"attrs": {
//										"type": "string",
//										"uiMode": "Note",
//										"required": "true",
//										"label": {
//											"type": "string",
//											"valText": "Issue",
//											"localize": {
//												"EN": "Issue",
//												"CN": "问题"
//											},
//											"localizable": true
//										}
//									}
//								},
//								"tags": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1IN0LV6CP0",
//									"attrs": {
//										"type": "string",
//										"label": {
//											"type": "string",
//											"valText": "Tags",
//											"localize": {
//												"EN": "Tags",
//												"CN": "标签"
//											},
//											"localizable": true
//										}
//									}
//								},
//								"postToRoot": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1IN0K0GOM0",
//									"attrs": {
//										"type": "bool",
//										"label": {
//											"type": "string",
//											"valText": "Submit to public RAG",
//											"localize": {
//												"EN": "Submit to public RAG",
//												"CN": "提交至公有云RAG"
//											},
//											"localizable": true
//										}
//									}
//								}
//							}
//						},
//						"functions": {
//							"jaxId": "1IN0JK0JM5",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false",
//						"exportClass": "false"
//					},
//					"mockups": {}
//				},
//				"RagQueryIssue": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1IN0OGMTF0",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1IN0OHFLU0",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1IN0OHFLU1",
//							"attrs": {
//								"issue": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1IN0OHFLU2",
//									"attrs": {
//										"type": "string",
//										"required": "true",
//										"uiMode": "Note",
//										"label": {
//											"type": "string",
//											"valText": "Issue",
//											"localize": {
//												"EN": "Issue",
//												"CN": "问题"
//											},
//											"localizable": true
//										}
//									}
//								},
//								"tags": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1IN0OHFLU3",
//									"attrs": {
//										"type": "string",
//										"label": {
//											"type": "string",
//											"valText": "Tags",
//											"localize": {
//												"EN": "Tags",
//												"CN": "标签"
//											},
//											"localizable": true
//										}
//									}
//								}
//							}
//						},
//						"functions": {
//							"jaxId": "1IN0OHFLU4",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false",
//						"exportClass": "false"
//					},
//					"mockups": {}
//				},
//				"RagKb": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1IN0TOFMS0",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1IN0TQAUK0",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1IN0TQAUK1",
//							"attrs": {
//								"identifier": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1IN0TQAUK3",
//									"attrs": {
//										"type": "string",
//										"choices": {
//											"type": "array",
//											"def": "Array",
//											"attrs": [
//												{
//													"type": "string",
//													"valText": "public"
//												},
//												{
//													"type": "string",
//													"valText": "personal"
//												}
//											]
//										},
//										"defaultValue": "personal",
//										"label": {
//											"type": "string",
//											"valText": "Knowledge Base Account",
//											"localize": {
//												"EN": "Knowledge Base Account",
//												"CN": "知识库帐号"
//											},
//											"localizable": true
//										}
//									}
//								},
//								"kbName": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1IN0TQAUK2",
//									"attrs": {
//										"type": "string",
//										"defaultValue": "public",
//										"label": {
//											"type": "string",
//											"valText": "Knowledge Base Name",
//											"localize": {
//												"EN": "Knowledge Base Name",
//												"CN": "知识库名称"
//											},
//											"localizable": true
//										}
//									}
//								},
//								"postToRoot": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1IN4O27SL0",
//									"attrs": {
//										"type": "bool",
//										"label": {
//											"type": "string",
//											"valText": "Submit to public RAG",
//											"localize": {
//												"EN": "Submit to public RAG",
//												"CN": "提交公有云 RAG"
//											},
//											"localizable": true
//										}
//									}
//								}
//							}
//						},
//						"functions": {
//							"jaxId": "1IN0TQAUK4",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false",
//						"exportClass": "false"
//					},
//					"mockups": {}
//				},
//				"RagKbQuery": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1ING5NJ7O0",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1ING5U4700",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1ING5U4701",
//							"attrs": {
//								"identifier": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1ING5U4702",
//									"attrs": {
//										"type": "string",
//										"label": {
//											"type": "string",
//											"valText": "Knowledge Base Name",
//											"localize": {
//												"EN": "Knowledge Base Name",
//												"CN": "知识库名称"
//											},
//											"localizable": true
//										},
//										"choices": {
//											"type": "array",
//											"def": "Array",
//											"attrs": [
//												{
//													"type": "string",
//													"valText": "personal"
//												},
//												{
//													"type": "string",
//													"valText": "public"
//												}
//											]
//										}
//									}
//								},
//								"kbName": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1ING5U4703",
//									"attrs": {
//										"type": "string",
//										"label": {
//											"type": "string",
//											"valText": "Knowledge Base Name",
//											"localize": {
//												"EN": "Knowledge Base Name",
//												"CN": "知识库名称"
//											},
//											"localizable": true
//										},
//										"defaultValue": "public"
//									}
//								},
//								"postToRoot": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1ING5U4704",
//									"attrs": {
//										"type": "bool",
//										"label": {
//											"type": "string",
//											"valText": "Only query public RAG",
//											"localize": {
//												"EN": "Only query public RAG",
//												"CN": "仅查询公有云RAG"
//											},
//											"localizable": true
//										}
//									}
//								}
//							}
//						},
//						"functions": {
//							"jaxId": "1ING5U4705",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false",
//						"exportClass": "false"
//					},
//					"mockups": {}
//				}
//			}
//		}
//	}
//}