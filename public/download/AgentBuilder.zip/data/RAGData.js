//Auto genterated by Cody
import VFACT from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1IMUAC90L0StartDoc*/
/*}#1IMUAC90L0StartDoc*/
let RAGData={
	name:"RAGData",//1IMUAC90L2
	type:"object",
	label:undefined,
	properties:{
		/*#{1IMUAC90L2MoreProperties*/
		/*}#1IMUAC90L2MoreProperties*/
	},
	desc:undefined,
	newObject(){return VFACT.newUITemplateObj(this)},
	/*#{1IMUAC90L2MoreFunctions*/
	/*}#1IMUAC90L2MoreFunctions*/
};
VFACT.regUITemplate("1IMUAC90L2",RAGData);
VFACT.regUITemplate("RAGData",RAGData);
/*#{1IMUAC90L2MoreCodes*/
/*}#1IMUAC90L2MoreCodes*/
let RagSetupPrj={
	name:"RagSetupPrj",//1IMUACQDA0
	type:"object",
	label:undefined,
	properties:{
		platform:{
			name:"platform",type:"string",
			choices:[
				"darwin","linux","win32","android"
			],
		},
		arch:{
			name:"arch",type:"string",
			choices:[
				"arm64","x64","riscv64","ia32","mips"
			],
		},
		project:{
			name:"project",type:"string",
		},
		postToRoot:{
			name:"postToRoot",type:"bool",
		},
		/*#{1IMUACQDA0MoreProperties*/
		/*}#1IMUACQDA0MoreProperties*/
	},
	desc:undefined,
	newObject(){return VFACT.newUITemplateObj(this)},
	/*#{1IMUACQDA0MoreFunctions*/
	/*}#1IMUACQDA0MoreFunctions*/
};
VFACT.regUITemplate("1IMUACQDA0",RagSetupPrj);
VFACT.regUITemplate("RagSetupPrj",RagSetupPrj);
/*#{1IMUACQDA0MoreCodes*/
/*}#1IMUACQDA0MoreCodes*/
let RagIssue={
	name:"RagIssue",//1IN0JHEB20
	type:"object",
	label:undefined,
	properties:{
		issue:{
			name:"issue",type:"string",
			required:true,
			uiMode:"Note",
		},
		tags:{
			name:"tags",type:"string",
		},
		postToRoot:{
			name:"postToRoot",type:"bool",
		},
		/*#{1IN0JHEB20MoreProperties*/
		/*}#1IN0JHEB20MoreProperties*/
	},
	desc:undefined,
	newObject(){return VFACT.newUITemplateObj(this)},
	/*#{1IN0JHEB20MoreFunctions*/
	/*}#1IN0JHEB20MoreFunctions*/
};
VFACT.regUITemplate("1IN0JHEB20",RagIssue);
VFACT.regUITemplate("RagIssue",RagIssue);
/*#{1IN0JHEB20MoreCodes*/
/*}#1IN0JHEB20MoreCodes*/
let RagQueryIssue={
	name:"RagQueryIssue",//1IN0OGMTF0
	type:"object",
	label:undefined,
	properties:{
		issue:{
			name:"issue",type:"string",
			required:true,
			uiMode:"Note",
		},
		tags:{
			name:"tags",type:"string",
		},
		/*#{1IN0OGMTF0MoreProperties*/
		/*}#1IN0OGMTF0MoreProperties*/
	},
	desc:undefined,
	newObject(){return VFACT.newUITemplateObj(this)},
	/*#{1IN0OGMTF0MoreFunctions*/
	/*}#1IN0OGMTF0MoreFunctions*/
};
VFACT.regUITemplate("1IN0OGMTF0",RagQueryIssue);
VFACT.regUITemplate("RagQueryIssue",RagQueryIssue);
/*#{1IN0OGMTF0MoreCodes*/
/*}#1IN0OGMTF0MoreCodes*/
let RagKb={
	name:"RagKb",//1IN0TOFMS0
	type:"object",
	label:undefined,
	properties:{
		kbName:{
			name:"kbName",type:"string",
			defaultValue:"public",
		},
		identifier:{
			name:"identifier",type:"string",
		},
		postToRoot:{
			name:"postToRoot",type:"bool",
		},
		/*#{1IN0TOFMS0MoreProperties*/
		/*}#1IN0TOFMS0MoreProperties*/
	},
	desc:undefined,
	newObject(){return VFACT.newUITemplateObj(this)},
	/*#{1IN0TOFMS0MoreFunctions*/
	/*}#1IN0TOFMS0MoreFunctions*/
};
VFACT.regUITemplate("1IN0TOFMS0",RagKb);
VFACT.regUITemplate("RagKb",RagKb);
/*#{1IN0TOFMS0MoreCodes*/
/*}#1IN0TOFMS0MoreCodes*/

/*#{1IMUAC90L0EndDoc*/
/*}#1IMUAC90L0EndDoc*/

export{RAGData,RagSetupPrj,RagIssue,RagQueryIssue,RagKb};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DataDoc",
//	"jaxId": "1IMUAC90L0",
//	"attrs": {
//		"editObjs": {
//			"jaxId": "1IMUAC90L1",
//			"attrs": {
//				"RAGData": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1IMUAC90L2",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1IMUAC90M0",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1IMUAC90M1",
//							"attrs": {}
//						},
//						"functions": {
//							"jaxId": "1IMUAC90M2",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false",
//						"exportClass": "false"
//					},
//					"mockups": {}
//				},
//				"RagSetupPrj": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1IMUACQDA0",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1IMUAL4NO0",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1IMUAL4NO1",
//							"attrs": {
//								"platform": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1IMUAL4NO2",
//									"attrs": {
//										"type": "string",
//										"choices": {
//											"type": "array",
//											"def": "Array",
//											"attrs": [
//												{
//													"type": "string",
//													"valText": "darwin"
//												},
//												{
//													"type": "string",
//													"valText": "linux"
//												},
//												{
//													"type": "string",
//													"valText": "win32"
//												},
//												{
//													"type": "string",
//													"valText": "android"
//												}
//											]
//										}
//									}
//								},
//								"arch": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1IMUAL4NO3",
//									"attrs": {
//										"type": "string",
//										"choices": {
//											"type": "array",
//											"def": "Array",
//											"attrs": [
//												{
//													"type": "string",
//													"valText": "arm64"
//												},
//												{
//													"type": "string",
//													"valText": "x64"
//												},
//												{
//													"type": "string",
//													"valText": "riscv64"
//												},
//												{
//													"type": "string",
//													"valText": "ia32"
//												},
//												{
//													"type": "string",
//													"valText": "mips"
//												}
//											]
//										}
//									}
//								},
//								"project": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1IMUAL4NO4",
//									"attrs": {
//										"type": "string"
//									}
//								},
//								"postToRoot": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1IN092QG80",
//									"attrs": {
//										"type": "bool"
//									}
//								}
//							}
//						},
//						"functions": {
//							"jaxId": "1IMUAL4NO5",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false",
//						"exportClass": "false"
//					},
//					"mockups": {}
//				},
//				"RagIssue": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1IN0JHEB20",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1IN0JK0JM0",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1IN0JK0JM1",
//							"attrs": {
//								"issue": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1IN0JK0JM4",
//									"attrs": {
//										"type": "string",
//										"uiMode": "Note",
//										"required": "true"
//									}
//								},
//								"tags": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1IN0LV6CP0",
//									"attrs": {
//										"type": "string"
//									}
//								},
//								"postToRoot": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1IN0K0GOM0",
//									"attrs": {
//										"type": "bool"
//									}
//								}
//							}
//						},
//						"functions": {
//							"jaxId": "1IN0JK0JM5",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false",
//						"exportClass": "false"
//					},
//					"mockups": {}
//				},
//				"RagQueryIssue": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1IN0OGMTF0",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1IN0OHFLU0",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1IN0OHFLU1",
//							"attrs": {
//								"issue": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1IN0OHFLU2",
//									"attrs": {
//										"type": "string",
//										"required": "true",
//										"uiMode": "Note"
//									}
//								},
//								"tags": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1IN0OHFLU3",
//									"attrs": {
//										"type": "string"
//									}
//								}
//							}
//						},
//						"functions": {
//							"jaxId": "1IN0OHFLU4",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false",
//						"exportClass": "false"
//					},
//					"mockups": {}
//				},
//				"RagKb": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1IN0TOFMS0",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1IN0TQAUK0",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1IN0TQAUK1",
//							"attrs": {
//								"kbName": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1IN0TQAUK2",
//									"attrs": {
//										"type": "string",
//										"defaultValue": "public"
//									}
//								},
//								"identifier": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1IN0TQAUK3",
//									"attrs": {
//										"type": "string"
//									}
//								},
//								"postToRoot": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1IN4O27SL0",
//									"attrs": {
//										"type": "bool"
//									}
//								}
//							}
//						},
//						"functions": {
//							"jaxId": "1IN0TQAUK4",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false",
//						"exportClass": "false"
//					},
//					"mockups": {}
//				}
//			}
//		}
//	}
//}