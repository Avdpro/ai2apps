//Auto genterated by Cody
import VFACT from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1INGPGPEK0StartDoc*/
const $ln=VFACT.lanCode;
/*}#1INGPGPEK0StartDoc*/
let AIConfig={
	name:"AIConfig",//1INGPGPEK2
	type:"object",
	label:undefined,
	properties:{
		models:{
			name:"models",type:"object",
			label:(($ln==="CN")?("AI 模型"):("AI Models")),
			class:"1INGPNOAN0",
		},
		/*#{1INGPGPEK2MoreProperties*/
		/*}#1INGPGPEK2MoreProperties*/
	},
	desc:(($ln==="CN")?("在LLM组件中，可以使用$开头的字符串来指定AI模型，例如使用$fast来指定使用“fast”模型设定。"):("In the LLM component, you can use a string starting with $ to specify the AI model, for example, using $fast to specify using the 'fast' model setting.")),
	newObject(){return VFACT.newUITemplateObj(this)},
	/*#{1INGPGPEK2MoreFunctions*/
	/*}#1INGPGPEK2MoreFunctions*/
};
VFACT.regUITemplate("1INGPGPEK2",AIConfig);
VFACT.regUITemplate("AIConfig",AIConfig);
/*#{1INGPGPEK2MoreCodes*/
/*}#1INGPGPEK2MoreCodes*/
let AIModel={
	name:"AIModel",//1INGPHIJU0
	type:"object",
	label:undefined,
	properties:{
		platform:{
			name:"platform",type:"string",
			label:(($ln==="CN")?("API平台"):("API Platform")),
			choices:[
				"OpenAI","Claude","Google","Ollama"
			],
		},
		model:{
			name:"model",type:"string",
			label:(($ln==="CN")?("AI 模型"):("AI Model")),
		},
		/*#{1INGPHIJU0MoreProperties*/
		/*}#1INGPHIJU0MoreProperties*/
	},
	desc:undefined,
	newObject(){return VFACT.newUITemplateObj(this)},
	/*#{1INGPHIJU0MoreFunctions*/
	/*}#1INGPHIJU0MoreFunctions*/
};
VFACT.regUITemplate("1INGPHIJU0",AIModel);
VFACT.regUITemplate("AIModel",AIModel);
/*#{1INGPHIJU0MoreCodes*/
/*}#1INGPHIJU0MoreCodes*/
let ModelConfig={
	name:"ModelConfig",//1INGPNOAN0
	type:"object",
	label:undefined,
	properties:{
		default:{
			name:"default",type:"object",
			class:"1INGPHIJU0",
		},
		fast:{
			name:"fast",type:"object",
			class:"1INGPHIJU0",
		},
		lite:{
			name:"lite",type:"object",
			class:"1INGPHIJU0",
		},
		expert:{
			name:"expert",type:"object",
			class:"1INGPHIJU0",
		},
		coding:{
			name:"coding",type:"object",
			class:"1INGPHIJU0",
		},
		planning:{
			name:"planning",type:"object",
			class:"1INGPHIJU0",
		},
		view:{
			name:"view",type:"object",
			class:"1INGPHIJU0",
		},
		/*#{1INGPNOAN0MoreProperties*/
		/*}#1INGPNOAN0MoreProperties*/
	},
	desc:undefined,
	newObject(){return VFACT.newUITemplateObj(this)},
	/*#{1INGPNOAN0MoreFunctions*/
	/*}#1INGPNOAN0MoreFunctions*/
};
VFACT.regUITemplate("1INGPNOAN0",ModelConfig);
VFACT.regUITemplate("ModelConfig",ModelConfig);
/*#{1INGPNOAN0MoreCodes*/
/*}#1INGPNOAN0MoreCodes*/

/*#{1INGPGPEK0EndDoc*/
/*}#1INGPGPEK0EndDoc*/

export{AIConfig,AIModel,ModelConfig};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DataDoc",
//	"jaxId": "1INGPGPEK0",
//	"attrs": {
//		"editObjs": {
//			"jaxId": "1INGPGPEK1",
//			"attrs": {
//				"AIConfig": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1INGPGPEK2",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1INGPGPEK3",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1INGPGPEK4",
//							"attrs": {
//								"models": {
//									"type": "object",
//									"def": "EditClassObjPpt",
//									"jaxId": "1INGQH1IK0",
//									"attrs": {
//										"type": "object",
//										"class": "\"1INGPNOAN0\"",
//										"label": {
//											"type": "string",
//											"valText": "AI Models",
//											"localize": {
//												"EN": "AI Models",
//												"CN": "AI 模型"
//											},
//											"localizable": true
//										}
//									}
//								}
//							}
//						},
//						"functions": {
//							"jaxId": "1INGPGPEK5",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false",
//						"exportClass": "false",
//						"desc": {
//							"type": "string",
//							"valText": "In the LLM component, you can use a string starting with $ to specify the AI model, for example, using $fast to specify using the 'fast' model setting.",
//							"localize": {
//								"EN": "In the LLM component, you can use a string starting with $ to specify the AI model, for example, using $fast to specify using the 'fast' model setting.",
//								"CN": "在LLM组件中，可以使用$开头的字符串来指定AI模型，例如使用$fast来指定使用“fast”模型设定。"
//							},
//							"localizable": true
//						}
//					},
//					"mockups": {}
//				},
//				"AIModel": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1INGPHIJU0",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1INGPN0D90",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1INGPN0D91",
//							"attrs": {
//								"platform": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1INGPN0D92",
//									"attrs": {
//										"type": "string",
//										"choices": {
//											"type": "array",
//											"def": "Array",
//											"attrs": [
//												{
//													"type": "string",
//													"valText": "OpenAI"
//												},
//												{
//													"type": "string",
//													"valText": "Claude"
//												},
//												{
//													"type": "string",
//													"valText": "Google"
//												},
//												{
//													"type": "string",
//													"valText": "Ollama"
//												}
//											]
//										},
//										"label": {
//											"type": "string",
//											"valText": "API Platform",
//											"localize": {
//												"EN": "API Platform",
//												"CN": "API平台"
//											},
//											"localizable": true
//										}
//									}
//								},
//								"model": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1INGPN0D93",
//									"attrs": {
//										"type": "string",
//										"label": {
//											"type": "string",
//											"valText": "AI Model",
//											"localize": {
//												"EN": "AI Model",
//												"CN": "AI 模型"
//											},
//											"localizable": true
//										}
//									}
//								}
//							}
//						},
//						"functions": {
//							"jaxId": "1INGPN0D94",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false",
//						"exportClass": "false"
//					},
//					"mockups": {}
//				},
//				"ModelConfig": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1INGPNOAN0",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1INGQGEKT0",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1INGQGEKT1",
//							"attrs": {
//								"default": {
//									"type": "object",
//									"def": "EditClassObjPpt",
//									"jaxId": "1INGQGEKT2",
//									"attrs": {
//										"type": "object",
//										"class": "\"1INGPHIJU0\""
//									}
//								},
//								"fast": {
//									"type": "object",
//									"def": "EditClassObjPpt",
//									"jaxId": "1INGQGEKT3",
//									"attrs": {
//										"type": "object",
//										"class": "\"1INGPHIJU0\""
//									}
//								},
//								"lite": {
//									"type": "object",
//									"def": "EditClassObjPpt",
//									"jaxId": "1INGQGEKT4",
//									"attrs": {
//										"type": "object",
//										"class": "\"1INGPHIJU0\""
//									}
//								},
//								"expert": {
//									"type": "object",
//									"def": "EditClassObjPpt",
//									"jaxId": "1INGQGEKT7",
//									"attrs": {
//										"type": "object",
//										"class": "\"1INGPHIJU0\""
//									}
//								},
//								"coding": {
//									"type": "object",
//									"def": "EditClassObjPpt",
//									"jaxId": "1INGQGEKT5",
//									"attrs": {
//										"type": "object",
//										"class": "\"1INGPHIJU0\""
//									}
//								},
//								"planning": {
//									"type": "object",
//									"def": "EditClassObjPpt",
//									"jaxId": "1INGQGEKT6",
//									"attrs": {
//										"type": "object",
//										"class": "\"1INGPHIJU0\""
//									}
//								},
//								"view": {
//									"type": "object",
//									"def": "EditClassObjPpt",
//									"jaxId": "1INGT1UTJ0",
//									"attrs": {
//										"type": "object",
//										"class": "\"1INGPHIJU0\""
//									}
//								}
//							}
//						},
//						"functions": {
//							"jaxId": "1INGQGEKT8",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false",
//						"exportClass": "false"
//					},
//					"mockups": {}
//				}
//			}
//		}
//	}
//}