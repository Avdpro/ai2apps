//Auto genterated by Cody
import VFACT from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1ILTMHV9J0StartDoc*/
/*}#1ILTMHV9J0StartDoc*/
let WebStep={
	name:"WebStep",//1ILTMHV9J2
	type:"object",
	label:undefined,
	properties:{
		state:{
			name:"state",type:"string",
			choices:[
				"Execute","Finish","Failed","Abort"
			],
			desc:"当前执行任务的状态，Execute代表要执行操作网页的步骤",
		},
		content:{
			name:"content",type:"string",
			desc:"当前步骤的说明或者任务执行结果",
		},
		execute:{
			name:"execute",type:"object",
			class:"1ILTMI90P0",
			desc:"如果state是\"Execute\"，要执行的步骤内容。",
		},
		/*#{1ILTMHV9J2MoreProperties*/
		/*}#1ILTMHV9J2MoreProperties*/
	},
	desc:undefined,
	newObject(){return VFACT.newUITemplateObj(this)},
	/*#{1ILTMHV9J2MoreFunctions*/
	/*}#1ILTMHV9J2MoreFunctions*/
};
VFACT.regUITemplate("1ILTMHV9J2",WebStep);
VFACT.regUITemplate("WebStep",WebStep);
/*#{1ILTMHV9J2MoreCodes*/
/*}#1ILTMHV9J2MoreCodes*/
let WebAction={
	name:"WebAction",//1ILTMI90P0
	type:"object",
	label:undefined,
	properties:{
		action:{
			name:"action",type:"string",
			choices:[
				"Click","Input","PressKey","Goto","Hover","Back","Scroll","Tool","UserAction","Ask","NA"
			],
			desc:"要执行的网页操作动作类型，如果不用执行操作：NA",
		},
		queryHint:{
			name:"queryHint",type:"string",
			required:false,
			desc:"用于定位要操作的目标HTML元素的描述。",
		},
		targetAAEId:{
			name:"targetAAEId",type:"string",
			required:false,
			desc:"要操作的目标元素的aaeid属性值",
		},
		waitEvent:{
			name:"waitEvent",type:"string",
			required:false,
			choices:[
				"Navi","PickFile"
			],
			desc:"如果步骤会导致页面切换或者打开上传文件的对话框，相应的设定此属性",
		},
		text:{
			name:"text",type:"string",
			required:false,
			desc:"如果action是\"input\"，要输入的文本内容。",
		},
		key:{
			name:"key",type:"string",
			required:false,
			desc:"如果action是\"PressKey\"，要按的键的键码",
		},
		url:{
			name:"url",type:"string",
			required:false,
			desc:"如果actoin是\"Goto\"，目标网址",
		},
		file:{
			name:"file",type:"string",
			required:false,
			desc:"如果action是\"PickFIle\"，要上传的文件的地址/路径，通常是hub://开始的",
		},
		scroll:{
			name:"scroll",type:"int",
			required:false,
			desc:"当action为\"scroll\"时，滚动的距离，正数为向下滚动，负数为向上滚动",
		},
		tool:{
			name:"tool",type:"string",
			required:false,
			desc:"要调用的外部工具名称",
		},
		toolArg:{
			name:"toolArg",type:"string",
			required:false,
			desc:"调用工具/智能体的指令/参数的文本",
		},
		/*#{1ILTMI90P0MoreProperties*/
		/*}#1ILTMI90P0MoreProperties*/
	},
	desc:undefined,
	newObject(){return VFACT.newUITemplateObj(this)},
	/*#{1ILTMI90P0MoreFunctions*/
	/*}#1ILTMI90P0MoreFunctions*/
};
VFACT.regUITemplate("1ILTMI90P0",WebAction);
VFACT.regUITemplate("WebAction",WebAction);
/*#{1ILTMI90P0MoreCodes*/
/*}#1ILTMI90P0MoreCodes*/

/*#{1ILTMHV9J0EndDoc*/
/*}#1ILTMHV9J0EndDoc*/

export{WebStep,WebAction};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DataDoc",
//	"jaxId": "1ILTMHV9J0",
//	"attrs": {
//		"editObjs": {
//			"jaxId": "1ILTMHV9J1",
//			"attrs": {
//				"WebStep": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1ILTMHV9J2",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1ILTMHV9J3",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1ILTMHV9J4",
//							"attrs": {
//								"state": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1ILTNSU0V0",
//									"attrs": {
//										"type": "string",
//										"desc": "当前执行任务的状态，Execute代表要执行操作网页的步骤",
//										"choices": {
//											"type": "array",
//											"def": "Array",
//											"attrs": [
//												{
//													"type": "string",
//													"valText": "Execute"
//												},
//												{
//													"type": "string",
//													"valText": "Finish"
//												},
//												{
//													"type": "string",
//													"valText": "Failed"
//												},
//												{
//													"type": "string",
//													"valText": "Abort"
//												}
//											]
//										}
//									}
//								},
//								"content": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1ILTO1F8P0",
//									"attrs": {
//										"type": "string",
//										"desc": "当前步骤的说明或者任务执行结果"
//									}
//								},
//								"execute": {
//									"type": "object",
//									"def": "EditClassObjPpt",
//									"jaxId": "1ILTO1F8P1",
//									"attrs": {
//										"type": "object",
//										"class": "\"1ILTMI90P0\"",
//										"desc": "如果state是\"Execute\"，要执行的步骤内容。",
//										"required": "true"
//									}
//								}
//							}
//						},
//						"functions": {
//							"jaxId": "1ILTMHV9J5",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false",
//						"exportClass": "false"
//					},
//					"mockups": {}
//				},
//				"WebAction": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1ILTMI90P0",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1ILTMLIJ10",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1ILTMLIJ11",
//							"attrs": {
//								"action": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1ILTMLIJ12",
//									"attrs": {
//										"type": "string",
//										"desc": "要执行的网页操作动作类型，如果不用执行操作：NA",
//										"choices": {
//											"type": "array",
//											"def": "Array",
//											"attrs": [
//												{
//													"type": "string",
//													"valText": "Click"
//												},
//												{
//													"type": "string",
//													"valText": "Input"
//												},
//												{
//													"type": "string",
//													"valText": "PressKey"
//												},
//												{
//													"type": "string",
//													"valText": "Goto"
//												},
//												{
//													"type": "string",
//													"valText": "Hover"
//												},
//												{
//													"type": "string",
//													"valText": "Back"
//												},
//												{
//													"type": "string",
//													"valText": "Scroll"
//												},
//												{
//													"type": "string",
//													"valText": "Tool"
//												},
//												{
//													"type": "string",
//													"valText": "UserAction"
//												},
//												{
//													"type": "string",
//													"valText": "Ask"
//												},
//												{
//													"type": "string",
//													"valText": "NA"
//												}
//											]
//										}
//									}
//								},
//								"queryHint": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1ILTMTI9E0",
//									"attrs": {
//										"type": "string",
//										"required": "false",
//										"desc": "用于定位要操作的目标HTML元素的描述。"
//									}
//								},
//								"targetAAEId": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1ILTN9ACU0",
//									"attrs": {
//										"type": "string",
//										"desc": "要操作的目标元素的aaeid属性值",
//										"required": "false"
//									}
//								},
//								"waitEvent": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1ILTN9ACU1",
//									"attrs": {
//										"type": "string",
//										"required": "false",
//										"choices": {
//											"type": "array",
//											"def": "Array",
//											"attrs": [
//												{
//													"type": "string",
//													"valText": "Navi"
//												},
//												{
//													"type": "string",
//													"valText": "PickFile"
//												}
//											]
//										},
//										"desc": "如果步骤会导致页面切换或者打开上传文件的对话框，相应的设定此属性"
//									}
//								},
//								"text": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1ILTNGHMK0",
//									"attrs": {
//										"type": "string",
//										"desc": "如果action是\"input\"，要输入的文本内容。",
//										"required": "false"
//									}
//								},
//								"key": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1ILTNGHMK1",
//									"attrs": {
//										"type": "string",
//										"desc": "如果action是\"PressKey\"，要按的键的键码",
//										"required": "false"
//									}
//								},
//								"url": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1ILTNNEHD0",
//									"attrs": {
//										"type": "string",
//										"required": "false",
//										"desc": "如果actoin是\"Goto\"，目标网址"
//									}
//								},
//								"file": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1ILTNNEHD1",
//									"attrs": {
//										"type": "string",
//										"required": "false",
//										"desc": "如果action是\"PickFIle\"，要上传的文件的地址/路径，通常是hub://开始的"
//									}
//								},
//								"scroll": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1ILTNPHR50",
//									"attrs": {
//										"type": "int",
//										"required": "false",
//										"desc": "当action为\"scroll\"时，滚动的距离，正数为向下滚动，负数为向上滚动"
//									}
//								},
//								"tool": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1ILUPVN0U0",
//									"attrs": {
//										"type": "string",
//										"desc": "要调用的外部工具名称",
//										"required": "false"
//									}
//								},
//								"toolArg": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1ILUPVN0U1",
//									"attrs": {
//										"type": "string",
//										"desc": "调用工具/智能体的指令/参数的文本",
//										"required": "false"
//									}
//								}
//							}
//						},
//						"functions": {
//							"jaxId": "1ILTMLIJ13",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false",
//						"exportClass": "false"
//					},
//					"mockups": {}
//				}
//			}
//		}
//	}
//}