//Auto genterated by Cody
import VFACT from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1IIUI7JO70StartDoc*/
/*}#1IIUI7JO70StartDoc*/
let AskUser={
	name:"AskUser",//1IIUI7JO80
	type:"object",
	label:undefined,
	properties:{
		items:{
			name:"items",type:"array",
			required:false,
			initLength:0,
			element:{
				"type":"object","label":'###:',"class":"1IIUI80EH0"
			},
			desc:"菜单选项列表",
		},
		/*#{1IIUI7JO80MoreProperties*/
		/*}#1IIUI7JO80MoreProperties*/
	},
	desc:undefined,
	newObject(){return VFACT.newUITemplateObj(this)},
	/*#{1IIUI7JO80MoreFunctions*/
	/*}#1IIUI7JO80MoreFunctions*/
};
VFACT.regUITemplate("1IIUI7JO80",AskUser);
VFACT.regUITemplate("AskUser",AskUser);
/*#{1IIUI7JO80MoreCodes*/
/*}#1IIUI7JO80MoreCodes*/
let AskMenuItem={
	name:"AskMenuItem",//1IIUI80EH0
	type:"object",
	label:undefined,
	properties:{
		emoji:{
			name:"emoji",type:"string",
			desc:"用于描述该选项的Emoji符号，不要超过两个符号",
		},
		text:{
			name:"text",type:"string",
			desc:"菜单选项的文本",
		},
		/*#{1IIUI80EH0MoreProperties*/
		/*}#1IIUI80EH0MoreProperties*/
	},
	desc:undefined,
	newObject(){return VFACT.newUITemplateObj(this)},
	/*#{1IIUI80EH0MoreFunctions*/
	/*}#1IIUI80EH0MoreFunctions*/
};
VFACT.regUITemplate("1IIUI80EH0",AskMenuItem);
VFACT.regUITemplate("AskMenuItem",AskMenuItem);
/*#{1IIUI80EH0MoreCodes*/
/*}#1IIUI80EH0MoreCodes*/

/*#{1IIUI7JO70EndDoc*/
/*}#1IIUI7JO70EndDoc*/

export{AskUser,AskMenuItem};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DataDoc",
//	"jaxId": "1IIUI7JO70",
//	"attrs": {
//		"editObjs": {
//			"jaxId": "1IIUI7JO71",
//			"attrs": {
//				"AskUser": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1IIUI7JO80",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1IIUI7JO81",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1IIUI7JO82",
//							"attrs": {
//								"items": {
//									"type": "object",
//									"def": "EditClassAryPpt",
//									"jaxId": "1IIUIBTF20",
//									"attrs": {
//										"type": "array",
//										"element": {
//											"jaxId": "1IIUIBTF21",
//											"attrs": {
//												"type": "Object",
//												"label": "#'###:'",
//												"class": "\"1IIUI80EH0\""
//											}
//										},
//										"initLength": "0",
//										"desc": "菜单选项列表",
//										"required": "false"
//									}
//								}
//							}
//						},
//						"functions": {
//							"jaxId": "1IIUI7JO83",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false",
//						"exportClass": "false"
//					},
//					"mockups": {}
//				},
//				"AskMenuItem": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1IIUI80EH0",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1IIUIBTF22",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1IIUIBTF23",
//							"attrs": {
//								"emoji": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1IIUIBTF24",
//									"attrs": {
//										"type": "string",
//										"desc": "用于描述该选项的Emoji符号，不要超过两个符号"
//									}
//								},
//								"text": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1IIUIBTF25",
//									"attrs": {
//										"type": "string",
//										"desc": "菜单选项的文本"
//									}
//								}
//							}
//						},
//						"functions": {
//							"jaxId": "1IIUIBTF26",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false",
//						"exportClass": "false"
//					},
//					"mockups": {}
//				}
//			}
//		}
//	}
//}