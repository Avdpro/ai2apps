//Auto genterated by Cody
import VFACT from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1IG5ML8LR0StartDoc*/
/*}#1IG5ML8LR0StartDoc*/
let ResultPreview={
	name:"ResultPreview",//1IG5ML8LS0
	type:"object",
	label:undefined,
	properties:{
		brief:{
			name:"brief",type:"string",
			desc:"当前项目的简短总结，包括采用了什么技术，达到什么目的，有什么优势。",
		},
		aiPrj:{
			name:"aiPrj",type:"bool",
			desc:"项目是否是AI相关的",
		},
		aiType:{
			name:"aiType",type:"string",
			required:false,
			choices:[
				"Chat"," Graphic","Voice","Video","Coding","Others"
			],
			desc:"如果是AI项目，属于那种类型",
		},
		diffusers:{
			name:"diffusers",type:"bool",
			required:false,
			desc:"是否可以用diffusers来执行",
		},
		diffusersPipeline:{
			name:"diffusersPipeline",type:"bool",
			desc:"是否有diffusers pipline",
		},
		comfyUI:{
			name:"comfyUI",type:"bool",
			desc:"是否是一个comfyUI项目",
		},
		setup:{
			name:"setup",type:"bool",
			desc:"本地是否可以部署项目",
		},
		node:{
			name:"node",type:"bool",
			desc:"项目是否需要node环境",
		},
		python:{
			name:"python",type:"bool",
			desc:"项目是否需要python环境",
		},
		warn:{
			name:"warn",type:"string",
			desc:"部署时可能遇到的问题",
		},
		error:{
			name:"error",type:"string",
			required:false,
			desc:"如果不能部署项目，不能部署的错误原因",
		},
		summary:{
			name:"summary",type:"string",
			desc:"总结：项目用途，项目技术要点，以及在本地部署项目的可行性总结。",
		},
		/*#{1IG5ML8LS0MoreProperties*/
		/*}#1IG5ML8LS0MoreProperties*/
	},
	desc:undefined,
	newObject(){return VFACT.newUITemplateObj(this)},
	/*#{1IG5ML8LS0MoreFunctions*/
	/*}#1IG5ML8LS0MoreFunctions*/
};
VFACT.regUITemplate("1IG5ML8LS0",ResultPreview);
VFACT.regUITemplate("ResultPreview",ResultPreview);
/*#{1IG5ML8LS0MoreCodes*/
/*}#1IG5ML8LS0MoreCodes*/

/*#{1IG5ML8LR0EndDoc*/
/*}#1IG5ML8LR0EndDoc*/

export{ResultPreview};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DataDoc",
//	"jaxId": "1IG5ML8LR0",
//	"attrs": {
//		"editObjs": {
//			"jaxId": "1IG5ML8LR1",
//			"attrs": {
//				"ResultPreview": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1IG5ML8LS0",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1IG5ML8LS1",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1IG5ML8LS2",
//							"attrs": {
//								"brief": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1IITDE7SR0",
//									"attrs": {
//										"type": "string",
//										"desc": "当前项目的简短总结，包括采用了什么技术，达到什么目的，有什么优势。"
//									}
//								},
//								"aiPrj": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1IITDE7SR1",
//									"attrs": {
//										"type": "bool",
//										"desc": "项目是否是AI相关的"
//									}
//								},
//								"aiType": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1IITDE7SR2",
//									"attrs": {
//										"type": "string",
//										"required": "false",
//										"desc": "如果是AI项目，属于那种类型",
//										"choices": {
//											"type": "array",
//											"def": "Array",
//											"attrs": [
//												{
//													"type": "string",
//													"valText": "Chat"
//												},
//												{
//													"type": "string",
//													"valText": " Graphic"
//												},
//												{
//													"type": "string",
//													"valText": "Voice"
//												},
//												{
//													"type": "string",
//													"valText": "Video"
//												},
//												{
//													"type": "string",
//													"valText": "Coding"
//												},
//												{
//													"type": "string",
//													"valText": "Others"
//												}
//											]
//										}
//									}
//								},
//								"diffusers": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1IITDE7SS0",
//									"attrs": {
//										"type": "bool",
//										"required": "false",
//										"desc": "是否可以用diffusers来执行"
//									}
//								},
//								"diffusersPipeline": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1IITDE7SS1",
//									"attrs": {
//										"type": "bool",
//										"desc": "是否有diffusers pipline"
//									}
//								},
//								"comfyUI": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1IITDE7SS2",
//									"attrs": {
//										"type": "bool",
//										"desc": "是否是一个comfyUI项目"
//									}
//								},
//								"setup": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1IG5MQVQR0",
//									"attrs": {
//										"type": "bool",
//										"desc": "本地是否可以部署项目"
//									}
//								},
//								"node": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1IG5MQVQR4",
//									"attrs": {
//										"type": "bool",
//										"desc": "项目是否需要node环境"
//									}
//								},
//								"python": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1IG5MQVQR5",
//									"attrs": {
//										"type": "bool",
//										"desc": "项目是否需要python环境"
//									}
//								},
//								"warn": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1IG5MQVQR1",
//									"attrs": {
//										"type": "string",
//										"desc": "部署时可能遇到的问题"
//									}
//								},
//								"error": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1IG5MQVQR2",
//									"attrs": {
//										"type": "string",
//										"desc": "如果不能部署项目，不能部署的错误原因",
//										"required": "false"
//									}
//								},
//								"summary": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1IG5MQVQR3",
//									"attrs": {
//										"type": "string",
//										"desc": "总结：项目用途，项目技术要点，以及在本地部署项目的可行性总结。"
//									}
//								}
//							}
//						},
//						"functions": {
//							"jaxId": "1IG5ML8LS3",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false",
//						"exportClass": "false"
//					},
//					"mockups": {}
//				}
//			}
//		}
//	}
//}