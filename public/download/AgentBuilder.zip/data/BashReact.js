//Auto genterated by Cody
import VFACT from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1IIF6SA1I0StartDoc*/
/*}#1IIF6SA1I0StartDoc*/
let BashReact={
	name:"BashReact",//1IIF6SA1I2
	type:"object",
	label:undefined,
	properties:{
		action:{
			name:"action",type:"string",
			defaultValue:undefined,
			required:true,
			choices:[
				"Wait","Input","AskUser","Finish"
			],
			desc:"下一步行动",
		},
		input:{
			name:"input",type:"string",
			required:false,
			desc:"当\"action\"为\"Input\"，要输出Terminal的内容。",
		},
		/*#{1IIF6SA1I2MoreProperties*/
		/*}#1IIF6SA1I2MoreProperties*/
	},
	desc:undefined,
	newObject(){return VFACT.newUITemplateObj(this)},
	/*#{1IIF6SA1I2MoreFunctions*/
	/*}#1IIF6SA1I2MoreFunctions*/
};
VFACT.regUITemplate("1IIF6SA1I2",BashReact);
VFACT.regUITemplate("BashReact",BashReact);
/*#{1IIF6SA1I2MoreCodes*/
/*}#1IIF6SA1I2MoreCodes*/

/*#{1IIF6SA1I0EndDoc*/
/*}#1IIF6SA1I0EndDoc*/

export{BashReact};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DataDoc",
//	"jaxId": "1IIF6SA1I0",
//	"attrs": {
//		"editObjs": {
//			"jaxId": "1IIF6SA1I1",
//			"attrs": {
//				"BashReact": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1IIF6SA1I2",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1IIF6SA1I3",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1IIF6SA1I4",
//							"attrs": {
//								"action": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1IIF6U1A60",
//									"attrs": {
//										"type": "string",
//										"defaultValue": "",
//										"required": "true",
//										"desc": "下一步行动",
//										"choices": {
//											"type": "array",
//											"def": "Array",
//											"attrs": [
//												{
//													"type": "string",
//													"valText": "Wait"
//												},
//												{
//													"type": "string",
//													"valText": "Input"
//												},
//												{
//													"type": "string",
//													"valText": "AskUser"
//												},
//												{
//													"type": "string",
//													"valText": "Finish"
//												}
//											]
//										}
//									}
//								},
//								"input": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1IIF720150",
//									"attrs": {
//										"type": "string",
//										"desc": "当\"action\"为\"Input\"，要输出Terminal的内容。",
//										"required": "false"
//									}
//								}
//							}
//						},
//						"functions": {
//							"jaxId": "1IIF6SA1I5",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false",
//						"exportClass": "false"
//					},
//					"mockups": {}
//				}
//			}
//		}
//	}
//}