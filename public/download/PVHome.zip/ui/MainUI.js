//Auto genterated by Cody
import {$P,VFACT,callAfter} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {CardPreview} from "./CardPreview.js";
/*#{1GGJKM84D0StartDoc*/
import Base64 from "/@tabos/utils/base64.js";
import {tabFS,tabNT} from "/@tabos";
import {zip2Path} from "/@zippath";
import {getLocalPkgInfo,installPkg,setupDiskPkgs} from "/@pkg/pkgUtil.js";
import tabEnv from "/@tabos/tabos_env.js";
/*}#1GGJKM84D0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let MainUI=function(app,appFrame){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let boxContents,boxPVs;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1GGJKM84D1LocalVals*/
	/*}#1GGJKM84D1LocalVals*/
	
	/*#{1GGJKM84D1PreState*/
	/*}#1GGJKM84D1PreState*/
	state={
		"counter":0,
		/*#{1GGJKM84D6ExState*/
		/*}#1GGJKM84D6ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1GGJKM84D1PostState*/
	/*}#1GGJKM84D1PostState*/
	cssVO={
		"hash":"1GGJKM84D1",nameHost:true,
		"type":"view","x":0,"y":0,"w":"100%","h":"100%","padding":[15,15,10,15],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
		children:[
			{
				"hash":"1GGJKQ2PD0",
				"type":"text","id":"TxtTitle","position":"relative","x":0,"y":0,"w":"100%","h":50,"autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"color":cfgColor.fontBodySub,"text":(($ln==="CN")?("App 预览"):("Application Previews")),"fontSize":txtSize.large,"fontWeight":"bold","fontStyle":"normal",
				"textDecoration":"","alignH":1,"alignV":1,
			},
			{
				"hash":"1HGUIL22F0",
				"type":"hud","id":"BoxContents","position":"relative","x":0,"y":0,"w":"100%","h":"","overflow":"auto-y","margin":[10,0,0,0],"minW":"","minH":"","maxW":"",
				"maxH":"","styleClass":"","contentLayout":"flex-y","flex":true,"itemsAlign":1,
				children:[
					{
						"hash":"1HGUKUOPC0",
						"type":"hud","id":"BoxPVs","position":"relative","x":0,"y":0,"w":"100%","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
						"itemsAlign":1,
						children:[
							{
								"hash":"1HGUL96SL0",
								"type":CardPreview("Title","Card intro text",appCfg.sharedAssets+"/prj.svg","",50,50),"position":"relative","x":0,"y":0,"margin":[0,0,10,0],
							},
							{
								"hash":"1HGUL9C4K0",
								"type":CardPreview("Title","Card intro text",appCfg.sharedAssets+"/prj.svg","",50,50),"position":"relative","x":0,"y":0,"margin":[0,0,10,0],
							}
						],
					},
					{
						"hash":"1HGUL05QQ0",
						"type":"text","id":"TxtNoPreview","position":"relative","x":0,"y":0,"w":"100%","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodyLit"],
						"text":"No previews installed.","fontSize":txtSize.midPlus,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignH":1,
					}
				],
			}
		],
		/*#{1GGJKM84D1ExtraCSS*/
		/*}#1GGJKM84D1ExtraCSS*/
		faces:{
			"HasPreviews":{
				/*BoxPVs*/"#1HGUKUOPC0":{
					"display":1
				},
				/*TxtNoPreview*/"#1HGUL05QQ0":{
					"display":0
				}
			},"NoPreviews":{
				/*BoxPVs*/"#1HGUKUOPC0":{
					"display":0
				},
				/*TxtNoPreview*/"#1HGUL05QQ0":{
					"display":1
				}
			},"CheckSys":{
			}
		},
		OnCreate:function(){
			self=this;
			boxContents=self.BoxContents;boxPVs=self.BoxPVs;
			/*#{1GGJKM84D1Create*/
			let userId,key,slot;
			let params=VFACT.appParams;
			self.initPreviews();
			key=params.key;
			userId=params.userId;
			slot=params.slot;
			if(userId && slot && key){
				slot=parseInt(slot);
				self.installPreview(userId,slot,key);
			}
			/*}#1GGJKM84D1Create*/
		},
		/*#{1GGJKM84D1EndCSS*/
		/*}#1GGJKM84D1EndCSS*/
	};
	/*#{1GGJKM84D1PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.checkSysemPackages=async function(){
		let resVO,list,pkgName,curVIdx,sysVIdx,pkgInfo;
		resVO=await tabNT.makeCall("getKeyPackages",{});
		if(resVO && resVO.code===200){
			list=resVO.packages.preview;
			app.keyPackages=list;
			for(pkgName in list){
				sysVIdx=list[pkgName];
				pkgInfo=await getLocalPkgInfo(pkgName);
				if(!pkgInfo || pkgInfo.versionIdx<sysVIdx){
					console.log(`Package ${pkgName} is not ready: ${sysVIdx} vs ${pkgInfo?pkgInfo.versionIdx:-1}`);
					return true;
				}
				console.log(`Package ${pkgName} is ready: ${sysVIdx} vs ${pkgInfo.versionIdx}`);
			}
		}
		return false;
	};
	
	//------------------------------------------------------------------------
	cssVO.initPreviews=async function(){
		let list,entry,json,time,count;
		boxPVs.clearChildren();
		list=await tabFS.getEntries("/");
		if(list.length){
			self.showFace("HasPreviews");
			count=0;
			for(entry of list){
				if(entry.name.startsWith("PV")){
					try{
						json=await tabFS.readFile(`/${entry.name}/preview.json`,"utf8");
						json=JSON.parse(json);
						json.path=`/${entry.name}`;
						json.entry=`/~/${entry.name}/`+(json.entry||"app.html");
					}catch(err){
						json={
							path:`/${entry.name}`,
							entry:`/~/${entry.name}/app.html`,
							name:entry.name,
							time:entry.modifyTime,
							user:"NA"
						};
					}
					time=new Date();
					if(json.time>0){
						time.setTime(json.time);
					}
					time=time.toLocaleString();
					boxPVs.appendNewChild({
						type:CardPreview(json.name,`${json.user}\n${time}`,appCfg.sharedAssets+"/prj.svg",50,50),x:0,y:0,position:"relative",w:"90%",
						maxW:360,json:json,margin:[0,0,15,0],
						OnClick(){
							window.open(this.json.entry,"","noreferrer");
						},
						OnDelete:async function(){
							if(window.confirm("Are you sure to remove this preview?")){
								if(this.json.path.startsWith("/PV_")){
									await tabFS.del(this.json.path,true);
								}
								self.initPreviews();
							}
						}
					});
					count++;
				}
			}
			if(!count){
				self.showFace("NoPreviews");
			}
			//TODO: Add reset button.
		}else{
			self.showFace("NoPreviews");
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.installPreview=async function(userId,slot,key){
		let path;
		path=await app.modalDlg("/@homekit/ui/DlgCloud.js",{
			mode:"Work",
			title:"Preview",
			workingText:"Install preview...",
			work:async function(tty){
				let callVO,resVO,zipData,diskName,diskObj,hasUpdate;
				//First, check and update system key packags:
				tty.texOut((($ln==="CN")?(`检查系统更新……\n`):/*EN*/(`Check system update...\n`)));
				hasUpdate=await self.checkSysemPackages();
				if(hasUpdate){
					let list,pkgName,options;
					list=app.keyPackages;
					tty.texOut((($ln==="CN")?(`更新系统……\n`):/*EN*/(`Update system...\n`)));
					options={
						mode:"install",
						noMerge:false,
						upgrade:true,
						sysDisk:"coke",
						tree:true,
						tty:tty
					};
					for(pkgName in list){
						tabEnv.chdir("/");
						await installPkg(tabEnv,pkgName,options);
					}
				}
				callVO={
					previewUserId:userId,
					slot:slot,
					key:key			
				};
				tty.textOut((($ln==="CN")?(`下载预览包...\n`):/*EN*/(`Download preview package...\n`)));
				resVO=await tabNT.makeCall('getPreview',callVO,10000);
				if(resVO.code!==200){
					tty.textOut((($ln==="CN")?(`下载预览包失败: ${resVO.info}\n`):/*EN*/(`Download preview package failed:  ${resVO.info}\n`)));
					return null;
				}
				zipData=resVO.zip;
				zipData=Base64.decode(zipData);
				diskName="PV_"+key;
				diskObj=await tabFS.openDisk(diskName,1);
				if(!diskObj){
					tty.textOut("Create folder error\n");
					return null;
				}
	
				tty.textOut("Extract preview zip...\n");
				await zip2Path("/"+diskName,zipData,0,tty);
				tty.textOut("Extract preview zip done.\n");
				tty.textOut("Setup packages...\n");
				await setupDiskPkgs(tty,diskName);
				tty.textOut("Setup packages done.\n");
				return "/"+diskName;
			}
		});
		if(path){
			let json;
			try{
				json=await tabFS.readFile(`${path}/preview.json`,"utf8");
				json=JSON.parse(json);
			}catch(err){
				json={
					entry:`${path}/app.html`,
				};
			}
			path=path+"/"+json.entry;
			window.open("/~"+path,"");
			self.initPreviews();
		}
	};
	/*}#1GGJKM84D1PostCSSVO*/
	return cssVO;
};
/*#{1GGJKM84D1ExCodes*/
/*}#1GGJKM84D1ExCodes*/


export default MainUI;
export{MainUI};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "UIView",
//	"jaxId": "1GGJKM84D0",
//	"editVersion": 49,
//	"attrs": {
//		"editEnv": {
//			"type": "object",
//			"jaxId": "1GGJKM84D2",
//			"editVersion": 30,
//			"attrs": {
//				"device": "iPhone 375x750",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "#cfgColor.body",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"type": "object",
//			"jaxId": "1GGJKM84D3",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"model": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1H90TKKV70",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"createArgs": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1GGJKM84D4",
//			"editVersion": 16,
//			"attrs": {
//				"app": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"appFrame": {
//					"type": "auto",
//					"valText": "null"
//				}
//			}
//		},
//		"localVars": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1GGJKM84D5",
//			"editVersion": 18,
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"type": "object",
//			"def": "StateObj",
//			"jaxId": "1GGJKM84D6",
//			"editVersion": 4,
//			"attrs": {
//				"counter": {
//					"type": "int",
//					"valText": "0"
//				}
//			}
//		},
//		"segs": {
//			"type": "array",
//			"attrs": []
//		},
//		"exportTarget": "VFACT document",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"type": "object",
//			"def": "FaceTags",
//			"jaxId": "1GGJKM84D7",
//			"editVersion": 10,
//			"attrs": {
//				"HasPreviews": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HGUL3LSF0",
//					"editVersion": 20,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1HGUL53VU0",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"NoPreviews": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HGUL4RUH0",
//					"editVersion": 16,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1HGUL53VU1",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"CheckSys": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HHSHGHGS0",
//					"editVersion": 16,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1HHSHGHGS1",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"type": "object",
//			"def": "MockupObj",
//			"jaxId": "1HGUIFJGE0",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "view",
//			"jaxId": "1GGJKM84D1",
//			"editVersion": 16,
//			"attrs": {
//				"properties": {
//					"type": "object",
//					"jaxId": "1GGJKM84D8",
//					"editVersion": 228,
//					"attrs": {
//						"type": "view",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "100%",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "[15,15,10,15]",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Flex Y"
//					}
//				},
//				"subHuds": {
//					"type": "array",
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1GGJKQ2PD0",
//							"editVersion": 25,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1GGJKSPTQ0",
//									"editVersion": 204,
//									"attrs": {
//										"type": "text",
//										"id": "TxtTitle",
//										"position": "Relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "50",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "true",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#cfgColor.fontBodySub",
//										"text": {
//											"type": "string",
//											"valText": "Application Previews",
//											"localize": {
//												"EN": "Application Previews",
//												"CN": "App 预览"
//											},
//											"localizable": true
//										},
//										"font": "",
//										"fontSize": "#txtSize.large",
//										"bold": "true",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Center",
//										"alignV": "Center",
//										"wrap": "false",
//										"ellipsis": "false",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0",
//										"autoSizeW": "false",
//										"autoSizeH": "false"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1GGJKSPTQ1",
//									"editVersion": 18,
//									"attrs": {
//										"1HGUL3LSF0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HGUL53VU2",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HGUL53VU3",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HGUL3LSF0",
//											"faceTagName": "HasPreviews"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1GGJKSPTQ2",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1GGJKSPTQ3",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1HGUIL22F0",
//							"editVersion": 31,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1HGUIMBI90",
//									"editVersion": 128,
//									"attrs": {
//										"type": "hud",
//										"id": "BoxContents",
//										"position": "Relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Auto Scroll Y",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[10,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex Y",
//										"flex": "true",
//										"itemsAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1HGUKUOPC0",
//											"editVersion": 32,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HGUL1M7S0",
//													"editVersion": 90,
//													"attrs": {
//														"type": "hud",
//														"id": "BoxPVs",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex Y",
//														"itemsAlign": "Center"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "Gear1HGUJ28VK0",
//															"jaxId": "1HGUL96SL0",
//															"editVersion": 33,
//															"attrs": {
//																"createArgs": {
//																	"type": "object",
//																	"def": "gearCrateArgs",
//																	"jaxId": "1HGULAFPQ0",
//																	"editVersion": 12,
//																	"attrs": {
//																		"title": "Title",
//																		"intro": "Card intro text",
//																		"pic": "#appCfg.sharedAssets+\"/prj.svg\"",
//																		"icon": "",
//																		"picW": "50",
//																		"picH": "50"
//																	}
//																},
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HGULAFPQ1",
//																	"editVersion": 33,
//																	"attrs": {
//																		"type": "#null#>CardPreview(\"Title\",\"Card intro text\",appCfg.sharedAssets+\"/prj.svg\",\"\",50,50)",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"margin": "[0,0,10,0]"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HGULAFPQ2",
//																	"editVersion": 10,
//																	"attrs": {
//																		"1HGUL3LSF0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HGV20UJO0",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HGV20UJO1",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HGUL3LSF0",
//																			"faceTagName": "HasPreviews"
//																		}
//																	}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HGULAFPQ3",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HGULAFPQ4",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"type": "object",
//																	"jaxId": "1HGULAFPQ5",
//																	"editVersion": 0,
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear1HGUJ28VK0",
//															"jaxId": "1HGUL9C4K0",
//															"editVersion": 33,
//															"attrs": {
//																"createArgs": {
//																	"type": "object",
//																	"def": "gearCrateArgs",
//																	"jaxId": "1HGULAFPQ6",
//																	"editVersion": 12,
//																	"attrs": {
//																		"title": "Title",
//																		"intro": "Card intro text",
//																		"pic": "#appCfg.sharedAssets+\"/prj.svg\"",
//																		"icon": "",
//																		"picW": "50",
//																		"picH": "50"
//																	}
//																},
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HGULAFPQ7",
//																	"editVersion": 33,
//																	"attrs": {
//																		"type": "#null#>CardPreview(\"Title\",\"Card intro text\",appCfg.sharedAssets+\"/prj.svg\",\"\",50,50)",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"margin": "[0,0,10,0]"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HGULAFPQ8",
//																	"editVersion": 10,
//																	"attrs": {
//																		"1HGUL3LSF0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HGV20UJO2",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HGV20UJO3",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HGUL3LSF0",
//																			"faceTagName": "HasPreviews"
//																		}
//																	}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HGULAFPQ9",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HGULAFPQ10",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"type": "object",
//																	"jaxId": "1HGULAFPQ11",
//																	"editVersion": 0,
//																	"attrs": {}
//																}
//															}
//														}
//													]
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1HGUL1M7S1",
//													"editVersion": 8,
//													"attrs": {
//														"1HGUL3LSF0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HGUL53VU6",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HGUL53VU7",
//																	"editVersion": 4,
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HGUL3LSF0",
//															"faceTagName": "HasPreviews"
//														},
//														"1HGUL4RUH0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HGUL53VU8",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HGUL53VU9",
//																	"editVersion": 4,
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HGUL4RUH0",
//															"faceTagName": "NoPreviews"
//														}
//													}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1HGUL1M7S2",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1HGUL1M7S3",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "true",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1HGUL05QQ0",
//											"editVersion": 25,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HGUL1M7S4",
//													"editVersion": 130,
//													"attrs": {
//														"type": "text",
//														"id": "TxtNoPreview",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBodyLit\"]",
//														"text": "No previews installed.",
//														"font": "",
//														"fontSize": "#txtSize.midPlus",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Center",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "false",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1HGUL1M7S5",
//													"editVersion": 8,
//													"attrs": {
//														"1HGUL3LSF0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HGUL53VU10",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HGUL53VU11",
//																	"editVersion": 4,
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HGUL3LSF0",
//															"faceTagName": "HasPreviews"
//														},
//														"1HGUL4RUH0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HGUL53VU12",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HGUL53VU13",
//																	"editVersion": 4,
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HGUL4RUH0",
//															"faceTagName": "NoPreviews"
//														}
//													}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1HGUL1M7S6",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1HGUL1M7S7",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1HGUIMBIA0",
//									"editVersion": 18,
//									"attrs": {
//										"1HGUL3LSF0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HGUL53VU14",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HGUL53VU15",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HGUL3LSF0",
//											"faceTagName": "HasPreviews"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1HGUIMBIA1",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1HGUIMBIA2",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"type": "object",
//					"jaxId": "1GGJKM84D9",
//					"editVersion": 18,
//					"attrs": {
//						"1HGUL3LSF0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HGUL53VU18",
//							"editVersion": 4,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1HGUL53VU19",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"anis": {
//									"type": "array",
//									"def": "Array",
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HGUL3LSF0",
//							"faceTagName": "HasPreviews"
//						}
//					}
//				},
//				"functions": {
//					"type": "object",
//					"jaxId": "1GGJKM84D10",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"extraPpts": {
//					"type": "object",
//					"def": "Object",
//					"jaxId": "1GGJKM84D11",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1GGJKM84D12",
//			"editVersion": 70,
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"innerLayout": {
//					"valText": "false"
//				},
//				"marginL": {
//					"valText": "false"
//				},
//				"marginR": {
//					"valText": "false"
//				},
//				"marginT": {
//					"valText": "false"
//				},
//				"marginB": {
//					"valText": "false"
//				},
//				"paddingL": {
//					"valText": "false"
//				},
//				"paddingR": {
//					"valText": "false"
//				},
//				"paddingT": {
//					"valText": "false"
//				},
//				"paddingB": {
//					"valText": "false"
//				},
//				"attach": {
//					"valText": "false"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}