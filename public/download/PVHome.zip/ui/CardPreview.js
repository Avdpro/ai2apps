//Auto genterated by Cody
import {$P,VFACT,callAfter} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
/*#{1HGUJ28VK0StartDoc*/
/*}#1HGUJ28VK0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let CardPreview=function(title,intro,pic,icon,picW,picH){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1H54B0SFB1LocalVals*/
	/*}#1H54B0SFB1LocalVals*/
	
	/*#{1H54B0SFB1PreState*/
	/*}#1H54B0SFB1PreState*/
	/*#{1H54B0SFB1PostState*/
	/*}#1H54B0SFB1PostState*/
	cssVO={
		"hash":"1H54B0SFB1",nameHost:true,
		"type":"button","position":"relative","x":0,"y":0,"w":300,"h":"","padding":10,"minW":"","minH":(pic&&picH>0)?picH+20:30,"maxW":"","maxH":"","styleClass":"",
		"contentLayout":"flex-y","traceSize":true,"subAlign":1,
		children:[
			{
				"hash":"1H54B23MV0",
				"type":"box","id":"BG","x":0,"y":0,"w":"100%","h":"100%","uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":[255,255,255,0],
				"border":1,"borderColor":cfgColor.lineBodyLit,"corner":6,
			},
			{
				"hash":"1H571UPP00",
				"type":"image","x":10,"y":"50%","w":picW||100,"h":picH||picW||100,"anchorY":1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","image":pic,
				"fitSize":"cover","alignX":1,"alignY":1,
			},
			{
				"hash":"1H8H7U93F0",
				"type":"box","x":10,"y":"50%","w":picW||100,"h":picH||picW||100,"anchorY":1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["fontBody"],
				"attached":!!icon,"maskImage":icon,
			},
			{
				"hash":"1H5721BRE0",
				"type":"text","position":"relative","x":(pic&&picW>0)?picW+10:0,"y":0,"w":(pic&&picW>0)?`FW-${picW+30}`:"FW","h":"","autoLayout":true,"uiEvent":-1,
				"margin":[0,0,5,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor.fontBody,"text":title,"fontSize":txtSize.midPlus,"fontWeight":"normal",
				"fontStyle":"normal","textDecoration":"","ellipsis":true,
			},
			{
				"hash":"1H572917N0",
				"type":"text","position":"relative","x":(pic&&picW>0)?picW+10:0,"y":0,"w":(pic&&picW>0)?`FW-${picW+30}`:"FW-20","h":"","autoLayout":true,"minW":"",
				"minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor.fontBodySub,"text":intro,"fontSize":txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal",
				"textDecoration":"","wrap":true,
			},
			{
				"hash":"1HGUJIOI20",
				"type":BtnIcon(cfgColor.fontBodySub,28,0,appCfg.sharedAssets+"/trash.svg",null),"x":">calc(100%        -  33px)","y":5,
				"OnClick":function(event){
					/*#{1HH1F4LC40FunctionBody*/
					if(self.OnDelete){
						self.OnDelete();
					}
					/*}#1HH1F4LC40FunctionBody*/
				},
			},
			{
				"hash":"1HHSG6EE60",
				"type":"box","id":"BoxNew","x":">calc(100% - 55px)","y":5,"w":50,"h":25,"display":0,"styleClass":"","background":cfgColor["primary"],"corner":[10,0,10,0],
				children:[
					{
						"hash":"1HHSG8C1O0",
						"type":"text","x":0,"y":0,"w":"100%","h":"100%","styleClass":"","color":cfgColor["fontPrimary"],"text":"New!","fontSize":txtSize.smallPlus,"fontWeight":"bold",
						"fontStyle":"normal","textDecoration":"","alignH":1,"alignV":1,
					}
				],
			}
		],
		/*#{1H54B0SFB1ExtraCSS*/
		/*}#1H54B0SFB1ExtraCSS*/
		faces:{
			"up":{
				"#self":{
					"alpha":1
				},
				/*BG*/"#1H54B23MV0":{
					"border":1,"borderColor":cfgColor.lineBodyLit
				}
			},"over":{
				"#self":{
					"alpha":1
				},
				/*BG*/"#1H54B23MV0":{
					"border":2,"borderColor":cfgColor.lineBody
				}
			},"down":{
				"#self":{
					"alpha":1
				},
				/*BG*/"#1H54B23MV0":{
					"border":2,"borderColor":cfgColor.lineBody
				}
			},"gray":{
				"#self":{
					"alpha":0.5
				},
				/*BG*/"#1H54B23MV0":{
					"border":1,"borderColor":cfgColor.lineBodyLit
				}
			},"new":{
				"#1HGUJIOI20":{
					"display":0
				},
				/*BoxNew*/"#1HHSG6EE60":{
					"display":1
				}
			}
		},
		OnCreate:function(){
			self=this;
			
			/*#{1H54B0SFB1Create*/
			/*}#1H54B0SFB1Create*/
		},
		/*#{1H54B0SFB1EndCSS*/
		/*}#1H54B0SFB1EndCSS*/
	};
	/*#{1H54B0SFB1PostCSSVO*/
	/*}#1H54B0SFB1PostCSSVO*/
	return cssVO;
};
/*#{1H54B0SFB1ExCodes*/
/*}#1H54B0SFB1ExCodes*/

CardPreview.gearExport={
	framework: "jax",
	hudType: "button",
	"showName":(($ln==="CN")?("PV 卡片"):("PV Card")),icon:"rename.svg",previewImg:false,
	fixPose:false,initW:300,initH:80,
	"desc":(($ln==="CN")?("一个带有标题和简介的卡片。可能在左侧有一张图片或者图标。"):("A card with title and intro. Maybe has a picture image on left side.")),
	catalog:"Views",
	args: {
		"title": {
			"name": "title", "showName": "title", "type": "string", "key": true, "fixed": true, "initVal": "Title", "localizable": true
		}, 
		"intro": {
			"name": "intro", "showName": "intro", "type": "string", "key": true, "fixed": true, "initVal": "Card intro text", "localizable": true
		}, 
		"pic": {
			"name": "pic", "showName": "pic", "type": "url", "key": true, "fixed": true, "initVal": "/~/-tabos/shared/assets/prj.svg", "initValText": "#appCfg.sharedAssets+\"/prj.svg\""
		}, 
		"icon": {
			"name": "icon", "showName": "icon", "type": "url", "key": true, "fixed": true, "initVal": ""
		}, 
		"picW": {
			"name": "picW", "showName": "picW", "type": "int", "key": true, "fixed": true, "initVal": 50
		}, 
		"picH": {
			"name": "picH", "showName": "picH", "type": "int", "key": true, "fixed": true, "initVal": 50
		}
	},
	state:{
	},
	properties:["id","position","x","y","w","anchorH","anchorV","autoLayout","display","uiEvent","alpha","rotate","scale","filter","cursor","zIndex","flex","margin","minW","minH","maxW","maxH","enable","drag"],
	faces:["up","over","down","gray","new"],
	subContainers:{
	},
	/*#{1HGUJ28VK0ExGearInfo*/
	/*}#1HGUJ28VK0ExGearInfo*/
};
export default CardPreview;
export{CardPreview};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearButton",
//	"jaxId": "1HGUJ28VK0",
//	"editVersion": 152,
//	"attrs": {
//		"editEnv": {
//			"type": "object",
//			"jaxId": "1H54B0SFB2",
//			"editVersion": 10,
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"type": "object",
//			"jaxId": "1H54B0SFC0",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"model": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1H5MLLAOG0",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"createArgs": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1H54B0SFC1",
//			"editVersion": 84,
//			"attrs": {
//				"title": {
//					"type": "string",
//					"valText": "Title",
//					"localizable": true
//				},
//				"intro": {
//					"type": "string",
//					"valText": "Card intro text",
//					"localizable": true
//				},
//				"pic": {
//					"type": "url",
//					"valText": "#appCfg.sharedAssets+\"/prj.svg\""
//				},
//				"icon": {
//					"type": "url",
//					"valText": ""
//				},
//				"picW": {
//					"type": "int",
//					"valText": "50"
//				},
//				"picH": {
//					"type": "int",
//					"valText": "50"
//				}
//			}
//		},
//		"localVars": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1H54B0SFC2",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"type": "object",
//			"def": "StateObj",
//			"jaxId": "1H54B0SFC3",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"segs": {
//			"type": "array",
//			"attrs": []
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": {
//			"type": "string",
//			"valText": "PV Card",
//			"localize": {
//				"EN": "PV Card",
//				"CN": "PV 卡片"
//			},
//			"localizable": true
//		},
//		"gearIcon": "rename.svg",
//		"gearW": "300",
//		"gearH": "80",
//		"gearCatalog": "Views",
//		"description": {
//			"type": "string",
//			"valText": "A card with title and intro. Maybe has a picture image on left side.",
//			"localize": {
//				"EN": "A card with title and intro. Maybe has a picture image on left side.",
//				"CN": "一个带有标题和简介的卡片。可能在左侧有一张图片或者图标。"
//			},
//			"localizable": true
//		},
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"type": "object",
//			"def": "FaceTags",
//			"jaxId": "1H54B0SFC4",
//			"editVersion": 10,
//			"attrs": {
//				"up": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H599SSCN0",
//					"editVersion": 16,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1H59BOAKE0",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"over": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H59BOAKE1",
//					"editVersion": 16,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1H59BOAKE2",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"down": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H59BOAKE3",
//					"editVersion": 16,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1H59BOAKE4",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"gray": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H59CBSSK0",
//					"editVersion": 16,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1H59CCI1N0",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"new": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HHSGAA4O0",
//					"editVersion": 16,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1HHSGAKGN0",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"type": "object",
//			"def": "MockupObj",
//			"jaxId": "1HGUJ295U0",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "button",
//			"jaxId": "1H54B0SFB1",
//			"editVersion": 29,
//			"attrs": {
//				"properties": {
//					"type": "object",
//					"jaxId": "1H54B0SFC5",
//					"editVersion": 150,
//					"attrs": {
//						"type": "button",
//						"id": "",
//						"position": "Relative",
//						"x": "0",
//						"y": "0",
//						"w": "300",
//						"h": "\"\"",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "10",
//						"minW": "",
//						"minH": "#(pic&&picH>0)?picH+20:30",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"enable": "true",
//						"drag": "NA",
//						"contentLayout": "Flex Y",
//						"traceSize": "true",
//						"subAlign": "Center"
//					}
//				},
//				"subHuds": {
//					"type": "array",
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1H54B23MV0",
//							"editVersion": 50,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H572GMLL0",
//									"editVersion": 228,
//									"attrs": {
//										"type": "box",
//										"id": "BG",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "[255,255,255,0]",
//										"border": "1",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor.lineBodyLit",
//										"corner": "6",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1H572GMLL1",
//									"editVersion": 24,
//									"attrs": {
//										"1H599SSCN0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H59CCI1N1",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H59CCI1N2",
//													"editVersion": 8,
//													"attrs": {
//														"border": {
//															"type": "auto",
//															"valText": "1",
//															"editMode": "edges"
//														},
//														"borderColor": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor.lineBodyLit"
//														}
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H599SSCN0",
//											"faceTagName": "up"
//										},
//										"1H59BOAKE1": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H59CCI1N3",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H59CCI1N4",
//													"editVersion": 16,
//													"attrs": {
//														"border": {
//															"type": "auto",
//															"valText": "2",
//															"editMode": "edges"
//														},
//														"borderColor": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor.lineBody"
//														}
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H59BOAKE1",
//											"faceTagName": "over"
//										},
//										"1H59BOAKE3": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H59CCI1N5",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H59CCI1N6",
//													"editVersion": 20,
//													"attrs": {
//														"border": {
//															"type": "auto",
//															"valText": "2",
//															"editMode": "edges"
//														},
//														"borderColor": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor.lineBody"
//														}
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H59BOAKE3",
//											"faceTagName": "down"
//										},
//										"1H59CBSSK0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H59CJKI00",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H59CJKI01",
//													"editVersion": 8,
//													"attrs": {
//														"border": {
//															"type": "auto",
//															"valText": "1",
//															"editMode": "edges"
//														},
//														"borderColor": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor.lineBodyLit"
//														}
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H59CBSSK0",
//											"faceTagName": "gray"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1H572GMLL2",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1H572GMLL3",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "image",
//							"jaxId": "1H571UPP00",
//							"editVersion": 20,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H572GMLL4",
//									"editVersion": 116,
//									"attrs": {
//										"type": "image",
//										"id": "",
//										"position": "Absolute",
//										"x": "10",
//										"y": "50%",
//										"w": "#picW||100",
//										"h": "#picH||picW||100",
//										"anchorH": "Left",
//										"anchorV": "Center",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"image": "#pic",
//										"autoSize": "false",
//										"fitSize": "Cover",
//										"repeat": "true",
//										"alignX": "Center",
//										"alignY": "Center"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1H572GMLL5",
//									"editVersion": 38,
//									"attrs": {
//										"1H59BOAKE1": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H59CCI1N9",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H59CCI1N10",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H59BOAKE1",
//											"faceTagName": "over"
//										},
//										"1H59BOAKE3": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H59CJKI04",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H59CJKI05",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H59BOAKE3",
//											"faceTagName": "down"
//										},
//										"1H59CBSSK0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H59CJKI06",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H59CJKI07",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H59CBSSK0",
//											"faceTagName": "gray"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1H572GMLL6",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1H572GMLL7",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1H8H7U93F0",
//							"editVersion": 20,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H8H7U93F1",
//									"editVersion": 156,
//									"attrs": {
//										"type": "box",
//										"id": "",
//										"position": "Absolute",
//										"x": "10",
//										"y": "50%",
//										"w": "#picW||100",
//										"h": "#picH||picW||100",
//										"anchorH": "Left",
//										"anchorV": "Center",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"fontBody\"]",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"attach": "#!!icon",
//										"maskImage": "#icon"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1H8H7U93F2",
//									"editVersion": 22,
//									"attrs": {
//										"1H59BOAKE1": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H8H7U93F5",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H8H7U93F6",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H59BOAKE1",
//											"faceTagName": "over"
//										},
//										"1H59BOAKE3": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H8H7U93F7",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H8H7U93F8",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H59BOAKE3",
//											"faceTagName": "down"
//										},
//										"1H59CBSSK0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HHSGG7MH0",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HHSGG7MH1",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H59CBSSK0",
//											"faceTagName": "gray"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1H8H7U93F9",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1H8H7U93F10",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1H5721BRE0",
//							"editVersion": 20,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H57290200",
//									"editVersion": 172,
//									"attrs": {
//										"type": "text",
//										"id": "",
//										"position": "relative",
//										"x": "#(pic&&picW>0)?picW+10:0",
//										"y": "0",
//										"w": "#(pic&&picW>0)?`FW-${picW+30}`:\"FW\"",
//										"h": "\"\"",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "true",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,5,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#cfgColor.fontBody",
//										"text": "#title",
//										"font": "",
//										"fontSize": "#txtSize.midPlus",
//										"bold": "false",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Top",
//										"wrap": "false",
//										"ellipsis": "true",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0",
//										"autoSizeW": "false",
//										"autoSizeH": "false"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1H57290201",
//									"editVersion": 38,
//									"attrs": {
//										"1H59BOAKE1": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H59CCI1N13",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H59CCI1N14",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H59BOAKE1",
//											"faceTagName": "over"
//										},
//										"1H59BOAKE3": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H59CJKI010",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H59CJKI011",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H59BOAKE3",
//											"faceTagName": "down"
//										},
//										"1H59CBSSK0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H59CJKI012",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H59CJKI013",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H59CBSSK0",
//											"faceTagName": "gray"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1H57290202",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1H57290203",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1H572917N0",
//							"editVersion": 20,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H572917N1",
//									"editVersion": 184,
//									"attrs": {
//										"type": "text",
//										"id": "",
//										"position": "relative",
//										"x": "#(pic&&picW>0)?picW+10:0",
//										"y": "0",
//										"w": "#(pic&&picW>0)?`FW-${picW+30}`:\"FW-20\"",
//										"h": "\"\"",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "true",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#cfgColor.fontBodySub",
//										"text": "#intro",
//										"font": "",
//										"fontSize": "#txtSize.smallPlus",
//										"bold": "false",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Top",
//										"wrap": "true",
//										"ellipsis": "false",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0",
//										"autoSizeW": "false",
//										"autoSizeH": "false"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1H572917O0",
//									"editVersion": 38,
//									"attrs": {
//										"1H59BOAKE1": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H59CCI1N17",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H59CCI1N18",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H59BOAKE1",
//											"faceTagName": "over"
//										},
//										"1H59BOAKE3": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H59CJKI016",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H59CJKI017",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H59BOAKE3",
//											"faceTagName": "down"
//										},
//										"1H59CBSSK0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H59CJKI018",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1H59CJKI019",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H59CBSSK0",
//											"faceTagName": "gray"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1H572917O1",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1H572917O2",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear/@StdUI/ui/BtnIcon.js",
//							"jaxId": "1HGUJIOI20",
//							"editVersion": 30,
//							"attrs": {
//								"createArgs": {
//									"type": "object",
//									"def": "gearCrateArgs",
//									"jaxId": "1HGUJN95I0",
//									"editVersion": 28,
//									"attrs": {
//										"style": "#cfgColor.fontBodySub",
//										"w": "28",
//										"h": "0",
//										"icon": "#appCfg.sharedAssets+\"/trash.svg\"",
//										"colorBG": "null"
//									}
//								},
//								"properties": {
//									"type": "object",
//									"jaxId": "1HGUJN95I1",
//									"editVersion": 55,
//									"attrs": {
//										"type": "#null#>BtnIcon(cfgColor.fontBodySub,28,0,appCfg.sharedAssets+\"/trash.svg\",null)",
//										"id": "",
//										"position": "Absolute",
//										"x": "100%       - 33",
//										"y": "5",
//										"display": "On",
//										"face": ""
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1HGUJN95I2",
//									"editVersion": 8,
//									"attrs": {
//										"1HHSGAA4O0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HHSGAKGN11",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HHSGAKGN12",
//													"editVersion": 4,
//													"attrs": {
//														"display": "Off"
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HHSGAA4O0",
//											"faceTagName": "new"
//										},
//										"1H59CBSSK0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HHSGG7MH2",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HHSGG7MH3",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H59CBSSK0",
//											"faceTagName": "gray"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1HGUJN95I3",
//									"editVersion": 2,
//									"attrs": {
//										"OnClick": {
//											"type": "fixedFunc",
//											"jaxId": "1HH1F4LC40",
//											"editVersion": 4,
//											"attrs": {
//												"callArgs": {
//													"type": "object",
//													"jaxId": "1HH1F51R40",
//													"editVersion": 2,
//													"attrs": {
//														"event": ""
//													}
//												},
//												"seg": ""
//											}
//										}
//									}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1HGUJN95I4",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false",
//								"containerSlots": {
//									"type": "object",
//									"jaxId": "1HGUJN95I5",
//									"editVersion": 0,
//									"attrs": {}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1HHSG6EE60",
//							"editVersion": 22,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1HHSGAKGN13",
//									"editVersion": 156,
//									"attrs": {
//										"type": "box",
//										"id": "BoxNew",
//										"position": "Absolute",
//										"x": "100%-55",
//										"y": "5",
//										"w": "50",
//										"h": "25",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "Off",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"primary\"]",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "[10,0,10,0]",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1HHSG8C1O0",
//											"editVersion": 20,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HHSGAKGN14",
//													"editVersion": 124,
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "Absolute",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontPrimary\"]",
//														"text": "New!",
//														"font": "",
//														"fontSize": "#txtSize.smallPlus",
//														"bold": "true",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Center",
//														"alignV": "Center",
//														"wrap": "false",
//														"ellipsis": "false",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1HHSGAKGN15",
//													"editVersion": 14,
//													"attrs": {
//														"1H59CBSSK0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HHSGG7MH4",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HHSGG7MH5",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H59CBSSK0",
//															"faceTagName": "gray"
//														}
//													}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1HHSGAKGN18",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1HHSGAKGN19",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1HHSGAKGN20",
//									"editVersion": 8,
//									"attrs": {
//										"1HHSGAA4O0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HHSGAKGN21",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HHSGAKGN22",
//													"editVersion": 4,
//													"attrs": {
//														"display": "On"
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HHSGAA4O0",
//											"faceTagName": "new"
//										},
//										"1H59CBSSK0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HHSGG7MH6",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HHSGG7MH7",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H59CBSSK0",
//											"faceTagName": "gray"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1HHSGAKGN23",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1HHSGAKGN24",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"type": "object",
//					"jaxId": "1H54B0SFC6",
//					"editVersion": 28,
//					"attrs": {
//						"1H59BOAKE1": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H59CCI1N21",
//							"editVersion": 4,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H59CCI1N22",
//									"editVersion": 4,
//									"attrs": {
//										"alpha": {
//											"type": "number",
//											"valText": "1",
//											"editMode": "range",
//											"editType": "range"
//										}
//									}
//								},
//								"anis": {
//									"type": "array",
//									"def": "Array",
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H59BOAKE1",
//							"faceTagName": "over"
//						},
//						"1H59CBSSK0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H59CCI1N23",
//							"editVersion": 4,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H59CCI1N24",
//									"editVersion": 14,
//									"attrs": {
//										"alpha": {
//											"type": "number",
//											"valText": "0.5",
//											"editMode": "range",
//											"editType": "range"
//										}
//									}
//								},
//								"anis": {
//									"type": "array",
//									"def": "Array",
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H59CBSSK0",
//							"faceTagName": "gray"
//						},
//						"1H599SSCN0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H59CJKI020",
//							"editVersion": 4,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H59CJKI021",
//									"editVersion": 4,
//									"attrs": {
//										"alpha": {
//											"type": "number",
//											"valText": "1",
//											"editMode": "range",
//											"editType": "range"
//										}
//									}
//								},
//								"anis": {
//									"type": "array",
//									"def": "Array",
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H599SSCN0",
//							"faceTagName": "up"
//						},
//						"1H59BOAKE3": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H59CJKI022",
//							"editVersion": 4,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1H59CJKI023",
//									"editVersion": 4,
//									"attrs": {
//										"alpha": {
//											"type": "number",
//											"valText": "1",
//											"editMode": "range",
//											"editType": "range"
//										}
//									}
//								},
//								"anis": {
//									"type": "array",
//									"def": "Array",
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H59BOAKE3",
//							"faceTagName": "down"
//						}
//					}
//				},
//				"functions": {
//					"type": "object",
//					"jaxId": "1H54B0SFC7",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"extraPpts": {
//					"type": "object",
//					"def": "Object",
//					"jaxId": "1H54B0SFC8",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1H54B0SFC9",
//			"editVersion": 112,
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "true",
//				"h": "false",
//				"anchorH": "true",
//				"anchorV": "true",
//				"autoLayout": "true",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "true",
//				"alpha": "true",
//				"rotate": "true",
//				"scale": "true",
//				"filter": "true",
//				"aspect": "false",
//				"cursor": "true",
//				"zIndex": "true",
//				"flex": "true",
//				"margin": "true",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "true",
//				"minH": "true",
//				"maxW": "true",
//				"maxH": "true",
//				"styleClass": "false",
//				"enable": "true",
//				"drag": "true"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}