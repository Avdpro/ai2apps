export default {
	versionIdx:"$$BuildVersionIdx$$",
	disks:"$$ZipDirs$$",
	files:{
	},
	runOnPreSetup:async function(){
		//TODO: codes runs only before setup
	},
	runOnPostSetup:async function(){
		//TODO: codes runs only after setup
	},
	run:async function(){
		//TODO: codes runs before entner the entry.
	},
	entry:"$$Entry$$",
};
