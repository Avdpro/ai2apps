## Commnad: *cat*

### Usage:
       cat [files]

The cat utility reads files sequentially, writing them to the standard output.

### Examples:
      cd disk.json
Display content of file disk.json in cur path.

      cd disk.json app.js
Display content of file disk.json and app.js in cur path.

