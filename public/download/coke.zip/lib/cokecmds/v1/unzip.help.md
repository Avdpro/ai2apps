### Commnad: *unzip* -- extract zip file

#### Usage:
       uzip zipfile [dst-dir]

Extract **zipfile** contents into dst-dir. Default dst-dir is current path.

#### Examples:
      unzip logs.zip
Extract logs.zip into current path.

      unzip logs.zip /logs
Extract logs.zip into /logs dir.
