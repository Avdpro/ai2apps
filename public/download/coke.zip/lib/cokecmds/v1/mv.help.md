### Commnad: *mv* -- move files.

#### Usage:
       mkdir [-f] srouce target
       mkdir [-f] srouce ... target

In its first form, the mv utility renames the file named by the source 
operand to the destination path named by the target operand.  This form 
is assumed when the last operand does not name an already existing directory.


In its second form, mv moves each file named by a source operand to a
destination file in the existing directory named by the directory oper-
and.  The destination path for each operand is the pathname produced by
the concatenation of the last operand, a slash, and the final pathname
component of the named file.
- -f: Froce to overwrite files.

#### Examples:
      mv nice.js good.js
Rename nice.js to good.js

      mv nice.js /MyApp/
Move **nice.js** into **/MyApp**, as **/MyApp/nice.js**

      mv nice.js images/* ok.js /MyApp
Move **nice.js**, and all files in **image** dir, and **ok.js** into **/MyApp**.
