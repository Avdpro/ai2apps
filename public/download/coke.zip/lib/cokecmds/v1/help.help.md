## Commnad: *help*

### Usage:
       help comand-name

Show cokecodes terminal command's help. The help will be showed in a new browser tab(window).

### Examples:
      help cp
Terminal command "cp"'s help markdown will be showed.

      help pkg
Terminal command "pkg"'s help markdown will be showed.