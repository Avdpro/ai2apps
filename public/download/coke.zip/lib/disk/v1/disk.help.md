
## Commnad: *disk*

### Usage:
```
  disk info [Disk-Name]                 Display local disk info.
  disk new [New-Disk-Name]              Create a new disk.
  disk drop [Disk-Name]                 Remove(delete) a disk.
  disk checkin                          Check in current disk onto cloud.
  disk get                              Download a cloud disk.
  disk checkout                         Download a cloud disk and mark it sync with cloud.
  disk commit                           Commit your local disk changes to cloud.
  disk update                           Sync cloud disk content with your local disk.
  disk changes                          Show the local changes after last sync(checkin/ commit).
  disk cloud                            List your cloud disks.
```

**info**  
Display local disk info.

**new**   
Create a new disk. Disk name should be only contains char a~z, A~Z, 0~9, -, _; and starts only with a~z, A~Z.
examples:  
`disk new MyNewDisk`
Create a new disk named "MyNewDisk".  
`disk new /@MyNewDisk`
Error, illegal disk name: "/@MyNewDisk".

**drop**  
Delete a disk, remove all contents with in it.

**checkin**  
Check in current disk onto cloud. You will be asked about disk name on cloud. You need to login in your account before checkin.

**get**  
Download a cloud disk. You will be asked about the disk-cloud-id to download. Let's say your account is "tom@mail.com" you checked-in a disk named "MyDisk", so it cloud-disk-id should be `MyDisk@tom@mail.com`.

**commit**  
Commit your local disk changes to cloud. If the cloud-disk has a new version, you will be notify to update it before commit. You need to login in your account before commit.

**update**
Unimport a package for current project-disk. If a package is not needed by any project, it will be removed.

**changes**  
Show the local changes after last sync(checkin/ commit).

**cloud**  
List your cloud disks. You need to login in your account.
