import {makeObjEventEmitter,makeNotify} from "./utils/events.js";
import pathLib from "./utils/path.js";
function getDomain(url) {
	try{
		if((!url.startsWith("http://"))||(!url.startsWith("https://"))){
			url="https://"+url;
		}
		const parsedUrl = new URL(url);
		const hostname = parsedUrl.hostname;
		if (hostname) {
			const domainParts = hostname.split('.');
			if (domainParts.length >= 2) {
				return domainParts.slice(-2).join('.');
			} else {
				return hostname;
			}
		}
		return url;
	}catch(err){
		return url;
	}
}
const safeToolsJSON={
	"tools": [
		{
			"filePath": "/@tabedit/app.html",
			"type": "Page",
			"name": "TabOS IDE",
			"description": {
				"EN": "A powerful visual IDE for developing various AI agents and apps.",
				"CN": "用于开发各种AI智能体以及App的强大的可视化IDE。"
			},
			"keyTool":true,
			"icon": "prj.svg",
			"package": "tabedit",
			"enable": true,
			"handleFiles":{
				"edit":[".project.json"],
				"open":[".project.json"]
			}
		},
		{
			"filePath": "/@tabedit/edlit.html",
			"type": "App",
			"name": "Edit Pad",
			"metaName":"EditPad@tabedit",
			"appFrameW": 800,
			"appFrameH": 800,
			"description": {
				"EN": "Simple yet powerful text editor.",
				"CN": "简单而强大的文本编辑器。"
			},
			"keyTool":true,
			"icon": "hudedit.svg",
			"package": "tabedit",
			"enable": true,
			"handleFiles":{
				"edit":[".js",".mjs",".json",".css",".jsx",".ts",".html",".htm",".svg",".md",".c",".cpp",".h",".hpp",".py",".ini",".inf",".link",".sh",".conflict",".baseversion"],
				"open":[".js",".mjs",".json",".css",".jsx",".ts",".svg",".c",".cpp",".h",".hpp",".py",".ini",".inf",".link",".conflict",".baseversion"]
			}
		},
		{
			"filePath": "/@homekit/ui/DlgProjects.js",
			"type": "App",
			"appFrameW": 600,
			"appFrameH": 750,
			"name": {
				"EN": "New Dev. Project",
				"CN": "新建开发工程"
			},
			"keyTool":true,
			"description": {
				"EN": "Create new dev. project.",
				"CN": "创建新的开发工程项目。"
			},
			"icon": "labadd.svg",
			"package": "homekit"
		},
		{
			"filePath": "/~/-files/app.html",
			"type": "App",
			"appFrameW": 800,
			"appFrameH": 600,
			"name": {
				"EN": "File Manager",
				"CN": "文件管理器"
			},
			"metaName":"Files@files",
			"keyTool":true,
			"description": {
				"EN": "File manager App for Tab-OS.",
				"CN": "Tab-OS的文件管理器App。"
			},
			"icon": "disk.svg",
			"package": "files"
		},
		{
			"filePath": "/~/-terminal/app.html",
			"type": "App",
			"appFrameW": 800,
			"appFrameH": 500,
			"name": {
				"EN": "Terminal",
				"CN": "命令行终端"
			},
			"metaName":"Terminal@terminal",
			"keyTool":true,
			"description": {
				"EN": "Command line terminal App for Tab-OS.",
				"CN": "Tab-OS的命令行终端App。"
			},
			"icon": "terminal.svg",
			"package": "files"
		}
	],
	"groups": [
		{
			"codeName": "Favorites",
			"name": {
				"CN": "日常任务",
				"EN": " Favorites"
			},
			"description": "Favorite Apps, Tools or Agents",
			"icon": "star_s.svg",
			"tools": []
		},
		{
			"codeName": "Development",
			"name": {
				"CN": "开发",
				"EN": "Development"
			},
			"description": "Develop",
			"icon": "lab.svg",
			"tools": [
				"/@tabedit/app.html",
				"/@homekit/ui/DlgProjects.js"
			]
		},
		{
			"codeName": "Tools",
			"name": {
				"CN": "工具",
				"EN": "Tools"
			},
			"description": "Tools",
			"icon": "cal.svg",
			"tools": [
				"/@tabedit/editlit.html",
				"/~/-files/app.html",
				"/~/-terminal/app.html"
			]
		}
	],
	"sites": []
};

//****************************************************************************
//:AATool
//****************************************************************************
let AATool,aaTool;
{
	AATool=function(tools){
		this.aaTools=tools;
		this.filePath="";
		this.type="";
		this.codeName="";
		this.name="";
		this.description="";
		this.icon="";
		this.package="";
		this.modual=null;
		this.isRPA=false;
		this.rpaHost="";
		this.agentNode=null;
		this.appMeta=null;
		this.appFrameW=0;
		this.appFrameH=0;
		this.enable=true;
		this.handleFiles=null;
		this.keyTool=false;
		this.metaName="";
		this.multiInstance=true;
		makeNotify(this);
	};
	aaTool=AATool.prototype={};
	AATool.TYPE_NONE="";
	AATool.TYPE_APP="App";
	AATool.TYPE_PAGE="Page";
	AATool.TYPE_AGENT="Agent";
	AATool.TYPE_GUIDE="Guide";
	AATool.TYPE_API="API";

	//------------------------------------------------------------------------
	aaTool.loadFromPath=async function(path){
		let apiList,apiVO,modual;
		this.filePath=path;
		//Read package info:
		{
			let pos=path.indexOf("/@");
			if(pos>=0){
				let pos2=path.indexOf("/",pos+2);
				if(pos2>0){
					this.package=path.substring(2,pos);
				}else{
					this.package=path.substring(2);
				}
			}
		}
		modual=this.modual=await import(path);
		apiList=modual.ChatAPI;
		if(Array.isArray(apiList)){
			apiVO=apiList[0];
		}
		if(apiVO){
			this.name=apiVO.def.name;
			this.description=apiVO.def.description;
			this.icon=apiVO.icon;
			if(apiVO.agent){
				this.type=AATool.TYPE_AGENT;
			}else{
				this.type=AATool.TYPE_API;
			}
			this.isRPA=apiVO.isRPA;
			if(this.isRPA){
				this.rpaHost=apiVO.rpaHost;
			}
			return true;
		}
		apiVO=modual.tool;
		if(apiVO && apiVO.guide){
			this.type=AATool.TYPE_GUIDE;
			this.name=apiVO.name;
			this.description=apiVO.description;
			this.icon=apiVO.icon;
			this.isRPA=true;
			this.rpaHost=apiVO.rapHost;
			return true;
		}
		throw Error(`${path} is not a tool file.`);
	};
	
	//------------------------------------------------------------------------
	aaTool.loadFromVO=async function(vo){
		this.filePath=vo.filePath;
		this.type=vo.type;
		this.name=vo.name;
		this.description=vo.description||"";
		this.icon=vo.icon||"gas.svg";
		this.package=vo.package;
		this.isRPA=vo.isRPA;
		this.rpaHost=vo.rpaHost;
		this.agentNode=vo.agentNode;
		this.modual=null;
		this.appMeta=null;
		this.appFrameW=vo.appFrameW||0;
		this.appFrameH=vo.appFrameH||0;
		this.enable=vo.enable===false?false:true;
		this.keyTool=vo.keyTool||false;
		this.metaName=vo.metaName||this.filePath;
		this.multiInstance=vo.multiInstance!==false;
		if(vo.handleFiles){
			this.handleFiles=vo.handleFiles;
		}
	};

	//------------------------------------------------------------------------
	aaTool.genSaveVO=async function(){
		let vo = {};
		vo.filePath = this.filePath;
		vo.type = this.type;
		vo.name = this.name;
		vo.description = this.description;
		vo.icon = this.icon;
		vo.package = this.package;
		vo.isRPA = this.isRPA;
		vo.rpaHost = this.rpaHost;
		vo.agentNode=this.agentNode;
		vo.enable = !!this.enable;
		vo.keyTool = !!this.keyTool;
		vo.metaName = this.metaName;
		vo.multiInstance=this.multiInstance;
		if(this.appFrameW>0){
			vo.appFrameW=this.appFrameW;
		}
		if(this.appFrameH>0){
			vo.appFrameH=this.appFrameH;
		}
		if(this.handleFiles){
			vo.handleFiles=this.handleFiles;
		}
		return vo;
	};
	
	//------------------------------------------------------------------------
	aaTool.genInfoVO=function(lan){
		let vo={};
		let ref;
		vo.filePath = this.filePath;
		vo.type = this.type;
		vo.name = this.getNameText();
		vo.description = this.getDescText();
		vo.icon = this.icon;
		vo.package = this.package;
		vo.isRPA = this.isRPA;
		vo.rpaHost = this.rpaHost||"NA";
		vo.agentNode= this.agentNode;
		vo.enable = !!this.enable;
		vo.keyTool = !!this.keyTool;
		ref=this.getReference();
		ref.groups=ref.groups.map((g)=>g.getNameText(lan));
		ref.chains=ref.chains.map((c)=>c.getNameText(lan));
		vo.reference=`Chains: ${ref.chains.length?ref.chains:0}. Groups: ${ref.groups.length?ref.groups:0}.`;
		return vo;
	};
	
	//------------------------------------------------------------------------
	aaTool.getName=aaTool.getNameText=function(lan){
		let text=this.name;
		if(text.EN){
			text=text[lan]||text.EN;
		}
		return text;
	};

	//------------------------------------------------------------------------
	aaTool.getDescText=function(lan){
		let text=this.description;
		if(text.EN){
			text=text[lan]||text.EN;
		}
		return text;
	};
	
	//------------------------------------------------------------------------
	aaTool.getReference=function(){
		return this.aaTools.getToolRef(this);
	};
	
	//------------------------------------------------------------------------
	aaTool.genAppMeta=function(lan,orgMeta){
		let tool=this;
		switch(tool.type){
			case "App":{
				let meta,icon;
				meta=tool.appMeta;
				if(!meta){
					let ext;
					ext=pathLib.extname(tool.filePath).toLowerCase();
					icon=tool.icon;
					if(icon[0]!=="/"){
						icon="/~/-tabos/shared/assets/"+icon;
					}
					meta={
						type:"app",
						name:tool.name,
						caption:tool.getName(lan),
						icon:icon,
						package:tool.package,
						appFrame:{
							group:tool.filePath,
							caption:tool.name,openApp:true,
							multiInstance:(tool.multiInstance!==false),
							icon:icon,
							width:tool.appFrameW||360,
							height:tool.appFrameH||600,
						}
					};
					if(ext===".js"){
						meta.appFrame.uiDef=tool.filePath;
					}else{
						meta.appFrame.main=tool.filePath;
					}
					tool.appMeta=meta;
				}
				if(orgMeta){
					Object.assign(orgMeta,meta);
					tool.appMeta=orgMeta;
					return orgMeta;
				}
				return meta;
			}
			case "Page":{
				let meta,icon;
				meta=tool.appMeta;
				if(!meta){
					icon=tool.icon;
					if(icon[0]!=="/"){
						icon="/~/-tabos/shared/assets/"+icon;
					}
					meta={
						type:"app",
						main:tool.filePath,
						name:tool.name,
						package:tool.package,
						caption:tool.getNameText(lan),
						icon:icon,
						iconApp:null,
					};
					tool.appMeta=meta;
				}
				if(orgMeta){
					Object.assign(orgMeta,meta);
					tool.appMeta=orgMeta;
					return orgMeta;
				}
				return meta;
			}
			case "Agent":{
				return null;
			}
			case "API":{
				return null;
			}
		}
	};
}

//****************************************************************************
//::AAToolChain
//****************************************************************************
let AAToolChain,aaToolChain;
{
	//------------------------------------------------------------------------
	AAToolChain=function(tools){
		this.aaTools=tools;
		this.name="";
		this.filePath="";
		this.tools={};
		this.guide="";
		this.icon="toolchain.svg";
		this.description="";
		this.enable=true;
		makeNotify(this);
	};
	aaToolChain=AAToolChain.prototype={};
	
	//------------------------------------------------------------------------
	aaToolChain.genSaveVO=async function(){
		let vo,tool,tools;
		vo={
			name:this.name,
			guide:this.guide,
			icon:this.icon,
			description:this.description,
			tools:{}
		};
		tools=this.tools;
		for(tool of tools){
			vo.tools[tool.fileName]=tool.fileName;
		}
		return vo;
	};
	
	//------------------------------------------------------------------------
	aaToolChain.loadFromVO=async function(vo){
		let tool,path,name;
		// Load tool chains from the provided value object (VO):
		this.name = vo.name || '';
		this.guide = vo.guide || '';
		this.icon=vo.icon||'';
		this.description=vo.description||'';
		let chainTools = vo.tools || {};
		for(name in chainTools){
			path=chainTools[name];
			tool=this.aaTools.getTool(path);
			if(tool){
				this.tools[name]=tool;
			}else{
				//TODO: Report missing tools:
			}
		}
	};
	
	//------------------------------------------------------------------------
	AAToolChain.loadChainVO=async function(path){
		let chainJSON,ext;
		if(path[0]==="/" && path[1]!=="~" && path[1]!=="/"){
			path="/~"+path;
		}
		ext=pathLib.extname(path).toLowerCase();
		if(ext===".js"){
			chainJSON=(await import(path)).default;
		}else{
			chainJSON=await (await fetch(path)).json();
		}
		return chainJSON;
	};

	//------------------------------------------------------------------------
	aaToolChain.loadFromPath=async function(path){
		let chainJSON;
		chainJSON=await AAToolChain.loadChainVO(path);
		this.loadFromVO(chainJSON);
	};

	//------------------------------------------------------------------------
	aaToolChain.getNameText=function(lan){
		let text=this.name;
		if(text.EN){
			text=text[lan]||text.EN;
		}
		return text;
	};

	//------------------------------------------------------------------------
	aaToolChain.getDescText=function(lan){
		let text=this.description;
		if(text.EN){
			text=text[lan]||text.EN;
		}
		return text;
	};
	
	//------------------------------------------------------------------------
	aaToolChain.genInfoVO=function(ln){
		let vo={};
		let ref,tools,groups;
		vo.filePath = this.filePath;
		vo.type = this.type;
		vo.name = this.getNameText();
		vo.description = this.getDescText();
		vo.icon = this.icon;
		vo.package = this.package;
		vo.isRPA = this.isRPA;
		vo.rpaHost = this.rpaHost||"NA";
		vo.enable = !!this.enable;
		ref=this.getReference();
		tools=ref.tools.map(s=>s.getNameText(ln));
		groups=ref.groups.map(g=>g.getNameText(ln));
		vo.reference=`Tool: ${tools.length?tools:"0"}. Group: ${groups.length?groups:"0"}`;
		return vo;
	};

	//------------------------------------------------------------------------
	aaToolChain.getReference=function(){
		let ref;
		ref=this.aaTools.getChainRef(this);
		ref.tools=Object.values(this.tools);
		return ref;
	};
}

//****************************************************************************
//:AAToolGroup
//****************************************************************************
let AAToolGroup,aaToolGroup;
{
	AAToolGroup=function(tools){
		this.aaTools=tools;
		this.codeName="";
		this.name="";
		this.icon="";
		this.description="";
		this.chains=[];
		this.tools=[];
		makeNotify(this);
	};
	aaToolGroup=AAToolGroup.prototype={};
	
	//------------------------------------------------------------------------
	aaToolGroup.genSaveVO=async function(){
		let vo={};
		vo.codeName=this.codeName||this.name;
		vo.name=this.name;
		vo.description=this.description;
		vo.tools=this.tools.map(tool => tool.filePath);
		vo.chains=this.chains.map(chain=>chain.filePath);
		vo.icon=this.icon;
		return vo;
	};

	//------------------------------------------------------------------------
	aaToolGroup.loadFromVO=async function(groupVO){
		let aaTools,toolStubs,toolStub,tools,tool,chains,chain;
		aaTools=this.aaTools;
		// Load group properties from the given value object (VO):
		this.codeName=groupVO.codeName||groupVO.name||"";
		this.name = groupVO.name || '';
		this.description = groupVO.description || '';
		this.icon = groupVO.icon || '';
		// Load the tools by creating AATool instances for each filePath in the VO:
		toolStubs=groupVO.tools;
		this.tools=tools=[];
		for(toolStub of toolStubs){
			tool=aaTools.getTool(toolStub);
			if(tool){
				tools.push(tool);
			}
		}
		// Load the tool chains from the value object:
		chains=groupVO.chains||[];
		this.chains=[];
		for(let chainPath of chains){
			chain=this.aaTools.getChain(chainPath);
			if(chain){
				this.chains.push(chain);
			}
		}
	};

	//------------------------------------------------------------------------
	aaToolGroup.addTool=function(tool){
		let idx;
		idx=this.tools.indexOf(tool);
		if(idx>=0)
			return;
		this.tools.push(tool);
	};
	
	//------------------------------------------------------------------------
	aaToolGroup.removeTool=function(tool){
		let idx;
		idx=this.tools.indexOf(tool);
		this.tools.splice(idx,1);
	};

	//------------------------------------------------------------------------
	aaToolGroup.addChain=function(chain){
		let idx;
		idx=this.chains.indexOf(chain);
		if(idx>=0)
			return;
		this.chains.push(chain);
	};

	//------------------------------------------------------------------------
	aaToolGroup.removeChain=function(chain){
		let idx;
		idx=this.chains.indexOf(chain);
		this.chains.splice(idx,1);
	};
	
	//------------------------------------------------------------------------
	aaToolGroup.getName=aaToolGroup.getNameText=function(lan){
		let text=this.name;
		if(text.EN){
			text=text[lan]||text.EN;
		}
		return text;
	};

	//------------------------------------------------------------------------
	aaToolGroup.getDescText=function(lan){
		let text=this.description;
		if(text.EN){
			text=text[lan]||text.EN;
		}
		return text;
	};
}

//****************************************************************************
//:AAToolSite
//****************************************************************************
let AAToolSite,aaToolSite;
{
	AAToolSite=function(tools,hostSite){
		this.aaTools=tools;
		this.name=getDomain(hostSite);
		this.icon="browser.svg";
		this.hostSite=hostSite;
		this.description=`Tools related to host: ${hostSite}`;
		this.tools=[];
		this.checkLogin="";
	};
	aaToolSite=AAToolSite.prototype={};
	
	//------------------------------------------------------------------------
	aaToolSite.genSaveVO=async function(){
		let vo={};
		vo.name=this.name;
		vo.description=this.description;
		vo.hostSite=this.hostSite;
		vo.icon=this.icon;
		vo.checkLogin=this.checkLogin;
		return vo;
	};

	//------------------------------------------------------------------------
	aaToolSite.loadFromVO=async function(groupVO){
		this.name = groupVO.name || '';
		this.description = groupVO.description || '';
		this.icon = groupVO.icon || '';
		this.hostSite = groupVO.hostSite || '';
		this.checkLogin=groupVO.checkLogin||"";
	};

	//------------------------------------------------------------------------
	aaToolSite.addTool=function(tool){
		this.tools.push(tool);
	};
	
	//------------------------------------------------------------------------
	aaToolSite.removeTool=function(tool){
		let idx;
		idx=this.tools.indexOf(tool);
		this.tools.splice(idx,1);
	};
}

//****************************************************************************
//:AATools
//****************************************************************************
let AATools,aaTools;
{
	AATools=function(){
		this.groups=new Map();
		this.sites=new Map();
		this.tools=new Map();
		this.chains=new Map();
		this.fileHandlers=null;
	};
	aaTools=AATools.prototype = {};
	
	//************************************************************************
	//I/O
	//************************************************************************
	{
		//--------------------------------------------------------------------
		aaTools.genSaveVO=async function(){
			let saveVO = {};
			let list,tool,tools,chains;
			// Generate a Save Value Object (VO) for all tools:
			tools=[];
			list=this.getTools();
			for(tool of list){
				if(tool.type==="Agent"){
					tools.push({
						type:"Agent",enable:tool.enable,
						filePath:tool.filePath
					});
				}else{
					tools.push(await tool.genSaveVO());
				}
			}
			saveVO.tools=tools;
			
			// Generate a Save Value Object (VO) for all chains:
			chains=Array.from(this.chains.keys());
			saveVO.chains=chains;
			
			// Generate a Save Value Object (VO) for all groups:
			saveVO.groups = [];
			for (let [groupKey, group] of this.groups) {
				let groupSaveVO = await group.genSaveVO();
				saveVO.groups.push(groupSaveVO);
			}
			return saveVO;
		};
		
		//--------------------------------------------------------------------
		aaTools.load=async function(){
			try{
				let toolJSON;
				toolJSON=await (await fetch("/~/coke/ToolIndex.json",{cache: 'no-store'})).json();
				{
					//Merge with safe:
					let safeTools,jsonTools,tool,filePath,pos;
					let safeGroups,jsonGroups,group,groupCode,jsonGroup;
					safeTools=safeToolsJSON.tools;
					jsonTools=toolJSON.tools;
					pos=0;
					for(tool of safeTools){
						filePath=tool.filePath;
						if(!jsonTools.some((t)=>{return t.filePath===filePath;})){
							jsonTools.splice(pos++,0,tool);
						}
					}
					safeGroups=safeToolsJSON.groups;
					jsonGroups=toolJSON.groups;
					for(group of safeGroups){
						groupCode=group.codeName;
						jsonGroup=jsonGroups.find((g)=>{return g.codeName===groupCode;});
						if(!jsonGroup){
							jsonGroups.unshift(group);
						}else{
							pos=0;
							safeTools=group.tools;
							jsonTools=jsonGroup.tools;
							for(tool of safeTools){
								if(jsonTools.indexOf(tool)<0){
									jsonTools.splice(pos++,0,tool);
								}
							}
						}
					}
				}
				await this.loadFromVO(toolJSON);
			}catch(err){
				await this.loadFromVO(safeToolsJSON);
			}
			return true;
		};

		//--------------------------------------------------------------------
		aaTools.loadFromVO=async function(vo){
			let groupStubs,toolStubs,chainStubs;
			//Load all tools:
			toolStubs = vo.tools || [];
			await Promise.all(toolStubs.map(async (toolStub) => {
				await this.loadTool(toolStub);
			}));
			chainStubs = vo.chains || [];
			await Promise.all(chainStubs.map(async (chainStub) => {
				await this.loadChain(chainStub);
			}));
			// Load all groups, hosts, and tools from the provided value object (VO):
			groupStubs = vo.groups || [];
			for(let groupVO of groupStubs){
				let group = new AAToolGroup(this);
				await group.loadFromVO(groupVO);
				this.groups.set(group.name, group);
			}
			this.loadTime=Date.now();
		};

		//--------------------------------------------------------------------
		aaTools.loadTool=async function(toolStub){
			let toolPath,tool,host;
			if(typeof(toolStub)==="object"){
				toolPath=toolStub.filePath;
				tool=this.tools.get(toolPath);
				if(tool){
					return tool;
				}
				tool=new AATool(this);
				if(toolStub.type==="Agent"){
					toolPath=toolStub.filePath;
					try {
						await tool.loadFromPath(toolPath);
						this.tools.set(toolPath, tool);
						host=tool.rpaHost;
						if(host){
							let hostSite;
							hostSite=this.sites.get(host);
							if(!hostSite){
								hostSite=new AAToolSite(this,host);
								this.sites.set(host,hostSite);
							}
							hostSite.addTool(tool);
						}
						tool.enable=toolStub.enable;
						return tool;
					} catch (error) {
						console.error(`Failed to load tool from path: ${toolPath}`, error);
						return null;
						//throw error;
					}
					
				}else{
					try {
						await tool.loadFromVO(toolStub);
						this.tools.set(toolPath, tool);
						host=tool.rpaHost;
						if(host){
							let hostSite;
							hostSite=this.sites.get(host);
							if(!hostSite){
								hostSite=new AAToolSite(this,hostSite);
								this.sites.set(host,hostSite);
							}
							hostSite.addTool(tool);
						}
						return tool;
					} catch (error) {
						console.error(`Failed to load tool from path: ${toolPath}`, error);
						return null;
						//throw error;
					}
				}
			}
			//Stub is tool path:
			toolPath=toolStub;
			tool=this.tools.get(toolPath);
			if(tool){
				return tool;
			}
			tool = new AATool(this);
			try {
				await tool.loadFromPath(toolPath);
				this.tools.set(toolPath, tool);
				host=tool.rpaHost;
				if(host){
					let hostSite;
					hostSite=this.sites.get(host);
					if(!hostSite){
						hostSite=new AAToolSite(this,host);
						this.sites.set(host,hostSite);
					}
					hostSite.addTool(tool);
				}
				return tool;
			} catch (error) {
				console.error(`Failed to load tool from path: ${toolPath}`, error);
				//throw error;
				return null;
			}
		};
		
		//--------------------------------------------------------------------
		aaTools.loadChain=async function(chainPath){
			let chain;
			chain=this.chains.get(chainPath);
			if(chain){
				return chain;
			}
			chain=new AAToolChain(this);
			chain.filePath=chainPath;
			await chain.loadFromPath(chainPath);
			this.chains.set(chainPath,chain);
			return chain;
		};
	}
	
	//************************************************************************
	//Access contents:
	//************************************************************************
	{	
		//--------------------------------------------------------------------
		aaTools.getFileHandler=function(filePath,mode){
			let handlers,map,handleFiles,tool,ext;
			handlers=this.fileHandlers;
			if(!handlers){
				//Build map:
				handlers=this.fileHandlers={
					open:new Map(),
					edit:new Map()
				};
				for (tool of this.tools.values()) {
					handleFiles=tool.handleFiles;
					if(handleFiles){
						let types,fileType,map;
						types=handleFiles.open;
						if(types){
							map=this.fileHandlers.open;
							for(fileType of types){
								map.set(fileType,tool);
							}
						}
						types=handleFiles.edit;
						if(types){
							map=this.fileHandlers.edit;
							for(fileType of types){
								map.set(fileType,tool);
							}
						}
					}
				}
			}
			map=handlers[mode]||handlers.open;
			ext=pathLib.ext2name(filePath);
			if(ext){
				tool=map.get(ext);
				if(tool){
					return tool;
				}
			}
			ext=pathLib.extname(filePath);
			if(ext){
				return map.get(ext)||null;
			}
			return null;
		};
		
		//--------------------------------------------------------------------
		aaTools.getTool=function(filePath){
			return this.tools.get(filePath);
		};
		
		//--------------------------------------------------------------------
		aaTools.getChain=function(filePath){
			return this.chains.get(filePath);
		};
		
		//--------------------------------------------------------------------
		aaTools.getGroup=function(name){
			return this.groups.get(name);
		};
		
		//--------------------------------------------------------------------
		aaTools.addGroup=function(name){
			let group;
			group=this.groups.get(name);
			if(group){
				return group;
			}
			group = new AAToolGroup(this);
			group.name=name;
			this.groups.set(name,group);
			return group;
		};
		
		//--------------------------------------------------------------------
		aaTools.renameGroup=function(group,name){
			let oldName;
			oldName=group.name;
			this.groups.delete(oldName);
			group.name=name;
			this.groups.set(name,group);
			return group;
		};

		//--------------------------------------------------------------------
		aaTools.removeGroup=function(group){
			let oldName;
			oldName=group.name;
			this.groups.delete(oldName);
		};

		//--------------------------------------------------------------------
		aaTools.getTools=function(){
			return Array.from(this.tools.values());
		};

		//--------------------------------------------------------------------
		aaTools.getChains=function(){
			return Array.from(this.chains.values());
		};

		//--------------------------------------------------------------------
		aaTools.getGroups=function(sort){
			let groups;
			groups=Array.from(this.groups.values());
			if(sort){
				groups.sort((a,b)=>{return a>b?1:(a<b?-1:0);});
			}
			return groups;
		};

		//--------------------------------------------------------------------
		aaTools.getSites=function(sort){
			let groups;
			groups=Array.from(this.sites.values());
			if(sort){
				groups.sort((a,b)=>{return a>b?1:(a<b?-1:0);});
			}
			return groups;
		};

		//--------------------------------------------------------------------
		aaTools.getToolAPIIndex=function(){
			//TODO: Code this:
		};

		//--------------------------------------------------------------------
		aaTools.getToolDescIndex=aaTools.getToolScope=function(){
			let tools,vo,tool,i,n;
			tools=Array.from(this.tools.values());
			vo={};
			n=tools.length;
			for(i=0;i<n;i++){
				tool=tools[i];
				if(tool.enable){
					vo["Tool-"+i]=tool.description;
				}
			}
			return vo;
		};
		
		//--------------------------------------------------------------------
		aaTools.removeTool=function(tool,ref){
			let g;
			if(!ref){
				ref=this.getToolRef(tool);
			}
			for(g of ref.groups){
				g.removeTool(tool);
			}
			this.tools.delete(tool.filePath);
		};

		//--------------------------------------------------------------------
		aaTools.removeChain=function(chain,ref){
			let g;
			if(!ref){
				ref=this.getChainRef(chain);
			}
			for(g of ref.groups){
				g.removeChain(chain);
			}
			this.chains.delete(chain.filePath);
		};
		
		//--------------------------------------------------------------------
		aaTools.removeToolPackage=function(pkg){
			let tools,tool;
			tools=Array.from(this.tools.values());
			tools=tools.filter((tool)=>{return tool.package===pkg;});
			for(tool of tools){
				this.removeTool(tool);
			}
		};
	}
	
	//************************************************************************
	//Run tool or chain:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		aaTools.execTool=async function(app,tool,args,session){
			switch(tool.type){
				case "App":{
					let meta,icon;
					meta=tool.genAppMeta(app.lanCode||"EN");
					//app.newFrameApp(meta,{},{});
					app.openMeta(meta,args,null);
					return `App ${tool.name} started.`;
				}
				case "Page":{
					window.open(document.location.origin+tool.filePath,"","noreferrer");
					return `Page ${tool.name} started.`;
				}
				case "Agent":{
					let meta,icon;
					if(session){
						return await session.pipeChat(tool.filePath,args,false);
					}else{
						meta=tool.appMeta;
						if(!meta){
							icon=tool.icon||"aichat.svg";
							if(icon[0]!=="/"){
								icon="/~/-tabos/shared/assets/"+icon;
							}
							meta={
								type:"app",
								name:"Projects",
								caption:tool.name,
								icon:icon,
								appFrame:{
									group:"Projects",caption:tool.name,openApp:true,multiInstance:(tool.multiInstance!==false),
									icon:icon,
									width:tool.appFrameW||800,
									height:tool.appFrameH||600,
								}
							};
							meta.appFrame.main=`/@aichat/app.html?chat=${encodeURIComponent(tool.filePath)}&style=pro`;
							tool.appMeta=meta;
						}					
						app.newFrameApp(meta,null,{});
					}
					return "Agent app started.";
				}
				case "API":{
					//TODO: Code this:
					break;
				}
			}
		};
		
		//--------------------------------------------------------------------
		aaTools.execChain=async function(app,chain,args,session){
			let meta,icon;
			if(session){
				//TODO: Use pipechat:
			}else{
				meta=this.chainAppMeta;
				if(!meta){
					icon="/~/-tabos/shared/assets/aalogo.svg";
					meta={
						type:"app",
						name:"Run command",
						caption:"Run command",
						icon:icon,
						appFrame:{
							group:"RunChain",caption:"Run Tool-Chain",openApp:true,multiInstance:true,
							icon:icon,width:600,height:600,
						}
					};
					this.chainAppMeta=meta;
				}
				meta.appFrame.main=`/@aichat/app.html?chat=${encodeURIComponent("/@aae/ai/RunToolChain.js")}&prompt=${encodeURIComponent(chain.filePath)}&style=pro`;
				app.newFrameApp(meta,null,{});
			}
		};
	}
	
	//************************************************************************
	//Utils:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		aaTools.getToolRef=function(tool){
			let groups,group,chains,chain;
			let ref={
				groups:[],chains:[]
			};
			groups=Array.from(this.groups.values());
			chains=Array.from(this.chains.values());
			for(group of groups){
				if(group.tools.indexOf(tool)>=0){
					ref.groups.push(group);
				}
			}
			for(chain of chains){
				if(Object.values(chain.tools).indexOf(tool)>=0){
					ref.chains.push(chain);
				}
			}
			return ref;
		};

		//--------------------------------------------------------------------
		aaTools.getChainRef=function(chain){
			let groups,group;
			let ref={
				groups:[],chains:[]
			};
			groups=Array.from(this.groups.values());
			for(group of groups){
				if(group.chains.indexOf(chain)>=0){
					ref.groups.push(group);
				}
			}
			return ref;
		};
	}
}

export default AATools;
export {AATool,AAToolChain,AAToolGroup,AAToolSite,AATools};