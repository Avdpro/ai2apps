import pathLib from "/@path";
import {VFACT} from "/@vfact";
const $ln=VFACT.lanCode;
let url=import.meta.url;
let dir=pathLib.dirname(url);
export default [
	{
		type:"app",
		name:"Books",
		caption:(($ln==="CN")?("书籍阅览"):/*EN*/("Books")),
		main:`${dir}/app.html`,
		package:"books",
		catalog:["System"],
		icon:`${dir}/favicon.svg`,
		iconApp:null,
		appFrame:{
			main:`${dir}/app.html`,
			group:`${dir}/app.html`,
			title:(($ln==="CN")?("书籍阅览"):/*EN*/("Books")),
			caption:(($ln==="CN")?("书籍阅览"):/*EN*/("Books")),
			openApp:true,
			icon:`${dir}/favicon.svg`,
			width:1200,height:800,
			maxable:false,
			multiFrame:true,
		}
	},
	{
		type:"app",
		name:"MDReader",
		caption:(($ln==="CN")?("MD 阅读器"):/*EN*/("MD Reader")),
		main:`${dir}/app.html`,
		package:"books",
		icon:`${dir}/favicon.svg`,
		iconApp:null,
		appFrame:{
			main:`${dir}/app.html`,
			group:`${dir}/app.html`,
			title:(($ln==="CN")?("MD 阅读器"):/*EN*/("MD Reader")),
			caption:(($ln==="CN")?("MD 阅读器"):/*EN*/("MD Reader")),
			openApp:true,
			icon:`${dir}/favicon.svg`,
			width:500,height:800,
			maxable:false,
			multiFrame:true,
		},
		acceptFileType:{
			"open":[".md"]
		}
	},
	{
		type:"app",
		name:"Documents",
		caption:(($ln==="CN")?("开发文档"):/*EN*/("Documents")),
		main:`${dir}/app.html`,
		package:"books",
		icon:`${dir}/favicon.svg`,
		iconApp:null,
		appFrame:{
			main:`${dir}/app.html`,
			group:`${dir}/app.html@documents`,
			title:(($ln==="CN")?("开发文档"):/*EN*/("Documents")),
			caption:(($ln==="CN")?("开发文档"):/*EN*/("Documents")),
			openApp:true,
			icon:`${dir}/favicon.svg`,
			width:1200,height:800,
			maxable:false,
		}
	}
];