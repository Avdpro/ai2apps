### 编辑板提示

#### 编辑器：
这是一个轻量级的文本/代码编辑器。要开发完整的网页/应用程序项目，请使用“Tab-OS IDE”应用，或用“项目向导”创建新的工程。

#### 正在建设中：
该编辑器仍在开发中。更多功能即将推出。

#### 快捷键：
- 切换文档：`Alt+Tab`/`Ctrl+~（数字键1左边的键）`
- 保存文档：`Cmd+S`
- 另存为：`Shift+Cmd+S`
- 复制：`Cmd+C`（macOS）/`Ctrl+C`（PC）
- 粘贴：`Cmd+V`（macOS）/`Ctrl+V`（PC）
- 撤销：`Cmd+Z`（macOS）/`Ctrl+Z`（PC）
- 重做：`Shift+Cmd+Z`，`Cmd+Y`（macOS）/`Shift+Ctrl+V`，`Ctrl+Y`（PC）
- 查找：`Cmd+F`（macOS）/`Ctrl+F`（PC）
- 查找下一个：`Cmt+G`（macOS）/`Ctrl+G`（PC）
- 替换：`Cmd+Alt+F`（macOS）/`Ctrl+Alt+F`（PC）
