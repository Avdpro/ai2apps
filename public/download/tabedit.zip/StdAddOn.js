import {tabFS} from "/@tabos";

//----------------------------------------------------------------------------
/**
 * Tab-OS universal Add-On class
 * @class
 * @constructor
 * @param {string} cfgPath - path of config json file
 */
let StdAddOn=function(){
	this.cfgPath=null;
	this.config=null;
	this.files=[];
	this.shared={};
	this.regs={};
};

let stdAddOn=StdAddOn.prototype={};

//----------------------------------------------------------------------------
/**
 * Load config json
 * 
 * @param {path} - the config josn path
 * @returns Promise<void>
 */
stdAddOn.loadCfg=async function(path,defCfg){
	let json;
	this.cfgPath=path;
	try{
		json=await tabFS.readFile(path,"utf8");
		json=JSON.parse(json);
		this.config=json;
		this.files=json.files;
	}catch(err){
		this.config=defCfg||{
			files:[],
		};
		this.config.files=this.config.files||[];
		this.files=this.config.files;
		this.saveCfg();
	}
};

//----------------------------------------------------------------------------
/**
 * Save config json
 * 
 * @param [path] - the config josn path, optional. Null path will use the path when loading cifg.
 * @returns Promise<void>
 */
stdAddOn.saveCfg=async function(path){
	let json;
	path=path||this.cfgPath;
	json=JSON.stringify(this.config,null,"\t");
	await tabFS.writeFile(path,json);
};

//----------------------------------------------------------------------------
/**
 * Active addons.
 * 
 * @returns Promise<void>
 */
stdAddOn.active=async function(){
	let files,path,func;
	files=this.files;
	for(path of files){
		try{
			func=(await import(path)).default;
			await func(this);
		}catch(err){
			console.error(`Load addon ${path} failed:`);
			console.log(err);
		}
	}
};

//----------------------------------------------------------------------------
/**
 * Share an object, shared object can ba accessed by name through add-ons and the App.
 *
 * @param {string} name - name of shared
 * @param {any} obj - the object(value) will be shared.
 * @returns {void}
 */
stdAddOn.share=function(name,obj){
	let shared=this.shared;
	if(shared[name]){
		console.warn(`Add-on will replace shared object: ${name}, old object:`);
		console.log(shared[name]);
		console.log("Replacing with: ");
		console.log(obj);
	}
	this.shared[name]=obj;
};

//----------------------------------------------------------------------------
/**
 * Get shared object by name
 * 
 * @param {string} name - name of object
 */
stdAddOn.getShared=function(name){
	return this.shared[name];
};

//----------------------------------------------------------------------------
/**
 * Register an object to a specific slot for later retrieval or use
 * 
 * @param {string} slotName - The name of the slot to register the object to
 * @param {any} obj - The object to register
 */
stdAddOn.reg=function(slotName,obj){
	let slot;
	slot=this.regs[slotName];
	if(!slot){
		slot=this.regs[slotName]=[];
	}
	slot.push(obj);
};

//----------------------------------------------------------------------------
/**
 * Retrieve all the objects registered to a specific slot
 *
 * @param {string} slotName - The name of the slot to retrieve objects from
 * @returns {any[]} - An array of registered objects, or an empty array if no objects are registered to the slot
 */
stdAddOn.getSlot=function(slotName){
	return this.regs[slotName] || [];
};

export default new StdAddOn();
export {StdAddOn};