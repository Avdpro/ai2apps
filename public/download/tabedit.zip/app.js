//Auto genterated by Cody
import {tabOS,tabFS,tabTask} from "/@tabos";
import {VFACT} from "/@vfact";
import {} from "/@vfact/vfact_app.js";
import{appCfg} from "./cfg/appCfg.js";
import{} from "/@StdUI/cfg/appCfg.js";
/*#{MoreImports*/
import {} from "/@homekit/cfg/appCfg.js";
import {AppLib} from "/@homekit/data/AppLib.js";
import pathLib from "/@path";
import {UIStudioi} from "./ui/UIStudioi.js";
import {DlgTask} from "/@homekit/ui/DlgTask.js";
import {DataDocs} from "./data/DataDoc.js";
import {DataPrj} from "./data/DataPrj.js";
import {DataAIChat} from "./data/DataAIChat.js";
import {AddOn} from "./data/AddOn.js";
//Basic addons:
import {TBXPath} from "./ui/TBXPath.js";
import {TBXCloud} from "./ui/TBXCloud.js";
import {TBXFindInFile} from "./ui/TBXFindInFile.js";
import {TBXBookMark} from "./ui/TBXBookMark.js";
import {TBXLint} from "./ui/TBXLint.js";
import {TBXViewHTML} from "./ui/TBXViewHTML.js";
import {DlgFile} from "/@homekit/ui/DlgFile.js";
import AppAddOn from "./StdAddOn.js";
//import {aiCreateFile,aiCoderHelp} from "./ai/AICoder.js";
window.VFACT=VFACT;
/*}#MoreImports*/
VFACT.appCfg=appCfg;
//Prefix extern-lib's appCfgs:
{
	let cfgs,name;
	cfgs=window.codyAppCfgs;
	for(name in cfgs){
		cfgs[name].applyCfg();
	}
}
/*#{StartApp*/
tabOS.allowRoot=true;//Debug
/*}#StartApp*/
//----------------------------------------------------------------------------
//Start the app:
async function startApp() {
	/*#{AppCode*/
	let app,uiDef;
	
	document.title="TabEditor";
	//------------------------------------------------------------------------
	//Check if we are in appFrame:
	let appFrame=null;
	//CheckAppFrame:
	{
		let pw;
		appFrame=null;
		pw=window.parent;
		if(pw!==window){
			if(pw.getAppFrame){
				appFrame=window.appFrame=pw.getAppFrame(window);
			}
		}
	}
	window.tabOSApp=app=await VFACT.createApp();
	
	app.docs=new DataDocs();
	app.docs.saveUsage=false;
	
	app.prj=new DataPrj(app);
	app.aiChat=new DataAIChat();
	
	//setup open (openPath, openMeta...) API:
	await AppLib.setupOpenAPI(app,appFrame);
	
	uiDef=UIStudioi(app);
	if(!appFrame){
		uiDef=AppLib.setupMiniDocker(app,uiDef);
	}
	
	//init app, create app UI tree:
	await VFACT.initApp(app,uiDef,{
		wait:1,
		shortcuts:appCfg.shortcuts,
		DlgTask:DlgTask,
		appFrame:appFrame,
		handleShortcut(action,e){
			if(action==="AIChat"){
				app.showAIDlg && app.showAIDlg();
			}
		}
	});
	
	//Setup StdAddOn-System:
	app.addOn=AppAddOn;
	AppAddOn.share("App",app);
	await AppAddOn.loadCfg("/doc/tabedit/config.json",{files:["/@files/addon/cmpversion.js"]});
	await AppAddOn.active();
	
	
	//Init basic addons here:
	await AddOn.regAddOn("NaviTool","Path",TBXPath);
	await AddOn.regAddOn("InfoTool","Cloud",TBXCloud);
	await AddOn.regAddOn("InfoTool","FindInFiles",TBXFindInFile);
	await AddOn.regAddOn("InfoTool","BookMark",TBXBookMark);
	await AddOn.regAddOn("InfoTool","Lint",TBXLint);
	await AddOn.regAddOn("InfoTool","ViewHTML",TBXViewHTML);
	
	app.mainUI.start();
	//----------------------------------------------------------------------------
	//Focus gain callback:
	window.addEventListener("focus",()=>{
		app.mainUI.OnAppActive();
	});
	
	//Ask before close:
	const isElectron = navigator.userAgent.toLowerCase().includes('electron');
	if(!isElectron){
		window.onbeforeunload=function (e) {
			if(window.editPrjLoaded){
				// Cancel the event
				e.preventDefault(); // If you prevent default behavior in Mozilla Firefox prompt will always be shown
				// Chrome requires returnValue to be set
				e.returnValue = 'Are you sure to close code editor? Unsaved changes will be lost.';
				return 'Are you sure to close code editor? Unsaved changes will be lost.';
			}
		};
	}
	/*}#AppCode*/
}
tabOS.setup().then(()=>{startApp();});
/*#{EndDoc*/
/*}#EndDoc*/

/*Cody Project Doc*/
//{
//	"jaxId": "1G9DJJEFB0",
//	"attrs": {
//		"fonts": {
//			"jaxId": "1G9DJJEFB1",
//			"attrs": {}
//		},
//		"exportTarget": "VFACT document",
//		"localize": {
//			"attrs": [
//				"EN",
//				{
//					"type": "string",
//					"valText": "CN"
//				}
//			]
//		},
//		"language": "CN",
//		"useTabOS": "true",
//		"title": "Tab-OS App",
//		"bgColor": "[255,255,255]",
//		"icon": "",
//		"fullScreen": "false",
//		"multiTouch": "false",
//		"location": "false",
//		"camera": "false",
//		"photo": "false",
//		"notification": "false",
//		"contacts": "false",
//		"payment": "false",
//		"inlinePreloads": "true"
//	}
//}