### 实验室提示

#### 注意：AI-实验室 需要登录 Tab-OS 才能访问 AI-API 调用。

#### 特点：
- 创建 AIChat 或 HTML 游乐场，尝试你的创意。
- AI-实验室可以显示你的词元令牌（token）使用数量，让你预估使用成本情况。
- AI-实验室可以生成AI调用代码，方便你把实验成果迅速投入实用。
- AI-实验室可以启动Chat-Bot测试你的聊天。

#### 正在建设中：
实验室应用程序仍在开发中中。HTML实验室暂未开放。

#### 快捷键：
- 切换文档：`Alt+Tab`/`Ctrl+~（位于 "1" 键左侧的键）`
- 保存文档：`Cmd+S`
- 另存为文档：`Shift+Cmd+S`
- 撤销：`Cmd+Z`（macOS）/`Ctrl+Z`（PC）
- 重做：`Shift+Cmd+Z`，`Cmd+Y`（macOS）/`Shift+Ctrl+V`，`Ctrl+Y`（PC）

