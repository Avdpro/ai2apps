//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1G9LDEL3T0StartDoc*/
/*}#1G9LDEL3T0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BoxFindLine=function(app,icon,text,indent,opts){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let tip="";
	let iconColor=cfgColor.fontToolSub;
	
	/*#{1G9LDEL3T7LocalVals*/
	let txtInfo=null;
	opts=opts||{};//Make sure opts is an object.
	tip=opts.tip||"";
	if(opts.iconColor){
		iconColor=opts.iconColor;
	}
	/*}#1G9LDEL3T7LocalVals*/
	
	/*#{1G9LDEL3T7PreState*/
	/*}#1G9LDEL3T7PreState*/
	/*#{1G9LDEL3T7PostState*/
	/*}#1G9LDEL3T7PostState*/
	cssVO={
		"hash":"1G9LDEL3T7",nameHost:true,
		"type":"button","x":indent,"y":0,"w":`FW-${indent}`,"h":cfgSize.pathLineH,"autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
		"contentLayout":"flex-x",
		children:[
			{
				"hash":"1G9LDQ4UT0",
				"type":"box","id":"BoxOver","x":0,"y":0,"w":"FW","h":"FH","display":0,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.hot,
				"border":[0,0,1,0],"borderColor":cfgColor.fontToolSub,
			},
			{
				"hash":"1G9LDJIVQ0",
				"type":"box","id":"BoxIcon","position":"relative","x":0,"y":3,"w":"FH-6","h":"FH-6","uiEvent":0,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"background":iconColor,"maskImage":icon,"attached":icon?true:false,
			},
			{
				"hash":"1G9LDMPDO0",
				"type":"text","id":"TxtInfo","position":"relative","x":0,"y":0,"w":icon?"FW-FH":"FW","h":"FH","uiEvent":0,"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","color":cfgColor.fontTool,"text":text,"fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,
				"ellipsis":true,
			}
		],
		/*#{1G9LDEL3T7ExtraCSS*/
		/*}#1G9LDEL3T7ExtraCSS*/
		faces:{
			"up":{
				/*BoxOver*/"#1G9LDQ4UT0":{
					"display":0
				}
			},"over":{
				/*BoxOver*/"#1G9LDQ4UT0":{
					"display":1,"background":[255,255,255,0]
				}
			},"down":{
				/*BoxOver*/"#1G9LDQ4UT0":{
					"display":1,"background":cfgColor.hot
				}
			}
		},
		OnCreate:function(){
			self=this;
			
			/*#{1G9LDEL3T7Create*/
			txtInfo=self.TxtInfo;
			/*}#1G9LDEL3T7Create*/
		},
		/*#{1G9LDEL3T7EndCSS*/
		/*}#1G9LDEL3T7EndCSS*/
	};
	/*#{1G9LDEL3T7PostCSSVO*/
	if(tip){
		cssVO.OnMouseInOut=function(isIn){
			if(isIn){
				if(txtInfo.isEllipsised()){
					app.showTip(self,tip,self.w*0.5,0,1,2);
				}
			}else{
				app.abortTip(self);
			}
		}
	}
	/*}#1G9LDEL3T7PostCSSVO*/
	return cssVO;
};
/*#{1G9LDEL3T7ExCodes*/
/*}#1G9LDEL3T7ExCodes*/


/*#{1G9LDEL3T0EndDoc*/
/*}#1G9LDEL3T0EndDoc*/

export default BoxFindLine;
export{BoxFindLine};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearButton",
//	"jaxId": "1G9LDEL3T0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1G9LDEL3T1",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1G9LDEL3T2",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1IA74NO900",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1G9LDEL3T3",
//			"attrs": {
//				"app": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"icon": {
//					"type": "string",
//					"valText": "#appCfg.sharedAssets+\"/find.svg\""
//				},
//				"text": {
//					"type": "string",
//					"valText": "Line 78: x+=10;"
//				},
//				"indent": {
//					"type": "int",
//					"valText": "20"
//				},
//				"opts": {
//					"type": "auto",
//					"valText": "{}"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1G9LDEL3T4",
//			"attrs": {
//				"tip": {
//					"type": "string",
//					"valText": ""
//				},
//				"iconColor": {
//					"type": "colorRGBA",
//					"valText": "#cfgColor.fontToolSub"
//				}
//			}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1G9LDEL3T5",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "VFACT document",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1G9LDEL3T6",
//			"attrs": {
//				"up": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1G9LDV9H60",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1G9LE1SA40",
//							"attrs": {}
//						}
//					}
//				},
//				"over": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1G9LDVD2K0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1G9LE1SA41",
//							"attrs": {}
//						}
//					}
//				},
//				"down": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1G9LDVG430",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1G9LE1SA42",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1IA74NO910",
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "button",
//			"jaxId": "1G9LDEL3T7",
//			"attrs": {
//				"properties": {
//					"jaxId": "1G9LDEL3T8",
//					"attrs": {
//						"type": "button",
//						"id": "",
//						"position": "Absolute",
//						"x": "#indent",
//						"y": "0",
//						"w": "#`FW-${indent}`",
//						"h": "#cfgSize.pathLineH",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "true",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "[0,0,0,0]",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "\"\"",
//						"styleClass": "",
//						"enable": "true",
//						"drag": "NA",
//						"contentLayout": "Flex X"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1G9LDQ4UT0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G9LDUN830",
//									"attrs": {
//										"type": "box",
//										"id": "BoxOver",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "\"FW\"",
//										"h": "\"FH\"",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "Off",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "\"\"",
//										"styleClass": "",
//										"background": "#cfgColor.hot",
//										"border": "[0,0,1,0]",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor.fontToolSub",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1G9LDUN831",
//									"attrs": {
//										"1G9LDVG430": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9LE1SA43",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9LE1SA44",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														},
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor.hot"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9LDVG430",
//											"faceTagName": "down"
//										},
//										"1G9LDV9H60": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9LE1SA45",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9LE1SA46",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9LDV9H60",
//											"faceTagName": "up"
//										},
//										"1G9LDVD2K0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9LE1SA47",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9LE1SA48",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														},
//														"background": {
//															"type": "colorRGBA",
//															"valText": "[255,255,255,0]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9LDVD2K0",
//											"faceTagName": "over"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1G9LDUN832",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IA74NO911",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1G9LDJIVQ0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G9LDMKCV0",
//									"attrs": {
//										"type": "box",
//										"id": "BoxIcon",
//										"position": "Relative",
//										"x": "0",
//										"y": "3",
//										"w": "\"FH-6\"",
//										"h": "\"FH-6\"",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "\"\"",
//										"styleClass": "",
//										"background": "#iconColor",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"maskImage": "#icon",
//										"attach": "#icon?true:false"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1G9LDMKCV1",
//									"attrs": {
//										"1G9LDV9H60": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9LE1SA411",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9LE1SA412",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9LDV9H60",
//											"faceTagName": "up"
//										},
//										"1G9LDVD2K0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9LE1SA413",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9LE1SA414",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9LDVD2K0",
//											"faceTagName": "over"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1G9LDMKCV2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IA74NO912",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1G9LDMPDO0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G9LDUN833",
//									"attrs": {
//										"type": "text",
//										"id": "TxtInfo",
//										"position": "Relative",
//										"x": "0",
//										"y": "0",
//										"w": "#icon?\"FW-FH\":\"FW\"",
//										"h": "\"FH\"",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "\"\"",
//										"styleClass": "",
//										"color": "#cfgColor.fontTool",
//										"text": "#text",
//										"font": "",
//										"fontSize": "#txtSize.smallMid",
//										"bold": "false",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Center",
//										"wrap": "false",
//										"ellipsis": "true",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0",
//										"autoSizeW": "false",
//										"autoSizeH": "false"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1G9LDUN834",
//									"attrs": {
//										"1G9LDV9H60": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9LE1SA417",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9LE1SA418",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9LDV9H60",
//											"faceTagName": "up"
//										},
//										"1G9LDVD2K0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9LE1SA419",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9LE1SA420",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9LDVD2K0",
//											"faceTagName": "over"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1G9LDUN835",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IA74NO913",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1G9LDEL3T9",
//					"attrs": {
//						"1G9LDV9H60": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1G9LE1SA423",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G9LE1SA424",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1G9LDV9H60",
//							"faceTagName": "up"
//						},
//						"1G9LDVD2K0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1G9LE1SA425",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G9LE1SA426",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1G9LDVD2K0",
//							"faceTagName": "over"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1G9LDEL3T10",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1IA74NO914",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1G9LDEL3T11",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"enable": "false",
//				"drag": "false",
//				"innerLayout": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"face": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"marginL": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"marginR": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"marginT": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"marginB": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"paddingL": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"paddingT": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"paddingR": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"paddingB": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"attach": {
//					"type": "bool",
//					"valText": "false"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}