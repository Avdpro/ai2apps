//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
/*#{1G9E583100StartDoc*/
import pathLib from "/@path";
/*}#1G9E583100StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let DocTabBtn=function(app,doc,trk){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let icon=appCfg.sharedAssets+"/file.svg";
	let name="DocTabBtn.js";
	
	/*#{1G9E583107LocalVals*/
	let path,extName;
	path=doc.path;
	extName=pathLib.extname(path);
	name=pathLib.basename(path);
	/*}#1G9E583107LocalVals*/
	
	/*#{1G9E583107PreState*/
	let isFocused=0;
	let track=null;
	let dragMoved=false;
	/*}#1G9E583107PreState*/
	/*#{1G9E583107PostState*/
	/*}#1G9E583107PostState*/
	cssVO={
		"hash":"1G9E583107",nameHost:true,
		"type":"button","position":"relative","x":0,"y":2,"w":"","h":"FH-2","margin":[0,1,0,1],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","drag":2,
		"contentLayout":"flex-x",
		children:[
			{
				"hash":"1G9E5NC6M0",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"FH-1","autoLayout":true,"uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"background":cfgColor.tool,"border":[0,0,0,0],"borderColor":cfgColor.fontToolSub,
			},
			{
				"hash":"1G9E61GF40",
				"type":"box","id":"BoxIcon","position":"relative","x":0,"y":3,"w":"FH-6","h":"FH-6","uiEvent":-1,"margin":[0,0,0,2],"minW":"","minH":"","maxW":"",
				"maxH":"","styleClass":"","background":cfgColor["fontBodySub"],"maskImage":icon,
			},
			{
				"hash":"1G9E64LN50",
				"type":"text","id":"TxtName","position":"relative","x":0,"y":0,"w":"","h":"FH","uiEvent":-1,"margin":[0,2,0,0],"minW":"","minH":"","maxW":200,"maxH":"",
				"styleClass":"","color":cfgColor["fontBodySub"],"text":name,"fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
				"alignV":1,"ellipsis":true,
			},
			{
				"hash":"1IA1128O70",
				"type":BtnIcon("front",18,0,appCfg.sharedAssets+"/close.svg",null),"id":"BtnClose","position":"relative","x":0,"y":"50%","alpha":0.5,"padding":1,"anchorY":1,
				/*#{1IA1128O70Codes*/
				OnClick(){
					self.closeDoc();
				}
				/*}#1IA1128O70Codes*/
			},
			{
				"hash":"1G9EGAVV50",
				"type":"box","id":"BoxDirty","x":">calc(100% - 12px)","y":"50%","w":12,"h":12,"anchorX":1,"anchorY":1,"autoLayout":true,"display":0,"uiEvent":-1,"alpha":0.7,
				"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.error,"corner":6,
			}
		],
		/*#{1G9E583107ExtraCSS*/
		doc:doc,traceSize:1,
		/*}#1G9E583107ExtraCSS*/
		faces:{
			"up":{
				/*#{1G9EGDL020PreCode*/
				$(){
					return isFocused?false:true;
				},
				/*}#1G9EGDL020PreCode*/
				/*BoxBG*/"#1G9E5NC6M0":{
					"background":cfgColor.tool
				}
			},"over":{
				/*#{1G9EGDQAD0PreCode*/
				$(){
					return isFocused?false:true;
				},
				/*}#1G9EGDQAD0PreCode*/
				/*BoxBG*/"#1G9E5NC6M0":{
					"background":cfgColor.hot
				}
			},"down":{
				/*#{1G9EGDTK90PreCode*/
				$(){
					return isFocused?false:true;
				},
				/*}#1G9EGDTK90PreCode*/
				/*BoxBG*/"#1G9E5NC6M0":{
					"background":cfgColor.hot
				}
			},"dirty":{
				/*BoxDirty*/"#1G9EGAVV50":{
					"display":1
				}
			},"clean":{
				/*BoxDirty*/"#1G9EGAVV50":{
					"display":0
				}
			},"focus":{
				/*BoxBG*/"#1G9E5NC6M0":{
					"h":"FH","background":cfgColor.body,"border":[1,1,0,1]
				},
				/*TxtName*/"#1G9E64LN50":{
					"fontStyle":"normal","color":cfgColor["fontBody"]
				},
				/*#{1G9EGEKR60Code*/
				$(){
					isFocused=true;
				},
				/*}#1G9EGEKR60Code*/
			},"blur":{
				/*BoxBG*/"#1G9E5NC6M0":{
					"background":cfgColor.tool,"h":"FH-1","border":[0,0,0,0]
				},
				/*TxtName*/"#1G9E64LN50":{
					"fontStyle":"normal","color":cfgColor["fontBodySub"]
				},
				/*#{1G9EGGTRM0Code*/
				$(){
					isFocused=false;
				},
				/*}#1G9EGGTRM0Code*/
			},"temp":{
				/*BoxBG*/"#1G9E5NC6M0":{
					"h":"FH","background":[...cfgColor.success,90],"border":[1,1,0,1]
				},
				/*TxtName*/"#1G9E64LN50":{
					"fontStyle":"italic"
				},
				/*#{1G9JP5OMF0Code*/
				$(){
					isFocused=true;
				},
				/*}#1G9JP5OMF0Code*/
			}
		},
		OnCreate:function(){
			self=this;
			
			/*#{1G9E583107Create*/
			track=trk;//self.parent;
			doc.assignTabBox(self);
			doc.onNotify("Changed",self.OnChanged);
			doc.onNotify("Saved",self.OnSaved);
			/*}#1G9E583107Create*/
		},
		/*#{1G9E583107EndCSS*/
		OnFree(){
			doc.offNotify("Changed",self.OnChanged);
			doc.offNotify("Saved",self.OnSaved);
		}
		/*}#1G9E583107EndCSS*/
	};
	/*#{1G9E583107PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.OnChanged=function(){
		self.showFace("dirty");
	};
	
	//------------------------------------------------------------------------
	cssVO.OnSaved=function(){
		self.showFace("clean");
	};
	//------------------------------------------------------------------------
	cssVO.OnDragStart=function(evt){
		if(doc.tempOpen){
			doc.docs.pinDoc(doc);
		}
		dragMoved=false;
		if(!isFocused){
			doc.docs.focusDoc(doc);
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.OnDrag=function(evt,dx,dy){
		if(!dragMoved){
			if(dx<-5 || dx>5){
				track.dragTabStart(self);
				track.dragTab(self,dx,dy);
				dragMoved=true;
			}
			return;
		}
		track.dragTab(self,dx,dy);
	};
	
	//------------------------------------------------------------------------
	cssVO.OnDragEnd=function(evt,dx,dy){
		if(dragMoved){
			track.dragTabEnd(self);
		}
		callAfter(()=>{
			doc.docs.focusDoc(doc);
		});
		doc.tabFocused();
	};
	
	//------------------------------------------------------------------------
	cssVO.closeDoc=function(){
		if(!doc.isChanged()){
			doc.docs.closeDoc(doc);
			return;
		}
		if(window.confirm(`${doc.path} is changed, are you sure to abort changes and close it?`)){
			doc.docs.closeDoc(doc);
		}
	};
	/*}#1G9E583107PostCSSVO*/
	return cssVO;
};
/*#{1G9E583107ExCodes*/
/*}#1G9E583107ExCodes*/


/*#{1G9E583100EndDoc*/
/*}#1G9E583100EndDoc*/

export default DocTabBtn;
export{DocTabBtn};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearButton",
//	"jaxId": "1G9E583100",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1G9E583101",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "30",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1G9E583102",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1IA115L330",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1G9E583103",
//			"attrs": {
//				"app": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"doc": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"trk": {
//					"type": "auto",
//					"valText": "null"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1G9E583104",
//			"attrs": {
//				"icon": {
//					"type": "string",
//					"valText": "#appCfg.sharedAssets+\"/file.svg\""
//				},
//				"name": {
//					"type": "string",
//					"valText": "DocTabBtn.js"
//				}
//			}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1G9E583105",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "VFACT document",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1G9E583106",
//			"attrs": {
//				"up": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1G9EGDL020",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "true",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1G9EGQ2IM0",
//							"attrs": {}
//						}
//					}
//				},
//				"over": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1G9EGDQAD0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "true",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1G9EGQ2IM1",
//							"attrs": {}
//						}
//					}
//				},
//				"down": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1G9EGDTK90",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "true",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1G9EGQ2IM2",
//							"attrs": {}
//						}
//					}
//				},
//				"dirty": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1G9EGEB8G0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1G9EGQ2IM3",
//							"attrs": {}
//						}
//					}
//				},
//				"clean": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1G9EGEG7B0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1G9EGQ2IM4",
//							"attrs": {}
//						}
//					}
//				},
//				"focus": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1G9EGEKR60",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1G9EGQ2IM5",
//							"attrs": {}
//						}
//					}
//				},
//				"blur": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1G9EGGTRM0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1G9EGQ2IM6",
//							"attrs": {}
//						}
//					}
//				},
//				"temp": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1G9JP5OMF0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1G9JP8D4S0",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1IA115L340",
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "button",
//			"jaxId": "1G9E583107",
//			"attrs": {
//				"properties": {
//					"jaxId": "1G9E583108",
//					"attrs": {
//						"type": "button",
//						"id": "",
//						"position": "Relative",
//						"x": "0",
//						"y": "2",
//						"w": "\"\"",
//						"h": "\"FH-2\"",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "[0,1,0,1]",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "\"\"",
//						"styleClass": "",
//						"enable": "true",
//						"drag": "Pointer down",
//						"contentLayout": "Flex X"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1G9E5NC6M0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G9E5V8SH0",
//									"attrs": {
//										"type": "box",
//										"id": "BoxBG",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "#\"FW\"#>\"100%\"",
//										"h": "\"FH-1\"",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "true",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "\"\"",
//										"styleClass": "",
//										"background": "#cfgColor.tool",
//										"border": "[0,0,0,0]",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor.fontToolSub",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1G9E5V8SH1",
//									"attrs": {
//										"1G9EGGTRM0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9EGQ2IM7",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9EGQ2IM8",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor.tool"
//														},
//														"h": {
//															"type": "length",
//															"valText": "\"FH-1\""
//														},
//														"border": {
//															"type": "auto",
//															"valText": "[0,0,0,0]",
//															"editMode": "edges"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9EGGTRM0",
//											"faceTagName": "blur"
//										},
//										"1G9EGDL020": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9EGQ2IM9",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9EGQ2IM10",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor.tool"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9EGDL020",
//											"faceTagName": "up"
//										},
//										"1G9EGDQAD0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9EGQ2IM11",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9EGQ2IM12",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor.hot"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9EGDQAD0",
//											"faceTagName": "over"
//										},
//										"1G9EGDTK90": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9EGQ2IM13",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9EGQ2IM14",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor.hot"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9EGDTK90",
//											"faceTagName": "down"
//										},
//										"1G9EGEB8G0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9EGQ2IM15",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9EGQ2IM16",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9EGEB8G0",
//											"faceTagName": "dirty"
//										},
//										"1G9EGEKR60": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9EH17QI0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9EH17QI1",
//													"attrs": {
//														"h": {
//															"type": "length",
//															"valText": "\"FH\""
//														},
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor.body"
//														},
//														"border": {
//															"type": "auto",
//															"valText": "[1,1,0,1]",
//															"editMode": "edges"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9EGEKR60",
//											"faceTagName": "focus"
//										},
//										"1G9EGEG7B0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9GGR3PI0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9GGR3PI1",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9EGEG7B0",
//											"faceTagName": "clean"
//										},
//										"1G9JP5OMF0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9JP8D4S1",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9JP8D4S2",
//													"attrs": {
//														"h": {
//															"type": "length",
//															"valText": "\"FH\""
//														},
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#[...cfgColor.success,90]"
//														},
//														"border": {
//															"type": "auto",
//															"valText": "[1,1,0,1]",
//															"editMode": "edges"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9JP5OMF0",
//											"faceTagName": "temp"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1G9E5V8SH2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H0MNFQRK0",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1G9E61GF40",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G9E61GF41",
//									"attrs": {
//										"type": "box",
//										"id": "BoxIcon",
//										"position": "Relative",
//										"x": "0",
//										"y": "3",
//										"w": "\"FH-6\"",
//										"h": "\"FH-6\"",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,2]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "\"\"",
//										"styleClass": "",
//										"background": "#cfgColor[\"fontBodySub\"]",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"maskImage": "#icon"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1G9E61GF50",
//									"attrs": {
//										"1G9EGDL020": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9EGQ2IM19",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9EGQ2IM20",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9EGDL020",
//											"faceTagName": "up"
//										},
//										"1G9EGEB8G0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9EGQ2IM25",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9EGQ2IM26",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9EGEB8G0",
//											"faceTagName": "dirty"
//										},
//										"1G9EGEG7B0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9GGR3PI4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9GGR3PI5",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9EGEG7B0",
//											"faceTagName": "clean"
//										},
//										"1G9EGDQAD0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9JP8D4S3",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9JP8D4S4",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9EGDQAD0",
//											"faceTagName": "over"
//										},
//										"1G9EGDTK90": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9JP8D4S5",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9JP8D4S6",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9EGDTK90",
//											"faceTagName": "down"
//										},
//										"1G9EGEKR60": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IA4EA9UE0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IA4EA9UE1",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9EGEKR60",
//											"faceTagName": "focus"
//										},
//										"1G9EGGTRM0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IA4EBL8U0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IA4EBL8U1",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9EGGTRM0",
//											"faceTagName": "blur"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1G9E61GF51",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H0MNFQRK1",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1G9E64LN50",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G9EGD2RP0",
//									"attrs": {
//										"type": "text",
//										"id": "TxtName",
//										"position": "Relative",
//										"x": "0",
//										"y": "0",
//										"w": "\"\"",
//										"h": "\"FH\"",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,2,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "200",
//										"maxH": "",
//										"face": "\"\"",
//										"styleClass": "",
//										"color": "#cfgColor[\"fontBodySub\"]",
//										"text": "#name",
//										"font": "",
//										"fontSize": "#txtSize.smallMid",
//										"bold": "false",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Center",
//										"wrap": "false",
//										"ellipsis": "true",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0",
//										"autoSizeW": "false",
//										"autoSizeH": "false"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1G9EGD2RP1",
//									"attrs": {
//										"1G9EGDL020": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9EGQ2IM29",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9EGQ2IM30",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9EGDL020",
//											"faceTagName": "up"
//										},
//										"1G9EGEB8G0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9EGQ2IM35",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9EGQ2IM36",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9EGEB8G0",
//											"faceTagName": "dirty"
//										},
//										"1G9EGEKR60": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9GGNUHM2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9GGNUHM3",
//													"attrs": {
//														"italic": {
//															"type": "bool",
//															"valText": "false"
//														},
//														"color": {
//															"type": "colorRGB",
//															"valText": "#cfgColor[\"fontBody\"]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9EGEKR60",
//											"faceTagName": "focus"
//										},
//										"1G9EGEG7B0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9GGR3PI8",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9GGR3PI9",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9EGEG7B0",
//											"faceTagName": "clean"
//										},
//										"1G9EGDQAD0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9JP8D4S9",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9JP8D4S10",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9EGDQAD0",
//											"faceTagName": "over"
//										},
//										"1G9EGDTK90": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9JP8D4S11",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9JP8D4S12",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9EGDTK90",
//											"faceTagName": "down"
//										},
//										"1G9JP5OMF0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9JQK2662",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9JQK2663",
//													"attrs": {
//														"italic": {
//															"type": "bool",
//															"valText": "true"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9JP5OMF0",
//											"faceTagName": "temp"
//										},
//										"1G9EGGTRM0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9JQKQP52",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9JQKQP53",
//													"attrs": {
//														"italic": {
//															"type": "bool",
//															"valText": "false"
//														},
//														"color": {
//															"type": "colorRGB",
//															"valText": "#cfgColor[\"fontBodySub\"]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9EGGTRM0",
//											"faceTagName": "blur"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1G9EGD2RQ0",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H0MNFQRK2",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear/@StdUI/ui/BtnIcon.js",
//							"jaxId": "1IA1128O70",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1IA115L346",
//									"attrs": {
//										"style": "\"front\"",
//										"w": "18",
//										"h": "0",
//										"icon": "#appCfg.sharedAssets+\"/close.svg\"",
//										"colorBG": "null"
//									}
//								},
//								"properties": {
//									"jaxId": "1IA115L347",
//									"attrs": {
//										"type": "#null#>BtnIcon(\"front\",18,0,appCfg.sharedAssets+\"/close.svg\",null)",
//										"id": "BtnClose",
//										"position": "relative",
//										"x": "0",
//										"y": "50%",
//										"display": "On",
//										"face": "",
//										"alpha": "0.50",
//										"padding": "1",
//										"anchorV": "Center"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1IA115L348",
//									"attrs": {
//										"1G9EGDL020": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IA4CCJ5A0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IA4CCJ5A1",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9EGDL020",
//											"faceTagName": "up"
//										},
//										"1G9EGDQAD0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IA4CCJ5A2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IA4CCJ5A3",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9EGDQAD0",
//											"faceTagName": "over"
//										},
//										"1G9EGDTK90": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IA4CCJ5A4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IA4CCJ5A5",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9EGDTK90",
//											"faceTagName": "down"
//										},
//										"1G9EGEB8G0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IA4CCJ5A6",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IA4CCJ5A7",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9EGEB8G0",
//											"faceTagName": "dirty"
//										},
//										"1G9EGEG7B0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IA4CCJ5A8",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IA4CCJ5A9",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9EGEG7B0",
//											"faceTagName": "clean"
//										},
//										"1G9EGEKR60": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IA4EA9UE2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IA4EA9UE3",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9EGEKR60",
//											"faceTagName": "focus"
//										},
//										"1G9EGGTRM0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IA4EBL8U2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IA4EBL8U3",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9EGGTRM0",
//											"faceTagName": "blur"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1IA115L349",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IA115L3410",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "true",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false",
//								"containerSlots": {
//									"jaxId": "1IA115L3411",
//									"attrs": {}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1G9EGAVV50",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G9EGD2RQ5",
//									"attrs": {
//										"type": "box",
//										"id": "BoxDirty",
//										"position": "Absolute",
//										"x": "100%-12",
//										"y": "50%",
//										"w": "12",
//										"h": "12",
//										"anchorH": "Center",
//										"anchorV": "Center",
//										"autoLayout": "true",
//										"display": "Off",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "0.70",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "\"\"",
//										"styleClass": "",
//										"background": "#cfgColor.error",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "6",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1G9EGD2RQ6",
//									"attrs": {
//										"1G9EGDL020": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9EGQ2IM49",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9EGQ2IM50",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9EGDL020",
//											"faceTagName": "up"
//										},
//										"1G9EGEB8G0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9EGQ2IM55",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9EGQ2IM56",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9EGEB8G0",
//											"faceTagName": "dirty"
//										},
//										"1G9EGEG7B0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9EGQ2IM57",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9EGQ2IM58",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9EGEG7B0",
//											"faceTagName": "clean"
//										},
//										"1G9EGDQAD0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9JP8D4T4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9JP8D4T5",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9EGDQAD0",
//											"faceTagName": "over"
//										},
//										"1G9EGDTK90": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9JP8D4T6",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9JP8D4T7",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9EGDTK90",
//											"faceTagName": "down"
//										},
//										"1G9EGEKR60": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IA4EA9UE4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IA4EA9UE5",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9EGEKR60",
//											"faceTagName": "focus"
//										},
//										"1G9EGGTRM0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IA4EBL8U4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IA4EBL8U5",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9EGGTRM0",
//											"faceTagName": "blur"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1G9EGD2RQ7",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H0MNFQRK4",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1G9E583109",
//					"attrs": {
//						"1G9EGDL020": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1G9EGQ2IM61",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G9EGQ2IM62",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1G9EGDL020",
//							"faceTagName": "up"
//						},
//						"1G9EGEB8G0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1G9EGQ2IM67",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G9EGQ2IM68",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1G9EGEB8G0",
//							"faceTagName": "dirty"
//						},
//						"1G9EGEG7B0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1G9GGR3PI18",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G9GGR3PI19",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1G9EGEG7B0",
//							"faceTagName": "clean"
//						},
//						"1G9EGDQAD0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1G9JP8D4T10",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G9JP8D4T11",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1G9EGDQAD0",
//							"faceTagName": "over"
//						},
//						"1G9EGDTK90": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1G9JP8D4T12",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G9JP8D4T13",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1G9EGDTK90",
//							"faceTagName": "down"
//						},
//						"1G9EGEKR60": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1IA4EA9UE6",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IA4EA9UE7",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1G9EGEKR60",
//							"faceTagName": "focus"
//						},
//						"1G9EGGTRM0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1IA4EBL8U6",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IA4EBL8U7",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1G9EGGTRM0",
//							"faceTagName": "blur"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1G9E5831010",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1H0MNFQRK5",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1G9E5831011",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"enable": "false",
//				"drag": "false",
//				"innerLayout": {
//					"valText": "false"
//				},
//				"marginL": {
//					"valText": "false"
//				},
//				"marginR": {
//					"valText": "false"
//				},
//				"marginT": {
//					"valText": "false"
//				},
//				"marginB": {
//					"valText": "false"
//				},
//				"paddingL": {
//					"valText": "false"
//				},
//				"paddingR": {
//					"valText": "false"
//				},
//				"paddingT": {
//					"valText": "false"
//				},
//				"paddingB": {
//					"valText": "false"
//				},
//				"attach": {
//					"valText": "false"
//				},
//				"face": {
//					"type": "bool",
//					"valText": "false"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}