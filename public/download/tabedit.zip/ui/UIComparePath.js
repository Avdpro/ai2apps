//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
/*#{1IM07M1IM0StartDoc*/
import pathLib from "/@path";
import {tabFS} from "/@tabos";
import {AddOn} from "../data/AddOn.js";
import {makeNotify,makeObjEventEmitter} from "/@events";
import {readPath,readPathInfo} from "/@StdUI/FileUtils.js";
import {readCompDir} from "/@StdUI/CompareUtils.js";
import {PathCompareLine} from "/@StdUI/ui/PathCompareLine.js";
import {CompathPrj} from "../data/CompathPrj.js";
/*}#1IM07M1IM0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let UIComparePath=function(app,mode,codeText,cfgVO,dataDoc){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let edLeftPath,btnCfg,edRightPath,btnCopyToRight,btnCopyToLeft,listBox;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let cellDef=undefined;
	let lineDef=undefined;
	let leftPath="";
	let rightPath="";
	let sbarWidth=20;
	
	/*#{1IM07M1IM1LocalVals*/
	function getScrollbarWidth() {
		const div = document.createElement("div");
		div.style.width = "100px";
		div.style.height = "100px";
		div.style.overflow = "scroll";
		div.style.position = "absolute";
		div.style.top = "-9999px";
		document.body.appendChild(div);
	
		const scrollbarWidth = div.offsetWidth - div.clientWidth;
		document.body.removeChild(div);
		return scrollbarWidth;
	}
	sbarWidth=getScrollbarWidth();
	/*}#1IM07M1IM1LocalVals*/
	
	/*#{1IM07M1IM1PreState*/
	let dataDocs=app.docs;
	/*}#1IM07M1IM1PreState*/
	/*#{1IM07M1IM1PostState*/
	let lastClickTime=0;
	let lastClickItem=null;
	let itemOnClick=function(evt,side){
		let button,item,entry,node;
		item=this;
		entry=item.entry;
		node=item.node;
		button=evt.button;
		if(button===0){//Left button
			let time=Date.now();
			self.emitNotify("CaptureFocus");
			if(time-lastClickTime<500 && item===lastClickItem){
				self.emitNotify("OpenLine");
				lastClickTime=0;
				lastClickItem=null;
			}else{
				if(evt.shiftKey){
					let hotNode,nodes,idx1,idx2,i;
					hotNode=listBox.hotNode;
					nodes=listBox.nodes;
					if(!hotNode){
						listBox.setHotNode(node);
						lastClickTime=0;
					}else{
						if(hotNode===node){
							return;//Do nothing.
						}
						idx1=listBox.indexOfNode(hotNode);
						idx2=listBox.indexOfNode(node);
						if(idx1>idx2){//Swap idx,idx2
							idx1=idx1+idx2;
							idx2=idx1-idx2;
							idx1=idx1-idx2;
						}
						if(evt.metaKey||evt.ctrlKey){
							let nd;
							listBox.pauseCallback++;
							//tbView.hotNode=null;
							for(i=idx1;i<=idx2;i++){
								nd=nodes[i];
								if(listBox.isNodeSelected(nd)){
									listBox.deselectNode(nd);
								}else{
									listBox.selectNode(nd);
								}
							}
							listBox.pauseCallback--;
							listBox.setHotNode(node,true);
						}else{
							listBox.pauseCallback++;
							listBox.clearSelects();
							listBox.hotNode=null;
							for(i=idx1;i<=idx2;i++){
								listBox.selectNode(nodes[i]);
							}
							listBox.pauseCallback--;
							listBox.setHotNode(node,true);
						}
					}
				}else if(evt.metaKey||evt.ctrlKey){
					if(listBox.isNodeSelected(node)){
						let idx,selList,nextNode,hotNode;
						hotNode=listBox.hotNode;
						selList=Array.from(listBox.selected);
						idx=selList.indexOf(node);
						listBox.deselectNode(node);
						if(hotNode===node){
							nextNode=selList[idx+1]||selList[idx-1];
							if(nextNode){
								listBox.setHotNode(nextNode,true);
							}
						}
					}else{
						listBox.setHotNode(node,true);
					}
					lastClickTime=0;
					lastClickItem=null;
				}else{
					listBox.setHotNode(node);
					lastClickTime=time;
					lastClickItem=item;
				}
			}
		}else{//Right button
			if(listBox.selected.size>1){
				if(listBox.isItemSelected(item)){
					listBox.setHotNode(node,true);
					lastClickTime=0;
					lastClickItem=item;
					self.showMenu(item,side,entry,node,evt);
					return;
				}
			}
			listBox.setHotNode(node);
			self.showMenu(item,side,entry,node,evt);
			lastClickTime=0;
			lastClickItem=item;
		}
	};
	
	let cellOpts={
		height:24,fontSize:txtSize.smallMid,iconSize:20,indentSize:20,dataDoc:dataDoc
	};
	lineDef=function(obj,node){
		let name,path,indent,left,right;
		let lastClickTime=0;
		name=obj.name;path=obj.path;left=obj.left||{path:obj.leftPath};right=obj.right||{path:obj.rightPath};
		return {
			type:PathCompareLine(self,obj,node,cellOpts),entryObj:obj,
			OnLineClick:itemOnClick
		};
	};
	//------------------------------------------------------------------------
	let getSubObjs=function(obj,node){
		return node.subItems||obj.subItems;
	};
	/*}#1IM07M1IM1PostState*/
	cssVO={
		"hash":"1IM07M1IM1",nameHost:true,
		"type":"view","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
		children:[
			{
				"hash":"1IM07SGPB0",
				"type":"box","id":"BoxPath","x":0,"y":0,"w":"100%","h":30,"padding":[0,sbarWidth,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["body"],
				"border":[0,0,1,0],"borderColor":cfgColor["fontBodyLit"],"contentLayout":"flex-x","itemsAlign":1,
				children:[
					{
						"hash":"1IM07U1NA0",
						"type":"hud","position":"relative","x":0,"y":0,"w":">calc(50% - 1px)","h":"100%","padding":[0,5,0,5],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						"contentLayout":"flex-x","itemsAlign":1,
						children:[
							{
								"hash":"1IM081BV50",
								"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/folder.svg",null),"position":"relative","x":0,"y":0,
								"OnClick":function(event){
									self.openLeftPath(this,event);
								},
							},
							{
								"hash":"1IM07UR7S0",
								"type":"edit","id":"EdLeftPath","position":"relative","x":0,"y":0,"w":">calc(100% - 99px)","h":20,"margin":[0,0,0,5],"minW":"","minH":"","maxW":"",
								"maxH":"","styleClass":"","color":[0,0,0],"outline":0,"border":[0,0,1,0],
								"OnKeyDown":function(event){
									/*#{1IM4C2OU20FunctionBody*/
									if(event.code==="Enter"){
										if((!event.isComposing) &&(!event.shiftKey)){
											event.stopPropagation();
											event.preventDefault();
											self.refresh();
										}
									}
									/*}#1IM4C2OU20FunctionBody*/
								},
								/*#{1IM07UR7S0Codes*/
								/*}#1IM07UR7S0Codes*/
							},
							{
								"hash":"1IM7MGM970",
								"type":"hud","position":"relative","x":0,"y":0,"w":5,"h":"100%","styleClass":"","flex":true,
							},
							{
								"hash":"1IM7MH9JP0",
								"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/settings.svg",null),"id":"BtnCfg","position":"relative","x":0,"y":0,
								"tip":(($ln==="CN")?("规则设置"):("Rule Settings")),
								"OnClick":function(event){
									self.editCfg(this,event);
								},
							}
						],
					},
					{
						"hash":"1IM085G8M0",
						"type":"box","position":"relative","x":0,"y":0,"w":1,"h":"90%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["fontBodyLit"],
					},
					{
						"hash":"1IM07UDR10",
						"type":"hud","position":"relative","x":0,"y":0,"w":"50%","h":"100%","padding":[0,5,0,5],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						"contentLayout":"flex-x","itemsAlign":1,
						children:[
							{
								"hash":"1IM08394V0",
								"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/folder.svg",null),"position":"relative","x":0,"y":0,
								"OnClick":function(event){
									self.openRightPath(this,event);
								},
							},
							{
								"hash":"1IM083O4A0",
								"type":"edit","id":"EdRightPath","position":"relative","x":0,"y":0,"w":">calc(100% - 100px)","h":20,"margin":[0,0,0,5],"minW":"","minH":"","maxW":"",
								"maxH":"","styleClass":"","color":[0,0,0],"outline":0,"border":[0,0,1,0],
								"OnKeyDown":function(event){
									/*#{1IM4C2OU21FunctionBody*/
									if(event.code==="Enter"){
										if((!event.isComposing) &&(!event.shiftKey)){
											event.stopPropagation();
											event.preventDefault();
											self.refresh();
										}
									}
									/*}#1IM4C2OU21FunctionBody*/
								},
							}
						],
					}
				],
			},
			{
				"hash":"1IM07ML6U0",
				"type":"box","id":"BoxHeader","x":0,"y":30,"w":"100%","h":20,"padding":[0,sbarWidth,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["footer"],
				"border":[0,0,1,0],"borderColor":cfgColor["fontBodySub"],"contentLayout":"flex-x","itemsAlign":1,
				children:[
					{
						"hash":"1IM08F44I0",
						"type":"hud","position":"relative","x":0,"y":0,"w":">calc(50% - 15px)","h":"100%","margin":[0,30,0,0],"padding":[0,0,0,5],"minW":"","minH":"","maxW":"",
						"maxH":"","styleClass":"","contentLayout":"flex-xr","itemsAlign":1,
						children:[
							{
								"hash":"1IM08FJAT0",
								"type":BtnIcon("front",20,0,appCfg.sharedAssets+"/arrowright.svg",null),"id":"BtnCopyToRight","position":"relative","x":0,"y":0,"margin":[0,5,0,5],
								"enable":false,
							},
							{
								"hash":"1IM08HHR80",
								"type":BtnIcon("front",20,0,appCfg.sharedAssets+"/trash.svg",null),"id":"BtnDelLeft","position":"relative","x":0,"y":0,"margin":[0,5,0,5],
								"OnClick":function(event){
									self.delLeft(this,event);
								},
							},
							{
								"hash":"1IM2RCH5N0",
								"type":"hud","position":"relative","x":0,"y":0,"w":10,"h":"100%","styleClass":"","flex":true,
							},
							{
								"hash":"1IM2RDC4L0",
								"type":BtnIcon("front",20,0,appCfg.sharedAssets+"/undo.svg",null),"position":"relative","x":0,"y":0,
								"tip":(($ln==="CN")?("刷新"):("Refresh")),
								"OnClick":function(event){
									self.refresh(this,event);
								},
							}
						],
					},
					{
						"hash":"1IM08G01V0",
						"type":"hud","position":"relative","x":0,"y":0,"w":">calc(50% - 15px)","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
						"itemsAlign":1,
						children:[
							{
								"hash":"1IM08G0200",
								"type":BtnIcon("front",20,0,appCfg.sharedAssets+"/arrowleft.svg",null),"id":"BtnCopyToLeft","position":"relative","x":0,"y":0,"margin":[0,5,0,5],
								"enable":false,
							},
							{
								"hash":"1IM08I5AL0",
								"type":BtnIcon("front",20,0,appCfg.sharedAssets+"/trash.svg",null),"id":"BtnDelLeft","position":"relative","x":0,"y":0,"margin":[0,5,0,5],
								"OnClick":function(event){
									self.delRight(this,event);
								},
							}
						],
					}
				],
			},
			{
				"hash":"1IM07P46H0",
				"type":"tree","id":"ListBox","x":0,"y":50,"w":"100%","h":">calc(100% - 50px)","contentLayout":"flex-y","overflow":"hidden scroll","minW":"","minH":"",
				"maxW":"","maxH":"","styleClass":"",
				/*#{1IM07P46H0Codes*/
				/*}#1IM07P46H0Codes*/
			}
		],
		/*#{1IM07M1IM1ExtraCSS*/
		/*}#1IM07M1IM1ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			self=this;
			edLeftPath=self.EdLeftPath;btnCfg=self.BtnCfg;edRightPath=self.EdRightPath;btnCopyToRight=self.BtnCopyToRight;btnCopyToLeft=self.BtnCopyToLeft;listBox=self.ListBox;
			/*#{1IM07M1IM1Create*/
			makeObjEventEmitter(this);
			makeNotify(this);
			listBox.nodeDef=lineDef;
			listBox.getSubObjs=getSubObjs;
			
			self.onNotify("OpenLine",()=>{
				let node,hud,entry,path;
				node=listBox.hotNode;
				if(!node){
					return;
				}
				entry=node.hud.entry;
				if(entry){
					if(entry.dir){
						if(node.isOpen){
							self.collapseDirNode(node);
						}else{
							self.expandDirNode(node);
						}
					}else{
						dataDocs.openCompare({
							left:{path:entry.leftPath},right:{path:entry.rightPath},
							OnSave(){
								let cur;
								if(entry.hudLine){
									entry.hudLine.update(true);
									cur=entry;
									while(cur){
										cur=cur.upperEntry
										if(cur && cur.hudLine){
											cur.hudLine.update(false);
										}
									}
								}
							}
						});
					}
				}
			});
			
			self.init();
			/*}#1IM07M1IM1Create*/
		},
		/*#{1IM07M1IM1EndCSS*/
		/*}#1IM07M1IM1EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.init=async function(){
		/*#{1IM1DM7NS0Start*/
		let lPath,rPath;
		lPath=dataDoc.leftPath;
		rPath=dataDoc.rightPath;
		edLeftPath.text=lPath;
		edRightPath.text=rPath;
		if(lPath && rPath && (rPath!=="/") && (lPath!=="/")){
			self.listPath();
		}
		/*}#1IM1DM7NS0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.refresh=async function(silent){
		/*#{1IM4BUS7I0Start*/
		let lPath,rPath,lInfo,rInfo;
		lPath=edLeftPath.text;
		rPath=edRightPath.text;
		lInfo=await tabFS.getEntry(lPath);
		rInfo=await tabFS.getEntry(rPath);
		if(!lInfo || !lInfo.dir || lPath==="/"){
			if(!silent){
				window.alert((($ln==="CN")?(`左侧路径错误。`):/*EN*/(`Left path is wrong.`)));
			}
			return;
		}
		if(!rInfo || !rInfo.dir || rPath==="/"){
			if(!silent){
				window.alert((($ln==="CN")?(`右侧路径错误。`):/*EN*/(`Right path is wrong.`)));
			}
			return;
		}
		dataDoc.leftPath=lPath;
		dataDoc.rightPath=rPath;
		dataDoc.compathVO.leftPath=lPath;
		dataDoc.compathVO.rightPath=rPath;
		self.init();
		/*}#1IM4BUS7I0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.listPath=async function(){
		/*#{1IM08QNND0Start*/
		let list,entry;
		listBox.clear();
		leftPath=edLeftPath.text;
		rightPath=edRightPath.text;
		list=await self.readPath("");
		for(entry of list){
			listBox.addNode(entry,null);
		}
		/*}#1IM08QNND0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.readPath=async function(path){
		/*#{1IM0H2V7E0Start*/
		let lPath,rPath,leftList,rightList,list;
		let i,n,entryMap,item,name,entry;
		
		return await readCompDir(leftPath,rightPath,path,dataDoc.excludePathSet,dataDoc.excludeTypeSet);
		
		entryMap=new Map();
		lPath=pathLib.join(leftPath,path);
		rPath=pathLib.join(rightPath,path);
		leftList=await readPath(lPath);
		rightList=await readPath(rPath);
		n=leftList.length;
		for(i=0;i<n;i++){
			item=leftList[i];
			name=item.name;
			entry={name:name,nameNoCase:item.nameNoCase,path:pathLib.join(path,name),left:item,right:{path:pathLib.join(rPath,name)},dir:item.dir,leftPath:pathLib.join(lPath,name),rightPath:pathLib.join(rPath,name)};
			entryMap.set(name,entry);
		}
		n=rightList.length;
		for(i=0;i<n;i++){
			item=rightList[i];
			name=item.name;
			entry=entryMap.get(name);
			if(entry){
				entry.right=item;
			}else{
				entry={name:name,nameNoCase:item.nameNoCase,path:pathLib.join(path,name),left:{path:pathLib.join(lPath,name)},right:item,dir:item.dir,leftPath:pathLib.join(lPath,name),rightPath:pathLib.join(rPath,name)};
				entryMap.set(name,entry);
			}
			entryMap.set(name,entry);
		}
		list=Array.from(entryMap.values());
		//Sort:
		list.sort((a,b)=>{
			let name1,name2;
			if(a.dir && !b.dir){
				return -1;
			}
			if(b.dir && !a.dir){
				return 1;
			}
			name1=a.nameNoCase;
			name2=b.nameNoCase;
			if(a.disk && b.disk){
				if(name1[0]==="-" && name2[0]!=="-"){
					return 1;
				}else if(name2[0]==="-" && name1[0]!=="-"){
					return -1;
				}
			}
			return name1<name2?-1:(name1>name2?1:0);
		});
		return list;		
		/*}#1IM0H2V7E0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.copyToRight=async function(line){
		/*#{1IM08SM0J0Start*/
		if(line){
			let entry,lPath,rPath;
			entry=line.entry;
			lPath=entry.leftPath;
			rPath=entry.rightPath;
			await tabFS.copy(lPath,rPath,true);
			line.update(true);
		}
		/*}#1IM08SM0J0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.copyToLeft=async function(line){
		/*#{1IM08STA20Start*/
		if(line){
			let entry,lPath,rPath;
			entry=line.entry;
			lPath=entry.leftPath;
			rPath=entry.rightPath;
			await tabFS.copy(rPath,lPath,true);
			line.update(true);
		}
		/*}#1IM08STA20Start*/
	};
	//------------------------------------------------------------------------
	cssVO.delLeft=async function(){
		/*#{1IM08T79N0Start*/
		let node,line,entry,path;
		node=listBox.hotNode;
		if(!node){
			return;
		}
		line=node.hud;
		entry=node.nodeObj;
		path=entry.leftPath;
		if(entry.dir){
			//Delete dir:
			if(entry.subItems && entry.subItems.length>0){
				window.alert((($ln==="CN")?(`当前目录下还有两侧文件，不能删除。`):/*EN*/(`There are still two side files in the current directory, directory cannot be deleted.`)));
				return;
			}
			//Remove left dir:
			if(!window.confirm((($ln==="CN")?(`确认删除左边的目录${path}?`):/*EN*/(`Confirm deletion of the directory on the left: ${path}?`)))){
				return;
			}
			await tabFS.del(path);
			line.update(true);
			return;
		}
		if(!window.confirm((($ln==="CN")?(`确认删除左边的文件${path}?`):/*EN*/(`Confirm deletion of the file on the left: ${path}?`)))){
			return;
		}
		//Delete file:
		await tabFS.del(path);
		line.update(true);
		/*}#1IM08T79N0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.delRight=async function(){
		/*#{1IM08TJ180Start*/
		let node,line,entry,path;
		node=listBox.hotNode;
		if(!node){
			return;
		}
		line=node.hud;
		entry=node.nodeObj;
		path=entry.rightPath;
		if(entry.dir){
			//Delete dir:
			if(entry.subItems && entry.subItems.length>0){
				window.alert((($ln==="CN")?(`当前目录下还有两侧文件，不能删除。`):/*EN*/(`There are still two side files in the current directory, directory cannot be deleted.`)));
				return;
			}
			//Remove right dir:
			if(!window.confirm((($ln==="CN")?(`确认删除右边的目录${path}?`):/*EN*/(`Confirm deletion of the directory on the right: ${path}?`)))){
				return;
			}
			await tabFS.del(path);
			line.update(true);
			return;
		}
		if(!window.confirm((($ln==="CN")?(`确认删除右边的文件${path}?`):/*EN*/(`Confirm deletion of the file on the right: ${path}?`)))){
			return;
		}
		//Delete file:
		await tabFS.del(path);
		line.update(true);
		/*}#1IM08TJ180Start*/
	};
	//------------------------------------------------------------------------
	cssVO.removeEntryLine=async function(line){
		/*#{1IM4APRDF0Start*/
		let node,entry,upperEntry,subItems,idx;
		node=line.node;
		entry=node.nodeObj;
		upperEntry=entry.upperEntry;
		if(upperEntry){
			subItems=upperEntry.subItems;
			if(subItems){
				idx=subItems.indexOf(entry);
				if(idx>=0){
					subItems.splice(idx,1);
				}
			}
		}
		listBox.closeNode(node);
		listBox.removeNode(node);
		/*}#1IM4APRDF0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.openEditor=async function(){
		/*#{1IM08U0G90Start*/
		/*}#1IM08U0G90Start*/
	};
	//------------------------------------------------------------------------
	cssVO.expandDirNode=async function(node){
		/*#{1IM2DVCM30Start*/
		let entryObj,hud;
		entryObj=node.nodeObj;
		if(entryObj && entryObj.subItems && entryObj.subItems.length>0){
			listBox.openNode(node);
		}
		hud=node.hud;
		hud.setFace("expand");
		/*}#1IM2DVCM30Start*/
	};
	//------------------------------------------------------------------------
	cssVO.collapseDirNode=async function(node){
		/*#{1IM2E5NNO0Start*/
		let hud=node.hud;
		listBox.closeNode(node);
		hud.setFace("collapse");
		/*}#1IM2E5NNO0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.openLeftPath=async function(){
		/*#{1IM4J0EST0Start*/
		let path;
		path="/";
		path=await app.modalDlg("/@StdUI/ui/DlgFile.js",{
			mode:"open",
			title:(($ln==="CN")?("选择左侧路径"):/*EN*/("Choose Left Path")),
			path:"/",
			options:{dirOnly:1,preview:false},
		});
		if(path){
			edLeftPath.text=path;
			self.refresh(true);
		}
		/*}#1IM4J0EST0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.openRightPath=async function(){
		/*#{1IM4J0VBL0Start*/
		let path;
		path="/";
		path=await app.modalDlg("/@StdUI/ui/DlgFile.js",{
			mode:"open",
			title:(($ln==="CN")?("选择右侧路径"):/*EN*/("Choose Right Path")),
			path:"/",
			options:{dirOnly:1,preview:false},
		});
		if(path){
			edRightPath.text=path;
			self.refresh(true);
		}
		/*}#1IM4J0VBL0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.showMenu=async function(line,side,entry,node,event){
		/*#{1IM796BRS0Start*/
		let items,item;
		if(entry.dir){
			if(side==="Left"){
				items=[
					{text:node.isOpen?(($ln==="CN")?("关闭"):/*EN*/("Collapse")):(($ln==="CN")?("展开"):/*EN*/("Expand")),code:node.isOpen?"Collapse":"Expand"},
					{text:(($ln==="CN")?("排除"):/*EN*/("Exclute")),code:"Exclude"},
					{text:(($ln==="CN")?("删除"):/*EN*/("Delete")),code:"DeleteLeft"},
				];
			}else{
				items=[
					{text:node.isOpen?(($ln==="CN")?("关闭"):/*EN*/("Collapse")):(($ln==="CN")?("展开"):/*EN*/("Expand")),code:node.isOpen?"Collapse":"Expand"},
					{text:(($ln==="CN")?("排除"):/*EN*/("Exclute")),code:"Exclude"},
					{text:(($ln==="CN")?("删除"):/*EN*/("Delete")),code:"DeleteRight"},
				];
			}
		}else{
			if(side==="Left"){
				items=[
					{text:(($ln==="CN")?("复制到右边"):/*EN*/("Copy to right")),code:"CopyToRight"},
					{text:(($ln==="CN")?("比较变化"):/*EN*/("Edit diff")),code:"Diff"},
					{text:(($ln==="CN")?("排除"):/*EN*/("Exclute")),code:"Exclude"},
					{text:(($ln==="CN")?("删除"):/*EN*/("Delete")),code:"DeleteLeft"},
				];
			}else{
				items=[
					{text:(($ln==="CN")?("复制到左边"):/*EN*/("Copy to left")),code:"CopyToLeft"},
					{text:(($ln==="CN")?("比较变化"):/*EN*/("Edit diff")),code:"Diff"},
					{text:(($ln==="CN")?("排除"):/*EN*/("Exclute")),code:"Exclude"},
					{text:(($ln==="CN")?("删除"):/*EN*/("Delete")),code:"DeleteRight"},
				];
			}
		}
		item=await app.modalDlg("/@StdUI/ui/DlgMenu.js",{
			hud:side==="Left"?line.LeftLine.TxtName:line.RightLine.TxtName,
			items:items,w:150,event:event
		});
		if(!item){
			return;
		}
		switch(item.code){
			case "CopyToRight":
				self.copyToRight(line);
				return;
			case "CopyToLeft":
				self.copyToLeft(line);
				return;
			case "Diff":
				self.emitNotify("OpenLine");
				return;
			case "Exclude":{
				if(entry.dir){
					let exSet;
					if(!window.confirm((($ln==="CN")?(`确定要排除这个目录么？`):/*EN*/(`Are you sure you want to exclude this directory?`)))){
						return;
					}
					exSet=dataDoc.excludePathSet;
					if(!exSet){
						exSet=dataDoc.excludePathSet=new Set();
					}
					exSet.add(entry.path);
					self.removeEntryLine(line);
					dataDoc.compathChanged=true;
					dataDoc.emitNotify("Changed");
				}else{
					let ext,exSet;
					ext=pathLib.extname(entry.path);
					if(ext){
						items=[
							{text:`Exclude this file`,code:"File"},
							{text:`Exclude all "${ext}" files`,code:"Type"},
						];
						item=await app.modalDlg("/@StdUI/ui/DlgMenu.js",{
							hud:line,
							items:items,w:150,event:event
						});
						if(!item){
							return;
						}
					}else{
						item={code:"File"};
					}
					if(item.code==="File"){
						exSet=dataDoc.excludePathSet;
						if(!exSet){
							exSet=dataDoc.excludePathSet=new Set();
						}
						exSet.add(entry.path);
						self.removeEntryLine(line);
						dataDoc.compathChanged=true;
						dataDoc.emitNotify("Changed");
					}else{
						exSet=dataDoc.excludeTypeSet;
						if(!exSet){
							exSet=dataDoc.excludeTypeSet=new Set();
						}
						exSet.add(ext);
						self.refresh();
						dataDoc.compathChanged=true;
						dataDoc.emitNotify("Changed");
				}
				}
				return;
			}
			case "DeleteLeft":
				self.delLeft();
				return;
			case "DeleteRight":
				self.delRight();
				return;
			case "Collapse":
				self.emitNotify("OpenLine");
				return;
			case "Expand":
				self.emitNotify("OpenLine");
				return;
		}
		/*}#1IM796BRS0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.editCfg=async function(){
		/*#{1IM7U21FI0Start*/
		let dataCfg;
		dataCfg={
			exFile:[],exType:[]
		};
		if(dataDoc.excludePathSet){
			dataCfg.exFile=[...dataDoc.excludePathSet.values()];
		}
		if(dataDoc.excludeTypeSet){
			dataCfg.exType=[...dataDoc.excludeTypeSet.values()];
		}
		dataCfg=await app.modalDlg("/@StdUI/ui/DlgDataView.js",{
			hud:btnCfg,width:500,x:0,y:20,alignX:0,alignY:0,
			template:"CompathPrj",object:dataCfg,title:"Edit conifg"
		});
		if(dataCfg){
			dataDoc.excludePathSet=new Set(dataCfg.exFile);
			dataDoc.excludeTypeSet=new Set(dataCfg.exType);
			self.refresh();
			dataDoc.compathChanged=true;
			dataDoc.emitNotify("Changed");
		}
		/*}#1IM7U21FI0Start*/
	};
	/*#{1IM07M1IM1PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.applyCfg=function(opts){
	};
	
	//------------------------------------------------------------------------
	cssVO.setEditText=function(text,undo=true){
	};
	
	//------------------------------------------------------------------------
	cssVO.getEditText=function(slot){
		return "";
	};
	
	//------------------------------------------------------------------------
	cssVO.getEditVersion=function(){
		return 0;
	};
	
	//------------------------------------------------------------------------
	cssVO.focus=function(){
		//TODO: Reload?
		return 0;
	};
	
	//------------------------------------------------------------------------
	cssVO.blur=function(){
	};
	
	//------------------------------------------------------------------------
	cssVO.gotoLine=function(line){
	};
	
	//------------------------------------------------------------------------
	cssVO.getSelection=function(){
		return "";
	};
	
	//--------------------------------------------------------------------
	cssVO.replaceSelection=function(text,select){
	};
		
	//------------------------------------------------------------------------
	cssVO.getCursorPos=function(){
		return {line:0,ch:0};
	};
	
	//------------------------------------------------------------------------
	cssVO.getCursorIndex=function(){
		return 0;
	};
	
	//------------------------------------------------------------------------
	cssVO.getSelectionRange=function(){
		return [0,0];
	};
	
	//------------------------------------------------------------------------
	cssVO.handleShortcut=function(cmd){
		return false;
	};
	/*}#1IM07M1IM1PostCSSVO*/
	cssVO.constructor=UIComparePath;
	return cssVO;
};
/*#{1IM07M1IM1ExCodes*/
VFACT.appendCSS("/@codemirror/addon/merge.css");
UIComparePath.scoreDoc=function(doc){
	let path;
	path=doc.path.toLowerCase();
	if(path.endsWith(".compath")){
		return 100;
	}
	return 0;
};
AddOn.regAddOn("DocEditor","ComparePath",UIComparePath);
/*}#1IM07M1IM1ExCodes*/

//----------------------------------------------------------------------------
UIComparePath.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1IM07M1IM1PreAISpot*/
	/*}#1IM07M1IM1PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1IM07M1IM1PostAISpot*/
	/*}#1IM07M1IM1PostAISpot*/
	return exposeVO;
};

/*#{1IM07M1IM0EndDoc*/
/*}#1IM07M1IM0EndDoc*/

export default UIComparePath;
export{UIComparePath};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "UIView",
//	"jaxId": "1IM07M1IM0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1IM07M1IM2",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "800",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1IM07M1IM3",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1IM07M1IM4",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1IM07M1IM5",
//			"attrs": {
//				"app": {
//					"type": "auto",
//					"valText": ""
//				},
//				"mode": {
//					"type": "string",
//					"valText": ""
//				},
//				"codeText": {
//					"type": "string",
//					"valText": ""
//				},
//				"cfgVO": {
//					"type": "auto",
//					"valText": "{}"
//				},
//				"dataDoc": {
//					"type": "auto",
//					"valText": "null"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1IM07M1IM6",
//			"attrs": {
//				"cellDef": {
//					"type": "auto",
//					"valText": ""
//				},
//				"lineDef": {
//					"type": "auto",
//					"valText": ""
//				},
//				"leftPath": {
//					"type": "string",
//					"valText": ""
//				},
//				"rightPath": {
//					"type": "string",
//					"valText": ""
//				},
//				"sbarWidth": {
//					"type": "int",
//					"valText": "20"
//				}
//			}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1IM07M1IM7",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IM1DM7NS0",
//					"attrs": {
//						"id": "init",
//						"label": "New AI Seg",
//						"x": "85",
//						"y": "70",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IM1DMJ1P0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IM1DMJ1P1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IM1DMJ1P2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IM4BUS7I0",
//					"attrs": {
//						"id": "refresh",
//						"label": "New AI Seg",
//						"x": "345",
//						"y": "70",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IM4BVMPF0",
//							"attrs": {
//								"silent": {
//									"type": "bool",
//									"valText": "false"
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IM4BVMPF1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IM4BVMPF2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IM08QNND0",
//					"attrs": {
//						"id": "listPath",
//						"label": "New AI Seg",
//						"x": "90",
//						"y": "160",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IM08S9CP0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IM08S9CP1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IM08S9CP2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IM0H2V7E0",
//					"attrs": {
//						"id": "readPath",
//						"label": "New AI Seg",
//						"x": "345",
//						"y": "160",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IM0H4GD40",
//							"attrs": {
//								"path": {
//									"type": "string",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IM0H4GD41",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IM0H4GD42",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IM08SM0J0",
//					"attrs": {
//						"id": "copyToRight",
//						"label": "New AI Seg",
//						"x": "90",
//						"y": "240",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IM08TUQC0",
//							"attrs": {
//								"line": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IM08TUQC1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IM08TUQC2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IM08STA20",
//					"attrs": {
//						"id": "copyToLeft",
//						"label": "New AI Seg",
//						"x": "345",
//						"y": "240",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IM08TUQC3",
//							"attrs": {
//								"line": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IM08TUQC4",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IM08TUQC5",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IM08T79N0",
//					"attrs": {
//						"id": "delLeft",
//						"label": "New AI Seg",
//						"x": "90",
//						"y": "330",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IM08TFPG0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IM08TFPG1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IM08TFPG2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IM08TJ180",
//					"attrs": {
//						"id": "delRight",
//						"label": "New AI Seg",
//						"x": "345",
//						"y": "330",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IM08TUQC6",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IM08TUQC7",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IM08TUQC8",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IM4APRDF0",
//					"attrs": {
//						"id": "removeEntryLine",
//						"label": "New AI Seg",
//						"x": "575",
//						"y": "330",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IM4AQO070",
//							"attrs": {
//								"line": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IM4AQO071",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IM4AQO072",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IM08U0G90",
//					"attrs": {
//						"id": "openEditor",
//						"label": "New AI Seg",
//						"x": "90",
//						"y": "435",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IM08U6MH0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IM08U6MH1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IM08U6MH2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IM2DVCM30",
//					"attrs": {
//						"id": "expandDirNode",
//						"label": "New AI Seg",
//						"x": "90",
//						"y": "520",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IM2DVMDB0",
//							"attrs": {
//								"node": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IM2DVMDB1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IM2DVMDB2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IM2E5NNO0",
//					"attrs": {
//						"id": "collapseDirNode",
//						"label": "New AI Seg",
//						"x": "345",
//						"y": "520",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IM2E60DQ0",
//							"attrs": {
//								"node": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IM2E60DQ1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IM2E60DQ2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IM4J0EST0",
//					"attrs": {
//						"id": "openLeftPath",
//						"label": "New AI Seg",
//						"x": "575",
//						"y": "70",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IM4J1E4S0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IM4J1E4S1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IM4J1E4S2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IM4J0VBL0",
//					"attrs": {
//						"id": "openRightPath",
//						"label": "New AI Seg",
//						"x": "855",
//						"y": "70",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IM4J1E4S3",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IM4J1E4S4",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IM4J1E4S5",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IM796BRS0",
//					"attrs": {
//						"id": "showMenu",
//						"label": "New AI Seg",
//						"x": "335",
//						"y": "440",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IM7988GO0",
//							"attrs": {
//								"line": {
//									"type": "auto",
//									"valText": ""
//								},
//								"side": {
//									"type": "string",
//									"valText": ""
//								},
//								"entry": {
//									"type": "auto",
//									"valText": ""
//								},
//								"node": {
//									"type": "auto",
//									"valText": ""
//								},
//								"event": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IM7988GP0",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IM7988GP1",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1IM7U21FI0",
//					"attrs": {
//						"id": "editCfg",
//						"label": "New AI Seg",
//						"x": "575",
//						"y": "440",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1IM7U398A0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1IM7U398A1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1IM7U398A2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				}
//			]
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1IM07M1IM8",
//			"attrs": {}
//		},
//		"mockupStates": {
//			"jaxId": "1IM07M1IM9",
//			"attrs": {}
//		},
//		"exposeToAI": "true",
//		"descAI": "",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "view",
//			"jaxId": "1IM07M1IM1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1IM07M1IM10",
//					"attrs": {
//						"type": "view",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "100%",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": ""
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1IM07SGPB0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IM07SGPB1",
//									"attrs": {
//										"type": "box",
//										"id": "BoxPath",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "#[0,sbarWidth,0,0]",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"body\"]",
//										"border": "[0,0,1,0]",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor[\"fontBodyLit\"]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"contentLayout": "Flex X",
//										"itemsAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1IM07U1NA0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IM07UCNV0",
//													"attrs": {
//														"type": "hud",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "50%-1",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "[0,5,0,5]",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex X",
//														"itemsAlign": "Center",
//														"subAlign": "Start"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1IM081BV50",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1IM082VAO0",
//																	"attrs": {
//																		"style": "\"front\"",
//																		"w": "24",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/folder.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1IM082VAO1",
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"front\",24,0,appCfg.sharedAssets+\"/folder.svg\",null)",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IM082VAO2",
//																	"attrs": {}
//																},
//																"functions": {
//																	"jaxId": "1IM082VAO3",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1IM4J1VJI0",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1IM4J1VJI1",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": "1IM4J0EST0"
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1IM082VAO4",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1IM082VAO5",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "edit",
//															"jaxId": "1IM07UR7S0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IM083NIU0",
//																	"attrs": {
//																		"type": "edit",
//																		"id": "EdLeftPath",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%-99",
//																		"h": "20",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[0,0,0,5]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"inputType": "Text",
//																		"text": "",
//																		"placeHolder": "",
//																		"color": "[0,0,0]",
//																		"bgColor": "[255,255,255,1.00]",
//																		"font": "",
//																		"fontSize": "16",
//																		"outline": "0",
//																		"border": "[0,0,1,0]",
//																		"borderStyle": "Solid",
//																		"borderColor": "[0,0,0,1.00]",
//																		"corner": "0",
//																		"selectOnFocus": "true",
//																		"spellCheck": "true"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IM083NIU1",
//																	"attrs": {}
//																},
//																"functions": {
//																	"jaxId": "1IM083NIU2",
//																	"attrs": {
//																		"OnKeyDown": {
//																			"type": "fixedFunc",
//																			"jaxId": "1IM4C2OU20",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1IM4C2OUA0",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1IM083NIU3",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "true",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1IM7MGM970",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IM7MHQA20",
//																	"attrs": {
//																		"type": "hud",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "5",
//																		"h": "100%",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"flex": "true"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IM7MHQA21",
//																	"attrs": {}
//																},
//																"functions": {
//																	"jaxId": "1IM7MHQA22",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1IM7MHQA23",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"exposeContainer": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1IM7MH9JP0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1IM7MHQA24",
//																	"attrs": {
//																		"style": "\"front\"",
//																		"w": "24",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/settings.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1IM7MHQA25",
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"front\",24,0,appCfg.sharedAssets+\"/settings.svg\",null)",
//																		"id": "BtnCfg",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IM7MHQA26",
//																	"attrs": {}
//																},
//																"functions": {
//																	"jaxId": "1IM7MHQA27",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1IM7URSMT0",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1IM7URSMT1",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": "1IM7U21FI0"
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1IM7MHQA28",
//																	"attrs": {
//																		"tip": {
//																			"type": "string",
//																			"valText": "规则设置",
//																			"localize": {
//																				"EN": "Rule Settings",
//																				"CN": "规则设置"
//																			},
//																			"localizable": true
//																		}
//																	}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1IM7MHQA29",
//																	"attrs": {}
//																}
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1IM07UCNV1",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1IM07UCNV2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IM07UCNV3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1IM085G8M0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IM087N4I0",
//													"attrs": {
//														"type": "box",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "1",
//														"h": "90%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "#cfgColor[\"fontBodyLit\"]",
//														"border": "0",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IM087N4I1",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1IM087N4I2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IM087N4I3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1IM07UDR10",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IM07UDR11",
//													"attrs": {
//														"type": "hud",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "50%",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "[0,5,0,5]",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex X",
//														"itemsWrap": "No Wrap",
//														"itemsAlign": "Center",
//														"subAlign": "Start"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1IM08394V0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1IM08394V1",
//																	"attrs": {
//																		"style": "\"front\"",
//																		"w": "24",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/folder.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1IM08394V2",
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"front\",24,0,appCfg.sharedAssets+\"/folder.svg\",null)",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IM0839500",
//																	"attrs": {}
//																},
//																"functions": {
//																	"jaxId": "1IM0839501",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1IM4J1VJI2",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1IM4J1VJI3",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": "1IM4J0VBL0"
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1IM0839502",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1IM0839503",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "edit",
//															"jaxId": "1IM083O4A0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IM083O4A1",
//																	"attrs": {
//																		"type": "edit",
//																		"id": "EdRightPath",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%-100",
//																		"h": "20",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[0,0,0,5]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"inputType": "Text",
//																		"text": "",
//																		"placeHolder": "",
//																		"color": "[0,0,0]",
//																		"bgColor": "[255,255,255,1.00]",
//																		"font": "",
//																		"fontSize": "16",
//																		"outline": "0",
//																		"border": "[0,0,1,0]",
//																		"borderStyle": "Solid",
//																		"borderColor": "[0,0,0,1.00]",
//																		"corner": "0",
//																		"selectOnFocus": "true",
//																		"spellCheck": "true"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IM083O4A2",
//																	"attrs": {}
//																},
//																"functions": {
//																	"jaxId": "1IM083O4A3",
//																	"attrs": {
//																		"OnKeyDown": {
//																			"type": "fixedFunc",
//																			"jaxId": "1IM4C2OU21",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1IM4C2OUA1",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1IM083O4A4",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true"
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1IM07UDR12",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1IM07UDR13",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IM07UDR14",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1IM07SGPC0",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1IM07SGPC1",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IM07SGPC2",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1IM07ML6U0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IM07OQO00",
//									"attrs": {
//										"type": "box",
//										"id": "BoxHeader",
//										"position": "Absolute",
//										"x": "0",
//										"y": "30",
//										"w": "100%",
//										"h": "20",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "#[0,sbarWidth,0,0]",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"footer\"]",
//										"border": "[0,0,1,0]",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor[\"fontBodySub\"]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"contentLayout": "Flex X",
//										"itemsAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1IM08F44I0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IM08FV6C0",
//													"attrs": {
//														"type": "hud",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "50%-15",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[0,30,0,0]",
//														"padding": "[0,0,0,5]",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex XR",
//														"itemsAlign": "Center"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1IM08FJAT0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1IM08FJAT1",
//																	"attrs": {
//																		"style": "\"front\"",
//																		"w": "20",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/arrowright.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1IM08FJAU0",
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"front\",20,0,appCfg.sharedAssets+\"/arrowright.svg\",null)",
//																		"id": "BtnCopyToRight",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"margin": "[0,5,0,5]",
//																		"enable": "false"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IM08FJAU1",
//																	"attrs": {}
//																},
//																"functions": {
//																	"jaxId": "1IM08FJAU2",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1IM08FJAU3",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1IM08FJAU4",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1IM08HHR80",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1IM08HHR81",
//																	"attrs": {
//																		"style": "\"front\"",
//																		"w": "20",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/trash.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1IM08HHR82",
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"front\",20,0,appCfg.sharedAssets+\"/trash.svg\",null)",
//																		"id": "BtnDelLeft",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"margin": "[0,5,0,5]"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IM08HHR83",
//																	"attrs": {}
//																},
//																"functions": {
//																	"jaxId": "1IM08HHR84",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1IM49D2VS0",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1IM49D2VS1",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": "1IM08T79N0"
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1IM08HHR85",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1IM08HHR86",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1IM2RCH5N0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IM2REIJC0",
//																	"attrs": {
//																		"type": "hud",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "10",
//																		"h": "100%",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"flex": "true"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IM2REIJC1",
//																	"attrs": {}
//																},
//																"functions": {
//																	"jaxId": "1IM2REIJC2",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1IM2REIJC3",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false",
//																"exposeContainer": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1IM2RDC4L0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1IM2REIJC4",
//																	"attrs": {
//																		"style": "\"front\"",
//																		"w": "20",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/undo.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1IM2REIJC5",
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"front\",20,0,appCfg.sharedAssets+\"/undo.svg\",null)",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IM2REIJC6",
//																	"attrs": {}
//																},
//																"functions": {
//																	"jaxId": "1IM2REIJC7",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1IM4C090I0",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1IM4C090I1",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": "1IM4BUS7I0"
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1IM2REIJC8",
//																	"attrs": {
//																		"tip": {
//																			"type": "string",
//																			"valText": "刷新",
//																			"localize": {
//																				"EN": "Refresh",
//																				"CN": "刷新"
//																			},
//																			"localizable": true
//																		}
//																	}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1IM2REIJC9",
//																	"attrs": {}
//																}
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1IM08FV6C1",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1IM08FV6C2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IM08FV6C3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1IM08G01V0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IM08G01V1",
//													"attrs": {
//														"type": "hud",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "50%-15",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex X",
//														"itemsAlign": "Center"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1IM08G0200",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1IM08G0201",
//																	"attrs": {
//																		"style": "\"front\"",
//																		"w": "20",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/arrowleft.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1IM08G0202",
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"front\",20,0,appCfg.sharedAssets+\"/arrowleft.svg\",null)",
//																		"id": "BtnCopyToLeft",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"margin": "[0,5,0,5]",
//																		"enable": "false"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IM08G0203",
//																	"attrs": {}
//																},
//																"functions": {
//																	"jaxId": "1IM08G0204",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1IM08G0205",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1IM08G0206",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1IM08I5AL0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1IM08I5AL1",
//																	"attrs": {
//																		"style": "\"front\"",
//																		"w": "20",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/trash.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1IM08I5AL2",
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"front\",20,0,appCfg.sharedAssets+\"/trash.svg\",null)",
//																		"id": "BtnDelLeft",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"margin": "[0,5,0,5]"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IM08I5AL3",
//																	"attrs": {}
//																},
//																"functions": {
//																	"jaxId": "1IM08I5AL4",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1IM49D2VS2",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1IM49D2VS3",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": "1IM08TJ180"
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1IM08I5AL5",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1IM08I5AL6",
//																	"attrs": {}
//																}
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1IM08G0207",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1IM08G0208",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IM08G0209",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1IM07OQO01",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1IM07OQO02",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IM07OQO03",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "TreeBox",
//							"jaxId": "1IM07P46H0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IM087N4I4",
//									"attrs": {
//										"type": "tree",
//										"id": "ListBox",
//										"position": "Absolute",
//										"x": "0",
//										"y": "50",
//										"w": "100%",
//										"h": "100%-50",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"contentLayout": "flex-y",
//										"clip": "Scroll Y",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": ""
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1IM087N4I5",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1IM087N4I6",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IM087N4I7",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "true",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1IM07M1IM11",
//					"attrs": {}
//				},
//				"functions": {
//					"jaxId": "1IM07M1IM12",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1IM07M1IM13",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1IM07M1IM14",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}