//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
import {BtnCheck} from "/@StdUI/ui/BtnCheck.js";
import {BtnText} from "/@StdUI/ui/BtnText.js";
/*#{1G9EKS4E90StartDoc*/
import {makeObjEventEmitter,makeNotify} from "/@events";
import {DlgAICoder} from "./DlgAICoder.js";
let initEnv;
let envInited=0;
let CodeMirror=window.CodeMirror;

let clearSearch=null;
let startSearch=null;
let doSearch=null;
let getSearchState=null;
let findNext=null;
let replace=null;
let equalCursorPos=null;
let cmp=null;
let getSearchCursor=null;
/*}#1G9EKS4E90StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let DocEditor=function(app,mod,codeText,cfgVO,dataDoc){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1G9EKS4E97LocalVals*/
	let cm=null;
	let cmDoc=null;
	let docMode="";
	let findText="";
	let editConfig=null;
	let curDlg=null;
	let aboutRefresh=0;
	let targetLine=-1;
	let initPms=null;
	let setupPms=null;
	let cmOptions=null;
	/*}#1G9EKS4E97LocalVals*/
	
	/*#{1G9EKS4E97PreState*/
	if(!envInited){
		initEnv();
	}
	let appPrj=app.prj;
	/*}#1G9EKS4E97PreState*/
	/*#{1G9EKS4E97PostState*/
	/*}#1G9EKS4E97PostState*/
	cssVO={
		"hash":"1G9EKS4E97",nameHost:true,
		"type":"hud","x":0,"y":0,"w":"FW","h":"FH","autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
		children:[
			{
				"hash":"1G9ELAPE50",
				"type":"hud","id":"BoxEdit","x":0,"y":0,"w":"FW","h":"FH","autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
			},
			{
				"hash":"1G9ELBEE50",
				"type":"box","id":"BoxDlgSearch","x":0,"y":0,"w":"FW","h":60,"autoLayout":true,"display":0,"overflow":1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"background":cfgColor.tool,"border":[0,0,1,0],"borderColor":cfgColor.fontToolLit,
				children:[
					{
						"hash":"1G9ELDUOB0",
						"type":"hud","id":"BoxFind","x":0,"y":0,"w":"FW","h":30,"autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
						children:[
							{
								"hash":"1G9ELF1DR0",
								"type":"edit","id":"EdFind","position":"relative","x":0,"y":"FH/2","w":250,"h":24,"anchorY":1,"margin":[0,3,0,5],"minW":"","minH":"","maxW":"",
								"maxH":"","styleClass":"","placeHolder":"Text to find","color":[0,0,0],"fontSize":txtSize.smallMid,"outline":0,"border":1,
								/*#{1G9ELF1DR0Codes*/
								OnKeyDown(evt){
									if(evt.code==="KeyG" && (evt.ctrlKey||evt.metaKey)){
										if(evt.shiftKey){
											self.findPre();
											return 1;
										}else{
											self.findNext();
											return 1;
										}
									}
								},
								OnUpdate(){
									self.startFind(false);
								},
								OnCancel(){
									self.closeDlg();
								},
								OnInput(){
									self.checkReplaceBtns();
								}
								/*}#1G9ELF1DR0Codes*/
							},
							{
								"hash":"1G9EM9MA30",
								"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/arrowup.svg",null),"position":"relative","x":0,"y":"FH/2","anchorY":1,"padding":2,
								/*#{1G9EM9MA30Codes*/
								OnClick(){
									self.findPre();
								}
								/*}#1G9EM9MA30Codes*/
							},
							{
								"hash":"1G9EMBOVT0",
								"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/arrowdown.svg",null),"position":"relative","x":0,"y":"FH/2","anchorY":1,"padding":2,
								/*#{1G9EMBOVT0Codes*/
								OnClick(){
									self.findNext();
								}
								/*}#1G9EMBOVT0Codes*/
							},
							{
								"hash":"1G9EMCIUV0",
								"type":BtnCheck(20,"",false,false),"id":"BtnCase","position":"relative","x":0,"y":5,"checked":false,"padding":2,
								/*#{1G9EMCIUV0Codes*/
								OnCheck(){
									self.startFind();
								}
								/*}#1G9EMCIUV0Codes*/
							},
							{
								"hash":"1G9EME6T70",
								"type":"text","position":"relative","x":0,"y":0,"w":100,"h":"FH","margin":[0,5,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":[0,0,0],
								"text":"Case","fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,"autoW":true,
							},
							{
								"hash":"1G9EMGCFF0",
								"type":BtnCheck(20,"",false,false),"id":"BtnWords","position":"relative","x":0,"y":5,"checked":false,"padding":2,
								/*#{1G9EMGCFF0Codes*/
								OnCheck(){
									self.startFind();
								}
								/*}#1G9EMGCFF0Codes*/
							},
							{
								"hash":"1G9EMGFDM0",
								"type":"text","position":"relative","x":0,"y":0,"w":100,"h":"FH","margin":[0,5,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":[0,0,0],
								"text":"Words","fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,"autoW":true,
							},
							{
								"hash":"1G9EMIEQA0",
								"type":"box","position":"relative","x":0,"y":5,"w":1,"h":20,"margin":[0,3,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.fontToolLit,
							},
							{
								"hash":"1G9EMJMKR0",
								"type":BtnCheck(20,"",false,false),"id":"BtnRegex","position":"relative","x":0,"y":5,"checked":false,"padding":2,
								/*#{1G9EMJMKR0Codes*/
								OnCheck(){
									self.startFind();
								}
								/*}#1G9EMJMKR0Codes*/
							},
							{
								"hash":"1G9EMK76J0",
								"type":"text","position":"relative","x":0,"y":0,"w":100,"h":"FH","margin":[0,10,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":[0,0,0],
								"text":"Regex","fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,"autoW":true,
							},
							{
								"hash":"1G9EMLQSQ0",
								"type":BtnText("",80,22,"Replace",false,""),"position":"relative","x":0,"y":4,"text":"Replace","corner":3,
								/*#{1G9EMLQSQ0Codes*/
								OnClick(){
									self.showFace("replace");
								}
								/*}#1G9EMLQSQ0Codes*/
							}
						],
					},
					{
						"hash":"1G9EMR09O0",
						"type":"hud","id":"BoxReplace","x":0,"y":30,"w":"FW","h":30,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
						children:[
							{
								"hash":"1G9EMS1PC0",
								"type":"edit","id":"EdReplace","position":"relative","x":0,"y":"FH/2","w":250,"h":24,"anchorY":1,"margin":[0,5,0,5],"minW":"","minH":"","maxW":"",
								"maxH":"","styleClass":"","placeHolder":"Text to replace","color":[0,0,0],"fontSize":txtSize.smallMid,"outline":0,"border":1,
								/*#{1G9EMS1PC0Codes*/
								OnInput(){
									self.checkReplaceBtns();
								}
								/*}#1G9EMS1PC0Codes*/
							},
							{
								"hash":"1G9EMSK160",
								"type":BtnText("",80,22,"Replace",false,""),"id":"BtnReplace","position":"relative","x":0,"y":4,"text":"Replace","margin":[0,5,0,0],"corner":3,
								/*#{1G9EMSK160Codes*/
								OnClick(){
									self.replace();
								}
								/*}#1G9EMSK160Codes*/
							},
							{
								"hash":"1G9EMT4OU0",
								"type":BtnText("warning",80,22,"Replace",false,""),"id":"BtnReplaceAll","position":"relative","x":0,"y":4,"text":"All","margin":[0,5,0,0],"corner":3,
								/*#{1G9EMT4OU0Codes*/
								OnClick(){
									self.replaceAll();
								}
								/*}#1G9EMT4OU0Codes*/
							},
							{
								"hash":"1G9EMUCLH0",
								"type":BtnCheck(20,"",false,false),"id":"BtnRange","position":"relative","x":0,"y":5,"checked":false,"padding":2,
								/*#{1G9EMUCLH0Codes*/
								/*}#1G9EMUCLH0Codes*/
							},
							{
								"hash":"1G9EMV75L0",
								"type":"text","position":"relative","x":0,"y":0,"w":100,"h":"FH","margin":[0,10,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":[0,0,0],
								"text":"In selection","fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,"autoW":true,
							},
							{
								"hash":"1IB22TBN40",
								"type":BtnIcon("front",20,0,appCfg.sharedAssets+"/close.svg",null),"position":"relative","x":0,"y":"50%","autoLayout":true,"padding":1,"anchorY":1,
								/*#{1IB22TBN40Codes*/
								OnClick(){
									self.showFace("find");
								}
								/*}#1IB22TBN40Codes*/
							}
						],
					},
					{
						"hash":"1G9EMO7PA0",
						"type":BtnIcon("front",20,0,appCfg.sharedAssets+"/close.svg",null),"x":"FW-25","y":5,"autoLayout":true,"padding":1,
						/*#{1G9EMO7PA0Codes*/
						OnClick(){
							self.closeDlg();
						}
						/*}#1G9EMO7PA0Codes*/
					}
				],
			}
		],
		/*#{1G9EKS4E97ExtraCSS*/
		app:app,
		/*}#1G9EKS4E97ExtraCSS*/
		faces:{
			"nodlg":{
				/*BoxEdit*/"#1G9ELAPE50":{
					"y":0,"h":"FH"
				},
				/*BoxDlgSearch*/"#1G9ELBEE50":{
					"display":0
				},
				/*#{1G9EN206M0Code*/
				$(){
					curDlg=0;
					self.emit("DialogOff");
				}
				/*}#1G9EN206M0Code*/
			},"find":{
				/*BoxEdit*/"#1G9ELAPE50":{
					"y":30,"h":"FH-30"
				},
				/*BoxDlgSearch*/"#1G9ELBEE50":{
					"h":30,"display":1
				},
				"#1G9EMLQSQ0":{
					"display":1
				},
				/*#{1G9EN28FS0Code*/
				$(){
					curDlg="Find";
					self.emit("DialogOn",30);
				}
				/*}#1G9EN28FS0Code*/
			},"replace":{
				/*BoxEdit*/"#1G9ELAPE50":{
					"y":60,"h":"FH-60"
				},
				/*BoxDlgSearch*/"#1G9ELBEE50":{
					"display":1,"h":60
				},
				"#1G9EMLQSQ0":{
					"display":0
				},
				/*#{1G9EN2D1R0Code*/
				$(){
					curDlg="Replace";
					self.emit("DialogOn",60);
				}
				/*}#1G9EN2D1R0Code*/
			}
		},
		OnCreate:function(){
			self=this;
			
			/*#{1G9EKS4E97Create*/
			self.dataDoc=dataDoc;
			setupPms=self.setup();
			makeNotify(self);
			makeObjEventEmitter(self);
			/*}#1G9EKS4E97Create*/
		},
		/*#{1G9EKS4E97EndCSS*/
		/*}#1G9EKS4E97EndCSS*/
	};
	/*#{1G9EKS4E97PostCSSVO*/
	//--------------------------------------------------------------------
	cssVO.getEditMode=function(){
		return "Code";
	};
	
	//************************************************************************
	//Editor related:
	//************************************************************************
	{
		let hasHint=0;
		let jsHint=0;
		//--------------------------------------------------------------------
		cssVO.setup=async function(){
			let mode,wrap,darkTheme;
			docMode=mod;
			wrap=false;
			editConfig=cfgVO;
			switch(docMode){
				case "js":
				case "mjs":
				case ".js":
				case ".mjs":
				case "javascript":
					mode="javascript";
					await VFACT.appendScript("/@codemirror/mode/javascript.js");
					await VFACT.appendCSS("/@codemirror/mode/javascript.css");
					hasHint=1;
					jsHint=1;
					break;
				case "htm":
				case "html":
				case ".htm":
				case ".html":
					mode="text/html";
					await VFACT.appendCSS("/@codemirror/mode/javascript.css");
	
					await VFACT.appendScript("/@codemirror/mode/css.js");
					await VFACT.appendScript("/@codemirror/mode/javascript.js");
					await VFACT.appendScript("/@codemirror/mode/xml.js");
					await VFACT.appendScript("/@codemirror/mode/htmlmixed.js");
					break;
				case "markdown":
				case "md":
				case ".md":
					wrap=true;
					mode="text/x-markdown";
					await VFACT.appendScript("/@codemirror/mode/markdown.js");
					break;
				case "json":
				case ".json":
					mode={name: "javascript", json: true};
					await VFACT.appendCSS("/@codemirror/mode/javascript.css");
					await VFACT.appendScript("/@codemirror/mode/javascript.js");
					break;
				case "css":
				case ".css":
					mode={name: "css"};
					await VFACT.appendScript("/@codemirror/mode/css.js");
					break;
				case "jsx":
				case ".jsx":
					mode="text/jsx";
					await VFACT.appendScript("/@codemirror/mode/javascript.js");
					await VFACT.appendCSS("/@codemirror/mode/javascript.css");
					await VFACT.appendScript("/@codemirror/mode/xml.js");
					await VFACT.appendScript("/@codemirror/mode/jsx.js");
					break;
				case ".c":
				case ".cpp":
				case ".h":
				case ".hpp":
				case ".c":
				case ".cpp":
				case ".h":
				case ".hpp":
					mode="text/x-c++src";
					await VFACT.appendScript("/@codemirror/mode/clike.js");
					break;
				case ".java":
					mode="text/x-java";
					await VFACT.appendScript("/@codemirror/mode/clike.js");
					break;
				case ".py":
					mode="text/x-python";
					mode="python";
					await VFACT.appendScript("/@codemirror/mode/python.js");
					break;
				default:
					mode="text";
					break;
			}
			darkTheme="blackboard";
			if(appCfg.darkMode){
				await VFACT.appendCSS(`/@tabedit/theme/${darkTheme}.css`);
			}
			self.docMode=docMode=mode;
			cmDoc=this.cmDoc=CodeMirror.Doc(codeText,mode);
			cmOptions={
				value: "",
				mode: docMode,
				indentUnit: editConfig["IndentSize"]||4,
				indentWithTabs: editConfig["UseTab"],
				smartIndent:editConfig["AutoIndent"],
				tabSize: editConfig["TabSize"]||4,
				lineWrapping:wrap,
				lineNumbers: true,
				foldGutter: true,
				gutters: ["CodeMirror-linenumbers", "CodeMirror-foldgutter"],
				fixedGutter: this.w>=500?true:false,
				rulers: [{color: "#CCC", column: 78, lineStyle: "dashed"}],
				styleActiveLine: true,
				extraKeys: {},
			};
			if(appCfg.darkMode){
				cmOptions.theme=darkTheme;
			}
			if(hasHint){
				cmOptions.extraKeys["Ctrl-Space"]="autocomplete";
			}
			if(dataDoc){
				dataDoc.resetEditorVersion(self);
			}
			cmDoc.on("change",()=>{});
		};
		
		//--------------------------------------------------------------------
		cssVO.init=async function(){
			if(cm){
				throw "Already inited";
			}
			await setupPms;
			cm=this.cm = CodeMirror(self.BoxEdit.webObj, cmOptions);
			cm.setSize("100%","100%");
			cm.swapDoc(cmDoc);
			cm.on("focus", this.OnCMFocus.bind(this));
			cm.on("blur", this.OnCMBlur.bind(this));
			cm.on("input", this.OnCMInput.bind(this));
			cm.on("changes", this.OnCMChanges.bind(this));
			cm.on("cursorActivity", this.OnCMCursorAct.bind(this));
			cm.uiCodeEditor=this;
			if(targetLine>=0||typeof(targetLine)==="string"){
				self.gotoLine(targetLine);
			}
			if(editConfig.lockCodySegs){
				self.lockCodySegs();
			}
			if(jsHint){
				cm.on("change", this.OnCMChangeJSHint.bind(this));
			}
			//Emit event
			this.emit("InitDone");
			this.emitNotify("InitDone");
		};
		
		//--------------------------------------------------------------------
		cssVO.applyCfg=function(opts){
			opts=opts||editConfig;
			if(cm){
				cm.setOption("indentUnit",opts["IndentSize"]);		
				cm.setOption("tabSize",opts["TabSize"]);		
				cm.setOption("indentWithTabs",opts["UseTab"]);
			}
		};
	
		//--------------------------------------------------------------------
		cssVO.setEditText=function(text,undo=true){
			let sinfo,cpos,hpos,topLineNumber;
			if(codeText===text){
				return;
			}
			codeText=text;
			if(cm){
				sinfo=cm.getScrollInfo();
				topLineNumber = cm.lineAtHeight(sinfo.top, "local");
			}
			if(cmDoc){
				cpos=cmDoc.getCursor();
				if(undo){
					cmDoc.setValue(codeText);
				}else{
					cmDoc.setValueNoUndo(codeText);
				}
				self.emit("DocReplace");
				if(editConfig.lockCodySegs){
					let hst=cmDoc.getHistory();
					self.lockCodySegs();
					//Restore history
					cmDoc.setHistory(hst);
				}
				cmDoc.setCursor(cpos);
			}
			if(cm){
				cm.scrollTo(sinfo.left,sinfo.top);
				if(topLineNumber>=0){
					let newTopLine,dline;
					newTopLine = cm.lineAtHeight(sinfo.top, "local");
					dline=newTopLine-topLineNumber;
					if(dline<-10 || dline>10){
						let topPosition = cm.heightAtLine(topLineNumber, "local");
						cm.scrollTo(sinfo.left,topPosition);
					}
				}
				if(!cm.hasFocus()){
					aboutRefresh=1;
				}
			}
		};
	
		//--------------------------------------------------------------------
		cssVO.getEditText=function(){
			if(cmDoc){
				codeText=cmDoc.getValue();
			}
			return codeText;
		};
	
		//--------------------------------------------------------------------
		cssVO.getSelection=function(){
			if(cmDoc){
				return cmDoc.getSelection();
			}
			return "";
		};
		
		//--------------------------------------------------------------------
		cssVO.replaceSelection=function(text,select){
			if(cmDoc){
				cmDoc.replaceSelection(text,select);
			}
		};
		
		//--------------------------------------------------------------------
		cssVO.getCursorPos=function(){
			if(!cmDoc){
				return {line:0,ch:0};
			}
			return cmDoc.getCursor();
		};
	
		//--------------------------------------------------------------------
		cssVO.getCursorIndex=function(){
			if(!cmDoc){
				return 0;
			}
			return cmDoc.indexFromPos(cmDoc.getCursor());
		};
		
		//--------------------------------------------------------------------
		cssVO.getSelectionRange=function(){
			let list,range,p1,p2;
			if(!cmDoc){
				return null;
			}
			if(!cmDoc.somethingSelected()){
				return null;
			}
			list=cmDoc.listSelections();
			range=list[0];
			p1=cmDoc.indexFromPos(range.anchor);
			p2=cmDoc.indexFromPos(range.head);
			return [p1<p2?p1:p2,p1>p2?p1:p2];
		};
	
		//--------------------------------------------------------------------
		cssVO.getEditVersion=function(){
			if(!cmDoc){
				return 0;
			}
			return cmDoc.changeGeneration();
		};
		
		//--------------------------------------------------------------------
		cssVO.clearHistory=function(){
			if(!cmDoc){
				return 0;
			}
			return cmDoc.clearHistory();
		};
		
		//--------------------------------------------------------------------
		cssVO.focus=function(){
			if(cm){
				cm.focus();
				if(aboutRefresh){
					let info;
					info=cm.getScrollInfo();
					cm.refresh();
					cm.scrollTo(info.left,info.top);
					aboutRefresh=0;
				}
			}else{
				if(!initPms){
					initPms=self.init();
				}
				initPms.then(()=>{
					if(cm){
						cm.focus();
					}
				});
			}
		};
	
		//--------------------------------------------------------------------
		cssVO.blur=function(){
			if(cm){
				cm.blur();
			}
			if(app.aiChat){
				app.aiChat.unregisterHandler(self);
			}
		};
		
		//--------------------------------------------------------------------
		cssVO.gotoLine=function(line){
			if(cmDoc && cm){
				if(line>=0){
					cmDoc.setCursor({line:line-1,ch:0});
					cm.scrollIntoView({line:line-1,ch:0},150);
					targetLine=-1;
				}else if(typeof(line)==="string"){
					return self.gotoMarkLine(line);
				}
			}else{
				targetLine=line;
				//Editor is not ready...
			}
		};
		
		//--------------------------------------------------------------------
		cssVO.gotoMarkLine=function(mark){
			let i,n,line;
			if(!cmDoc)
				return;
			n=cmDoc.lineCount();
			FindLine:{
				for(i=0;i<n;i++){
					line=cmDoc.getLine(i);
					if(line.indexOf(mark)>=0){
						break FindLine;
					}
				}
				return false;
			}
			cmDoc.setCursor(i,0);
			cm.scrollIntoView(null,100);
			return true;
		};
	}
	
	//************************************************************************
	//Work with cody
	//************************************************************************
	{
		//--------------------------------------------------------------------
		cssVO.peekUndoAction=function(){
			return cmDoc.peekUndoAction();
		};
		
		//--------------------------------------------------------------------
		cssVO.peekRedoAction=function(){
			return cmDoc.peekRedoAction();
		};
		
		//--------------------------------------------------------------------
		cssVO.undo=function(){
			cmDoc.undo();
		};
	
		//--------------------------------------------------------------------
		cssVO.redo=function(){
			cmDoc.redo();
		};
		
		//--------------------------------------------------------------------
		cssVO.addCodyEditAction=function(action){
			if(cmDoc){
				if(!cmDoc.addCodyEditAction(action)){
					self.emit("Change");
					self.emitNotify("Change");
				}
			}
		};
	
		//--------------------------------------------------------------------
		cssVO.lockCodySegs=function(){
			let idx,ln,line,lockStartLine,lockStartCh,elMark,elText;
			ln=cmDoc.lineCount();
			idx=0;
			lockStartLine=0;
			lockStartCh=0;
			function lockStart(){
				let pos,pos2,mark;
				for(;idx<ln;idx++){
					line=cmDoc.getLine(idx);
					if(line.startsWith("\/\*Cody Project Doc\*/")){
						cmDoc.markText({line:lockStartLine,ch:lockStartCh},{line:ln-1,ch:0},{readOnly:true});
						cmDoc.markText({line:idx+1,ch:0},{line:ln-1,ch:0},{collapsed:true});
						return null;
					}
					pos=line.indexOf("\/\*#{");
					if(pos>=0){
						pos2=line.indexOf("*/",pos);
						if(pos2>0){
							//Mark End:
							/*if(lockStartLine>0){
								elMark=document.createElement("span");
								elMark.style.background="linear-gradient(to top, rgba(255,255,255,0) 60%,black 60%, black 65%, #8888 65%, rgba(255,255,255,0) 80%";
								elMark.style.width="100px";
								elMark.style.height="10px";
								elMark.style.color="rgba(0,0,0,0)";
								elText = document.createTextNode("======================================================================================================");
								elMark.appendChild(elText);
								cmDoc.markText({line:lockStartLine,ch:0},{line:lockStartLine,ch:cmDoc.getLine(lockStartLine).length},{replacedWith:elMark});
							}*/
							
							mark=line.substring(pos+"\/\*#{".length,pos2);
							cmDoc.markText({line:lockStartLine,ch:lockStartCh},{line:idx,ch:line.length},{readOnly:true});
							//cmDoc.markText({line:lockStartLine,ch:lockStartCh},{line:idx,ch:0},{readOnly:true});
							//Mark Start:
							/*elMark=document.createElement("span");
							elMark.style.background="linear-gradient(to bottom, rgba(255,255,255,0) 60%,black 60%, black 65%, #8888 65%, rgba(255,255,255,0) 80%";
							elMark.style.width="100px";
							elMark.style.height="10px";
							elMark.style.color="rgba(0,0,0,0)";
							elText = document.createTextNode("======================================================================================================");
							elMark.appendChild(elText);
							cmDoc.markText({line:idx,ch:0},{line:idx,ch:line.length},{replacedWith:elMark});*/
							idx++;
							return mark;
						}
					}
				}
				return null;
			}
			function lockEnd(mark){
				let pos,endMark;
				endMark=`/*}#${mark}*/`
				for(;idx<ln;idx++){
					line=cmDoc.getLine(idx);
					pos=line.indexOf(endMark);
					if(pos>=0){
						lockStartLine=idx;
						//lockStartCh=pos;
						lockStartCh=0;
						idx++;
						return;
					}
				}
			}
			do{
				let mark;
				mark=lockStart();
				if(!mark){
					return;
				}
				lockEnd(mark);
			}while(idx<ln);
		};
	}
	
	//************************************************************************
	//Code mirror events:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		cssVO.OnCMInput=function(){
			self.emit("Input");
			self.emitNotify("Input");
		};
	
		//--------------------------------------------------------------------
		cssVO.OnCMChanges=function(){
			self.emit("Change");
			self.emitNotify("Change");
		};
	
		//-------------------------------------------------------------------
		cssVO.OnCMChangeJSHint=function(cm,changeObj){
			if(changeObj.origin==="+input" && changeObj.text[0]==='.'){
				cm.execCommand("autocomplete");
			}
			return cm;
		};
	
		//--------------------------------------------------------------------
		cssVO.OnCMCursorAct=function(){
			if(app.setCursorText && cm){
				let pos=self.getCursorPos();
				let baseCoords=cm.cursorCoords({line:pos.line,ch:0},"local");
				let coords=cm.cursorCoords(pos,"local");
				let tw=cm.defaultCharWidth();
				let ch=Math.round((coords.left-baseCoords.left)/tw)+1;
				app.setCursorText(`${pos.line}:${ch}`);
			}
		};
	
		//--------------------------------------------------------------------
		cssVO.OnCMFocus=function(){
			self.emit("Focus");
			self.emitNotify("Focus");
		};
	
		//--------------------------------------------------------------------
		cssVO.OnCMBlur=function(){
			self.emit("Blur");
			self.emitNotify("Blur");
		};
	}
	
	//************************************************************************
	//Find and replace:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		cssVO.showDlg=function(dlg){
			switch(dlg){
				default:
				case "Find":
					self.showFace("find");
					break;
				case "Replace":
					self.showFace("replace");
					break;
			}
		};
	
		//--------------------------------------------------------------------
		cssVO.getDlg=function(){
			return curDlg;
		};
	
		//--------------------------------------------------------------------
		cssVO.closeDlg=function(dlg){
			if(dlg===curDlg || !dlg){
				self.showFace("nodlg");
				self.focus();
			}
		};
		
		//--------------------------------------------------------------------
		cssVO.showFind=function(vo){
			let state=vo.state;
			let find=vo.find;
			self.showFace("find");
			if(find instanceof RegExp){
				findText=find.source;
			}else if(find){
				findText=""+find;
			}else{
				findText="";
			}
			self.EdFind.text=findText;
			self.EdFind.startEdit();
			if(findText){
				if(cm){
					if(cm.getSelection()===findText){
						let pos,index;
						pos=cm.getCursor("from");
						index=cm.indexFromPos(pos);
						index=index>0?index-1:0;
						pos=cm.posFromIndex(index);
						cm.setCursor(pos);
					}
				}
				self.startFind();
			}
		};
	
		//--------------------------------------------------------------------
		cssVO.showReplace=function(vo){
			let state=vo.state;
			let find=vo.find;
			self.showFace("replace");
			if(find instanceof RegExp){
				findText=find.source;
			}else if(find){
				findText=""+find;
			}else{
				findText="";
			}
			self.EdFind.text=findText;
			self.EdFind.startEdit();
			if(findText){
				self.startFind();
			}
			self.checkReplaceBtns();
		};
	
		//--------------------------------------------------------------------
		cssVO.startFind=function(rev){
			let useCase,useWord,useRegExp;
			let state = getSearchState(cm);
	
			findText=self.EdFind.text;
			if(!findText){
				clearSearch(cm);
				return;
			}
			useCase=self.BtnCase.checked;
			useWord=self.BtnWords.checked;
			useRegExp=self.BtnRegex.checked;
			cm.operation(function() {
				startSearch(cm, state, findText, useCase, useWord, useRegExp);
				state.posFrom = state.posTo = cm.getCursor();
				findNext(cm, !!rev);
			});			
		};
	
		//--------------------------------------------------------------------
		cssVO.findNext=function(){
			if(findText!==self.EdFind.text){
				self.startFind(false);
				return;
			}
			if(cm){
				var state = getSearchState(cm);
				if (!state.query){
					self.startFind(false);
				}
				doSearch(cm);
			}
		};
	
		//--------------------------------------------------------------------
		cssVO.findPre=function(){
			if(findText!==self.EdFind.text){
				self.startFind(true);
				return;
			}
			if(cm){
				var state = getSearchState(cm);
				if (!state.query){
					self.startFind(true);
					return;
				}
				doSearch(cm,true);
			}
		};
	
		//------------------------------------------------------------------------
		//Replace current find item
		cssVO.replace=function(){
			let cursor,match,query;
			let selFrom,selTo,findFrom,findTo;
			var state = getSearchState(cm);
			var text;
			if (!state.query){
				self.startFind(false);
				doSearch(cm);
				return;
			}
			cursor=state.findCursor;
			if(!cursor){
				doSearch(cm);
				return;
			}
			text=self.EdReplace.text;
			query=state.query;
			match=state.findMatch;
			findFrom=state.findFrom;
			findTo=state.findTo;
			selFrom=cm.getCursor("from");
			selTo=cm.getCursor("to");
			if(equalCursorPos(findFrom,selFrom) && equalCursorPos(findTo,selTo)){
				cursor.replace(typeof query == "string" ? text :
							text.replace(/\$(\d)/g, function(_, i) {return match[i];}));
				doSearch(cm);
			}else{
				doSearch(cm);
			}
		};
	
		//------------------------------------------------------------------------
		//Replace all items in doc
		cssVO.replaceAll=function(){
			let inSel,cursor,findText,text,query,useCase,cnt;
			var state = getSearchState(cm);
			text=self.EdReplace.text;
			findText=self.EdFind.text;
			query=state.query;
			if (!query){
				self.startFind(false);
				doSearch(cm);
				return;
			}
			if(state.queryText!==findText){
				self.startFind(false);
				doSearch(cm);
				return;
			}
			cursor=state.findCursor;
			if(!cursor){
				doSearch(cm);
				return;
			}
			useCase=state.useCase;
			inSel=self.BtnRange.checked;
			cnt=0;
			if(inSel){
				let selFrom,selTo,findFrom,findTo;
				selFrom=cm.getCursor("from");
				selTo=cm.getCursor("to");
				cm.operation(function() {
					for (var cursor = getSearchCursor(cm, query, CodeMirror.Pos(cm.firstLine()), useCase); cursor.findNext();) {
						findFrom=cursor.from();
						findTo=cursor.to();
						if(cmp(findFrom,selFrom)>0){
							if(cmp(findFrom,selTo)<0){
								if (typeof query != "string") {
									var match = cm.getRange(cursor.from(), cursor.to()).match(query);
									cursor.replace(text.replace(/\$(\d)/g, function(_, i) {return match[i];}));
								} else {
									cursor.replace(text);
								}
								cnt++;
							}
						}
					}
				});
			}else{
				cm.operation(function() {
					for (var cursor = getSearchCursor(cm, query, CodeMirror.Pos(cm.firstLine()), useCase); cursor.findNext();) {
						if (typeof query != "string") {
							var match = cm.getRange(cursor.from(), cursor.to()).match(query);
							cursor.replace(text.replace(/\$(\d)/g, function(_, i) {return match[i];}));
						} else {
							cursor.replace(text);
						}
						cnt++;
					}
				});
			}
			self.showStateText(`${cnt} ${cnt>1?"occurrences":"occurrence"} replaced.`,0);
			//TODO: code this:
		};
	
		//--------------------------------------------------------------------
		cssVO.showStateText=function(text,life,underText){
			if(app.showStateText){
				return app.showStateText(text,life,underText);
			}
			//TODO: Use app tip:
		};
		
		//--------------------------------------------------------------------
		//Check dlgBtn:
		cssVO.checkReplaceBtns=function(){
			self.BtnReplace.enable=self.EdFind.text;
			self.BtnReplaceAll.enable=self.EdFind.text;
		};
	}
	
	//------------------------------------------------------------------------
	//Handle shortcut, only handle "Find"/Replace
	cssVO.handleShortcut=function(cmd){
		if(cmd==="Find"){
			self.findNext();
			return 1;
		}else if(cmd==="FindNext"){
			self.findNext();
			return 1;
		}else if(cmd==="FindPre"){
			self.findPre();
			return 1;
		}else if(cmd==="AICode"){
			app.showDlg(DlgAICoder,{
				doc:dataDoc
			});
			return 1;
		}
		return 0;
	};
	/*}#1G9EKS4E97PostCSSVO*/
	cssVO.constructor=DocEditor;
	return cssVO;
};
/*#{1G9EKS4E97ExCodes*/
initEnv=function(){
	//----------------------------------------------------------------------------
	//Config CodeMirror to close dialog when press ESC key.
	let sel_dontScroll={scroll: false};
	CodeMirror.commands.singleSelection= function (cm) { 
		let editUI=cm.uiCodeEditor;
		if(editUI){
			let dlg=editUI.getDlg();
			if(dlg){
				editUI.closeDlg(dlg);
				return;
			}
		}
		let list=cm.listSelections();
		if(list && list.length>1){
			return cm.setSelection(cm.getCursor("anchor"), cm.getCursor("head"), sel_dontScroll); 
		}
		return cm.setSelection(cm.getCursor("head"), cm.getCursor("head"), sel_dontScroll); 
	};

	//****************************************************************************
	//Search and replace:
	//****************************************************************************
	cmp=function(a, b) {
		return a.line - b.line || a.ch - b.ch;
	}

	equalCursorPos=function (a, b){
		return a.sticky === b.sticky && cmp(a, b) === 0;
	}

	//----------------------------------------------------------------------------
	//Convert special chars:
	function parseString(string) {
		return string.replace(/\\([nrt\\])/g, function(match, ch) {
			if (ch === "n") return "\n";
			if (ch === "r") return "\r";
			if (ch === "t") return "\t";
			if (ch === "\\") return "\\";
			return match;
		});
	}

	//----------------------------------------------------------------------------
	//Parse the query:
	function parseQuery(query,isRE,useWord,useCase) {
		//var isRE = query.match(/^\/(.*)\/([a-z]*)$/);
		if (isRE) {
			try { query = new RegExp(query); }
			catch(e) {} // Not a regular expression after all, do a string search
		} else {
			query = parseString(query);
		}
		if(useWord){
			query=new RegExp(`\\b${query}\\b`,"g");
		}
		if (typeof query === "string" ? query === "" : query.test("")){
			query = /x^/;
		}
		return query;
	}

	//----------------------------------------------------------------------------
	//Function to let codemirror mark query string in code feild:
	function searchOverlay(query, useCase) {
		if (typeof query === "string")
			query = new RegExp(query.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g, "\\$&"), useCase ? "g" : "gi");
		else if (!query.global)
			query = new RegExp(query.source, query.ignoreCase ? "gi" : "g");

		return {token: function(stream) {
			query.lastIndex = stream.pos;
			var match = query.exec(stream.string);
			if (match && match.index === stream.pos) {
				stream.pos += match[0].length || 1;
				return "searching";
			} else if (match) {
				stream.pos = match.index;
			} else {
				stream.skipToEnd();
			}
		}};
	}

	//----------------------------------------------------------------------------
	//The search state to keep in codemirror:
	function SearchState() {
		this.posFrom = this.posTo = this.lastQuery = this.query = null;
		this.useCase=false;
		this.overlay = null;
	}

	//----------------------------------------------------------------------------
	//Get current search state, if there is none, create one:
	getSearchState=function(cm) {
		return cm.state.search || (cm.state.search = new SearchState());
	}

	//----------------------------------------------------------------------------
	//Clear current search
	clearSearch=function(cm) {cm.operation(function() {
		var state = getSearchState(cm);
		state.lastQuery = state.query;
		if (!state.query) return;
		state.query = state.queryText = null;
		cm.removeOverlay(state.overlay);
		if (state.annotate) { state.annotate.clear(); state.annotate = null; }
	});}

	//----------------------------------------------------------------------------
	//Get the search cursor:
	getSearchCursor=function (cm, query, pos, useCase) {
		return cm.getSearchCursor(query, pos, {caseFold: useCase?false:true, multiline: true});
	}

	//----------------------------------------------------------------------------
	//Start the search
	startSearch=function(cm, state, query, useCase, useWord, useRegExp) {
		state.queryText = query;
		state.query = parseQuery(query,useRegExp,useWord);
		cm.removeOverlay(state.overlay, state.useCase);
		state.useCase=useCase;
		state.overlay = searchOverlay(state.query, state.useCase);
		cm.addOverlay(state.overlay);
		if (cm.showMatchesOnScrollbar) {
			if (state.annotate) { state.annotate.clear(); state.annotate = null; }
			state.annotate = cm.showMatchesOnScrollbar(state.query, state.useCase);
		}
		//cm.focus();
	}

	//----------------------------------------------------------------------------
	//Open dialog to search:
	doSearch=function(cm, rev, persistent, immediate) {
		var state = getSearchState(cm);
		if (state.query)
			return findNext(cm, rev);
		var q = cm.getSelection();// || state.lastQuery;
		if (q instanceof RegExp && q.source === "x^") q = null;
		if (persistent) {
			//What is this?
		} else {
			let editUI=cm.uiCodeEditor;
			if(editUI){
				editUI.showFind({find:q,cm:cm,state:state});
			}
		}
	}

	//----------------------------------------------------------------------------
	//Find next match, rev is the find direction:
	findNext=function(cm, rev, callback) {cm.operation(function() {
		var state = getSearchState(cm);
		var useCase=state.useCase;
		var match;
		let editUI=cm.uiCodeEditor;
		if(rev){
			state.posFrom = state.posTo = cm.getCursor("from");
		}else{
			state.posFrom = state.posTo = cm.getCursor();
		}
		var cursor = getSearchCursor(cm, state.query, rev ? state.posFrom : state.posTo, useCase);
		state.findMatch=null;
		state.findFrom=null;
		state.findTo=null;
		state.findCursor=null;
		match=cursor.find(rev);
		if (!match) {
			cursor = getSearchCursor(cm, state.query, rev ? CodeMirror.Pos(cm.lastLine()) : CodeMirror.Pos(cm.firstLine(), 0), useCase);
			match=cursor.find(rev);
			if (!match){
				editUI.showStateText(`Can't find text: `,0,state.queryText);
				return;
			}
			editUI.showStateText(rev?"Find passed the file begining.":"Find passed the file end.");
		}
		state.findMatch=match;
		state.findFrom=cursor.from();
		state.findTo=cursor.to();
		cm.setSelection(cursor.from(), cursor.to());
		cm.scrollIntoView({from: cursor.from(), to: cursor.to()}, 20);
		state.posFrom = cursor.from(); state.posTo = cursor.to();
		state.findCursor=cursor;
		if (callback){
			callback(cursor.from(), cursor.to())
		}
		//callAfter(()=>{cm.focus();});
	});}

	//----------------------------------------------------------------------------
	//Open dialog to replace:
	replace=function(cm){
		var state = getSearchState(cm);
		var q = cm.getSelection() || state.lastQuery;
		if (q instanceof RegExp && q.source === "x^") q = null
		let editUI=cm.uiCodeEditor;
		if(editUI){
			editUI.showReplace({find:q,cm:cm,state:state,replace:true});
		}
	};


	CodeMirror.commands.find = function(cm) {
		clearSearch(cm);
		doSearch(cm);
	};

	CodeMirror.commands.findNext = doSearch;
	CodeMirror.commands.findPrev = function(cm) {doSearch(cm, true);};
	CodeMirror.commands.clearSearch = clearSearch;

	CodeMirror.commands.replace = replace;
	CodeMirror.commands.replaceAll = replace;
	
	envInited=1;
};
/*}#1G9EKS4E97ExCodes*/

//----------------------------------------------------------------------------
DocEditor.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1G9EKS4E97PreAISpot*/
	/*}#1G9EKS4E97PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1G9EKS4E97PostAISpot*/
	/*}#1G9EKS4E97PostAISpot*/
	return exposeVO;
};

/*#{1G9EKS4E90EndDoc*/
/*}#1G9EKS4E90EndDoc*/

export default DocEditor;
export{DocEditor};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1G9EKS4E90",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1G9EKS4E91",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "750",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1G9EKS4E92",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1H7A1MNQC0",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1G9EKS4E93",
//			"attrs": {
//				"app": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"mod": {
//					"type": "string",
//					"valText": "\".js\""
//				},
//				"codeText": {
//					"type": "string",
//					"valText": ""
//				},
//				"cfgVO": {
//					"type": "auto",
//					"valText": "{}"
//				},
//				"dataDoc": {
//					"type": "auto",
//					"valText": "null"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1G9EKS4E94",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1G9EKS4E95",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "VFACT document",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1G9EKS4E96",
//			"attrs": {
//				"nodlg": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1G9EN206M0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1G9EN8U2N0",
//							"attrs": {}
//						}
//					}
//				},
//				"find": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1G9EN28FS0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1G9EN8U2N1",
//							"attrs": {}
//						}
//					}
//				},
//				"replace": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1G9EN2D1R0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1G9EN8U2N2",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1HD4O9D3U0",
//			"attrs": {}
//		},
//		"exposeToAI": "true",
//		"descAI": "",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1G9EKS4E97",
//			"attrs": {
//				"properties": {
//					"jaxId": "1G9EKS4EA0",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "\"FW\"",
//						"h": "\"FH\"",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "true",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "[0,0,0,0]",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "\"\"",
//						"styleClass": ""
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1G9ELAPE50",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G9ELBBES0",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxEdit",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "\"FW\"",
//										"h": "\"FH\"",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "true",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "\"\"",
//										"styleClass": ""
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1G9ELBBES1",
//									"attrs": {
//										"1G9EN2D1R0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9EN8U2N3",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9EN8U2N4",
//													"attrs": {
//														"y": {
//															"type": "length",
//															"valText": "60"
//														},
//														"h": {
//															"type": "length",
//															"valText": "\"FH-60\""
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9EN2D1R0",
//											"faceTagName": "replace"
//										},
//										"1G9EN206M0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9EN8U2N5",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9EN8U2N6",
//													"attrs": {
//														"y": {
//															"type": "length",
//															"valText": "0"
//														},
//														"h": {
//															"type": "length",
//															"valText": "\"FH\""
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9EN206M0",
//											"faceTagName": "nodlg"
//										},
//										"1G9EN28FS0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9EN8U2N7",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9EN8U2N8",
//													"attrs": {
//														"y": {
//															"type": "length",
//															"valText": "30"
//														},
//														"h": {
//															"type": "length",
//															"valText": "\"FH-30\""
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9EN28FS0",
//											"faceTagName": "find"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1G9ELBBES2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1GHRBF7SB0",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1G9ELBEE50",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G9EM8NRV0",
//									"attrs": {
//										"type": "box",
//										"id": "BoxDlgSearch",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "\"FW\"",
//										"h": "60",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "true",
//										"display": "Off",
//										"clip": "On",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "\"\"",
//										"styleClass": "",
//										"background": "#cfgColor.tool",
//										"border": "[0,0,1,0]",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor.fontToolLit",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1G9ELDUOB0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9EM8NRV1",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxFind",
//														"position": "Absolute",
//														"x": "0",
//														"y": "0",
//														"w": "\"FW\"",
//														"h": "30",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "true",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[0,0,0,0]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "\"\"",
//														"styleClass": "",
//														"contentLayout": "Flex X"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "edit",
//															"jaxId": "1G9ELF1DR0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1G9EM8NRV2",
//																	"attrs": {
//																		"type": "edit",
//																		"id": "EdFind",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "\"FH/2\"",
//																		"w": "250",
//																		"h": "24",
//																		"anchorH": "Left",
//																		"anchorV": "Center",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[0,3,0,5]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "\"\"",
//																		"styleClass": "",
//																		"inputType": "Text",
//																		"text": "",
//																		"placeHolder": "Text to find",
//																		"color": "[0,0,0]",
//																		"bgColor": "[255,255,255,1.00]",
//																		"font": "",
//																		"fontSize": "#txtSize.smallMid",
//																		"outline": "0",
//																		"border": "1",
//																		"borderStyle": "Solid",
//																		"borderColor": "[0,0,0,1.00]",
//																		"corner": "0",
//																		"selectOnFocus": "true",
//																		"spellCheck": "true"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1G9EM8NS00",
//																	"attrs": {
//																		"1G9EN28FS0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1G9EN8U2N11",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1G9EN8U2N12",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1G9EN28FS0",
//																			"faceTagName": "find"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1G9EM8NS01",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1GHRBF7SB1",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "true",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1G9EM9MA30",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1G9EMBNIR0",
//																	"attrs": {
//																		"style": "front",
//																		"w": "24",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/arrowup.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1G9EMBNIR1",
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"front\",24,0,appCfg.sharedAssets+\"/arrowup.svg\",null)",
//																		"id": "",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "\"FH/2\"",
//																		"display": "On",
//																		"face": "",
//																		"anchorV": "Center",
//																		"padding": "2"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1G9EMBNIR2",
//																	"attrs": {
//																		"1G9EN28FS0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1G9EN8U2N15",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1G9EN8U2N16",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1G9EN28FS0",
//																			"faceTagName": "find"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1G9EMBNIR3",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1GHRBF7SC0",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "true",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1H7A1MNQC1",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1G9EMBOVT0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1G9EMBOVT1",
//																	"attrs": {
//																		"style": "front",
//																		"w": "24",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/arrowdown.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1G9EMBOVT2",
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"front\",24,0,appCfg.sharedAssets+\"/arrowdown.svg\",null)",
//																		"id": "",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "\"FH/2\"",
//																		"display": "On",
//																		"face": "",
//																		"anchorV": "Center",
//																		"padding": "2"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1G9EMBOVU0",
//																	"attrs": {
//																		"1G9EN28FS0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1G9EN8U2N19",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1G9EN8U2N20",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1G9EN28FS0",
//																			"faceTagName": "find"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1G9EMBOVU1",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1GHRBF7SC1",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "true",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1H7A1MNQC2",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnCheck.js",
//															"jaxId": "1G9EMCIUV0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1G9EMFLCR0",
//																	"attrs": {
//																		"size": "20",
//																		"text": "",
//																		"checked": "false",
//																		"radio": "false"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1G9EMFLCR1",
//																	"attrs": {
//																		"type": "#null#>BtnCheck(20,\"\",false,false)",
//																		"id": "BtnCase",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "5",
//																		"display": "On",
//																		"face": "",
//																		"checked": "false",
//																		"padding": "2"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1G9EMFLCR2",
//																	"attrs": {
//																		"1G9EN28FS0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1G9EN8U2N23",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1G9EN8U2N24",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1G9EN28FS0",
//																			"faceTagName": "find"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1G9EMFLCR3",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1GHRBF7SC2",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "true",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1H7A1MNQC3",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1G9EME6T70",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1G9EMFLCR4",
//																	"attrs": {
//																		"type": "text",
//																		"id": "",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100",
//																		"h": "\"FH\"",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[0,5,0,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "\"\"",
//																		"styleClass": "",
//																		"color": "[0,0,0]",
//																		"text": "Case",
//																		"font": "",
//																		"fontSize": "#txtSize.smallMid",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Center",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"lineClamp": "0",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0",
//																		"autoSizeW": "true",
//																		"autoSizeH": "false"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1G9EMFLCR5",
//																	"attrs": {
//																		"1G9EN28FS0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1G9EN8U2N27",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1G9EN8U2N28",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1G9EN28FS0",
//																			"faceTagName": "find"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1G9EMFLCR6",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1GHRBF7SC3",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnCheck.js",
//															"jaxId": "1G9EMGCFF0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1G9EMGCFF1",
//																	"attrs": {
//																		"size": "20",
//																		"text": "",
//																		"checked": "false",
//																		"radio": "false"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1G9EMGCFF2",
//																	"attrs": {
//																		"type": "#null#>BtnCheck(20,\"\",false,false)",
//																		"id": "BtnWords",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "5",
//																		"display": "On",
//																		"face": "",
//																		"checked": "false",
//																		"padding": "2"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1G9EMGCFG0",
//																	"attrs": {
//																		"1G9EN28FS0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1G9EN8U2N31",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1G9EN8U2N32",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1G9EN28FS0",
//																			"faceTagName": "find"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1G9EMGCFG1",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1GHRBF7SC4",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "true",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1H7A1MNQC4",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1G9EMGFDM0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1G9EMGFDM1",
//																	"attrs": {
//																		"type": "text",
//																		"id": "",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100",
//																		"h": "\"FH\"",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[0,5,0,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "\"\"",
//																		"styleClass": "",
//																		"color": "[0,0,0]",
//																		"text": "Words",
//																		"font": "",
//																		"fontSize": "#txtSize.smallMid",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Center",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"lineClamp": "0",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0",
//																		"autoSizeW": "true",
//																		"autoSizeH": "false"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1G9EMGFDN0",
//																	"attrs": {
//																		"1G9EN28FS0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1G9EN8U2N35",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1G9EN8U2N36",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1G9EN28FS0",
//																			"faceTagName": "find"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1G9EMGFDN1",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1GHRBF7SC5",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "box",
//															"jaxId": "1G9EMIEQA0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1G9EMPJTI0",
//																	"attrs": {
//																		"type": "box",
//																		"id": "",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "5",
//																		"w": "1",
//																		"h": "20",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[0,3,0,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "\"\"",
//																		"styleClass": "",
//																		"background": "#cfgColor.fontToolLit",
//																		"border": "0",
//																		"borderStyle": "Solid",
//																		"borderColor": "[0,0,0,1.00]",
//																		"corner": "0",
//																		"shadow": "false",
//																		"shadowX": "2",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowSpread": "0",
//																		"shadowColor": "[0,0,0,0.50]"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1G9EMPJTI1",
//																	"attrs": {
//																		"1G9EN28FS0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1G9EN8U2N39",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1G9EN8U2N40",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1G9EN28FS0",
//																			"faceTagName": "find"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1G9EMPJTI2",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1GHRBF7SC6",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnCheck.js",
//															"jaxId": "1G9EMJMKR0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1G9EMJMKR1",
//																	"attrs": {
//																		"size": "20",
//																		"text": "",
//																		"checked": "false",
//																		"radio": "false"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1G9EMJMKR2",
//																	"attrs": {
//																		"type": "#null#>BtnCheck(20,\"\",false,false)",
//																		"id": "BtnRegex",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "5",
//																		"display": "On",
//																		"face": "",
//																		"checked": "false",
//																		"padding": "2"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1G9EMJMKS0",
//																	"attrs": {
//																		"1G9EN28FS0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1G9EN8U2N43",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1G9EN8U2N44",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1G9EN28FS0",
//																			"faceTagName": "find"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1G9EMJMKS1",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1GHRBF7SC7",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "true",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1H7A1MNQC5",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1G9EMK76J0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1G9EMK76J1",
//																	"attrs": {
//																		"type": "text",
//																		"id": "",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100",
//																		"h": "\"FH\"",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[0,10,0,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "\"\"",
//																		"styleClass": "",
//																		"color": "[0,0,0]",
//																		"text": "Regex",
//																		"font": "",
//																		"fontSize": "#txtSize.smallMid",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Center",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"lineClamp": "0",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0",
//																		"autoSizeW": "true",
//																		"autoSizeH": "false"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1G9EMK76J2",
//																	"attrs": {
//																		"1G9EN28FS0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1G9EN8U2O2",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1G9EN8U2O3",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1G9EN28FS0",
//																			"faceTagName": "find"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1G9EMK76J3",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1GHRBF7SC8",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnText.js",
//															"jaxId": "1G9EMLQSQ0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1G9EMPJTI3",
//																	"attrs": {
//																		"style": "",
//																		"w": "80",
//																		"h": "22",
//																		"text": "Replace",
//																		"outlined": "false",
//																		"icon": ""
//																	}
//																},
//																"properties": {
//																	"jaxId": "1G9EMPJTI4",
//																	"attrs": {
//																		"type": "#null#>BtnText(\"\",80,22,\"Replace\",false,\"\")",
//																		"id": "",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "4",
//																		"display": "On",
//																		"face": "",
//																		"text": "Replace",
//																		"corner": "3"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1G9EMPJTI5",
//																	"attrs": {
//																		"1G9EN2D1R0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1G9EN8U2O4",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1G9EN8U2O5",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1G9EN2D1R0",
//																			"faceTagName": "replace"
//																		},
//																		"1G9EN28FS0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1G9EN8U2O8",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1G9EN8U2O9",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1G9EN28FS0",
//																			"faceTagName": "find"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1G9EMPJTI6",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1GHRBF7SC9",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "true",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1H7A1MNQC6",
//																	"attrs": {
//																		"Slot1H2F6U36O0": {
//																			"jaxId": "1IA23FHAK0",
//																			"attrs": {
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"container": "true"
//																			}
//																		}
//																	}
//																}
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1G9EM8NS02",
//													"attrs": {
//														"1G9EN28FS0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1G9EN8U2O12",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1G9EN8U2O13",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1G9EN28FS0",
//															"faceTagName": "find"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1G9EM8NS03",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1GHRBF7SC10",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1G9EMR09O0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9EMVSJI0",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxReplace",
//														"position": "Absolute",
//														"x": "0",
//														"y": "30",
//														"w": "\"FW\"",
//														"h": "30",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[0,0,0,0]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "\"\"",
//														"styleClass": "",
//														"contentLayout": "Flex X"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "edit",
//															"jaxId": "1G9EMS1PC0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1G9EMS1PC1",
//																	"attrs": {
//																		"type": "edit",
//																		"id": "EdReplace",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "\"FH/2\"",
//																		"w": "250",
//																		"h": "24",
//																		"anchorH": "Left",
//																		"anchorV": "Center",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[0,5,0,5]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "\"\"",
//																		"styleClass": "",
//																		"inputType": "Text",
//																		"text": "",
//																		"placeHolder": "Text to replace",
//																		"color": "[0,0,0]",
//																		"bgColor": "[255,255,255,1.00]",
//																		"font": "",
//																		"fontSize": "#txtSize.smallMid",
//																		"outline": "0",
//																		"border": "1",
//																		"borderStyle": "Solid",
//																		"borderColor": "[0,0,0,1.00]",
//																		"corner": "0",
//																		"selectOnFocus": "true",
//																		"spellCheck": "true"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1G9EMS1PC2",
//																	"attrs": {
//																		"1G9EN28FS0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1G9EN8U2O20",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1G9EN8U2O21",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1G9EN28FS0",
//																			"faceTagName": "find"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1G9EMS1PC3",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1GHRBF7SC11",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "true",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnText.js",
//															"jaxId": "1G9EMSK160",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1G9EMSK161",
//																	"attrs": {
//																		"style": "",
//																		"w": "80",
//																		"h": "22",
//																		"text": "Replace",
//																		"outlined": "false",
//																		"icon": ""
//																	}
//																},
//																"properties": {
//																	"jaxId": "1G9EMSK162",
//																	"attrs": {
//																		"type": "#null#>BtnText(\"\",80,22,\"Replace\",false,\"\")",
//																		"id": "BtnReplace",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "4",
//																		"display": "On",
//																		"face": "",
//																		"text": "Replace",
//																		"margin": "[0,5,0,0]",
//																		"corner": "3"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1G9EMSK170",
//																	"attrs": {
//																		"1G9EN28FS0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1G9EN8U2O24",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1G9EN8U2O25",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1G9EN28FS0",
//																			"faceTagName": "find"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1G9EMSK171",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1GHRBF7SC12",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "true",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1H7A1MNQD0",
//																	"attrs": {
//																		"Slot1H2F6U36O0": {
//																			"jaxId": "1IA23FHAK1",
//																			"attrs": {
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"container": "true"
//																			}
//																		}
//																	}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnText.js",
//															"jaxId": "1G9EMT4OU0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1G9EMT4OU1",
//																	"attrs": {
//																		"style": "warning",
//																		"w": "80",
//																		"h": "22",
//																		"text": "Replace",
//																		"outlined": "false",
//																		"icon": ""
//																	}
//																},
//																"properties": {
//																	"jaxId": "1G9EMT4OU2",
//																	"attrs": {
//																		"type": "#null#>BtnText(\"warning\",80,22,\"Replace\",false,\"\")",
//																		"id": "BtnReplaceAll",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "4",
//																		"display": "On",
//																		"face": "",
//																		"text": "All",
//																		"margin": "[0,5,0,0]",
//																		"corner": "3"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1G9EMT4OU3",
//																	"attrs": {
//																		"1G9EN28FS0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1G9EN8U2O28",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1G9EN8U2O29",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1G9EN28FS0",
//																			"faceTagName": "find"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1G9EMT4OU4",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1GHRBF7SC13",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "true",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1H7A1MNQD1",
//																	"attrs": {
//																		"Slot1H2F6U36O0": {
//																			"jaxId": "1IA23FHAK2",
//																			"attrs": {
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"container": "true"
//																			}
//																		}
//																	}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnCheck.js",
//															"jaxId": "1G9EMUCLH0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1G9EMUCLH1",
//																	"attrs": {
//																		"size": "20",
//																		"text": "",
//																		"checked": "false",
//																		"radio": "false"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1G9EMUCLH2",
//																	"attrs": {
//																		"type": "#null#>BtnCheck(20,\"\",false,false)",
//																		"id": "BtnRange",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "5",
//																		"display": "On",
//																		"face": "",
//																		"checked": "false",
//																		"padding": "2"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1G9EMUCLI0",
//																	"attrs": {
//																		"1G9EN28FS0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1G9EN8U2O32",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1G9EN8U2O33",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1G9EN28FS0",
//																			"faceTagName": "find"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1G9EMUCLI1",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1GHRBF7SC14",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "true",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1H7A1MNQD2",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1G9EMV75L0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1G9EMV75L1",
//																	"attrs": {
//																		"type": "text",
//																		"id": "",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100",
//																		"h": "\"FH\"",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[0,10,0,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "\"\"",
//																		"styleClass": "",
//																		"color": "[0,0,0]",
//																		"text": "In selection",
//																		"font": "",
//																		"fontSize": "#txtSize.smallMid",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Center",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"lineClamp": "0",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0",
//																		"autoSizeW": "true",
//																		"autoSizeH": "false"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1G9EMV75M0",
//																	"attrs": {
//																		"1G9EN28FS0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1G9EN8U2O36",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1G9EN8U2O37",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1G9EN28FS0",
//																			"faceTagName": "find"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1G9EMV75M1",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1GHRBF7SC15",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1IB22TBN40",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1IB22TBN41",
//																	"attrs": {
//																		"style": "front",
//																		"w": "20",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/close.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1IB22TBN42",
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"front\",20,0,appCfg.sharedAssets+\"/close.svg\",null)",
//																		"id": "",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "50%",
//																		"display": "On",
//																		"face": "",
//																		"autoLayout": "true",
//																		"padding": "1",
//																		"anchorV": "Center"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IB22TBN43",
//																	"attrs": {
//																		"1G9EN28FS0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IB22TBN44",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IB22TBN45",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1G9EN28FS0",
//																			"faceTagName": "find"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1IB22TBN48",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1IB22TBN49",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "true",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1IB22TBN410",
//																	"attrs": {}
//																}
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1G9EMVSJI1",
//													"attrs": {
//														"1G9EN28FS0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1G9EN8U2O40",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1G9EN8U2O41",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1G9EN28FS0",
//															"faceTagName": "find"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1G9EMVSJI2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1GHRBF7SC16",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1G9EMO7PA0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1G9EMPJTI7",
//													"attrs": {
//														"style": "front",
//														"w": "20",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/close.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1G9EMPJTI8",
//													"attrs": {
//														"type": "#null#>BtnIcon(\"front\",20,0,appCfg.sharedAssets+\"/close.svg\",null)",
//														"id": "",
//														"position": "Absolute",
//														"x": "\"FW-25\"",
//														"y": "5",
//														"display": "On",
//														"face": "",
//														"autoLayout": "true",
//														"padding": "1"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1G9EMPJTI9",
//													"attrs": {
//														"1G9EN28FS0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1G9EN8U2O16",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1G9EN8U2O17",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1G9EN28FS0",
//															"faceTagName": "find"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1G9EMPJTI10",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1GHRBF7SC17",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "true",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1H7A1MNQD3",
//													"attrs": {}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1G9EM8NS04",
//									"attrs": {
//										"1G9EN2D1R0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9EN8U2O42",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9EN8U2O43",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														},
//														"h": {
//															"type": "length",
//															"valText": "60"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9EN2D1R0",
//											"faceTagName": "replace"
//										},
//										"1G9EN206M0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9EN8U2O44",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9EN8U2O45",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9EN206M0",
//											"faceTagName": "nodlg"
//										},
//										"1G9EN28FS0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9EN8U2O46",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9EN8U2O47",
//													"attrs": {
//														"h": {
//															"type": "length",
//															"valText": "30"
//														},
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9EN28FS0",
//											"faceTagName": "find"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1G9EM8NS05",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1GHRBF7SC18",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1G9EKS4EA1",
//					"attrs": {
//						"1G9EN28FS0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1G9EN8U2O50",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G9EN8U2O51",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1G9EN28FS0",
//							"faceTagName": "find"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1G9EKS4EA2",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1GHRBF7SC19",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1G9EKS4EA3",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false",
//				"innerLayout": {
//					"valText": "false"
//				},
//				"marginL": {
//					"valText": "false"
//				},
//				"marginR": {
//					"valText": "false"
//				},
//				"marginT": {
//					"valText": "false"
//				},
//				"marginB": {
//					"valText": "false"
//				},
//				"paddingL": {
//					"valText": "false"
//				},
//				"paddingR": {
//					"valText": "false"
//				},
//				"paddingT": {
//					"valText": "false"
//				},
//				"paddingB": {
//					"valText": "false"
//				},
//				"attach": {
//					"valText": "false"
//				},
//				"face": {
//					"type": "bool",
//					"valText": "false"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}