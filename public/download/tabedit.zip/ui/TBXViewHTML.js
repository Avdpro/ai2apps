//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
/*#{1G9HD19OQ0StartDoc*/
import pathLib from "/@path";
/*}#1G9HD19OQ0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let TBXViewHTML=function(app){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1G9HD19OQ7LocalVals*/
	let appPrj,dataDocs;
	let isFocused=0;
	let curURL=null;
	let pageFrame=null;
	let pageDoc=null;
	let startURL=null;
	appPrj=app.prj;
	dataDocs=appPrj.docs;
	/*}#1G9HD19OQ7LocalVals*/
	
	/*#{1G9HD19OQ7PreState*/
	/*}#1G9HD19OQ7PreState*/
	/*#{1G9HD19OQ7PostState*/
	/*}#1G9HD19OQ7PostState*/
	cssVO={
		"hash":"1G9HD19OQ7",nameHost:true,
		"type":"hud","x":0,"y":0,"w":"FW","h":"FH","autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
		children:[
			{
				"hash":"1G9OAOHR40",
				"type":"hud","id":"BoxToolBtn","x":0,"y":0,"w":"FW","h":30,"autoLayout":true,"display":0,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
				children:[
					{
						"hash":"1G9OAOHR50",
						"type":"text","position":"relative","x":0,"y":0,"w":100,"h":"FH","margin":[0,0,0,3],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor.fontToolSub,
						"text":(($ln==="CN")?("查看HTML页面"):("View HTML Page")),"fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
						"alignV":1,"autoW":true,
					}
				],
			},
			{
				"hash":"1G9OB3H4G0",
				"type":"box","id":"Header","x":0,"y":0,"w":"100%","h":30,"padding":[0,2,0,2],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.tool,
				"border":[0,0,1,0],"borderColor":cfgColor.fontToolSub,"contentLayout":"flex-x","itemsAlign":1,
				children:[
					{
						"hash":"1IA0HJ4UM0",
						"type":BtnIcon("front",28,0,appCfg.sharedAssets+"/arrowright.svg",null),"id":"BtnUseFile","position":"relative","x":0,"y":0,"enable":false,"padding":2,
						"tip":(($ln==="CN")?("使用当前文件"):("Use current file")),
						/*#{1IA0HJ4UM0Codes*/
						OnClick(){
							self.useCurFile();
						}
						/*}#1IA0HJ4UM0Codes*/
					},
					{
						"hash":"1G9OBBHJO0",
						"type":"edit","id":"EdURL","position":"relative","x":0,"y":0,"w":20,"h":25,"autoLayout":true,"padding":[0,6,0,6],"minW":"","minH":"","maxW":"","maxH":"",
						"styleClass":"","placeHolder":(($ln==="CN")?("页面文件URL"):("Page file URL")),"color":cfgColor["fontBody"],"background":cfgColor.body,"fontSize":txtSize.smallMid,
						"outline":0,"border":1,"corner":10,"flex":true,
						/*#{1G9OBBHJO0Codes*/
						OnUpdate(){
							let url=this.text;
							self.openPage(url);
						}
						/*}#1G9OBBHJO0Codes*/
					},
					{
						"hash":"1IA0HP61N0",
						"type":BtnIcon("front",28,0,appCfg.sharedAssets+"/redo.svg",null),"id":"BtnReload","position":"relative","x":0,"y":0,"enable":false,"padding":1,
						"tip":(($ln==="CN")?("重新加载"):("Reload")),
						/*#{1IA0HP61N0Codes*/
						OnClick(){
							self.refreshPage();
						}
						/*}#1IA0HP61N0Codes*/
					},
					{
						"hash":"1IA0HSONN0",
						"type":BtnIcon("front",28,0,appCfg.sharedAssets+"/web.svg",null),"id":"BtnOpenPage","position":"relative","x":0,"y":0,"enable":false,"padding":2,
						"tip":(($ln==="CN")?("在新标签页中打开"):("Open in new tab")),
						/*#{1IA0HSONN0Codes*/
						OnClick(){
							self.openBrowser();
						}
						/*}#1IA0HSONN0Codes*/
					}
				],
			},
			{
				"hash":"1G9OB5PTV0",
				"type":"hud","id":"BoxPage","x":0,"y":30,"w":"100%","h":">calc(100% - 30px)","autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
			}
		],
		/*#{1G9HD19OQ7ExtraCSS*/
		/*}#1G9HD19OQ7ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			self=this;
			
			/*#{1G9HD19OQ7Create*/
			let cfgVO;
			self.toolBtnBox=self.BoxToolBtn;
			self.toolBtnBox.hold();
			self.removeChild(self.toolBtnBox);
			self.toolBtnBox.h="FH";
			self.toolBtnBox.display=1;
			
			self.ensureFrame();
			dataDocs.on("DocSaved",self.OnDocSaved);
			//Check prj if there is start page:
			cfgVO=appPrj.prjConfig.TBXViewHTML;
			if(cfgVO){
				startURL=cfgVO.file;
				if(startURL){
					startURL=`${document.location.origin}/${pathLib.join(appPrj.path,startURL)}`;
				}
			}
			/*}#1G9HD19OQ7Create*/
		},
		/*#{1G9HD19OQ7EndCSS*/
		/*}#1G9HD19OQ7EndCSS*/
	};
	/*#{1G9HD19OQ7PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.OnShow=function(){
		dataDocs.on("FocusDoc",self.updateBtns);
		self.updateBtns();
		isFocused=1;
		if(startURL){
			self.openPage(startURL);
			startURL=null;
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.OnHide=function(){
		dataDocs.off("FocusDoc",self.updateBtns);
		isFocused=0;
	};
	
	//------------------------------------------------------------------------
	cssVO.OnDocSaved=function(doc){
		if(doc===pageDoc){
			self.refreshPage();
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.updateBtns=function(){
		let doc;
		doc=dataDocs.hotDoc;
		if(!doc){
			self.BtnUseFile.enable=0;
		}else{
			let extName;
			extName=pathLib.extname(doc.path);
			if(extName===".html" || extName===".htm"){
				self.BtnUseFile.enable=1;
			}else{
				self.BtnUseFile.enable=0;
			}
			self.BtnOpenPage.enable=curURL?1:0;
			self.BtnReload.enable=curURL?1:0;
		}
	};
	
	//------------------------------------------------------------------------
	//Create the iFrame if there is not:
	cssVO.ensureFrame=function(){
		if(!pageFrame){
			pageFrame=document.createElement("iframe");
			//pageFrame.src=`${document.location.origin}//-terminal/frame.html?${seq}`;
			pageFrame.style.position="absolute";
			pageFrame.style.left="0px";
			pageFrame.style.top="0px";
			pageFrame.style.width="100%";
			pageFrame.style.height="100%";
			pageFrame.style.border="none";
			self.BoxPage.webObj.appendChild(pageFrame);
		}
	};
	
	//------------------------------------------------------------------------
	//Generate URL from doc
	function doc2URL(doc){
		return `${document.location.origin}/${doc.path}`;
	};
	
	//------------------------------------------------------------------------
	//Open page:
	cssVO.openPage=function(url){
		self.ensureFrame();
		curURL=url;
		self.EdURL.text=curURL;
		pageFrame.src=curURL;
		pageDoc=null;
		self.updateBtns();
	};
	
	//------------------------------------------------------------------------
	//Refresh the page:
	cssVO.refreshPage=function(){
		if(pageFrame && curURL){
			pageFrame.src=curURL;
		}
	};
	
	//------------------------------------------------------------------------
	//Open a new web-browser-page:
	cssVO.openBrowser=function(){
		if(pageFrame && curURL){
			window.open(curURL,"CCEditHtmlViewOpen");
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.useCurFile=function(){
		let doc;
		doc=dataDocs.hotDoc;
		if(!doc){
			return;
		}
		curURL=doc2URL(doc);
		pageDoc=doc;
		pageFrame.src=curURL;
		self.EdURL.text=curURL;
		self.updateBtns();
	};
	//************************************************************************
	//EditorOpenPage for terminal:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		//Register the global open page in editor HTMLView API:
		window.editorOpenPage=function(pageURL){
			if(!(pageURL.indexOf("://")>0)){
				if(!pageURL.startsWith("/")){
					pageURL=`${document.location.origin}/${pathLib.join(appPrj.path,pageURL)}`
				}else{
					pageURL=`${document.location.origin}/${pageURL}`
				}
			}
			self.openPage(pageURL);
		};
	}
	/*}#1G9HD19OQ7PostCSSVO*/
	return cssVO;
};
/*#{1G9HD19OQ7ExCodes*/
TBXViewHTML.tbxCodeName="ViewHTML";
TBXViewHTML.tbxTip=(($ln==="CN")?("查看页面"):("View HTML"));
TBXViewHTML.tbxIcon=appCfg.sharedAssets+"/browser.svg";
TBXViewHTML.tbxIconPad=3;
TBXViewHTML.scoreDoc=function(doc){
	return 10;
};
TBXViewHTML.confgBlock=function(){
	//TODO: Code this:
};
/*}#1G9HD19OQ7ExCodes*/


/*#{1G9HD19OQ0EndDoc*/
/*}#1G9HD19OQ0EndDoc*/

export default TBXViewHTML;
export{TBXViewHTML};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1G9HD19OQ0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1G9HD19OQ1",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1G9HD19OQ2",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1H7J1Q0EU0",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1G9HD19OQ3",
//			"attrs": {
//				"app": {
//					"type": "auto",
//					"valText": "null"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1G9HD19OQ4",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1G9HD19OQ5",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "VFACT document",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1G9HD19OQ6",
//			"attrs": {}
//		},
//		"mockupStates": {
//			"jaxId": "1IA0HM5KU0",
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1G9HD19OQ7",
//			"attrs": {
//				"properties": {
//					"jaxId": "1G9HD19OQ8",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "\"FW\"",
//						"h": "\"FH\"",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "true",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "[0,0,0,0]",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "\"\"",
//						"styleClass": ""
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1G9OAOHR40",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G9OAOHR41",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxToolBtn",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "\"FW\"",
//										"h": "30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "true",
//										"display": "Off",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "\"\"",
//										"styleClass": "",
//										"contentLayout": "Flex X"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1G9OAOHR50",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9OAOHR51",
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"w": "100",
//														"h": "\"FH\"",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[0,0,0,3]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "\"\"",
//														"styleClass": "",
//														"color": "#cfgColor.fontToolSub",
//														"text": {
//															"type": "string",
//															"valText": "查看HTML页面",
//															"localize": {
//																"EN": "View HTML Page",
//																"CN": "查看HTML页面"
//															},
//															"localizable": true
//														},
//														"font": "",
//														"fontSize": "#txtSize.smallMid",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Center",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0",
//														"autoSizeW": "true",
//														"autoSizeH": "false"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1G9OAOHR52",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1G9OAOHR53",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1H7J1Q0EV0",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1G9OAOHR54",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1G9OAOHR55",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H7J1Q0EV1",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1G9OB3H4G0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G9OB58BG0",
//									"attrs": {
//										"type": "box",
//										"id": "Header",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,0]",
//										"padding": "[0,2,0,2]",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "\"\"",
//										"styleClass": "",
//										"background": "#cfgColor.tool",
//										"border": "[0,0,1,0]",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor.fontToolSub",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"contentLayout": "Flex X",
//										"itemsAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1IA0HJ4UM0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1IA0HM5KV0",
//													"attrs": {
//														"style": "\"front\"",
//														"w": "28",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/arrowright.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1IA0HM5KV1",
//													"attrs": {
//														"type": "#null#>BtnIcon(\"front\",28,0,appCfg.sharedAssets+\"/arrowright.svg\",null)",
//														"id": "BtnUseFile",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"enable": "false",
//														"padding": "2"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IA0HM5KV2",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1IA0HM5KV3",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IA0HM5KV4",
//													"attrs": {
//														"tip": {
//															"type": "string",
//															"valText": "使用当前文件",
//															"localize": {
//																"EN": "Use current file",
//																"CN": "使用当前文件"
//															},
//															"localizable": true
//														}
//													}
//												},
//												"mockup": "false",
//												"codes": "true",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1IA0HM5KV5",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "edit",
//											"jaxId": "1G9OBBHJO0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9OBIELD0",
//													"attrs": {
//														"type": "edit",
//														"id": "EdURL",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"w": "20",
//														"h": "25",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "true",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[0,0,0,0]",
//														"padding": "[0,6,0,6]",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "\"\"",
//														"styleClass": "",
//														"inputType": "Text",
//														"text": "",
//														"placeHolder": {
//															"type": "string",
//															"valText": "页面文件URL",
//															"localize": {
//																"EN": "Page file URL",
//																"CN": "页面文件URL"
//															},
//															"localizable": true
//														},
//														"color": "#cfgColor[\"fontBody\"]",
//														"bgColor": "#cfgColor.body",
//														"font": "",
//														"fontSize": "#txtSize.smallMid",
//														"outline": "0",
//														"border": "1",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "10",
//														"selectOnFocus": "true",
//														"spellCheck": "true",
//														"flex": "true"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1G9OBIELD1",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1G9OBIELD2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1H7J1Q0EV4",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "true",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1IA0HP61N0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1IA0HP61N1",
//													"attrs": {
//														"style": "\"front\"",
//														"w": "28",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/redo.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1IA0HP61N2",
//													"attrs": {
//														"type": "#null#>BtnIcon(\"front\",28,0,appCfg.sharedAssets+\"/redo.svg\",null)",
//														"id": "BtnReload",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"enable": "false",
//														"padding": "1"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IA0HP61N3",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1IA0HP61N4",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IA0HP61N5",
//													"attrs": {
//														"tip": {
//															"type": "string",
//															"valText": "重新加载",
//															"localize": {
//																"EN": "Reload",
//																"CN": "重新加载"
//															},
//															"localizable": true
//														}
//													}
//												},
//												"mockup": "false",
//												"codes": "true",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1IA0HP61N6",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1IA0HSONN0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1IA0HSONN1",
//													"attrs": {
//														"style": "\"front\"",
//														"w": "28",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/web.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1IA0HSONN2",
//													"attrs": {
//														"type": "#null#>BtnIcon(\"front\",28,0,appCfg.sharedAssets+\"/web.svg\",null)",
//														"id": "BtnOpenPage",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"enable": "false",
//														"padding": "2"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IA0HSONN3",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1IA0HSONN4",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IA0HSONN5",
//													"attrs": {
//														"tip": {
//															"type": "string",
//															"valText": "在新标签页中打开",
//															"localize": {
//																"EN": "Open in new tab",
//																"CN": "在新标签页中打开"
//															},
//															"localizable": true
//														}
//													}
//												},
//												"mockup": "false",
//												"codes": "true",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1IA0HSONN6",
//													"attrs": {}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1G9OB58BG1",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1G9OB58BG2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H7J1Q0EV9",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "true",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1G9OB5PTV0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G9OB7ARV0",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxPage",
//										"position": "Absolute",
//										"x": "0",
//										"y": "30",
//										"w": "100%",
//										"h": "100%-30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "true",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "\"\"",
//										"styleClass": ""
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1G9OB7ARV1",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1G9OB7ARV2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H7J1Q0EV10",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1G9HD19OQ9",
//					"attrs": {}
//				},
//				"functions": {
//					"jaxId": "1G9HD19OQ10",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1H7J1Q0EV11",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1G9HD19OQ11",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"innerLayout": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"face": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"marginL": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"marginR": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"marginT": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"marginB": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"paddingL": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"paddingT": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"paddingR": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"paddingB": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"attach": {
//					"type": "bool",
//					"valText": "false"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}