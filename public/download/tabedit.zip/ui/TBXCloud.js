//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnStd} from "/@homekit/ui/BtnStd.js";
import {PathPreview} from "/@StdUI/ui/PathPreview.js";
/*#{1G9HB2K300StartDoc*/
import {tabFS} from "/@tabos";
/*}#1G9HB2K300StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let TBXCloud=function(app){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let pvDocInfo;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1G9HB2K307LocalVals*/
	let isFocused=0;
	let appPrj,dataDocs;
	let curDoc=null;
	/*}#1G9HB2K307LocalVals*/
	
	/*#{1G9HB2K307PreState*/
	/*}#1G9HB2K307PreState*/
	/*#{1G9HB2K307PostState*/
	/*}#1G9HB2K307PostState*/
	cssVO={
		"hash":"1G9HB2K307",nameHost:true,
		"type":"hud","x":0,"y":0,"w":"FW","h":"FH","autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
		children:[
			{
				"hash":"1G9L30SH80",
				"type":"hud","id":"BoxToolBtn","x":0,"y":0,"w":"100%","h":30,"autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
				children:[
					{
						"hash":"1G9L30SH82",
						"type":"text","position":"relative","x":0,"y":0,"w":"","h":"100%","margin":[0,0,0,3],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor.fontToolSub,
						"text":(($ln==="CN")?("文档文件信息:"):("Doc file info:")),"fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
						"alignV":1,"autoW":true,
					}
				],
			},
			{
				"hash":"1G9L4UP6I0",
				"type":"text","id":"TxtPath","position":"relative","x":10,"y":0,"w":"FW-10","h":20,"display":0,"margin":[10,0,5,0],"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","color":[0,0,0],"text":"text","fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
			},
			{
				"hash":"1G9L52HSB0",
				"type":"text","id":"TxtSize","position":"relative","x":10,"y":0,"w":"FW-10","h":20,"display":0,"margin":[0,0,5,0],"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","color":[0,0,0],"text":"text","fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
			},
			{
				"hash":"1G9L54KP80",
				"type":"text","id":"TxtTime","position":"relative","x":10,"y":0,"w":"FW-10","h":20,"display":0,"margin":[0,0,5,0],"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","color":[0,0,0],"text":"text","fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
			},
			{
				"hash":"1G9L55M880",
				"type":"text","id":"TxtBase","position":"relative","x":10,"y":0,"w":"FW-10","h":20,"display":0,"margin":[0,0,5,0],"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","color":[0,0,0],"text":"text","fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
			},
			{
				"hash":"1G9L56MI20",
				"type":"text","id":"TxtModified","position":"relative","x":10,"y":0,"w":"FW-10","h":20,"display":0,"margin":[0,0,5,0],"minW":"","minH":"","maxW":"",
				"maxH":"","styleClass":"","color":[0,0,0],"text":"text","fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
			},
			{
				"hash":"1G9L576M90",
				"type":BtnStd(app,100,25,("Button"),""),"id":"BtnEditChange","position":"relative","x":15,"y":0,"display":0,"text":(($ln==="CN")?("编辑更改"):("Edit Change")),
				/*#{1G9L576M90Codes*/
				OnClick(){
					self.openCompare();
				}
				/*}#1G9L576M90Codes*/
			},
			{
				"hash":"1IA39EHEQ0",
				"type":PathPreview({"readOnly":true,"showImage":true,"showContent":false,"showVersion":true,"showCloud":false,"showTool":false}),"id":"PvDocInfo",
				"position":"relative","x":0,"y":0,"w":"100%","h":"100%",
			}
		],
		/*#{1G9HB2K307ExtraCSS*/
		/*}#1G9HB2K307ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			self=this;
			pvDocInfo=self.PvDocInfo;
			/*#{1G9HB2K307Create*/
			appPrj=app.prj;
			dataDocs=appPrj.docs;
			
			self.toolBtnBox=self.BoxToolBtn;
			self.toolBtnBox.hold();
			self.removeChild(self.toolBtnBox);
			self.toolBtnBox.h="FH";
			self.toolBtnBox.display=1;
			/*}#1G9HB2K307Create*/
		},
		/*#{1G9HB2K307EndCSS*/
		/*}#1G9HB2K307EndCSS*/
	};
	/*#{1G9HB2K307PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.OnShow=function(){
		dataDocs.on("FocusDoc",self.OnFocusDoc);
		self.showState(dataDocs.hotDoc);
		isFocused=1;
	};
	
	//------------------------------------------------------------------------
	cssVO.OnHide=function(){
		dataDocs.off("FocusDoc",self.OnFocusDoc);
		isFocused=0;
	};
	
	//------------------------------------------------------------------------
	cssVO.OnFocusDoc=function(doc){
		self.showState(doc);
	};
	
	//------------------------------------------------------------------------
	cssVO.showState=async function(doc){
		let entry;
		curDoc=doc;
		if(curDoc && curDoc.path){
			try{
				entry=await tabFS.getEntry(doc.path);
				if(entry){
					pvDocInfo.display=true;
					pvDocInfo.setEntry(doc.path);
				}else{
					pvDocInfo.display=false;
				}
			}catch(err){
				entry=null;
			}
		}else{
			pvDocInfo.display=false;
		}
		return;
		if(!doc){
			self.TxtPath.display=0;
			self.TxtSize.display=0;
			self.TxtTime.display=0;
			self.TxtBase.display=0;
			self.TxtModified.display=0;
			self.BtnEditChange.display=0;
			return;
		}
		try{
			entry=await tabFS.getEntry(doc.path);
		}catch(err){
			entry=null;
		}
		if(entry){
			self.TxtPath.display=1;
			self.TxtSize.display=1;
			self.TxtTime.display=1;
			self.TxtBase.display=1;
			self.BtnEditChange.display=1;
			self.TxtPath.text=(($ln==="CN")?(`路径: ${doc.path}`):(`Path: ${doc.path}`));
			self.TxtSize.text=(($ln==="CN")?(`大小：${entry.size}`):(`Size: ${entry.size}`));
			if(entry.modifyTime>0){
				let date=new Date(entry.modifyTime);
				self.TxtTime.text=(($ln==="CN")?(`时间：${date.toLocaleDateString()} ${date.toLocaleTimeString()}`):(`Time: ${date.toLocaleDateString()} ${date.toLocaleTimeString()}`));
				
			}else{
				self.TxtTime.text="Time: NA";
			}
			if(entry.baseVersionIdx>0){
				self.TxtBase.text=(($ln==="CN")?(`基础版本: ${entry.baseVersionIdx}`):(`Base version: ${entry.baseVersionIdx}`));
				self.TxtModified.display=1;
				self.TxtModified.text=(($ln==="CN")?("修改时间: "+(entry.modified?"是":"否")):("Modified: "+(entry.modified?"Yes":"No")));
				self.BtnEditChange.enable=!!entry.modified;
			}else{
				self.TxtBase.text=(($ln==="CN")?(`基础版本：无`):(`Base version: NA`));
				self.TxtModified.display=0;
				self.BtnEditChange.enable=false;
			}
		}else{
			self.TxtPath.display=0;
			self.TxtSize.display=0;
			self.TxtTime.display=0;
			self.TxtBase.display=0;
			self.TxtModified.display=0;
			self.BtnEditChange.display=0;
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.openCompare=async function(){
		let path,doc;
		if(!curDoc)
			return;
		path=curDoc.path;
		path+=".baseversion";
		doc=await dataDocs.openDoc(path);
		dataDocs.focusDoc(doc);
	};
	
	/*}#1G9HB2K307PostCSSVO*/
	return cssVO;
};
/*#{1G9HB2K307ExCodes*/
TBXCloud.tbxCodeName="Cloud";
TBXCloud.tbxTip=(($ln==="CN")?("文档版本"):("Doc version"));
TBXCloud.tbxIcon=appCfg.sharedAssets+"/recent.svg";
TBXCloud.tbxIconPad=2;
TBXCloud.scoreDoc=function(doc){
	return 10;
};
/*}#1G9HB2K307ExCodes*/


/*#{1G9HB2K300EndDoc*/
/*}#1G9HB2K300EndDoc*/

export default TBXCloud;
export{TBXCloud};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1G9HB2K300",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1G9HB2K301",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1G9HB2K302",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1H7IVTLBM0",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1G9HB2K303",
//			"attrs": {
//				"app": {
//					"type": "auto",
//					"valText": "null"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1G9HB2K304",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1G9HB2K305",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "VFACT document",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1G9HB2K306",
//			"attrs": {}
//		},
//		"mockupStates": {
//			"jaxId": "1I9VHF6J10",
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1G9HB2K307",
//			"attrs": {
//				"properties": {
//					"jaxId": "1G9HB2K308",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "\"FW\"",
//						"h": "\"FH\"",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "true",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "[0,0,0,0]",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "\"\"",
//						"styleClass": "",
//						"contentLayout": "Flex Y"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1G9L30SH80",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G9L30SH81",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxToolBtn",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "true",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "\"\"",
//										"styleClass": "",
//										"contentLayout": "Flex X"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1G9L30SH82",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9L30SH83",
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"w": "",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[0,0,0,3]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "\"\"",
//														"styleClass": "",
//														"color": "#cfgColor.fontToolSub",
//														"text": {
//															"type": "string",
//															"valText": "文档文件信息:",
//															"localize": {
//																"EN": "Doc file info:",
//																"CN": "文档文件信息:"
//															},
//															"localizable": true
//														},
//														"font": "",
//														"fontSize": "#txtSize.smallMid",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Center",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0",
//														"autoSizeW": "true",
//														"autoSizeH": "false"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1G9L30SH90",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1G9L30SH91",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1H0O2T0ME0",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1G9L30SH92",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1G9L30SH93",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H0O2T0ME1",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1G9L4UP6I0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G9L52H3B0",
//									"attrs": {
//										"type": "text",
//										"id": "TxtPath",
//										"position": "Relative",
//										"x": "10",
//										"y": "0",
//										"w": "\"FW-10\"",
//										"h": "20",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "Off",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[10,0,5,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "\"\"",
//										"styleClass": "",
//										"color": "[0,0,0]",
//										"text": "text",
//										"font": "",
//										"fontSize": "#txtSize.smallMid",
//										"bold": "false",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Top",
//										"wrap": "false",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0",
//										"autoSizeW": "false",
//										"autoSizeH": "false"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1G9L52H3B1",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1G9L52H3B2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H0O2T0ME2",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1G9L52HSB0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G9L52HSB1",
//									"attrs": {
//										"type": "text",
//										"id": "TxtSize",
//										"position": "Relative",
//										"x": "10",
//										"y": "0",
//										"w": "\"FW-10\"",
//										"h": "20",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "Off",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,5,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "\"\"",
//										"styleClass": "",
//										"color": "[0,0,0]",
//										"text": "text",
//										"font": "",
//										"fontSize": "#txtSize.smallMid",
//										"bold": "false",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Top",
//										"wrap": "false",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0",
//										"autoSizeW": "false",
//										"autoSizeH": "false"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1G9L52HSB2",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1G9L52HSB3",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H0O2T0ME3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1G9L54KP80",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G9L54KP81",
//									"attrs": {
//										"type": "text",
//										"id": "TxtTime",
//										"position": "Relative",
//										"x": "10",
//										"y": "0",
//										"w": "\"FW-10\"",
//										"h": "20",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "Off",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,5,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "\"\"",
//										"styleClass": "",
//										"color": "[0,0,0]",
//										"text": "text",
//										"font": "",
//										"fontSize": "#txtSize.smallMid",
//										"bold": "false",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Top",
//										"wrap": "false",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0",
//										"autoSizeW": "false",
//										"autoSizeH": "false"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1G9L54KP90",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1G9L54KP91",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H0O2T0ME4",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1G9L55M880",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G9L55M881",
//									"attrs": {
//										"type": "text",
//										"id": "TxtBase",
//										"position": "Relative",
//										"x": "10",
//										"y": "0",
//										"w": "\"FW-10\"",
//										"h": "20",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "Off",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,5,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "\"\"",
//										"styleClass": "",
//										"color": "[0,0,0]",
//										"text": "text",
//										"font": "",
//										"fontSize": "#txtSize.smallMid",
//										"bold": "false",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Top",
//										"wrap": "false",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0",
//										"autoSizeW": "false",
//										"autoSizeH": "false"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1G9L55M882",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1G9L55M883",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H0O2T0ME5",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1G9L56MI20",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G9L56MI21",
//									"attrs": {
//										"type": "text",
//										"id": "TxtModified",
//										"position": "Relative",
//										"x": "10",
//										"y": "0",
//										"w": "\"FW-10\"",
//										"h": "20",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "Off",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,5,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "\"\"",
//										"styleClass": "",
//										"color": "[0,0,0]",
//										"text": "text",
//										"font": "",
//										"fontSize": "#txtSize.smallMid",
//										"bold": "false",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Top",
//										"wrap": "false",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0",
//										"autoSizeW": "false",
//										"autoSizeH": "false"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1G9L56MI30",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1G9L56MI31",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H0O2T0ME6",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear/@homekit/ui/BtnStd.js",
//							"jaxId": "1G9L576M90",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1G9L59DKK0",
//									"attrs": {
//										"app": "#app",
//										"w": "100",
//										"h": "25",
//										"text": {
//											"type": "string",
//											"valText": "Button",
//											"localize": {
//												"EN": "Button"
//											},
//											"localizable": true
//										},
//										"style": ""
//									}
//								},
//								"properties": {
//									"jaxId": "1G9L59DKK1",
//									"attrs": {
//										"type": "#null#>BtnStd(app,100,25,(\"Button\"),\"\")",
//										"id": "BtnEditChange",
//										"position": "Relative",
//										"x": "15",
//										"y": "0",
//										"display": "Off",
//										"face": "",
//										"text": {
//											"type": "string",
//											"valText": "编辑更改",
//											"localize": {
//												"EN": "Edit Change",
//												"CN": "编辑更改"
//											},
//											"localizable": true
//										}
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1G9L59DKK2",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1G9L59DKK3",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H0O2T0ME7",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "true",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false",
//								"containerSlots": {
//									"jaxId": "1H7IVTLBM1",
//									"attrs": {}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear/@StdUI/ui/PathPreview.js",
//							"jaxId": "1IA39EHEQ0",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1IA39NG2P0",
//									"attrs": {
//										"options": {
//											"jaxId": "1IA39NG2P1",
//											"attrs": {
//												"readOnly": "true",
//												"showImage": "true",
//												"showContent": "false",
//												"showVersion": "true",
//												"showCloud": "false",
//												"showTool": "false"
//											}
//										}
//									}
//								},
//								"properties": {
//									"jaxId": "1IA39NG2P2",
//									"attrs": {
//										"type": "#null#>PathPreview({\"readOnly\":true,\"showImage\":true,\"showContent\":false,\"showVersion\":true,\"showCloud\":false,\"showTool\":false})",
//										"id": "PvDocInfo",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"display": "On",
//										"face": "",
//										"w": "100%",
//										"h": "100%"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1IA39NG2P3",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1IA39NG2P4",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IA39NG2P5",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true",
//								"containerSlots": {
//									"jaxId": "1IA39NG2P6",
//									"attrs": {}
//								}
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1G9HB2K309",
//					"attrs": {}
//				},
//				"functions": {
//					"jaxId": "1G9HB2K3010",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1H0O2T0ME8",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1G9HB2K3011",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"innerLayout": {
//					"valText": "false"
//				},
//				"marginL": {
//					"valText": "false"
//				},
//				"marginR": {
//					"valText": "false"
//				},
//				"marginT": {
//					"valText": "false"
//				},
//				"marginB": {
//					"valText": "false"
//				},
//				"paddingL": {
//					"valText": "false"
//				},
//				"paddingR": {
//					"valText": "false"
//				},
//				"paddingT": {
//					"valText": "false"
//				},
//				"paddingB": {
//					"valText": "false"
//				},
//				"attach": {
//					"valText": "false"
//				},
//				"face": {
//					"type": "bool",
//					"valText": "false"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}