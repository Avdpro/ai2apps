//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {InfoCard} from "/@StdUI/ui/InfoCard.js";
import {BoxTabLine} from "/@StdUI/ui/BoxTabLine.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
/*#{1H0VIN5V70StartDoc*/
import pathLib from "/@path";
import {tabOS,tabFS,tabNT} from "/@tabos";
/*}#1H0VIN5V70StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let DlgNewPlayground=function(app){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let boxTabs,boxList;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1H0VIN5V71LocalVals*/
	/*}#1H0VIN5V71LocalVals*/
	
	/*#{1H0VIN5V71PreState*/
	/*}#1H0VIN5V71PreState*/
	/*#{1H0VIN5V71PostState*/
	/*}#1H0VIN5V71PostState*/
	cssVO={
		"hash":"1H0VIN5V71",nameHost:true,
		"type":"box","x":"50%","y":100,"w":600,"h":600,"anchorX":1,"overflow":1,"padding":10,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":[255,255,255,1],
		"border":2,"corner":6,"shadow":true,"shadowY":6,"shadowBlur":6,"contentLayout":"flex-y",
		children:[
			{
				"hash":"1H0VIPPSC0",
				"type":"text","position":"relative","x":0,"y":0,"w":">calc(100% - 40px)","h":"","uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"color":cfgColor.fontBodySub,"text":(($ln==="CN")?("创建新实验"):("NEW PLAYGROUND")),"fontSize":txtSize.larger,"fontWeight":"bold","fontStyle":"normal",
				"textDecoration":"",
			},
			{
				"hash":"1H0VJBRAE0",
				"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":100,"margin":[20,0,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
				"subAlign":1,
				children:[
					{
						"hash":"1H0VJBVLH0",
						"type":InfoCard((($ln==="CN")?("AI聊天"):("AI Chat")),(($ln==="CN")?("优化AI聊天模板"):("Finetune AI Chat template")),appCfg.sharedAssets+"/aichat.svg","",80,0),
						"position":"relative","x":0,"y":"50%","anchorY":1,"margin":[0,30,0,0],"w":240,"h":100,"border":2,"corner":12,"sizeCap":20,"hideInfo":false,
						"OnClick":function(event){
							/*#{1H10NFO9N0FunctionBody*/
							self.doNewAIChat();
							/*}#1H10NFO9N0FunctionBody*/
						},
					},
					{
						"hash":"1H0VJC3QI0",
						"type":InfoCard((($ln==="CN")?("HTML创意"):("HTML Idea")),(($ln==="CN")?("带有CSS和脚本的HTML片段。"):("HTML snippet with CSS and scripts.")),appCfg.sharedAssets+"/web.svg","",80,0),
						"position":"relative","x":0,"y":"50%","anchorY":1,"enable":false,"w":240,"h":100,"border":2,"corner":12,"sizeCap":20,"hideInfo":false,
						"OnClick":function(event){
							/*#{1H10NIBCG0FunctionBody*/
							self.doNewHTMLPen();
							/*}#1H10NIBCG0FunctionBody*/
						},
					}
				],
			},
			{
				"hash":"1H10P80590",
				"type":BoxTabLine(24,128,[
	{"text":$ln==="CN"?"AI聊天例子":"AI Samples","msg":"AIExamples","hot":1},
	{"text":$ln==="CN"?"HTML片段例子":"HTML Samples","msg":"H5Examples"},
	{"text":$ln==="CN"?"最近项目":"Recent","msg":"Recent"},
    {"text":$ln==="CN"?"社区分享":"Community","msg":"Community"}
]),
				"id":"BoxTabs","position":"relative","x":0,"y":0,"w":"100%","margin":[10,0,0,0],
			},
			{
				"hash":"1H0VJKMNF0",
				"type":"hud","id":"BoxList","position":"relative","x":0,"y":0,"w":"100%","h":100,"overflow":"auto-y","padding":10,"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","flex":true,"contentLayout":"flex-y",
			},
			{
				"hash":"1H10MT61O0",
				"type":BtnIcon("front",32,0,appCfg.sharedAssets+"/close.svg",null),"id":"BtnClose","x":554,"y":10,"padding":1,
				"OnClick":function(event){
					/*#{1H10MU7U00FunctionBody*/
					app.closeDlg(self);
					return 1;
					/*}#1H10MU7U00FunctionBody*/
				},
			}
		],
		/*#{1H0VIN5V71ExtraCSS*/
		/*}#1H0VIN5V71ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			self=this;
			boxTabs=self.BoxTabs;boxList=self.BoxList;
			/*#{1H0VIN5V71Create*/
			boxTabs.onNotify("TabChanged",self.showList);
			/*}#1H0VIN5V71Create*/
		},
		/*#{1H0VIN5V71EndCSS*/
		/*}#1H0VIN5V71EndCSS*/
	};
	/*#{1H0VIN5V71PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.showDlg=function(vo){
		boxTabs.hotTab="AIExamples";
		self.showList();
	};
	
	//------------------------------------------------------------------------
	cssVO.showList=async function(){
		let tab,dirPath;
		dirPath=(($ln==="CN")?("/-tabedit/playground/examples_cn"):/*EN*/("/-tabedit/playground/examples"));
		tab=boxTabs.hotTab;
		boxList.clearChildren();
		switch(tab){
			case "AIExamples":{
				let items,ext,w;
				w=boxList.clientWidth;
				items=await tabFS.getEntries(dirPath);
				if(items && items.length>0){
					let i,n,item,docText,docJSON,css;
					n=items.length;
					for(i=0;i<n;i++){
						item=items[i];
						ext=pathLib.extname(item.name);
						if(ext===".aichat"){
							try{
								docText=await tabFS.readFile(dirPath+"/"+item.name,"utf8");
								docJSON=JSON.parse(docText);
							}catch(err){
								docJSON=null;
							}
							if(docJSON){
								css={
									type:BtnCard(app,w-30,80,appCfg.sharedAssets+"/lab.svg",60,60,docJSON.name||item.name,docJSON.info||"Playground example.",txtSize.big,txtSize.small),
									position:"relative",x:"50%",y:0,margin:[0,0,10,0],anchorX:1,docText:docText,
									OnClick(){
										app.docs.newEmptyDoc(".aichat",false,this.docText);
										app.closeDlg(self);
									}
								};
								boxList.appendNewChild(css);
							}
						}
					}
				}
				break;
			}
			case "H5Examples":{
				let items,ext,w;
				w=boxList.clientWidth;
				boxList.appendNewChild({
					type:BtnCard(app,w-30,80,appCfg.sharedAssets+"/mark_work.svg",60,60,"Comming soon.","HTML snipt features is under development.",txtSize.big,txtSize.small),
					position:"relative",x:"50%",y:0,margin:[0,0,10,0],anchorX:1,enable:false
				});
				return;
				items=await tabFS.getEntries("/-tabedit/playground/examples");
				if(items && items.length>0){
					let i,n,item,docText,docJSON,css;
					n=items.length;
					for(i=0;i<n;i++){
						item=items[i];
						ext=pathLib.extname(item.name);
						if(ext===".pghtml"){
							try{
								docText=await tabFS.readFile("/-tabedit/playground/examples/"+item.name,"utf8");
								docJSON=JSON.parse(docText);
							}catch(err){
								docJSON=null;
							}
							if(docJSON){
								css={
									type:BtnCard(app,w-30,80,appCfg.sharedAssets+"/lab.svg",60,60,docJSON.name||item.name,docJSON.info||"Playground example.",txtSize.big,txtSize.small),
									position:"relative",x:"50%",y:0,margin:[0,0,10,0],anchorX:1,docText:docText,
									OnClick(){
										//TODO: Init with exmaples
									}
								};
								boxList.appendNewChild(css);
							}
						}
					}
				}
				break;
			}
			case "Recent":{
				let list,w;
				w=boxList.clientWidth;
				list=await app.docs.getUsage();
				list=list.reverse();
				list=list.filter(item=>item[0]==="/");
				list=list.filter(item=>{
					let ext=pathLib.extname(item);
					return ext===".aichat"||ext===".pghtml";
				});
				list=list.map(item=>{
					return {
						type:BtnCard(app,w-30,80,appCfg.sharedAssets+"/lab.svg",60,60,pathLib.basename(item),item,txtSize.big,txtSize.small),
						position:"relative",x:"50%",y:0,margin:[0,0,10,0],anchorX:1,docPath:item,
						OnClick(){
							//TODO: Load this doc:
							app.docs.openDoc(this.docPath);
							app.closeDlg(self);
						}
					};
				});
				if(!list.length){
					list.push({
						type:BtnCard(app,w-30,80,appCfg.sharedAssets+"/help.svg",60,60,"No Recent Docs","Playground can't find your recent docs.",txtSize.big,txtSize.small),
						position:"relative",x:"50%",y:0,margin:[0,0,10,0],anchorX:1,enable:false
					});
				}
				boxList.appendNewChild(list);
				break;
			}
			case "Community":{
				let list,w;
				w=boxList.clientWidth;
				boxList.appendNewChild({
					type:BtnCard(app,w-30,80,appCfg.sharedAssets+"/mark_work.svg",60,60,"Comming soon.","Community features is under development.",txtSize.big,txtSize.small),
					position:"relative",x:"50%",y:0,margin:[0,0,10,0],anchorX:1,enable:false
				});
				break;
			}
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.doNewAIChat=function(){
		app.docs.newEmptyDoc(".aichat");
		app.closeDlg(self);
	};
	
	//------------------------------------------------------------------------
	cssVO.doNewHTMLPen=function(){
		app.docs.newEmptyDoc(".pghtml");
		app.closeDlg(self);
	};
	/*}#1H0VIN5V71PostCSSVO*/
	return cssVO;
};
/*#{1H0VIN5V71ExCodes*/
/*}#1H0VIN5V71ExCodes*/


/*#{1H0VIN5V70EndDoc*/
/*}#1H0VIN5V70EndDoc*/

export default DlgNewPlayground;
export{DlgNewPlayground};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearBox",
//	"jaxId": "1H0VIN5V70",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1H0VIN5V72",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "800",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1H0VIN5V73",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1H64HL1P80",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1H0VIN5V74",
//			"attrs": {
//				"app": {
//					"type": "auto",
//					"valText": "{}"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1H0VIN5V75",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1H0VIN5V76",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1H0VIN5V77",
//			"attrs": {}
//		},
//		"mockupStates": {
//			"jaxId": "1IA30JVLG0",
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "box",
//			"jaxId": "1H0VIN5V71",
//			"attrs": {
//				"properties": {
//					"jaxId": "1H0VIN5V80",
//					"attrs": {
//						"type": "box",
//						"id": "",
//						"position": "Absolute",
//						"x": "50%",
//						"y": "100",
//						"w": "600",
//						"h": "600",
//						"anchorH": "Center",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "On",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "10",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"background": "[255,255,255,1.00]",
//						"border": "2",
//						"borderStyle": "Solid",
//						"borderColor": "[0,0,0,1.00]",
//						"corner": "6",
//						"shadow": "true",
//						"shadowX": "2",
//						"shadowY": "6",
//						"shadowBlur": "6",
//						"shadowSpread": "0",
//						"shadowColor": "[0,0,0,0.50]",
//						"contentLayout": "Flex Y"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1H0VIPPSC0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H0VIS1CK0",
//									"attrs": {
//										"type": "text",
//										"id": "",
//										"position": "Relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%-40",
//										"h": "\"\"",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#cfgColor.fontBodySub",
//										"text": {
//											"type": "string",
//											"valText": "创建新实验",
//											"localize": {
//												"EN": "NEW PLAYGROUND",
//												"CN": "创建新实验"
//											},
//											"localizable": true
//										},
//										"font": "",
//										"fontSize": "#txtSize.larger",
//										"bold": "true",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Top",
//										"wrap": "false",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0",
//										"autoSizeW": "false",
//										"autoSizeH": "false"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H0VIS1CK1",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1H0VIS1CK2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H0VIS1CK3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1H0VJBRAE0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H0VJHU3P0",
//									"attrs": {
//										"type": "hud",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[20,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex X",
//										"subAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/InfoCard.js",
//											"jaxId": "1H0VJBVLH0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1H0VJBVLH1",
//													"attrs": {
//														"title": {
//															"type": "string",
//															"valText": "AI聊天",
//															"localize": {
//																"EN": "AI Chat",
//																"CN": "AI聊天"
//															},
//															"localizable": true
//														},
//														"intro": {
//															"type": "string",
//															"valText": "优化AI聊天模板",
//															"localize": {
//																"EN": "Finetune AI Chat template",
//																"CN": "优化AI聊天模板"
//															},
//															"localizable": true
//														},
//														"pic": "#appCfg.sharedAssets+\"/aichat.svg\"",
//														"icon": "",
//														"picW": "80",
//														"picH": "0"
//													}
//												},
//												"properties": {
//													"jaxId": "1H0VJBVLH2",
//													"attrs": {
//														"type": "#null#>InfoCard((($ln===\"CN\")?(\"AI聊天\"):(\"AI Chat\")),(($ln===\"CN\")?(\"优化AI聊天模板\"):(\"Finetune AI Chat template\")),appCfg.sharedAssets+\"/aichat.svg\",\"\",80,0)",
//														"id": "",
//														"position": "Relative",
//														"x": "0",
//														"y": "50%",
//														"display": "On",
//														"face": "",
//														"anchorV": "Center",
//														"margin": "[0,30,0,0]",
//														"w": "240",
//														"h": {
//															"valText": "100"
//														},
//														"border": "2",
//														"corner": "12",
//														"sizeCap": "20",
//														"hideInfo": {
//															"valText": "false"
//														}
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1H0VJBVLH3",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1H0VJBVLH4",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1H10NFO9N0",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1H10NG2KP0",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1H0VJBVLH5",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1H64HL1P81",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/InfoCard.js",
//											"jaxId": "1H0VJC3QI0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1H0VJC3QI1",
//													"attrs": {
//														"title": {
//															"type": "string",
//															"valText": "HTML创意",
//															"localize": {
//																"EN": "HTML Idea",
//																"CN": "HTML创意"
//															},
//															"localizable": true
//														},
//														"intro": {
//															"type": "string",
//															"valText": "带有CSS和脚本的HTML片段。",
//															"localize": {
//																"EN": "HTML snippet with CSS and scripts.",
//																"CN": "带有CSS和脚本的HTML片段。"
//															},
//															"localizable": true
//														},
//														"pic": "#appCfg.sharedAssets+\"/web.svg\"",
//														"icon": "",
//														"picW": "80",
//														"picH": "0"
//													}
//												},
//												"properties": {
//													"jaxId": "1H0VJC3QI2",
//													"attrs": {
//														"type": "#null#>InfoCard((($ln===\"CN\")?(\"HTML创意\"):(\"HTML Idea\")),(($ln===\"CN\")?(\"带有CSS和脚本的HTML片段。\"):(\"HTML snippet with CSS and scripts.\")),appCfg.sharedAssets+\"/web.svg\",\"\",80,0)",
//														"id": "",
//														"position": "Relative",
//														"x": "0",
//														"y": "50%",
//														"display": "On",
//														"face": "",
//														"anchorV": "Center",
//														"enable": "false",
//														"w": "240",
//														"h": {
//															"valText": "100"
//														},
//														"border": "2",
//														"corner": "12",
//														"sizeCap": "20",
//														"hideInfo": {
//															"valText": "false"
//														}
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1H0VJC3QI3",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1H0VJC3QI4",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1H10NIBCG0",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1H10NJ0GC0",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1H0VJC3QI5",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1H64HL1P82",
//													"attrs": {}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1H0VJHU3P1",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1H0VJHU3P2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H0VJHU3P3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear/@StdUI/ui/BoxTabLine.js",
//							"jaxId": "1H10P80590",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1H10PDA9A0",
//									"attrs": {
//										"trkH": "24",
//										"tabSize": "128",
//										"tabs": "#[\n\t{\"text\":$ln===\"CN\"?\"AI聊天例子\":\"AI Samples\",\"msg\":\"AIExamples\",\"hot\":1},\n\t{\"text\":$ln===\"CN\"?\"HTML片段例子\":\"HTML Samples\",\"msg\":\"H5Examples\"},\n\t{\"text\":$ln===\"CN\"?\"最近项目\":\"Recent\",\"msg\":\"Recent\"},\n    {\"text\":$ln===\"CN\"?\"社区分享\":\"Community\",\"msg\":\"Community\"}\n]"
//									}
//								},
//								"properties": {
//									"jaxId": "1H10PDA9A1",
//									"attrs": {
//										"type": "#null#>BoxTabLine(24,128,[\n\t{\"text\":$ln===\"CN\"?\"AI聊天例子\":\"AI Samples\",\"msg\":\"AIExamples\",\"hot\":1},\n\t{\"text\":$ln===\"CN\"?\"HTML片段例子\":\"HTML Samples\",\"msg\":\"H5Examples\"},\n\t{\"text\":$ln===\"CN\"?\"最近项目\":\"Recent\",\"msg\":\"Recent\"},\n    {\"text\":$ln===\"CN\"?\"社区分享\":\"Community\",\"msg\":\"Community\"}\n])",
//										"id": "BoxTabs",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"display": "On",
//										"face": "",
//										"w": "100%",
//										"margin": "[10,0,0,0]"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H10PDA9A2",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1H10PDA9A3",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H10PDA9A4",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true",
//								"containerSlots": {
//									"jaxId": "1H64HL1P83",
//									"attrs": {}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1H0VJKMNF0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H0VJT0280",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxList",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Auto Scroll Y",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "10",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"flex": "true",
//										"contentLayout": "Flex Y",
//										"subAlign": "Start"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H0VJT0281",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1H0VJT0282",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H0VJT0283",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear/@StdUI/ui/BtnIcon.js",
//							"jaxId": "1H10MT61O0",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1H10MU2BC0",
//									"attrs": {
//										"style": "front",
//										"w": "32",
//										"h": "0",
//										"icon": "#appCfg.sharedAssets+\"/close.svg\"",
//										"colorBG": "null"
//									}
//								},
//								"properties": {
//									"jaxId": "1H10MU2BC1",
//									"attrs": {
//										"type": "#null#>BtnIcon(\"front\",32,0,appCfg.sharedAssets+\"/close.svg\",null)",
//										"id": "BtnClose",
//										"position": "Absolute",
//										"x": "554",
//										"y": "10",
//										"display": "On",
//										"face": "",
//										"padding": "1"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H10MU2BC2",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1H10MU2BC3",
//									"attrs": {
//										"OnClick": {
//											"type": "fixedFunc",
//											"jaxId": "1H10MU7U00",
//											"attrs": {
//												"callArgs": {
//													"jaxId": "1H10MV7BE0",
//													"attrs": {
//														"event": ""
//													}
//												},
//												"seg": ""
//											}
//										}
//									}
//								},
//								"extraPpts": {
//									"jaxId": "1H10MU2BC4",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false",
//								"containerSlots": {
//									"jaxId": "1H64HL1P84",
//									"attrs": {}
//								}
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1H0VIN5V81",
//					"attrs": {}
//				},
//				"functions": {
//					"jaxId": "1H0VIN5V82",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1H0VIN5V83",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1H0VIN5V84",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"background": "false",
//				"color": "false",
//				"gradient": "false",
//				"border": "false",
//				"borders": "false",
//				"borderStyle": "false",
//				"borderColor": "false",
//				"borderColors": "false",
//				"corner": "false",
//				"coner": "false",
//				"coners": "false",
//				"shadow": "false",
//				"shadowX": "false",
//				"shadowY": "false",
//				"shadowBlur": "false",
//				"shadowSpread": "false",
//				"shadowColor": "false",
//				"maskImage": "false",
//				"innerLayout": {
//					"valText": "false"
//				},
//				"marginL": {
//					"valText": "false"
//				},
//				"marginR": {
//					"valText": "false"
//				},
//				"marginT": {
//					"valText": "false"
//				},
//				"marginB": {
//					"valText": "false"
//				},
//				"paddingL": {
//					"valText": "false"
//				},
//				"paddingR": {
//					"valText": "false"
//				},
//				"paddingT": {
//					"valText": "false"
//				},
//				"paddingB": {
//					"valText": "false"
//				},
//				"attach": {
//					"valText": "false"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}