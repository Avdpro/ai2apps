//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnCheck} from "/@StdUI/ui/BtnCheck.js";
import {BtnText} from "/@StdUI/ui/BtnText.js";
/*#{1G9HB3FRN0StartDoc*/
import {FindInFiles,FindFile,FindLine} from "../lib/findfile.js";
import {BoxFindFile} from "./BoxFindFile.js";
import {BoxFindLine} from "./BoxFindLine.js";
/*}#1G9HB3FRN0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let TBXFindInFile=function(app,view){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1G9HB3FRN7LocalVals*/
	let appPrj,dataDocs;
	let listBox;
	/*}#1G9HB3FRN7LocalVals*/
	
	/*#{1G9HB3FRN7PreState*/
	/*}#1G9HB3FRN7PreState*/
	/*#{1G9HB3FRN7PostState*/
	/*}#1G9HB3FRN7PostState*/
	cssVO={
		"hash":"1G9HB3FRN7",nameHost:true,
		"type":"hud","x":0,"y":0,"w":"FW","h":"FH","autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
		children:[
			{
				"hash":"1G9L2OFDA0",
				"type":"hud","id":"BoxToolBtn","x":0,"y":0,"w":"FW","h":30,"autoLayout":true,"display":0,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
				children:[
					{
						"hash":"1G9L2P90K0",
						"type":"text","position":"relative","x":0,"y":0,"w":100,"h":"FH","margin":[0,0,0,3],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor.fontToolSub,
						"text":(($ln==="CN")?("在文件中查找:"):("Find in files:")),"fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
						"alignV":1,"autoW":true,
					}
				],
			},
			{
				"hash":"1G9LAT17S0",
				"type":"text","x":5,"y":10,"w":100,"h":txtSize.smallMid,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor.fontTool,"text":(($ln==="CN")?("查找:"):("Find:")),
				"fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
			},
			{
				"hash":"1G9LAUVDO0",
				"type":"edit","id":"EdFind","x":10,"y":30,"w":"FW-20","h":24,"autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","placeHolder":(($ln==="CN")?("要查找的文本"):("Text to find")),
				"color":cfgColor["fontBody"],"outline":0,"border":1,
				/*#{1G9LAUVDO0Codes*/
				OnUpdate:function(){
					self.doFind();
				}
				/*}#1G9LAUVDO0Codes*/
			},
			{
				"hash":"1G9LBC9TL0",
				"type":"hud","x":15,"y":55,"w":">calc(100% - 30px)","h":30,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x","itemsAlign":1,
				children:[
					{
						"hash":"1IA0VK2LU0",
						"type":BtnCheck(20,"",false,false),"id":"BtnCase","position":"relative","x":0,"y":0,"padding":2,
					},
					{
						"hash":"1G9LBEJ3H0",
						"type":"text","position":"relative","x":0,"y":0,"w":100,"h":"FH","margin":[0,10,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
						"text":(($ln==="CN")?("大小写"):("Case")),"fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,"autoW":true,
					},
					{
						"hash":"1IA0VJ37I0",
						"type":BtnCheck(20,"",false,false),"id":"BtnWord","position":"relative","x":0,"y":0,"padding":2,
					},
					{
						"hash":"1G9LBGFD20",
						"type":"text","position":"relative","x":0,"y":0,"w":100,"h":"FH","margin":[0,10,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
						"text":("Words"),"fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,"autoW":true,
					},
					{
						"hash":"1IA0VFTRT0",
						"type":BtnCheck(20,"",false,false),"id":"BtnRegex","position":"relative","x":0,"y":0,"padding":2,
					},
					{
						"hash":"1G9LBH2GG0",
						"type":"text","position":"relative","x":0,"y":0,"w":100,"h":"FH","margin":[0,10,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
						"text":(($ln==="CN")?("正则表达式"):("Regex")),"fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,
						"autoW":true,
					}
				],
			},
			{
				"hash":"1G9LBIM280",
				"type":"edit","id":"EdFilter","x":10,"y":85,"w":"FW-120","h":24,"autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","placeHolder":(($ln==="CN")?("文件类型过滤，例如：*.js;*.jsx"):("File filter, e.g: *.js;*.jsx")),
				"color":cfgColor["fontBody"],"outline":0,"border":1,
				/*#{1G9LBIM280Codes*/
				OnUpdate:function(){
					self.doFind();
				}
				/*}#1G9LBIM280Codes*/
			},
			{
				"hash":"1IA0VB0SM0",
				"type":BtnText("primary",90,24,(($ln==="CN")?("查找"):("Find")),false,""),"id":"BtnFind","x":">calc(100% - 100px)","y":85,
				/*#{1IA0VB0SM0Codes*/
				OnClick:function(){
					self.doFind();
				}
				/*}#1IA0VB0SM0Codes*/
			},
			{
				"hash":"1G9LBUK6I0",
				"type":"tree","id":"BoxList","x":10,"y":120,"w":"FW-20","h":"FH-185","autoLayout":true,"contentLayout":"flex-y","overflow":"auto-y","minW":"","minH":"",
				"maxW":"","maxH":"","styleClass":"",
				/*#{1G9LBUK6I0Codes*/
				nodeDef(obj,node){
					if(obj instanceof FindFile){
						return BoxFindFile(app,`${obj.path} (${obj.lines.length})`,node,listBox);
					}
					return {
						type:BoxFindLine(app,null,`Line ${obj.line}: ${obj.text}`,15),
						OnClick:function(){
							self.doShowLine(obj);
						}
					};
				},
				getSubObjs(obj,node){
					return obj.lines;
				}
				/*}#1G9LBUK6I0Codes*/
			},
			{
				"hash":"1G9LCASEU0",
				"type":"hud","id":"BoxReplace","x":0,"y":"FH-60","w":"FW","h":60,"display":0,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				children:[
					{
						"hash":"1G9LC4EDK0",
						"type":"text","x":5,"y":"FH-60","w":100,"h":txtSize.smallMid,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor.fontTool,"text":("Replace all with:"),
						"fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
					},
					{
						"hash":"1G9LC6PUN0",
						"type":"edit","id":"EdReplace","x":10,"y":"FH-40","w":"FW-120","h":20,"autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						"placeHolder":("Text to replace"),"color":[0,0,0],"outline":0,"border":1,
					},
					{
						"hash":"1IA0VMA580",
						"type":BtnText("primary",90,24,(($ln==="CN")?("查找"):("Find")),false,""),"id":"BtnReplace","x":">calc(100% - 100px)","y":">calc(100% - 43px)",
						/*#{1IA0VMA580Codes*/
						/*}#1IA0VMA580Codes*/
					},
					{
						"hash":"1G9LCEBEL0",
						"type":"box","x":10,"y":-5,"w":"FW-20","h":1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.fontToolSub,
					}
				],
			}
		],
		/*#{1G9HB3FRN7ExtraCSS*/
		/*}#1G9HB3FRN7ExtraCSS*/
		faces:{
			"clear":{
				/*BoxReplace*/"#1G9LCASEU0":{
					"display":0
				},
				/*#{1G9LE3P5M0Code*/
				$(){
					self.BoxList.clear();
				}
				/*}#1G9LE3P5M0Code*/
			},"find":{
				/*BoxReplace*/"#1G9LCASEU0":{
					"display":1
				}
			}
		},
		OnCreate:function(){
			self=this;
			
			/*#{1G9HB3FRN7Create*/
			appPrj=app.prj;
			dataDocs=appPrj.docs;
			listBox=self.BoxList;
			self.toolBtnBox=self.BoxToolBtn;
			self.toolBtnBox.hold();
			self.removeChild(self.toolBtnBox);
			self.toolBtnBox.h="FH";
			self.toolBtnBox.display=1;
			/*}#1G9HB3FRN7Create*/
		},
		/*#{1G9HB3FRN7EndCSS*/
		/*}#1G9HB3FRN7EndCSS*/
	};
	/*#{1G9HB3FRN7PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.doFind=async function(){
		let text2Find,options;
		let entryList;
		let fileNode=null;
		text2Find=self.EdFind.text;
		self.showFace("clear");
		if(!text2Find){
			return;
		}
		self.BtnFind.enable=0;
		options={
			useCase:self.BtnCase.checked,
			useWord:self.BtnWord.checked,
			useRegExp:self.BtnRegex.checked,
			filter:self.EdFilter.text
		}
		self.BoxList.clear();
		await FindInFiles(appPrj.path,text2Find,options,item=>{
			if(item instanceof FindFile){
				self.BoxList.addNode(item,null);
			}
		});
		self.BtnFind.enable=1;
	};
	
	//------------------------------------------------------------------------
	cssVO.doShowLine=async function(line){
		let file,lineIdx,doc,editor;
		file=line.file;
		line=line.line;
		doc=await dataDocs.openDoc(file.path);
		if(doc){
			dataDocs.focusDoc(doc);
			editor=doc.editBox;
			if(editor){
				editor.gotoLine(line);
			}
		}
	};
	/*}#1G9HB3FRN7PostCSSVO*/
	return cssVO;
};
/*#{1G9HB3FRN7ExCodes*/
TBXFindInFile.tbxCodeName="FindInFiles";
TBXFindInFile.tbxTip=(($ln==="CN")?("在文件中查找"):("Find in files"));
TBXFindInFile.tbxIcon=appCfg.sharedAssets+"/findfiles.svg";
TBXFindInFile.tbxIconPad=2;
TBXFindInFile.scoreDoc=function(doc){
	return 10;
};
/*}#1G9HB3FRN7ExCodes*/


/*#{1G9HB3FRN0EndDoc*/
/*}#1G9HB3FRN0EndDoc*/

export default TBXFindInFile;
export{TBXFindInFile};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1G9HB3FRN0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1G9HB3FRN1",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1G9HB3FRN2",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1H7J0DF0R0",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1G9HB3FRN3",
//			"attrs": {
//				"app": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"view": {
//					"type": "auto",
//					"valText": "null"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1G9HB3FRN4",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1G9HB3FRN5",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "VFACT document",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1G9HB3FRN6",
//			"attrs": {
//				"clear": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1G9LE3P5M0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1G9LE6L1B0",
//							"attrs": {}
//						}
//					}
//				},
//				"find": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1G9LE44I90",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1G9LE6L1B1",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1IA0VA1T30",
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1G9HB3FRN7",
//			"attrs": {
//				"properties": {
//					"jaxId": "1G9HB3FRN8",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "\"FW\"",
//						"h": "\"FH\"",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "true",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "[0,0,0,0]",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "\"\"",
//						"styleClass": "",
//						"contentLayout": "Flex Y"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1G9L2OFDA0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G9L2OFDA1",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxToolBtn",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "\"FW\"",
//										"h": "30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "true",
//										"display": "Off",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "\"\"",
//										"styleClass": "",
//										"contentLayout": "Flex X"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1G9L2P90K0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9L2RGVJ0",
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"w": "100",
//														"h": "\"FH\"",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[0,0,0,3]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "\"\"",
//														"styleClass": "",
//														"color": "#cfgColor.fontToolSub",
//														"text": {
//															"type": "string",
//															"valText": "在文件中查找:",
//															"localize": {
//																"EN": "Find in files:",
//																"CN": "在文件中查找:"
//															},
//															"localizable": true
//														},
//														"font": "",
//														"fontSize": "#txtSize.smallMid",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Center",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0",
//														"autoSizeW": "true",
//														"autoSizeH": "false"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1G9L2RGVJ1",
//													"attrs": {
//														"1G9LE44I90": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1G9LE6L1B2",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1G9LE6L1B3",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1G9LE44I90",
//															"faceTagName": "find"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1G9L2RGVJ2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1H7J0DF0R1",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1G9L2OFDB10",
//									"attrs": {
//										"1G9LE44I90": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9LE6L1B4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9LE6L1B5",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9LE44I90",
//											"faceTagName": "find"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1G9L2OFDB11",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H7J0DF0R2",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1G9LAT17S0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G9LBD5JK0",
//									"attrs": {
//										"type": "text",
//										"id": "",
//										"position": "Absolute",
//										"x": "5",
//										"y": "10",
//										"w": "100",
//										"h": "#txtSize.smallMid",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "\"\"",
//										"styleClass": "",
//										"color": "#cfgColor.fontTool",
//										"text": {
//											"type": "string",
//											"valText": "查找:",
//											"localize": {
//												"EN": "Find:",
//												"CN": "查找:"
//											},
//											"localizable": true
//										},
//										"font": "",
//										"fontSize": "#txtSize.smallMid",
//										"bold": "false",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Top",
//										"wrap": "false",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0",
//										"autoSizeW": "false",
//										"autoSizeH": "false"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1G9LBD5JK1",
//									"attrs": {
//										"1G9LE44I90": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9LE6L1C0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9LE6L1C1",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9LE44I90",
//											"faceTagName": "find"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1G9LBD5JK2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H7J0DF0R3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "edit",
//							"jaxId": "1G9LAUVDO0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G9LBD5JK3",
//									"attrs": {
//										"type": "edit",
//										"id": "EdFind",
//										"position": "Absolute",
//										"x": "10",
//										"y": "30",
//										"w": "\"FW-20\"",
//										"h": "24",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "true",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "\"\"",
//										"styleClass": "",
//										"inputType": "Text",
//										"text": "",
//										"placeHolder": {
//											"type": "string",
//											"valText": "要查找的文本",
//											"localize": {
//												"EN": "Text to find",
//												"CN": "要查找的文本"
//											},
//											"localizable": true
//										},
//										"color": "#cfgColor[\"fontBody\"]",
//										"bgColor": "[255,255,255,1.00]",
//										"font": "",
//										"fontSize": "16",
//										"outline": "0",
//										"border": "1",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"selectOnFocus": "true",
//										"spellCheck": "true"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1G9LBD5JK4",
//									"attrs": {
//										"1G9LE44I90": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9LE6L1C2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9LE6L1C3",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9LE44I90",
//											"faceTagName": "find"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1G9LBD5JK5",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H7J0DF0R4",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "true",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1G9LBC9TL0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G9LBD5JK6",
//									"attrs": {
//										"type": "hud",
//										"id": "",
//										"position": "Absolute",
//										"x": "15",
//										"y": "55",
//										"w": "100%-30",
//										"h": "30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "\"\"",
//										"styleClass": "",
//										"contentLayout": "Flex X",
//										"itemsAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnCheck.js",
//											"jaxId": "1IA0VK2LU0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1IA0VK2LU1",
//													"attrs": {
//														"size": "20",
//														"text": "",
//														"checked": "false",
//														"radio": "false"
//													}
//												},
//												"properties": {
//													"jaxId": "1IA0VK2LU2",
//													"attrs": {
//														"type": "#null#>BtnCheck(20,\"\",false,false)",
//														"id": "BtnCase",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"padding": "2"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IA0VK2LU3",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1IA0VK2LU4",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IA0VK2LU5",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1IA0VK2LU6",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1G9LBEJ3H0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9LBGE8K0",
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"w": "100",
//														"h": "\"FH\"",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[0,10,0,0]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "\"\"",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBody\"]",
//														"text": {
//															"type": "string",
//															"valText": "大小写",
//															"localize": {
//																"EN": "Case",
//																"CN": "大小写"
//															},
//															"localizable": true
//														},
//														"font": "",
//														"fontSize": "#txtSize.smallMid",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Center",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0",
//														"autoSizeW": "true",
//														"autoSizeH": "false"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1G9LBGE8K1",
//													"attrs": {
//														"1G9LE44I90": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1G9LE6L1C6",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1G9LE6L1C7",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1G9LE44I90",
//															"faceTagName": "find"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1G9LBGE8K2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1H7J0DF0R7",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnCheck.js",
//											"jaxId": "1IA0VJ37I0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1IA0VJ37I1",
//													"attrs": {
//														"size": "20",
//														"text": "",
//														"checked": "false",
//														"radio": "false"
//													}
//												},
//												"properties": {
//													"jaxId": "1IA0VJ37I2",
//													"attrs": {
//														"type": "#null#>BtnCheck(20,\"\",false,false)",
//														"id": "BtnWord",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"padding": "2"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IA0VJ37I3",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1IA0VJ37I4",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IA0VJ37I5",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1IA0VJ37I6",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1G9LBGFD20",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9LBGFD21",
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"w": "100",
//														"h": "\"FH\"",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[0,10,0,0]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "\"\"",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBody\"]",
//														"text": {
//															"type": "string",
//															"valText": "Words",
//															"localize": {
//																"EN": "Words"
//															},
//															"localizable": true
//														},
//														"font": "",
//														"fontSize": "#txtSize.smallMid",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Center",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0",
//														"autoSizeW": "true",
//														"autoSizeH": "false"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1G9LBGFD22",
//													"attrs": {
//														"1G9LE44I90": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1G9LE6L1C10",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1G9LE6L1C11",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1G9LE44I90",
//															"faceTagName": "find"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1G9LBGFD23",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1H7J0DF0S0",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnCheck.js",
//											"jaxId": "1IA0VFTRT0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1IA0VJ1PU0",
//													"attrs": {
//														"size": "20",
//														"text": "",
//														"checked": "false",
//														"radio": "false"
//													}
//												},
//												"properties": {
//													"jaxId": "1IA0VJ1PU1",
//													"attrs": {
//														"type": "#null#>BtnCheck(20,\"\",false,false)",
//														"id": "BtnRegex",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"padding": "2"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IA0VJ1PU2",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1IA0VJ1PU3",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IA0VJ1PU4",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1IA0VJ1PU5",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1G9LBH2GG0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9LBH2GG1",
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"w": "100",
//														"h": "\"FH\"",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[0,10,0,0]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "\"\"",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBody\"]",
//														"text": {
//															"type": "string",
//															"valText": "正则表达式",
//															"localize": {
//																"EN": "Regex",
//																"CN": "正则表达式"
//															},
//															"localizable": true
//														},
//														"font": "",
//														"fontSize": "#txtSize.smallMid",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Center",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0",
//														"autoSizeW": "true",
//														"autoSizeH": "false"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1G9LBH2GG2",
//													"attrs": {
//														"1G9LE44I90": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1G9LE6L1C14",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1G9LE6L1C15",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1G9LE44I90",
//															"faceTagName": "find"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1G9LBH2GG3",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1H7J0DF0S3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1G9LBD5JK7",
//									"attrs": {
//										"1G9LE44I90": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9LE6L1C16",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9LE6L1C17",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9LE44I90",
//											"faceTagName": "find"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1G9LBD5JK8",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H7J0DF0S4",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "edit",
//							"jaxId": "1G9LBIM280",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G9LBIM281",
//									"attrs": {
//										"type": "edit",
//										"id": "EdFilter",
//										"position": "Absolute",
//										"x": "10",
//										"y": "85",
//										"w": "\"FW-120\"",
//										"h": "24",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "true",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "\"\"",
//										"styleClass": "",
//										"inputType": "Text",
//										"text": "",
//										"placeHolder": {
//											"type": "string",
//											"valText": "文件类型过滤，例如：*.js;*.jsx",
//											"localize": {
//												"EN": "File filter, e.g: *.js;*.jsx",
//												"CN": "文件类型过滤，例如：*.js;*.jsx"
//											},
//											"localizable": true
//										},
//										"color": "#cfgColor[\"fontBody\"]",
//										"bgColor": "[255,255,255,1.00]",
//										"font": "",
//										"fontSize": "16",
//										"outline": "0",
//										"border": "1",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"selectOnFocus": "true",
//										"spellCheck": "true"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1G9LBIM282",
//									"attrs": {
//										"1G9LE44I90": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9LE6L1C18",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9LE6L1C19",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9LE44I90",
//											"faceTagName": "find"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1G9LBIM283",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H7J0DF0S5",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "true",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear/@StdUI/ui/BtnText.js",
//							"jaxId": "1IA0VB0SM0",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1IA0VE6LA0",
//									"attrs": {
//										"style": "primary",
//										"w": "90",
//										"h": "24",
//										"text": {
//											"type": "string",
//											"valText": "查找",
//											"localize": {
//												"EN": "Find",
//												"CN": "查找"
//											},
//											"localizable": true
//										},
//										"outlined": "false",
//										"icon": ""
//									}
//								},
//								"properties": {
//									"jaxId": "1IA0VE6LA1",
//									"attrs": {
//										"type": "#null#>BtnText(\"primary\",90,24,(($ln===\"CN\")?(\"查找\"):(\"Find\")),false,\"\")",
//										"id": "BtnFind",
//										"position": "Absolute",
//										"x": "100%-100",
//										"y": "85",
//										"display": "On",
//										"face": ""
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1IA0VE6LA2",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1IA0VE6LA3",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IA0VE6LA4",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "true",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false",
//								"containerSlots": {
//									"jaxId": "1IA0VE6LA5",
//									"attrs": {
//										"Slot1H2F6U36O0": {
//											"jaxId": "1IA0VE6LA6",
//											"attrs": {
//												"subHuds": {
//													"attrs": []
//												},
//												"container": "true"
//											}
//										}
//									}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "TreeBox",
//							"jaxId": "1G9LBUK6I0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G9LC6M0T0",
//									"attrs": {
//										"type": "tree",
//										"id": "BoxList",
//										"position": "Absolute",
//										"x": "10",
//										"y": "120",
//										"w": "\"FW-20\"",
//										"h": "\"FH-185\"",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "true",
//										"display": "On",
//										"contentLayout": "flex-y",
//										"clip": "Auto Scroll Y",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "\"\"",
//										"styleClass": ""
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1G9LC6M0T1",
//									"attrs": {
//										"1G9LE44I90": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9LE6L1C22",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9LE6L1C23",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9LE44I90",
//											"faceTagName": "find"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1G9LC6M0T2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H7J0DF0S8",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "true",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1G9LCASEU0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G9LCGIBF0",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxReplace",
//										"position": "Absolute",
//										"x": "0",
//										"y": "\"FH-60\"",
//										"w": "\"FW\"",
//										"h": "60",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "Off",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "\"\"",
//										"styleClass": ""
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1G9LC4EDK0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9LC4EDK1",
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "Absolute",
//														"x": "5",
//														"y": "\"FH-60\"",
//														"w": "100",
//														"h": "#txtSize.smallMid",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[0,0,0,0]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "\"\"",
//														"styleClass": "",
//														"color": "#cfgColor.fontTool",
//														"text": {
//															"type": "string",
//															"valText": "Replace all with:",
//															"localize": {
//																"EN": "Replace all with:"
//															},
//															"localizable": true
//														},
//														"font": "",
//														"fontSize": "#txtSize.smallMid",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0",
//														"autoSizeW": "false",
//														"autoSizeH": "false"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1G9LC4EDK2",
//													"attrs": {
//														"1G9LE44I90": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1G9LE6L1C24",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1G9LE6L1C25",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1G9LE44I90",
//															"faceTagName": "find"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1G9LC4EDK3",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1H7J0DF0S9",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "edit",
//											"jaxId": "1G9LC6PUN0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9LC6PUN1",
//													"attrs": {
//														"type": "edit",
//														"id": "EdReplace",
//														"position": "Absolute",
//														"x": "10",
//														"y": "\"FH-40\"",
//														"w": "\"FW-120\"",
//														"h": "20",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "true",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[0,0,0,0]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "\"\"",
//														"styleClass": "",
//														"inputType": "Text",
//														"text": "",
//														"placeHolder": {
//															"type": "string",
//															"valText": "Text to replace",
//															"localize": {
//																"EN": "Text to replace"
//															},
//															"localizable": true
//														},
//														"color": "[0,0,0]",
//														"bgColor": "[255,255,255,1.00]",
//														"font": "",
//														"fontSize": "16",
//														"outline": "0",
//														"border": "1",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"selectOnFocus": "true",
//														"spellCheck": "true"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1G9LC6PUO0",
//													"attrs": {
//														"1G9LE44I90": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1G9LE6L1C26",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1G9LE6L1C27",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1G9LE44I90",
//															"faceTagName": "find"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1G9LC6PUO1",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1H7J0DF0S10",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnText.js",
//											"jaxId": "1IA0VMA580",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1IA0VMA581",
//													"attrs": {
//														"style": "primary",
//														"w": "90",
//														"h": "24",
//														"text": {
//															"type": "string",
//															"valText": "查找",
//															"localize": {
//																"EN": "Find",
//																"CN": "查找"
//															},
//															"localizable": true
//														},
//														"outlined": "false",
//														"icon": ""
//													}
//												},
//												"properties": {
//													"jaxId": "1IA0VMA582",
//													"attrs": {
//														"type": "#null#>BtnText(\"primary\",90,24,(($ln===\"CN\")?(\"查找\"):(\"Find\")),false,\"\")",
//														"id": "BtnReplace",
//														"position": "Absolute",
//														"x": "100%-100",
//														"y": "100%-43",
//														"display": "On",
//														"face": ""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IA0VMA590",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1IA0VMA591",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IA0VMA592",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "true",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1IA0VMA593",
//													"attrs": {
//														"Slot1H2F6U36O0": {
//															"jaxId": "1IA0VMA594",
//															"attrs": {
//																"subHuds": {
//																	"attrs": []
//																},
//																"container": "true"
//															}
//														}
//													}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1G9LCEBEL0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9LCGIBF1",
//													"attrs": {
//														"type": "box",
//														"id": "",
//														"position": "Absolute",
//														"x": "10",
//														"y": "-5",
//														"w": "\"FW-20\"",
//														"h": "1",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[0,0,0,0]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "\"\"",
//														"styleClass": "",
//														"background": "#cfgColor.fontToolSub",
//														"border": "0",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1G9LCGIBF2",
//													"attrs": {
//														"1G9LE44I90": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1G9LE6L1C30",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1G9LE6L1C31",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1G9LE44I90",
//															"faceTagName": "find"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1G9LCGIBF3",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1H7J0DF0S13",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1G9LCGIBF4",
//									"attrs": {
//										"1G9LE44I90": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9LE6L1C32",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9LE6L1C33",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9LE44I90",
//											"faceTagName": "find"
//										},
//										"1G9LE3P5M0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9LE6L1C34",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9LE6L1C35",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9LE3P5M0",
//											"faceTagName": "clear"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1G9LCGIBF5",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H7J0DF0S14",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1G9HB3FRN9",
//					"attrs": {
//						"1G9LE44I90": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1G9LE6L1C36",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G9LE6L1C37",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1G9LE44I90",
//							"faceTagName": "find"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1G9HB3FRN10",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1H7J0DF0S15",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1G9HB3FRN11",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"innerLayout": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"face": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"marginL": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"marginR": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"marginT": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"marginB": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"paddingL": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"paddingT": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"paddingR": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"paddingB": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"attach": {
//					"type": "bool",
//					"valText": "false"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}