//Auto genterated by Cody
import {$P,VFACT,callAfter} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1G9HCQVCC0StartDoc*/
import {BoxFindLine} from "./BoxFindLine.js";
import markdownit from "/@markdownit";
import pathLib from "/@path";
import {tabFS} from "/@tabos";
/*}#1G9HCQVCC0StartDoc*/
const $ln=appCfg.lanCode||"EN";
//----------------------------------------------------------------------------
let TBXBookMark=function(app){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1G9HCQVCD1LocalVals*/
	let appPrj,dataDocs;
	let isFocused=0;
	let listBox,tipBox;
	let mode,modState=null;
	/*}#1G9HCQVCD1LocalVals*/
	
	/*#{1G9HCQVCD1PreState*/
	/*}#1G9HCQVCD1PreState*/
	/*#{1G9HCQVCD1PostState*/
	/*}#1G9HCQVCD1PostState*/
	cssVO={
		"hash":"1G9HCQVCD1",nameHost:true,
		"type":"hud","x":0,"y":0,"w":"FW","h":"FH","autoLayout":true,"overflow":"hidden scroll","styleClass":"","contentLayout":"flex-y",
		children:[
			{
				"hash":"1G9M1OR9A0",
				"type":"hud","id":"BoxToolBtn","x":0,"y":0,"w":"FW","h":30,"autoLayout":true,"display":0,"styleClass":"","contentLayout":"flex-x",
				children:[
					{
						"hash":"1G9M1OR9A2",
						"type":"text","position":"relative","x":0,"y":0,"w":100,"h":"FH","margin":[0,0,0,3],"styleClass":"","color":cfgColor.fontToolSub,"text":(($ln==="CN")?("书签和待办事项"):("Bookmarks and Todo")),
						"fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,"autoW":true,
					}
				],
			},
			{
				"hash":"1G9M6RNHA0",
				"type":"text","position":"relative","x":10,"y":0,"w":"FW-20","h":20,"margin":[10,0,5,0],"styleClass":"","color":cfgColor.fontToolSub,"text":(($ln==="CN")?("书签和待办事项："):("Book marks and todo:")),
				"fontSize":txtSize.mid,"fontWeight":"bold","fontStyle":"normal","textDecoration":"",
			},
			{
				"hash":"1G9M6U83J0",
				"type":"hud","id":"ListBox","position":"relative","x":10,"y":0,"w":"FW-20","h":"","autoLayout":true,"styleClass":"","contentLayout":"flex-y",
			},
			{
				"hash":"1G9M7056O0",
				"type":"hud","id":"BoxTip","position":"relative","x":10,"y":0,"w":"FW-20","h":100,"autoLayout":true,"alpha":0.5,"styleClass":"",
			}
		],
		/*#{1G9HCQVCD1ExtraCSS*/
		/*}#1G9HCQVCD1ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			self=this;
			
			/*#{1G9HCQVCD1Create*/
			appPrj=app.prj;
			dataDocs=appPrj.docs;
			self.toolBtnBox=self.BoxToolBtn;
			self.toolBtnBox.hold();
			self.removeChild(self.toolBtnBox);
			self.toolBtnBox.h="FH";
			self.toolBtnBox.display=1;
			listBox=self.ListBox;
			tipBox=self.BoxTip;
			//TODO: set tip info:
			//load and show tips:
			let showTip=async function(){
				let dir,path;
				dir=app.appDir;
				dir=dir.startsWith("//")?dir.substring(1):dir;
				path=pathLib.join(dir,(($ln==="CN")?("marks_cn.md"):("marks.md")));
				try{
					let text=await tabFS.readFile(path,"utf8");
					text=markdownit().render(text);
					tipBox.webObj.style.fontSize="12px";
					tipBox.webObj.innerHTML=text;
				}catch(err){
					console.error(err);
				}
			}
			showTip();
			/*}#1G9HCQVCD1Create*/
		},
		/*#{1G9HCQVCD1EndCSS*/
		/*}#1G9HCQVCD1EndCSS*/
	};
	/*#{1G9HCQVCD1PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.OnShow=function(){
		dataDocs.on("FocusDoc",self.showMarks);
		dataDocs.on("DocSaved",self.showMarks);
		self.showMarks();
		isFocused=1;
	};
	
	//------------------------------------------------------------------------
	cssVO.OnHide=function(){
		dataDocs.off("FocusDoc",self.showMarks);
		dataDocs.off("DocSaved",self.showMarks);
		isFocused=0;
	};
	
	//------------------------------------------------------------------------
	cssVO.showMarks=function(){
		let curDoc,cnt,source,lines,style,info;
		curDoc=dataDocs.hotDoc;
		listBox.clearChildren();
		if(!curDoc){
			tipBox.display=1;
			return;
		}
		if(!mode){
			mode = CodeMirror.getMode(CodeMirror.defaults, "javascript");
			if(!mode.name){
				mode=null;
				return;
			}
		}
		modState=CodeMirror.startState(mode);
		cnt=0;
		if(curDoc){
			source=curDoc.getDocText();
			lines= CodeMirror.splitLines(source);
			for (var i = 0, e = lines.length; i < e; ++i) {
				var stream = new CodeMirror.StringStream(lines[i], null, {
					lookAhead: function(n) { return lines[i + n]; },
					baseToken: function() {}
				});
				while (!stream.eol()) {
					style = mode.token(stream, modState);
					if(style==="todo"){
						info=stream.current().trim();
						info=info.substring(2).trim();
						listBox.appendNewChild({
							type:BoxFindLine(app,appCfg.sharedAssets+"/todo.svg",`${info}`,0),position:"relative",line:i,
							OnClick:function(){
								self.showLine(curDoc,this.line+1);
							}
						});
						cnt++;
					}else if(style==="bookmark"){
						let pos;
						info=stream.current().trim();
						info=info.substring(3).trim();
						pos=info.indexOf(":");
						if(pos>0){
							info=info.substring(0,pos).trim();
						}
						listBox.appendNewChild({
							type:BoxFindLine(app,appCfg.sharedAssets+"/mark.svg",`${info}`,0),position:"relative",line:i,
							OnClick:function(){
								self.showLine(curDoc,this.line+1);
							}
						});
						cnt++;
					}
					stream.start = stream.pos;
				}
			}
		}
		if(cnt<5){
			tipBox.display=1;
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.showLine=function(doc,line){
		let editor;
		dataDocs.focusDoc(doc);
		editor=doc.editBox;
		if(editor){
			editor.gotoLine(line);
		}
	};
	/*}#1G9HCQVCD1PostCSSVO*/
	return cssVO;
};
/*#{1G9HCQVCD1ExCodes*/
TBXBookMark.tbxCodeName="BookMark";
TBXBookMark.tbxTip=(($ln==="CN")?("书签/待办"):("Bookmarks"));
TBXBookMark.tbxIcon=appCfg.sharedAssets+"/flag.svg";
TBXBookMark.tbxIconPad=2;
TBXBookMark.scoreDoc=function(doc){
	return 10;
};
/*}#1G9HCQVCD1ExCodes*/


export default TBXBookMark;
export{TBXBookMark};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1G9HCQVCC0",
//	"editVersion": 22,
//	"attrs": {
//		"editEnv": {
//			"type": "object",
//			"jaxId": "1G9HCQVCC1",
//			"editVersion": 5,
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"type": "object",
//			"jaxId": "1G9HCQVCC2",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"model": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1H7J0M46J0",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"createArgs": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1G9HCQVCC3",
//			"editVersion": 2,
//			"attrs": {
//				"app": {
//					"type": "auto",
//					"valText": "null"
//				}
//			}
//		},
//		"localVars": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1G9HCQVCC4",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"type": "object",
//			"def": "StateObj",
//			"jaxId": "1G9HCQVCC5",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"exportTarget": "VFACT document",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"type": "object",
//			"def": "FaceTags",
//			"jaxId": "1G9HCQVCD0",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1G9HCQVCD1",
//			"editVersion": 7,
//			"attrs": {
//				"properties": {
//					"type": "object",
//					"jaxId": "1G9HCQVCD2",
//					"editVersion": 51,
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "\"FW\"",
//						"h": "\"FH\"",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "true",
//						"display": "On",
//						"clip": "Scroll Y",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "[0,0,0,0]",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "\"\"",
//						"styleClass": "",
//						"contentLayout": "Flex Y"
//					}
//				},
//				"subHuds": {
//					"type": "array",
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1G9M1OR9A0",
//							"editVersion": 8,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1G9M1OR9A1",
//									"editVersion": 52,
//									"attrs": {
//										"type": "hud",
//										"id": "BoxToolBtn",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "\"FW\"",
//										"h": "30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "true",
//										"display": "Off",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "\"\"",
//										"styleClass": "",
//										"contentLayout": "Flex X"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1G9M1OR9A2",
//											"editVersion": 7,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1G9M1OR9A3",
//													"editVersion": 66,
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"w": "100",
//														"h": "\"FH\"",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[0,0,0,3]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "\"\"",
//														"styleClass": "",
//														"color": "#cfgColor.fontToolSub",
//														"text": {
//															"type": "string",
//															"valText": "Bookmarks and Todo",
//															"localize": {
//																"EN": "Bookmarks and Todo",
//																"CN": "书签和待办事项"
//															},
//															"localizable": true
//														},
//														"font": "",
//														"fontSize": "#txtSize.smallMid",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Center",
//														"autoSizeW": "true",
//														"autoSizeH": "false",
//														"wrap": "false",
//														"ellipsis": "false",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1G9M1OR9A4",
//													"editVersion": 15,
//													"attrs": {}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1G9M1OR9B0",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1H7J0M46J1",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1G9M1OR9B1",
//									"editVersion": 15,
//									"attrs": {}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1G9M1OR9B4",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1H7J0M46J2",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1G9M6RNHA0",
//							"editVersion": 7,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1G9M76I140",
//									"editVersion": 66,
//									"attrs": {
//										"type": "text",
//										"id": "",
//										"position": "Relative",
//										"x": "10",
//										"y": "0",
//										"w": "\"FW-20\"",
//										"h": "20",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[10,0,5,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "\"\"",
//										"styleClass": "",
//										"color": "#cfgColor.fontToolSub",
//										"text": {
//											"type": "string",
//											"valText": "Book marks and todo:",
//											"localize": {
//												"EN": "Book marks and todo:",
//												"CN": "书签和待办事项："
//											},
//											"localizable": true
//										},
//										"font": "",
//										"fontSize": "#txtSize.mid",
//										"bold": "true",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Top",
//										"autoSizeW": "false",
//										"autoSizeH": "false",
//										"wrap": "false",
//										"ellipsis": "false",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1G9M76I141",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1G9M76I142",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1H7J0M46J3",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1G9M6U83J0",
//							"editVersion": 8,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1G9M6UGPI0",
//									"editVersion": 53,
//									"attrs": {
//										"type": "hud",
//										"id": "ListBox",
//										"position": "Relative",
//										"x": "10",
//										"y": "0",
//										"w": "\"FW-20\"",
//										"h": "\"\"",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "true",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "\"\"",
//										"styleClass": "",
//										"contentLayout": "Flex Y"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1G9M6UGPI1",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1G9M6UGPI2",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1H7J0M46J4",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1G9M7056O0",
//							"editVersion": 8,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1G9M76I143",
//									"editVersion": 219,
//									"attrs": {
//										"type": "hud",
//										"id": "BoxTip",
//										"position": "Relative",
//										"x": "10",
//										"y": "0",
//										"w": "\"FW-20\"",
//										"h": "100",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "true",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "0.50",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "\"\"",
//										"styleClass": ""
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1G9M76I144",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1G9M76I145",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1H7J0M46J5",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"type": "object",
//					"jaxId": "1G9HCQVCD3",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"functions": {
//					"type": "object",
//					"jaxId": "1G9HCQVCD4",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"extraPpts": {
//					"type": "object",
//					"def": "Object",
//					"jaxId": "1H7J0M46J6",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1G9HCQVCD5",
//			"editVersion": 34,
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"innerLayout": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"face": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"marginL": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"marginR": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"marginT": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"marginB": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"paddingL": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"paddingT": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"paddingR": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"paddingB": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"attach": {
//					"type": "bool",
//					"valText": "false"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}