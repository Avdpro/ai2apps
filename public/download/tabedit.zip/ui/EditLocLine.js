//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnCheck} from "/@StdUI/ui/BtnCheck.js";
/*#{1GURHE9VJ0StartDoc*/
/*}#1GURHE9VJ0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let EditLocLine=function(app){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let txtCode,edText,btnUse;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1GURHE9VJ1LocalVals*/
	let localize,isMemoText;
	/*}#1GURHE9VJ1LocalVals*/
	
	/*#{1GURHE9VJ1PreState*/
	/*}#1GURHE9VJ1PreState*/
	/*#{1GURHE9VJ1PostState*/
	/*}#1GURHE9VJ1PostState*/
	cssVO={
		"hash":"1GURHE9VJ1",nameHost:true,
		"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":"","margin":[0,0,5,0],"padding":[5,0,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
		"contentLayout":"flex-y",
		children:[
			{
				"hash":"1GURHH8070",
				"type":"text","id":"TxtCode","x":0,"y":0,"w":40,"h":30,"margin":[0,5,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
				"text":"EN:","fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignH":2,"alignV":1,
			},
			{
				"hash":"1GUROLV2R0",
				"type":"memo","id":"EdText","position":"relative","x":45,"y":0,"w":">calc(100% - 75px)","h":"","padding":3,"minW":"","minH":20,"maxW":"","maxH":100,
				"styleClass":"","color":cfgColor["fontBody"],"fontSize":txtSize.smallMid,"border":[0,0,1,0],"borderColor":[0,0,0,1],
				"OnFocus":function(event){
					/*#{1GUSLC4TN0FunctionBody*/
					self.OnLineFocus(self);
					/*}#1GUSLC4TN0FunctionBody*/
				},
				"OnInput":function(){
					/*#{1GUVG7DR00FunctionBody*/
					self.OnChanged();
					/*}#1GUVG7DR00FunctionBody*/
				},
			},
			{
				"hash":"1IA118QMC0",
				"type":BtnCheck(20,"",true,false),"id":"BtnUse","x":">calc(100% - 25px)","y":15,"padding":2,"anchorY":1,
				/*#{1IA118QMC0Codes*/
				OnCheck(check){
					self.showFace(check?"on":"off");
					self.OnChanged(true);
				}
				/*}#1IA118QMC0Codes*/
			}
		],
		/*#{1GURHE9VJ1ExtraCSS*/
		/*}#1GURHE9VJ1ExtraCSS*/
		faces:{
			"on":{
				/*TxtCode*/"#1GURHH8070":{
					"alpha":1,"color":cfgColor["fontBody"]
				},
				/*EdText*/"#1GUROLV2R0":{
					"readOnly":false
				}
			},"off":{
				/*TxtCode*/"#1GURHH8070":{
					"alpha":0.5
				},
				/*EdText*/"#1GUROLV2R0":{
					"readOnly":true
				}
			}
		},
		OnCreate:function(){
			self=this;
			txtCode=self.TxtCode;edText=self.EdText;btnUse=self.BtnUse;
			/*#{1GURHE9VJ1Create*/
			/*}#1GURHE9VJ1Create*/
		},
		/*#{1GURHE9VJ1EndCSS*/
		/*}#1GURHE9VJ1EndCSS*/
	};
	/*#{1GURHE9VJ1PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.startEdit=function(attr,lanCode){
		self.lanCode=lanCode;
		localize=attr?(attr.localize||{}):{};
		txtCode.text=lanCode+":";
		if(lanCode==="EN"){
			btnUse.checked=true;
			edText.text=(""+localize[lanCode])||"";
			self.showFace("on");
		}else if((lanCode in localize)&& (localize[lanCode]!==undefined)){
			btnUse.checked=true;
			edText.text=(""+localize[lanCode])||"";
			self.showFace("on");
		}else{
			btnUse.checked=false;
			edText.text="";
			self.showFace("false");
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.isChecked=function(){
		return btnUse.checked;
	};
	
	//------------------------------------------------------------------------
	cssVO.getText=function(){
		if(!btnUse.checked)
			return;//undefined
		return edText.text;
	};
	
	//------------------------------------------------------------------------
	cssVO.setText=function(text){
		edText.text=text;
	};
	/*}#1GURHE9VJ1PostCSSVO*/
	return cssVO;
};
/*#{1GURHE9VJ1ExCodes*/
/*}#1GURHE9VJ1ExCodes*/


/*#{1GURHE9VJ0EndDoc*/
/*}#1GURHE9VJ0EndDoc*/

export default EditLocLine;
export{EditLocLine};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1GURHE9VJ0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1GURHE9VJ2",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1GURHE9VJ3",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1H82QP69Q0",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1GURHE9VJ4",
//			"attrs": {
//				"app": {
//					"type": "auto",
//					"valText": "{}"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1GURHE9VJ5",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1GURHE9VJ6",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1GURHE9VJ7",
//			"attrs": {
//				"on": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1GUROQPMB0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1GUROT68A0",
//							"attrs": {}
//						}
//					}
//				},
//				"off": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1GUROQUSN0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1GUROT68A1",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1IA11BEPA0",
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1GURHE9VJ1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1GURHE9VJ8",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Relative",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "\"\"",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "[0,0,5,0]",
//						"padding": "[5,0,0,0]",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Flex Y"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1GURHH8070",
//							"attrs": {
//								"properties": {
//									"jaxId": "1GURIB8G30",
//									"attrs": {
//										"type": "text",
//										"id": "TxtCode",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "40",
//										"h": "30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,5,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#cfgColor[\"fontBody\"]",
//										"text": "EN:",
//										"font": "",
//										"fontSize": "#txtSize.smallMid",
//										"bold": "false",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Right",
//										"alignV": "Center",
//										"wrap": "false",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0",
//										"autoSizeW": "false",
//										"autoSizeH": "false"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1GURIB8G31",
//									"attrs": {
//										"1GUROQPMB0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1GUROT68A2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1GUROT68A3",
//													"attrs": {
//														"alpha": {
//															"type": "number",
//															"valText": "1",
//															"editMode": "range",
//															"editType": "range"
//														},
//														"color": "#cfgColor[\"fontBody\"]"
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1GUROQPMB0",
//											"faceTagName": "on"
//										},
//										"1GUROQUSN0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1GUROT68A4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1GUROT68A5",
//													"attrs": {
//														"alpha": {
//															"type": "number",
//															"valText": "0.5",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1GUROQUSN0",
//											"faceTagName": "off"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1GURIB8G32",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1GURIB8G33",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "memo",
//							"jaxId": "1GUROLV2R0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1GUROOAFI0",
//									"attrs": {
//										"type": "memo",
//										"id": "EdText",
//										"position": "relative",
//										"x": "45",
//										"y": "0",
//										"w": "100%-75",
//										"h": "\"\"",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "3",
//										"minW": "",
//										"minH": "20",
//										"maxW": "",
//										"maxH": "100",
//										"face": "",
//										"styleClass": "",
//										"text": "",
//										"color": "#cfgColor[\"fontBody\"]",
//										"bgColor": "[255,255,255,1.00]",
//										"font": "",
//										"fontSize": "#txtSize.smallMid",
//										"outline": "1",
//										"border": "[0,0,1,0]",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"readOnly": "false",
//										"selectOnFocus": "true",
//										"spellCheck": "true"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1GUROOAFI1",
//									"attrs": {
//										"1GUROQPMB0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1GUROT68A6",
//											"attrs": {
//												"properties": {
//													"jaxId": "1GUROT68A7",
//													"attrs": {
//														"readOnly": {
//															"type": "bool",
//															"valText": "false"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1GUROQPMB0",
//											"faceTagName": "on"
//										},
//										"1GUROQUSN0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1GUROT68A8",
//											"attrs": {
//												"properties": {
//													"jaxId": "1GUROT68A9",
//													"attrs": {
//														"readOnly": {
//															"type": "bool",
//															"valText": "true"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1GUROQUSN0",
//											"faceTagName": "off"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1GUROOAFI2",
//									"attrs": {
//										"OnFocus": {
//											"type": "fixedFunc",
//											"jaxId": "1GUSLC4TN0",
//											"attrs": {
//												"callArgs": {
//													"jaxId": "1GUSLCRJ50",
//													"attrs": {
//														"event": ""
//													}
//												},
//												"seg": ""
//											}
//										},
//										"OnInput": {
//											"type": "fixedFunc",
//											"jaxId": "1GUVG7DR00",
//											"attrs": {
//												"callArgs": {
//													"jaxId": "1GUVG7M9Q0",
//													"attrs": {}
//												},
//												"seg": ""
//											}
//										}
//									}
//								},
//								"extraPpts": {
//									"jaxId": "1GUROOAFI3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear/@StdUI/ui/BtnCheck.js",
//							"jaxId": "1IA118QMC0",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1IA11BEPA1",
//									"attrs": {
//										"size": "20",
//										"text": "",
//										"checked": "true",
//										"radio": "false"
//									}
//								},
//								"properties": {
//									"jaxId": "1IA11BEPA2",
//									"attrs": {
//										"type": "#null#>BtnCheck(20,\"\",true,false)",
//										"id": "BtnUse",
//										"position": "Absolute",
//										"x": "100%-25",
//										"y": "15",
//										"display": "On",
//										"face": "",
//										"padding": "2",
//										"anchorV": "Center"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1IA11BEPA3",
//									"attrs": {
//										"1GUROQPMB0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IA7537MA0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IA7537MA1",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1GUROQPMB0",
//											"faceTagName": "on"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1IA11BEPA4",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IA11BEPA5",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "true",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true",
//								"containerSlots": {
//									"jaxId": "1IA11BEPA6",
//									"attrs": {}
//								}
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1GURHE9VJ9",
//					"attrs": {
//						"1GUROQPMB0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1GUROT68A12",
//							"attrs": {
//								"properties": {
//									"jaxId": "1GUROT68A13",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1GUROQPMB0",
//							"faceTagName": "on"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1GURHE9VJ10",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1GURHE9VJ11",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1GURHE9VJ12",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"innerLayout": {
//					"valText": "false"
//				},
//				"marginL": {
//					"valText": "false"
//				},
//				"marginR": {
//					"valText": "false"
//				},
//				"marginT": {
//					"valText": "false"
//				},
//				"marginB": {
//					"valText": "false"
//				},
//				"paddingL": {
//					"valText": "false"
//				},
//				"paddingR": {
//					"valText": "false"
//				},
//				"paddingT": {
//					"valText": "false"
//				},
//				"paddingB": {
//					"valText": "false"
//				},
//				"attach": {
//					"valText": "false"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}