//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
import {BtnSlideSizeX} from "/@StdUI/ui/BtnSlideSizeX.js";
/*#{1GDK6DVVD0StartDoc*/
import {DocEditor} from "./DocEditor.js";
import {makeObjEventEmitter,makeNotify} from "/@events";
import {AddOn} from "../data/AddOn.js";
import markdownit from "/@markdownit/markdown-it.min.mjs";
import pathLib from "/@path";
const DlgCloud="/@homekit/ui/DlgCloud.js";
/*}#1GDK6DVVD0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let UIEditMD=function(app,mode,codeText,cfgVO,dataDoc){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1GDK6DVVD7LocalVals*/
	let boxCode,boxPreview,codeEditor;
	let sldSize,slideMinX,slideMaxX;
	let changeTimer;
	let cm,cmDoc;
	/*}#1GDK6DVVD7LocalVals*/
	
	/*#{1GDK6DVVD7PreState*/
	/*}#1GDK6DVVD7PreState*/
	state={
		"codeW":500,
		/*#{1GDK6DVVD5ExState*/
		/*}#1GDK6DVVD5ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1GDK6DVVD7PostState*/
	/*}#1GDK6DVVD7PostState*/
	cssVO={
		"hash":"1GDK6DVVD7",nameHost:true,
		"type":"view","x":0,"y":0,"w":"FW","h":"FH","autoLayout":true,"display":"On","overflow":1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
		children:[
			{
				"hash":"1GDK7IRA80",
				"type":"box","id":"BoxHeader","x":0,"y":0,"w":"FW","h":cfgSize.headerH,"autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["head"],
				"border":[0,0,1,0],"borderColor":cfgColor.lineBodySub,"contentLayout":"flex-x","itemsAlign":1,
				children:[
					{
						"hash":"1GDKIURPM0",
						"type":"hud","id":"BoxViewBtns","x":">calc(100% - 200px)","y":0,"w":200,"h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-xr",
						"itemsAlign":1,
						children:[
							{
								"hash":"1IA1S14DU0",
								"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/uirighthide.svg",null),"id":"BtnHidePreview","position":"relative","x":0,"y":0,"padding":1,
								/*#{1IA1S14DU0Codes*/
								tip:"Hide Preview",
								OnClick(){
									self.showFace("previewOff");
								}
								/*}#1IA1S14DU0Codes*/
							},
							{
								"hash":"1IA1SCO8M0",
								"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/uiright.svg",null),"id":"BtnShowPreview","position":"relative","x":0,"y":0,"display":0,"padding":1,
								/*#{1IA1SCO8M0Codes*/
								tip:"Show Preview",
								OnClick(){
									self.showFace("previewOn");
								}
								/*}#1IA1SCO8M0Codes*/
							},
							{
								"hash":"1IA1S4O0P0",
								"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/uilefthide.svg",null),"id":"BtnHideCode","position":"relative","x":0,"y":0,"padding":1,
								/*#{1IA1S4O0P0Codes*/
								tip:"Hide Code",
								OnClick(){
									self.showFace("previewOnly");
								}
								/*}#1IA1S4O0P0Codes*/
							},
							{
								"hash":"1IA1SG3IG0",
								"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/uileft.svg",null),"id":"BtnShowCode","position":"relative","x":0,"y":0,"display":0,"padding":1,
								/*#{1IA1SG3IG0Codes*/
								tip:"Show Code",
								OnClick(){
									self.showFace("previewOn");
								}
								/*}#1IA1SG3IG0Codes*/
							},
							{
								"hash":"1GDKJ5SKK0",
								"type":"text","position":"relative","x":0,"y":0,"w":100,"h":"FH","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
								"text":(($ln==="CN")?("视图"):("View:")),"fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,"autoW":true,
							}
						],
					},
					{
						"hash":"1IA1RQCKV0",
						"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/font_bold.svg",null),"id":"BtnBold","position":"relative","x":0,"y":0,"padding":3,
						/*#{1IA1RQCKV0Codes*/
						tip:(($ln==="CN")?("切换粗体模式"):("Toggles bold mode")),
						OnClick(){
							self.makeBold();
						}
						/*}#1IA1RQCKV0Codes*/
					},
					{
						"hash":"1IA1ROB710",
						"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/font_italic.svg",null),"id":"BtnItalic","position":"relative","x":0,"y":0,"padding":3,
						/*#{1IA1ROB710Codes*/
						tip:(($ln==="CN")?("切换斜体模式"):("Toggles italic mode")),
						OnClick(){
							self.makeItalic();
						}
						/*}#1IA1ROB710Codes*/
					},
					{
						"hash":"1IA1RMLCT0",
						"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/font_strike.svg",null),"id":"BtnStrikeOut","position":"relative","x":0,"y":0,"padding":1,
						/*#{1IA1RMLCT0Codes*/
						tip:"Toggles strike-out mode",
						OnClick(){
							self.makeStrike();
						}
						/*}#1IA1RMLCT0Codes*/
					},
					{
						"hash":"1IA1RIE320",
						"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/code.svg",null),"id":"BtnMicronSpace","position":"relative","x":0,"y":0,"padding":1,
						/*#{1IA1RIE320Codes*/
						tip:(($ln==="CN")?("切换代码或微空间模式"):("Toggles code or micro-space mode")),
						OnClick(){
							self.makeCode();
						}
						/*}#1IA1RIE320Codes*/
					},
					{
						"hash":"1IA1RH6KP0",
						"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/inc.svg",null),"id":"BtnHeadUp","position":"relative","x":0,"y":0,"padding":1,
						/*#{1IA1RH6KP0Codes*/
						tip:(($ln==="CN")?("增加标题文本的级别"):("Increase level of header text")),
						OnClick(){
							self.makeHeadUp();
						}
						/*}#1IA1RH6KP0Codes*/
					},
					{
						"hash":"1IA1REFH70",
						"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/dec.svg",null),"id":"BtnHeadDown","position":"relative","x":0,"y":0,"padding":1,
						/*#{1IA1REFH70Codes*/
						tip:(($ln==="CN")?("降低标题文本的级别"):("Decrease level of header text")),
						OnClick(){
							self.makeHeadDown();
						}
						/*}#1IA1REFH70Codes*/
					},
					{
						"hash":"1IA1R6H8P0",
						"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/link.svg",null),"id":"BtnLink","position":"relative","x":0,"y":0,"padding":3,
						/*#{1IA1R6H8P0Codes*/
						tip:(($ln==="CN")?("切换链接"):("Toggles link")),
						OnClick(){
							self.makeLink();
						}
						/*}#1IA1R6H8P0Codes*/
					}
				],
			},
			{
				"hash":"1GDK7LQ9R0",
				"type":"hud","id":"BoxCode","x":0,"y":cfgSize.headerH,"w":$P(()=>(state.codeW),state),"h":`FH-${cfgSize.headerH}`,"autoLayout":true,"minW":"","minH":"",
				"maxW":"","maxH":"","styleClass":"",
			},
			{
				"hash":"1GDK810R20",
				"type":"hud","id":"BoxPreview","x":$P(()=>(state.codeW+8),state),"y":cfgSize.headerH,"w":$P(()=>(`FW-${state.codeW+8}`),state),"h":`FH-${cfgSize.headerH}`,
				"autoLayout":true,"padding":[0,0,0,5],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
			},
			{
				"hash":"1GDK86JAB0",
				"type":"box","id":"BoxMidGap","x":$P(()=>(state.codeW),state),"y":cfgSize.headerH,"w":8,"h":`FH-${cfgSize.headerH}`,"autoLayout":true,"uiEvent":-1,
				"zIndex":8,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":[...cfgColor.lineBodyLit,50],"border":[0,0,0,0],
				children:[
					{
						"hash":"1GDK8DCQC0",
						"type":"box","x":2,"y":"(FH-30)/2","w":4,"h":"30","autoLayout":true,"alpha":0.5,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":[0,0,0,0],
						"border":[0,1,0,1],"borderStyle":2,"borderColor":cfgColor.lineBodySub,
					}
				],
			},
			{
				"hash":"1GDK7TMT10",
				"type":BtnSlideSizeX(null,null,null),"id":"SLDSize","x":state.codeW,"y":cfgSize.headerH,"h":`FH-${cfgSize.headerH}`,"w":8,"zIndex":8,
				/*#{1GDK7TMT10Codes*/
				OnSlideStart(){
					let w;
					w=self.w;
					slideMinX=100;
					slideMaxX=w-100;
					self.showFace("dragOn");
				},
				OnSlideUpdate(evt,x,dx){
					let w;
					if(x<slideMinX){
						x=slideMinX;
					}
					if(x>slideMaxX){
						x=slideMaxX;
					}
					return x;
				},
				OnSlideFin(evt,x,dx){
					state.codeW=x;
					self.showFace("dragOff");
				}
				/*}#1GDK7TMT10Codes*/
			}
		],
		/*#{1GDK6DVVD7ExtraCSS*/
		/*}#1GDK6DVVD7ExtraCSS*/
		faces:{
			"previewOn":{
				/*BtnHidePreview*/"#1IA1S14DU0":{
					"display":1
				},
				/*BtnShowPreview*/"#1IA1SCO8M0":{
					"display":0
				},
				/*BtnHideCode*/"#1IA1S4O0P0":{
					"display":1
				},
				/*BtnShowCode*/"#1IA1SG3IG0":{
					"display":0
				},
				/*BtnBold*/"#1IA1RQCKV0":{
					"display":1
				},
				/*BtnItalic*/"#1IA1ROB710":{
					"display":1
				},
				/*BtnStrikeOut*/"#1IA1RMLCT0":{
					"display":1
				},
				/*BtnMicronSpace*/"#1IA1RIE320":{
					"display":1
				},
				/*BtnHeadUp*/"#1IA1RH6KP0":{
					"display":1
				},
				/*BtnHeadDown*/"#1IA1REFH70":{
					"display":1
				},
				/*BtnLink*/"#1IA1R6H8P0":{
					"display":1
				},
				/*BoxCode*/"#1GDK7LQ9R0":{
					"w":$P(()=>(state.codeW),state),"display":1
				},
				/*BoxPreview*/"#1GDK810R20":{
					"display":1,"x":$P(()=>(state.codeW+8),state),"w":$P(()=>(`FW-${state.codeW+8}`),state)
				},
				/*BoxMidGap*/"#1GDK86JAB0":{
					"display":1
				},
				/*SLDSize*/"#1GDK7TMT10":{
					"display":1
				}
			},"previewOff":{
				/*BtnHidePreview*/"#1IA1S14DU0":{
					"display":0
				},
				/*BtnShowPreview*/"#1IA1SCO8M0":{
					"display":1
				},
				/*BtnHideCode*/"#1IA1S4O0P0":{
					"display":0
				},
				/*BtnShowCode*/"#1IA1SG3IG0":{
					"display":0
				},
				/*BtnBold*/"#1IA1RQCKV0":{
					"display":1
				},
				/*BtnItalic*/"#1IA1ROB710":{
					"display":1
				},
				/*BtnStrikeOut*/"#1IA1RMLCT0":{
					"display":1
				},
				/*BtnMicronSpace*/"#1IA1RIE320":{
					"display":1
				},
				/*BtnHeadUp*/"#1IA1RH6KP0":{
					"display":1
				},
				/*BtnHeadDown*/"#1IA1REFH70":{
					"display":1
				},
				/*BtnLink*/"#1IA1R6H8P0":{
					"display":1
				},
				/*BoxCode*/"#1GDK7LQ9R0":{
					"w":"FW"
				},
				/*BoxPreview*/"#1GDK810R20":{
					"display":0
				},
				/*BoxMidGap*/"#1GDK86JAB0":{
					"display":0
				},
				/*SLDSize*/"#1GDK7TMT10":{
					"display":0
				}
			},"previewOnly":{
				/*BtnHidePreview*/"#1IA1S14DU0":{
					"display":0
				},
				/*BtnShowPreview*/"#1IA1SCO8M0":{
					"display":0
				},
				/*BtnHideCode*/"#1IA1S4O0P0":{
					"display":0
				},
				/*BtnShowCode*/"#1IA1SG3IG0":{
					"display":1
				},
				/*BtnBold*/"#1IA1RQCKV0":{
					"display":0
				},
				/*BtnItalic*/"#1IA1ROB710":{
					"display":0
				},
				/*BtnStrikeOut*/"#1IA1RMLCT0":{
					"display":0
				},
				/*BtnMicronSpace*/"#1IA1RIE320":{
					"display":0
				},
				/*BtnHeadUp*/"#1IA1RH6KP0":{
					"display":0
				},
				/*BtnHeadDown*/"#1IA1REFH70":{
					"display":0
				},
				/*BtnLink*/"#1IA1R6H8P0":{
					"display":0
				},
				/*BoxCode*/"#1GDK7LQ9R0":{
					"display":0
				},
				/*BoxPreview*/"#1GDK810R20":{
					"display":1,"x":0,"w":"FW"
				},
				/*BoxMidGap*/"#1GDK86JAB0":{
					"display":0
				},
				/*SLDSize*/"#1GDK7TMT10":{
					"display":0
				}
			},"dragOn":{
				/*BoxMidGap*/"#1GDK86JAB0":{
					"display":0
				}
			},"dragOff":{
				/*BoxMidGap*/"#1GDK86JAB0":{
					"display":1
				}
			}
		},
		OnCreate:function(){
			self=this;
			
			/*#{1GDK6DVVD7Create*/
			let fw;
			fw=self.parent.w;
			state.codeW=Math.trunc(fw*0.5);
			
			makeNotify(self);
			makeObjEventEmitter(self);
			boxCode=self.BoxCode;
			boxPreview=self.BoxPreview;
			sldSize=self.SLDSize;
			sldSize.x=state.codeW;
			//Setup code editor:
			{
				codeEditor=boxCode.insertNewBefore(DocEditor(app,mode,codeText,cfgVO),self.BoxEditGearBtn);
				//Rout all codeEditor events to this:
				codeEditor.emit=this.emit.bind(this);
				codeEditor.emitNotify=this.emitNotify.bind(this);
				codeEditor.on=this.on.bind(this);
				codeEditor.off=this.off.bind(this);
				codeEditor.onNotify=this.onNotify.bind(this);
				codeEditor.offNotify=this.offNotify.bind(this);
				codeEditor.on("InitDone",()=>{
					cm=codeEditor.cm;
					cmDoc=codeEditor.cmDoc;
				});
				self.onNotify("Change",self.OnCodeChange);
			}
			//Setup MD view:
			{
				self.updatePreview();
			}
			/*}#1GDK6DVVD7Create*/
		},
		/*#{1GDK6DVVD7EndCSS*/
		traceSize:1,
		OnFree(){
			if(changeTimer){
				window.clearTimeout(changeTimer);
			}
		},
		OnSize(){
			let w;
			w=self.w;
			if(w<state.codeW+8){
				if(w>20){
					state.codeW=w-20;
				}else{
					state.codeW=20;
				}
				sldSize.x=state.codeW;
			}
		}
		/*}#1GDK6DVVD7EndCSS*/
	};
	/*#{1GDK6DVVD7PostCSSVO*/
	//************************************************************************
	//Code Editor related:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		cssVO.init=async function(){
			return await codeEditor.init();
		};
	
		//------------------------------------------------------------------------
		cssVO.applyCfg=function(opts){
			return codeEditor.applyCfg(opts);
		};
	
		//--------------------------------------------------------------------
		cssVO.setEditText=function(text,undo=true){
			codeEditor.setEditText(text,undo);
		};
	
		//--------------------------------------------------------------------
		cssVO.getEditText=function(){
			return codeEditor.getEditText();
		};
	
		//--------------------------------------------------------------------
		cssVO.getSelection=function(){
			return codeEditor.getSelection();
		};
		
		//--------------------------------------------------------------------
		cssVO.replaceSelection=function(text,select){
			codeEditor.replaceSelection(text,select);
		};
		
		//--------------------------------------------------------------------
		cssVO.getCursorPos=function(){
			return codeEditor.getCursorPos();
		};
	
		//--------------------------------------------------------------------
		cssVO.getCursorIndex=function(){
			return codeEditor.getCursorIndex();
		};
		
		//--------------------------------------------------------------------
		cssVO.getSelectionRange=function(){
			return codeEditor.getSelectionRange();
		};
	
		//--------------------------------------------------------------------
		cssVO.getEditVersion=function(){
			return codeEditor.getEditVersion();
		};
	
		//--------------------------------------------------------------------
		cssVO.focus=function(){
			codeEditor.focus();
		};
	
		//--------------------------------------------------------------------
		cssVO.blur=function(){
			codeEditor.blur();
		};
	
		//--------------------------------------------------------------------
		cssVO.gotoLine=function(line){
			return codeEditor.gotoLine(line);
		};
	
		//--------------------------------------------------------------------
		cssVO.undo=function(){
			codeEditor.undo();
		};
	
		//--------------------------------------------------------------------
		cssVO.redo=function(){
			codeEditor.redo();
		};
	}
	
	//************************************************************************
	//MD View
	//************************************************************************
	{
		//--------------------------------------------------------------------
		let renderMD=async function(text,path,tgtDiv){
			let div,lnkPath,hrefPath,baseDir;
			baseDir=pathLib.dirname(path);
			let md=markdownit({html:true});
			text=md.render(text);
			div=tgtDiv;//.firstChild;
			div.innerHTML =text;
			if(div.scrollHeight>div.clientHeight){
				tgtDiv.style.overflowY="scroll";
			}else{
				tgtDiv.style.overflowY="";
			}
			//Deal with links:
			let tags=div.getElementsByTagName("a");
			for(let tag of tags){
				hrefPath=tag.href;
				lnkPath=tag.attributes.href.nodeValue||tag.attributes.href.value;
				if(lnkPath.startsWith("checkout://")){
					tag.onclick=function(evt){
						let url=tag.attributes.href.nodeValue||tag.attributes.href.value;
						let pos=url.indexOf("://");
						let diskIdName=url.substring(pos+3);
						app.showDlg(DlgCloud,{
							mode:"CheckOut",
							diskId:diskIdName,
							updateDisk:async function(diskName){
								app.openPath("/"+diskName);
							}
						});
						evt.stopPropagation();
						evt.preventDefault();
					};
				}else{
					tag.onclick=function(evt){
						let url=tag.attributes.href.nodeValue||tag.attributes.href.value;
						app.showStateText("URL: "+url);
						evt.stopPropagation();
						evt.preventDefault();
					};
				}
			}
			tags=div.getElementsByTagName("img");
			for(let tag of tags){
				hrefPath=tag.src;
				lnkPath=tag.attributes.src.nodeValue||tag.attributes.href.value;
				if(lnkPath.indexOf("://")<0){
					let pos=baseDir.lastIndexOf("//");
					tag.src=baseDir.substring(0,pos+2)+pathLib.join(baseDir.substring(pos+2),lnkPath);
				}
				tag.style.maxWidth="780px";
			}
			if(tags.length>0){
				tgtDiv.style.overflowY="scroll";
			}
		};
		
		//--------------------------------------------------------------------
		cssVO.updatePreview=function(){
			let text;
			text=dataDoc.getDocText();
			renderMD(text,dataDoc.path,boxPreview.webObj);
		};
	}
	
	//************************************************************************
	//MD Code
	//************************************************************************
	{
		//--------------------------------------------------------------------
		cssVO.makeBold=function(){
			let selects,text,cursor;
			selects=cmDoc.getSelections();
			if(selects.length>1){
				//TODO: Notify user:
				cm.focus();
				return;
			}
			text=cmDoc.getSelection();
			if(text.length){
				if(text.startsWith("**") && text.endsWith("**")){
					cmDoc.replaceSelection(text.substring(2,text.length-2),"around");
				}else{
					cmDoc.replaceSelection(`**${text}**`,"around");
				}
			}else{
				cmDoc.replaceSelection("****","around");
			}
			cm.focus();
		};
	
		//--------------------------------------------------------------------
		cssVO.makeItalic=function(){
			let selects,text,cursor;
			selects=cmDoc.getSelections();
			if(selects.length>1){
				//TODO: Notify user:
				cm.focus();
				return;
			}
			text=cmDoc.getSelection();
			if(text.length){
				if(text.startsWith("***") && text.endsWith("***")){
					cmDoc.replaceSelection(text.substring(1,text.length-1),"around");
				}else if(text.startsWith("**") && text.endsWith("**")){
					cmDoc.replaceSelection(`*${text}*`,"around");
				}else if(text.startsWith("*") && text.endsWith("*")){
					cmDoc.replaceSelection(text.substring(1,text.length-1),"around");
				}else{
					cmDoc.replaceSelection(`*${text}*`,"around");
				}
			}else{
				cmDoc.replaceSelection("**","around");
			}
			cm.focus();
		};
	
		//--------------------------------------------------------------------
		cssVO.makeStrike=function(){
			let selects,text,cursor;
			selects=cmDoc.getSelections();
			if(selects.length>1){
				//TODO: Notify user:
				cm.focus();
				return;
			}
			text=cmDoc.getSelection();
			if(text.length){
				if(text.startsWith("~~") && text.endsWith("~~")){
					cmDoc.replaceSelection(text.substring(2,text.length-2),"around");
				}else{
					cmDoc.replaceSelection(`~~${text}~~`,"around");
				}
			}else{
				cmDoc.replaceSelection("~~~~","around");
			}
			cm.focus();
		};
	
		//--------------------------------------------------------------------
		cssVO.makeCode=function(){
			let selects,text,cursor;
			selects=cmDoc.getSelections();
			if(selects.length>1){
				//TODO: Notify user:
				cm.focus();
				return;
			}
			text=cmDoc.getSelection();
			if(text.length){
				if(text.startsWith("`") && text.endsWith("`")){
					cmDoc.replaceSelection(text.substring(1,text.length-1),"around");
				}else{
					cmDoc.replaceSelection(`\`${text}\``,"around");
				}
			}else{
				cmDoc.replaceSelection("``","around");
			}
			cm.focus();
		};
	
		//--------------------------------------------------------------------
		cssVO.makeHeadUp=function(){
			let cursor,text,pos,curLevel,i;
			cursor=cmDoc.getCursor();
			text=cmDoc.getLine(cursor.line);
			pos=text.indexOf(" ");
			if(pos>0){
				CheckLevel:{
					for(i=0;i<pos;i++){
						if(text[i]!=="#"){
							break CheckLevel;
						}
					}
					cmDoc.setCursor(cursor.line,0);
					cm.execCommand("delCharAfter");
					if(pos===1){
						cmDoc.setCursor(cursor.line,0);
						cm.execCommand("delCharAfter");
					}
					cmDoc.setCursor(cursor.line,0);
					return;
				}
			}
			cmDoc.setCursor(cursor.line,0);
			cmDoc.replaceSelection("###### ");
			cm.focus();
		};
	
		//--------------------------------------------------------------------
		cssVO.makeHeadDown=function(){
			let cursor,text,pos,curLevel,i;
			cursor=cmDoc.getCursor();
			text=cmDoc.getLine(cursor.line);
			pos=text.indexOf(" ");
			if(pos>0){
				CheckLevel:{
					for(i=0;i<pos;i++){
						if(text[i]!=="#"){
							break CheckLevel;
						}
					}
					if(pos>=6){
						cmDoc.setSelection({line:cursor.line,ch:0},{line:cursor.line,ch:pos+1});
						cmDoc.replaceSelection("");
					}else{
						cmDoc.setCursor(cursor.line,0);
						cmDoc.replaceSelection("#");
						cmDoc.setCursor(cursor.line,0);
					}
					return;
				}
			}
			cmDoc.setCursor(cursor.line,0);
			cmDoc.replaceSelection("# ");
			cm.focus();
		};
	
		//--------------------------------------------------------------------
		cssVO.makeLink=function(){
			let selects,text,cursor;
			selects=cmDoc.getSelections();
			if(selects.length>1){
				//TODO: Notify user:
				cm.focus();
				return;
			}
			text=cmDoc.getSelection();
			if(text.length){
				if(text.startsWith("[") && text.endsWith(")")){
					let pos;
					text=text.substring(1,text.length-1);
					pos=text.indexOf("](");
					if(pos>=0){
						text=text.substring(0,pos)+text.substring(pos+2);
					}else{
						pos=text.indexOf("]");
						if(pos>=0){
							text=text.substring(0,pos)+text.substring(pos+1);
						}
					}
					cmDoc.replaceSelection(text,"around");
				}else if(text.startsWith("[") && text.endsWith("]")){
					cmDoc.replaceSelection(text.substring(1,text.length-1),"around");
				}else{
					cmDoc.replaceSelection(`[${text}]()`,"around");
				}
			}else{
				cmDoc.replaceSelection("[]()","around");
			}
			cm.focus();
		};
	}
	
	//------------------------------------------------------------------------
	cssVO.OnCodeChange=function(){
		if(changeTimer){
			window.clearTimeout(changeTimer);
		}
		changeTimer=window.setTimeout(()=>{
			changeTimer=null;
			self.updatePreview();
		},500);
	};
	
	//------------------------------------------------------------------------
	//Handle shortcut, only handle "Find"/Replace
	cssVO.handleShortcut=function(cmd){
		if(cmd==="Find"){
			codeEditor.findNext();
			return 1;
		}else if(cmd==="FindNext"){
			codeEditor.findNext();
			return 1;
		}else if(cmd==="FindPre"){
			codeEditor.findPre();
			return 1;
		}
		return 0;
	};
	/*}#1GDK6DVVD7PostCSSVO*/
	return cssVO;
};
/*#{1GDK6DVVD7ExCodes*/
UIEditMD.scoreDoc=function(doc){
	let path;
	path=doc.path.toLowerCase();
	if(path.endsWith(".md")){
		return 100;
	}
	return 0;
};
AddOn.regAddOn("DocEditor","MDEditor",UIEditMD);
/*}#1GDK6DVVD7ExCodes*/


/*#{1GDK6DVVD0EndDoc*/
/*}#1GDK6DVVD0EndDoc*/

export default UIEditMD;
export{UIEditMD};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "UIView",
//	"jaxId": "1GDK6DVVD0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1GDK6DVVD1",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "800",
//				"screenH": "500",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1GDK6DVVD2",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1H7A22SBL0",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1GDK6DVVD3",
//			"attrs": {
//				"app": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"mode": {
//					"type": "string",
//					"valText": "\".md\""
//				},
//				"codeText": {
//					"type": "string",
//					"valText": ""
//				},
//				"cfgVO": {
//					"type": "auto",
//					"valText": "{}"
//				},
//				"dataDoc": {
//					"type": "auto",
//					"valText": "null"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1GDK6DVVD4",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1GDK6DVVD5",
//			"attrs": {
//				"codeW": {
//					"type": "int",
//					"valText": "500"
//				}
//			}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "VFACT document",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1GDK6DVVD6",
//			"attrs": {
//				"previewOn": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1GDK908V60",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1GDK915ET0",
//							"attrs": {}
//						}
//					}
//				},
//				"previewOff": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1GDK90DFD0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1GDK915ET1",
//							"attrs": {}
//						}
//					}
//				},
//				"previewOnly": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1GDK90VVM0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1GDK915ET2",
//							"attrs": {}
//						}
//					}
//				},
//				"dragOn": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1GDK95H3S0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1GDK9A4G90",
//							"attrs": {}
//						}
//					}
//				},
//				"dragOff": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1GDK95MO80",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1GDK9A4G91",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1IA1RBOSM0",
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "view",
//			"jaxId": "1GDK6DVVD7",
//			"attrs": {
//				"properties": {
//					"jaxId": "1GDK6DVVD8",
//					"attrs": {
//						"type": "view",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "\"FW\"",
//						"h": "\"FH\"",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "true",
//						"display": "\"On\"",
//						"clip": "On",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "[0,0,0,0]",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "\"\"",
//						"styleClass": ""
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1GDK7IRA80",
//							"attrs": {
//								"properties": {
//									"jaxId": "1GDK7LM300",
//									"attrs": {
//										"type": "box",
//										"id": "BoxHeader",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "\"FW\"",
//										"h": "#cfgSize.headerH",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "true",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "\"\"",
//										"styleClass": "",
//										"background": "#cfgColor[\"head\"]",
//										"border": "[0,0,1,0]",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor.lineBodySub",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"contentLayout": "Flex X",
//										"itemsAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1GDKIURPM0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1GDKJIN1F0",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxViewBtns",
//														"position": "Absolute",
//														"x": "100%-200",
//														"y": "0",
//														"w": "200",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[0,0,0,0]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "\"\"",
//														"styleClass": "",
//														"contentLayout": "Flex XR",
//														"itemsAlign": "Center"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1IA1S14DU0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1IA1S14DU1",
//																	"attrs": {
//																		"style": "\"front\"",
//																		"w": "24",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/uirighthide.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1IA1S14DU2",
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"front\",24,0,appCfg.sharedAssets+\"/uirighthide.svg\",null)",
//																		"id": "BtnHidePreview",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"padding": "1"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IA1S14DV0",
//																	"attrs": {
//																		"1GDK908V60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IA1S14DV1",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IA1S14DV2",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1GDK908V60",
//																			"faceTagName": "previewOn"
//																		},
//																		"1GDK90DFD0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IA1S14DV3",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IA1S14DV4",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1GDK90DFD0",
//																			"faceTagName": "previewOff"
//																		},
//																		"1GDK90VVM0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IA1S14DV5",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IA1S14DV6",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1GDK90VVM0",
//																			"faceTagName": "previewOnly"
//																		},
//																		"1GDK95H3S0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IA1S14DV7",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IA1S14DV8",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1GDK95H3S0",
//																			"faceTagName": "dragOn"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1IA1S14DV9",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1IA1S14DV10",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "true",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1IA1S14DV11",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1IA1SCO8M0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1IA1SCO8M1",
//																	"attrs": {
//																		"style": "\"front\"",
//																		"w": "24",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/uiright.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1IA1SCO8M2",
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"front\",24,0,appCfg.sharedAssets+\"/uiright.svg\",null)",
//																		"id": "BtnShowPreview",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "Off",
//																		"face": "",
//																		"padding": "1"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IA1SCO8M3",
//																	"attrs": {
//																		"1GDK908V60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IA1SCO8N0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IA1SCO8N1",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1GDK908V60",
//																			"faceTagName": "previewOn"
//																		},
//																		"1GDK90DFD0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IA1SCO8N2",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IA1SCO8N3",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1GDK90DFD0",
//																			"faceTagName": "previewOff"
//																		},
//																		"1GDK90VVM0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IA1SCO8N4",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IA1SCO8N5",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1GDK90VVM0",
//																			"faceTagName": "previewOnly"
//																		},
//																		"1GDK95H3S0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IA1SCO8N6",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IA1SCO8N7",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1GDK95H3S0",
//																			"faceTagName": "dragOn"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1IA1SCO8N8",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1IA1SCO8N9",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "true",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1IA1SCO8N10",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1IA1S4O0P0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1IA1S4O0P1",
//																	"attrs": {
//																		"style": "\"front\"",
//																		"w": "24",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/uilefthide.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1IA1S4O0P2",
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"front\",24,0,appCfg.sharedAssets+\"/uilefthide.svg\",null)",
//																		"id": "BtnHideCode",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"padding": "1"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IA1S4O0P3",
//																	"attrs": {
//																		"1GDK908V60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IA1S4O0P4",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IA1S4O0P5",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1GDK908V60",
//																			"faceTagName": "previewOn"
//																		},
//																		"1GDK90DFD0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IA1S4O0Q0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IA1S4O0Q1",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1GDK90DFD0",
//																			"faceTagName": "previewOff"
//																		},
//																		"1GDK90VVM0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IA1S4O0Q2",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IA1S4O0Q3",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1GDK90VVM0",
//																			"faceTagName": "previewOnly"
//																		},
//																		"1GDK95H3S0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IA1S4O0Q4",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IA1S4O0Q5",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1GDK95H3S0",
//																			"faceTagName": "dragOn"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1IA1S4O0Q6",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1IA1S4O0Q7",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "true",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1IA1S4O0Q8",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1IA1SG3IG0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1IA1SG3IG1",
//																	"attrs": {
//																		"style": "\"front\"",
//																		"w": "24",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/uileft.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1IA1SG3IG2",
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"front\",24,0,appCfg.sharedAssets+\"/uileft.svg\",null)",
//																		"id": "BtnShowCode",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "Off",
//																		"face": "",
//																		"padding": "1"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IA1SG3IH0",
//																	"attrs": {
//																		"1GDK908V60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IA1SG3IH1",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IA1SG3IH2",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1GDK908V60",
//																			"faceTagName": "previewOn"
//																		},
//																		"1GDK90DFD0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IA1SG3IH3",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IA1SG3IH4",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1GDK90DFD0",
//																			"faceTagName": "previewOff"
//																		},
//																		"1GDK90VVM0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IA1SG3IH5",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IA1SG3IH6",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1GDK90VVM0",
//																			"faceTagName": "previewOnly"
//																		},
//																		"1GDK95H3S0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IA1SG3IH7",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IA1SG3IH8",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1GDK95H3S0",
//																			"faceTagName": "dragOn"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1IA1SG3IH9",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1IA1SG3IH10",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "true",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1IA1SG3IH11",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1GDKJ5SKK0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1GDKJIN1G6",
//																	"attrs": {
//																		"type": "text",
//																		"id": "",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100",
//																		"h": "\"FH\"",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[0,0,0,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "\"\"",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontBody\"]",
//																		"text": {
//																			"type": "string",
//																			"valText": "视图",
//																			"localize": {
//																				"EN": "View:",
//																				"CN": "视图"
//																			},
//																			"localizable": true
//																		},
//																		"font": "",
//																		"fontSize": "#txtSize.small",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Center",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"lineClamp": "0",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0",
//																		"autoSizeW": "true",
//																		"autoSizeH": "false"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1GDKJIN1G7",
//																	"attrs": {
//																		"1GDK95H3S0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IA1RBOSM13",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IA1RBOSM14",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1GDK95H3S0",
//																			"faceTagName": "dragOn"
//																		},
//																		"1GDK908V60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IA1SERTA0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IA1SERTA1",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1GDK908V60",
//																			"faceTagName": "previewOn"
//																		},
//																		"1GDK90DFD0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IA1SJCF10",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IA1SJCF11",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1GDK90DFD0",
//																			"faceTagName": "previewOff"
//																		},
//																		"1GDK90VVM0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IA1SJCF12",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IA1SJCF13",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1GDK90VVM0",
//																			"faceTagName": "previewOnly"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1GDKJIN1G12",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1GJ3Q80HG4",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false"
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1GDKJIN1G13",
//													"attrs": {
//														"1GDK95H3S0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IA1RBOSM19",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IA1RBOSM20",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1GDK95H3S0",
//															"faceTagName": "dragOn"
//														},
//														"1GDK908V60": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IA1SERTA2",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IA1SERTA3",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1GDK908V60",
//															"faceTagName": "previewOn"
//														},
//														"1GDK90DFD0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IA1SJCF14",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IA1SJCF15",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1GDK90DFD0",
//															"faceTagName": "previewOff"
//														},
//														"1GDK90VVM0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IA1SJCF16",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IA1SJCF17",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1GDK90VVM0",
//															"faceTagName": "previewOnly"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1GDKJIN1G18",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1GJ3Q80HG5",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1IA1RQCKV0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1IA1RQCKV1",
//													"attrs": {
//														"style": "\"front\"",
//														"w": "24",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/font_bold.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1IA1RQCKV2",
//													"attrs": {
//														"type": "#null#>BtnIcon(\"front\",24,0,appCfg.sharedAssets+\"/font_bold.svg\",null)",
//														"id": "BtnBold",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"padding": "3"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IA1RQCKV3",
//													"attrs": {
//														"1GDK908V60": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IA1RQCL00",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IA1RQCL01",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1GDK908V60",
//															"faceTagName": "previewOn"
//														},
//														"1GDK90DFD0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IA1RQCL02",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IA1RQCL03",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1GDK90DFD0",
//															"faceTagName": "previewOff"
//														},
//														"1GDK90VVM0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IA1RQCL04",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IA1RQCL05",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1GDK90VVM0",
//															"faceTagName": "previewOnly"
//														},
//														"1GDK95H3S0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IA1RQCL06",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IA1RQCL07",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1GDK95H3S0",
//															"faceTagName": "dragOn"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IA1RQCL08",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IA1RQCL09",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "true",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1IA1RQCL010",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1IA1ROB710",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1IA1ROB711",
//													"attrs": {
//														"style": "\"front\"",
//														"w": "24",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/font_italic.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1IA1ROB712",
//													"attrs": {
//														"type": "#null#>BtnIcon(\"front\",24,0,appCfg.sharedAssets+\"/font_italic.svg\",null)",
//														"id": "BtnItalic",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"padding": "3"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IA1ROB713",
//													"attrs": {
//														"1GDK908V60": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IA1ROB714",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IA1ROB715",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1GDK908V60",
//															"faceTagName": "previewOn"
//														},
//														"1GDK90DFD0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IA1ROB716",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IA1ROB717",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1GDK90DFD0",
//															"faceTagName": "previewOff"
//														},
//														"1GDK90VVM0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IA1ROB720",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IA1ROB721",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1GDK90VVM0",
//															"faceTagName": "previewOnly"
//														},
//														"1GDK95H3S0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IA1ROB722",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IA1ROB723",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1GDK95H3S0",
//															"faceTagName": "dragOn"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IA1ROB724",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IA1ROB725",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "true",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1IA1ROB726",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1IA1RMLCT0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1IA1RMLCT1",
//													"attrs": {
//														"style": "\"front\"",
//														"w": "24",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/font_strike.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1IA1RMLCT2",
//													"attrs": {
//														"type": "#null#>BtnIcon(\"front\",24,0,appCfg.sharedAssets+\"/font_strike.svg\",null)",
//														"id": "BtnStrikeOut",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"padding": "1"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IA1RMLCT3",
//													"attrs": {
//														"1GDK908V60": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IA1RMLCT4",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IA1RMLCT5",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1GDK908V60",
//															"faceTagName": "previewOn"
//														},
//														"1GDK90DFD0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IA1RMLCU0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IA1RMLCU1",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1GDK90DFD0",
//															"faceTagName": "previewOff"
//														},
//														"1GDK90VVM0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IA1RMLCU2",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IA1RMLCU3",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1GDK90VVM0",
//															"faceTagName": "previewOnly"
//														},
//														"1GDK95H3S0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IA1RMLCU4",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IA1RMLCU5",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1GDK95H3S0",
//															"faceTagName": "dragOn"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IA1RMLCU6",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IA1RMLCU7",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "true",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1IA1RMLCU8",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1IA1RIE320",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1IA1RIE321",
//													"attrs": {
//														"style": "\"front\"",
//														"w": "24",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/code.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1IA1RIE330",
//													"attrs": {
//														"type": "#null#>BtnIcon(\"front\",24,0,appCfg.sharedAssets+\"/code.svg\",null)",
//														"id": "BtnMicronSpace",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"padding": "1"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IA1RIE331",
//													"attrs": {
//														"1GDK908V60": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IA1RIE332",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IA1RIE333",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1GDK908V60",
//															"faceTagName": "previewOn"
//														},
//														"1GDK90DFD0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IA1RIE334",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IA1RIE335",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1GDK90DFD0",
//															"faceTagName": "previewOff"
//														},
//														"1GDK90VVM0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IA1RIE336",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IA1RIE337",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1GDK90VVM0",
//															"faceTagName": "previewOnly"
//														},
//														"1GDK95H3S0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IA1RIE338",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IA1RIE339",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1GDK95H3S0",
//															"faceTagName": "dragOn"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IA1RIE3310",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IA1RIE3311",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "true",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1IA1RIE3312",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1IA1RH6KP0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1IA1RH6KP1",
//													"attrs": {
//														"style": "\"front\"",
//														"w": "24",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/inc.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1IA1RH6KP2",
//													"attrs": {
//														"type": "#null#>BtnIcon(\"front\",24,0,appCfg.sharedAssets+\"/inc.svg\",null)",
//														"id": "BtnHeadUp",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"padding": "1"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IA1RH6KP3",
//													"attrs": {
//														"1GDK908V60": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IA1RH6KP4",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IA1RH6KP5",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1GDK908V60",
//															"faceTagName": "previewOn"
//														},
//														"1GDK90DFD0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IA1RH6KP6",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IA1RH6KP7",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1GDK90DFD0",
//															"faceTagName": "previewOff"
//														},
//														"1GDK90VVM0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IA1RH6KP8",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IA1RH6KP9",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1GDK90VVM0",
//															"faceTagName": "previewOnly"
//														},
//														"1GDK95H3S0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IA1RH6KQ0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IA1RH6KQ1",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1GDK95H3S0",
//															"faceTagName": "dragOn"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IA1RH6KQ2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IA1RH6KQ3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "true",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1IA1RH6KQ4",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1IA1REFH70",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1IA1REFH71",
//													"attrs": {
//														"style": "\"front\"",
//														"w": "24",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/dec.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1IA1REFH72",
//													"attrs": {
//														"type": "#null#>BtnIcon(\"front\",24,0,appCfg.sharedAssets+\"/dec.svg\",null)",
//														"id": "BtnHeadDown",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"padding": "1"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IA1REFH73",
//													"attrs": {
//														"1GDK908V60": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IA1REFH80",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IA1REFH81",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1GDK908V60",
//															"faceTagName": "previewOn"
//														},
//														"1GDK90DFD0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IA1REFH82",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IA1REFH83",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1GDK90DFD0",
//															"faceTagName": "previewOff"
//														},
//														"1GDK90VVM0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IA1REFH84",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IA1REFH85",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1GDK90VVM0",
//															"faceTagName": "previewOnly"
//														},
//														"1GDK95H3S0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IA1REFH86",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IA1REFH87",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1GDK95H3S0",
//															"faceTagName": "dragOn"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IA1REFH88",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IA1REFH89",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "true",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1IA1REFH810",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1IA1R6H8P0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1IA1RBOSM35",
//													"attrs": {
//														"style": "\"front\"",
//														"w": "24",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/link.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1IA1RBOSM36",
//													"attrs": {
//														"type": "#null#>BtnIcon(\"front\",24,0,appCfg.sharedAssets+\"/link.svg\",null)",
//														"id": "BtnLink",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"padding": "3"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IA1RBOSM37",
//													"attrs": {
//														"1GDK908V60": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IA1RBOSM38",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IA1RBOSM39",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1GDK908V60",
//															"faceTagName": "previewOn"
//														},
//														"1GDK90DFD0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IA1RBOSM40",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IA1RBOSM41",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1GDK90DFD0",
//															"faceTagName": "previewOff"
//														},
//														"1GDK90VVM0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IA1RBOSM42",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IA1RBOSM43",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1GDK90VVM0",
//															"faceTagName": "previewOnly"
//														},
//														"1GDK95H3S0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IA1RBOSM44",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IA1RBOSM45",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1GDK95H3S0",
//															"faceTagName": "dragOn"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IA1RBOSM46",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IA1RBOSM47",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "true",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1IA1RBOSM48",
//													"attrs": {}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1GDK7LM301",
//									"attrs": {
//										"1GDK95H3S0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IA1RBOSM53",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IA1RBOSM54",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1GDK95H3S0",
//											"faceTagName": "dragOn"
//										},
//										"1GDK908V60": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IA1SERTA4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IA1SERTA5",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1GDK908V60",
//											"faceTagName": "previewOn"
//										},
//										"1GDK90DFD0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IA1SJCF20",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IA1SJCF21",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1GDK90DFD0",
//											"faceTagName": "previewOff"
//										},
//										"1GDK90VVM0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IA1SJCF22",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IA1SJCF23",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1GDK90VVM0",
//											"faceTagName": "previewOnly"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1GDK7LM302",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1GJ3Q80HH5",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1GDK7LQ9R0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1GDK80NBI0",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxCode",
//										"position": "Absolute",
//										"x": "0",
//										"y": "#cfgSize.headerH",
//										"w": "${state.codeW},state",
//										"h": "#`FH-${cfgSize.headerH}`",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "true",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "\"\"",
//										"styleClass": ""
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1GDK80NBI1",
//									"attrs": {
//										"1GDK908V60": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1GDK9A4GA6",
//											"attrs": {
//												"properties": {
//													"jaxId": "1GDK9A4GA7",
//													"attrs": {
//														"w": {
//															"type": "length",
//															"valText": "${state.codeW},state"
//														},
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1GDK908V60",
//											"faceTagName": "previewOn"
//										},
//										"1GDK90DFD0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1GDK9A4GA8",
//											"attrs": {
//												"properties": {
//													"jaxId": "1GDK9A4GA9",
//													"attrs": {
//														"w": {
//															"type": "length",
//															"valText": "\"FW\""
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1GDK90DFD0",
//											"faceTagName": "previewOff"
//										},
//										"1GDK90VVM0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1GDK9F1OP4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1GDK9F1OP5",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1GDK90VVM0",
//											"faceTagName": "previewOnly"
//										},
//										"1GDK95H3S0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IA1RBOSM55",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IA1RBOSM56",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1GDK95H3S0",
//											"faceTagName": "dragOn"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1GDK80NBI2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1GJ3Q80HH6",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1GDK810R20",
//							"attrs": {
//								"properties": {
//									"jaxId": "1GDK8RTOV0",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxPreview",
//										"position": "Absolute",
//										"x": "${state.codeW+8},state",
//										"y": "#cfgSize.headerH",
//										"w": "${`FW-${state.codeW+8}`},state",
//										"h": "#`FH-${cfgSize.headerH}`",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "true",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,0]",
//										"padding": "[0,0,0,5]",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "\"\"",
//										"styleClass": ""
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1GDK8RTOV1",
//									"attrs": {
//										"1GDK908V60": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1GDK9A4GA12",
//											"attrs": {
//												"properties": {
//													"jaxId": "1GDK9A4GA13",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														},
//														"x": {
//															"type": "length",
//															"valText": "${state.codeW+8},state"
//														},
//														"w": {
//															"type": "length",
//															"valText": "${`FW-${state.codeW+8}`},state"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1GDK908V60",
//											"faceTagName": "previewOn"
//										},
//										"1GDK90VVM0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1GDK9F1OP6",
//											"attrs": {
//												"properties": {
//													"jaxId": "1GDK9F1OP7",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														},
//														"x": {
//															"type": "length",
//															"valText": "0"
//														},
//														"w": {
//															"type": "length",
//															"valText": "\"FW\""
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1GDK90VVM0",
//											"faceTagName": "previewOnly"
//										},
//										"1GDK90DFD0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1GDKJIN1G23",
//											"attrs": {
//												"properties": {
//													"jaxId": "1GDKJIN1G24",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1GDK90DFD0",
//											"faceTagName": "previewOff"
//										},
//										"1GDK95H3S0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IA1RBOSM57",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IA1RBOSM58",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1GDK95H3S0",
//											"faceTagName": "dragOn"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1GDK8RTOV2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1GJ3Q80HH7",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1GDK86JAB0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1GDK8RTOV3",
//									"attrs": {
//										"type": "box",
//										"id": "BoxMidGap",
//										"position": "Absolute",
//										"x": "${state.codeW},state",
//										"y": "#cfgSize.headerH",
//										"w": "8",
//										"h": "#`FH-${cfgSize.headerH}`",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "true",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "8",
//										"margin": "[0,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "\"\"",
//										"styleClass": "",
//										"background": "#[...cfgColor.lineBodyLit,50]",
//										"border": "[0,0,0,0]",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1GDK8DCQC0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1GDK8RTOV4",
//													"attrs": {
//														"type": "box",
//														"id": "",
//														"position": "Absolute",
//														"x": "2",
//														"y": "\"(FH-30)/2\"",
//														"w": "4",
//														"h": "\"30\"",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "true",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "0.50",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[0,0,0,0]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "\"\"",
//														"styleClass": "",
//														"background": "[0,0,0,0]",
//														"border": "[0,1,0,1]",
//														"borderStyle": "Dashed",
//														"borderColor": "#cfgColor.lineBodySub",
//														"corner": "0",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1GDK8RTOV5",
//													"attrs": {
//														"1GDK95H3S0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IA1RBOSN4",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IA1RBOSN5",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1GDK95H3S0",
//															"faceTagName": "dragOn"
//														},
//														"1GDK908V60": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IA1SERTA6",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IA1SERTA7",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1GDK908V60",
//															"faceTagName": "previewOn"
//														},
//														"1GDK90DFD0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IA1SJCF24",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IA1SJCF25",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1GDK90DFD0",
//															"faceTagName": "previewOff"
//														},
//														"1GDK90VVM0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IA1SJCF26",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IA1SJCF27",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1GDK90VVM0",
//															"faceTagName": "previewOnly"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1GDK8RTOV6",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1GJ3Q80HH8",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1GDK8RTOV7",
//									"attrs": {
//										"1GDK95H3S0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1GDK9A4GA20",
//											"attrs": {
//												"properties": {
//													"jaxId": "1GDK9A4GA21",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1GDK95H3S0",
//											"faceTagName": "dragOn"
//										},
//										"1GDK95MO80": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1GDK9A4GA22",
//											"attrs": {
//												"properties": {
//													"jaxId": "1GDK9A4GA23",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1GDK95MO80",
//											"faceTagName": "dragOff"
//										},
//										"1GDK908V60": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1GDK9A4GA24",
//											"attrs": {
//												"properties": {
//													"jaxId": "1GDK9A4GA25",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1GDK908V60",
//											"faceTagName": "previewOn"
//										},
//										"1GDK90DFD0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1GDK9A4GA26",
//											"attrs": {
//												"properties": {
//													"jaxId": "1GDK9A4GA27",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1GDK90DFD0",
//											"faceTagName": "previewOff"
//										},
//										"1GDK90VVM0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1GDK9F1OP14",
//											"attrs": {
//												"properties": {
//													"jaxId": "1GDK9F1OP15",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1GDK90VVM0",
//											"faceTagName": "previewOnly"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1GDK8RTOV8",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1GJ3Q80HH9",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear/@StdUI/ui/BtnSlideSizeX.js",
//							"jaxId": "1GDK7TMT10",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1GDK80NBI3",
//									"attrs": {
//										"start": "null",
//										"update": "null",
//										"fin": "null"
//									}
//								},
//								"properties": {
//									"jaxId": "1GDK80NBI4",
//									"attrs": {
//										"type": "#null#>BtnSlideSizeX(null,null,null)",
//										"id": "SLDSize",
//										"position": "Absolute",
//										"x": "#state.codeW",
//										"y": "#cfgSize.headerH",
//										"display": "On",
//										"face": "",
//										"h": "#`FH-${cfgSize.headerH}`",
//										"w": "8",
//										"zIndex": "8"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1GDK80NBI5",
//									"attrs": {
//										"1GDK90DFD0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1GDK9A4GA30",
//											"attrs": {
//												"properties": {
//													"jaxId": "1GDK9A4GA31",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1GDK90DFD0",
//											"faceTagName": "previewOff"
//										},
//										"1GDK90VVM0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1GDK9F1OP16",
//											"attrs": {
//												"properties": {
//													"jaxId": "1GDK9F1OP17",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1GDK90VVM0",
//											"faceTagName": "previewOnly"
//										},
//										"1GDK908V60": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1GDKJODEI10",
//											"attrs": {
//												"properties": {
//													"jaxId": "1GDKJODEI11",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1GDK908V60",
//											"faceTagName": "previewOn"
//										},
//										"1GDK95H3S0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IA1RBOSN6",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IA1RBOSN7",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1GDK95H3S0",
//											"faceTagName": "dragOn"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1GDK80NBI6",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1GJ3Q80HH10",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "true",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false",
//								"containerSlots": {
//									"jaxId": "1H7A22SBM8",
//									"attrs": {}
//								}
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1GDK6DVVD9",
//					"attrs": {
//						"1GDK95H3S0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1IA1RBOSN12",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IA1RBOSN13",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1GDK95H3S0",
//							"faceTagName": "dragOn"
//						},
//						"1GDK908V60": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1IA1SERTA8",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IA1SERTA9",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1GDK908V60",
//							"faceTagName": "previewOn"
//						},
//						"1GDK90DFD0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1IA1SJCF28",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IA1SJCF29",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1GDK90DFD0",
//							"faceTagName": "previewOff"
//						},
//						"1GDK90VVM0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1IA1SJCF210",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IA1SJCF211",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1GDK90VVM0",
//							"faceTagName": "previewOnly"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1GDK6DVVD10",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1GJ3Q80HH11",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1GDK6DVVD11",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"innerLayout": {
//					"valText": "false"
//				},
//				"marginL": {
//					"valText": "false"
//				},
//				"marginR": {
//					"valText": "false"
//				},
//				"marginT": {
//					"valText": "false"
//				},
//				"marginB": {
//					"valText": "false"
//				},
//				"paddingL": {
//					"valText": "false"
//				},
//				"paddingR": {
//					"valText": "false"
//				},
//				"paddingT": {
//					"valText": "false"
//				},
//				"paddingB": {
//					"valText": "false"
//				},
//				"attach": {
//					"valText": "false"
//				},
//				"face": {
//					"type": "bool",
//					"valText": "false"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}