//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1G9E2UOKI0StartDoc*/
import {AddOn} from "../data/AddOn.js";
import {ToolTabBtn} from "./ToolTabBtn.js";
/*}#1G9E2UOKI0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let ToolView=function(app,addOnCode){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1G9E2UOKI7LocalVals*/
	let boxViews=null;
	let curView=null;
	let appPrj=null;
	let defHash={};
	let defList=[];
	let viewHash={};
	let toolBtnBox=null;
	let boxTabTrk=null;
	let tabHash={};
	let tabList=[];
	let curTab=null;
	/*}#1G9E2UOKI7LocalVals*/
	
	/*#{1G9E2UOKI7PreState*/
	/*}#1G9E2UOKI7PreState*/
	/*#{1G9E2UOKI7PostState*/
	/*}#1G9E2UOKI7PostState*/
	cssVO={
		"hash":"1G9E2UOKI7",nameHost:true,
		"type":"hud","x":0,"y":0,"w":"FW","h":"FH","autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
		children:[
			{
				"hash":"1G9E309K20",
				"type":"hud","id":"BoxViews","x":0,"y":0,"w":"FW","h":`FH-${cfgSize.headerH}`,"autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
			},
			{
				"hash":"1G9E2VNTT0",
				"type":"box","id":"BoxTabs","x":0,"y":"FH","w":"FW","h":cfgSize.headerH,"anchorY":2,"autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"background":cfgColor.head,"borderColor":cfgColor["fontBodySub"],
				children:[
					{
						"hash":"1G9E2VNTU0",
						"type":"box","x":0,"y":0,"w":"FW","h":1,"autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.lineBodySub,
					},
					{
						"hash":"1G9E38AFV0",
						"type":"hud","id":"BoxTabTrk","x":0,"y":0,"w":"FW-30","h":"FH","autoLayout":true,"overflow":1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						"contentLayout":"flex-x",
					}
				],
			}
		],
		/*#{1G9E2UOKI7ExtraCSS*/
		/*}#1G9E2UOKI7ExtraCSS*/
		faces:{
			"focus":{
				/*BoxTabs*/"#1G9E2VNTT0":{
					"background":cfgColor.hot
				}
			},"blur":{
				/*BoxTabs*/"#1G9E2VNTT0":{
					"background":cfgColor.head
				}
			}
		},
		OnCreate:function(){
			self=this;
			
			/*#{1G9E2UOKI7Create*/
			boxViews=self.BoxViews;
			boxTabTrk=self.BoxTabTrk;
			appPrj=app.prj;
			/*}#1G9E2UOKI7Create*/
		},
		/*#{1G9E2UOKI7EndCSS*/
		/*}#1G9E2UOKI7EndCSS*/
	};
	/*#{1G9E2UOKI7PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.initViews=function(btnBox){
		let addOns,addOn,uiDef,ui,icon,tip,codeName;
		let tab,tabVO;
		toolBtnBox=btnBox;
		addOns=AddOn.getAddOns(addOnCode);
		for(addOn of addOns){
			uiDef=addOn.def;
			icon=uiDef.tbxIcon;
			tip=uiDef.tbxTip;
			codeName=uiDef.tbxCodeName;
			defHash[codeName]=uiDef;
			defList.push(uiDef);
	
			//Add tab:
			tabVO={icon:icon,name:codeName,info:tip,text:tip};
			tab=boxTabTrk.appendNewChild(ToolTabBtn(app,self,tabVO,uiDef.tbxIconPad||0));
			tabHash[codeName]=tab;
			tabList.push(tabVO);
			tabList.sort((a,b)=>{
				if(a.text<b.text){
					return -1;
				}
				if(a.text>b.text){
					return 1;
				}
				return 0;
			});
			if(uiDef.loadOnInit){
				self.loadView(codeName);
			}
		}
		//TODO: Trace project docs changes:
	};
	
	//------------------------------------------------------------------------
	cssVO.loadView=async function(codeName){
		let uiView;
		uiView=viewHash[codeName];
		if(!uiView){
			let def,tab;
			tab=tabHash[codeName];
			def=defHash[codeName];
			if(def){
				uiView=boxViews.appendNewChild(def(app,self,tab));
				uiView.hold();
				viewHash[codeName]=uiView;
				boxViews.removeChild(uiView);
			}else{
				return null;
			}
		}
		return uiView;
	};
	
	//------------------------------------------------------------------------
	cssVO.showView=async function(codeName,vo=null){
		let uiView;
		uiView=await self.loadView(codeName);
		if(uiView===curView){
			return uiView;
		}
		if(curView){
			curView.OnHide && curView.OnHide();
			curView.display=0;
		}
		curView=uiView;
	
		if(curTab){
			curTab.showFace("blur");
		}
		curTab=tabHash[codeName];
		if(curTab){
			curTab.showFace("focus");
		}
		
		boxViews.appendChild(uiView);
		toolBtnBox.clearChildren();
		if(uiView.toolBtnBox){
			toolBtnBox.appendChild(uiView.toolBtnBox);
		}
		
		curView.display=1;
		if(curView.OnShow){
			await curView.OnShow();
		}
		return uiView;
	};
	
	//------------------------------------------------------------------------
	cssVO.OnAppFocus=function(){
		self.showFace("focus");
	};
	
	//------------------------------------------------------------------------
	cssVO.OnAppBlur=function(){
		self.showFace("blur");
	};
	
	/*}#1G9E2UOKI7PostCSSVO*/
	return cssVO;
};
/*#{1G9E2UOKI7ExCodes*/
/*}#1G9E2UOKI7ExCodes*/

ToolView.gearExport={
	framework: "vfact",
	hudType: "hud",
	"showName":"Tool View",icon:"gears.svg",previewImg:false,
	fixPose:false,initW:200,initH:300,
	catalog:"",
	args: {
		"app": {
			"name": "app", "showName": "app", "type": "auto", "key": true, "fixed": true, 
			"initVal": null
		}, 
		"addOnCode": {
			"name": "addOnCode", "showName": "addOnCode", "type": "string", "key": true, "fixed": true, "initVal": ""
		}
	},
	state:{
	},
	properties:["id","position","x","y","display"],
	faces:["focus","blur"],
	subContainers:{
	},
	/*#{1G9E2UOKI0ExGearInfo*/
	/*}#1G9E2UOKI0ExGearInfo*/
};
/*#{1G9E2UOKI0EndDoc*/
/*}#1G9E2UOKI0EndDoc*/

export default ToolView;
export{ToolView};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1G9E2UOKI0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1G9E2UOKI1",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1G9E2UOKI2",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1HTGJ3CR10",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1G9E2UOKI3",
//			"attrs": {
//				"app": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"addOnCode": {
//					"type": "string",
//					"valText": ""
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1G9E2UOKI4",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1G9E2UOKI5",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "VFACT document",
//		"gearName": "Tool View",
//		"gearIcon": "gears.svg",
//		"gearW": "200",
//		"gearH": "300",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1G9E2UOKI6",
//			"attrs": {
//				"focus": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1GBKFRDA60",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1GBKFTU4S0",
//							"attrs": {}
//						}
//					}
//				},
//				"blur": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1GBKFRHBA0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1GBKFTU4S1",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1HTGJ3CR11",
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1G9E2UOKI7",
//			"attrs": {
//				"properties": {
//					"jaxId": "1G9E2UOKI8",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "\"FW\"",
//						"h": "\"FH\"",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "true",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "[0,0,0,0]",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "\"\"",
//						"styleClass": ""
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1G9E309K20",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G9E309K21",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxViews",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "\"FW\"",
//										"h": "#`FH-${cfgSize.headerH}`",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "true",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "\"\"",
//										"styleClass": ""
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1G9E309K30",
//									"attrs": {
//										"1GBKFRHBA0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1GBKFTU4S2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1GBKFTU4S3",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1GBKFRHBA0",
//											"faceTagName": "blur"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1G9E309K31",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1GPMF4G530",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1G9E2VNTT0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G9E2VNTT1",
//									"attrs": {
//										"type": "box",
//										"id": "BoxTabs",
//										"position": "Absolute",
//										"x": "0",
//										"y": "\"FH\"",
//										"w": "\"FW\"",
//										"h": "#cfgSize.headerH",
//										"anchorH": "Left",
//										"anchorV": "Bottom",
//										"autoLayout": "true",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "\"\"",
//										"styleClass": "",
//										"background": "#cfgColor.head",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor[\"fontBodySub\"]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1G9E2VNTU0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9E2VNTU1",
//													"attrs": {
//														"type": "box",
//														"id": "",
//														"position": "Absolute",
//														"x": "0",
//														"y": "0",
//														"w": "\"FW\"",
//														"h": "1",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "true",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[0,0,0,0]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "\"\"",
//														"styleClass": "",
//														"background": "#cfgColor.lineBodySub",
//														"border": "0",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1G9E2VNTU2",
//													"attrs": {
//														"1GBKFRHBA0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1GBKFTU4S4",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1GBKFTU4S5",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1GBKFRHBA0",
//															"faceTagName": "blur"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1G9E2VNTU3",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1GPMF4G531",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "true",
//												"container": "true",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1G9E38AFV0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9E39A2V0",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxTabTrk",
//														"position": "Absolute",
//														"x": "0",
//														"y": "0",
//														"w": "\"FW-30\"",
//														"h": "\"FH\"",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "true",
//														"display": "On",
//														"clip": "On",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[0,0,0,0]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "\"\"",
//														"styleClass": "",
//														"contentLayout": "Flex X"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1G9E39A2V1",
//													"attrs": {
//														"1GBKFRHBA0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1GBKFTU4T0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1GBKFTU4T1",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1GBKFRHBA0",
//															"faceTagName": "blur"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1G9E39A2V2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1GPMF4G533",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1G9E2VNTU4",
//									"attrs": {
//										"1GBKFRHBA0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1GBKFTU4T2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1GBKFTU4T3",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor.head"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1GBKFRHBA0",
//											"faceTagName": "blur"
//										},
//										"1GBKFRDA60": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1GBKFTU4T4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1GBKFTU4T5",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor.hot"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1GBKFRDA60",
//											"faceTagName": "focus"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1G9E2VNTU5",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1GPMF4G534",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1G9E2UOKI9",
//					"attrs": {
//						"1GBKFRHBA0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1GBKFTU4T6",
//							"attrs": {
//								"properties": {
//									"jaxId": "1GBKFTU4T7",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1GBKFRHBA0",
//							"faceTagName": "blur"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1G9E2UOKI10",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1GPMF4G535",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1G9E2UOKI11",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"innerLayout": {
//					"valText": "false"
//				},
//				"marginL": {
//					"valText": "false"
//				},
//				"marginR": {
//					"valText": "false"
//				},
//				"marginT": {
//					"valText": "false"
//				},
//				"marginB": {
//					"valText": "false"
//				},
//				"paddingL": {
//					"valText": "false"
//				},
//				"paddingR": {
//					"valText": "false"
//				},
//				"paddingT": {
//					"valText": "false"
//				},
//				"paddingB": {
//					"valText": "false"
//				},
//				"attach": {
//					"valText": "false"
//				},
//				"face": {
//					"type": "bool",
//					"valText": "false"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}