//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnCheck} from "/@StdUI/ui/BtnCheck.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
/*#{1JF31PNA30StartDoc*/
import pathLib from "/@path";
import {assetDef,assetDefItems} from "../AssetDef.js";
/*}#1JF31PNA30StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BoxAIAsset=function(fileStub){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let btnUse,txtFileName,btnType,txtType,btnDigest,txtDigest,txtWork;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1JF31PNA31LocalVals*/
	const app=VFACT.app;
	fileStub.fileName=pathLib.basename(fileStub.path);
	/*}#1JF31PNA31LocalVals*/
	
	/*#{1JF31PNA31PreState*/
	/*}#1JF31PNA31PreState*/
	/*#{1JF31PNA31PostState*/
	/*}#1JF31PNA31PostState*/
	cssVO={
		"hash":"1JF31PNA31",nameHost:true,
		"type":"hud","x":0,"y":0,"w":"100%","h":30,"padding":[0,5,0,5],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x","itemsAlign":1,
		"file":fileStub,
		children:[
			{
				"hash":"1JF31TSRL0",
				"type":BtnCheck(18,"",!!fileStub.active,false),"id":"BtnUse","position":"relative","x":0,"y":0,
				/*#{1JF31TSRL0Codes*/
				OnCheck(checked){
					self.OnActiveClick(checked);
				}
				/*}#1JF31TSRL0Codes*/
			},
			{
				"hash":"1JF32CA7E0",
				"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/folder.svg",null),"id":"BtnOpen","position":"relative","x":0,"y":0,"margin":[0,0,0,3],
				"tip":"打开文件",
				"OnClick":function(event){
					self.OpenFile(this,event);
				},
			},
			{
				"hash":"1JF31USBC0",
				"type":"text","id":"TxtFileName","position":"relative","x":0,"y":0,"w":"","h":"","margin":[0,0,0,5],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"color":cfgColor["fontBody"],"text":fileStub.fileName||fileStub.path,"fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
				"flex":true,
			},
			{
				"hash":"1JF3229AN0",
				"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/btncombo.svg",null),"id":"BtnType","position":"relative","x":0,"y":0,"margin":[0,0,0,3],
				"tip":"文件类型",
				"OnClick":function(event){
					self.ChooseType(this,event);
				},
			},
			{
				"hash":"1JF322SGA0",
				"type":"text","id":"TxtType","position":"relative","x":0,"y":0,"w":"","h":"","margin":[0,5,0,3],"minW":40,"minH":"","maxW":"","maxH":"","styleClass":"",
				"color":cfgColor["fontBody"],"text":fileStub.type,"fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
			},
			{
				"hash":"1JF3256VA0",
				"type":"box","x":10,"y":">calc(100% - 1px)","w":">calc(100% - 20px)","h":1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["fontBodyLit"],
			},
			{
				"hash":"1JF6L856O0",
				"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/btncombo.svg",null),"id":"BtnDigest","position":"relative","x":0,"y":0,"margin":[0,0,0,3],
				"tip":"代码加工",
				"OnClick":function(event){
					self.ChooseDigest(this,event);
				},
			},
			{
				"hash":"1JF6L92560",
				"type":"text","id":"TxtDigest","position":"relative","x":0,"y":0,"w":"","h":"","margin":[0,5,0,3],"minW":40,"minH":"","maxW":"","maxH":"","styleClass":"",
				"color":cfgColor["fontBody"],"text":fileStub.digest||"none","fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
			},
			{
				"hash":"1JF328M290",
				"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/trash.svg",null),"id":"BtnRemove","position":"relative","x":0,"y":0,"margin":[0,0,0,10],
				"tip":"删除文件",
				"OnClick":function(event){
					self.Remove(this,event);
				},
			},
			{
				"hash":"1JF54RI940",
				"type":"text","id":"TxtWork","position":"relative","x":0,"y":0,"w":"","h":"","display":0,"margin":[0,5,0,3],"minW":40,"minH":"","maxW":"","maxH":"",
				"styleClass":"","color":cfgColor["fontBody"],"text":"indexing...","fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
			}
		],
		/*#{1JF31PNA31ExtraCSS*/
		/*}#1JF31PNA31ExtraCSS*/
		faces:{
			"std":{
				/*BtnUse*/"#1JF31TSRL0":{
					"display":1
				},
				/*BtnOpen*/"#1JF32CA7E0":{
					"display":1
				},
				/*BtnType*/"#1JF3229AN0":{
					"display":1
				},
				/*TxtType*/"#1JF322SGA0":{
					"display":1
				},
				/*BtnDigest*/"#1JF6L856O0":{
					"display":1
				},
				/*TxtDigest*/"#1JF6L92560":{
					"display":1
				},
				/*BtnRemove*/"#1JF328M290":{
					"display":1
				},
				/*TxtWork*/"#1JF54RI940":{
					"display":0
				}
			},"working":{
				/*BtnUse*/"#1JF31TSRL0":{
					"display":0
				},
				/*BtnOpen*/"#1JF32CA7E0":{
					"display":0
				},
				/*BtnType*/"#1JF3229AN0":{
					"display":0
				},
				/*TxtType*/"#1JF322SGA0":{
					"display":0
				},
				/*BtnDigest*/"#1JF6L856O0":{
					"display":0
				},
				/*TxtDigest*/"#1JF6L92560":{
					"display":0
				},
				/*BtnRemove*/"#1JF328M290":{
					"display":0
				},
				/*TxtWork*/"#1JF54RI940":{
					"display":1,"text":"digesting..."
				}
			},"wait":{
				/*BtnUse*/"#1JF31TSRL0":{
					"display":0
				},
				/*BtnOpen*/"#1JF32CA7E0":{
					"display":0
				},
				/*BtnType*/"#1JF3229AN0":{
					"display":0
				},
				/*TxtType*/"#1JF322SGA0":{
					"display":0
				},
				/*BtnDigest*/"#1JF6L856O0":{
					"display":0
				},
				/*TxtDigest*/"#1JF6L92560":{
					"display":0
				},
				/*BtnRemove*/"#1JF328M290":{
					"display":0
				},
				/*TxtWork*/"#1JF54RI940":{
					"display":1,"text":"waiting..."
				}
			},"ready":{
				/*TxtWork*/"#1JF54RI940":{
					"text":"digested"
				}
			}
		},
		OnCreate:function(){
			self=this;
			btnUse=self.BtnUse;txtFileName=self.TxtFileName;btnType=self.BtnType;txtType=self.TxtType;btnDigest=self.BtnDigest;txtDigest=self.TxtDigest;txtWork=self.TxtWork;
			/*#{1JF31PNA31Create*/
			/*}#1JF31PNA31Create*/
		},
		/*#{1JF31PNA31EndCSS*/
		/*}#1JF31PNA31EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.ChooseType=async function(){
		/*#{1JF3RB9KV0Start*/
		let items=assetDefItems.slice(0);
		let item=await app.modalDlg("/@StdUI/ui/DlgMenu.js",{
			items:items,hud:btnType
		});
		if(!item){
			return;
		}
		fileStub.type=item.code;
		txtType.text=item.code;
		/*}#1JF3RB9KV0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.ChooseDigest=async function(){
		/*#{1JF6LFU1C0Start*/
		let items=[
			{text:"No digest",code:"none"},
			{text:"Abridge codes",code:"abridge"},
			{text:"Index codes",code:"index"},
		];
		let item=await app.modalDlg("/@StdUI/ui/DlgMenu.js",{
			items:items,hud:btnDigest
		});
		if(!item){
			return;
		}
		fileStub.digest=item.code;
		txtDigest.text=item.code;
		/*}#1JF6LFU1C0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.Remove=async function(){
		/*#{1JF3RBLRD0Start*/
		self.parent.removeChild(self);
		/*}#1JF3RBLRD0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.OpenFile=async function(){
		/*#{1JF3RC0HS0Start*/
		let dir,path;
		if(fileStub.path){
			dir=pathLib.dirname(fileStub.path);
		}else{
			dir=app.prj.path;
		}
		path=await app.modalDlg("/@StdUI/ui/DlgFile.js",{
			path:dir,mode:"Open",title:"Choose Asset"
		});
		if(!path){
			return;
		}
		fileStub.path=path;
		fileStub.fileName=pathLib.basename(path);
		txtFileName.text=path;
		/*}#1JF3RC0HS0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.OnActiveClick=async function(checked){
		/*#{1JF3RCOTQ0Start*/
		fileStub.active=!!checked;
		/*}#1JF3RCOTQ0Start*/
	};
	/*#{1JF31PNA31PostCSSVO*/
	/*}#1JF31PNA31PostCSSVO*/
	cssVO.constructor=BoxAIAsset;
	return cssVO;
};
/*#{1JF31PNA31ExCodes*/
/*}#1JF31PNA31ExCodes*/

//----------------------------------------------------------------------------
BoxAIAsset.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1JF31PNA31PreAISpot*/
	/*}#1JF31PNA31PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1JF31PNA31PostAISpot*/
	/*}#1JF31PNA31PostAISpot*/
	return exposeVO;
};

/*#{1JF31PNA30EndDoc*/
/*}#1JF31PNA30EndDoc*/

export default BoxAIAsset;
export{BoxAIAsset};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1JF31PNA30",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1JF31PNA40",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1JF31PNA41",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1JF31PNA42",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1JF31PNA43",
//			"attrs": {
//				"fileStub": {
//					"type": "object",
//					"def": "FlatObj",
//					"jaxId": "1JF3O8PN70",
//					"attrs": {
//						"path": {
//							"type": "string",
//							"valText": "./ai/chatbot.js"
//						},
//						"type": {
//							"type": "string",
//							"valText": "reference"
//						},
//						"active": {
//							"type": "bool",
//							"valText": "true"
//						},
//						"fileName": {
//							"type": "string",
//							"valText": "path.js"
//						},
//						"index": {
//							"type": "bool",
//							"valText": "false"
//						},
//						"digest": {
//							"type": "string",
//							"valText": "none"
//						}
//					}
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1JF31PNA44",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1JF31PNA45",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1JF3RB9KV0",
//					"attrs": {
//						"id": "ChooseType",
//						"label": "New AI Seg",
//						"x": "75",
//						"y": "75",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1JF3RDB8S0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1JF3RDB8S1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1JF3RDB8S2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1JF6LFU1C0",
//					"attrs": {
//						"id": "ChooseDigest",
//						"label": "New AI Seg",
//						"x": "315",
//						"y": "75",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1JF6LG7EN0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1JF6LG7EN1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1JF6LG7EN2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1JF3RBLRD0",
//					"attrs": {
//						"id": "Remove",
//						"label": "New AI Seg",
//						"x": "75",
//						"y": "165",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1JF3RDB8S3",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1JF3RDB8S4",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1JF3RDB8S5",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1JF3RC0HS0",
//					"attrs": {
//						"id": "OpenFile",
//						"label": "New AI Seg",
//						"x": "75",
//						"y": "255",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1JF3RDB8S6",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1JF3RDB8S7",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1JF3RDB8S8",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1JF3RCOTQ0",
//					"attrs": {
//						"id": "OnActiveClick",
//						"label": "New AI Seg",
//						"x": "75",
//						"y": "345",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1JF3RDB8S9",
//							"attrs": {
//								"checked": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1JF3RDB8S10",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1JF3RDB8S11",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				}
//			]
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1JF31PNA46",
//			"attrs": {
//				"std": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1JF54OH5C0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1JF54SEV50",
//							"attrs": {}
//						}
//					}
//				},
//				"working": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1JF54ON7Q0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1JF54SEV51",
//							"attrs": {}
//						}
//					}
//				},
//				"wait": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1JF80B7RT0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1JF80GVSA0",
//							"attrs": {}
//						}
//					}
//				},
//				"ready": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1JF80BM4F0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1JF80GVSA1",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1JF31PNA47",
//			"attrs": {}
//		},
//		"exposeToAI": "true",
//		"descAI": "",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1JF31PNA31",
//			"attrs": {
//				"properties": {
//					"jaxId": "1JF31PNA48",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "30",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "[0,5,0,5]",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Flex X",
//						"itemsAlign": "Center"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "Gear/@StdUI/ui/BtnCheck.js",
//							"jaxId": "1JF31TSRL0",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1JF320FEM0",
//									"attrs": {
//										"size": "18",
//										"text": "",
//										"checked": "#!!fileStub.active",
//										"radio": "false"
//									}
//								},
//								"properties": {
//									"jaxId": "1JF320FEM1",
//									"attrs": {
//										"type": "#null#>BtnCheck(18,\"\",!!fileStub.active,false)",
//										"id": "BtnUse",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"display": "On",
//										"face": ""
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1JF320FEM2",
//									"attrs": {
//										"1JF54ON7Q0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1JF54SEV52",
//											"attrs": {
//												"properties": {
//													"jaxId": "1JF54SEV53",
//													"attrs": {
//														"display": "Off"
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1JF54ON7Q0",
//											"faceTagName": "working"
//										},
//										"1JF54OH5C0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1JF54SEV54",
//											"attrs": {
//												"properties": {
//													"jaxId": "1JF54SEV55",
//													"attrs": {
//														"display": "On"
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1JF54OH5C0",
//											"faceTagName": "std"
//										},
//										"1JF80B7RT0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1JF80GVSA2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1JF80GVSA3",
//													"attrs": {
//														"display": "Off"
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1JF80B7RT0",
//											"faceTagName": "wait"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1JF320FEM3",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1JF320FEN0",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "true",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true",
//								"containerSlots": {
//									"jaxId": "1JF320FEN1",
//									"attrs": {}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear/@StdUI/ui/BtnIcon.js",
//							"jaxId": "1JF32CA7E0",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1JF32CA7E1",
//									"attrs": {
//										"style": "\"front\"",
//										"w": "24",
//										"h": "0",
//										"icon": "#appCfg.sharedAssets+\"/folder.svg\"",
//										"colorBG": "null"
//									}
//								},
//								"properties": {
//									"jaxId": "1JF32CA7F0",
//									"attrs": {
//										"type": "#null#>BtnIcon(\"front\",24,0,appCfg.sharedAssets+\"/folder.svg\",null)",
//										"id": "BtnOpen",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"display": "On",
//										"face": "",
//										"margin": "[0,0,0,3]"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1JF32CA7F1",
//									"attrs": {
//										"1JF54ON7Q0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1JF54SEV56",
//											"attrs": {
//												"properties": {
//													"jaxId": "1JF54SEV57",
//													"attrs": {
//														"display": "Off"
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1JF54ON7Q0",
//											"faceTagName": "working"
//										},
//										"1JF54OH5C0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1JF54SEV58",
//											"attrs": {
//												"properties": {
//													"jaxId": "1JF54SEV59",
//													"attrs": {
//														"display": "On"
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1JF54OH5C0",
//											"faceTagName": "std"
//										},
//										"1JF80B7RT0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1JF80GVSA6",
//											"attrs": {
//												"properties": {
//													"jaxId": "1JF80GVSA7",
//													"attrs": {
//														"display": "Off"
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1JF80B7RT0",
//											"faceTagName": "wait"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1JF32CA7F2",
//									"attrs": {
//										"OnClick": {
//											"type": "fixedFunc",
//											"jaxId": "1JF3UOBF50",
//											"attrs": {
//												"callArgs": {
//													"jaxId": "1JF3UOBF51",
//													"attrs": {
//														"event": ""
//													}
//												},
//												"seg": "1JF3RC0HS0"
//											}
//										}
//									}
//								},
//								"extraPpts": {
//									"jaxId": "1JF32CA7F3",
//									"attrs": {
//										"tip": {
//											"type": "string",
//											"valText": "打开文件",
//											"localizable": true
//										}
//									}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false",
//								"containerSlots": {
//									"jaxId": "1JF32CA7F4",
//									"attrs": {}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1JF31USBC0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1JF320FEN2",
//									"attrs": {
//										"type": "text",
//										"id": "TxtFileName",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,5]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#cfgColor[\"fontBody\"]",
//										"text": "#fileStub.fileName||fileStub.path",
//										"font": "",
//										"fontSize": "#txtSize.smallMid",
//										"bold": "false",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Top",
//										"wrap": "false",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0",
//										"flex": "true"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1JF320FEN3",
//									"attrs": {
//										"1JF54ON7Q0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1JF54SEV510",
//											"attrs": {
//												"properties": {
//													"jaxId": "1JF54SEV511",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1JF54ON7Q0",
//											"faceTagName": "working"
//										},
//										"1JF54OH5C0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1JF80GVSA10",
//											"attrs": {
//												"properties": {
//													"jaxId": "1JF80GVSA11",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1JF54OH5C0",
//											"faceTagName": "std"
//										},
//										"1JF80B7RT0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1JF80GVSA12",
//											"attrs": {
//												"properties": {
//													"jaxId": "1JF80GVSA13",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1JF80B7RT0",
//											"faceTagName": "wait"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1JF320FEN4",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1JF320FEN5",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear/@StdUI/ui/BtnIcon.js",
//							"jaxId": "1JF3229AN0",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1JF3247J60",
//									"attrs": {
//										"style": "\"front\"",
//										"w": "24",
//										"h": "0",
//										"icon": "#appCfg.sharedAssets+\"/btncombo.svg\"",
//										"colorBG": "null"
//									}
//								},
//								"properties": {
//									"jaxId": "1JF3247J61",
//									"attrs": {
//										"type": "#null#>BtnIcon(\"front\",24,0,appCfg.sharedAssets+\"/btncombo.svg\",null)",
//										"id": "BtnType",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"display": "On",
//										"face": "",
//										"margin": "[0,0,0,3]"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1JF3247J62",
//									"attrs": {
//										"1JF54ON7Q0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1JF54SEV512",
//											"attrs": {
//												"properties": {
//													"jaxId": "1JF54SEV513",
//													"attrs": {
//														"display": "Off"
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1JF54ON7Q0",
//											"faceTagName": "working"
//										},
//										"1JF54OH5C0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1JF54SEV514",
//											"attrs": {
//												"properties": {
//													"jaxId": "1JF54SEV515",
//													"attrs": {
//														"display": "On"
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1JF54OH5C0",
//											"faceTagName": "std"
//										},
//										"1JF80B7RT0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1JF80GVSA16",
//											"attrs": {
//												"properties": {
//													"jaxId": "1JF80GVSA17",
//													"attrs": {
//														"display": "Off"
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1JF80B7RT0",
//											"faceTagName": "wait"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1JF3247J63",
//									"attrs": {
//										"OnClick": {
//											"type": "fixedFunc",
//											"jaxId": "1JF3UOBF60",
//											"attrs": {
//												"callArgs": {
//													"jaxId": "1JF3UOBF61",
//													"attrs": {
//														"event": ""
//													}
//												},
//												"seg": "1JF3RB9KV0"
//											}
//										}
//									}
//								},
//								"extraPpts": {
//									"jaxId": "1JF3247J64",
//									"attrs": {
//										"tip": {
//											"type": "string",
//											"valText": "文件类型",
//											"localizable": true
//										}
//									}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true",
//								"containerSlots": {
//									"jaxId": "1JF3247J65",
//									"attrs": {}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1JF322SGA0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1JF3247J66",
//									"attrs": {
//										"type": "text",
//										"id": "TxtType",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,5,0,3]",
//										"padding": "",
//										"minW": "40",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#cfgColor[\"fontBody\"]",
//										"text": "#fileStub.type",
//										"font": "",
//										"fontSize": "#txtSize.smallMid",
//										"bold": "false",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Top",
//										"wrap": "false",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1JF3247J67",
//									"attrs": {
//										"1JF54ON7Q0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1JF54RGTS0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1JF54RGTS1",
//													"attrs": {
//														"display": "Off"
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1JF54ON7Q0",
//											"faceTagName": "working"
//										},
//										"1JF54OH5C0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1JF54RGTS2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1JF54RGTS3",
//													"attrs": {
//														"display": "On"
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1JF54OH5C0",
//											"faceTagName": "std"
//										},
//										"1JF80B7RT0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1JF80GVSA20",
//											"attrs": {
//												"properties": {
//													"jaxId": "1JF80GVSA21",
//													"attrs": {
//														"display": "Off"
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1JF80B7RT0",
//											"faceTagName": "wait"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1JF3247J68",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1JF3247J69",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1JF3256VA0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1JF32616F0",
//									"attrs": {
//										"type": "box",
//										"id": "",
//										"position": "Absolute",
//										"x": "10",
//										"y": "100%-1",
//										"w": "100%-20",
//										"h": "1",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"fontBodyLit\"]",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1JF32616F1",
//									"attrs": {
//										"1JF54ON7Q0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1JF54SEV516",
//											"attrs": {
//												"properties": {
//													"jaxId": "1JF54SEV517",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1JF54ON7Q0",
//											"faceTagName": "working"
//										},
//										"1JF54OH5C0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1JF80GVSA24",
//											"attrs": {
//												"properties": {
//													"jaxId": "1JF80GVSA25",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1JF54OH5C0",
//											"faceTagName": "std"
//										},
//										"1JF80B7RT0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1JF80GVSA26",
//											"attrs": {
//												"properties": {
//													"jaxId": "1JF80GVSA27",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1JF80B7RT0",
//											"faceTagName": "wait"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1JF32616F2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1JF32616F3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear/@StdUI/ui/BtnIcon.js",
//							"jaxId": "1JF6L856O0",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1JF6L856O1",
//									"attrs": {
//										"style": "\"front\"",
//										"w": "24",
//										"h": "0",
//										"icon": "#appCfg.sharedAssets+\"/btncombo.svg\"",
//										"colorBG": "null"
//									}
//								},
//								"properties": {
//									"jaxId": "1JF6L856O2",
//									"attrs": {
//										"type": "#null#>BtnIcon(\"front\",24,0,appCfg.sharedAssets+\"/btncombo.svg\",null)",
//										"id": "BtnDigest",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"display": "On",
//										"face": "",
//										"margin": "[0,0,0,3]"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1JF6L856O3",
//									"attrs": {
//										"1JF54ON7Q0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1JF6L856O4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1JF6L856O5",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1JF54ON7Q0",
//											"faceTagName": "working"
//										},
//										"1JF54OH5C0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1JF6L856O6",
//											"attrs": {
//												"properties": {
//													"jaxId": "1JF6L856O7",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1JF54OH5C0",
//											"faceTagName": "std"
//										},
//										"1JF80B7RT0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1JF80GVSA30",
//											"attrs": {
//												"properties": {
//													"jaxId": "1JF80GVSA31",
//													"attrs": {
//														"display": "Off"
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1JF80B7RT0",
//											"faceTagName": "wait"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1JF6L856O8",
//									"attrs": {
//										"OnClick": {
//											"type": "fixedFunc",
//											"jaxId": "1JF6L856O9",
//											"attrs": {
//												"callArgs": {
//													"jaxId": "1JF6L856O10",
//													"attrs": {
//														"event": ""
//													}
//												},
//												"seg": "1JF6LFU1C0"
//											}
//										}
//									}
//								},
//								"extraPpts": {
//									"jaxId": "1JF6L856O11",
//									"attrs": {
//										"tip": {
//											"type": "string",
//											"valText": "代码加工",
//											"localizable": true
//										}
//									}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true",
//								"containerSlots": {
//									"jaxId": "1JF6L856O12",
//									"attrs": {}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1JF6L92560",
//							"attrs": {
//								"properties": {
//									"jaxId": "1JF6L92561",
//									"attrs": {
//										"type": "text",
//										"id": "TxtDigest",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,5,0,3]",
//										"padding": "",
//										"minW": "40",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#cfgColor[\"fontBody\"]",
//										"text": "#fileStub.digest||\"none\"",
//										"font": "",
//										"fontSize": "#txtSize.smallMid",
//										"bold": "false",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Top",
//										"wrap": "false",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1JF6L92562",
//									"attrs": {
//										"1JF54ON7Q0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1JF6L92563",
//											"attrs": {
//												"properties": {
//													"jaxId": "1JF6L92564",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1JF54ON7Q0",
//											"faceTagName": "working"
//										},
//										"1JF54OH5C0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1JF6L92570",
//											"attrs": {
//												"properties": {
//													"jaxId": "1JF6L92571",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1JF54OH5C0",
//											"faceTagName": "std"
//										},
//										"1JF80B7RT0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1JF80GVSA34",
//											"attrs": {
//												"properties": {
//													"jaxId": "1JF80GVSA35",
//													"attrs": {
//														"display": "Off"
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1JF80B7RT0",
//											"faceTagName": "wait"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1JF6L92572",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1JF6L92573",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear/@StdUI/ui/BtnIcon.js",
//							"jaxId": "1JF328M290",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1JF328M291",
//									"attrs": {
//										"style": "\"front\"",
//										"w": "24",
//										"h": "0",
//										"icon": "#appCfg.sharedAssets+\"/trash.svg\"",
//										"colorBG": "null"
//									}
//								},
//								"properties": {
//									"jaxId": "1JF328M292",
//									"attrs": {
//										"type": "#null#>BtnIcon(\"front\",24,0,appCfg.sharedAssets+\"/trash.svg\",null)",
//										"id": "BtnRemove",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"display": "On",
//										"face": "",
//										"margin": "[0,0,0,10]"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1JF328M293",
//									"attrs": {
//										"1JF54ON7Q0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1JF54SEV522",
//											"attrs": {
//												"properties": {
//													"jaxId": "1JF54SEV523",
//													"attrs": {
//														"display": "Off"
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1JF54ON7Q0",
//											"faceTagName": "working"
//										},
//										"1JF54OH5C0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1JF54SEV524",
//											"attrs": {
//												"properties": {
//													"jaxId": "1JF54SEV525",
//													"attrs": {
//														"display": "On"
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1JF54OH5C0",
//											"faceTagName": "std"
//										},
//										"1JF80B7RT0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1JF80GVSB0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1JF80GVSB1",
//													"attrs": {
//														"display": "Off"
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1JF80B7RT0",
//											"faceTagName": "wait"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1JF328M294",
//									"attrs": {
//										"OnClick": {
//											"type": "fixedFunc",
//											"jaxId": "1JF3UOBF62",
//											"attrs": {
//												"callArgs": {
//													"jaxId": "1JF3UOBF63",
//													"attrs": {
//														"event": ""
//													}
//												},
//												"seg": "1JF3RBLRD0"
//											}
//										}
//									}
//								},
//								"extraPpts": {
//									"jaxId": "1JF328M295",
//									"attrs": {
//										"tip": {
//											"type": "string",
//											"valText": "删除文件",
//											"localizable": true
//										}
//									}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false",
//								"containerSlots": {
//									"jaxId": "1JF328M296",
//									"attrs": {}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1JF54RI940",
//							"attrs": {
//								"properties": {
//									"jaxId": "1JF54RI941",
//									"attrs": {
//										"type": "text",
//										"id": "TxtWork",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "Off",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,5,0,3]",
//										"padding": "",
//										"minW": "40",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#cfgColor[\"fontBody\"]",
//										"text": "indexing...",
//										"font": "",
//										"fontSize": "#txtSize.smallMid",
//										"bold": "false",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Top",
//										"wrap": "false",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1JF54RI950",
//									"attrs": {
//										"1JF54ON7Q0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1JF54RI951",
//											"attrs": {
//												"properties": {
//													"jaxId": "1JF54RI952",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														},
//														"text": "digesting..."
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1JF54ON7Q0",
//											"faceTagName": "working"
//										},
//										"1JF54OH5C0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1JF54RI953",
//											"attrs": {
//												"properties": {
//													"jaxId": "1JF54RI954",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1JF54OH5C0",
//											"faceTagName": "std"
//										},
//										"1JF80B7RT0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1JF80GVSB4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1JF80GVSB5",
//													"attrs": {
//														"display": "On",
//														"text": "waiting..."
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1JF80B7RT0",
//											"faceTagName": "wait"
//										},
//										"1JF80BM4F0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1JF80GVSB6",
//											"attrs": {
//												"properties": {
//													"jaxId": "1JF80GVSB7",
//													"attrs": {
//														"text": "digested"
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1JF80BM4F0",
//											"faceTagName": "ready"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1JF54RI955",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1JF54RI956",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1JF31PNA49",
//					"attrs": {
//						"1JF54ON7Q0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1JF54SEV526",
//							"attrs": {
//								"properties": {
//									"jaxId": "1JF54SEV527",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1JF54ON7Q0",
//							"faceTagName": "working"
//						},
//						"1JF54OH5C0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1JF80GVSB8",
//							"attrs": {
//								"properties": {
//									"jaxId": "1JF80GVSB9",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1JF54OH5C0",
//							"faceTagName": "std"
//						},
//						"1JF80B7RT0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1JF80GVSB10",
//							"attrs": {
//								"properties": {
//									"jaxId": "1JF80GVSB11",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1JF80B7RT0",
//							"faceTagName": "wait"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1JF31PNA410",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1JF31PNA411",
//					"attrs": {
//						"file": {
//							"type": "auto",
//							"valText": "#fileStub"
//						}
//					}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1JF31PNA412",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}