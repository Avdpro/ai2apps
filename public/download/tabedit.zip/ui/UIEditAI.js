//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnText} from "/@StdUI/ui/BtnText.js";
import {BoxRange} from "/@StdUI/ui/BoxRange.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
import {BtnSwitch} from "/@StdUI/ui/BtnSwitch.js";
/*#{1H04Q8C9M0StartDoc*/
import {tabNT} from "/@tabos";
import {AddOn} from "../data/AddOn.js";
import {DlgFile} from "/@StdUI/ui/DlgFile.js";
import {DlgMenu} from "/@StdUI/ui/DlgMenu.js";
import {BtnAIChatMsg} from "./BtnAIChatMsg.js";
import {makeObjEventEmitter,makeNotify} from "/@events";
import pathLib from "/@path";

const DlgLogin="/@homekit/ui/DlgLogin.js";
//----------------------------------------------------------------------------
const ChatModels={
	"GPT-3.5":{text:"GPT-3.5",maxToken:4096,model:"gpt-3.5-turbo"},
	"GPT-4":{text:"GPT-4",maxToken:8192,model:"gpt-4"},
	"GPT-3.5 16K":{text:"GPT-3.5 16K",maxToken:16*1024-32,model:"gpt-3.5-turbo-16k"},
	"GPT-4 32K":{text:"GPT-4 32K",maxToken:32*1024-32,model:"gpt-4-32k"},
};

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
let DataAIChatDoc=function(app,doc){
	this.app=app;
	this.doc=doc;
	this.sysMsg="You are a smart assistant.";
	this.sysMsgTokens=-1;
	this.chatMsgs=[];
	this.name="";
	this.info="";
	this.greeting="";
	this.userMsgPrefix="";
	this.userMsgPostfix="";
	this.filterInit="";
	this.filterReset="";
	this.filterInput="";
	this.filterOutput="";
	this.filterEndRound="";
	this.filterCompress="";
	this.apiFiles="";
	this.memoryChatNum=10;
	this.compressChatNum=6;
	this.secretInternal=false;
	this.allowFileInput=false;
	this.execOnStart=false;
	this.config={
		model:"GPT-3.5",
		temperature:0,
		maxToken:2048,
		topP:1,fqcP:0,prcP:0
	};
	this.readDoc();
};
DataAIChatDoc.prototype={};
let dataAIChatDoc=DataAIChatDoc.prototype;

//----------------------------------------------------------------------------
dataAIChatDoc.readDoc=function(){
	let docText,saveVO;
	docText=this.doc.getDocText();
	try{
		saveVO=JSON.parse(docText);
	}catch(err){
		saveVO={};
	}
	if(!saveVO.config){
		saveVO.config={};
	}
	this.loadFmVO(saveVO);
};

//----------------------------------------------------------------------------
dataAIChatDoc.genDocText=function(){
	let saveVO;
	saveVO=this.genSaveVO();
	return JSON.stringify(saveVO,null,"\t");
};

//----------------------------------------------------------------------------
dataAIChatDoc.loadFmVO=function(vo){
	let srcList,tgtList,msg;
	this.name=vo.name||(pathLib.basename(this.doc.name||this.doc.path));
	this.info=vo.info||"AIChat playground.";
	this.greeting=vo.greeting||"";
	this.sysMsg=vo.sysMsg;
	this.userMsgPrefix=vo.userMsgPrefix||"";
	this.userMsgPostfix=vo.userMsgPostfix||"";
	this.config.model=vo.config.model||"GPT-3.5";
	this.config.temperature=vo.config.temperature||0;
	this.config.maxToken=vo.config.maxToken||2048;
	this.config.topP=vo.config.topP||1;
	this.config.fqcP=vo.config.fqcP||0;
	this.config.prcP=vo.config.prcP||0;
	this.filterInit=vo.filterInit||"";
	this.filterReset=vo.filterReset||"";
	this.filterInput=vo.filterInput||"";
	this.filterOutput=vo.filterOutput||"";
	this.filterEndRound=vo.filterEndRound||"";
	this.filterCompress=vo.filterCompress||"";
	this.apiFiles=vo.apiFiles||"";
	this.memoryChatNum=vo.memoryChatNum>=0?vo.memoryChatNum:200;
	this.compressChatNum=vo.compressChatNum>=0?vo.compressChatNum:6;
	this.secretInternal=vo.secretInternal===true;
	this.allowFileInput=vo.allowFileInput===true;
	this.execOnStart=vo.execOnStart===true;
	srcList=vo.chatMsgs;
	tgtList=this.chatMsgs=[];
	if(!Array.isArray(srcList)){
		srcList=[];
	}
	for(msg of srcList){
		tgtList.push(VFACT.flexState({...msg,tokens:-1}));
	}
	if(!tgtList.length){
		tgtList.push(VFACT.flexState({"role":"user","content":"hello",tokens:-1}));
	}
};

//----------------------------------------------------------------------------
dataAIChatDoc.genSaveVO=function(){
	let saveVO,tgtList,srcList,msg;
	saveVO={
		name:this.name,
		info:this.info,
		greeting:this.greeting,
		sysMsg:this.sysMsg,
		userMsgPrefix:this.userMsgPrefix,
		userMsgPostfix:this.userMsgPostfix,
		chatMsgs:[],
		config:{...this.config},
		filterInit:this.filterInit,
		filterReset:this.filterReset,
		filterInput:this.filterInput,
		filterOutput:this.filterOutput,
		filterEndRound:this.filterEndRound,
		filterCompress:this.filterCompress,
		memoryChatNum:this.memoryChatNum,
		compressChatNum:this.compressChatNum,
		secretInternal:!!this.secretInternal,
		allowFileInput:!!this.allowFileInput,
		execOnStart:!!this.execOnStart,
		apiFiles:this.apiFiles||"",
	};
	tgtList=saveVO.chatMsgs;
	srcList=this.chatMsgs;
	for(msg of srcList){
		tgtList.push({role:msg.role,content:msg.content});
	}
	return saveVO;
};

//----------------------------------------------------------------------------
dataAIChatDoc.genCallVO=function(){
	let callVO,cfg;
	cfg=this.config;
	switch(cfg.model){
		case "GPT-3.5":
		case "GPT-4":
		default:{
			let messages,msgs,msg,blk;
			messages=[];
			callVO={
				model:ChatModels[cfg.model]?ChatModels[cfg.model].model:"gpt-3.5-turbo",
				temperature:cfg.temperature,
				max_tokens:cfg.maxToken,
				top_p:cfg.topP,
				presence_penalty:cfg.prcP,
				frequency_penalty:cfg.fqcP,
				messages:messages,
			};
			msgs=this.chatMsgs;
			messages.push({role:"system",content:this.sysMsg});
			for(msg of msgs){
				blk=msg.block;
				if(blk){
					blk.syncMsg();
				}
				if(msg.role==="user"){
					messages.push({role:msg.role,content:this.userMsgPrefix+"\n"+msg.content+"\n"+this.userMsgPostfix});
				}else if(msg.role==="raw"){
					messages.push({role:"user",content:msg.content});
				}else{
					messages.push({role:msg.role,content:msg.content});
				}
			}
		}
	};
	return callVO;
};

//----------------------------------------------------------------------------
dataAIChatDoc.genCode=function(idx){
	let messages,cfg,i;
	cfg=this.config;
	switch(cfg.model){
		case "GPT-3.5":
		case "GPT-4":
		default:{
			let msgs,msg,blk,i;
			messages=[];
			msgs=this.chatMsgs;
			messages.push({role:"system",content:this.sysMsg});
			for(i=0;i<=idx;i++){
				msg=msgs[i];
				blk=msg.block;
				if(blk){
					blk.syncMsg();
				}
				if(msg.role==="user"){
					messages.push({role:msg.role,content:this.userMsgPrefix+"\n"+msg.content+"\n"+this.userMsgPostfix});
				}else if(msg.role==="raw"){
					messages.push({role:"user",content:msg.content});
				}else{
					messages.push({role:msg.role,content:msg.content});
				}
			}
		}
	};
	return "let messages="+JSON.stringify(messages,null,"\t");
};

/*}#1H04Q8C9M0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let UIEditAI=function(app,mode,codeText,cfgVO,dataDoc){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let btnChatModel,txtTemperature,btnTemperature,txtMaxToken,btnMaxToken,txtTopP,btnTopP,txtFqcP,btnFqcP,txtPrcP,btnPrcP,edChatName,edChatInfo,edGreeting,txtSysTokens,edSysMsg,edPrefix,edPostfix,hudMsgList,txtAllTokens,btnCalTokens,btnShowAdv,boxAdvanced,txtMem,btnMem,txtCompress,btnCompress,btnSecretInternal,btnAllowFile,btnInitExec,edFilterInit,edFilterReset,edFilterInput,edFilterOutput,edFilterRound,edFilterCompress,edBotAPIFile;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1H04Q8C9M1LocalVals*/
	let appPrj=app.prj;
	let dataDocs=appPrj?appPrj.docs:app.docs;
	let chatDoc=new DataAIChatDoc(app,dataDoc);
	let docPath=pathLib.dirname(dataDoc.path);
	let msgBlks=[];
	let editingBlk=null;
	let editVersion=0;
	let executing=false;
	let execBlk=null;
	let msgVersion=0;
	let tokenVersion=-1;
	let pendingHistory=false;
	let pendingHistoryHud=null;
	let history=[];
	let historyIdx=0;
	/*}#1H04Q8C9M1LocalVals*/
	
	/*#{1H04Q8C9M1PreState*/
	/*}#1H04Q8C9M1PreState*/
	state={
		"cfgFrmW":260,"hudBtmH":50,"userTokens":-1,"userGas":-1,
		/*#{1H04Q8C9M6ExState*/
		/*}#1H04Q8C9M6ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1H04Q8C9M1PostState*/
	/*}#1H04Q8C9M1PostState*/
	cssVO={
		"hash":"1H04Q8C9M1",nameHost:true,
		"type":"hud","x":0,"y":0,"w":"FW","h":"FH","autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
		children:[
			{
				"hash":"1H04QFDMC0",
				"type":"hud","id":"HudCfgFrm","x":0,"y":0,"w":$P(()=>(state.cfgFrmW),state),"h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				children:[
					{
						"hash":"1H04QQRGC0",
						"type":"hud","id":"HudCfgBox","x":0,"y":0,"w":"100%","h":"100%","padding":[0,10,0,10],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
						children:[
							{
								"hash":"1H04QV7C20",
								"type":BtnText("secondary",180,24,"Model: GPT-3.5",false,""),"id":"BtnChatModel","position":"relative","x":"50%","y":0,"anchorX":1,"margin":[5,0,0,0],
								"corner":3,
								"OnClick":function(event){
									/*#{1H07EK69K0FunctionBody*/
									self.doChangeModel();
									/*}#1H07EK69K0FunctionBody*/
								},
							},
							{
								"hash":"1H04RO3J80",
								"type":"box","position":"relative","x":20,"y":0,"w":">calc(100% - 40px)","h":1,"margin":[10,0,10,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
								"background":cfgColor["lineBodySub"],
							},
							{
								"hash":"1H04S3U4J0",
								"type":"hud","id":"BoxTemperature","position":"relative","x":0,"y":0,"w":"100%","h":50,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
								children:[
									{
										"hash":"1H04S4C9G0",
										"type":"text","x":0,"y":0,"w":"100%","h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor.fontBody,"text":(($ln==="CN")?("温度(Temperature):"):("Temperature:")),
										"fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,
									},
									{
										"hash":"1H04S5M580",
										"type":"text","id":"TxtTemperature","x":0,"y":0,"w":"100%","h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor.fontBody,
										"text":"20","fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignH":2,"alignV":1,
									},
									{
										"hash":"1H04S4EOE0",
										"type":BoxRange(1,0,2),"id":"BtnTemperature","x":0,"y":20,"w":"100%","margin":[5,0,0,0],"digit":0,"step":0.1,"h":20,"buttonSize":20,
										/*#{1H04S4EOE0Codes*/
										OnChange(){
											self.syncConfig(true,this);
										}
										/*}#1H04S4EOE0Codes*/
									}
								],
							},
							{
								"hash":"1H04SBRNC0",
								"type":"hud","id":"BoxMaxToken","position":"relative","x":0,"y":0,"w":"100%","h":50,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
								children:[
									{
										"hash":"1H04SBRND0",
										"type":"text","x":0,"y":0,"w":"100%","h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor.fontBody,"text":(($ln==="CN")?("最大词元数(Max tokens):"):("Max tokens:")),
										"fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,
									},
									{
										"hash":"1H04SBRND5",
										"type":"text","id":"TxtMaxToken","x":0,"y":0,"w":"100%","h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor.fontBody,
										"text":"4800","fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignH":2,"alignV":1,
									},
									{
										"hash":"1H04SBRND10",
										"type":BoxRange(1024,0,3096),"id":"BtnMaxToken","x":0,"y":20,"w":"100%","margin":[5,0,0,0],"step":50,"digit":0,"h":20,"buttonSize":20,
										/*#{1H04SBRND10Codes*/
										OnChange(){
											self.syncConfig(true,this);
										}
										/*}#1H04SBRND10Codes*/
									}
								],
							},
							{
								"hash":"1H04SGD1P0",
								"type":"hud","id":"BoxTopP","position":"relative","x":0,"y":0,"w":"100%","h":50,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
								children:[
									{
										"hash":"1H04SGD1P2",
										"type":"text","x":0,"y":0,"w":"100%","h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor.fontBody,"text":(($ln==="CN")?("P峰值(Top P):"):("Top P:")),
										"fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,
									},
									{
										"hash":"1H04SGD1Q3",
										"type":"text","id":"TxtTopP","x":0,"y":0,"w":"100%","h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor.fontBody,
										"text":"1","fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignH":2,"alignV":1,
									},
									{
										"hash":"1H04SGD1Q8",
										"type":BoxRange(1,0,1),"id":"BtnTopP","x":0,"y":20,"w":"100%","margin":[5,0,0,0],"digit":2,"step":0.1,"h":20,"buttonSize":20,
										/*#{1H04SGD1Q8Codes*/
										OnChange(){
											self.syncConfig(true,this);
										}
										/*}#1H04SGD1Q8Codes*/
									}
								],
							},
							{
								"hash":"1H04SJBC40",
								"type":"hud","id":"BoxFqcP","position":"relative","x":0,"y":0,"w":"100%","h":50,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
								children:[
									{
										"hash":"1H04SJBC42",
										"type":"text","x":0,"y":0,"w":"100%","h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor.fontBody,"text":(($ln==="CN")?("频率惩罚(Frequency penalty):"):("Frequency penalty:")),
										"fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,
									},
									{
										"hash":"1H04SJBC50",
										"type":"text","id":"TxtFqcP","x":0,"y":0,"w":"100%","h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor.fontBody,
										"text":"0","fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignH":2,"alignV":1,
									},
									{
										"hash":"1H04SJBC55",
										"type":BoxRange(0,0,1),"id":"BtnFqcP","x":0,"y":20,"w":"100%","margin":[5,0,0,0],"digit":2,"step":0.1,"h":20,"buttonSize":20,
										/*#{1H04SJBC55Codes*/
										OnChange(){
											self.syncConfig(true,this);
										}
										/*}#1H04SJBC55Codes*/
									}
								],
							},
							{
								"hash":"1H04SOV4T0",
								"type":"hud","id":"BoxPrcP","position":"relative","x":0,"y":0,"w":"100%","h":50,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
								children:[
									{
										"hash":"1H04SOV4U0",
										"type":"text","x":0,"y":0,"w":"100%","h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor.fontBody,"text":(($ln==="CN")?("重复惩罚(Presence penalty):"):("Presence penalty:")),
										"fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,
									},
									{
										"hash":"1H04SOV4U5",
										"type":"text","id":"TxtPrcP","x":0,"y":0,"w":"100%","h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor.fontBody,
										"text":"0","fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignH":2,"alignV":1,
									},
									{
										"hash":"1H04SOV4V0",
										"type":BoxRange(0,0,1),"id":"BtnPrcP","x":0,"y":20,"w":"100%","margin":[5,0,0,0],"digit":2,"step":0.1,"h":20,"buttonSize":20,
										/*#{1H04SOV4V0Codes*/
										OnChange(){
											self.syncConfig(true,this);
										}
										/*}#1H04SOV4V0Codes*/
									}
								],
							},
							{
								"hash":"1H0MO4EQU0",
								"type":"box","position":"relative","x":20,"y":0,"w":">calc(100% - 40px)","h":1,"margin":[10,0,10,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
								"background":cfgColor["lineBodySub"],
							},
							{
								"hash":"1H11F89F60",
								"type":"box","id":"BoxChatName","position":"relative","x":0,"y":0,"w":"100%","h":"","margin":[0,0,10,0],"minW":"","minH":"","maxW":"","maxH":"",
								"styleClass":"","background":[255,255,255,1],"border":1,"borderColor":cfgColor.lineBodyLit,"corner":5,"contentLayout":"flex-y",
								children:[
									{
										"hash":"1H11F89F70",
										"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":16,"margin":[5,0,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
										children:[
											{
												"hash":"1H11F89F72",
												"type":"text","x":5,"y":0,"w":"","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor.fontBodySub,"text":(($ln==="CN")?("实验名称:"):("Playground name:")),
												"fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
											}
										],
									},
									{
										"hash":"1H11F89F87",
										"type":"memo","id":"EdChatName","position":"relative","x":0,"y":0,"w":"100%","h":"","cursor":"text","margin":[3,0,0,0],"minW":"","minH":20,"maxW":"",
										"maxH":"","styleClass":"","color":[0,0,0],"background":[255,255,255,0],"fontSize":txtSize.smallMid,"outline":0,"borderColor":[0,0,0,1],"flex":true,
										"OnInput":function(){
											/*#{1H11F89F813FunctionBody*/
											self.aboutChangeDoc(this);
											chatDoc.name=this.text;
											self.docChanged(this);
											/*}#1H11F89F813FunctionBody*/
										},
									}
								],
							},
							{
								"hash":"1H11F9JHF0",
								"type":"box","id":"BoxChatName","position":"relative","x":0,"y":0,"w":"100%","h":"","margin":[0,0,10,0],"minW":"","minH":"","maxW":"","maxH":"",
								"styleClass":"","background":[255,255,255,1],"border":1,"borderColor":cfgColor.lineBodyLit,"corner":5,"contentLayout":"flex-y",
								children:[
									{
										"hash":"1H11F9JHG0",
										"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":16,"margin":[5,0,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
										children:[
											{
												"hash":"1H11F9JHG2",
												"type":"text","x":5,"y":0,"w":"","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor.fontBodySub,"text":(($ln==="CN")?("实验描述:"):("Description:")),
												"fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
											}
										],
									},
									{
										"hash":"1H11F9JHH0",
										"type":"memo","id":"EdChatInfo","position":"relative","x":0,"y":0,"w":"100%","h":"","cursor":"text","margin":[3,0,0,0],"minW":"","minH":80,"maxW":"",
										"maxH":"","styleClass":"","color":[0,0,0],"background":[255,255,255,0],"fontSize":txtSize.smallMid,"outline":0,"borderColor":[0,0,0,1],"flex":true,
										"OnInput":function(){
											/*#{1H11F9JHH6FunctionBody*/
											self.aboutChangeDoc(this);
											chatDoc.info=this.text;
											self.docChanged(this);
											/*}#1H11F9JHH6FunctionBody*/
										},
									}
								],
							},
							{
								"hash":"1H9N9QSP20",
								"type":"box","id":"BoxGreeting","position":"relative","x":0,"y":0,"w":"100%","h":"","margin":[0,0,10,0],"minW":"","minH":"","maxW":"","maxH":"",
								"styleClass":"","background":[255,255,255,1],"border":1,"borderColor":cfgColor.lineBodyLit,"corner":5,"contentLayout":"flex-y",
								children:[
									{
										"hash":"1H9N9QSP30",
										"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":16,"margin":[5,0,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
										children:[
											{
												"hash":"1H9N9QSP32",
												"type":"text","x":5,"y":0,"w":"","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor.fontBodySub,"text":(($ln==="CN")?("聊天问候语:"):("Chat greetings:")),
												"fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
											}
										],
									},
									{
										"hash":"1H9N9QSP40",
										"type":"memo","id":"EdGreeting","position":"relative","x":0,"y":0,"w":"100%","h":"","cursor":"text","margin":[3,0,0,0],"minW":"","minH":50,"maxW":"",
										"maxH":"","styleClass":"","color":[0,0,0],"background":[255,255,255,0],"fontSize":txtSize.smallMid,"outline":0,"borderColor":[0,0,0,1],"flex":true,
										"OnInput":function(){
											/*#{1H9N9QSP410FunctionBody*/
											self.aboutChangeDoc(this);
											chatDoc.greeting=this.text;
											self.docChanged(this);
											/*}#1H9N9QSP410FunctionBody*/
										},
									}
								],
							},
							{
								"hash":"1H16HHN8C0",
								"type":"box","position":"relative","x":20,"y":0,"w":">calc(100% - 40px)","h":1,"margin":[0,0,5,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
								"background":cfgColor["lineBodySub"],
							},
							{
								"hash":"1H16J4N780",
								"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":24,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
								children:[
									{
										"hash":"1H16J5ABC0",
										"type":"hud","id":"HudCurrency","position":"relative","x":2,"y":0,"w":"100%","h":24,"padding":[0,0,0,0],"minW":"","minH":"","maxW":"","maxH":"",
										"styleClass":"","contentLayout":"flex-x","subAlign":1,
										children:[
											{
												"hash":"1H16J5ABC2",
												"type":"box","position":"relative","x":0,"y":"50%","w":20,"h":20,"anchorY":1,"display":$P(()=>(state.userTokens>=0),state),"minW":"","minH":"",
												"maxW":"","maxH":"","styleClass":"","background":cfgColor.fontBody,"maskImage":appCfg.sharedAssets+"/token.svg",
											},
											{
												"hash":"1H16J5ABD0",
												"type":"text","id":"TxtTokens","position":"relative","x":0,"y":0,"w":"","h":"100%","display":$P(()=>(state.userTokens>=0),state),"minW":"",
												"minH":"","maxW":"","maxH":"","styleClass":"","color":[0,0,0],"text":$P(()=>(state.userTokens>=0?state.userTokens:"- - -"),state),"fontSize":txtSize.mid,
												"fontWeight":"bold","fontStyle":"normal","textDecoration":"","alignV":1,
											},
											{
												"hash":"1H16J5ABD5",
												"type":"box","position":"relative","x":0,"y":"50%","w":20,"h":20,"anchorY":1,"display":$P(()=>(state.userTokens>=0),state),"margin":[0,0,0,10],
												"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.fontBody,"maskImage":appCfg.sharedAssets+"/gas.svg",
											},
											{
												"hash":"1H16J5ABE0",
												"type":"text","id":"TxtGas","position":"relative","x":0,"y":0,"w":"","h":"100%","display":$P(()=>(state.userTokens>=0),state),"minW":"","minH":"",
												"maxW":"","maxH":"","styleClass":"","color":[0,0,0],"text":$P(()=>(state.userGas>=0?state.userGas:"- - -"),state),"fontSize":txtSize.mid,"fontWeight":"bold",
												"fontStyle":"normal","textDecoration":"","alignV":1,
											},
											{
												"hash":"1H16J5ABF3",
												"type":"text","position":"relative","x":0,"y":0,"w":"","h":"100%","display":$P(()=>(state.userTokens>=0?false:true),state),"minW":"","minH":"",
												"maxW":"","maxH":"","styleClass":"","color":cfgColor.fontBodySub,"text":(($ln==="CN")?("请登录Tab-OS"):("Please login Tab-OS")),"fontSize":txtSize.smallMid,
												"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,
											}
										],
									},
									{
										"hash":"1H16J7MSR0",
										"type":"text","x":0,"y":1,"w":"100%","h":"100%","display":0,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor.fontBodySub,
										"text":"Checking account...","fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignH":1,"alignV":1,
									}
								],
							},
							{
								"hash":"1H1917UFF0",
								"type":BtnText("",120,24,(($ln==="CN")?("测试聊天"):("Test Chat")),false,""),"position":"relative","x":"50%","y":0,"anchorX":1,"margin":[5,0,0,0],
								"corner":3,
								"OnClick":function(event){
									/*#{1H191AE770FunctionBody*/
									self.testChat();
									/*}#1H191AE770FunctionBody*/
								},
							}
						],
					}
				],
			},
			{
				"hash":"1H04QKV440",
				"type":"hud","id":"HudChatFrame","x":$P(()=>(260),state),"y":0,"w":$P(()=>(`FW-260`),state),"h":"100%","autoLayout":true,"padding":[0,0,0,10],"minW":"",
				"minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
				children:[
					{
						"hash":"1H04T7CG70",
						"type":"hud","id":"HudChats","position":"relative","x":0,"y":0,"w":"100%","h":100,"overflow":"hidden scroll","padding":[10,0,0,0],"minW":"","minH":"",
						"maxW":"","maxH":"","styleClass":"","flex":true,"contentLayout":"flex-y",
						children:[
							{
								"hash":"1H0MMDTKF0",
								"type":"box","id":"BoxSysMsg","position":"relative","x":0,"y":0,"w":">calc(100% - 10px)","h":"","margin":[0,0,10,0],"minW":"","minH":"","maxW":"",
								"maxH":"","styleClass":"","background":[255,255,255,1],"border":1,"borderColor":cfgColor.lineBodyLit,"corner":5,"contentLayout":"flex-y",
								children:[
									{
										"hash":"1H0PAE2690",
										"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":16,"margin":[5,0,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
										children:[
											{
												"hash":"1H0PAF0L80",
												"type":"text","x":5,"y":0,"w":100,"h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor.fontBodySub,"text":(($ln==="CN")?("系统设定消息"):("SYSTEM Message:")),
												"fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
											},
											{
												"hash":"1H0PAIFP80",
												"type":"text","id":"TxtSysTokens","x":5,"y":0,"w":">calc(100% - 10px)","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor.fontBodyLit,
												"text":"Tokens: - - -","fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignH":2,
											}
										],
									},
									{
										"hash":"1H0MMDTKG5",
										"type":"memo","id":"EdSysMsg","position":"relative","x":0,"y":0,"w":"100%","h":"","cursor":"text","minW":"","minH":50,"maxW":"","maxH":"","styleClass":"",
										"text":"You are a smart AI assistant.","color":[0,0,0],"background":[255,255,255,0],"fontSize":txtSize.smallMid,"outline":0,"borderColor":[0,0,0,1],
										"flex":true,
										"OnInput":function(){
											/*#{1H0MMDTKG9FunctionBody*/
											self.aboutChangeDoc(this);
											chatDoc.sysMsg=this.text;
											self.docChanged(this);
											/*}#1H0MMDTKG9FunctionBody*/
										},
									}
								],
							},
							{
								"hash":"1H11ECO5T0",
								"type":"box","id":"BoxPrefix","position":"relative","x":0,"y":0,"w":">calc(100% - 10px)","h":"","margin":[0,0,10,0],"minW":"","minH":"","maxW":"",
								"maxH":"","styleClass":"","background":[255,255,255,1],"border":1,"borderColor":cfgColor.lineBodyLit,"corner":5,"contentLayout":"flex-y",
								children:[
									{
										"hash":"1H11ECO5T2",
										"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":16,"margin":[5,0,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
										children:[
											{
												"hash":"1H11ECO5U0",
												"type":"text","x":5,"y":0,"w":"","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor.fontBodySub,"text":(($ln==="CN")?("用户消息前置修饰"):("User Message Prefix:")),
												"fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
											}
										],
									},
									{
										"hash":"1H11ECO5V7",
										"type":"memo","id":"EdPrefix","position":"relative","x":0,"y":0,"w":"100%","h":"","cursor":"text","margin":[3,0,0,0],"minW":"","minH":20,"maxW":"",
										"maxH":"","styleClass":"","color":[0,0,0],"background":[255,255,255,0],"fontSize":txtSize.smallMid,"outline":0,"borderColor":[0,0,0,1],"flex":true,
										"OnInput":function(){
											/*#{1H11ECO5V13FunctionBody*/
											self.aboutChangeDoc(this);
											chatDoc.userMsgPrefix=this.text;
											self.docChanged(this);
											/*}#1H11ECO5V13FunctionBody*/
										},
									}
								],
							},
							{
								"hash":"1H11ELLUF0",
								"type":"box","id":"BoxPostfix","position":"relative","x":0,"y":0,"w":">calc(100% - 10px)","h":"","margin":[0,0,10,0],"minW":"","minH":"","maxW":"",
								"maxH":"","styleClass":"","background":[255,255,255,1],"border":1,"borderColor":cfgColor.lineBodyLit,"corner":5,"contentLayout":"flex-y",
								children:[
									{
										"hash":"1H11ELLUG0",
										"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":16,"margin":[5,0,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
										children:[
											{
												"hash":"1H11ELLUG2",
												"type":"text","x":5,"y":0,"w":"","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor.fontBodySub,"text":(($ln==="CN")?("用户消息后置修饰"):("User Message Postfix:")),
												"fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
											}
										],
									},
									{
										"hash":"1H11ELLUH8",
										"type":"memo","id":"EdPostfix","position":"relative","x":0,"y":0,"w":"100%","h":"","cursor":"text","margin":[3,0,0,0],"minW":"","minH":20,"maxW":"",
										"maxH":"","styleClass":"","color":[0,0,0],"background":[255,255,255,0],"fontSize":txtSize.smallMid,"outline":0,"borderColor":[0,0,0,1],"flex":true,
										"OnInput":function(){
											/*#{1H11ELLUI4FunctionBody*/
											self.aboutChangeDoc(this);
											chatDoc.userMsgPostfix=this.text;
											self.docChanged(this);
											/*}#1H11ELLUI4FunctionBody*/
										},
									}
								],
							},
							{
								"hash":"1H05RG23B0",
								"type":"hud","id":"HudMsgList","position":"relative","x":0,"y":0,"w":"100%","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
							},
							{
								"hash":"1H05RHVTF0",
								"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":30,"margin":[5,0,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
								children:[
									{
										"hash":"1H0PEN8IJ0",
										"type":"text","id":"TxtAllTokens","x":5,"y":0,"w":">calc(100% - 20px)","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor.fontBodyLit,
										"text":"- - -","fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignH":2,
									},
									{
										"hash":"1H05RIBSV0",
										"type":BtnIcon("front",30,0,appCfg.sharedAssets+"/additem.svg",null),"x":5,"y":0,"padding":1,
										"tip":(($ln==="CN")?("添加消息"):("Add message")),
										"OnClick":function(event){
											/*#{1H07BJ9M80FunctionBody*/
											self.doAddMsg(null,this);
											/*}#1H07BJ9M80FunctionBody*/
										},
									},
									{
										"hash":"1H0MO0P380",
										"type":BtnIcon("front",30,0,appCfg.sharedAssets+"/gas.svg",null),"id":"BtnCalTokens","x":35,"y":0,"display":0,"padding":2,
										"tip":"Calculate tokens",
										"OnClick":function(event){
											/*#{1H0MO0P385FunctionBody*/
											self.doCalTokens();
											/*}#1H0MO0P385FunctionBody*/
										},
									},
									{
										"hash":"1H0NSB8DU0",
										"type":BtnIcon("front",30,0,appCfg.sharedAssets+"/run.svg",null),"x":35,"y":0,"padding":2,
										"tip":(($ln==="CN")?("提交并生成"):("Submit and Generate")),
										"OnClick":function(event){
											/*#{1H0NSB8DV6FunctionBody*/
											self.executeChat();
											/*}#1H0NSB8DV6FunctionBody*/
										},
									},
									{
										"hash":"1HA7V8KVP0",
										"type":BtnIcon("front",30,0,appCfg.sharedAssets+"/appdata.svg",null),"id":"BtnShowAdv","x":65,"y":0,"padding":1,
										"tip":(($ln==="CN")?("高级设置"):("Advanced")),
										"OnClick":function(event){
											/*#{1HA7V8KVP11FunctionBody*/
											btnShowAdv.display=0;
											boxAdvanced.display=1;
											VFACT.scrollToShow(boxAdvanced);
											/*}#1HA7V8KVP11FunctionBody*/
										},
									}
								],
							},
							{
								"hash":"1HA7UKAVE0",
								"type":"hud","id":"BoxAdvanced","position":"relative","x":0,"y":0,"w":"100%","h":"","display":0,"padding":[5,0,5,0],"minW":"","minH":"","maxW":"",
								"maxH":"","styleClass":"","contentLayout":"flex-y",
								children:[
									{
										"hash":"1HA92CPTP0",
										"type":"box","position":"relative","x":10,"y":0,"w":">calc(100% - 20px)","h":1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["fontBodySub"],
									},
									{
										"hash":"1HA92F37T0",
										"type":"text","position":"relative","x":0,"y":0,"w":"100%","h":"","margin":[6,0,5,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
										"color":cfgColor["fontBodySub"],"text":(($ln==="CN")?("高级设定"):("Advanced")),"fontSize":txtSize.smallMid,"fontWeight":"bold","fontStyle":"normal",
										"textDecoration":"","alignH":1,
									},
									{
										"hash":"1HA81MKQ50",
										"type":"hud","id":"BoxMem","position":"relative","x":0,"y":0,"w":300,"h":50,"minW":"","minH":"","maxW":300,"maxH":"","styleClass":"",
										children:[
											{
												"hash":"1HA81MKQ52",
												"type":"text","x":0,"y":0,"w":"100%","h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor.fontBody,"text":(($ln==="CN")?("记忆的对话条数"):("Memory messages capability:")),
												"fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,
											},
											{
												"hash":"1HA81MKQ60",
												"type":"text","id":"TxtMem","x":0,"y":0,"w":"100%","h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor.fontBody,
												"text":"0","fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignH":2,"alignV":1,
											},
											{
												"hash":"1HA81MKQ611",
												"type":BoxRange(0,0,200),"id":"BtnMem","x":0,"y":20,"w":300,"margin":[5,0,0,0],"digit":0,"step":2,"h":20,"buttonSize":20,
												/*#{1HA81MKQ611Codes*/
												OnChange(){
													self.syncConfig(true,this);
												}
												/*}#1HA81MKQ611Codes*/
											}
										],
									},
									{
										"hash":"1HAJFHGFL0",
										"type":"hud","id":"BoxMem","position":"relative","x":0,"y":0,"w":300,"h":50,"minW":"","minH":"","maxW":300,"maxH":"","styleClass":"",
										children:[
											{
												"hash":"1HAJFHGFL2",
												"type":"text","x":0,"y":0,"w":"100%","h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor.fontBody,"text":(($ln==="CN")?("批量压缩消息数："):("Compress messages batch:")),
												"fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,
											},
											{
												"hash":"1HAJFHGFM9",
												"type":"text","id":"TxtCompress","x":0,"y":0,"w":"100%","h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor.fontBody,
												"text":"0","fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignH":2,"alignV":1,
											},
											{
												"hash":"1HAJFHGFN0",
												"type":BoxRange(6,2,20),"id":"BtnCompress","x":0,"y":20,"w":300,"margin":[5,0,0,0],"digit":0,"step":2,"h":20,"buttonSize":20,
												/*#{1HAJFHGFN0Codes*/
												OnChange(){
													self.syncConfig(true,this);
												}
												/*}#1HAJFHGFN0Codes*/
											}
										],
									},
									{
										"hash":"1HAFB0C6U0",
										"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":30,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
										"itemsAlign":1,
										children:[
											{
												"hash":"1HAFBD38M0",
												"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","margin":[0,2,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":[0,0,0],
												"text":(($ln==="CN")?("保密过程:"):("Secret process:")),"fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
											},
											{
												"hash":"1HAFBK4V90",
												"type":BtnSwitch(16,false),"id":"BtnSecretInternal","position":"relative","x":0,"y":0,"margin":[0,10,0,0],
												/*#{1HAFBK4V90Codes*/
												OnCheck(checked){
													self.syncConfig(true,this);
												}
												/*}#1HAFBK4V90Codes*/
											},
											{
												"hash":"1HBHNS1VC0",
												"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","margin":[0,2,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":[0,0,0],
												"text":(($ln==="CN")?("接受文件:"):("Accept file:")),"fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
											},
											{
												"hash":"1HBHNS5A60",
												"type":BtnSwitch(16,false),"id":"BtnAllowFile","position":"relative","x":0,"y":0,"margin":[0,10,0,0],
												/*#{1HBHNS5A60Codes*/
												OnCheck(checked){
													self.syncConfig(true,this);
												}
												/*}#1HBHNS5A60Codes*/
											},
											{
												"hash":"1HBHO1OD70",
												"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","margin":[0,2,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":[0,0,0],
												"text":(($ln==="CN")?("启动时执行AI:"):("Run AI on startup:")),"fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
											},
											{
												"hash":"1HBHO1R880",
												"type":BtnSwitch(16,false),"id":"BtnInitExec","position":"relative","x":0,"y":0,"margin":[0,10,0,0],
												/*#{1HBHO1R880Codes*/
												OnCheck(checked){
													self.syncConfig(true,this);
												}
												/*}#1HBHO1R880Codes*/
											}
										],
									},
									{
										"hash":"1HA7VC0T50",
										"type":"text","position":"relative","x":0,"y":0,"w":"100%","h":"","margin":[5,0,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
										"color":cfgColor["fontBody"],"text":(($ln==="CN")?("修饰函数（格式：函数名@JS代码路径，或aichat文件路径）"):("Filter functions (format: function-name@file-path, or .aichat file path)")),
										"fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
									},
									{
										"hash":"1HA81C3NH0",
										"type":"box","id":"BoxFilterInit","position":"relative","x":0,"y":0,"w":">calc(100% - 10px)","h":"","margin":[0,0,10,0],"minW":"","minH":"",
										"maxW":"","maxH":"","styleClass":"","background":[255,255,255,1],"border":1,"borderColor":cfgColor.lineBodyLit,"corner":5,"contentLayout":"flex-y",
										children:[
											{
												"hash":"1HA81C3NH2",
												"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":16,"margin":[5,0,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
												children:[
													{
														"hash":"1HA81C3NH4",
														"type":"text","x":5,"y":0,"w":"","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor.fontBodySub,"text":(($ln==="CN")?("初始化修饰函数（例如：init@./filters.js or ./init.aichat）"):("Init filter function (e.g. init@./filters.js or ./init.aichat)")),
														"fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
													}
												],
											},
											{
												"hash":"1HAG5633H0",
												"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":30,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
												children:[
													{
														"hash":"1HAG56F2E0",
														"type":"edit","id":"EdFilterInit","position":"relative","x":35,"y":0,"w":">calc(100% - 50px)","h":20,"margin":[5,0,5,0],"minW":"","minH":"",
														"maxW":"","maxH":"","styleClass":"","placeHolder":"function-name@path-to-file","color":[0,0,0],"fontSize":txtSize.smallMid,"outline":0,"border":[0,0,1,0],
														"borderColor":cfgColor["fontBodySub"],
														"OnChange":function(){
															/*#{1HAG56F2E4FunctionBody*/
															self.syncConfig(true,this);
															/*}#1HAG56F2E4FunctionBody*/
														},
													},
													{
														"hash":"1HAG57UOB0",
														"type":BtnIcon("front",26,0,"/~/-tabos/shared/assets/folder.svg",null),"x":5,"y":"50%","anchorY":1,"padding":2,
														"tgt":"EdFilterInit",
														"OnClick":function(event){
															/*#{1HBGBQOBC0FunctionBody*/
															self.setFilterFile(this);
															/*}#1HBGBQOBC0FunctionBody*/
														},
													}
												],
											}
										],
									},
									{
										"hash":"1HA81E0450",
										"type":"box","id":"BoxFilterReset","position":"relative","x":0,"y":0,"w":">calc(100% - 10px)","h":"","margin":[0,0,10,0],"minW":"","minH":"",
										"maxW":"","maxH":"","styleClass":"","background":[255,255,255,1],"border":1,"borderColor":cfgColor.lineBodyLit,"corner":5,"contentLayout":"flex-y",
										children:[
											{
												"hash":"1HA81E0452",
												"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":16,"margin":[5,0,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
												children:[
													{
														"hash":"1HA81E0454",
														"type":"text","x":5,"y":0,"w":"","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor.fontBodySub,"text":(($ln==="CN")?("重置修饰函数（例如：reset@./filters.js）"):("reset filter function (e.g. reset@./filters.js)")),
														"fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
													}
												],
											},
											{
												"hash":"1HAG5M3G70",
												"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":30,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
												children:[
													{
														"hash":"1HAG5M3G87",
														"type":BtnIcon("front",26,0,"/~/-tabos/shared/assets/folder.svg",null),"x":5,"y":"50%","anchorY":1,"padding":2,
														"OnClick":function(event){
															/*#{1HBGDICS80FunctionBody*/
															self.setFilterFile(this);
															/*}#1HBGDICS80FunctionBody*/
														},
													},
													{
														"hash":"1HAG5MA0P0",
														"type":"edit","id":"EdFilterReset","position":"relative","x":35,"y":0,"w":">calc(100% - 50px)","h":20,"margin":[5,0,5,0],"minW":"","minH":"",
														"maxW":"","maxH":"","styleClass":"","placeHolder":"function-name@path-to-file","color":[0,0,0],"fontSize":txtSize.smallMid,"outline":0,"border":[0,0,1,0],
														"borderColor":cfgColor["fontBodySub"],
														"OnChange":function(){
															/*#{1HAG5MA0P4FunctionBody*/
															self.syncConfig(true,this);
															/*}#1HAG5MA0P4FunctionBody*/
														},
													}
												],
											}
										],
									},
									{
										"hash":"1HA7UL0PQ0",
										"type":"box","id":"BoxFilterInput","position":"relative","x":0,"y":0,"w":">calc(100% - 10px)","h":"","margin":[0,0,10,0],"minW":"","minH":"",
										"maxW":"","maxH":"","styleClass":"","background":[255,255,255,1],"border":1,"borderColor":cfgColor.lineBodyLit,"corner":5,"contentLayout":"flex-y",
										children:[
											{
												"hash":"1HA7UL0PQ2",
												"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":16,"margin":[5,0,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
												children:[
													{
														"hash":"1HA7UL0PQ4",
														"type":"text","x":5,"y":0,"w":"","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor.fontBodySub,"text":(($ln==="CN")?("用户输入修饰函数 （例如: input@./filters.js）"):("Prompt filter (e.g. input@./filters.js)")),
														"fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
													}
												],
											},
											{
												"hash":"1HAG5NGCR0",
												"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":30,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
												children:[
													{
														"hash":"1HAG5NGCS0",
														"type":BtnIcon("front",26,0,"/~/-tabos/shared/assets/folder.svg",null),"x":5,"y":"50%","anchorY":1,"padding":2,
														"OnClick":function(event){
															/*#{1HBGDJ6PK0FunctionBody*/
															self.setFilterFile(this);
															/*}#1HBGDJ6PK0FunctionBody*/
														},
													},
													{
														"hash":"1HAG5NORI0",
														"type":"edit","id":"EdFilterInput","position":"relative","x":35,"y":0,"w":">calc(100% - 50px)","h":20,"margin":[5,0,5,0],"minW":"","minH":"",
														"maxW":"","maxH":"","styleClass":"","placeHolder":"function-name@path-to-file","color":[0,0,0],"fontSize":txtSize.smallMid,"outline":0,"border":[0,0,1,0],
														"borderColor":cfgColor["fontBodySub"],
														"OnChange":function(){
															/*#{1HAG5NORJ0FunctionBody*/
															self.syncConfig(true,this);
															/*}#1HAG5NORJ0FunctionBody*/
														},
													}
												],
											}
										],
									},
									{
										"hash":"1HA7UN27D0",
										"type":"box","id":"BoxFilterOutput","position":"relative","x":0,"y":0,"w":">calc(100% - 10px)","h":"","margin":[0,0,10,0],"minW":"","minH":"",
										"maxW":"","maxH":"","styleClass":"","background":[255,255,255,1],"border":1,"borderColor":cfgColor.lineBodyLit,"corner":5,"contentLayout":"flex-y",
										children:[
											{
												"hash":"1HA7UN27E0",
												"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":16,"margin":[5,0,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
												children:[
													{
														"hash":"1HA7UN27E2",
														"type":"text","x":5,"y":0,"w":"","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor.fontBodySub,"text":(($ln==="CN")?("AI输出修饰函数（例如：output@./filters.js）"):("Output filter function (e.g. output@./filters.js)")),
														"fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
													}
												],
											},
											{
												"hash":"1HAG5OOQ50",
												"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":30,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
												children:[
													{
														"hash":"1HAG5OOQ60",
														"type":BtnIcon("front",26,0,"/~/-tabos/shared/assets/folder.svg",null),"x":5,"y":"50%","anchorY":1,"padding":2,
														"OnClick":function(event){
															/*#{1HBGDJJQD0FunctionBody*/
															self.setFilterFile(this);
															/*}#1HBGDJJQD0FunctionBody*/
														},
													},
													{
														"hash":"1HAG5P0R00",
														"type":"edit","id":"EdFilterOutput","position":"relative","x":35,"y":0,"w":">calc(100% - 50px)","h":20,"margin":[5,0,5,0],"minW":"","minH":"",
														"maxW":"","maxH":"","styleClass":"","placeHolder":"function-name@path-to-file","color":[0,0,0],"fontSize":txtSize.smallMid,"outline":0,"border":[0,0,1,0],
														"borderColor":cfgColor["fontBodySub"],
														"OnChange":function(){
															/*#{1HAG5P0R04FunctionBody*/
															self.syncConfig(true,this);
															/*}#1HAG5P0R04FunctionBody*/
														},
													}
												],
											}
										],
									},
									{
										"hash":"1HBGBCGQF0",
										"type":"box","id":"BoxFilterRound","position":"relative","x":0,"y":0,"w":">calc(100% - 10px)","h":"","margin":[0,0,10,0],"minW":"","minH":"",
										"maxW":"","maxH":"","styleClass":"","background":[255,255,255,1],"border":1,"borderColor":cfgColor.lineBodyLit,"corner":5,"contentLayout":"flex-y",
										children:[
											{
												"hash":"1HBGBCGQF2",
												"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":16,"margin":[5,0,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
												children:[
													{
														"hash":"1HBGBCGQG0",
														"type":"text","x":5,"y":0,"w":"","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor.fontBodySub,"text":(($ln==="CN")?("对话回合修饰函数（例如：round@./filters.js）"):("End round filter function (e.g. round@./filters.js)")),
														"fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
													}
												],
											},
											{
												"hash":"1HBGBCGQG20",
												"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":30,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
												children:[
													{
														"hash":"1HBGBCGQH7",
														"type":"edit","id":"EdFilterRound","position":"relative","x":35,"y":0,"w":">calc(100% - 50px)","h":20,"margin":[5,0,5,0],"minW":"","minH":"",
														"maxW":"","maxH":"","styleClass":"","placeHolder":"function-name@path-to-file","color":[0,0,0],"fontSize":txtSize.smallMid,"outline":0,"border":[0,0,1,0],
														"borderColor":cfgColor["fontBodySub"],
														"OnChange":function(){
															/*#{1HBGBCGQH11FunctionBody*/
															self.syncConfig(true,this);
															/*}#1HBGBCGQH11FunctionBody*/
														},
													},
													{
														"hash":"1HBGBCGQH0",
														"type":BtnIcon("front",26,0,"/~/-tabos/shared/assets/folder.svg",null),"x":5,"y":"50%","anchorY":1,"padding":2,
														"OnClick":function(event){
															/*#{1HBGDJT5G0FunctionBody*/
															self.setFilterFile(this);
															/*}#1HBGDJT5G0FunctionBody*/
														},
													}
												],
											}
										],
									},
									{
										"hash":"1HAFCFAV10",
										"type":"box","id":"BoxFilterCompress","position":"relative","x":0,"y":0,"w":">calc(100% - 10px)","h":"","margin":[0,0,10,0],"minW":"","minH":"",
										"maxW":"","maxH":"","styleClass":"","background":[255,255,255,1],"border":1,"borderColor":cfgColor.lineBodyLit,"corner":5,"contentLayout":"flex-y",
										children:[
											{
												"hash":"1HAFCFAV12",
												"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":16,"margin":[5,0,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
												children:[
													{
														"hash":"1HAFCFAV14",
														"type":"text","x":5,"y":0,"w":"","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor.fontBodySub,"text":(($ln==="CN")?("压缩对话函数（例如：output@./filters.js）"):("Compress messages function (e.g. output@./filters.js)")),
														"fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
													}
												],
											},
											{
												"hash":"1HAG5RRCB0",
												"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":30,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
												children:[
													{
														"hash":"1HAG5RVUT0",
														"type":"edit","id":"EdFilterCompress","position":"relative","x":35,"y":0,"w":">calc(100% - 50px)","h":20,"margin":[5,0,5,0],"minW":"","minH":"",
														"maxW":"","maxH":"","styleClass":"","placeHolder":"function-name@path-to-file","color":[0,0,0],"fontSize":txtSize.smallMid,"outline":0,"border":[0,0,1,0],
														"borderColor":cfgColor["fontBodySub"],
														"OnChange":function(){
															/*#{1HAG5RVUT4FunctionBody*/
															self.syncConfig(true,this);
															/*}#1HAG5RVUT4FunctionBody*/
														},
													},
													{
														"hash":"1HAG5RRCB2",
														"type":BtnIcon("front",26,0,"/~/-tabos/shared/assets/folder.svg",null),"x":5,"y":"50%","anchorY":1,"padding":2,
														"OnClick":function(event){
															/*#{1HBGDK8DM0FunctionBody*/
															self.setFilterFile(this);
															/*}#1HBGDK8DM0FunctionBody*/
														},
													}
												],
											}
										],
									},
									{
										"hash":"1HAG5CML10",
										"type":"box","id":"BoxBotAPIFile","position":"relative","x":0,"y":0,"w":">calc(100% - 10px)","h":"","margin":[0,0,10,0],"minW":"","minH":"",
										"maxW":"","maxH":"","styleClass":"","background":[255,255,255,1],"border":1,"borderColor":cfgColor.lineBodyLit,"corner":5,"contentLayout":"flex-y",
										children:[
											{
												"hash":"1HAG5CML20",
												"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":16,"margin":[5,0,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
												children:[
													{
														"hash":"1HAG5CML22",
														"type":"text","x":5,"y":0,"w":"","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor.fontBodySub,"text":(($ln==="CN")?("API 文件，如有多个文件，用分号隔开"):("API file, separate multiple files with semicolon")),
														"fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
													}
												],
											},
											{
												"hash":"1HAG63NJR0",
												"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":30,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
												children:[
													{
														"hash":"1HAG64K3H0",
														"type":"edit","id":"EdBotAPIFile","position":"relative","x":35,"y":0,"w":">calc(100% - 50px)","h":20,"margin":[5,0,5,0],"minW":"","minH":"",
														"maxW":"","maxH":"","styleClass":"","placeHolder":"path-to-file1;path-to-file2;...","color":[0,0,0],"fontSize":txtSize.smallMid,"outline":0,
														"border":[0,0,1,0],"borderColor":cfgColor["fontBodySub"],
														"OnChange":function(){
															/*#{1HAG64K3I2FunctionBody*/
															self.syncConfig(true,this);
															/*}#1HAG64K3I2FunctionBody*/
														},
													},
													{
														"hash":"1HAG63NJR2",
														"type":BtnIcon("front",26,0,"/~/-tabos/shared/assets/folder.svg",null),"x":5,"y":"50%","anchorY":1,"padding":2,
														"OnClick":function(event){
															/*#{1HBGDNPJJ0FunctionBody*/
															self.setAPIFile(this);
															/*}#1HBGDNPJJ0FunctionBody*/
														},
													}
												],
											}
										],
									},
									{
										"hash":"1HA809PPQ0",
										"type":BtnText("",100,20,(($ln==="CN")?("应用"):("Apply")),false,""),"position":"relative","x":0,"y":0,"corner":3,
										"OnClick":function(event){
											/*#{1HA80I71C0FunctionBody*/
											btnShowAdv.display=1;
											boxAdvanced.display=0;
											self.syncConfig(true,this);
											/*}#1HA80I71C0FunctionBody*/
										},
									}
								],
							}
						],
					},
					{
						"hash":"1H04VDHIR0",
						"type":"hud","id":"HudBtm","position":"relative","x":0,"y":0,"w":"100%","h":$P(()=>(state.hudBtmH),state),"minW":"","minH":"","maxW":"","maxH":"",
						"styleClass":"",
						children:[
							{
								"hash":"1H04VHO0Q0",
								"type":BtnText("success",100,24,(($ln==="CN")?("提交"):("Submit")),false,""),"id":"BtnExec","x":10,"y":10,"corner":3,
								"OnClick":function(event){
									/*#{1H0MPPA5E0FunctionBody*/
									self.executeChat();
									/*}#1H0MPPA5E0FunctionBody*/
								},
							},
							{
								"hash":"1H0MT30BJ0",
								"type":BtnText("warning",100,24,"Cancel",false,""),"id":"BtnCancel","x":10,"y":10,"display":0,"corner":3,
								"OnClick":function(event){
									/*#{1H0MT30BJ7FunctionBody*/
									self.cancelExec();
									/*}#1H0MT30BJ7FunctionBody*/
								},
							}
						],
					}
				],
			}
		],
		/*#{1H04Q8C9M1ExtraCSS*/
		/*}#1H04Q8C9M1ExtraCSS*/
		faces:{
			"lite":{
			},"full":{
			},"mobile":{
			},"execOn":{
				/*HudMsgList*/"#1H05RG23B0":{
					"uiEvent":-1
				},
				"#1H05RIBSV0":{
					"enable":false
				},
				/*BtnCalTokens*/"#1H0MO0P380":{
					"enable":false
				},
				"#1H0NSB8DU0":{
					"enable":false
				},
				/*BtnShowAdv*/"#1HA7V8KVP0":{
					"enable":false
				},
				/*BtnExec*/"#1H04VHO0Q0":{
					"display":0
				},
				/*BtnCancel*/"#1H0MT30BJ0":{
					"display":1
				}
			},"execOff":{
				/*HudMsgList*/"#1H05RG23B0":{
					"uiEvent":1
				},
				"#1H05RIBSV0":{
					"enable":true
				},
				/*BtnCalTokens*/"#1H0MO0P380":{
					"enable":true
				},
				"#1H0NSB8DU0":{
					"enable":true
				},
				/*BtnShowAdv*/"#1HA7V8KVP0":{
					"enable":true
				},
				/*BtnExec*/"#1H04VHO0Q0":{
					"display":1
				},
				/*BtnCancel*/"#1H0MT30BJ0":{
					"display":0
				}
			},"checkCy":{
				/*HudCurrency*/"#1H16J5ABC0":{
					"display":0
				},
				"#1H16J7MSR0":{
					"display":1
				}
			},"showCy":{
				/*HudCurrency*/"#1H16J5ABC0":{
					"display":1
				},
				"#1H16J7MSR0":{
					"display":0
				}
			}
		},
		OnCreate:function(){
			self=this;
			btnChatModel=self.BtnChatModel;txtTemperature=self.TxtTemperature;btnTemperature=self.BtnTemperature;txtMaxToken=self.TxtMaxToken;btnMaxToken=self.BtnMaxToken;txtTopP=self.TxtTopP;btnTopP=self.BtnTopP;txtFqcP=self.TxtFqcP;btnFqcP=self.BtnFqcP;txtPrcP=self.TxtPrcP;btnPrcP=self.BtnPrcP;edChatName=self.EdChatName;edChatInfo=self.EdChatInfo;edGreeting=self.EdGreeting;txtSysTokens=self.TxtSysTokens;edSysMsg=self.EdSysMsg;edPrefix=self.EdPrefix;edPostfix=self.EdPostfix;hudMsgList=self.HudMsgList;txtAllTokens=self.TxtAllTokens;btnCalTokens=self.BtnCalTokens;btnShowAdv=self.BtnShowAdv;boxAdvanced=self.BoxAdvanced;txtMem=self.TxtMem;btnMem=self.BtnMem;txtCompress=self.TxtCompress;btnCompress=self.BtnCompress;btnSecretInternal=self.BtnSecretInternal;btnAllowFile=self.BtnAllowFile;btnInitExec=self.BtnInitExec;edFilterInit=self.EdFilterInit;edFilterReset=self.EdFilterReset;edFilterInput=self.EdFilterInput;edFilterOutput=self.EdFilterOutput;edFilterRound=self.EdFilterRound;edFilterCompress=self.EdFilterCompress;edBotAPIFile=self.EdBotAPIFile;
			/*#{1H04Q8C9M1Create*/
			makeNotify(self);
			makeObjEventEmitter(self);
			self.showDoc();
			/*}#1H04Q8C9M1Create*/
		},
		/*#{1H04Q8C9M1EndCSS*/
		/*}#1H04Q8C9M1EndCSS*/
	};
	/*#{1H04Q8C9M1PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.showDoc=function(){
		let msgs,msg,def,model;
		//Model related:
		model=chatDoc.config.model;
		model=ChatModels[model]||ChatModels["GTP-3.5"];
		btnChatModel.text=model.text;
		btnMaxToken.max=model.maxToken;
		if(btnMaxToken.value>btnMaxToken.max){
			btnMaxToken.value=btnMaxToken.max;
		}
		
		txtTemperature.text=chatDoc.config.temperature;
		txtMaxToken.text=chatDoc.config.maxToken;
		txtTopP.text=chatDoc.config.topP;
		txtFqcP.text=chatDoc.config.fqcP;
		txtPrcP.text=chatDoc.config.prcP;
		btnTemperature.value=chatDoc.config.temperature;
		btnMaxToken.value=chatDoc.config.maxToken;
		btnTopP.value=chatDoc.config.topP;
		btnFqcP.value=chatDoc.config.fqcP;
		btnPrcP.value=chatDoc.config.prcP;
		edChatName.text=chatDoc.name;
		edChatInfo.text=chatDoc.info;
		edGreeting.text=chatDoc.greeting;
	
		btnMem.value=chatDoc.memoryChatNum;
		txtMem.text=(chatDoc.memoryChatNum>=200)?"All":chatDoc.memoryChatNum;
		btnCompress.value=chatDoc.compressChatNum;
		txtCompress.text=chatDoc.compressChatNum;
		
		
		btnSecretInternal.checked=!!chatDoc.secretInternal;
		btnAllowFile.checked=!!chatDoc.allowFileInput;
		btnInitExec.checked=!!chatDoc.execOnStart;
		
		edFilterInit.text=chatDoc.filterInit;
		edFilterReset.text=chatDoc.filterReset;
		edFilterInput.text=chatDoc.filterInput;
		edFilterOutput.text=chatDoc.filterOutput;
		edFilterRound.text=chatDoc.filterEndRound;
		edFilterCompress.text=chatDoc.filterCompress;
		edBotAPIFile.text=chatDoc.apiFiles;
		
		edSysMsg.text=chatDoc.sysMsg;
		edPrefix.text=chatDoc.userMsgPrefix;
		edPostfix.text=chatDoc.userMsgPostfix;
		//Show messages:
		hudMsgList.clearChildren();
		msgs=chatDoc.chatMsgs;
		for(msg of msgs){
			def={
				type:BtnAIChatMsg(app,msg,self),
				OnClick(){
					if(editingBlk){
						//TODO: Code this:
					}
					this.startEdit();
					editingBlk=this;
				}
			};
			hudMsgList.appendNewChild(def);
		}
		self.doCalTokens();
	};
	
	//------------------------------------------------------------------------
	cssVO.syncConfig=function(changeVersion=true,hud=null){
		let config;
		if(changeVersion){
			self.aboutChangeDoc(hud);
		}
		config=chatDoc.config;
		config.temperature=btnTemperature.value;
		config.maxToken=Math.floor(btnMaxToken.value);
		config.topP=btnTopP.value;
		config.fqcP=btnFqcP.value;
		config.prcP=btnPrcP.value;
		txtTemperature.text=config.temperature.toFixed(2);
		txtMaxToken.text=config.maxToken;
		txtTopP.text=config.topP.toFixed(2);
		txtFqcP.text=config.fqcP.toFixed(2);
		txtPrcP.text=config.prcP.toFixed(2);
	
		chatDoc.memoryChatNum=Math.floor(btnMem.value);
		txtMem.text=(chatDoc.memoryChatNum>=200)?"All":chatDoc.memoryChatNum;
		chatDoc.compressChatNum=Math.floor(btnCompress.value);
		txtCompress.text=chatDoc.compressChatNum;
	
		chatDoc.secretInternal=btnSecretInternal.checked;
		chatDoc.allowFileInput=btnAllowFile.checked;
		chatDoc.execOnStart=btnInitExec.checked;
		
		chatDoc.filterInit=edFilterInit.text.trim();
		chatDoc.filterReset=edFilterReset.text.trim();
		chatDoc.filterInput=edFilterInput.text.trim();
		chatDoc.filterOutput=edFilterOutput.text.trim();
		chatDoc.filterEndRound=edFilterRound.text.trim();
		chatDoc.filterCompress=edFilterCompress.text.trim();
		chatDoc.apiFiles=edBotAPIFile.text.trim();
		if(changeVersion){
			self.docChanged(hud||self);
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.checkCy=async function(){
		let res;
		if(!tabNT.checkLogin(false)){
			state.userTokens=-1;
			state.userGas=-1;
			self.showFace("showCy");
			return;
		}
		self.showFace("checkCy");
		try{
			res=await tabNT.makeCall("userCurrency",{});
			if(res.code===200){
				state.userTokens=res.coins||0;
				state.userGas=res.points||0;
			}else{
				state.userTokens=-1;
				state.userGas=-1;
			}
		}catch(err){
			state.userTokens=-1;
			state.userGas=-1;
		}
		self.showFace("showCy");
	};
	
	
	//************************************************************************
	//Edit messages:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		cssVO.doAddMsg=function(blk,hud){
			let msgs,msg,lastMsg,def,idx;
			self.aboutChangeDoc(hud);
			msgs=chatDoc.chatMsgs
			lastMsg=blk?blk.msg:msgs[msgs.length-1];
			msg=VFACT.flexState({role:lastMsg.role==="user"?"assistant":"user",contents:"",tokens:-1});
			def={
				type:BtnAIChatMsg(app,msg,self),
				OnClick(){
					this.startEdit();
					editingBlk=this;
				}
			};
			if(blk){
				idx=msgs.indexOf(lastMsg);
				if(idx>=0){
					msgs.splice(idx,0,msg);
					blk=hudMsgList.insertNewBefore(def,blk);
				}else{
					msgs.push(msg);
					blk=hudMsgList.appendNewChild(def);
				}
			}else{
				msgs.push(msg);
				blk=hudMsgList.appendNewChild(def);
			}
			VFACT.scrollToShow(blk);
			blk.startEdit();
			self.updateAllTokens();
			self.docChanged(hud);
		};
	
		//--------------------------------------------------------------------
		cssVO.doCloneMsg=function(blk,hud){
			let msgs,orgMsg,msg,def,idx;
			self.aboutChangeDoc(hud);
			orgMsg=blk.msg;
			msgs=chatDoc.chatMsgs;
			idx=msgs.indexOf(blk.msg);
			if(idx<0)
				return;
			msg=VFACT.flexState({role:orgMsg.role,contents:orgMsg.content,tokens:orgMsg.tokens});
			def={
				type:BtnAIChatMsg(app,msg,self),
				OnClick(){
					this.startEdit();
					editingBlk=this;
				}
			};
			msgs.splice(idx,0,msg);
			blk=hudMsgList.insertNewBefore(def,blk);
			VFACT.scrollToShow(blk);
			blk.startEdit();
			self.updateAllTokens();
			self.docChanged(hud);
		};
		
		//--------------------------------------------------------------------
		cssVO.doDelMsg=function(blk,hud){
			let msgs,msg,idx;
			self.aboutChangeDoc(hud);
			msgs=chatDoc.chatMsgs;
			msg=blk.msg;
			idx=msgs.indexOf(msg);
			if(idx<0 || msgs.length<=1){
				return;
			}
			msgs.splice(idx,1);
			hudMsgList.removeChild(blk);
			if(blk===editingBlk){
				editingBlk=null;
			}
			self.updateAllTokens();
			self.docChanged(hud);
		};
	
		//--------------------------------------------------------------------
		cssVO.moveMsgUp=function(blk,hud){
			let msgs,msg,idx,pre;
			self.aboutChangeDoc(hud);
			msgs=chatDoc.chatMsgs;
			msg=blk.msg;
			idx=msgs.indexOf(msg);
			if(idx<1){
				return;
			}
			msgs.splice(idx,1);
			msgs.splice(idx-1,0,msg);
			blk.hold();
			pre=blk.previousSibling;
			hudMsgList.removeChild(blk);
			hudMsgList.insertBefore(blk,pre);
			blk.release();
			if(blk===editingBlk){
				editingBlk=null;
			}
			self.docChanged(hud);
		};
		
		//--------------------------------------------------------------------
		cssVO.moveMsgDown=function(blk,hud){
			blk=blk.nextSibling;
			if(blk){
				self.moveMsgUp(blk,hud);
			}
		};
		
		//--------------------------------------------------------------------
		cssVO.msgChanged=function(msg,blk){
			self.docChanged(blk);
			msgVersion=editVersion;
		};
		
		//--------------------------------------------------------------------
		cssVO.aboutChangeDoc=function(hud){
			let hsVO;
			if(pendingHistory){
				if(pendingHistoryHud===hud){
					return;
				}
				hsVO=chatDoc.genSaveVO();
				history[historyIdx]=hsVO;
				historyIdx++;
				history.splice(historyIdx);
				pendingHistory=false;
				if(history.length>10){
					historyIdx=10;
					history.splice(0,history.length-10);
				}
			}else if(hud!==self){
				hsVO=chatDoc.genSaveVO();
				history[historyIdx]=hsVO;
				historyIdx++;
				history.splice(historyIdx);
			}
		};
		
		//--------------------------------------------------------------------
		cssVO.docChanged=function(hud){
			editVersion++;
			self.emit("Change");
			self.emitNotify("Change");
			pendingHistory=true;
			pendingHistoryHud=hud;
		};
		
		//--------------------------------------------------------------------
		cssVO.undo=function(){
			let hsVO;
			self.aboutChangeDoc(self);
			hsVO=history[historyIdx-2];
			if(hsVO){
				chatDoc.loadFmVO(hsVO);
				self.showDoc();
				historyIdx=historyIdx-1;
			}
		};
	
		//--------------------------------------------------------------------
		cssVO.redo=function(){
			let hsVO;
			self.aboutChangeDoc(self);
			hsVO=history[historyIdx];
			if(hsVO){
				historyIdx=historyIdx+1;
				chatDoc.loadFmVO(hsVO);
				self.showDoc();
			}
		};
	}
	
	//************************************************************************
	//Advanced:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		cssVO.setFilterFile=async function(btn){
			let path,mod,items,name,item;
			path=await app.modalDlg(DlgFile,{
				mode:"open",
				path:docPath,
				options:{
					preview:1,
					filter:"*.aichat;*.js"
				},
			});
			if(path){
				try{
					let cnt;
					if(path.endsWith(".js")){
						mod=await import("/~"+path);
						items=[];
						cnt=0;
						for(name in mod){
							items.push({text:name});
							cnt++;
						}
						if(cnt>0){
							item=await app.modalDlg(DlgMenu,{
								hud:btn,
								items:items
							});
							if(item){
								path=pathLib.relative(docPath,path);
								if(path[0]!=="/" && path[0]!=="."){
									path="./"+path;
								}
								btn.previousSibling.text=item.text+"@"+path;
								self.syncConfig(true,btn.previousSibling);
							}
						}else{
							window.alert(`File ${path} has no export functions!`);
						}
					}else{
						path=pathLib.relative(docPath,path);
						btn.previousSibling.text=path;
						self.syncConfig(true,btn.previousSibling);
					}
				}catch(err){
					console.error(err);
					window.alert("Can't import file, err: "+err);
				}
			}
		};
	
		//--------------------------------------------------------------------
		cssVO.setAPIFile=async function(btn){
			let path,mod,items,name,item;
			path=await app.modalDlg(DlgFile,{
				mode:"open",
				path:docPath,
				options:{
					preview:1,
					filter:"*.js"
				},
			});
			if(path){
				try{
					let text;
					mod=await import("/~"+path);
					path=pathLib.relative(docPath,path);
					if(path[0]!=="/" && path[0]!=="."){
						path="./"+path;
					}
					text=btn.previousSibling.text;
					if(text){
						if(text.endsWith(";")){
							text+=path;
						}else{
							text+=";"+path;
						}
					}else{
						text=path;
					}
					btn.previousSibling.text=text;
					self.syncConfig(true,btn.previousSibling);
				}catch(err){
					console.error(err);
					window.alert("Can't import file, err: "+err);
				}
			}
		};
	}
	
	//************************************************************************
	//Chat
	//************************************************************************
	{
		//--------------------------------------------------------------------
		cssVO.doChangeModel=function(model){
			if(model){
				if(typeof(model)==="string"){
					let name=model;
					model=ChatModels[name];
					if(!model){
						console.error("Can't find model: "+name);
						return;
					}
				}
				btnChatModel.text=model.text;
				btnMaxToken.max=model.maxToken;
				if(btnMaxToken.value>btnMaxToken.max){
					btnMaxToken.value=btnMaxToken.max;
				}
				chatDoc.config.model=model.text;
				return;
			}
			app.showDlg(DlgMenu,{
				items:Object.values(ChatModels),
				hud:btnChatModel,
				callback(item){
					if(!item){
						return;
					}
					self.doChangeModel(item);
				}
			});
		};
		
		//--------------------------------------------------------------------
		cssVO.executeChat=async function(){
			let callVO;
			let msg,blk,def;
			let aiChat,watchObj;
			self.syncConfig(false,null);
	
			callVO=chatDoc.genCallVO();
			
			//Make sure user login:
			if(!(await tabNT.checkLogin(false))){
				let rootApp;
				rootApp=app.appFrame?app.appFrame.app:app;
				rootApp.showDlg(DlgLogin,{x:rootApp.width/2,y:100,alignH:1});
				return;
			}
			//Add new block:
			watchObj={content:""};
			makeObjEventEmitter(watchObj);
			//New message:
			msg=VFACT.flexState({role:"assistant",contents:""});
			def={
				type:BtnAIChatMsg(app,msg,self),
				OnClick(){
					this.startEdit();
					editingBlk=this;
				}
			};
			chatDoc.chatMsgs.push(msg);
			blk=hudMsgList.appendNewChild(def);
			VFACT.scrollToShow(blk);
			blk.traceObj(watchObj);
	
			executing=true;
			execBlk=blk;
	
			//show face, execute AI Call, 
			self.showFace("execOn");
			aiChat=app.aiChat;
			try{
				await aiChat.doAIStreamCall("AICallStream",callVO,watchObj);
				if(executing && execBlk===blk){//still in session?
					self.showFace("execOff");
					executing=false;
					execBlk=null;
					self.askToken(blk);
				}
			}catch(err){
				execBlk.stopTrace();
				app.showStateText(`AI call failed: ${err}`);
				if(executing && execBlk===blk){//still in session?
					self.showFace("execOff");
					chatDoc.chatMsgs.pop();
					hudMsgList.removeChild(execBlk);
					executing=false;
					execBlk=null;
				}
			}
			self.checkCy();
		};
		
		//--------------------------------------------------------------------
		cssVO.cancelExec=function(){
			if(!executing){
				return false;
			}
			execBlk.stopTrace();
			chatDoc.chatMsgs.pop();
			hudMsgList.removeChild(execBlk);
			executing=false;
			execBlk=null;
			self.showFace("execOff");
			self.checkCy();
		};
		
		//--------------------------------------------------------------------
		cssVO.showCode=function(blk){
			let chatMsgs,msg,idx,text;
			chatMsgs=chatDoc.chatMsgs;
			msg=blk.msg;
			idx=chatMsgs.indexOf(msg);
			if(idx<0)
				return;
			text=chatDoc.genCode(idx);
			dataDocs.newEmptyDoc(".js",false,text).then(doc=>{
				dataDocs.focusDoc(doc);
			});
		};
		
		//--------------------------------------------------------------------
		cssVO.doCalTokens=async function(){
			let callVO;
			if(tokenVersion===msgVersion){
				return;
			}
			if(!tabNT.checkLogin(false)){
				return;
			}
			tokenVersion=msgVersion;
			btnCalTokens.enable=false;
			callVO=chatDoc.genCallVO();
			callVO={messages:callVO.messages};
			try{
				let msgs,msg,tokens,i,n;
				let res=await tabNT.makeCall("AICalculateTokens",callVO);
				if(res.code!==200){
					throw new Error(`AIStreamCall failed: ${res.code}: ${res.info}`);
				}
				msgs=chatDoc.chatMsgs;
				tokens=res.messageTokens;
				chatDoc.sysMsgTokens=tokens[0];
				txtSysTokens.text="Tokens: "+tokens[0];
				tokens.shift();
				n=tokens.length;
				if(n!==msgs.length){
					throw new Error("Array size not aligned.");
				}
				for(i=0;i<n;i++){
					msgs[i].tokens=tokens[i];
				}
				txtAllTokens.text="Total tokens: "+res.tokens;
			}catch(err){
				app.showStateText(`Calculate tokens failed: ${err}`);
			}
			btnCalTokens.enable=true;
		};
		
		//--------------------------------------------------------------------
		cssVO.askToken=async function(blk){
			let msg,callVO;
			if(!tabNT.checkLogin(false)){
				return;
			}
			txtAllTokens.text="- - -";
			msg=blk.msg;
			callVO={messages:[{role:msg.role,content:msg.content}]};
			try{
				let res=await tabNT.makeCall("AICalculateTokens",callVO);
				if(res.code!==200){
					throw new Error(`AIStreamCall failed: ${res.code}: ${res.info}`);
				}
				msg.tokens=res.tokens;
				self.updateAllTokens();
			}catch(err){
				msg.tokens=-1;
			}
		};
		
		//--------------------------------------------------------------------
		cssVO.updateAllTokens=function(){
			let totalNum,msgs,msg;
			totalNum=chatDoc.sysMsgTokens;
			msgs=chatDoc.chatMsgs;
			for(msg of msgs){
				if(msg.tokens>=0){
					totalNum+=msg.tokens;
				}else{
					txtAllTokens.text="- - -";
					return;
				}
			}
			txtAllTokens.text="Total tokens: "+(totalNum>0?totalNum:"- - -");
		};
	}
	
	//************************************************************************
	//Doc Editor:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		cssVO.applyCfg=function(opts){
			//TODO: Code this
		};
		
		//--------------------------------------------------------------------
		cssVO.setEditText=function(text){
			//TODO: Code this:
		};
		
		//--------------------------------------------------------------------
		cssVO.getEditText=function(){
			self.syncConfig(false,null);
			return chatDoc.genDocText();
		};
		
		//--------------------------------------------------------------------
		cssVO.getEditVersion=function(){
			return editVersion;
		};
		
		//--------------------------------------------------------------------
		cssVO.focus=function(){
			self.checkCy();
		};
		
		//--------------------------------------------------------------------
		cssVO.blur=function(){
			//Do nothing.
		};
		
		//--------------------------------------------------------------------
		cssVO.gotoLine=function(line){
			//Do nothing.
		};
		
		//--------------------------------------------------------------------
		cssVO.getSelection=function(){
			return "";
		};
	
		//--------------------------------------------------------------------
		cssVO.replaceSelection=function(text,select){
		};
	
		//--------------------------------------------------------------------
		cssVO.getCursorPos=function(){
			return {line:0,ch:0};
		};
	
		//--------------------------------------------------------------------
		cssVO.getCursorIndex=function(){
			return 0;
		};
		
		//--------------------------------------------------------------------
		cssVO.getSelectionRange=function(){
			return [0,0];
		};
	}
	
	//************************************************************************
	//Work with cody
	//************************************************************************
	{
		//--------------------------------------------------------------------
		cssVO.peekUndoAction=function(){
		};
		
		//--------------------------------------------------------------------
		cssVO.peekRedoAction=function(){
		};
		
		//--------------------------------------------------------------------
		cssVO.addCodyEditAction=function(action){
		};
	
		//--------------------------------------------------------------------
		cssVO.lockCodySegs=function(){
		};
	}
	
	//------------------------------------------------------------------------
	const baseURL=import.meta.url;
	//const testAppURL=(baseURL.indexOf("/ui/")>0)?(new URL("../testchat.html", baseURL).href):(new URL("./testchat.html", baseURL).href);
	const testAppURL="/@aichat/app.html";
	const appIconURL=(baseURL.indexOf("/ui/")>0)?(new URL("../aichat.svg", baseURL).href):(new URL("./aichat.svg", baseURL).href);
	const runMeta={
		type:"app",
		name:"Test Chat",
		caption:(($ln==="CN")?("测试聊天"):/*EN*/("Test Chat")),
		package:"dev",
		appFrame:{
			main:testAppURL,
			group:testAppURL,
			title:(($ln==="CN")?("测试聊天"):/*EN*/("Test Chat")),
			caption:(($ln==="CN")?("测试聊天"):/*EN*/("Test Chat")),
			icon:appIconURL,
			multiFrame:false,
			width:360,height:720,
			maxable:false,
		}
	};
	cssVO.testChat=async function(){
		let docJSON,rootApp;
		if(!(await tabNT.checkLogin(false))){
			let rootApp;
			rootApp=app.appFrame?app.appFrame.app:app;
			rootApp.showDlg(DlgLogin,{x:rootApp.width/2,y:100,alignH:1});
			return;
		}
		docJSON=JSON.stringify(chatDoc.genSaveVO());
		rootApp=app.appFrame?app.appFrame.app:app;
		rootApp.newFrameApp(runMeta,`json=${encodeURIComponent(docJSON)}&file=${encodeURIComponent(dataDoc.path||dataDoc.name)}`,{});
	};
	
	//------------------------------------------------------------------------
	cssVO.handleShortcut=function(cmd){
		switch(cmd){
			case "Undo":
				self.undo();
				return true;
			case "Redo":
				self.redo();
				return true;
		};
		return false;
	};
	/*}#1H04Q8C9M1PostCSSVO*/
	return cssVO;
};
/*#{1H04Q8C9M1ExCodes*/
UIEditAI.scoreDoc=function(doc){
	let path;
	path=doc.path.toLowerCase();
	if(path.endsWith(".aichat")){
		return 100;
	}
	return 0;
};
AddOn.regAddOn("DocEditor","AIChatEditor",UIEditAI);
/*}#1H04Q8C9M1ExCodes*/


/*#{1H04Q8C9M0EndDoc*/
/*}#1H04Q8C9M0EndDoc*/

export default UIEditAI;
export{UIEditAI};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1H04Q8C9M0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1H04Q8C9M2",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "800",
//				"screenH": "1200",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1H04Q8C9M3",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1H7A209570",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1H04Q8C9M4",
//			"attrs": {
//				"app": {
//					"type": "auto",
//					"valText": "{}"
//				},
//				"mode": {
//					"type": "string",
//					"valText": "\".aichat\""
//				},
//				"codeText": {
//					"type": "string",
//					"valText": ""
//				},
//				"cfgVO": {
//					"type": "auto",
//					"valText": "{}"
//				},
//				"dataDoc": {
//					"type": "auto",
//					"valText": "{}"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1H04Q8C9M5",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1H04Q8C9M6",
//			"attrs": {
//				"cfgFrmW": {
//					"type": "int",
//					"valText": "260"
//				},
//				"hudBtmH": {
//					"type": "int",
//					"valText": "50"
//				},
//				"userTokens": {
//					"type": "int",
//					"valText": "-1"
//				},
//				"userGas": {
//					"type": "int",
//					"valText": "-1"
//				}
//			}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1H04Q8C9M7",
//			"attrs": {
//				"lite": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H04SO18C0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H04SO18C1",
//							"attrs": {}
//						}
//					}
//				},
//				"full": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H04SO18C2",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H04SO18C3",
//							"attrs": {}
//						}
//					}
//				},
//				"mobile": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H04SO18C4",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H04SO18C5",
//							"attrs": {}
//						}
//					}
//				},
//				"execOn": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H0MSV9FC0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H0MT60MA0",
//							"attrs": {}
//						}
//					}
//				},
//				"execOff": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H0MT4FFD0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H0MT60MA1",
//							"attrs": {}
//						}
//					}
//				},
//				"checkCy": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H16JA01P0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H16JAUVA0",
//							"attrs": {}
//						}
//					}
//				},
//				"showCy": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H16JAIMO0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H16JAUVA1",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1HBHO3VNC0",
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1H04Q8C9M1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1H04Q8C9M8",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "\"FW\"",
//						"h": "\"FH\"",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "true",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": ""
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1H04QFDMC0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H04SO18C6",
//									"attrs": {
//										"type": "hud",
//										"id": "HudCfgFrm",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "${state.cfgFrmW},state",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": ""
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1H04QQRGC0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H04SO18C7",
//													"attrs": {
//														"type": "hud",
//														"id": "HudCfgBox",
//														"position": "Absolute",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "[0,10,0,10]",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex Y"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnText.js",
//															"jaxId": "1H04QV7C20",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1H04SO18C8",
//																	"attrs": {
//																		"style": "secondary",
//																		"w": "180",
//																		"h": "24",
//																		"text": "Model: GPT-3.5",
//																		"outlined": "false",
//																		"icon": ""
//																	}
//																},
//																"properties": {
//																	"jaxId": "1H04SO18C9",
//																	"attrs": {
//																		"type": "#null#>BtnText(\"secondary\",180,24,\"Model: GPT-3.5\",false,\"\")",
//																		"id": "BtnChatModel",
//																		"position": "relative",
//																		"x": "50%",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"anchorH": "Center",
//																		"margin": "[5,0,0,0]",
//																		"corner": "3"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1H04SO18C10",
//																	"attrs": {
//																		"1H0MSV9FC0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H0MT60MA4",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H0MT60MA5",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H0MSV9FC0",
//																			"faceTagName": "execOn"
//																		},
//																		"1H16JA01P0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H16JAUVA2",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H16JAUVA3",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H16JA01P0",
//																			"faceTagName": "checkCy"
//																		},
//																		"1H0MT4FFD0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H9FCTHPB0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H9FCTHPB1",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H0MT4FFD0",
//																			"faceTagName": "execOff"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1H04SO18C11",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1H07EK69K0",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1H07EKDC30",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1H04SO18C12",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1H7A209571",
//																	"attrs": {
//																		"Slot1H2F6U36O0": {
//																			"jaxId": "1IA2I3ORN0",
//																			"attrs": {
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"container": "true"
//																			}
//																		}
//																	}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "box",
//															"jaxId": "1H04RO3J80",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1H04SO18D7",
//																	"attrs": {
//																		"type": "box",
//																		"id": "",
//																		"position": "relative",
//																		"x": "20",
//																		"y": "0",
//																		"w": "100%-40",
//																		"h": "1",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[10,0,10,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"background": "#cfgColor[\"lineBodySub\"]",
//																		"border": "0",
//																		"borderStyle": "Solid",
//																		"borderColor": "[0,0,0,1.00]",
//																		"corner": "0",
//																		"shadow": "false",
//																		"shadowX": "2",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowSpread": "0",
//																		"shadowColor": "[0,0,0,0.50]"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1H04SO18D8",
//																	"attrs": {
//																		"1H0MSV9FC0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H0MT60MB2",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H0MT60MB3",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H0MSV9FC0",
//																			"faceTagName": "execOn"
//																		},
//																		"1H16JA01P0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H16JAUVA6",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H16JAUVA7",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H16JA01P0",
//																			"faceTagName": "checkCy"
//																		},
//																		"1H0MT4FFD0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H9FCTHPB2",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H9FCTHPB3",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H0MT4FFD0",
//																			"faceTagName": "execOff"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1H04SO18D9",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1H04SO18D10",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1H04S3U4J0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1H04SBEIT0",
//																	"attrs": {
//																		"type": "hud",
//																		"id": "BoxTemperature",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "50",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "text",
//																			"jaxId": "1H04S4C9G0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H04S4C9G1",
//																					"attrs": {
//																						"type": "text",
//																						"id": "",
//																						"position": "Absolute",
//																						"x": "0",
//																						"y": "0",
//																						"w": "100%",
//																						"h": "20",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"color": "#cfgColor.fontBody",
//																						"text": {
//																							"type": "string",
//																							"valText": "温度(Temperature):",
//																							"localize": {
//																								"EN": "Temperature:",
//																								"CN": "温度(Temperature):"
//																							},
//																							"localizable": true
//																						},
//																						"font": "",
//																						"fontSize": "#txtSize.smallMid",
//																						"bold": "false",
//																						"italic": "false",
//																						"underline": "false",
//																						"alignH": "Left",
//																						"alignV": "Center",
//																						"wrap": "false",
//																						"ellipsis": "false",
//																						"lineClamp": "0",
//																						"select": "false",
//																						"shadow": "false",
//																						"shadowX": "0",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowColor": "[0,0,0,1.00]",
//																						"shadowEx": "",
//																						"maxTextW": "0",
//																						"autoSizeW": "false",
//																						"autoSizeH": "false"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1H04S4C9G2",
//																					"attrs": {
//																						"1H0MSV9FC0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H0MT60MB6",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H0MT60MB7",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MSV9FC0",
//																							"faceTagName": "execOn"
//																						},
//																						"1H16JA01P0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H16JAUVA10",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H16JAUVA11",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H16JA01P0",
//																							"faceTagName": "checkCy"
//																						},
//																						"1H0MT4FFD0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H9FCTHPB4",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H9FCTHPB5",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MT4FFD0",
//																							"faceTagName": "execOff"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1H04S4C9G3",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1H04S4C9G4",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "text",
//																			"jaxId": "1H04S5M580",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H04S5M590",
//																					"attrs": {
//																						"type": "text",
//																						"id": "TxtTemperature",
//																						"position": "Absolute",
//																						"x": "0",
//																						"y": "0",
//																						"w": "100%",
//																						"h": "20",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"color": "#cfgColor.fontBody",
//																						"text": "20",
//																						"font": "",
//																						"fontSize": "#txtSize.smallMid",
//																						"bold": "false",
//																						"italic": "false",
//																						"underline": "false",
//																						"alignH": "Right",
//																						"alignV": "Center",
//																						"wrap": "false",
//																						"ellipsis": "false",
//																						"lineClamp": "0",
//																						"select": "false",
//																						"shadow": "false",
//																						"shadowX": "0",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowColor": "[0,0,0,1.00]",
//																						"shadowEx": "",
//																						"maxTextW": "0",
//																						"autoSizeW": "false",
//																						"autoSizeH": "false"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1H04S5M591",
//																					"attrs": {
//																						"1H0MSV9FC0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H0MT60MB10",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H0MT60MB11",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MSV9FC0",
//																							"faceTagName": "execOn"
//																						},
//																						"1H16JA01P0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H16JAUVA14",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H16JAUVA15",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H16JA01P0",
//																							"faceTagName": "checkCy"
//																						},
//																						"1H0MT4FFD0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H9FCTHPB6",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H9FCTHPB7",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MT4FFD0",
//																							"faceTagName": "execOff"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1H04S5M592",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1H04S5M593",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "true"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "Gear/@StdUI/ui/BoxRange.js",
//																			"jaxId": "1H04S4EOE0",
//																			"attrs": {
//																				"createArgs": {
//																					"jaxId": "1H04S4EOE1",
//																					"attrs": {
//																						"value": "1",
//																						"minVal": "0",
//																						"maxVal": "2"
//																					}
//																				},
//																				"properties": {
//																					"jaxId": "1H04S4EOE2",
//																					"attrs": {
//																						"type": "#null#>BoxRange(1,0,2)",
//																						"id": "BtnTemperature",
//																						"position": "Absolute",
//																						"x": "0",
//																						"y": "20",
//																						"display": "On",
//																						"face": "",
//																						"w": "100%",
//																						"margin": "[5,0,0,0]",
//																						"digit": "0",
//																						"step": "0.1",
//																						"h": "20",
//																						"buttonSize": "20"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1H04S4EOF0",
//																					"attrs": {
//																						"1H0MSV9FC0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H0MT60MB14",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H0MT60MB15",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MSV9FC0",
//																							"faceTagName": "execOn"
//																						},
//																						"1H16JA01P0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H16JAUVA18",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H16JAUVA19",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H16JA01P0",
//																							"faceTagName": "checkCy"
//																						},
//																						"1H0MT4FFD0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H9FCTHPB8",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H9FCTHPB9",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MT4FFD0",
//																							"faceTagName": "execOff"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1H04S4EOF1",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1H04S4EOF2",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "true",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "true",
//																				"containerSlots": {
//																					"jaxId": "1H7A209580",
//																					"attrs": {}
//																				}
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"jaxId": "1H04SBEIT1",
//																	"attrs": {
//																		"1H0MSV9FC0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H0MT60MB18",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H0MT60MB19",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H0MSV9FC0",
//																			"faceTagName": "execOn"
//																		},
//																		"1H16JA01P0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H16JAUVA22",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H16JAUVA23",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H16JA01P0",
//																			"faceTagName": "checkCy"
//																		},
//																		"1H0MT4FFD0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H9FCTHPB10",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H9FCTHPB11",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H0MT4FFD0",
//																			"faceTagName": "execOff"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1H04SBEIT2",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1H04SBEIU0",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false",
//																"exposeContainer": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1H04SBRNC0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1H04SBRNC1",
//																	"attrs": {
//																		"type": "hud",
//																		"id": "BoxMaxToken",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "50",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "text",
//																			"jaxId": "1H04SBRND0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H04SBRND1",
//																					"attrs": {
//																						"type": "text",
//																						"id": "",
//																						"position": "Absolute",
//																						"x": "0",
//																						"y": "0",
//																						"w": "100%",
//																						"h": "20",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"color": "#cfgColor.fontBody",
//																						"text": {
//																							"type": "string",
//																							"valText": "最大词元数(Max tokens):",
//																							"localize": {
//																								"EN": "Max tokens:",
//																								"CN": "最大词元数(Max tokens):"
//																							},
//																							"localizable": true
//																						},
//																						"font": "",
//																						"fontSize": "#txtSize.smallMid",
//																						"bold": "false",
//																						"italic": "false",
//																						"underline": "false",
//																						"alignH": "Left",
//																						"alignV": "Center",
//																						"wrap": "false",
//																						"ellipsis": "false",
//																						"lineClamp": "0",
//																						"select": "false",
//																						"shadow": "false",
//																						"shadowX": "0",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowColor": "[0,0,0,1.00]",
//																						"shadowEx": "",
//																						"maxTextW": "0",
//																						"autoSizeW": "false",
//																						"autoSizeH": "false"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1H04SBRND2",
//																					"attrs": {
//																						"1H0MSV9FC0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H0MT60MB22",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H0MT60MB23",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MSV9FC0",
//																							"faceTagName": "execOn"
//																						},
//																						"1H16JA01P0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H16JAUVA26",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H16JAUVA27",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H16JA01P0",
//																							"faceTagName": "checkCy"
//																						},
//																						"1H0MT4FFD0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H9FCTHPB12",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H9FCTHPB13",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MT4FFD0",
//																							"faceTagName": "execOff"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1H04SBRND3",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1H04SBRND4",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "text",
//																			"jaxId": "1H04SBRND5",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H04SBRND6",
//																					"attrs": {
//																						"type": "text",
//																						"id": "TxtMaxToken",
//																						"position": "Absolute",
//																						"x": "0",
//																						"y": "0",
//																						"w": "100%",
//																						"h": "20",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"color": "#cfgColor.fontBody",
//																						"text": "4800",
//																						"font": "",
//																						"fontSize": "#txtSize.smallMid",
//																						"bold": "false",
//																						"italic": "false",
//																						"underline": "false",
//																						"alignH": "Right",
//																						"alignV": "Center",
//																						"wrap": "false",
//																						"ellipsis": "false",
//																						"lineClamp": "0",
//																						"select": "false",
//																						"shadow": "false",
//																						"shadowX": "0",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowColor": "[0,0,0,1.00]",
//																						"shadowEx": "",
//																						"maxTextW": "0",
//																						"autoSizeW": "false",
//																						"autoSizeH": "false"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1H04SBRND7",
//																					"attrs": {
//																						"1H0MSV9FC0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H0MT60MB26",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H0MT60MB27",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MSV9FC0",
//																							"faceTagName": "execOn"
//																						},
//																						"1H16JA01P0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H16JAUVA30",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H16JAUVA31",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H16JA01P0",
//																							"faceTagName": "checkCy"
//																						},
//																						"1H0MT4FFD0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H9FCTHPB14",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H9FCTHPB15",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MT4FFD0",
//																							"faceTagName": "execOff"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1H04SBRND8",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1H04SBRND9",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "true"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "Gear/@StdUI/ui/BoxRange.js",
//																			"jaxId": "1H04SBRND10",
//																			"attrs": {
//																				"createArgs": {
//																					"jaxId": "1H04SBRND11",
//																					"attrs": {
//																						"value": "1024",
//																						"minVal": "0",
//																						"maxVal": "3096"
//																					}
//																				},
//																				"properties": {
//																					"jaxId": "1H04SBRND12",
//																					"attrs": {
//																						"type": "#null#>BoxRange(1024,0,3096)",
//																						"id": "BtnMaxToken",
//																						"position": "Absolute",
//																						"x": "0",
//																						"y": "20",
//																						"display": "On",
//																						"face": "",
//																						"w": "100%",
//																						"margin": "[5,0,0,0]",
//																						"step": "50",
//																						"digit": "0",
//																						"h": "20",
//																						"buttonSize": "20"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1H04SBRND13",
//																					"attrs": {
//																						"1H0MSV9FC0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H0MT60MB30",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H0MT60MB31",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MSV9FC0",
//																							"faceTagName": "execOn"
//																						},
//																						"1H16JA01P0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H16JAUVA34",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H16JAUVA35",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H16JA01P0",
//																							"faceTagName": "checkCy"
//																						},
//																						"1H0MT4FFD0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H9FCTHPB16",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H9FCTHPB17",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MT4FFD0",
//																							"faceTagName": "execOff"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1H04SBRND14",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1H04SBRND15",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "true",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "true",
//																				"containerSlots": {
//																					"jaxId": "1H7A209581",
//																					"attrs": {}
//																				}
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"jaxId": "1H04SBRND16",
//																	"attrs": {
//																		"1H0MSV9FC0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H0MT60MB34",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H0MT60MB35",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H0MSV9FC0",
//																			"faceTagName": "execOn"
//																		},
//																		"1H16JA01P0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H16JAUVA38",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H16JAUVA39",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H16JA01P0",
//																			"faceTagName": "checkCy"
//																		},
//																		"1H0MT4FFD0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H9FCTHPB18",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H9FCTHPB19",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H0MT4FFD0",
//																			"faceTagName": "execOff"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1H04SBRND17",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1H04SBRND18",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false",
//																"exposeContainer": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1H04SGD1P0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1H04SGD1P1",
//																	"attrs": {
//																		"type": "hud",
//																		"id": "BoxTopP",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "50",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "text",
//																			"jaxId": "1H04SGD1P2",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H04SGD1P3",
//																					"attrs": {
//																						"type": "text",
//																						"id": "",
//																						"position": "Absolute",
//																						"x": "0",
//																						"y": "0",
//																						"w": "100%",
//																						"h": "20",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"color": "#cfgColor.fontBody",
//																						"text": {
//																							"type": "string",
//																							"valText": "P峰值(Top P):",
//																							"localize": {
//																								"EN": "Top P:",
//																								"CN": "P峰值(Top P):"
//																							},
//																							"localizable": true
//																						},
//																						"font": "",
//																						"fontSize": "#txtSize.smallMid",
//																						"bold": "false",
//																						"italic": "false",
//																						"underline": "false",
//																						"alignH": "Left",
//																						"alignV": "Center",
//																						"wrap": "false",
//																						"ellipsis": "false",
//																						"lineClamp": "0",
//																						"select": "false",
//																						"shadow": "false",
//																						"shadowX": "0",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowColor": "[0,0,0,1.00]",
//																						"shadowEx": "",
//																						"maxTextW": "0",
//																						"autoSizeW": "false",
//																						"autoSizeH": "false"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1H04SGD1Q0",
//																					"attrs": {
//																						"1H0MSV9FC0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H0MT60MB38",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H0MT60MB39",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MSV9FC0",
//																							"faceTagName": "execOn"
//																						},
//																						"1H16JA01P0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H16JAUVA42",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H16JAUVA43",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H16JA01P0",
//																							"faceTagName": "checkCy"
//																						},
//																						"1H0MT4FFD0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H9FCTHPB20",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H9FCTHPB21",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MT4FFD0",
//																							"faceTagName": "execOff"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1H04SGD1Q1",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1H04SGD1Q2",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "text",
//																			"jaxId": "1H04SGD1Q3",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H04SGD1Q4",
//																					"attrs": {
//																						"type": "text",
//																						"id": "TxtTopP",
//																						"position": "Absolute",
//																						"x": "0",
//																						"y": "0",
//																						"w": "100%",
//																						"h": "20",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"color": "#cfgColor.fontBody",
//																						"text": "1",
//																						"font": "",
//																						"fontSize": "#txtSize.smallMid",
//																						"bold": "false",
//																						"italic": "false",
//																						"underline": "false",
//																						"alignH": "Right",
//																						"alignV": "Center",
//																						"wrap": "false",
//																						"ellipsis": "false",
//																						"lineClamp": "0",
//																						"select": "false",
//																						"shadow": "false",
//																						"shadowX": "0",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowColor": "[0,0,0,1.00]",
//																						"shadowEx": "",
//																						"maxTextW": "0",
//																						"autoSizeW": "false",
//																						"autoSizeH": "false"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1H04SGD1Q5",
//																					"attrs": {
//																						"1H0MSV9FC0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H0MT60MB42",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H0MT60MB43",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MSV9FC0",
//																							"faceTagName": "execOn"
//																						},
//																						"1H16JA01P0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H16JAUVA46",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H16JAUVA47",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H16JA01P0",
//																							"faceTagName": "checkCy"
//																						},
//																						"1H0MT4FFD0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H9FCTHPB22",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H9FCTHPB23",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MT4FFD0",
//																							"faceTagName": "execOff"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1H04SGD1Q6",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1H04SGD1Q7",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "true"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "Gear/@StdUI/ui/BoxRange.js",
//																			"jaxId": "1H04SGD1Q8",
//																			"attrs": {
//																				"createArgs": {
//																					"jaxId": "1H04SGD1Q9",
//																					"attrs": {
//																						"value": "1",
//																						"minVal": "0",
//																						"maxVal": "1"
//																					}
//																				},
//																				"properties": {
//																					"jaxId": "1H04SGD1Q10",
//																					"attrs": {
//																						"type": "#null#>BoxRange(1,0,1)",
//																						"id": "BtnTopP",
//																						"position": "Absolute",
//																						"x": "0",
//																						"y": "20",
//																						"display": "On",
//																						"face": "",
//																						"w": "100%",
//																						"margin": "[5,0,0,0]",
//																						"digit": "2",
//																						"step": "0.1",
//																						"h": "20",
//																						"buttonSize": "20"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1H04SGD1R0",
//																					"attrs": {
//																						"1H0MSV9FC0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H0MT60MB46",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H0MT60MB47",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MSV9FC0",
//																							"faceTagName": "execOn"
//																						},
//																						"1H16JA01P0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H16JAUVA50",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H16JAUVA51",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H16JA01P0",
//																							"faceTagName": "checkCy"
//																						},
//																						"1H0MT4FFD0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H9FCTHPB24",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H9FCTHPB25",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MT4FFD0",
//																							"faceTagName": "execOff"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1H04SGD1R1",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1H04SGD1R2",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "true",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "true",
//																				"containerSlots": {
//																					"jaxId": "1H7A209582",
//																					"attrs": {}
//																				}
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"jaxId": "1H04SGD1R3",
//																	"attrs": {
//																		"1H0MSV9FC0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H0MT60MB50",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H0MT60MB51",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H0MSV9FC0",
//																			"faceTagName": "execOn"
//																		},
//																		"1H16JA01P0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H16JAUVA54",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H16JAUVA55",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H16JA01P0",
//																			"faceTagName": "checkCy"
//																		},
//																		"1H0MT4FFD0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H9FCTHPB26",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H9FCTHPB27",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H0MT4FFD0",
//																			"faceTagName": "execOff"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1H04SGD1R4",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1H04SGD1R5",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false",
//																"exposeContainer": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1H04SJBC40",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1H04SJBC41",
//																	"attrs": {
//																		"type": "hud",
//																		"id": "BoxFqcP",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "50",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "text",
//																			"jaxId": "1H04SJBC42",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H04SJBC43",
//																					"attrs": {
//																						"type": "text",
//																						"id": "",
//																						"position": "Absolute",
//																						"x": "0",
//																						"y": "0",
//																						"w": "100%",
//																						"h": "20",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"color": "#cfgColor.fontBody",
//																						"text": {
//																							"type": "string",
//																							"valText": "频率惩罚(Frequency penalty):",
//																							"localize": {
//																								"EN": "Frequency penalty:",
//																								"CN": "频率惩罚(Frequency penalty):"
//																							},
//																							"localizable": true
//																						},
//																						"font": "",
//																						"fontSize": "#txtSize.smallMid",
//																						"bold": "false",
//																						"italic": "false",
//																						"underline": "false",
//																						"alignH": "Left",
//																						"alignV": "Center",
//																						"wrap": "false",
//																						"ellipsis": "false",
//																						"lineClamp": "0",
//																						"select": "false",
//																						"shadow": "false",
//																						"shadowX": "0",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowColor": "[0,0,0,1.00]",
//																						"shadowEx": "",
//																						"maxTextW": "0",
//																						"autoSizeW": "false",
//																						"autoSizeH": "false"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1H04SJBC44",
//																					"attrs": {
//																						"1H0MSV9FC0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H0MT60MB54",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H0MT60MB55",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MSV9FC0",
//																							"faceTagName": "execOn"
//																						},
//																						"1H16JA01P0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H16JAUVB0",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H16JAUVB1",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H16JA01P0",
//																							"faceTagName": "checkCy"
//																						},
//																						"1H0MT4FFD0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H9FCTHPB28",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H9FCTHPB29",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MT4FFD0",
//																							"faceTagName": "execOff"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1H04SJBC45",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1H04SJBC46",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "text",
//																			"jaxId": "1H04SJBC50",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H04SJBC51",
//																					"attrs": {
//																						"type": "text",
//																						"id": "TxtFqcP",
//																						"position": "Absolute",
//																						"x": "0",
//																						"y": "0",
//																						"w": "100%",
//																						"h": "20",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"color": "#cfgColor.fontBody",
//																						"text": "0",
//																						"font": "",
//																						"fontSize": "#txtSize.smallMid",
//																						"bold": "false",
//																						"italic": "false",
//																						"underline": "false",
//																						"alignH": "Right",
//																						"alignV": "Center",
//																						"wrap": "false",
//																						"ellipsis": "false",
//																						"lineClamp": "0",
//																						"select": "false",
//																						"shadow": "false",
//																						"shadowX": "0",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowColor": "[0,0,0,1.00]",
//																						"shadowEx": "",
//																						"maxTextW": "0",
//																						"autoSizeW": "false",
//																						"autoSizeH": "false"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1H04SJBC52",
//																					"attrs": {
//																						"1H0MSV9FC0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H0MT60MB58",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H0MT60MB59",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MSV9FC0",
//																							"faceTagName": "execOn"
//																						},
//																						"1H16JA01P0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H16JAUVB4",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H16JAUVB5",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H16JA01P0",
//																							"faceTagName": "checkCy"
//																						},
//																						"1H0MT4FFD0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H9FCTHPB30",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H9FCTHPB31",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MT4FFD0",
//																							"faceTagName": "execOff"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1H04SJBC53",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1H04SJBC54",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "true"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "Gear/@StdUI/ui/BoxRange.js",
//																			"jaxId": "1H04SJBC55",
//																			"attrs": {
//																				"createArgs": {
//																					"jaxId": "1H04SJBC56",
//																					"attrs": {
//																						"value": "0",
//																						"minVal": "0",
//																						"maxVal": "1"
//																					}
//																				},
//																				"properties": {
//																					"jaxId": "1H04SJBC57",
//																					"attrs": {
//																						"type": "#null#>BoxRange(0,0,1)",
//																						"id": "BtnFqcP",
//																						"position": "Absolute",
//																						"x": "0",
//																						"y": "20",
//																						"display": "On",
//																						"face": "",
//																						"w": "100%",
//																						"margin": "[5,0,0,0]",
//																						"digit": "2",
//																						"step": "0.1",
//																						"h": "20",
//																						"buttonSize": "20"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1H04SJBC58",
//																					"attrs": {
//																						"1H0MSV9FC0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H0MT60MB62",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H0MT60MB63",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MSV9FC0",
//																							"faceTagName": "execOn"
//																						},
//																						"1H16JA01P0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H16JAUVB8",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H16JAUVB9",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H16JA01P0",
//																							"faceTagName": "checkCy"
//																						},
//																						"1H0MT4FFD0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H9FCTHPB32",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H9FCTHPB33",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MT4FFD0",
//																							"faceTagName": "execOff"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1H04SJBC59",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1H04SJBC510",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "true",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "true",
//																				"containerSlots": {
//																					"jaxId": "1H7A209583",
//																					"attrs": {}
//																				}
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"jaxId": "1H04SJBC511",
//																	"attrs": {
//																		"1H0MSV9FC0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H0MT60MB66",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H0MT60MB67",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H0MSV9FC0",
//																			"faceTagName": "execOn"
//																		},
//																		"1H16JA01P0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H16JAUVB12",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H16JAUVB13",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H16JA01P0",
//																			"faceTagName": "checkCy"
//																		},
//																		"1H0MT4FFD0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H9FCTHPB34",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H9FCTHPB35",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H0MT4FFD0",
//																			"faceTagName": "execOff"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1H04SJBC512",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1H04SJBC513",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false",
//																"exposeContainer": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1H04SOV4T0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1H04SOV4T1",
//																	"attrs": {
//																		"type": "hud",
//																		"id": "BoxPrcP",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "50",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "text",
//																			"jaxId": "1H04SOV4U0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H04SOV4U1",
//																					"attrs": {
//																						"type": "text",
//																						"id": "",
//																						"position": "Absolute",
//																						"x": "0",
//																						"y": "0",
//																						"w": "100%",
//																						"h": "20",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"color": "#cfgColor.fontBody",
//																						"text": {
//																							"type": "string",
//																							"valText": "重复惩罚(Presence penalty):",
//																							"localize": {
//																								"EN": "Presence penalty:",
//																								"CN": "重复惩罚(Presence penalty):"
//																							},
//																							"localizable": true
//																						},
//																						"font": "",
//																						"fontSize": "#txtSize.smallMid",
//																						"bold": "false",
//																						"italic": "false",
//																						"underline": "false",
//																						"alignH": "Left",
//																						"alignV": "Center",
//																						"wrap": "false",
//																						"ellipsis": "false",
//																						"lineClamp": "0",
//																						"select": "false",
//																						"shadow": "false",
//																						"shadowX": "0",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowColor": "[0,0,0,1.00]",
//																						"shadowEx": "",
//																						"maxTextW": "0",
//																						"autoSizeW": "false",
//																						"autoSizeH": "false"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1H04SOV4U2",
//																					"attrs": {
//																						"1H0MSV9FC0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H0MT60MB70",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H0MT60MB71",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MSV9FC0",
//																							"faceTagName": "execOn"
//																						},
//																						"1H16JA01P0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H16JAUVB16",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H16JAUVB17",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H16JA01P0",
//																							"faceTagName": "checkCy"
//																						},
//																						"1H0MT4FFD0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H9FCTHPB36",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H9FCTHPB37",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MT4FFD0",
//																							"faceTagName": "execOff"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1H04SOV4U3",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1H04SOV4U4",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "text",
//																			"jaxId": "1H04SOV4U5",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H04SOV4U6",
//																					"attrs": {
//																						"type": "text",
//																						"id": "TxtPrcP",
//																						"position": "Absolute",
//																						"x": "0",
//																						"y": "0",
//																						"w": "100%",
//																						"h": "20",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"color": "#cfgColor.fontBody",
//																						"text": "0",
//																						"font": "",
//																						"fontSize": "#txtSize.smallMid",
//																						"bold": "false",
//																						"italic": "false",
//																						"underline": "false",
//																						"alignH": "Right",
//																						"alignV": "Center",
//																						"wrap": "false",
//																						"ellipsis": "false",
//																						"lineClamp": "0",
//																						"select": "false",
//																						"shadow": "false",
//																						"shadowX": "0",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowColor": "[0,0,0,1.00]",
//																						"shadowEx": "",
//																						"maxTextW": "0",
//																						"autoSizeW": "false",
//																						"autoSizeH": "false"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1H04SOV4U7",
//																					"attrs": {
//																						"1H0MSV9FC0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H0MT60MB74",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H0MT60MB75",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MSV9FC0",
//																							"faceTagName": "execOn"
//																						},
//																						"1H16JA01P0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H16JAUVB20",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H16JAUVB21",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H16JA01P0",
//																							"faceTagName": "checkCy"
//																						},
//																						"1H0MT4FFD0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H9FCTHPB38",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H9FCTHPB39",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MT4FFD0",
//																							"faceTagName": "execOff"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1H04SOV4U8",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1H04SOV4U9",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "true"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "Gear/@StdUI/ui/BoxRange.js",
//																			"jaxId": "1H04SOV4V0",
//																			"attrs": {
//																				"createArgs": {
//																					"jaxId": "1H04SOV4V1",
//																					"attrs": {
//																						"value": "0",
//																						"minVal": "0",
//																						"maxVal": "1"
//																					}
//																				},
//																				"properties": {
//																					"jaxId": "1H04SOV4V2",
//																					"attrs": {
//																						"type": "#null#>BoxRange(0,0,1)",
//																						"id": "BtnPrcP",
//																						"position": "Absolute",
//																						"x": "0",
//																						"y": "20",
//																						"display": "On",
//																						"face": "",
//																						"w": "100%",
//																						"margin": "[5,0,0,0]",
//																						"digit": "2",
//																						"step": "0.1",
//																						"h": "20",
//																						"buttonSize": "20"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1H04SOV4V3",
//																					"attrs": {
//																						"1H0MSV9FC0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H0MT60MB78",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H0MT60MB79",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MSV9FC0",
//																							"faceTagName": "execOn"
//																						},
//																						"1H16JA01P0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H16JAUVB24",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H16JAUVB25",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H16JA01P0",
//																							"faceTagName": "checkCy"
//																						},
//																						"1H0MT4FFD0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H9FCTHPB40",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H9FCTHPB41",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MT4FFD0",
//																							"faceTagName": "execOff"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1H04SOV4V4",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1H04SOV4V5",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "true",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "true",
//																				"containerSlots": {
//																					"jaxId": "1H7A209584",
//																					"attrs": {}
//																				}
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"jaxId": "1H04SOV4V6",
//																	"attrs": {
//																		"1H0MSV9FC0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H0MT60MB82",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H0MT60MB83",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H0MSV9FC0",
//																			"faceTagName": "execOn"
//																		},
//																		"1H16JA01P0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H16JAUVB28",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H16JAUVB29",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H16JA01P0",
//																			"faceTagName": "checkCy"
//																		},
//																		"1H0MT4FFD0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H9FCTHPB42",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H9FCTHPB43",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H0MT4FFD0",
//																			"faceTagName": "execOff"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1H04SOV4V7",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1H04SOV4V8",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false",
//																"exposeContainer": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "box",
//															"jaxId": "1H0MO4EQU0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1H0MO4EQU1",
//																	"attrs": {
//																		"type": "box",
//																		"id": "",
//																		"position": "relative",
//																		"x": "20",
//																		"y": "0",
//																		"w": "100%-40",
//																		"h": "1",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[10,0,10,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"background": "#cfgColor[\"lineBodySub\"]",
//																		"border": "0",
//																		"borderStyle": "Solid",
//																		"borderColor": "[0,0,0,1.00]",
//																		"corner": "0",
//																		"shadow": "false",
//																		"shadowX": "2",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowSpread": "0",
//																		"shadowColor": "[0,0,0,0.50]"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1H0MO4EQV0",
//																	"attrs": {
//																		"1H0MSV9FC0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H0MT60MB86",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H0MT60MB87",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H0MSV9FC0",
//																			"faceTagName": "execOn"
//																		},
//																		"1H16JA01P0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H16JAUVB32",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H16JAUVB33",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H16JA01P0",
//																			"faceTagName": "checkCy"
//																		},
//																		"1H0MT4FFD0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H9FCTHPB44",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H9FCTHPB45",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H0MT4FFD0",
//																			"faceTagName": "execOff"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1H0MO4EQV1",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1H0MO4EQV2",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "box",
//															"jaxId": "1H11F89F60",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1H11F89F61",
//																	"attrs": {
//																		"type": "box",
//																		"id": "BoxChatName",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "\"\"",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[0,0,10,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"background": "[255,255,255,1.00]",
//																		"border": "1",
//																		"borderStyle": "Solid",
//																		"borderColor": "#cfgColor.lineBodyLit",
//																		"corner": "5",
//																		"shadow": "false",
//																		"shadowX": "2",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowSpread": "0",
//																		"shadowColor": "[0,0,0,0.50]",
//																		"contentLayout": "Flex Y"
//																	}
//																},
//																"subHuds": {
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "hud",
//																			"jaxId": "1H11F89F70",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H11F89F71",
//																					"attrs": {
//																						"type": "hud",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "100%",
//																						"h": "16",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "[5,0,0,0]",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": ""
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": [
//																						{
//																							"type": "hudobj",
//																							"def": "text",
//																							"jaxId": "1H11F89F72",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H11F89F73",
//																									"attrs": {
//																										"type": "text",
//																										"id": "",
//																										"position": "Absolute",
//																										"x": "5",
//																										"y": "0",
//																										"w": "\"\"",
//																										"h": "\"\"",
//																										"anchorH": "Left",
//																										"anchorV": "Top",
//																										"autoLayout": "false",
//																										"display": "On",
//																										"clip": "Off",
//																										"uiEvent": "On",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "",
//																										"zIndex": "0",
//																										"margin": "[0,0,0,0]",
//																										"padding": "",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": "",
//																										"color": "#cfgColor.fontBodySub",
//																										"text": {
//																											"type": "string",
//																											"valText": "实验名称:",
//																											"localize": {
//																												"EN": "Playground name:",
//																												"CN": "实验名称:"
//																											},
//																											"localizable": true
//																										},
//																										"font": "",
//																										"fontSize": "#txtSize.small",
//																										"bold": "false",
//																										"italic": "false",
//																										"underline": "false",
//																										"alignH": "Left",
//																										"alignV": "Top",
//																										"wrap": "false",
//																										"ellipsis": "false",
//																										"lineClamp": "0",
//																										"select": "false",
//																										"shadow": "false",
//																										"shadowX": "0",
//																										"shadowY": "2",
//																										"shadowBlur": "3",
//																										"shadowColor": "[0,0,0,1.00]",
//																										"shadowEx": "",
//																										"maxTextW": "0",
//																										"autoSizeW": "false",
//																										"autoSizeH": "false"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1H11F89F74",
//																									"attrs": {
//																										"1H0MSV9FC0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1H11F89F80",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1H11F89F81",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H0MSV9FC0",
//																											"faceTagName": "execOn"
//																										},
//																										"1H16JA01P0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1H16JAUVB36",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1H16JAUVB37",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H16JA01P0",
//																											"faceTagName": "checkCy"
//																										},
//																										"1H0MT4FFD0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1H9FCTHPB46",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1H9FCTHPB47",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H0MT4FFD0",
//																											"faceTagName": "execOff"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1H11F89F82",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1H11F89F83",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "false"
//																							}
//																						}
//																					]
//																				},
//																				"faces": {
//																					"jaxId": "1H11F89F84",
//																					"attrs": {
//																						"1H16JA01P0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H16JAUVB40",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H16JAUVB41",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H16JA01P0",
//																							"faceTagName": "checkCy"
//																						},
//																						"1H0MSV9FC0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H9FCTHPB48",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H9FCTHPB49",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MSV9FC0",
//																							"faceTagName": "execOn"
//																						},
//																						"1H0MT4FFD0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H9FCTHPB50",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H9FCTHPB51",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MT4FFD0",
//																							"faceTagName": "execOff"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1H11F89F85",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1H11F89F86",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "false",
//																				"exposeContainer": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "memo",
//																			"jaxId": "1H11F89F87",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H11F89F88",
//																					"attrs": {
//																						"type": "memo",
//																						"id": "EdChatName",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "100%",
//																						"h": "\"\"",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "text",
//																						"zIndex": "0",
//																						"margin": "[3,0,0,0]",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "20",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"text": "",
//																						"color": "[0,0,0]",
//																						"bgColor": "[255,255,255,0.00]",
//																						"font": "",
//																						"fontSize": "#txtSize.smallMid",
//																						"outline": "0",
//																						"border": "0",
//																						"borderStyle": "Solid",
//																						"borderColor": "[0,0,0,1.00]",
//																						"corner": "0",
//																						"readOnly": "false",
//																						"selectOnFocus": "true",
//																						"spellCheck": "true",
//																						"flex": "true"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1H11F89F89",
//																					"attrs": {
//																						"1H0MSV9FC0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H11F89F810",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H11F89F811",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MSV9FC0",
//																							"faceTagName": "execOn"
//																						},
//																						"1H16JA01P0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H16JAUVB44",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H16JAUVB45",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H16JA01P0",
//																							"faceTagName": "checkCy"
//																						},
//																						"1H0MT4FFD0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H9FCTHPB52",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H9FCTHPB53",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MT4FFD0",
//																							"faceTagName": "execOff"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1H11F89F812",
//																					"attrs": {
//																						"OnInput": {
//																							"type": "fixedFunc",
//																							"jaxId": "1H11F89F813",
//																							"attrs": {
//																								"callArgs": {
//																									"jaxId": "1H11F89F814",
//																									"attrs": {}
//																								},
//																								"seg": ""
//																							}
//																						}
//																					}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1H11F89F815",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "true",
//																				"container": "false",
//																				"nameVal": "true"
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"jaxId": "1H11F89F816",
//																	"attrs": {
//																		"1H0MSV9FC0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H11F89F817",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H11F89F818",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H0MSV9FC0",
//																			"faceTagName": "execOn"
//																		},
//																		"1H16JA01P0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H16JAUVB48",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H16JAUVB49",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H16JA01P0",
//																			"faceTagName": "checkCy"
//																		},
//																		"1H0MT4FFD0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H9FCTHPB54",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H9FCTHPB55",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H0MT4FFD0",
//																			"faceTagName": "execOff"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1H11F89F819",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1H11F89F820",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "box",
//															"jaxId": "1H11F9JHF0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1H11F9JHF1",
//																	"attrs": {
//																		"type": "box",
//																		"id": "BoxChatName",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "\"\"",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[0,0,10,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"background": "[255,255,255,1.00]",
//																		"border": "1",
//																		"borderStyle": "Solid",
//																		"borderColor": "#cfgColor.lineBodyLit",
//																		"corner": "5",
//																		"shadow": "false",
//																		"shadowX": "2",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowSpread": "0",
//																		"shadowColor": "[0,0,0,0.50]",
//																		"contentLayout": "Flex Y"
//																	}
//																},
//																"subHuds": {
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "hud",
//																			"jaxId": "1H11F9JHG0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H11F9JHG1",
//																					"attrs": {
//																						"type": "hud",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "100%",
//																						"h": "16",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "[5,0,0,0]",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": ""
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": [
//																						{
//																							"type": "hudobj",
//																							"def": "text",
//																							"jaxId": "1H11F9JHG2",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H11F9JHG3",
//																									"attrs": {
//																										"type": "text",
//																										"id": "",
//																										"position": "Absolute",
//																										"x": "5",
//																										"y": "0",
//																										"w": "\"\"",
//																										"h": "\"\"",
//																										"anchorH": "Left",
//																										"anchorV": "Top",
//																										"autoLayout": "false",
//																										"display": "On",
//																										"clip": "Off",
//																										"uiEvent": "On",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "",
//																										"zIndex": "0",
//																										"margin": "[0,0,0,0]",
//																										"padding": "",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": "",
//																										"color": "#cfgColor.fontBodySub",
//																										"text": {
//																											"type": "string",
//																											"valText": "实验描述:",
//																											"localize": {
//																												"EN": "Description:",
//																												"CN": "实验描述:"
//																											},
//																											"localizable": true
//																										},
//																										"font": "",
//																										"fontSize": "#txtSize.small",
//																										"bold": "false",
//																										"italic": "false",
//																										"underline": "false",
//																										"alignH": "Left",
//																										"alignV": "Top",
//																										"wrap": "false",
//																										"ellipsis": "false",
//																										"lineClamp": "0",
//																										"select": "false",
//																										"shadow": "false",
//																										"shadowX": "0",
//																										"shadowY": "2",
//																										"shadowBlur": "3",
//																										"shadowColor": "[0,0,0,1.00]",
//																										"shadowEx": "",
//																										"maxTextW": "0",
//																										"autoSizeW": "false",
//																										"autoSizeH": "false"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1H11F9JHG4",
//																									"attrs": {
//																										"1H0MSV9FC0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1H11F9JHG5",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1H11F9JHG6",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H0MSV9FC0",
//																											"faceTagName": "execOn"
//																										},
//																										"1H16JA01P0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1H16JAUVB52",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1H16JAUVB53",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H16JA01P0",
//																											"faceTagName": "checkCy"
//																										},
//																										"1H0MT4FFD0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1H9FCTHPB56",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1H9FCTHPB57",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H0MT4FFD0",
//																											"faceTagName": "execOff"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1H11F9JHG7",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1H11F9JHG8",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "false"
//																							}
//																						}
//																					]
//																				},
//																				"faces": {
//																					"jaxId": "1H11F9JHG9",
//																					"attrs": {
//																						"1H16JA01P0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H16JAUVB56",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H16JAUVB57",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H16JA01P0",
//																							"faceTagName": "checkCy"
//																						},
//																						"1H0MSV9FC0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H9FCTHPB58",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H9FCTHPB59",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MSV9FC0",
//																							"faceTagName": "execOn"
//																						},
//																						"1H0MT4FFD0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H9FCTHPB60",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H9FCTHPB61",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MT4FFD0",
//																							"faceTagName": "execOff"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1H11F9JHG10",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1H11F9JHG11",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "false",
//																				"exposeContainer": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "memo",
//																			"jaxId": "1H11F9JHH0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H11F9JHH1",
//																					"attrs": {
//																						"type": "memo",
//																						"id": "EdChatInfo",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "100%",
//																						"h": "\"\"",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "text",
//																						"zIndex": "0",
//																						"margin": "[3,0,0,0]",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "80",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"text": "",
//																						"color": "[0,0,0]",
//																						"bgColor": "[255,255,255,0.00]",
//																						"font": "",
//																						"fontSize": "#txtSize.smallMid",
//																						"outline": "0",
//																						"border": "0",
//																						"borderStyle": "Solid",
//																						"borderColor": "[0,0,0,1.00]",
//																						"corner": "0",
//																						"readOnly": "false",
//																						"selectOnFocus": "true",
//																						"spellCheck": "true",
//																						"flex": "true"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1H11F9JHH2",
//																					"attrs": {
//																						"1H0MSV9FC0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H11F9JHH3",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H11F9JHH4",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MSV9FC0",
//																							"faceTagName": "execOn"
//																						},
//																						"1H16JA01P0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H16JAUVB60",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H16JAUVB61",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H16JA01P0",
//																							"faceTagName": "checkCy"
//																						},
//																						"1H0MT4FFD0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H9FCTHPB62",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H9FCTHPB63",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MT4FFD0",
//																							"faceTagName": "execOff"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1H11F9JHH5",
//																					"attrs": {
//																						"OnInput": {
//																							"type": "fixedFunc",
//																							"jaxId": "1H11F9JHH6",
//																							"attrs": {
//																								"callArgs": {
//																									"jaxId": "1H11F9JHH7",
//																									"attrs": {}
//																								},
//																								"seg": ""
//																							}
//																						}
//																					}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1H11F9JHH8",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "true",
//																				"container": "false",
//																				"nameVal": "true"
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"jaxId": "1H11F9JHH9",
//																	"attrs": {
//																		"1H0MSV9FC0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H11F9JHH10",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H11F9JHH11",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H0MSV9FC0",
//																			"faceTagName": "execOn"
//																		},
//																		"1H16JA01P0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H16JAUVB64",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H16JAUVB65",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H16JA01P0",
//																			"faceTagName": "checkCy"
//																		},
//																		"1H0MT4FFD0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H9FCTHPB64",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H9FCTHPC0",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H0MT4FFD0",
//																			"faceTagName": "execOff"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1H11F9JHH12",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1H11F9JHH13",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "box",
//															"jaxId": "1H9N9QSP20",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1H9N9QSP21",
//																	"attrs": {
//																		"type": "box",
//																		"id": "BoxGreeting",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "\"\"",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[0,0,10,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"background": "[255,255,255,1.00]",
//																		"border": "1",
//																		"borderStyle": "Solid",
//																		"borderColor": "#cfgColor.lineBodyLit",
//																		"corner": "5",
//																		"shadow": "false",
//																		"shadowX": "2",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowSpread": "0",
//																		"shadowColor": "[0,0,0,0.50]",
//																		"contentLayout": "Flex Y"
//																	}
//																},
//																"subHuds": {
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "hud",
//																			"jaxId": "1H9N9QSP30",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H9N9QSP31",
//																					"attrs": {
//																						"type": "hud",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "100%",
//																						"h": "16",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "[5,0,0,0]",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": ""
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": [
//																						{
//																							"type": "hudobj",
//																							"def": "text",
//																							"jaxId": "1H9N9QSP32",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H9N9QSP33",
//																									"attrs": {
//																										"type": "text",
//																										"id": "",
//																										"position": "Absolute",
//																										"x": "5",
//																										"y": "0",
//																										"w": "\"\"",
//																										"h": "\"\"",
//																										"anchorH": "Left",
//																										"anchorV": "Top",
//																										"autoLayout": "false",
//																										"display": "On",
//																										"clip": "Off",
//																										"uiEvent": "On",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "",
//																										"zIndex": "0",
//																										"margin": "[0,0,0,0]",
//																										"padding": "",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": "",
//																										"color": "#cfgColor.fontBodySub",
//																										"text": {
//																											"type": "string",
//																											"valText": "聊天问候语:",
//																											"localize": {
//																												"EN": "Chat greetings:",
//																												"CN": "聊天问候语:"
//																											},
//																											"localizable": true
//																										},
//																										"font": "",
//																										"fontSize": "#txtSize.small",
//																										"bold": "false",
//																										"italic": "false",
//																										"underline": "false",
//																										"alignH": "Left",
//																										"alignV": "Top",
//																										"wrap": "false",
//																										"ellipsis": "false",
//																										"lineClamp": "0",
//																										"select": "false",
//																										"shadow": "false",
//																										"shadowX": "0",
//																										"shadowY": "2",
//																										"shadowBlur": "3",
//																										"shadowColor": "[0,0,0,1.00]",
//																										"shadowEx": "",
//																										"maxTextW": "0",
//																										"autoSizeW": "false",
//																										"autoSizeH": "false"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1H9N9QSP34",
//																									"attrs": {
//																										"1H0MSV9FC0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1H9N9QSP35",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1H9N9QSP36",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H0MSV9FC0",
//																											"faceTagName": "execOn"
//																										},
//																										"1H16JA01P0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1H9N9QSP37",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1H9N9QSP38",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H16JA01P0",
//																											"faceTagName": "checkCy"
//																										},
//																										"1H0MT4FFD0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1H9N9QSP39",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1H9N9QSP310",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H0MT4FFD0",
//																											"faceTagName": "execOff"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1H9N9QSP311",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1H9N9QSP312",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "false"
//																							}
//																						}
//																					]
//																				},
//																				"faces": {
//																					"jaxId": "1H9N9QSP313",
//																					"attrs": {
//																						"1H16JA01P0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H9N9QSP314",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H9N9QSP315",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H16JA01P0",
//																							"faceTagName": "checkCy"
//																						},
//																						"1H0MSV9FC0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H9N9QSP316",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H9N9QSP317",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MSV9FC0",
//																							"faceTagName": "execOn"
//																						},
//																						"1H0MT4FFD0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H9N9QSP318",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H9N9QSP319",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MT4FFD0",
//																							"faceTagName": "execOff"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1H9N9QSP320",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1H9N9QSP321",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "false",
//																				"exposeContainer": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "memo",
//																			"jaxId": "1H9N9QSP40",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H9N9QSP41",
//																					"attrs": {
//																						"type": "memo",
//																						"id": "EdGreeting",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "100%",
//																						"h": "\"\"",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "text",
//																						"zIndex": "0",
//																						"margin": "[3,0,0,0]",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "50",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"text": "",
//																						"color": "[0,0,0]",
//																						"bgColor": "[255,255,255,0.00]",
//																						"font": "",
//																						"fontSize": "#txtSize.smallMid",
//																						"outline": "0",
//																						"border": "0",
//																						"borderStyle": "Solid",
//																						"borderColor": "[0,0,0,1.00]",
//																						"corner": "0",
//																						"readOnly": "false",
//																						"selectOnFocus": "true",
//																						"spellCheck": "true",
//																						"flex": "true"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1H9N9QSP42",
//																					"attrs": {
//																						"1H0MSV9FC0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H9N9QSP43",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H9N9QSP44",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MSV9FC0",
//																							"faceTagName": "execOn"
//																						},
//																						"1H16JA01P0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H9N9QSP45",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H9N9QSP46",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H16JA01P0",
//																							"faceTagName": "checkCy"
//																						},
//																						"1H0MT4FFD0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H9N9QSP47",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H9N9QSP48",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MT4FFD0",
//																							"faceTagName": "execOff"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1H9N9QSP49",
//																					"attrs": {
//																						"OnInput": {
//																							"type": "fixedFunc",
//																							"jaxId": "1H9N9QSP410",
//																							"attrs": {
//																								"callArgs": {
//																									"jaxId": "1H9N9QSP411",
//																									"attrs": {}
//																								},
//																								"seg": ""
//																							}
//																						}
//																					}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1H9N9QSP412",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "true",
//																				"container": "false",
//																				"nameVal": "true"
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"jaxId": "1H9N9QSP413",
//																	"attrs": {
//																		"1H0MSV9FC0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H9N9QSP414",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H9N9QSP415",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H0MSV9FC0",
//																			"faceTagName": "execOn"
//																		},
//																		"1H16JA01P0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H9N9QSP416",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H9N9QSP417",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H16JA01P0",
//																			"faceTagName": "checkCy"
//																		},
//																		"1H0MT4FFD0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H9N9QSP418",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H9N9QSP419",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H0MT4FFD0",
//																			"faceTagName": "execOff"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1H9N9QSP420",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1H9N9QSP421",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "box",
//															"jaxId": "1H16HHN8C0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1H16HHN8C1",
//																	"attrs": {
//																		"type": "box",
//																		"id": "",
//																		"position": "relative",
//																		"x": "20",
//																		"y": "0",
//																		"w": "100%-40",
//																		"h": "1",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[0,0,5,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"background": "#cfgColor[\"lineBodySub\"]",
//																		"border": "0",
//																		"borderStyle": "Solid",
//																		"borderColor": "[0,0,0,1.00]",
//																		"corner": "0",
//																		"shadow": "false",
//																		"shadowX": "2",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowSpread": "0",
//																		"shadowColor": "[0,0,0,0.50]"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1H16HHN8C2",
//																	"attrs": {
//																		"1H0MSV9FC0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H16HHN8C3",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H16HHN8C4",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H0MSV9FC0",
//																			"faceTagName": "execOn"
//																		},
//																		"1H16JA01P0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H16JAUVB68",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H16JAUVB69",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H16JA01P0",
//																			"faceTagName": "checkCy"
//																		},
//																		"1H0MT4FFD0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H9FCTHPC1",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H9FCTHPC2",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H0MT4FFD0",
//																			"faceTagName": "execOff"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1H16HHN8C5",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1H16HHN8C6",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1H16J4N780",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1H16JAUVB72",
//																	"attrs": {
//																		"type": "hud",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "24",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "hud",
//																			"jaxId": "1H16J5ABC0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H16J5ABC1",
//																					"attrs": {
//																						"type": "hud",
//																						"id": "HudCurrency",
//																						"position": "relative",
//																						"x": "2",
//																						"y": "0",
//																						"w": "100%",
//																						"h": "24",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "[0,0,0,0]",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"contentLayout": "Flex X",
//																						"subAlign": "Center"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": [
//																						{
//																							"type": "hudobj",
//																							"def": "box",
//																							"jaxId": "1H16J5ABC2",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H16J5ABC3",
//																									"attrs": {
//																										"type": "box",
//																										"id": "",
//																										"position": "relative",
//																										"x": "0",
//																										"y": "50%",
//																										"w": "20",
//																										"h": "20",
//																										"anchorH": "Left",
//																										"anchorV": "Center",
//																										"autoLayout": "false",
//																										"display": "${state.userTokens>=0},state",
//																										"clip": "Off",
//																										"uiEvent": "On",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "",
//																										"zIndex": "0",
//																										"margin": "",
//																										"padding": "",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": "",
//																										"background": "#cfgColor.fontBody",
//																										"border": "0",
//																										"borderStyle": "Solid",
//																										"borderColor": "[0,0,0,1.00]",
//																										"corner": "0",
//																										"shadow": "false",
//																										"shadowX": "2",
//																										"shadowY": "2",
//																										"shadowBlur": "3",
//																										"shadowSpread": "0",
//																										"shadowColor": "[0,0,0,0.50]",
//																										"maskImage": "#appCfg.sharedAssets+\"/token.svg\""
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1H16J5ABC4",
//																									"attrs": {
//																										"1H16JA01P0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1H16JAUVB73",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1H16JAUVB74",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H16JA01P0",
//																											"faceTagName": "checkCy"
//																										},
//																										"1H0MSV9FC0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1H9FCTHPC3",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1H9FCTHPC4",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H0MSV9FC0",
//																											"faceTagName": "execOn"
//																										},
//																										"1H0MT4FFD0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1H9FCTHPC5",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1H9FCTHPC6",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H0MT4FFD0",
//																											"faceTagName": "execOff"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1H16J5ABC5",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1H16J5ABC6",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "true",
//																								"nameVal": "false"
//																							}
//																						},
//																						{
//																							"type": "hudobj",
//																							"def": "text",
//																							"jaxId": "1H16J5ABD0",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H16J5ABD1",
//																									"attrs": {
//																										"type": "text",
//																										"id": "TxtTokens",
//																										"position": "relative",
//																										"x": "0",
//																										"y": "0",
//																										"w": "\"\"",
//																										"h": "100%",
//																										"anchorH": "Left",
//																										"anchorV": "Top",
//																										"autoLayout": "false",
//																										"display": "${state.userTokens>=0},state",
//																										"clip": "Off",
//																										"uiEvent": "On",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "",
//																										"zIndex": "0",
//																										"margin": "",
//																										"padding": "",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": "",
//																										"color": "[0,0,0]",
//																										"text": "${state.userTokens>=0?state.userTokens:\"- - -\"},state",
//																										"font": "",
//																										"fontSize": "#txtSize.mid",
//																										"bold": "true",
//																										"italic": "false",
//																										"underline": "false",
//																										"alignH": "Left",
//																										"alignV": "Center",
//																										"wrap": "false",
//																										"ellipsis": "false",
//																										"lineClamp": "0",
//																										"select": "false",
//																										"shadow": "false",
//																										"shadowX": "0",
//																										"shadowY": "2",
//																										"shadowBlur": "3",
//																										"shadowColor": "[0,0,0,1.00]",
//																										"shadowEx": "",
//																										"maxTextW": "0",
//																										"autoSizeW": "false",
//																										"autoSizeH": "false"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1H16J5ABD2",
//																									"attrs": {
//																										"1H16JA01P0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1H16JAUVB77",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1H16JAUVB78",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H16JA01P0",
//																											"faceTagName": "checkCy"
//																										},
//																										"1H0MSV9FC0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1H9FCTHPC7",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1H9FCTHPC8",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H0MSV9FC0",
//																											"faceTagName": "execOn"
//																										},
//																										"1H0MT4FFD0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1H9FCTHPC9",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1H9FCTHPC10",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H0MT4FFD0",
//																											"faceTagName": "execOff"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1H16J5ABD3",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1H16J5ABD4",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "false"
//																							}
//																						},
//																						{
//																							"type": "hudobj",
//																							"def": "box",
//																							"jaxId": "1H16J5ABD5",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H16J5ABD6",
//																									"attrs": {
//																										"type": "box",
//																										"id": "",
//																										"position": "relative",
//																										"x": "0",
//																										"y": "50%",
//																										"w": "20",
//																										"h": "20",
//																										"anchorH": "Left",
//																										"anchorV": "Center",
//																										"autoLayout": "false",
//																										"display": "${state.userTokens>=0},state",
//																										"clip": "Off",
//																										"uiEvent": "On",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "",
//																										"zIndex": "0",
//																										"margin": "[0,0,0,10]",
//																										"padding": "",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": "",
//																										"background": "#cfgColor.fontBody",
//																										"border": "0",
//																										"borderStyle": "Solid",
//																										"borderColor": "[0,0,0,1.00]",
//																										"corner": "0",
//																										"shadow": "false",
//																										"shadowX": "2",
//																										"shadowY": "2",
//																										"shadowBlur": "3",
//																										"shadowSpread": "0",
//																										"shadowColor": "[0,0,0,0.50]",
//																										"maskImage": "#appCfg.sharedAssets+\"/gas.svg\""
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1H16J5ABD7",
//																									"attrs": {
//																										"1H16JA01P0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1H16JAUVB81",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1H16JAUVB82",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H16JA01P0",
//																											"faceTagName": "checkCy"
//																										},
//																										"1H0MSV9FC0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1H9FCTHPC11",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1H9FCTHPC12",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H0MSV9FC0",
//																											"faceTagName": "execOn"
//																										},
//																										"1H0MT4FFD0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1H9FCTHPC13",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1H9FCTHPC14",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H0MT4FFD0",
//																											"faceTagName": "execOff"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1H16J5ABD8",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1H16J5ABD9",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "true",
//																								"nameVal": "false"
//																							}
//																						},
//																						{
//																							"type": "hudobj",
//																							"def": "text",
//																							"jaxId": "1H16J5ABE0",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H16J5ABE1",
//																									"attrs": {
//																										"type": "text",
//																										"id": "TxtGas",
//																										"position": "relative",
//																										"x": "0",
//																										"y": "0",
//																										"w": "\"\"",
//																										"h": "100%",
//																										"anchorH": "Left",
//																										"anchorV": "Top",
//																										"autoLayout": "false",
//																										"display": "${state.userTokens>=0},state",
//																										"clip": "Off",
//																										"uiEvent": "On",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "",
//																										"zIndex": "0",
//																										"margin": "",
//																										"padding": "",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": "",
//																										"color": "[0,0,0]",
//																										"text": "${state.userGas>=0?state.userGas:\"- - -\"},state",
//																										"font": "",
//																										"fontSize": "#txtSize.mid",
//																										"bold": "true",
//																										"italic": "false",
//																										"underline": "false",
//																										"alignH": "Left",
//																										"alignV": "Center",
//																										"wrap": "false",
//																										"ellipsis": "false",
//																										"lineClamp": "0",
//																										"select": "false",
//																										"shadow": "false",
//																										"shadowX": "0",
//																										"shadowY": "2",
//																										"shadowBlur": "3",
//																										"shadowColor": "[0,0,0,1.00]",
//																										"shadowEx": "",
//																										"maxTextW": "0",
//																										"autoSizeW": "false",
//																										"autoSizeH": "false"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1H16J5ABF0",
//																									"attrs": {
//																										"1H16JA01P0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1H16JAUVB85",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1H16JAUVB86",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H16JA01P0",
//																											"faceTagName": "checkCy"
//																										},
//																										"1H0MSV9FC0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1H9FCTHPC15",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1H9FCTHPC16",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H0MSV9FC0",
//																											"faceTagName": "execOn"
//																										},
//																										"1H0MT4FFD0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1H9FCTHPC17",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1H9FCTHPC18",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H0MT4FFD0",
//																											"faceTagName": "execOff"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1H16J5ABF1",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1H16J5ABF2",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "false"
//																							}
//																						},
//																						{
//																							"type": "hudobj",
//																							"def": "text",
//																							"jaxId": "1H16J5ABF3",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H16J5ABF4",
//																									"attrs": {
//																										"type": "text",
//																										"id": "",
//																										"position": "relative",
//																										"x": "0",
//																										"y": "0",
//																										"w": "\"\"",
//																										"h": "100%",
//																										"anchorH": "Left",
//																										"anchorV": "Top",
//																										"autoLayout": "false",
//																										"display": "${state.userTokens>=0?false:true},state",
//																										"clip": "Off",
//																										"uiEvent": "On",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "",
//																										"zIndex": "0",
//																										"margin": "",
//																										"padding": "",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": "",
//																										"color": "#cfgColor.fontBodySub",
//																										"text": {
//																											"type": "string",
//																											"valText": "请登录Tab-OS",
//																											"localize": {
//																												"EN": "Please login Tab-OS",
//																												"CN": "请登录Tab-OS"
//																											},
//																											"localizable": true
//																										},
//																										"font": "",
//																										"fontSize": "#txtSize.smallMid",
//																										"bold": "false",
//																										"italic": "false",
//																										"underline": "false",
//																										"alignH": "Left",
//																										"alignV": "Center",
//																										"wrap": "false",
//																										"ellipsis": "false",
//																										"lineClamp": "0",
//																										"select": "false",
//																										"shadow": "false",
//																										"shadowX": "0",
//																										"shadowY": "2",
//																										"shadowBlur": "3",
//																										"shadowColor": "[0,0,0,1.00]",
//																										"shadowEx": "",
//																										"maxTextW": "0",
//																										"autoSizeW": "false",
//																										"autoSizeH": "false"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1H16J5ABF5",
//																									"attrs": {
//																										"1H16JA01P0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1H16JAUVB89",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1H16JAUVB90",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H16JA01P0",
//																											"faceTagName": "checkCy"
//																										},
//																										"1H0MSV9FC0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1H9FCTHPC19",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1H9FCTHPC20",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H0MSV9FC0",
//																											"faceTagName": "execOn"
//																										},
//																										"1H0MT4FFD0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1H9FCTHPC21",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1H9FCTHPC22",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H0MT4FFD0",
//																											"faceTagName": "execOff"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1H16J5ABF6",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1H16J5ABF7",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "false"
//																							}
//																						}
//																					]
//																				},
//																				"faces": {
//																					"jaxId": "1H16J5ABF8",
//																					"attrs": {
//																						"1H16JA01P0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H16JAUVB93",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H16JAUVB94",
//																									"attrs": {
//																										"display": {
//																											"type": "choice",
//																											"valText": "Off"
//																										}
//																									}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H16JA01P0",
//																							"faceTagName": "checkCy"
//																						},
//																						"1H16JAIMO0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H16JAUVB95",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H16JAUVB96",
//																									"attrs": {
//																										"display": {
//																											"type": "choice",
//																											"valText": "On"
//																										}
//																									}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H16JAIMO0",
//																							"faceTagName": "showCy"
//																						},
//																						"1H0MSV9FC0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H9FCTHPC23",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H9FCTHPC24",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MSV9FC0",
//																							"faceTagName": "execOn"
//																						},
//																						"1H0MT4FFD0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H9FCTHPC25",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H9FCTHPC26",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MT4FFD0",
//																							"faceTagName": "execOff"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1H16J5ABF9",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1H16J5ABF10",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "false",
//																				"exposeContainer": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "text",
//																			"jaxId": "1H16J7MSR0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H16JAUVB97",
//																					"attrs": {
//																						"type": "text",
//																						"id": "",
//																						"position": "Absolute",
//																						"x": "0",
//																						"y": "1",
//																						"w": "100%",
//																						"h": "100%",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "Off",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"color": "#cfgColor.fontBodySub",
//																						"text": "Checking account...",
//																						"font": "",
//																						"fontSize": "#txtSize.smallMid",
//																						"bold": "false",
//																						"italic": "false",
//																						"underline": "false",
//																						"alignH": "Center",
//																						"alignV": "Center",
//																						"wrap": "false",
//																						"ellipsis": "false",
//																						"lineClamp": "0",
//																						"select": "false",
//																						"shadow": "false",
//																						"shadowX": "0",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowColor": "[0,0,0,1.00]",
//																						"shadowEx": "",
//																						"maxTextW": "0",
//																						"autoSizeW": "false",
//																						"autoSizeH": "false"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1H16JAUVB98",
//																					"attrs": {
//																						"1H16JA01P0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H16JAUVB99",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H16JAUVB100",
//																									"attrs": {
//																										"display": {
//																											"type": "choice",
//																											"valText": "On"
//																										}
//																									}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H16JA01P0",
//																							"faceTagName": "checkCy"
//																						},
//																						"1H16JAIMO0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H16JAUVB101",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H16JAUVB102",
//																									"attrs": {
//																										"display": {
//																											"type": "choice",
//																											"valText": "Off"
//																										}
//																									}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H16JAIMO0",
//																							"faceTagName": "showCy"
//																						},
//																						"1H0MSV9FC0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H9FCTHPC27",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H9FCTHPC28",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MSV9FC0",
//																							"faceTagName": "execOn"
//																						},
//																						"1H0MT4FFD0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H9FCTHPC29",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H9FCTHPC30",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MT4FFD0",
//																							"faceTagName": "execOff"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1H16JAUVB103",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1H16JAUVB104",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false"
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"jaxId": "1H16JAUVB105",
//																	"attrs": {
//																		"1H16JA01P0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H16JAUVB106",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H16JAUVB107",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H16JA01P0",
//																			"faceTagName": "checkCy"
//																		},
//																		"1H0MSV9FC0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H9FCTHPC31",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H9FCTHPC32",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H0MSV9FC0",
//																			"faceTagName": "execOn"
//																		},
//																		"1H0MT4FFD0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H9FCTHPC33",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H9FCTHPC34",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H0MT4FFD0",
//																			"faceTagName": "execOff"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1H16JAUVB110",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1H16JAUVB111",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false",
//																"exposeContainer": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnText.js",
//															"jaxId": "1H1917UFF0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1H191AL2E0",
//																	"attrs": {
//																		"style": "",
//																		"w": "120",
//																		"h": "24",
//																		"text": {
//																			"type": "string",
//																			"valText": "测试聊天",
//																			"localize": {
//																				"EN": "Test Chat",
//																				"CN": "测试聊天"
//																			},
//																			"localizable": true
//																		},
//																		"outlined": "false",
//																		"icon": ""
//																	}
//																},
//																"properties": {
//																	"jaxId": "1H191AL2E1",
//																	"attrs": {
//																		"type": "#null#>BtnText(\"\",120,24,(($ln===\"CN\")?(\"测试聊天\"):(\"Test Chat\")),false,\"\")",
//																		"id": "",
//																		"position": "relative",
//																		"x": "50%",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"anchorH": "Center",
//																		"margin": "[5,0,0,0]",
//																		"corner": "3"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1H191AL2E2",
//																	"attrs": {
//																		"1H0MSV9FC0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H9FCTHPC35",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H9FCTHPC36",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H0MSV9FC0",
//																			"faceTagName": "execOn"
//																		},
//																		"1H0MT4FFD0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H9FCTHPC37",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H9FCTHPC38",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H0MT4FFD0",
//																			"faceTagName": "execOff"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1H191AL2E3",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1H191AE770",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1H191AL2E4",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1H191AL2E5",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1H7A209585",
//																	"attrs": {
//																		"Slot1H2F6U36O0": {
//																			"jaxId": "1IA2I3ORO0",
//																			"attrs": {
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"container": "true"
//																			}
//																		}
//																	}
//																}
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1H04SO18D11",
//													"attrs": {
//														"1H0MSV9FC0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H0MT60MB90",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1H0MT60MB91",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H0MSV9FC0",
//															"faceTagName": "execOn"
//														},
//														"1H16JA01P0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H16JAUVC0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1H16JAUVC1",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H16JA01P0",
//															"faceTagName": "checkCy"
//														},
//														"1H0MT4FFD0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H9FCTHPC39",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1H9FCTHPC40",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H0MT4FFD0",
//															"faceTagName": "execOff"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1H04SO18D12",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1H04SO18D13",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1H04SO18D14",
//									"attrs": {
//										"1H0MSV9FC0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H0MT60MB94",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H0MT60MB95",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H0MSV9FC0",
//											"faceTagName": "execOn"
//										},
//										"1H16JA01P0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H16JAUVC4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H16JAUVC5",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H16JA01P0",
//											"faceTagName": "checkCy"
//										},
//										"1H0MT4FFD0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H9FCTHPC41",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H9FCTHPC42",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H0MT4FFD0",
//											"faceTagName": "execOff"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1H04SO18D15",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H04SO18D16",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1H04QKV440",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H04SO18D17",
//									"attrs": {
//										"type": "hud",
//										"id": "HudChatFrame",
//										"position": "Absolute",
//										"x": "${260},state",
//										"y": "0",
//										"w": "${`FW-260`},state",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "true",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "[0,0,0,10]",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex Y"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1H04T7CG70",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H04VDE1U0",
//													"attrs": {
//														"type": "hud",
//														"id": "HudChats",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "100",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Scroll Y",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "[10,0,0,0]",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"flex": "true",
//														"contentLayout": "Flex Y"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "box",
//															"jaxId": "1H0MMDTKF0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1H0MMDTKF1",
//																	"attrs": {
//																		"type": "box",
//																		"id": "BoxSysMsg",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%-10",
//																		"h": "\"\"",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[0,0,10,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"background": "[255,255,255,1.00]",
//																		"border": "1",
//																		"borderStyle": "Solid",
//																		"borderColor": "#cfgColor.lineBodyLit",
//																		"corner": "5",
//																		"shadow": "false",
//																		"shadowX": "2",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowSpread": "0",
//																		"shadowColor": "[0,0,0,0.50]",
//																		"contentLayout": "Flex Y"
//																	}
//																},
//																"subHuds": {
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "hud",
//																			"jaxId": "1H0PAE2690",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H0PAKVOQ0",
//																					"attrs": {
//																						"type": "hud",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "100%",
//																						"h": "16",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "[5,0,0,0]",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": ""
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": [
//																						{
//																							"type": "hudobj",
//																							"def": "text",
//																							"jaxId": "1H0PAF0L80",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H0PAF0L81",
//																									"attrs": {
//																										"type": "text",
//																										"id": "",
//																										"position": "Absolute",
//																										"x": "5",
//																										"y": "0",
//																										"w": "100",
//																										"h": "\"\"",
//																										"anchorH": "Left",
//																										"anchorV": "Top",
//																										"autoLayout": "false",
//																										"display": "On",
//																										"clip": "Off",
//																										"uiEvent": "On",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "",
//																										"zIndex": "0",
//																										"margin": "[0,0,0,0]",
//																										"padding": "",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": "",
//																										"color": "#cfgColor.fontBodySub",
//																										"text": {
//																											"type": "string",
//																											"valText": "系统设定消息",
//																											"localize": {
//																												"EN": "SYSTEM Message:",
//																												"CN": "系统设定消息"
//																											},
//																											"localizable": true
//																										},
//																										"font": "",
//																										"fontSize": "#txtSize.small",
//																										"bold": "false",
//																										"italic": "false",
//																										"underline": "false",
//																										"alignH": "Left",
//																										"alignV": "Top",
//																										"wrap": "false",
//																										"ellipsis": "false",
//																										"lineClamp": "0",
//																										"select": "false",
//																										"shadow": "false",
//																										"shadowX": "0",
//																										"shadowY": "2",
//																										"shadowBlur": "3",
//																										"shadowColor": "[0,0,0,1.00]",
//																										"shadowEx": "",
//																										"maxTextW": "0",
//																										"autoSizeW": "false",
//																										"autoSizeH": "false"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1H0PAF0L82",
//																									"attrs": {
//																										"1H0MSV9FC0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1H0PAF0L83",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1H0PAF0L84",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H0MSV9FC0",
//																											"faceTagName": "execOn"
//																										},
//																										"1H16JA01P0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1H16JAUVC8",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1H16JAUVC9",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H16JA01P0",
//																											"faceTagName": "checkCy"
//																										},
//																										"1H0MT4FFD0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1H9FCTHPC43",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1H9FCTHPC44",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H0MT4FFD0",
//																											"faceTagName": "execOff"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1H0PAF0L85",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1H0PAF0L86",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "false"
//																							}
//																						},
//																						{
//																							"type": "hudobj",
//																							"def": "text",
//																							"jaxId": "1H0PAIFP80",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H0PAIFP81",
//																									"attrs": {
//																										"type": "text",
//																										"id": "TxtSysTokens",
//																										"position": "Absolute",
//																										"x": "5",
//																										"y": "0",
//																										"w": "100%-10",
//																										"h": "\"\"",
//																										"anchorH": "Left",
//																										"anchorV": "Top",
//																										"autoLayout": "false",
//																										"display": "On",
//																										"clip": "Off",
//																										"uiEvent": "On",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "",
//																										"zIndex": "0",
//																										"margin": "[0,0,0,0]",
//																										"padding": "",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": "",
//																										"color": "#cfgColor.fontBodyLit",
//																										"text": "Tokens: - - -",
//																										"font": "",
//																										"fontSize": "#txtSize.small",
//																										"bold": "false",
//																										"italic": "false",
//																										"underline": "false",
//																										"alignH": "Right",
//																										"alignV": "Top",
//																										"wrap": "false",
//																										"ellipsis": "false",
//																										"lineClamp": "0",
//																										"select": "false",
//																										"shadow": "false",
//																										"shadowX": "0",
//																										"shadowY": "2",
//																										"shadowBlur": "3",
//																										"shadowColor": "[0,0,0,1.00]",
//																										"shadowEx": "",
//																										"maxTextW": "0",
//																										"autoSizeW": "false",
//																										"autoSizeH": "false"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1H0PAIFP82",
//																									"attrs": {
//																										"1H0MSV9FC0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1H0PAIFP83",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1H0PAIFP84",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H0MSV9FC0",
//																											"faceTagName": "execOn"
//																										},
//																										"1H16JA01P0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1H16JAUVC12",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1H16JAUVC13",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H16JA01P0",
//																											"faceTagName": "checkCy"
//																										},
//																										"1H0MT4FFD0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1H9FCTHPC45",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1H9FCTHPC46",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H0MT4FFD0",
//																											"faceTagName": "execOff"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1H0PAIFP85",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1H0PAIFP86",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "true"
//																							}
//																						}
//																					]
//																				},
//																				"faces": {
//																					"jaxId": "1H0PAKVOQ1",
//																					"attrs": {
//																						"1H16JA01P0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H16JAUVC16",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H16JAUVC17",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H16JA01P0",
//																							"faceTagName": "checkCy"
//																						},
//																						"1H0MSV9FC0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H9FCTHPC47",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H9FCTHPC48",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MSV9FC0",
//																							"faceTagName": "execOn"
//																						},
//																						"1H0MT4FFD0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H9FCTHPC49",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H9FCTHPC50",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MT4FFD0",
//																							"faceTagName": "execOff"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1H0PAKVOQ2",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1H0PAKVOQ3",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "false",
//																				"exposeContainer": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "memo",
//																			"jaxId": "1H0MMDTKG5",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H0MMDTKG6",
//																					"attrs": {
//																						"type": "memo",
//																						"id": "EdSysMsg",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "100%",
//																						"h": "\"\"",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "text",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "50",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"text": "You are a smart AI assistant.",
//																						"color": "[0,0,0]",
//																						"bgColor": "[255,255,255,0.00]",
//																						"font": "",
//																						"fontSize": "#txtSize.smallMid",
//																						"outline": "0",
//																						"border": "0",
//																						"borderStyle": "Solid",
//																						"borderColor": "[0,0,0,1.00]",
//																						"corner": "0",
//																						"readOnly": "false",
//																						"selectOnFocus": "true",
//																						"spellCheck": "true",
//																						"flex": "true"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1H0MMDTKG7",
//																					"attrs": {
//																						"1H0MSV9FC0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H0MT60MB102",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H0MT60MB103",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MSV9FC0",
//																							"faceTagName": "execOn"
//																						},
//																						"1H16JA01P0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H16JAUVC20",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H16JAUVC21",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H16JA01P0",
//																							"faceTagName": "checkCy"
//																						},
//																						"1H0MT4FFD0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H9FCTHPC51",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H9FCTHPC52",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MT4FFD0",
//																							"faceTagName": "execOff"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1H0MMDTKG8",
//																					"attrs": {
//																						"OnInput": {
//																							"type": "fixedFunc",
//																							"jaxId": "1H0MMDTKG9",
//																							"attrs": {
//																								"callArgs": {
//																									"jaxId": "1H0MMDTKG10",
//																									"attrs": {}
//																								},
//																								"seg": ""
//																							}
//																						}
//																					}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1H0MMDTKG11",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "true",
//																				"container": "false",
//																				"nameVal": "true"
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"jaxId": "1H0MMDTKG12",
//																	"attrs": {
//																		"1H0MSV9FC0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H0MT60MB106",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H0MT60MB107",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H0MSV9FC0",
//																			"faceTagName": "execOn"
//																		},
//																		"1H16JA01P0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H16JAUVC24",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H16JAUVC25",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H16JA01P0",
//																			"faceTagName": "checkCy"
//																		},
//																		"1H0MT4FFD0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H9FCTHPC53",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H9FCTHPC54",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H0MT4FFD0",
//																			"faceTagName": "execOff"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1H0MMDTKG13",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1H0MMDTKG14",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "box",
//															"jaxId": "1H11ECO5T0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1H11ECO5T1",
//																	"attrs": {
//																		"type": "box",
//																		"id": "BoxPrefix",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%-10",
//																		"h": "\"\"",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[0,0,10,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"background": "[255,255,255,1.00]",
//																		"border": "1",
//																		"borderStyle": "Solid",
//																		"borderColor": "#cfgColor.lineBodyLit",
//																		"corner": "5",
//																		"shadow": "false",
//																		"shadowX": "2",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowSpread": "0",
//																		"shadowColor": "[0,0,0,0.50]",
//																		"contentLayout": "Flex Y"
//																	}
//																},
//																"subHuds": {
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "hud",
//																			"jaxId": "1H11ECO5T2",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H11ECO5T3",
//																					"attrs": {
//																						"type": "hud",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "100%",
//																						"h": "16",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "[5,0,0,0]",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": ""
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": [
//																						{
//																							"type": "hudobj",
//																							"def": "text",
//																							"jaxId": "1H11ECO5U0",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H11ECO5U1",
//																									"attrs": {
//																										"type": "text",
//																										"id": "",
//																										"position": "Absolute",
//																										"x": "5",
//																										"y": "0",
//																										"w": "\"\"",
//																										"h": "\"\"",
//																										"anchorH": "Left",
//																										"anchorV": "Top",
//																										"autoLayout": "false",
//																										"display": "On",
//																										"clip": "Off",
//																										"uiEvent": "On",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "",
//																										"zIndex": "0",
//																										"margin": "[0,0,0,0]",
//																										"padding": "",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": "",
//																										"color": "#cfgColor.fontBodySub",
//																										"text": {
//																											"type": "string",
//																											"valText": "用户消息前置修饰",
//																											"localize": {
//																												"EN": "User Message Prefix:",
//																												"CN": "用户消息前置修饰"
//																											},
//																											"localizable": true
//																										},
//																										"font": "",
//																										"fontSize": "#txtSize.small",
//																										"bold": "false",
//																										"italic": "false",
//																										"underline": "false",
//																										"alignH": "Left",
//																										"alignV": "Top",
//																										"wrap": "false",
//																										"ellipsis": "false",
//																										"lineClamp": "0",
//																										"select": "false",
//																										"shadow": "false",
//																										"shadowX": "0",
//																										"shadowY": "2",
//																										"shadowBlur": "3",
//																										"shadowColor": "[0,0,0,1.00]",
//																										"shadowEx": "",
//																										"maxTextW": "0",
//																										"autoSizeW": "false",
//																										"autoSizeH": "false"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1H11ECO5U2",
//																									"attrs": {
//																										"1H0MSV9FC0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1H11ECO5U3",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1H11ECO5U4",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H0MSV9FC0",
//																											"faceTagName": "execOn"
//																										},
//																										"1H16JA01P0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1H16JAUVC28",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1H16JAUVC29",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H16JA01P0",
//																											"faceTagName": "checkCy"
//																										},
//																										"1H0MT4FFD0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1H9FCTHPC55",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1H9FCTHPC56",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H0MT4FFD0",
//																											"faceTagName": "execOff"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1H11ECO5U5",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1H11ECO5U6",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "false"
//																							}
//																						}
//																					]
//																				},
//																				"faces": {
//																					"jaxId": "1H11ECO5V4",
//																					"attrs": {
//																						"1H16JA01P0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H16JAUVC32",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H16JAUVC33",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H16JA01P0",
//																							"faceTagName": "checkCy"
//																						},
//																						"1H0MSV9FC0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H9FCTHPC57",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H9FCTHPC58",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MSV9FC0",
//																							"faceTagName": "execOn"
//																						},
//																						"1H0MT4FFD0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H9FCTHPC59",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H9FCTHPC60",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MT4FFD0",
//																							"faceTagName": "execOff"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1H11ECO5V5",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1H11ECO5V6",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "false",
//																				"exposeContainer": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "memo",
//																			"jaxId": "1H11ECO5V7",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H11ECO5V8",
//																					"attrs": {
//																						"type": "memo",
//																						"id": "EdPrefix",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "100%",
//																						"h": "\"\"",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "text",
//																						"zIndex": "0",
//																						"margin": "[3,0,0,0]",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "20",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"text": "",
//																						"color": "[0,0,0]",
//																						"bgColor": "[255,255,255,0.00]",
//																						"font": "",
//																						"fontSize": "#txtSize.smallMid",
//																						"outline": "0",
//																						"border": "0",
//																						"borderStyle": "Solid",
//																						"borderColor": "[0,0,0,1.00]",
//																						"corner": "0",
//																						"readOnly": "false",
//																						"selectOnFocus": "true",
//																						"spellCheck": "true",
//																						"flex": "true"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1H11ECO5V9",
//																					"attrs": {
//																						"1H0MSV9FC0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H11ECO5V10",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H11ECO5V11",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MSV9FC0",
//																							"faceTagName": "execOn"
//																						},
//																						"1H16JA01P0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H16JAUVC36",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H16JAUVC37",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H16JA01P0",
//																							"faceTagName": "checkCy"
//																						},
//																						"1H0MT4FFD0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H9FCTHPC61",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H9FCTHPC62",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MT4FFD0",
//																							"faceTagName": "execOff"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1H11ECO5V12",
//																					"attrs": {
//																						"OnInput": {
//																							"type": "fixedFunc",
//																							"jaxId": "1H11ECO5V13",
//																							"attrs": {
//																								"callArgs": {
//																									"jaxId": "1H11ECO5V14",
//																									"attrs": {}
//																								},
//																								"seg": ""
//																							}
//																						}
//																					}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1H11ECO5V15",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "true",
//																				"container": "false",
//																				"nameVal": "true"
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"jaxId": "1H11ECO5V16",
//																	"attrs": {
//																		"1H0MSV9FC0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H11ECO5V17",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H11ECO5V18",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H0MSV9FC0",
//																			"faceTagName": "execOn"
//																		},
//																		"1H16JA01P0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H16JAUVC40",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H16JAUVC41",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H16JA01P0",
//																			"faceTagName": "checkCy"
//																		},
//																		"1H0MT4FFD0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H9FCTHPC63",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H9FCTHPC64",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H0MT4FFD0",
//																			"faceTagName": "execOff"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1H11ECO5V19",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1H11ECO5V20",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "box",
//															"jaxId": "1H11ELLUF0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1H11ELLUF1",
//																	"attrs": {
//																		"type": "box",
//																		"id": "BoxPostfix",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%-10",
//																		"h": "\"\"",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[0,0,10,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"background": "[255,255,255,1.00]",
//																		"border": "1",
//																		"borderStyle": "Solid",
//																		"borderColor": "#cfgColor.lineBodyLit",
//																		"corner": "5",
//																		"shadow": "false",
//																		"shadowX": "2",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowSpread": "0",
//																		"shadowColor": "[0,0,0,0.50]",
//																		"contentLayout": "Flex Y"
//																	}
//																},
//																"subHuds": {
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "hud",
//																			"jaxId": "1H11ELLUG0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H11ELLUG1",
//																					"attrs": {
//																						"type": "hud",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "100%",
//																						"h": "16",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "[5,0,0,0]",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": ""
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": [
//																						{
//																							"type": "hudobj",
//																							"def": "text",
//																							"jaxId": "1H11ELLUG2",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H11ELLUG3",
//																									"attrs": {
//																										"type": "text",
//																										"id": "",
//																										"position": "Absolute",
//																										"x": "5",
//																										"y": "0",
//																										"w": "\"\"",
//																										"h": "\"\"",
//																										"anchorH": "Left",
//																										"anchorV": "Top",
//																										"autoLayout": "false",
//																										"display": "On",
//																										"clip": "Off",
//																										"uiEvent": "On",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "",
//																										"zIndex": "0",
//																										"margin": "[0,0,0,0]",
//																										"padding": "",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": "",
//																										"color": "#cfgColor.fontBodySub",
//																										"text": {
//																											"type": "string",
//																											"valText": "用户消息后置修饰",
//																											"localize": {
//																												"EN": "User Message Postfix:",
//																												"CN": "用户消息后置修饰"
//																											},
//																											"localizable": true
//																										},
//																										"font": "",
//																										"fontSize": "#txtSize.small",
//																										"bold": "false",
//																										"italic": "false",
//																										"underline": "false",
//																										"alignH": "Left",
//																										"alignV": "Top",
//																										"wrap": "false",
//																										"ellipsis": "false",
//																										"lineClamp": "0",
//																										"select": "false",
//																										"shadow": "false",
//																										"shadowX": "0",
//																										"shadowY": "2",
//																										"shadowBlur": "3",
//																										"shadowColor": "[0,0,0,1.00]",
//																										"shadowEx": "",
//																										"maxTextW": "0",
//																										"autoSizeW": "false",
//																										"autoSizeH": "false"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1H11ELLUH0",
//																									"attrs": {
//																										"1H0MSV9FC0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1H11ELLUH1",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1H11ELLUH2",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H0MSV9FC0",
//																											"faceTagName": "execOn"
//																										},
//																										"1H16JA01P0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1H16JAUVC44",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1H16JAUVC45",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H16JA01P0",
//																											"faceTagName": "checkCy"
//																										},
//																										"1H0MT4FFD0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1H9FCTHPC65",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1H9FCTHPC66",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H0MT4FFD0",
//																											"faceTagName": "execOff"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1H11ELLUH3",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1H11ELLUH4",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "false"
//																							}
//																						}
//																					]
//																				},
//																				"faces": {
//																					"jaxId": "1H11ELLUH5",
//																					"attrs": {
//																						"1H16JA01P0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H16JAUVC48",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H16JAUVC49",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H16JA01P0",
//																							"faceTagName": "checkCy"
//																						},
//																						"1H0MSV9FC0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H9FCTHPC67",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H9FCTHPC68",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MSV9FC0",
//																							"faceTagName": "execOn"
//																						},
//																						"1H0MT4FFD0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H9FCTHPC69",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H9FCTHPC70",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MT4FFD0",
//																							"faceTagName": "execOff"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1H11ELLUH6",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1H11ELLUH7",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "false",
//																				"exposeContainer": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "memo",
//																			"jaxId": "1H11ELLUH8",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H11ELLUH9",
//																					"attrs": {
//																						"type": "memo",
//																						"id": "EdPostfix",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "100%",
//																						"h": "\"\"",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "text",
//																						"zIndex": "0",
//																						"margin": "[3,0,0,0]",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "20",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"text": "",
//																						"color": "[0,0,0]",
//																						"bgColor": "[255,255,255,0.00]",
//																						"font": "",
//																						"fontSize": "#txtSize.smallMid",
//																						"outline": "0",
//																						"border": "0",
//																						"borderStyle": "Solid",
//																						"borderColor": "[0,0,0,1.00]",
//																						"corner": "0",
//																						"readOnly": "false",
//																						"selectOnFocus": "true",
//																						"spellCheck": "true",
//																						"flex": "true"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1H11ELLUI0",
//																					"attrs": {
//																						"1H0MSV9FC0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H11ELLUI1",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H11ELLUI2",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MSV9FC0",
//																							"faceTagName": "execOn"
//																						},
//																						"1H16JA01P0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H16JAUVC52",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H16JAUVC53",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H16JA01P0",
//																							"faceTagName": "checkCy"
//																						},
//																						"1H0MT4FFD0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H9FCTHPC71",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H9FCTHPC72",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MT4FFD0",
//																							"faceTagName": "execOff"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1H11ELLUI3",
//																					"attrs": {
//																						"OnInput": {
//																							"type": "fixedFunc",
//																							"jaxId": "1H11ELLUI4",
//																							"attrs": {
//																								"callArgs": {
//																									"jaxId": "1H11ELLUI5",
//																									"attrs": {}
//																								},
//																								"seg": ""
//																							}
//																						}
//																					}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1H11ELLUI6",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "true",
//																				"container": "false",
//																				"nameVal": "true"
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"jaxId": "1H11ELLUI7",
//																	"attrs": {
//																		"1H0MSV9FC0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H11ELLUI8",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H11ELLUI9",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H0MSV9FC0",
//																			"faceTagName": "execOn"
//																		},
//																		"1H16JA01P0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H16JAUVC56",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H16JAUVC57",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H16JA01P0",
//																			"faceTagName": "checkCy"
//																		},
//																		"1H0MT4FFD0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H9FCTHPC73",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H9FCTHPC74",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H0MT4FFD0",
//																			"faceTagName": "execOff"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1H11ELLUI10",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1H11ELLUI11",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1H05RG23B0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1H05RMDIQ0",
//																	"attrs": {
//																		"type": "hud",
//																		"id": "HudMsgList",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "\"\"",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1H05RMDIQ1",
//																	"attrs": {
//																		"1H0MSV9FC0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H0MT60MB108",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H0MT60MB109",
//																					"attrs": {
//																						"uiEvent": {
//																							"type": "choice",
//																							"valText": "Tree Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H0MSV9FC0",
//																			"faceTagName": "execOn"
//																		},
//																		"1H0MT4FFD0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H0MT60MB110",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H0MT60MB111",
//																					"attrs": {
//																						"uiEvent": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H0MT4FFD0",
//																			"faceTagName": "execOff"
//																		},
//																		"1H16JA01P0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H16JAUVC60",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H16JAUVC61",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H16JA01P0",
//																			"faceTagName": "checkCy"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1H05RMDIQ2",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1H05RMDIQ3",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "true",
//																"exposeContainer": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1H05RHVTF0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1H05RMDIQ4",
//																	"attrs": {
//																		"type": "hud",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "30",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[5,0,0,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "text",
//																			"jaxId": "1H0PEN8IJ0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H0PEN8IJ1",
//																					"attrs": {
//																						"type": "text",
//																						"id": "TxtAllTokens",
//																						"position": "Absolute",
//																						"x": "5",
//																						"y": "0",
//																						"w": "100%-20",
//																						"h": "\"\"",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "[0,0,0,0]",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"color": "#cfgColor.fontBodyLit",
//																						"text": "- - -",
//																						"font": "",
//																						"fontSize": "#txtSize.small",
//																						"bold": "false",
//																						"italic": "false",
//																						"underline": "false",
//																						"alignH": "Right",
//																						"alignV": "Top",
//																						"wrap": "false",
//																						"ellipsis": "false",
//																						"lineClamp": "0",
//																						"select": "false",
//																						"shadow": "false",
//																						"shadowX": "0",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowColor": "[0,0,0,1.00]",
//																						"shadowEx": "",
//																						"maxTextW": "0",
//																						"autoSizeW": "false",
//																						"autoSizeH": "false"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1H0PEN8IK0",
//																					"attrs": {
//																						"1H0MSV9FC0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H0PEN8IK1",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H0PEN8IK2",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MSV9FC0",
//																							"faceTagName": "execOn"
//																						},
//																						"1H16JA01P0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H16JAUVC64",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H16JAUVC65",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H16JA01P0",
//																							"faceTagName": "checkCy"
//																						},
//																						"1H0MT4FFD0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H9FCTHPC75",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H9FCTHPC76",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MT4FFD0",
//																							"faceTagName": "execOff"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1H0PEN8IK3",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1H0PEN8IK4",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "true"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "Gear/@StdUI/ui/BtnIcon.js",
//																			"jaxId": "1H05RIBSV0",
//																			"attrs": {
//																				"createArgs": {
//																					"jaxId": "1H05RMDIQ5",
//																					"attrs": {
//																						"style": "front",
//																						"w": "30",
//																						"h": "0",
//																						"icon": "#appCfg.sharedAssets+\"/additem.svg\"",
//																						"colorBG": "null"
//																					}
//																				},
//																				"properties": {
//																					"jaxId": "1H05RMDIQ6",
//																					"attrs": {
//																						"type": "#null#>BtnIcon(\"front\",30,0,appCfg.sharedAssets+\"/additem.svg\",null)",
//																						"id": "",
//																						"position": "Absolute",
//																						"x": "5",
//																						"y": "0",
//																						"display": "On",
//																						"face": "",
//																						"padding": "1"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1H05RMDIQ7",
//																					"attrs": {
//																						"1H0MSV9FC0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H0MT60MB112",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H0MT60MB113",
//																									"attrs": {
//																										"enable": {
//																											"type": "bool",
//																											"valText": "false"
//																										}
//																									}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MSV9FC0",
//																							"faceTagName": "execOn"
//																						},
//																						"1H0MT4FFD0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H0MT60MB114",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H0MT60MB115",
//																									"attrs": {
//																										"enable": {
//																											"type": "bool",
//																											"valText": "true"
//																										}
//																									}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MT4FFD0",
//																							"faceTagName": "execOff"
//																						},
//																						"1H16JA01P0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H16JAUVC68",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H16JAUVC69",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H16JA01P0",
//																							"faceTagName": "checkCy"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1H05RMDIQ8",
//																					"attrs": {
//																						"OnClick": {
//																							"type": "fixedFunc",
//																							"jaxId": "1H07BJ9M80",
//																							"attrs": {
//																								"callArgs": {
//																									"jaxId": "1H07BJIE10",
//																									"attrs": {
//																										"event": ""
//																									}
//																								},
//																								"seg": ""
//																							}
//																						}
//																					}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1H05RMDIQ9",
//																					"attrs": {
//																						"tip": {
//																							"type": "string",
//																							"valText": "添加消息",
//																							"localize": {
//																								"EN": "Add message",
//																								"CN": "添加消息"
//																							},
//																							"localizable": true
//																						}
//																					}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false",
//																				"containerSlots": {
//																					"jaxId": "1H7A209590",
//																					"attrs": {}
//																				}
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "Gear/@StdUI/ui/BtnIcon.js",
//																			"jaxId": "1H0MO0P380",
//																			"attrs": {
//																				"createArgs": {
//																					"jaxId": "1H0MO0P381",
//																					"attrs": {
//																						"style": "front",
//																						"w": "30",
//																						"h": "0",
//																						"icon": "#appCfg.sharedAssets+\"/gas.svg\"",
//																						"colorBG": "null"
//																					}
//																				},
//																				"properties": {
//																					"jaxId": "1H0MO0P382",
//																					"attrs": {
//																						"type": "#null#>BtnIcon(\"front\",30,0,appCfg.sharedAssets+\"/gas.svg\",null)",
//																						"id": "BtnCalTokens",
//																						"position": "Absolute",
//																						"x": "35",
//																						"y": "0",
//																						"display": "Off",
//																						"face": "",
//																						"padding": "2"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1H0MO0P383",
//																					"attrs": {
//																						"1H0MSV9FC0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H0MT60MB116",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H0MT60MB117",
//																									"attrs": {
//																										"enable": {
//																											"type": "bool",
//																											"valText": "false"
//																										}
//																									}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MSV9FC0",
//																							"faceTagName": "execOn"
//																						},
//																						"1H0MT4FFD0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H0MT60MB118",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H0MT60MB119",
//																									"attrs": {
//																										"enable": {
//																											"type": "bool",
//																											"valText": "true"
//																										}
//																									}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MT4FFD0",
//																							"faceTagName": "execOff"
//																						},
//																						"1H16JA01P0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H16JAUVC72",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H16JAUVC73",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H16JA01P0",
//																							"faceTagName": "checkCy"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1H0MO0P384",
//																					"attrs": {
//																						"OnClick": {
//																							"type": "fixedFunc",
//																							"jaxId": "1H0MO0P385",
//																							"attrs": {
//																								"callArgs": {
//																									"jaxId": "1H0MO0P386",
//																									"attrs": {
//																										"event": ""
//																									}
//																								},
//																								"seg": ""
//																							}
//																						}
//																					}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1H0MO0P387",
//																					"attrs": {
//																						"tip": {
//																							"type": "string",
//																							"valText": "Calculate tokens",
//																							"localizable": true
//																						}
//																					}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "true",
//																				"containerSlots": {
//																					"jaxId": "1H7A209591",
//																					"attrs": {}
//																				}
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "Gear/@StdUI/ui/BtnIcon.js",
//																			"jaxId": "1H0NSB8DU0",
//																			"attrs": {
//																				"createArgs": {
//																					"jaxId": "1H0NSB8DU1",
//																					"attrs": {
//																						"style": "front",
//																						"w": "30",
//																						"h": "0",
//																						"icon": "#appCfg.sharedAssets+\"/run.svg\"",
//																						"colorBG": "null"
//																					}
//																				},
//																				"properties": {
//																					"jaxId": "1H0NSB8DU2",
//																					"attrs": {
//																						"type": "#null#>BtnIcon(\"front\",30,0,appCfg.sharedAssets+\"/run.svg\",null)",
//																						"id": "",
//																						"position": "Absolute",
//																						"x": "35",
//																						"y": "0",
//																						"display": "On",
//																						"face": "",
//																						"padding": "2"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1H0NSB8DV0",
//																					"attrs": {
//																						"1H0MSV9FC0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H0NSB8DV1",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H0NSB8DV2",
//																									"attrs": {
//																										"enable": {
//																											"type": "bool",
//																											"valText": "false"
//																										}
//																									}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MSV9FC0",
//																							"faceTagName": "execOn"
//																						},
//																						"1H0MT4FFD0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H0NSB8DV3",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H0NSB8DV4",
//																									"attrs": {
//																										"enable": {
//																											"type": "bool",
//																											"valText": "true"
//																										}
//																									}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MT4FFD0",
//																							"faceTagName": "execOff"
//																						},
//																						"1H16JA01P0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1H16JAUVC76",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1H16JAUVC77",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H16JA01P0",
//																							"faceTagName": "checkCy"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1H0NSB8DV5",
//																					"attrs": {
//																						"OnClick": {
//																							"type": "fixedFunc",
//																							"jaxId": "1H0NSB8DV6",
//																							"attrs": {
//																								"callArgs": {
//																									"jaxId": "1H0NSB8DV7",
//																									"attrs": {
//																										"event": ""
//																									}
//																								},
//																								"seg": ""
//																							}
//																						}
//																					}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1H0NSB8DV8",
//																					"attrs": {
//																						"tip": {
//																							"type": "string",
//																							"valText": "提交并生成",
//																							"localize": {
//																								"EN": "Submit and Generate",
//																								"CN": "提交并生成"
//																							},
//																							"localizable": true
//																						}
//																					}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false",
//																				"containerSlots": {
//																					"jaxId": "1H7A209592",
//																					"attrs": {}
//																				}
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "Gear/@StdUI/ui/BtnIcon.js",
//																			"jaxId": "1HA7V8KVP0",
//																			"attrs": {
//																				"createArgs": {
//																					"jaxId": "1HA7V8KVP1",
//																					"attrs": {
//																						"style": "front",
//																						"w": "30",
//																						"h": "0",
//																						"icon": "#appCfg.sharedAssets+\"/appdata.svg\"",
//																						"colorBG": "null"
//																					}
//																				},
//																				"properties": {
//																					"jaxId": "1HA7V8KVP2",
//																					"attrs": {
//																						"type": "#null#>BtnIcon(\"front\",30,0,appCfg.sharedAssets+\"/appdata.svg\",null)",
//																						"id": "BtnShowAdv",
//																						"position": "Absolute",
//																						"x": "65",
//																						"y": "0",
//																						"display": "On",
//																						"face": "",
//																						"padding": "1"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1HA7V8KVP3",
//																					"attrs": {
//																						"1H0MSV9FC0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HA7V8KVP4",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HA7V8KVP5",
//																									"attrs": {
//																										"enable": {
//																											"type": "bool",
//																											"valText": "false"
//																										}
//																									}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MSV9FC0",
//																							"faceTagName": "execOn"
//																						},
//																						"1H0MT4FFD0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HA7V8KVP6",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HA7V8KVP7",
//																									"attrs": {
//																										"enable": {
//																											"type": "bool",
//																											"valText": "true"
//																										}
//																									}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MT4FFD0",
//																							"faceTagName": "execOff"
//																						},
//																						"1H16JA01P0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HA7V8KVP8",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HA7V8KVP9",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H16JA01P0",
//																							"faceTagName": "checkCy"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1HA7V8KVP10",
//																					"attrs": {
//																						"OnClick": {
//																							"type": "fixedFunc",
//																							"jaxId": "1HA7V8KVP11",
//																							"attrs": {
//																								"callArgs": {
//																									"jaxId": "1HA7V8KVP12",
//																									"attrs": {
//																										"event": ""
//																									}
//																								},
//																								"seg": ""
//																							}
//																						}
//																					}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1HA7V8KVP13",
//																					"attrs": {
//																						"tip": {
//																							"type": "string",
//																							"valText": "高级设置",
//																							"localize": {
//																								"EN": "Advanced",
//																								"CN": "高级设置"
//																							},
//																							"localizable": true
//																						}
//																					}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "true",
//																				"containerSlots": {
//																					"jaxId": "1HA7V8KVP14",
//																					"attrs": {}
//																				}
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"jaxId": "1H05RMDIQ14",
//																	"attrs": {
//																		"1H0MSV9FC0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H0MT60MB122",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H0MT60MB123",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H0MSV9FC0",
//																			"faceTagName": "execOn"
//																		},
//																		"1H16JA01P0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H16JAUVC80",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H16JAUVC81",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H16JA01P0",
//																			"faceTagName": "checkCy"
//																		},
//																		"1H0MT4FFD0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H9FCTHPC77",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H9FCTHPC78",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H0MT4FFD0",
//																			"faceTagName": "execOff"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1H05RMDIQ15",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1H05RMDIQ16",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false",
//																"exposeContainer": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1HA7UKAVE0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HA7V2GVE0",
//																	"attrs": {
//																		"type": "hud",
//																		"id": "BoxAdvanced",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "\"\"",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "Off",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "[5,0,5,0]",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"contentLayout": "Flex Y"
//																	}
//																},
//																"subHuds": {
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "box",
//																			"jaxId": "1HA92CPTP0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HA92IDR20",
//																					"attrs": {
//																						"type": "box",
//																						"id": "",
//																						"position": "relative",
//																						"x": "10",
//																						"y": "0",
//																						"w": "100%-20",
//																						"h": "1",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"background": "#cfgColor[\"fontBodySub\"]",
//																						"border": "0",
//																						"borderStyle": "Solid",
//																						"borderColor": "[0,0,0,1.00]",
//																						"corner": "0",
//																						"shadow": "false",
//																						"shadowX": "2",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowSpread": "0",
//																						"shadowColor": "[0,0,0,0.50]"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1HA92IDR21",
//																					"attrs": {}
//																				},
//																				"functions": {
//																					"jaxId": "1HA92IDR22",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1HA92IDR23",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "text",
//																			"jaxId": "1HA92F37T0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HA92IDR24",
//																					"attrs": {
//																						"type": "text",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "100%",
//																						"h": "\"\"",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "[6,0,5,0]",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"color": "#cfgColor[\"fontBodySub\"]",
//																						"text": {
//																							"type": "string",
//																							"valText": "高级设定",
//																							"localize": {
//																								"EN": "Advanced",
//																								"CN": "高级设定"
//																							},
//																							"localizable": true
//																						},
//																						"font": "",
//																						"fontSize": "#txtSize.smallMid",
//																						"bold": "true",
//																						"italic": "false",
//																						"underline": "false",
//																						"alignH": "Center",
//																						"alignV": "Top",
//																						"wrap": "false",
//																						"ellipsis": "false",
//																						"lineClamp": "0",
//																						"select": "false",
//																						"shadow": "false",
//																						"shadowX": "0",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowColor": "[0,0,0,1.00]",
//																						"shadowEx": "",
//																						"maxTextW": "0"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1HA92IDR25",
//																					"attrs": {}
//																				},
//																				"functions": {
//																					"jaxId": "1HA92IDR26",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1HA92IDR27",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "hud",
//																			"jaxId": "1HA81MKQ50",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HA81MKQ51",
//																					"attrs": {
//																						"type": "hud",
//																						"id": "BoxMem",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "300",
//																						"h": "50",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "300",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": ""
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": [
//																						{
//																							"type": "hudobj",
//																							"def": "text",
//																							"jaxId": "1HA81MKQ52",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HA81MKQ53",
//																									"attrs": {
//																										"type": "text",
//																										"id": "",
//																										"position": "Absolute",
//																										"x": "0",
//																										"y": "0",
//																										"w": "100%",
//																										"h": "20",
//																										"anchorH": "Left",
//																										"anchorV": "Top",
//																										"autoLayout": "false",
//																										"display": "On",
//																										"clip": "Off",
//																										"uiEvent": "On",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "",
//																										"zIndex": "0",
//																										"margin": "",
//																										"padding": "",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": "",
//																										"color": "#cfgColor.fontBody",
//																										"text": {
//																											"type": "string",
//																											"valText": "记忆的对话条数",
//																											"localize": {
//																												"EN": "Memory messages capability:",
//																												"CN": "记忆的对话条数"
//																											},
//																											"localizable": true
//																										},
//																										"font": "",
//																										"fontSize": "#txtSize.smallMid",
//																										"bold": "false",
//																										"italic": "false",
//																										"underline": "false",
//																										"alignH": "Left",
//																										"alignV": "Center",
//																										"wrap": "false",
//																										"ellipsis": "false",
//																										"lineClamp": "0",
//																										"select": "false",
//																										"shadow": "false",
//																										"shadowX": "0",
//																										"shadowY": "2",
//																										"shadowBlur": "3",
//																										"shadowColor": "[0,0,0,1.00]",
//																										"shadowEx": "",
//																										"maxTextW": "0",
//																										"autoSizeW": "false",
//																										"autoSizeH": "false"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1HA81MKQ54",
//																									"attrs": {
//																										"1H0MSV9FC0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HA81MKQ55",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HA81MKQ56",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H0MSV9FC0",
//																											"faceTagName": "execOn"
//																										},
//																										"1H16JA01P0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HA81MKQ57",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HA81MKQ58",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H16JA01P0",
//																											"faceTagName": "checkCy"
//																										},
//																										"1H0MT4FFD0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HA81MKQ59",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HA81MKQ510",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H0MT4FFD0",
//																											"faceTagName": "execOff"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1HA81MKQ511",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1HA81MKQ512",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "false"
//																							}
//																						},
//																						{
//																							"type": "hudobj",
//																							"def": "text",
//																							"jaxId": "1HA81MKQ60",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HA81MKQ61",
//																									"attrs": {
//																										"type": "text",
//																										"id": "TxtMem",
//																										"position": "Absolute",
//																										"x": "0",
//																										"y": "0",
//																										"w": "100%",
//																										"h": "20",
//																										"anchorH": "Left",
//																										"anchorV": "Top",
//																										"autoLayout": "false",
//																										"display": "On",
//																										"clip": "Off",
//																										"uiEvent": "On",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "",
//																										"zIndex": "0",
//																										"margin": "",
//																										"padding": "",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": "",
//																										"color": "#cfgColor.fontBody",
//																										"text": "0",
//																										"font": "",
//																										"fontSize": "#txtSize.smallMid",
//																										"bold": "false",
//																										"italic": "false",
//																										"underline": "false",
//																										"alignH": "Right",
//																										"alignV": "Center",
//																										"wrap": "false",
//																										"ellipsis": "false",
//																										"lineClamp": "0",
//																										"select": "false",
//																										"shadow": "false",
//																										"shadowX": "0",
//																										"shadowY": "2",
//																										"shadowBlur": "3",
//																										"shadowColor": "[0,0,0,1.00]",
//																										"shadowEx": "",
//																										"maxTextW": "0",
//																										"autoSizeW": "false",
//																										"autoSizeH": "false"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1HA81MKQ62",
//																									"attrs": {
//																										"1H0MSV9FC0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HA81MKQ63",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HA81MKQ64",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H0MSV9FC0",
//																											"faceTagName": "execOn"
//																										},
//																										"1H16JA01P0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HA81MKQ65",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HA81MKQ66",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H16JA01P0",
//																											"faceTagName": "checkCy"
//																										},
//																										"1H0MT4FFD0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HA81MKQ67",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HA81MKQ68",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H0MT4FFD0",
//																											"faceTagName": "execOff"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1HA81MKQ69",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1HA81MKQ610",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "true"
//																							}
//																						},
//																						{
//																							"type": "hudobj",
//																							"def": "Gear/@StdUI/ui/BoxRange.js",
//																							"jaxId": "1HA81MKQ611",
//																							"attrs": {
//																								"createArgs": {
//																									"jaxId": "1HA81MKQ612",
//																									"attrs": {
//																										"value": "0",
//																										"minVal": "0",
//																										"maxVal": "200"
//																									}
//																								},
//																								"properties": {
//																									"jaxId": "1HA81MKQ613",
//																									"attrs": {
//																										"type": "#null#>BoxRange(0,0,200)",
//																										"id": "BtnMem",
//																										"position": "Absolute",
//																										"x": "0",
//																										"y": "20",
//																										"display": "On",
//																										"face": "",
//																										"w": "300",
//																										"margin": "[5,0,0,0]",
//																										"digit": "0",
//																										"step": "2",
//																										"h": "20",
//																										"buttonSize": "20"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1HA81MKQ614",
//																									"attrs": {
//																										"1H0MSV9FC0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HA81MKQ615",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HA81MKQ616",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H0MSV9FC0",
//																											"faceTagName": "execOn"
//																										},
//																										"1H16JA01P0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HA81MKQ617",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HA81MKQ618",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H16JA01P0",
//																											"faceTagName": "checkCy"
//																										},
//																										"1H0MT4FFD0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HA81MKQ619",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HA81MKQ620",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H0MT4FFD0",
//																											"faceTagName": "execOff"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1HA81MKQ621",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1HA81MKQ622",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "true",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "true",
//																								"containerSlots": {
//																									"jaxId": "1HA81MKQ623",
//																									"attrs": {}
//																								}
//																							}
//																						}
//																					]
//																				},
//																				"faces": {
//																					"jaxId": "1HA81MKQ624",
//																					"attrs": {
//																						"1H0MSV9FC0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HA81MKQ625",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HA81MKQ626",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MSV9FC0",
//																							"faceTagName": "execOn"
//																						},
//																						"1H16JA01P0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HA81MKQ627",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HA81MKQ628",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H16JA01P0",
//																							"faceTagName": "checkCy"
//																						},
//																						"1H0MT4FFD0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HA81MKQ629",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HA81MKQ630",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MT4FFD0",
//																							"faceTagName": "execOff"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1HA81MKQ631",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1HA81MKQ632",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "false",
//																				"exposeContainer": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "hud",
//																			"jaxId": "1HAJFHGFL0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAJFHGFL1",
//																					"attrs": {
//																						"type": "hud",
//																						"id": "BoxMem",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "300",
//																						"h": "50",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "300",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": ""
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": [
//																						{
//																							"type": "hudobj",
//																							"def": "text",
//																							"jaxId": "1HAJFHGFL2",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HAJFHGFL3",
//																									"attrs": {
//																										"type": "text",
//																										"id": "",
//																										"position": "Absolute",
//																										"x": "0",
//																										"y": "0",
//																										"w": "100%",
//																										"h": "20",
//																										"anchorH": "Left",
//																										"anchorV": "Top",
//																										"autoLayout": "false",
//																										"display": "On",
//																										"clip": "Off",
//																										"uiEvent": "On",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "",
//																										"zIndex": "0",
//																										"margin": "",
//																										"padding": "",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": "",
//																										"color": "#cfgColor.fontBody",
//																										"text": {
//																											"type": "string",
//																											"valText": "批量压缩消息数：",
//																											"localize": {
//																												"EN": "Compress messages batch:",
//																												"CN": "批量压缩消息数："
//																											},
//																											"localizable": true
//																										},
//																										"font": "",
//																										"fontSize": "#txtSize.smallMid",
//																										"bold": "false",
//																										"italic": "false",
//																										"underline": "false",
//																										"alignH": "Left",
//																										"alignV": "Center",
//																										"wrap": "false",
//																										"ellipsis": "false",
//																										"lineClamp": "0",
//																										"select": "false",
//																										"shadow": "false",
//																										"shadowX": "0",
//																										"shadowY": "2",
//																										"shadowBlur": "3",
//																										"shadowColor": "[0,0,0,1.00]",
//																										"shadowEx": "",
//																										"maxTextW": "0",
//																										"autoSizeW": "false",
//																										"autoSizeH": "false"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1HAJFHGFM0",
//																									"attrs": {
//																										"1H0MSV9FC0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HAJFHGFM1",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HAJFHGFM2",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H0MSV9FC0",
//																											"faceTagName": "execOn"
//																										},
//																										"1H16JA01P0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HAJFHGFM3",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HAJFHGFM4",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H16JA01P0",
//																											"faceTagName": "checkCy"
//																										},
//																										"1H0MT4FFD0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HAJFHGFM5",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HAJFHGFM6",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H0MT4FFD0",
//																											"faceTagName": "execOff"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1HAJFHGFM7",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1HAJFHGFM8",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "false"
//																							}
//																						},
//																						{
//																							"type": "hudobj",
//																							"def": "text",
//																							"jaxId": "1HAJFHGFM9",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HAJFHGFM10",
//																									"attrs": {
//																										"type": "text",
//																										"id": "TxtCompress",
//																										"position": "Absolute",
//																										"x": "0",
//																										"y": "0",
//																										"w": "100%",
//																										"h": "20",
//																										"anchorH": "Left",
//																										"anchorV": "Top",
//																										"autoLayout": "false",
//																										"display": "On",
//																										"clip": "Off",
//																										"uiEvent": "On",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "",
//																										"zIndex": "0",
//																										"margin": "",
//																										"padding": "",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": "",
//																										"color": "#cfgColor.fontBody",
//																										"text": "0",
//																										"font": "",
//																										"fontSize": "#txtSize.smallMid",
//																										"bold": "false",
//																										"italic": "false",
//																										"underline": "false",
//																										"alignH": "Right",
//																										"alignV": "Center",
//																										"wrap": "false",
//																										"ellipsis": "false",
//																										"lineClamp": "0",
//																										"select": "false",
//																										"shadow": "false",
//																										"shadowX": "0",
//																										"shadowY": "2",
//																										"shadowBlur": "3",
//																										"shadowColor": "[0,0,0,1.00]",
//																										"shadowEx": "",
//																										"maxTextW": "0",
//																										"autoSizeW": "false",
//																										"autoSizeH": "false"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1HAJFHGFM11",
//																									"attrs": {
//																										"1H0MSV9FC0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HAJFHGFM12",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HAJFHGFM13",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H0MSV9FC0",
//																											"faceTagName": "execOn"
//																										},
//																										"1H16JA01P0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HAJFHGFM14",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HAJFHGFM15",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H16JA01P0",
//																											"faceTagName": "checkCy"
//																										},
//																										"1H0MT4FFD0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HAJFHGFM16",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HAJFHGFM17",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H0MT4FFD0",
//																											"faceTagName": "execOff"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1HAJFHGFM18",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1HAJFHGFM19",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "true"
//																							}
//																						},
//																						{
//																							"type": "hudobj",
//																							"def": "Gear/@StdUI/ui/BoxRange.js",
//																							"jaxId": "1HAJFHGFN0",
//																							"attrs": {
//																								"createArgs": {
//																									"jaxId": "1HAJFHGFN1",
//																									"attrs": {
//																										"value": "6",
//																										"minVal": "2",
//																										"maxVal": "20"
//																									}
//																								},
//																								"properties": {
//																									"jaxId": "1HAJFHGFN2",
//																									"attrs": {
//																										"type": "#null#>BoxRange(6,2,20)",
//																										"id": "BtnCompress",
//																										"position": "Absolute",
//																										"x": "0",
//																										"y": "20",
//																										"display": "On",
//																										"face": "",
//																										"w": "300",
//																										"margin": "[5,0,0,0]",
//																										"digit": "0",
//																										"step": "2",
//																										"h": "20",
//																										"buttonSize": "20"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1HAJFHGFN3",
//																									"attrs": {
//																										"1H0MSV9FC0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HAJFHGFN4",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HAJFHGFN5",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H0MSV9FC0",
//																											"faceTagName": "execOn"
//																										},
//																										"1H16JA01P0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HAJFHGFN6",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HAJFHGFN7",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H16JA01P0",
//																											"faceTagName": "checkCy"
//																										},
//																										"1H0MT4FFD0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HAJFHGFN8",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HAJFHGFN9",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H0MT4FFD0",
//																											"faceTagName": "execOff"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1HAJFHGFN10",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1HAJFHGFN11",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "true",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "true",
//																								"containerSlots": {
//																									"jaxId": "1HAJFHGFN12",
//																									"attrs": {}
//																								}
//																							}
//																						}
//																					]
//																				},
//																				"faces": {
//																					"jaxId": "1HAJFHGFN13",
//																					"attrs": {
//																						"1H0MSV9FC0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAJFHGFN14",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HAJFHGFN15",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MSV9FC0",
//																							"faceTagName": "execOn"
//																						},
//																						"1H16JA01P0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAJFHGFN16",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HAJFHGFN17",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H16JA01P0",
//																							"faceTagName": "checkCy"
//																						},
//																						"1H0MT4FFD0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAJFHGFN18",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HAJFHGFN19",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MT4FFD0",
//																							"faceTagName": "execOff"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1HAJFHGFN20",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1HAJFHGFN21",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "false",
//																				"exposeContainer": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "hud",
//																			"jaxId": "1HAFB0C6U0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAFBUOJ90",
//																					"attrs": {
//																						"type": "hud",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "100%",
//																						"h": "30",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"contentLayout": "Flex X",
//																						"itemsAlign": "Center"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": [
//																						{
//																							"type": "hudobj",
//																							"def": "text",
//																							"jaxId": "1HAFBD38M0",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HAFBUOJ91",
//																									"attrs": {
//																										"type": "text",
//																										"id": "",
//																										"position": "relative",
//																										"x": "0",
//																										"y": "0",
//																										"w": "\"\"",
//																										"h": "\"\"",
//																										"anchorH": "Left",
//																										"anchorV": "Top",
//																										"autoLayout": "false",
//																										"display": "On",
//																										"clip": "Off",
//																										"uiEvent": "On",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "",
//																										"zIndex": "0",
//																										"margin": "[0,2,0,0]",
//																										"padding": "",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": "",
//																										"color": "[0,0,0]",
//																										"text": {
//																											"type": "string",
//																											"valText": "保密过程:",
//																											"localize": {
//																												"EN": "Secret process:",
//																												"CN": "保密过程:"
//																											},
//																											"localizable": true
//																										},
//																										"font": "",
//																										"fontSize": "#txtSize.smallMid",
//																										"bold": "false",
//																										"italic": "false",
//																										"underline": "false",
//																										"alignH": "Left",
//																										"alignV": "Top",
//																										"wrap": "false",
//																										"ellipsis": "false",
//																										"lineClamp": "0",
//																										"select": "false",
//																										"shadow": "false",
//																										"shadowX": "0",
//																										"shadowY": "2",
//																										"shadowBlur": "3",
//																										"shadowColor": "[0,0,0,1.00]",
//																										"shadowEx": "",
//																										"maxTextW": "0"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1HAFBUOJ92",
//																									"attrs": {}
//																								},
//																								"functions": {
//																									"jaxId": "1HAFBUOJ93",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1HAFBUOJ94",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "false"
//																							}
//																						},
//																						{
//																							"type": "hudobj",
//																							"def": "Gear/@StdUI/ui/BtnSwitch.js",
//																							"jaxId": "1HAFBK4V90",
//																							"attrs": {
//																								"createArgs": {
//																									"jaxId": "1HAFBUOJ95",
//																									"attrs": {
//																										"size": "16",
//																										"check": "false"
//																									}
//																								},
//																								"properties": {
//																									"jaxId": "1HAFBUOJ96",
//																									"attrs": {
//																										"type": "#null#>BtnSwitch(16,false)",
//																										"id": "BtnSecretInternal",
//																										"position": "relative",
//																										"x": "0",
//																										"y": "0",
//																										"display": "On",
//																										"face": "",
//																										"margin": "[0,10,0,0]"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1HAFBUOJ97",
//																									"attrs": {}
//																								},
//																								"functions": {
//																									"jaxId": "1HAFBUOJ98",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1HAFBUOJ99",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "true",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "true",
//																								"containerSlots": {
//																									"jaxId": "1HAFBUOJ910",
//																									"attrs": {}
//																								}
//																							}
//																						},
//																						{
//																							"type": "hudobj",
//																							"def": "text",
//																							"jaxId": "1HBHNS1VC0",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HBHNS1VC1",
//																									"attrs": {
//																										"type": "text",
//																										"id": "",
//																										"position": "relative",
//																										"x": "0",
//																										"y": "0",
//																										"w": "\"\"",
//																										"h": "\"\"",
//																										"anchorH": "Left",
//																										"anchorV": "Top",
//																										"autoLayout": "false",
//																										"display": "On",
//																										"clip": "Off",
//																										"uiEvent": "On",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "",
//																										"zIndex": "0",
//																										"margin": "[0,2,0,0]",
//																										"padding": "",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": "",
//																										"color": "[0,0,0]",
//																										"text": {
//																											"type": "string",
//																											"valText": "接受文件:",
//																											"localize": {
//																												"EN": "Accept file:",
//																												"CN": "接受文件:"
//																											},
//																											"localizable": true
//																										},
//																										"font": "",
//																										"fontSize": "#txtSize.smallMid",
//																										"bold": "false",
//																										"italic": "false",
//																										"underline": "false",
//																										"alignH": "Left",
//																										"alignV": "Top",
//																										"wrap": "false",
//																										"ellipsis": "false",
//																										"lineClamp": "0",
//																										"select": "false",
//																										"shadow": "false",
//																										"shadowX": "0",
//																										"shadowY": "2",
//																										"shadowBlur": "3",
//																										"shadowColor": "[0,0,0,1.00]",
//																										"shadowEx": "",
//																										"maxTextW": "0"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1HBHNS1VC2",
//																									"attrs": {}
//																								},
//																								"functions": {
//																									"jaxId": "1HBHNS1VC3",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1HBHNS1VC4",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "false"
//																							}
//																						},
//																						{
//																							"type": "hudobj",
//																							"def": "Gear/@StdUI/ui/BtnSwitch.js",
//																							"jaxId": "1HBHNS5A60",
//																							"attrs": {
//																								"createArgs": {
//																									"jaxId": "1HBHNS5A61",
//																									"attrs": {
//																										"size": "16",
//																										"check": "false"
//																									}
//																								},
//																								"properties": {
//																									"jaxId": "1HBHNS5A62",
//																									"attrs": {
//																										"type": "#null#>BtnSwitch(16,false)",
//																										"id": "BtnAllowFile",
//																										"position": "relative",
//																										"x": "0",
//																										"y": "0",
//																										"display": "On",
//																										"face": "",
//																										"margin": "[0,10,0,0]"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1HBHNS5A63",
//																									"attrs": {}
//																								},
//																								"functions": {
//																									"jaxId": "1HBHNS5A64",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1HBHNS5A65",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "true",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "true",
//																								"containerSlots": {
//																									"jaxId": "1HBHNS5A66",
//																									"attrs": {}
//																								}
//																							}
//																						},
//																						{
//																							"type": "hudobj",
//																							"def": "text",
//																							"jaxId": "1HBHO1OD70",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HBHO1OD71",
//																									"attrs": {
//																										"type": "text",
//																										"id": "",
//																										"position": "relative",
//																										"x": "0",
//																										"y": "0",
//																										"w": "\"\"",
//																										"h": "\"\"",
//																										"anchorH": "Left",
//																										"anchorV": "Top",
//																										"autoLayout": "false",
//																										"display": "On",
//																										"clip": "Off",
//																										"uiEvent": "On",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "",
//																										"zIndex": "0",
//																										"margin": "[0,2,0,0]",
//																										"padding": "",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": "",
//																										"color": "[0,0,0]",
//																										"text": {
//																											"type": "string",
//																											"valText": "启动时执行AI:",
//																											"localize": {
//																												"EN": "Run AI on startup:",
//																												"CN": "启动时执行AI:"
//																											},
//																											"localizable": true
//																										},
//																										"font": "",
//																										"fontSize": "#txtSize.smallMid",
//																										"bold": "false",
//																										"italic": "false",
//																										"underline": "false",
//																										"alignH": "Left",
//																										"alignV": "Top",
//																										"wrap": "false",
//																										"ellipsis": "false",
//																										"lineClamp": "0",
//																										"select": "false",
//																										"shadow": "false",
//																										"shadowX": "0",
//																										"shadowY": "2",
//																										"shadowBlur": "3",
//																										"shadowColor": "[0,0,0,1.00]",
//																										"shadowEx": "",
//																										"maxTextW": "0"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1HBHO1OD80",
//																									"attrs": {}
//																								},
//																								"functions": {
//																									"jaxId": "1HBHO1OD81",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1HBHO1OD82",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "false"
//																							}
//																						},
//																						{
//																							"type": "hudobj",
//																							"def": "Gear/@StdUI/ui/BtnSwitch.js",
//																							"jaxId": "1HBHO1R880",
//																							"attrs": {
//																								"createArgs": {
//																									"jaxId": "1HBHO1R890",
//																									"attrs": {
//																										"size": "16",
//																										"check": "false"
//																									}
//																								},
//																								"properties": {
//																									"jaxId": "1HBHO1R891",
//																									"attrs": {
//																										"type": "#null#>BtnSwitch(16,false)",
//																										"id": "BtnInitExec",
//																										"position": "relative",
//																										"x": "0",
//																										"y": "0",
//																										"display": "On",
//																										"face": "",
//																										"margin": "[0,10,0,0]"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1HBHO1R892",
//																									"attrs": {}
//																								},
//																								"functions": {
//																									"jaxId": "1HBHO1R893",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1HBHO1R894",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "true",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "true",
//																								"containerSlots": {
//																									"jaxId": "1HBHO1R895",
//																									"attrs": {}
//																								}
//																							}
//																						}
//																					]
//																				},
//																				"faces": {
//																					"jaxId": "1HAFBUOJ911",
//																					"attrs": {}
//																				},
//																				"functions": {
//																					"jaxId": "1HAFBUOJA0",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1HAFBUOJA1",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "false",
//																				"exposeContainer": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "text",
//																			"jaxId": "1HA7VC0T50",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HA7VC0T51",
//																					"attrs": {
//																						"type": "text",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "100%",
//																						"h": "\"\"",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "[5,0,0,0]",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"color": "#cfgColor[\"fontBody\"]",
//																						"text": {
//																							"type": "string",
//																							"valText": "修饰函数（格式：函数名@JS代码路径，或aichat文件路径）",
//																							"localize": {
//																								"EN": "Filter functions (format: function-name@file-path, or .aichat file path)",
//																								"CN": "修饰函数（格式：函数名@JS代码路径，或aichat文件路径）"
//																							},
//																							"localizable": true
//																						},
//																						"font": "",
//																						"fontSize": "#txtSize.smallMid",
//																						"bold": "false",
//																						"italic": "false",
//																						"underline": "false",
//																						"alignH": "Left",
//																						"alignV": "Top",
//																						"wrap": "false",
//																						"ellipsis": "false",
//																						"lineClamp": "0",
//																						"select": "false",
//																						"shadow": "false",
//																						"shadowX": "0",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowColor": "[0,0,0,1.00]",
//																						"shadowEx": "",
//																						"maxTextW": "0"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1HA7VC0T52",
//																					"attrs": {}
//																				},
//																				"functions": {
//																					"jaxId": "1HA7VC0T53",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1HA7VC0T54",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "box",
//																			"jaxId": "1HA81C3NH0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HA81C3NH1",
//																					"attrs": {
//																						"type": "box",
//																						"id": "BoxFilterInit",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "100%-10",
//																						"h": "\"\"",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "[0,0,10,0]",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"background": "[255,255,255,1.00]",
//																						"border": "1",
//																						"borderStyle": "Solid",
//																						"borderColor": "#cfgColor.lineBodyLit",
//																						"corner": "5",
//																						"shadow": "false",
//																						"shadowX": "2",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowSpread": "0",
//																						"shadowColor": "[0,0,0,0.50]",
//																						"contentLayout": "Flex Y"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": [
//																						{
//																							"type": "hudobj",
//																							"def": "hud",
//																							"jaxId": "1HA81C3NH2",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HA81C3NH3",
//																									"attrs": {
//																										"type": "hud",
//																										"id": "",
//																										"position": "relative",
//																										"x": "0",
//																										"y": "0",
//																										"w": "100%",
//																										"h": "16",
//																										"anchorH": "Left",
//																										"anchorV": "Top",
//																										"autoLayout": "false",
//																										"display": "On",
//																										"clip": "Off",
//																										"uiEvent": "On",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "",
//																										"zIndex": "0",
//																										"margin": "[5,0,0,0]",
//																										"padding": "",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": ""
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": [
//																										{
//																											"type": "hudobj",
//																											"def": "text",
//																											"jaxId": "1HA81C3NH4",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HA81C3NH5",
//																													"attrs": {
//																														"type": "text",
//																														"id": "",
//																														"position": "Absolute",
//																														"x": "5",
//																														"y": "0",
//																														"w": "\"\"",
//																														"h": "\"\"",
//																														"anchorH": "Left",
//																														"anchorV": "Top",
//																														"autoLayout": "false",
//																														"display": "On",
//																														"clip": "Off",
//																														"uiEvent": "On",
//																														"alpha": "1",
//																														"rotate": "0",
//																														"scale": "",
//																														"filter": "",
//																														"cursor": "",
//																														"zIndex": "0",
//																														"margin": "[0,0,0,0]",
//																														"padding": "",
//																														"minW": "",
//																														"minH": "",
//																														"maxW": "",
//																														"maxH": "",
//																														"face": "",
//																														"styleClass": "",
//																														"color": "#cfgColor.fontBodySub",
//																														"text": {
//																															"type": "string",
//																															"valText": "初始化修饰函数（例如：init@./filters.js or ./init.aichat）",
//																															"localize": {
//																																"EN": "Init filter function (e.g. init@./filters.js or ./init.aichat)",
//																																"CN": "初始化修饰函数（例如：init@./filters.js or ./init.aichat）"
//																															},
//																															"localizable": true
//																														},
//																														"font": "",
//																														"fontSize": "#txtSize.small",
//																														"bold": "false",
//																														"italic": "false",
//																														"underline": "false",
//																														"alignH": "Left",
//																														"alignV": "Top",
//																														"wrap": "false",
//																														"ellipsis": "false",
//																														"lineClamp": "0",
//																														"select": "false",
//																														"shadow": "false",
//																														"shadowX": "0",
//																														"shadowY": "2",
//																														"shadowBlur": "3",
//																														"shadowColor": "[0,0,0,1.00]",
//																														"shadowEx": "",
//																														"maxTextW": "0",
//																														"autoSizeW": "false",
//																														"autoSizeH": "false"
//																													}
//																												},
//																												"subHuds": {
//																													"attrs": []
//																												},
//																												"faces": {
//																													"jaxId": "1HA81C3NI0",
//																													"attrs": {
//																														"1H0MSV9FC0": {
//																															"type": "hudface",
//																															"def": "HudFace",
//																															"jaxId": "1HA81C3NI1",
//																															"attrs": {
//																																"properties": {
//																																	"jaxId": "1HA81C3NI2",
//																																	"attrs": {}
//																																},
//																																"anis": {
//																																	"attrs": []
//																																}
//																															},
//																															"faceTagId": "1H0MSV9FC0",
//																															"faceTagName": "execOn"
//																														},
//																														"1H16JA01P0": {
//																															"type": "hudface",
//																															"def": "HudFace",
//																															"jaxId": "1HA81C3NI3",
//																															"attrs": {
//																																"properties": {
//																																	"jaxId": "1HA81C3NI4",
//																																	"attrs": {}
//																																},
//																																"anis": {
//																																	"attrs": []
//																																}
//																															},
//																															"faceTagId": "1H16JA01P0",
//																															"faceTagName": "checkCy"
//																														},
//																														"1H0MT4FFD0": {
//																															"type": "hudface",
//																															"def": "HudFace",
//																															"jaxId": "1HA81C3NI5",
//																															"attrs": {
//																																"properties": {
//																																	"jaxId": "1HA81C3NI6",
//																																	"attrs": {}
//																																},
//																																"anis": {
//																																	"attrs": []
//																																}
//																															},
//																															"faceTagId": "1H0MT4FFD0",
//																															"faceTagName": "execOff"
//																														}
//																													}
//																												},
//																												"functions": {
//																													"jaxId": "1HA81C3NI7",
//																													"attrs": {}
//																												},
//																												"extraPpts": {
//																													"jaxId": "1HA81C3NI8",
//																													"attrs": {}
//																												},
//																												"mockup": "false",
//																												"codes": "false",
//																												"locked": "false",
//																												"container": "false",
//																												"nameVal": "false"
//																											}
//																										}
//																									]
//																								},
//																								"faces": {
//																									"jaxId": "1HA81C3NI9",
//																									"attrs": {
//																										"1H16JA01P0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HA81C3NI10",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HA81C3NI11",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H16JA01P0",
//																											"faceTagName": "checkCy"
//																										},
//																										"1H0MSV9FC0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HA81C3NI12",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HA81C3NI13",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H0MSV9FC0",
//																											"faceTagName": "execOn"
//																										},
//																										"1H0MT4FFD0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HA81C3NI14",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HA81C3NI15",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H0MT4FFD0",
//																											"faceTagName": "execOff"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1HA81C3NI16",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1HA81C3NI17",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "true",
//																								"nameVal": "false",
//																								"exposeContainer": "false"
//																							}
//																						},
//																						{
//																							"type": "hudobj",
//																							"def": "hud",
//																							"jaxId": "1HAG5633H0",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HAG59N2K0",
//																									"attrs": {
//																										"type": "hud",
//																										"id": "",
//																										"position": "relative",
//																										"x": "0",
//																										"y": "0",
//																										"w": "100%",
//																										"h": "30",
//																										"anchorH": "Left",
//																										"anchorV": "Top",
//																										"autoLayout": "false",
//																										"display": "On",
//																										"clip": "Off",
//																										"uiEvent": "On",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "",
//																										"zIndex": "0",
//																										"margin": "",
//																										"padding": "",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": ""
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": [
//																										{
//																											"type": "hudobj",
//																											"def": "edit",
//																											"jaxId": "1HAG56F2E0",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HAG56F2E1",
//																													"attrs": {
//																														"type": "edit",
//																														"id": "EdFilterInit",
//																														"position": "relative",
//																														"x": "35",
//																														"y": "0",
//																														"w": "100%-50",
//																														"h": "20",
//																														"anchorH": "Left",
//																														"anchorV": "Top",
//																														"autoLayout": "false",
//																														"display": "On",
//																														"clip": "Off",
//																														"uiEvent": "On",
//																														"alpha": "1",
//																														"rotate": "0",
//																														"scale": "",
//																														"filter": "",
//																														"cursor": "",
//																														"zIndex": "0",
//																														"margin": "[5,0,5,0]",
//																														"padding": "",
//																														"minW": "",
//																														"minH": "",
//																														"maxW": "",
//																														"maxH": "",
//																														"face": "",
//																														"styleClass": "",
//																														"inputType": "Text",
//																														"text": "",
//																														"placeHolder": "function-name@path-to-file",
//																														"color": "[0,0,0]",
//																														"bgColor": "[255,255,255,1.00]",
//																														"font": "",
//																														"fontSize": "#txtSize.smallMid",
//																														"outline": "0",
//																														"border": "[0,0,1,0]",
//																														"borderStyle": "Solid",
//																														"borderColor": "#cfgColor[\"fontBodySub\"]",
//																														"corner": "0",
//																														"selectOnFocus": "true",
//																														"spellCheck": "true"
//																													}
//																												},
//																												"subHuds": {
//																													"attrs": []
//																												},
//																												"faces": {
//																													"jaxId": "1HAG56F2E2",
//																													"attrs": {}
//																												},
//																												"functions": {
//																													"jaxId": "1HAG56F2E3",
//																													"attrs": {
//																														"OnChange": {
//																															"type": "fixedFunc",
//																															"jaxId": "1HAG56F2E4",
//																															"attrs": {
//																																"callArgs": {
//																																	"jaxId": "1HAG56F2E5",
//																																	"attrs": {}
//																																},
//																																"seg": ""
//																															}
//																														}
//																													}
//																												},
//																												"extraPpts": {
//																													"jaxId": "1HAG56F2E6",
//																													"attrs": {}
//																												},
//																												"mockup": "false",
//																												"codes": "false",
//																												"locked": "false",
//																												"container": "false",
//																												"nameVal": "true"
//																											}
//																										},
//																										{
//																											"type": "hudobj",
//																											"def": "Gear/@StdUI/ui/BtnIcon.js",
//																											"jaxId": "1HAG57UOB0",
//																											"attrs": {
//																												"createArgs": {
//																													"jaxId": "1HAG59N2K1",
//																													"attrs": {
//																														"style": "front",
//																														"w": "26",
//																														"h": "0",
//																														"icon": "/~/-tabos/shared/assets/folder.svg",
//																														"colorBG": "null"
//																													}
//																												},
//																												"properties": {
//																													"jaxId": "1HAG59N2K2",
//																													"attrs": {
//																														"type": "#null#>BtnIcon(\"front\",26,0,\"/~/-tabos/shared/assets/folder.svg\",null)",
//																														"id": "",
//																														"position": "Absolute",
//																														"x": "5",
//																														"y": "50%",
//																														"display": "On",
//																														"face": "",
//																														"enable": "true",
//																														"anchorV": "Center",
//																														"padding": "2"
//																													}
//																												},
//																												"subHuds": {
//																													"attrs": []
//																												},
//																												"faces": {
//																													"jaxId": "1HAG59N2K3",
//																													"attrs": {}
//																												},
//																												"functions": {
//																													"jaxId": "1HAG59N2K4",
//																													"attrs": {
//																														"OnClick": {
//																															"type": "fixedFunc",
//																															"jaxId": "1HBGBQOBC0",
//																															"attrs": {
//																																"callArgs": {
//																																	"jaxId": "1HBGBR0BE0",
//																																	"attrs": {
//																																		"event": ""
//																																	}
//																																},
//																																"seg": ""
//																															}
//																														}
//																													}
//																												},
//																												"extraPpts": {
//																													"jaxId": "1HAG59N2K5",
//																													"attrs": {
//																														"tgt": {
//																															"type": "string",
//																															"valText": "EdFilterInit"
//																														}
//																													}
//																												},
//																												"mockup": "false",
//																												"codes": "false",
//																												"locked": "false",
//																												"container": "false",
//																												"nameVal": "false",
//																												"containerSlots": {
//																													"jaxId": "1HAG59N2K6",
//																													"attrs": {}
//																												}
//																											}
//																										}
//																									]
//																								},
//																								"faces": {
//																									"jaxId": "1HAG59N2K7",
//																									"attrs": {}
//																								},
//																								"functions": {
//																									"jaxId": "1HAG59N2K8",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1HAG59N2K9",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "true",
//																								"nameVal": "false",
//																								"exposeContainer": "false"
//																							}
//																						}
//																					]
//																				},
//																				"faces": {
//																					"jaxId": "1HA81C3NJ4",
//																					"attrs": {
//																						"1H0MSV9FC0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HA81C3NJ5",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HA81C3NJ6",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MSV9FC0",
//																							"faceTagName": "execOn"
//																						},
//																						"1H16JA01P0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HA81C3NJ7",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HA81C3NJ8",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H16JA01P0",
//																							"faceTagName": "checkCy"
//																						},
//																						"1H0MT4FFD0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HA81C3NJ9",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HA81C3NJ10",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MT4FFD0",
//																							"faceTagName": "execOff"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1HA81C3NJ11",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1HA81C3NJ12",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "box",
//																			"jaxId": "1HA81E0450",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HA81E0451",
//																					"attrs": {
//																						"type": "box",
//																						"id": "BoxFilterReset",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "100%-10",
//																						"h": "\"\"",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "[0,0,10,0]",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"background": "[255,255,255,1.00]",
//																						"border": "1",
//																						"borderStyle": "Solid",
//																						"borderColor": "#cfgColor.lineBodyLit",
//																						"corner": "5",
//																						"shadow": "false",
//																						"shadowX": "2",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowSpread": "0",
//																						"shadowColor": "[0,0,0,0.50]",
//																						"contentLayout": "Flex Y"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": [
//																						{
//																							"type": "hudobj",
//																							"def": "hud",
//																							"jaxId": "1HA81E0452",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HA81E0453",
//																									"attrs": {
//																										"type": "hud",
//																										"id": "",
//																										"position": "relative",
//																										"x": "0",
//																										"y": "0",
//																										"w": "100%",
//																										"h": "16",
//																										"anchorH": "Left",
//																										"anchorV": "Top",
//																										"autoLayout": "false",
//																										"display": "On",
//																										"clip": "Off",
//																										"uiEvent": "On",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "",
//																										"zIndex": "0",
//																										"margin": "[5,0,0,0]",
//																										"padding": "",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": ""
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": [
//																										{
//																											"type": "hudobj",
//																											"def": "text",
//																											"jaxId": "1HA81E0454",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HA81E0455",
//																													"attrs": {
//																														"type": "text",
//																														"id": "",
//																														"position": "Absolute",
//																														"x": "5",
//																														"y": "0",
//																														"w": "\"\"",
//																														"h": "\"\"",
//																														"anchorH": "Left",
//																														"anchorV": "Top",
//																														"autoLayout": "false",
//																														"display": "On",
//																														"clip": "Off",
//																														"uiEvent": "On",
//																														"alpha": "1",
//																														"rotate": "0",
//																														"scale": "",
//																														"filter": "",
//																														"cursor": "",
//																														"zIndex": "0",
//																														"margin": "[0,0,0,0]",
//																														"padding": "",
//																														"minW": "",
//																														"minH": "",
//																														"maxW": "",
//																														"maxH": "",
//																														"face": "",
//																														"styleClass": "",
//																														"color": "#cfgColor.fontBodySub",
//																														"text": {
//																															"type": "string",
//																															"valText": "重置修饰函数（例如：reset@./filters.js）",
//																															"localize": {
//																																"EN": "reset filter function (e.g. reset@./filters.js)",
//																																"CN": "重置修饰函数（例如：reset@./filters.js）"
//																															},
//																															"localizable": true
//																														},
//																														"font": "",
//																														"fontSize": "#txtSize.small",
//																														"bold": "false",
//																														"italic": "false",
//																														"underline": "false",
//																														"alignH": "Left",
//																														"alignV": "Top",
//																														"wrap": "false",
//																														"ellipsis": "false",
//																														"lineClamp": "0",
//																														"select": "false",
//																														"shadow": "false",
//																														"shadowX": "0",
//																														"shadowY": "2",
//																														"shadowBlur": "3",
//																														"shadowColor": "[0,0,0,1.00]",
//																														"shadowEx": "",
//																														"maxTextW": "0",
//																														"autoSizeW": "false",
//																														"autoSizeH": "false"
//																													}
//																												},
//																												"subHuds": {
//																													"attrs": []
//																												},
//																												"faces": {
//																													"jaxId": "1HA81E0460",
//																													"attrs": {
//																														"1H0MSV9FC0": {
//																															"type": "hudface",
//																															"def": "HudFace",
//																															"jaxId": "1HA81E0461",
//																															"attrs": {
//																																"properties": {
//																																	"jaxId": "1HA81E0462",
//																																	"attrs": {}
//																																},
//																																"anis": {
//																																	"attrs": []
//																																}
//																															},
//																															"faceTagId": "1H0MSV9FC0",
//																															"faceTagName": "execOn"
//																														},
//																														"1H16JA01P0": {
//																															"type": "hudface",
//																															"def": "HudFace",
//																															"jaxId": "1HA81E0463",
//																															"attrs": {
//																																"properties": {
//																																	"jaxId": "1HA81E0464",
//																																	"attrs": {}
//																																},
//																																"anis": {
//																																	"attrs": []
//																																}
//																															},
//																															"faceTagId": "1H16JA01P0",
//																															"faceTagName": "checkCy"
//																														},
//																														"1H0MT4FFD0": {
//																															"type": "hudface",
//																															"def": "HudFace",
//																															"jaxId": "1HA81E0465",
//																															"attrs": {
//																																"properties": {
//																																	"jaxId": "1HA81E0466",
//																																	"attrs": {}
//																																},
//																																"anis": {
//																																	"attrs": []
//																																}
//																															},
//																															"faceTagId": "1H0MT4FFD0",
//																															"faceTagName": "execOff"
//																														}
//																													}
//																												},
//																												"functions": {
//																													"jaxId": "1HA81E0467",
//																													"attrs": {}
//																												},
//																												"extraPpts": {
//																													"jaxId": "1HA81E0468",
//																													"attrs": {}
//																												},
//																												"mockup": "false",
//																												"codes": "false",
//																												"locked": "false",
//																												"container": "false",
//																												"nameVal": "false"
//																											}
//																										}
//																									]
//																								},
//																								"faces": {
//																									"jaxId": "1HA81E0469",
//																									"attrs": {
//																										"1H16JA01P0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HA81E04610",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HA81E04611",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H16JA01P0",
//																											"faceTagName": "checkCy"
//																										},
//																										"1H0MSV9FC0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HA81E04612",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HA81E04613",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H0MSV9FC0",
//																											"faceTagName": "execOn"
//																										},
//																										"1H0MT4FFD0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HA81E04614",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HA81E04615",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H0MT4FFD0",
//																											"faceTagName": "execOff"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1HA81E04616",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1HA81E04617",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "true",
//																								"nameVal": "false",
//																								"exposeContainer": "false"
//																							}
//																						},
//																						{
//																							"type": "hudobj",
//																							"def": "hud",
//																							"jaxId": "1HAG5M3G70",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HAG5M3G71",
//																									"attrs": {
//																										"type": "hud",
//																										"id": "",
//																										"position": "relative",
//																										"x": "0",
//																										"y": "0",
//																										"w": "100%",
//																										"h": "30",
//																										"anchorH": "Left",
//																										"anchorV": "Top",
//																										"autoLayout": "false",
//																										"display": "On",
//																										"clip": "Off",
//																										"uiEvent": "On",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "",
//																										"zIndex": "0",
//																										"margin": "",
//																										"padding": "",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": ""
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": [
//																										{
//																											"type": "hudobj",
//																											"def": "Gear/@StdUI/ui/BtnIcon.js",
//																											"jaxId": "1HAG5M3G87",
//																											"attrs": {
//																												"createArgs": {
//																													"jaxId": "1HAG5M3G88",
//																													"attrs": {
//																														"style": "front",
//																														"w": "26",
//																														"h": "0",
//																														"icon": "/~/-tabos/shared/assets/folder.svg",
//																														"colorBG": "null"
//																													}
//																												},
//																												"properties": {
//																													"jaxId": "1HAG5M3G89",
//																													"attrs": {
//																														"type": "#null#>BtnIcon(\"front\",26,0,\"/~/-tabos/shared/assets/folder.svg\",null)",
//																														"id": "",
//																														"position": "Absolute",
//																														"x": "5",
//																														"y": "50%",
//																														"display": "On",
//																														"face": "",
//																														"enable": "true",
//																														"anchorV": "Center",
//																														"padding": "2"
//																													}
//																												},
//																												"subHuds": {
//																													"attrs": []
//																												},
//																												"faces": {
//																													"jaxId": "1HAG5M3G810",
//																													"attrs": {}
//																												},
//																												"functions": {
//																													"jaxId": "1HAG5M3G811",
//																													"attrs": {
//																														"OnClick": {
//																															"type": "fixedFunc",
//																															"jaxId": "1HBGDICS80",
//																															"attrs": {
//																																"callArgs": {
//																																	"jaxId": "1HBGDIKRR0",
//																																	"attrs": {
//																																		"event": ""
//																																	}
//																																},
//																																"seg": ""
//																															}
//																														}
//																													}
//																												},
//																												"extraPpts": {
//																													"jaxId": "1HAG5M3G812",
//																													"attrs": {}
//																												},
//																												"mockup": "false",
//																												"codes": "false",
//																												"locked": "false",
//																												"container": "false",
//																												"nameVal": "false",
//																												"containerSlots": {
//																													"jaxId": "1HAG5M3G813",
//																													"attrs": {}
//																												}
//																											}
//																										},
//																										{
//																											"type": "hudobj",
//																											"def": "edit",
//																											"jaxId": "1HAG5MA0P0",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HAG5MA0P1",
//																													"attrs": {
//																														"type": "edit",
//																														"id": "EdFilterReset",
//																														"position": "relative",
//																														"x": "35",
//																														"y": "0",
//																														"w": "100%-50",
//																														"h": "20",
//																														"anchorH": "Left",
//																														"anchorV": "Top",
//																														"autoLayout": "false",
//																														"display": "On",
//																														"clip": "Off",
//																														"uiEvent": "On",
//																														"alpha": "1",
//																														"rotate": "0",
//																														"scale": "",
//																														"filter": "",
//																														"cursor": "",
//																														"zIndex": "0",
//																														"margin": "[5,0,5,0]",
//																														"padding": "",
//																														"minW": "",
//																														"minH": "",
//																														"maxW": "",
//																														"maxH": "",
//																														"face": "",
//																														"styleClass": "",
//																														"inputType": "Text",
//																														"text": "",
//																														"placeHolder": "function-name@path-to-file",
//																														"color": "[0,0,0]",
//																														"bgColor": "[255,255,255,1.00]",
//																														"font": "",
//																														"fontSize": "#txtSize.smallMid",
//																														"outline": "0",
//																														"border": "[0,0,1,0]",
//																														"borderStyle": "Solid",
//																														"borderColor": "#cfgColor[\"fontBodySub\"]",
//																														"corner": "0",
//																														"selectOnFocus": "true",
//																														"spellCheck": "true"
//																													}
//																												},
//																												"subHuds": {
//																													"attrs": []
//																												},
//																												"faces": {
//																													"jaxId": "1HAG5MA0P2",
//																													"attrs": {}
//																												},
//																												"functions": {
//																													"jaxId": "1HAG5MA0P3",
//																													"attrs": {
//																														"OnChange": {
//																															"type": "fixedFunc",
//																															"jaxId": "1HAG5MA0P4",
//																															"attrs": {
//																																"callArgs": {
//																																	"jaxId": "1HAG5MA0P5",
//																																	"attrs": {}
//																																},
//																																"seg": ""
//																															}
//																														}
//																													}
//																												},
//																												"extraPpts": {
//																													"jaxId": "1HAG5MA0P6",
//																													"attrs": {}
//																												},
//																												"mockup": "false",
//																												"codes": "false",
//																												"locked": "false",
//																												"container": "false",
//																												"nameVal": "true"
//																											}
//																										}
//																									]
//																								},
//																								"faces": {
//																									"jaxId": "1HAG5M3G814",
//																									"attrs": {}
//																								},
//																								"functions": {
//																									"jaxId": "1HAG5M3G815",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1HAG5M3G816",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "true",
//																								"nameVal": "false",
//																								"exposeContainer": "false"
//																							}
//																						}
//																					]
//																				},
//																				"faces": {
//																					"jaxId": "1HA81E0473",
//																					"attrs": {
//																						"1H0MSV9FC0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HA81E0474",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HA81E0475",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MSV9FC0",
//																							"faceTagName": "execOn"
//																						},
//																						"1H16JA01P0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HA81E0476",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HA81E0477",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H16JA01P0",
//																							"faceTagName": "checkCy"
//																						},
//																						"1H0MT4FFD0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HA81E0478",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HA81E0479",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MT4FFD0",
//																							"faceTagName": "execOff"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1HA81E04710",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1HA81E04711",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "box",
//																			"jaxId": "1HA7UL0PQ0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HA7UL0PQ1",
//																					"attrs": {
//																						"type": "box",
//																						"id": "BoxFilterInput",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "100%-10",
//																						"h": "\"\"",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "[0,0,10,0]",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"background": "[255,255,255,1.00]",
//																						"border": "1",
//																						"borderStyle": "Solid",
//																						"borderColor": "#cfgColor.lineBodyLit",
//																						"corner": "5",
//																						"shadow": "false",
//																						"shadowX": "2",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowSpread": "0",
//																						"shadowColor": "[0,0,0,0.50]",
//																						"contentLayout": "Flex Y"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": [
//																						{
//																							"type": "hudobj",
//																							"def": "hud",
//																							"jaxId": "1HA7UL0PQ2",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HA7UL0PQ3",
//																									"attrs": {
//																										"type": "hud",
//																										"id": "",
//																										"position": "relative",
//																										"x": "0",
//																										"y": "0",
//																										"w": "100%",
//																										"h": "16",
//																										"anchorH": "Left",
//																										"anchorV": "Top",
//																										"autoLayout": "false",
//																										"display": "On",
//																										"clip": "Off",
//																										"uiEvent": "On",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "",
//																										"zIndex": "0",
//																										"margin": "[5,0,0,0]",
//																										"padding": "",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": ""
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": [
//																										{
//																											"type": "hudobj",
//																											"def": "text",
//																											"jaxId": "1HA7UL0PQ4",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HA7UL0PQ5",
//																													"attrs": {
//																														"type": "text",
//																														"id": "",
//																														"position": "Absolute",
//																														"x": "5",
//																														"y": "0",
//																														"w": "\"\"",
//																														"h": "\"\"",
//																														"anchorH": "Left",
//																														"anchorV": "Top",
//																														"autoLayout": "false",
//																														"display": "On",
//																														"clip": "Off",
//																														"uiEvent": "On",
//																														"alpha": "1",
//																														"rotate": "0",
//																														"scale": "",
//																														"filter": "",
//																														"cursor": "",
//																														"zIndex": "0",
//																														"margin": "[0,0,0,0]",
//																														"padding": "",
//																														"minW": "",
//																														"minH": "",
//																														"maxW": "",
//																														"maxH": "",
//																														"face": "",
//																														"styleClass": "",
//																														"color": "#cfgColor.fontBodySub",
//																														"text": {
//																															"type": "string",
//																															"valText": "用户输入修饰函数 （例如: input@./filters.js）",
//																															"localize": {
//																																"EN": "Prompt filter (e.g. input@./filters.js)",
//																																"CN": "用户输入修饰函数 （例如: input@./filters.js）"
//																															},
//																															"localizable": true
//																														},
//																														"font": "",
//																														"fontSize": "#txtSize.small",
//																														"bold": "false",
//																														"italic": "false",
//																														"underline": "false",
//																														"alignH": "Left",
//																														"alignV": "Top",
//																														"wrap": "false",
//																														"ellipsis": "false",
//																														"lineClamp": "0",
//																														"select": "false",
//																														"shadow": "false",
//																														"shadowX": "0",
//																														"shadowY": "2",
//																														"shadowBlur": "3",
//																														"shadowColor": "[0,0,0,1.00]",
//																														"shadowEx": "",
//																														"maxTextW": "0",
//																														"autoSizeW": "false",
//																														"autoSizeH": "false"
//																													}
//																												},
//																												"subHuds": {
//																													"attrs": []
//																												},
//																												"faces": {
//																													"jaxId": "1HA7UL0PQ6",
//																													"attrs": {
//																														"1H0MSV9FC0": {
//																															"type": "hudface",
//																															"def": "HudFace",
//																															"jaxId": "1HA7UL0PR0",
//																															"attrs": {
//																																"properties": {
//																																	"jaxId": "1HA7UL0PR1",
//																																	"attrs": {}
//																																},
//																																"anis": {
//																																	"attrs": []
//																																}
//																															},
//																															"faceTagId": "1H0MSV9FC0",
//																															"faceTagName": "execOn"
//																														},
//																														"1H16JA01P0": {
//																															"type": "hudface",
//																															"def": "HudFace",
//																															"jaxId": "1HA7UL0PR2",
//																															"attrs": {
//																																"properties": {
//																																	"jaxId": "1HA7UL0PR3",
//																																	"attrs": {}
//																																},
//																																"anis": {
//																																	"attrs": []
//																																}
//																															},
//																															"faceTagId": "1H16JA01P0",
//																															"faceTagName": "checkCy"
//																														},
//																														"1H0MT4FFD0": {
//																															"type": "hudface",
//																															"def": "HudFace",
//																															"jaxId": "1HA7UL0PR4",
//																															"attrs": {
//																																"properties": {
//																																	"jaxId": "1HA7UL0PR5",
//																																	"attrs": {}
//																																},
//																																"anis": {
//																																	"attrs": []
//																																}
//																															},
//																															"faceTagId": "1H0MT4FFD0",
//																															"faceTagName": "execOff"
//																														}
//																													}
//																												},
//																												"functions": {
//																													"jaxId": "1HA7UL0PR6",
//																													"attrs": {}
//																												},
//																												"extraPpts": {
//																													"jaxId": "1HA7UL0PR7",
//																													"attrs": {}
//																												},
//																												"mockup": "false",
//																												"codes": "false",
//																												"locked": "false",
//																												"container": "false",
//																												"nameVal": "false"
//																											}
//																										}
//																									]
//																								},
//																								"faces": {
//																									"jaxId": "1HA7UL0PR8",
//																									"attrs": {
//																										"1H16JA01P0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HA7UL0PR9",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HA7UL0PR10",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H16JA01P0",
//																											"faceTagName": "checkCy"
//																										},
//																										"1H0MSV9FC0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HA7UL0PR11",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HA7UL0PR12",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H0MSV9FC0",
//																											"faceTagName": "execOn"
//																										},
//																										"1H0MT4FFD0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HA7UL0PR13",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HA7UL0PR14",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H0MT4FFD0",
//																											"faceTagName": "execOff"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1HA7UL0PR15",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1HA7UL0PR16",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "true",
//																								"nameVal": "false",
//																								"exposeContainer": "false"
//																							}
//																						},
//																						{
//																							"type": "hudobj",
//																							"def": "hud",
//																							"jaxId": "1HAG5NGCR0",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HAG5NGCR1",
//																									"attrs": {
//																										"type": "hud",
//																										"id": "",
//																										"position": "relative",
//																										"x": "0",
//																										"y": "0",
//																										"w": "100%",
//																										"h": "30",
//																										"anchorH": "Left",
//																										"anchorV": "Top",
//																										"autoLayout": "false",
//																										"display": "On",
//																										"clip": "Off",
//																										"uiEvent": "On",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "",
//																										"zIndex": "0",
//																										"margin": "",
//																										"padding": "",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": ""
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": [
//																										{
//																											"type": "hudobj",
//																											"def": "Gear/@StdUI/ui/BtnIcon.js",
//																											"jaxId": "1HAG5NGCS0",
//																											"attrs": {
//																												"createArgs": {
//																													"jaxId": "1HAG5NGCS1",
//																													"attrs": {
//																														"style": "front",
//																														"w": "26",
//																														"h": "0",
//																														"icon": "/~/-tabos/shared/assets/folder.svg",
//																														"colorBG": "null"
//																													}
//																												},
//																												"properties": {
//																													"jaxId": "1HAG5NGCS2",
//																													"attrs": {
//																														"type": "#null#>BtnIcon(\"front\",26,0,\"/~/-tabos/shared/assets/folder.svg\",null)",
//																														"id": "",
//																														"position": "Absolute",
//																														"x": "5",
//																														"y": "50%",
//																														"display": "On",
//																														"face": "",
//																														"enable": "true",
//																														"anchorV": "Center",
//																														"padding": "2"
//																													}
//																												},
//																												"subHuds": {
//																													"attrs": []
//																												},
//																												"faces": {
//																													"jaxId": "1HAG5NGCS3",
//																													"attrs": {}
//																												},
//																												"functions": {
//																													"jaxId": "1HAG5NGCS4",
//																													"attrs": {
//																														"OnClick": {
//																															"type": "fixedFunc",
//																															"jaxId": "1HBGDJ6PK0",
//																															"attrs": {
//																																"callArgs": {
//																																	"jaxId": "1HBGDJ9K30",
//																																	"attrs": {
//																																		"event": ""
//																																	}
//																																},
//																																"seg": ""
//																															}
//																														}
//																													}
//																												},
//																												"extraPpts": {
//																													"jaxId": "1HAG5NGCS5",
//																													"attrs": {}
//																												},
//																												"mockup": "false",
//																												"codes": "false",
//																												"locked": "false",
//																												"container": "false",
//																												"nameVal": "false",
//																												"containerSlots": {
//																													"jaxId": "1HAG5NGCS6",
//																													"attrs": {}
//																												}
//																											}
//																										},
//																										{
//																											"type": "hudobj",
//																											"def": "edit",
//																											"jaxId": "1HAG5NORI0",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HAG5NORI1",
//																													"attrs": {
//																														"type": "edit",
//																														"id": "EdFilterInput",
//																														"position": "relative",
//																														"x": "35",
//																														"y": "0",
//																														"w": "100%-50",
//																														"h": "20",
//																														"anchorH": "Left",
//																														"anchorV": "Top",
//																														"autoLayout": "false",
//																														"display": "On",
//																														"clip": "Off",
//																														"uiEvent": "On",
//																														"alpha": "1",
//																														"rotate": "0",
//																														"scale": "",
//																														"filter": "",
//																														"cursor": "",
//																														"zIndex": "0",
//																														"margin": "[5,0,5,0]",
//																														"padding": "",
//																														"minW": "",
//																														"minH": "",
//																														"maxW": "",
//																														"maxH": "",
//																														"face": "",
//																														"styleClass": "",
//																														"inputType": "Text",
//																														"text": "",
//																														"placeHolder": "function-name@path-to-file",
//																														"color": "[0,0,0]",
//																														"bgColor": "[255,255,255,1.00]",
//																														"font": "",
//																														"fontSize": "#txtSize.smallMid",
//																														"outline": "0",
//																														"border": "[0,0,1,0]",
//																														"borderStyle": "Solid",
//																														"borderColor": "#cfgColor[\"fontBodySub\"]",
//																														"corner": "0",
//																														"selectOnFocus": "true",
//																														"spellCheck": "true"
//																													}
//																												},
//																												"subHuds": {
//																													"attrs": []
//																												},
//																												"faces": {
//																													"jaxId": "1HAG5NORI2",
//																													"attrs": {}
//																												},
//																												"functions": {
//																													"jaxId": "1HAG5NORI3",
//																													"attrs": {
//																														"OnChange": {
//																															"type": "fixedFunc",
//																															"jaxId": "1HAG5NORJ0",
//																															"attrs": {
//																																"callArgs": {
//																																	"jaxId": "1HAG5NORJ1",
//																																	"attrs": {}
//																																},
//																																"seg": ""
//																															}
//																														}
//																													}
//																												},
//																												"extraPpts": {
//																													"jaxId": "1HAG5NORJ2",
//																													"attrs": {}
//																												},
//																												"mockup": "false",
//																												"codes": "false",
//																												"locked": "false",
//																												"container": "false",
//																												"nameVal": "true"
//																											}
//																										}
//																									]
//																								},
//																								"faces": {
//																									"jaxId": "1HAG5NGCS14",
//																									"attrs": {}
//																								},
//																								"functions": {
//																									"jaxId": "1HAG5NGCS15",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1HAG5NGCS16",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "true",
//																								"nameVal": "false",
//																								"exposeContainer": "false"
//																							}
//																						}
//																					]
//																				},
//																				"faces": {
//																					"jaxId": "1HA7UL0PR30",
//																					"attrs": {
//																						"1H0MSV9FC0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HA7UL0PR31",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HA7UL0PR32",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MSV9FC0",
//																							"faceTagName": "execOn"
//																						},
//																						"1H16JA01P0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HA7UL0PS0",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HA7UL0PS1",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H16JA01P0",
//																							"faceTagName": "checkCy"
//																						},
//																						"1H0MT4FFD0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HA7UL0PS2",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HA7UL0PS3",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MT4FFD0",
//																							"faceTagName": "execOff"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1HA7UL0PS4",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1HA7UL0PS5",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "box",
//																			"jaxId": "1HA7UN27D0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HA7UN27D1",
//																					"attrs": {
//																						"type": "box",
//																						"id": "BoxFilterOutput",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "100%-10",
//																						"h": "\"\"",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "[0,0,10,0]",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"background": "[255,255,255,1.00]",
//																						"border": "1",
//																						"borderStyle": "Solid",
//																						"borderColor": "#cfgColor.lineBodyLit",
//																						"corner": "5",
//																						"shadow": "false",
//																						"shadowX": "2",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowSpread": "0",
//																						"shadowColor": "[0,0,0,0.50]",
//																						"contentLayout": "Flex Y"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": [
//																						{
//																							"type": "hudobj",
//																							"def": "hud",
//																							"jaxId": "1HA7UN27E0",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HA7UN27E1",
//																									"attrs": {
//																										"type": "hud",
//																										"id": "",
//																										"position": "relative",
//																										"x": "0",
//																										"y": "0",
//																										"w": "100%",
//																										"h": "16",
//																										"anchorH": "Left",
//																										"anchorV": "Top",
//																										"autoLayout": "false",
//																										"display": "On",
//																										"clip": "Off",
//																										"uiEvent": "On",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "",
//																										"zIndex": "0",
//																										"margin": "[5,0,0,0]",
//																										"padding": "",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": ""
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": [
//																										{
//																											"type": "hudobj",
//																											"def": "text",
//																											"jaxId": "1HA7UN27E2",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HA7UN27E3",
//																													"attrs": {
//																														"type": "text",
//																														"id": "",
//																														"position": "Absolute",
//																														"x": "5",
//																														"y": "0",
//																														"w": "\"\"",
//																														"h": "\"\"",
//																														"anchorH": "Left",
//																														"anchorV": "Top",
//																														"autoLayout": "false",
//																														"display": "On",
//																														"clip": "Off",
//																														"uiEvent": "On",
//																														"alpha": "1",
//																														"rotate": "0",
//																														"scale": "",
//																														"filter": "",
//																														"cursor": "",
//																														"zIndex": "0",
//																														"margin": "[0,0,0,0]",
//																														"padding": "",
//																														"minW": "",
//																														"minH": "",
//																														"maxW": "",
//																														"maxH": "",
//																														"face": "",
//																														"styleClass": "",
//																														"color": "#cfgColor.fontBodySub",
//																														"text": {
//																															"type": "string",
//																															"valText": "AI输出修饰函数（例如：output@./filters.js）",
//																															"localize": {
//																																"EN": "Output filter function (e.g. output@./filters.js)",
//																																"CN": "AI输出修饰函数（例如：output@./filters.js）"
//																															},
//																															"localizable": true
//																														},
//																														"font": "",
//																														"fontSize": "#txtSize.small",
//																														"bold": "false",
//																														"italic": "false",
//																														"underline": "false",
//																														"alignH": "Left",
//																														"alignV": "Top",
//																														"wrap": "false",
//																														"ellipsis": "false",
//																														"lineClamp": "0",
//																														"select": "false",
//																														"shadow": "false",
//																														"shadowX": "0",
//																														"shadowY": "2",
//																														"shadowBlur": "3",
//																														"shadowColor": "[0,0,0,1.00]",
//																														"shadowEx": "",
//																														"maxTextW": "0",
//																														"autoSizeW": "false",
//																														"autoSizeH": "false"
//																													}
//																												},
//																												"subHuds": {
//																													"attrs": []
//																												},
//																												"faces": {
//																													"jaxId": "1HA7UN27E4",
//																													"attrs": {
//																														"1H0MSV9FC0": {
//																															"type": "hudface",
//																															"def": "HudFace",
//																															"jaxId": "1HA7UN27E5",
//																															"attrs": {
//																																"properties": {
//																																	"jaxId": "1HA7UN27E6",
//																																	"attrs": {}
//																																},
//																																"anis": {
//																																	"attrs": []
//																																}
//																															},
//																															"faceTagId": "1H0MSV9FC0",
//																															"faceTagName": "execOn"
//																														},
//																														"1H16JA01P0": {
//																															"type": "hudface",
//																															"def": "HudFace",
//																															"jaxId": "1HA7UN27E7",
//																															"attrs": {
//																																"properties": {
//																																	"jaxId": "1HA7UN27E8",
//																																	"attrs": {}
//																																},
//																																"anis": {
//																																	"attrs": []
//																																}
//																															},
//																															"faceTagId": "1H16JA01P0",
//																															"faceTagName": "checkCy"
//																														},
//																														"1H0MT4FFD0": {
//																															"type": "hudface",
//																															"def": "HudFace",
//																															"jaxId": "1HA7UN27E9",
//																															"attrs": {
//																																"properties": {
//																																	"jaxId": "1HA7UN27E10",
//																																	"attrs": {}
//																																},
//																																"anis": {
//																																	"attrs": []
//																																}
//																															},
//																															"faceTagId": "1H0MT4FFD0",
//																															"faceTagName": "execOff"
//																														}
//																													}
//																												},
//																												"functions": {
//																													"jaxId": "1HA7UN27E11",
//																													"attrs": {}
//																												},
//																												"extraPpts": {
//																													"jaxId": "1HA7UN27E12",
//																													"attrs": {}
//																												},
//																												"mockup": "false",
//																												"codes": "false",
//																												"locked": "false",
//																												"container": "false",
//																												"nameVal": "false"
//																											}
//																										}
//																									]
//																								},
//																								"faces": {
//																									"jaxId": "1HA7UN27E13",
//																									"attrs": {
//																										"1H16JA01P0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HA7UN27F0",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HA7UN27F1",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H16JA01P0",
//																											"faceTagName": "checkCy"
//																										},
//																										"1H0MSV9FC0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HA7UN27F2",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HA7UN27F3",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H0MSV9FC0",
//																											"faceTagName": "execOn"
//																										},
//																										"1H0MT4FFD0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HA7UN27F4",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HA7UN27F5",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H0MT4FFD0",
//																											"faceTagName": "execOff"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1HA7UN27F6",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1HA7UN27F7",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "true",
//																								"nameVal": "false",
//																								"exposeContainer": "false"
//																							}
//																						},
//																						{
//																							"type": "hudobj",
//																							"def": "hud",
//																							"jaxId": "1HAG5OOQ50",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HAG5OOQ51",
//																									"attrs": {
//																										"type": "hud",
//																										"id": "",
//																										"position": "relative",
//																										"x": "0",
//																										"y": "0",
//																										"w": "100%",
//																										"h": "30",
//																										"anchorH": "Left",
//																										"anchorV": "Top",
//																										"autoLayout": "false",
//																										"display": "On",
//																										"clip": "Off",
//																										"uiEvent": "On",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "",
//																										"zIndex": "0",
//																										"margin": "",
//																										"padding": "",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": ""
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": [
//																										{
//																											"type": "hudobj",
//																											"def": "Gear/@StdUI/ui/BtnIcon.js",
//																											"jaxId": "1HAG5OOQ60",
//																											"attrs": {
//																												"createArgs": {
//																													"jaxId": "1HAG5OOQ61",
//																													"attrs": {
//																														"style": "front",
//																														"w": "26",
//																														"h": "0",
//																														"icon": "/~/-tabos/shared/assets/folder.svg",
//																														"colorBG": "null"
//																													}
//																												},
//																												"properties": {
//																													"jaxId": "1HAG5OOQ62",
//																													"attrs": {
//																														"type": "#null#>BtnIcon(\"front\",26,0,\"/~/-tabos/shared/assets/folder.svg\",null)",
//																														"id": "",
//																														"position": "Absolute",
//																														"x": "5",
//																														"y": "50%",
//																														"display": "On",
//																														"face": "",
//																														"enable": "true",
//																														"anchorV": "Center",
//																														"padding": "2"
//																													}
//																												},
//																												"subHuds": {
//																													"attrs": []
//																												},
//																												"faces": {
//																													"jaxId": "1HAG5OOQ63",
//																													"attrs": {}
//																												},
//																												"functions": {
//																													"jaxId": "1HAG5OOQ64",
//																													"attrs": {
//																														"OnClick": {
//																															"type": "fixedFunc",
//																															"jaxId": "1HBGDJJQD0",
//																															"attrs": {
//																																"callArgs": {
//																																	"jaxId": "1HBGDJLJC0",
//																																	"attrs": {
//																																		"event": ""
//																																	}
//																																},
//																																"seg": ""
//																															}
//																														}
//																													}
//																												},
//																												"extraPpts": {
//																													"jaxId": "1HAG5OOQ65",
//																													"attrs": {}
//																												},
//																												"mockup": "false",
//																												"codes": "false",
//																												"locked": "false",
//																												"container": "false",
//																												"nameVal": "false",
//																												"containerSlots": {
//																													"jaxId": "1HAG5OOQ66",
//																													"attrs": {}
//																												}
//																											}
//																										},
//																										{
//																											"type": "hudobj",
//																											"def": "edit",
//																											"jaxId": "1HAG5P0R00",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HAG5P0R01",
//																													"attrs": {
//																														"type": "edit",
//																														"id": "EdFilterOutput",
//																														"position": "relative",
//																														"x": "35",
//																														"y": "0",
//																														"w": "100%-50",
//																														"h": "20",
//																														"anchorH": "Left",
//																														"anchorV": "Top",
//																														"autoLayout": "false",
//																														"display": "On",
//																														"clip": "Off",
//																														"uiEvent": "On",
//																														"alpha": "1",
//																														"rotate": "0",
//																														"scale": "",
//																														"filter": "",
//																														"cursor": "",
//																														"zIndex": "0",
//																														"margin": "[5,0,5,0]",
//																														"padding": "",
//																														"minW": "",
//																														"minH": "",
//																														"maxW": "",
//																														"maxH": "",
//																														"face": "",
//																														"styleClass": "",
//																														"inputType": "Text",
//																														"text": "",
//																														"placeHolder": "function-name@path-to-file",
//																														"color": "[0,0,0]",
//																														"bgColor": "[255,255,255,1.00]",
//																														"font": "",
//																														"fontSize": "#txtSize.smallMid",
//																														"outline": "0",
//																														"border": "[0,0,1,0]",
//																														"borderStyle": "Solid",
//																														"borderColor": "#cfgColor[\"fontBodySub\"]",
//																														"corner": "0",
//																														"selectOnFocus": "true",
//																														"spellCheck": "true"
//																													}
//																												},
//																												"subHuds": {
//																													"attrs": []
//																												},
//																												"faces": {
//																													"jaxId": "1HAG5P0R02",
//																													"attrs": {}
//																												},
//																												"functions": {
//																													"jaxId": "1HAG5P0R03",
//																													"attrs": {
//																														"OnChange": {
//																															"type": "fixedFunc",
//																															"jaxId": "1HAG5P0R04",
//																															"attrs": {
//																																"callArgs": {
//																																	"jaxId": "1HAG5P0R05",
//																																	"attrs": {}
//																																},
//																																"seg": ""
//																															}
//																														}
//																													}
//																												},
//																												"extraPpts": {
//																													"jaxId": "1HAG5P0R06",
//																													"attrs": {}
//																												},
//																												"mockup": "false",
//																												"codes": "false",
//																												"locked": "false",
//																												"container": "false",
//																												"nameVal": "true"
//																											}
//																										}
//																									]
//																								},
//																								"faces": {
//																									"jaxId": "1HAG5OOQ95",
//																									"attrs": {}
//																								},
//																								"functions": {
//																									"jaxId": "1HAG5OOQ96",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1HAG5OOQ97",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "true",
//																								"nameVal": "false",
//																								"exposeContainer": "false"
//																							}
//																						}
//																					]
//																				},
//																				"faces": {
//																					"jaxId": "1HA7UN27F21",
//																					"attrs": {
//																						"1H0MSV9FC0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HA7UN27F22",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HA7UN27F23",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MSV9FC0",
//																							"faceTagName": "execOn"
//																						},
//																						"1H16JA01P0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HA7UN27F24",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HA7UN27F25",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H16JA01P0",
//																							"faceTagName": "checkCy"
//																						},
//																						"1H0MT4FFD0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HA7UN27F26",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HA7UN27F27",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MT4FFD0",
//																							"faceTagName": "execOff"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1HA7UN27F28",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1HA7UN27F29",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "box",
//																			"jaxId": "1HBGBCGQF0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HBGBCGQF1",
//																					"attrs": {
//																						"type": "box",
//																						"id": "BoxFilterRound",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "100%-10",
//																						"h": "\"\"",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "[0,0,10,0]",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"background": "[255,255,255,1.00]",
//																						"border": "1",
//																						"borderStyle": "Solid",
//																						"borderColor": "#cfgColor.lineBodyLit",
//																						"corner": "5",
//																						"shadow": "false",
//																						"shadowX": "2",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowSpread": "0",
//																						"shadowColor": "[0,0,0,0.50]",
//																						"contentLayout": "Flex Y"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": [
//																						{
//																							"type": "hudobj",
//																							"def": "hud",
//																							"jaxId": "1HBGBCGQF2",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HBGBCGQF3",
//																									"attrs": {
//																										"type": "hud",
//																										"id": "",
//																										"position": "relative",
//																										"x": "0",
//																										"y": "0",
//																										"w": "100%",
//																										"h": "16",
//																										"anchorH": "Left",
//																										"anchorV": "Top",
//																										"autoLayout": "false",
//																										"display": "On",
//																										"clip": "Off",
//																										"uiEvent": "On",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "",
//																										"zIndex": "0",
//																										"margin": "[5,0,0,0]",
//																										"padding": "",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": ""
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": [
//																										{
//																											"type": "hudobj",
//																											"def": "text",
//																											"jaxId": "1HBGBCGQG0",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HBGBCGQG1",
//																													"attrs": {
//																														"type": "text",
//																														"id": "",
//																														"position": "Absolute",
//																														"x": "5",
//																														"y": "0",
//																														"w": "\"\"",
//																														"h": "\"\"",
//																														"anchorH": "Left",
//																														"anchorV": "Top",
//																														"autoLayout": "false",
//																														"display": "On",
//																														"clip": "Off",
//																														"uiEvent": "On",
//																														"alpha": "1",
//																														"rotate": "0",
//																														"scale": "",
//																														"filter": "",
//																														"cursor": "",
//																														"zIndex": "0",
//																														"margin": "[0,0,0,0]",
//																														"padding": "",
//																														"minW": "",
//																														"minH": "",
//																														"maxW": "",
//																														"maxH": "",
//																														"face": "",
//																														"styleClass": "",
//																														"color": "#cfgColor.fontBodySub",
//																														"text": {
//																															"type": "string",
//																															"valText": "对话回合修饰函数（例如：round@./filters.js）",
//																															"localize": {
//																																"EN": "End round filter function (e.g. round@./filters.js)",
//																																"CN": "对话回合修饰函数（例如：round@./filters.js）"
//																															},
//																															"localizable": true
//																														},
//																														"font": "",
//																														"fontSize": "#txtSize.small",
//																														"bold": "false",
//																														"italic": "false",
//																														"underline": "false",
//																														"alignH": "Left",
//																														"alignV": "Top",
//																														"wrap": "false",
//																														"ellipsis": "false",
//																														"lineClamp": "0",
//																														"select": "false",
//																														"shadow": "false",
//																														"shadowX": "0",
//																														"shadowY": "2",
//																														"shadowBlur": "3",
//																														"shadowColor": "[0,0,0,1.00]",
//																														"shadowEx": "",
//																														"maxTextW": "0",
//																														"autoSizeW": "false",
//																														"autoSizeH": "false"
//																													}
//																												},
//																												"subHuds": {
//																													"attrs": []
//																												},
//																												"faces": {
//																													"jaxId": "1HBGBCGQG2",
//																													"attrs": {
//																														"1H0MSV9FC0": {
//																															"type": "hudface",
//																															"def": "HudFace",
//																															"jaxId": "1HBGBCGQG3",
//																															"attrs": {
//																																"properties": {
//																																	"jaxId": "1HBGBCGQG4",
//																																	"attrs": {}
//																																},
//																																"anis": {
//																																	"attrs": []
//																																}
//																															},
//																															"faceTagId": "1H0MSV9FC0",
//																															"faceTagName": "execOn"
//																														},
//																														"1H16JA01P0": {
//																															"type": "hudface",
//																															"def": "HudFace",
//																															"jaxId": "1HBGBCGQG5",
//																															"attrs": {
//																																"properties": {
//																																	"jaxId": "1HBGBCGQG6",
//																																	"attrs": {}
//																																},
//																																"anis": {
//																																	"attrs": []
//																																}
//																															},
//																															"faceTagId": "1H16JA01P0",
//																															"faceTagName": "checkCy"
//																														},
//																														"1H0MT4FFD0": {
//																															"type": "hudface",
//																															"def": "HudFace",
//																															"jaxId": "1HBGBCGQG7",
//																															"attrs": {
//																																"properties": {
//																																	"jaxId": "1HBGBCGQG8",
//																																	"attrs": {}
//																																},
//																																"anis": {
//																																	"attrs": []
//																																}
//																															},
//																															"faceTagId": "1H0MT4FFD0",
//																															"faceTagName": "execOff"
//																														}
//																													}
//																												},
//																												"functions": {
//																													"jaxId": "1HBGBCGQG9",
//																													"attrs": {}
//																												},
//																												"extraPpts": {
//																													"jaxId": "1HBGBCGQG10",
//																													"attrs": {}
//																												},
//																												"mockup": "false",
//																												"codes": "false",
//																												"locked": "false",
//																												"container": "false",
//																												"nameVal": "false"
//																											}
//																										}
//																									]
//																								},
//																								"faces": {
//																									"jaxId": "1HBGBCGQG11",
//																									"attrs": {
//																										"1H16JA01P0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HBGBCGQG12",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HBGBCGQG13",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H16JA01P0",
//																											"faceTagName": "checkCy"
//																										},
//																										"1H0MSV9FC0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HBGBCGQG14",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HBGBCGQG15",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H0MSV9FC0",
//																											"faceTagName": "execOn"
//																										},
//																										"1H0MT4FFD0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HBGBCGQG16",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HBGBCGQG17",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H0MT4FFD0",
//																											"faceTagName": "execOff"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1HBGBCGQG18",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1HBGBCGQG19",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "true",
//																								"nameVal": "false",
//																								"exposeContainer": "false"
//																							}
//																						},
//																						{
//																							"type": "hudobj",
//																							"def": "hud",
//																							"jaxId": "1HBGBCGQG20",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HBGBCGQG21",
//																									"attrs": {
//																										"type": "hud",
//																										"id": "",
//																										"position": "relative",
//																										"x": "0",
//																										"y": "0",
//																										"w": "100%",
//																										"h": "30",
//																										"anchorH": "Left",
//																										"anchorV": "Top",
//																										"autoLayout": "false",
//																										"display": "On",
//																										"clip": "Off",
//																										"uiEvent": "On",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "",
//																										"zIndex": "0",
//																										"margin": "",
//																										"padding": "",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": ""
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": [
//																										{
//																											"type": "hudobj",
//																											"def": "edit",
//																											"jaxId": "1HBGBCGQH7",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HBGBCGQH8",
//																													"attrs": {
//																														"type": "edit",
//																														"id": "EdFilterRound",
//																														"position": "relative",
//																														"x": "35",
//																														"y": "0",
//																														"w": "100%-50",
//																														"h": "20",
//																														"anchorH": "Left",
//																														"anchorV": "Top",
//																														"autoLayout": "false",
//																														"display": "On",
//																														"clip": "Off",
//																														"uiEvent": "On",
//																														"alpha": "1",
//																														"rotate": "0",
//																														"scale": "",
//																														"filter": "",
//																														"cursor": "",
//																														"zIndex": "0",
//																														"margin": "[5,0,5,0]",
//																														"padding": "",
//																														"minW": "",
//																														"minH": "",
//																														"maxW": "",
//																														"maxH": "",
//																														"face": "",
//																														"styleClass": "",
//																														"inputType": "Text",
//																														"text": "",
//																														"placeHolder": "function-name@path-to-file",
//																														"color": "[0,0,0]",
//																														"bgColor": "[255,255,255,1.00]",
//																														"font": "",
//																														"fontSize": "#txtSize.smallMid",
//																														"outline": "0",
//																														"border": "[0,0,1,0]",
//																														"borderStyle": "Solid",
//																														"borderColor": "#cfgColor[\"fontBodySub\"]",
//																														"corner": "0",
//																														"selectOnFocus": "true",
//																														"spellCheck": "true"
//																													}
//																												},
//																												"subHuds": {
//																													"attrs": []
//																												},
//																												"faces": {
//																													"jaxId": "1HBGBCGQH9",
//																													"attrs": {}
//																												},
//																												"functions": {
//																													"jaxId": "1HBGBCGQH10",
//																													"attrs": {
//																														"OnChange": {
//																															"type": "fixedFunc",
//																															"jaxId": "1HBGBCGQH11",
//																															"attrs": {
//																																"callArgs": {
//																																	"jaxId": "1HBGBCGQH12",
//																																	"attrs": {}
//																																},
//																																"seg": ""
//																															}
//																														}
//																													}
//																												},
//																												"extraPpts": {
//																													"jaxId": "1HBGBCGQH13",
//																													"attrs": {}
//																												},
//																												"mockup": "false",
//																												"codes": "false",
//																												"locked": "false",
//																												"container": "false",
//																												"nameVal": "true"
//																											}
//																										},
//																										{
//																											"type": "hudobj",
//																											"def": "Gear/@StdUI/ui/BtnIcon.js",
//																											"jaxId": "1HBGBCGQH0",
//																											"attrs": {
//																												"createArgs": {
//																													"jaxId": "1HBGBCGQH1",
//																													"attrs": {
//																														"style": "front",
//																														"w": "26",
//																														"h": "0",
//																														"icon": "/~/-tabos/shared/assets/folder.svg",
//																														"colorBG": "null"
//																													}
//																												},
//																												"properties": {
//																													"jaxId": "1HBGBCGQH2",
//																													"attrs": {
//																														"type": "#null#>BtnIcon(\"front\",26,0,\"/~/-tabos/shared/assets/folder.svg\",null)",
//																														"id": "",
//																														"position": "Absolute",
//																														"x": "5",
//																														"y": "50%",
//																														"display": "On",
//																														"face": "",
//																														"enable": "true",
//																														"anchorV": "Center",
//																														"padding": "2"
//																													}
//																												},
//																												"subHuds": {
//																													"attrs": []
//																												},
//																												"faces": {
//																													"jaxId": "1HBGBCGQH3",
//																													"attrs": {}
//																												},
//																												"functions": {
//																													"jaxId": "1HBGBCGQH4",
//																													"attrs": {
//																														"OnClick": {
//																															"type": "fixedFunc",
//																															"jaxId": "1HBGDJT5G0",
//																															"attrs": {
//																																"callArgs": {
//																																	"jaxId": "1HBGDK07C0",
//																																	"attrs": {
//																																		"event": ""
//																																	}
//																																},
//																																"seg": ""
//																															}
//																														}
//																													}
//																												},
//																												"extraPpts": {
//																													"jaxId": "1HBGBCGQH5",
//																													"attrs": {}
//																												},
//																												"mockup": "false",
//																												"codes": "false",
//																												"locked": "false",
//																												"container": "false",
//																												"nameVal": "false",
//																												"containerSlots": {
//																													"jaxId": "1HBGBCGQH6",
//																													"attrs": {}
//																												}
//																											}
//																										}
//																									]
//																								},
//																								"faces": {
//																									"jaxId": "1HBGBCGQH14",
//																									"attrs": {}
//																								},
//																								"functions": {
//																									"jaxId": "1HBGBCGQH15",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1HBGBCGQH16",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "true",
//																								"nameVal": "false",
//																								"exposeContainer": "false"
//																							}
//																						}
//																					]
//																				},
//																				"faces": {
//																					"jaxId": "1HBGBCGQH17",
//																					"attrs": {
//																						"1H0MSV9FC0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HBGBCGQH18",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HBGBCGQH19",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MSV9FC0",
//																							"faceTagName": "execOn"
//																						},
//																						"1H16JA01P0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HBGBCGQH20",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HBGBCGQH21",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H16JA01P0",
//																							"faceTagName": "checkCy"
//																						},
//																						"1H0MT4FFD0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HBGBCGQH22",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HBGBCGQH23",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MT4FFD0",
//																							"faceTagName": "execOff"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1HBGBCGQH24",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1HBGBCGQH25",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "box",
//																			"jaxId": "1HAFCFAV10",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAFCFAV11",
//																					"attrs": {
//																						"type": "box",
//																						"id": "BoxFilterCompress",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "100%-10",
//																						"h": "\"\"",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "[0,0,10,0]",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"background": "[255,255,255,1.00]",
//																						"border": "1",
//																						"borderStyle": "Solid",
//																						"borderColor": "#cfgColor.lineBodyLit",
//																						"corner": "5",
//																						"shadow": "false",
//																						"shadowX": "2",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowSpread": "0",
//																						"shadowColor": "[0,0,0,0.50]",
//																						"contentLayout": "Flex Y"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": [
//																						{
//																							"type": "hudobj",
//																							"def": "hud",
//																							"jaxId": "1HAFCFAV12",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HAFCFAV13",
//																									"attrs": {
//																										"type": "hud",
//																										"id": "",
//																										"position": "relative",
//																										"x": "0",
//																										"y": "0",
//																										"w": "100%",
//																										"h": "16",
//																										"anchorH": "Left",
//																										"anchorV": "Top",
//																										"autoLayout": "false",
//																										"display": "On",
//																										"clip": "Off",
//																										"uiEvent": "On",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "",
//																										"zIndex": "0",
//																										"margin": "[5,0,0,0]",
//																										"padding": "",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": ""
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": [
//																										{
//																											"type": "hudobj",
//																											"def": "text",
//																											"jaxId": "1HAFCFAV14",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HAFCFAV15",
//																													"attrs": {
//																														"type": "text",
//																														"id": "",
//																														"position": "Absolute",
//																														"x": "5",
//																														"y": "0",
//																														"w": "\"\"",
//																														"h": "\"\"",
//																														"anchorH": "Left",
//																														"anchorV": "Top",
//																														"autoLayout": "false",
//																														"display": "On",
//																														"clip": "Off",
//																														"uiEvent": "On",
//																														"alpha": "1",
//																														"rotate": "0",
//																														"scale": "",
//																														"filter": "",
//																														"cursor": "",
//																														"zIndex": "0",
//																														"margin": "[0,0,0,0]",
//																														"padding": "",
//																														"minW": "",
//																														"minH": "",
//																														"maxW": "",
//																														"maxH": "",
//																														"face": "",
//																														"styleClass": "",
//																														"color": "#cfgColor.fontBodySub",
//																														"text": {
//																															"type": "string",
//																															"valText": "压缩对话函数（例如：output@./filters.js）",
//																															"localize": {
//																																"EN": "Compress messages function (e.g. output@./filters.js)",
//																																"CN": "压缩对话函数（例如：output@./filters.js）"
//																															},
//																															"localizable": true
//																														},
//																														"font": "",
//																														"fontSize": "#txtSize.small",
//																														"bold": "false",
//																														"italic": "false",
//																														"underline": "false",
//																														"alignH": "Left",
//																														"alignV": "Top",
//																														"wrap": "false",
//																														"ellipsis": "false",
//																														"lineClamp": "0",
//																														"select": "false",
//																														"shadow": "false",
//																														"shadowX": "0",
//																														"shadowY": "2",
//																														"shadowBlur": "3",
//																														"shadowColor": "[0,0,0,1.00]",
//																														"shadowEx": "",
//																														"maxTextW": "0",
//																														"autoSizeW": "false",
//																														"autoSizeH": "false"
//																													}
//																												},
//																												"subHuds": {
//																													"attrs": []
//																												},
//																												"faces": {
//																													"jaxId": "1HAFCFAV16",
//																													"attrs": {
//																														"1H0MSV9FC0": {
//																															"type": "hudface",
//																															"def": "HudFace",
//																															"jaxId": "1HAFCFAV20",
//																															"attrs": {
//																																"properties": {
//																																	"jaxId": "1HAFCFAV21",
//																																	"attrs": {}
//																																},
//																																"anis": {
//																																	"attrs": []
//																																}
//																															},
//																															"faceTagId": "1H0MSV9FC0",
//																															"faceTagName": "execOn"
//																														},
//																														"1H16JA01P0": {
//																															"type": "hudface",
//																															"def": "HudFace",
//																															"jaxId": "1HAFCFAV22",
//																															"attrs": {
//																																"properties": {
//																																	"jaxId": "1HAFCFAV23",
//																																	"attrs": {}
//																																},
//																																"anis": {
//																																	"attrs": []
//																																}
//																															},
//																															"faceTagId": "1H16JA01P0",
//																															"faceTagName": "checkCy"
//																														},
//																														"1H0MT4FFD0": {
//																															"type": "hudface",
//																															"def": "HudFace",
//																															"jaxId": "1HAFCFAV24",
//																															"attrs": {
//																																"properties": {
//																																	"jaxId": "1HAFCFAV25",
//																																	"attrs": {}
//																																},
//																																"anis": {
//																																	"attrs": []
//																																}
//																															},
//																															"faceTagId": "1H0MT4FFD0",
//																															"faceTagName": "execOff"
//																														}
//																													}
//																												},
//																												"functions": {
//																													"jaxId": "1HAFCFAV26",
//																													"attrs": {}
//																												},
//																												"extraPpts": {
//																													"jaxId": "1HAFCFAV27",
//																													"attrs": {}
//																												},
//																												"mockup": "false",
//																												"codes": "false",
//																												"locked": "false",
//																												"container": "false",
//																												"nameVal": "false"
//																											}
//																										}
//																									]
//																								},
//																								"faces": {
//																									"jaxId": "1HAFCFAV28",
//																									"attrs": {
//																										"1H16JA01P0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HAFCFAV29",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HAFCFAV210",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H16JA01P0",
//																											"faceTagName": "checkCy"
//																										},
//																										"1H0MSV9FC0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HAFCFAV211",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HAFCFAV212",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H0MSV9FC0",
//																											"faceTagName": "execOn"
//																										},
//																										"1H0MT4FFD0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HAFCFAV213",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HAFCFAV214",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H0MT4FFD0",
//																											"faceTagName": "execOff"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1HAFCFAV215",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1HAFCFAV216",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "true",
//																								"nameVal": "false",
//																								"exposeContainer": "false"
//																							}
//																						},
//																						{
//																							"type": "hudobj",
//																							"def": "hud",
//																							"jaxId": "1HAG5RRCB0",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HAG5RRCB1",
//																									"attrs": {
//																										"type": "hud",
//																										"id": "",
//																										"position": "relative",
//																										"x": "0",
//																										"y": "0",
//																										"w": "100%",
//																										"h": "30",
//																										"anchorH": "Left",
//																										"anchorV": "Top",
//																										"autoLayout": "false",
//																										"display": "On",
//																										"clip": "Off",
//																										"uiEvent": "On",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "",
//																										"zIndex": "0",
//																										"margin": "",
//																										"padding": "",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": ""
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": [
//																										{
//																											"type": "hudobj",
//																											"def": "edit",
//																											"jaxId": "1HAG5RVUT0",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HAG5RVUT1",
//																													"attrs": {
//																														"type": "edit",
//																														"id": "EdFilterCompress",
//																														"position": "relative",
//																														"x": "35",
//																														"y": "0",
//																														"w": "100%-50",
//																														"h": "20",
//																														"anchorH": "Left",
//																														"anchorV": "Top",
//																														"autoLayout": "false",
//																														"display": "On",
//																														"clip": "Off",
//																														"uiEvent": "On",
//																														"alpha": "1",
//																														"rotate": "0",
//																														"scale": "",
//																														"filter": "",
//																														"cursor": "",
//																														"zIndex": "0",
//																														"margin": "[5,0,5,0]",
//																														"padding": "",
//																														"minW": "",
//																														"minH": "",
//																														"maxW": "",
//																														"maxH": "",
//																														"face": "",
//																														"styleClass": "",
//																														"inputType": "Text",
//																														"text": "",
//																														"placeHolder": "function-name@path-to-file",
//																														"color": "[0,0,0]",
//																														"bgColor": "[255,255,255,1.00]",
//																														"font": "",
//																														"fontSize": "#txtSize.smallMid",
//																														"outline": "0",
//																														"border": "[0,0,1,0]",
//																														"borderStyle": "Solid",
//																														"borderColor": "#cfgColor[\"fontBodySub\"]",
//																														"corner": "0",
//																														"selectOnFocus": "true",
//																														"spellCheck": "true"
//																													}
//																												},
//																												"subHuds": {
//																													"attrs": []
//																												},
//																												"faces": {
//																													"jaxId": "1HAG5RVUT2",
//																													"attrs": {}
//																												},
//																												"functions": {
//																													"jaxId": "1HAG5RVUT3",
//																													"attrs": {
//																														"OnChange": {
//																															"type": "fixedFunc",
//																															"jaxId": "1HAG5RVUT4",
//																															"attrs": {
//																																"callArgs": {
//																																	"jaxId": "1HAG5RVUT5",
//																																	"attrs": {}
//																																},
//																																"seg": ""
//																															}
//																														}
//																													}
//																												},
//																												"extraPpts": {
//																													"jaxId": "1HAG5RVUT6",
//																													"attrs": {}
//																												},
//																												"mockup": "false",
//																												"codes": "false",
//																												"locked": "false",
//																												"container": "false",
//																												"nameVal": "true"
//																											}
//																										},
//																										{
//																											"type": "hudobj",
//																											"def": "Gear/@StdUI/ui/BtnIcon.js",
//																											"jaxId": "1HAG5RRCB2",
//																											"attrs": {
//																												"createArgs": {
//																													"jaxId": "1HAG5RRCB3",
//																													"attrs": {
//																														"style": "front",
//																														"w": "26",
//																														"h": "0",
//																														"icon": "/~/-tabos/shared/assets/folder.svg",
//																														"colorBG": "null"
//																													}
//																												},
//																												"properties": {
//																													"jaxId": "1HAG5RRCB4",
//																													"attrs": {
//																														"type": "#null#>BtnIcon(\"front\",26,0,\"/~/-tabos/shared/assets/folder.svg\",null)",
//																														"id": "",
//																														"position": "Absolute",
//																														"x": "5",
//																														"y": "50%",
//																														"display": "On",
//																														"face": "",
//																														"enable": "true",
//																														"anchorV": "Center",
//																														"padding": "2"
//																													}
//																												},
//																												"subHuds": {
//																													"attrs": []
//																												},
//																												"faces": {
//																													"jaxId": "1HAG5RRCB5",
//																													"attrs": {}
//																												},
//																												"functions": {
//																													"jaxId": "1HAG5RRCB6",
//																													"attrs": {
//																														"OnClick": {
//																															"type": "fixedFunc",
//																															"jaxId": "1HBGDK8DM0",
//																															"attrs": {
//																																"callArgs": {
//																																	"jaxId": "1HBGDKAGQ0",
//																																	"attrs": {
//																																		"event": ""
//																																	}
//																																},
//																																"seg": ""
//																															}
//																														}
//																													}
//																												},
//																												"extraPpts": {
//																													"jaxId": "1HAG5RRCB7",
//																													"attrs": {}
//																												},
//																												"mockup": "false",
//																												"codes": "false",
//																												"locked": "false",
//																												"container": "false",
//																												"nameVal": "false",
//																												"containerSlots": {
//																													"jaxId": "1HAG5RRCB8",
//																													"attrs": {}
//																												}
//																											}
//																										}
//																									]
//																								},
//																								"faces": {
//																									"jaxId": "1HAG5RRCC5",
//																									"attrs": {}
//																								},
//																								"functions": {
//																									"jaxId": "1HAG5RRCC6",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1HAG5RRCC7",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "true",
//																								"nameVal": "false",
//																								"exposeContainer": "false"
//																							}
//																						}
//																					]
//																				},
//																				"faces": {
//																					"jaxId": "1HAFCFAV224",
//																					"attrs": {
//																						"1H0MSV9FC0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAFCFAV225",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HAFCFAV226",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MSV9FC0",
//																							"faceTagName": "execOn"
//																						},
//																						"1H16JA01P0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAFCFAV227",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HAFCFAV228",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H16JA01P0",
//																							"faceTagName": "checkCy"
//																						},
//																						"1H0MT4FFD0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAFCFAV229",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HAFCFAV230",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MT4FFD0",
//																							"faceTagName": "execOff"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1HAFCFAV231",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1HAFCFAV232",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "box",
//																			"jaxId": "1HAG5CML10",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAG5CML11",
//																					"attrs": {
//																						"type": "box",
//																						"id": "BoxBotAPIFile",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "100%-10",
//																						"h": "\"\"",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "[0,0,10,0]",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"background": "[255,255,255,1.00]",
//																						"border": "1",
//																						"borderStyle": "Solid",
//																						"borderColor": "#cfgColor.lineBodyLit",
//																						"corner": "5",
//																						"shadow": "false",
//																						"shadowX": "2",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowSpread": "0",
//																						"shadowColor": "[0,0,0,0.50]",
//																						"contentLayout": "Flex Y"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": [
//																						{
//																							"type": "hudobj",
//																							"def": "hud",
//																							"jaxId": "1HAG5CML20",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HAG5CML21",
//																									"attrs": {
//																										"type": "hud",
//																										"id": "",
//																										"position": "relative",
//																										"x": "0",
//																										"y": "0",
//																										"w": "100%",
//																										"h": "16",
//																										"anchorH": "Left",
//																										"anchorV": "Top",
//																										"autoLayout": "false",
//																										"display": "On",
//																										"clip": "Off",
//																										"uiEvent": "On",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "",
//																										"zIndex": "0",
//																										"margin": "[5,0,0,0]",
//																										"padding": "",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": ""
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": [
//																										{
//																											"type": "hudobj",
//																											"def": "text",
//																											"jaxId": "1HAG5CML22",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HAG5CML23",
//																													"attrs": {
//																														"type": "text",
//																														"id": "",
//																														"position": "Absolute",
//																														"x": "5",
//																														"y": "0",
//																														"w": "\"\"",
//																														"h": "\"\"",
//																														"anchorH": "Left",
//																														"anchorV": "Top",
//																														"autoLayout": "false",
//																														"display": "On",
//																														"clip": "Off",
//																														"uiEvent": "On",
//																														"alpha": "1",
//																														"rotate": "0",
//																														"scale": "",
//																														"filter": "",
//																														"cursor": "",
//																														"zIndex": "0",
//																														"margin": "[0,0,0,0]",
//																														"padding": "",
//																														"minW": "",
//																														"minH": "",
//																														"maxW": "",
//																														"maxH": "",
//																														"face": "",
//																														"styleClass": "",
//																														"color": "#cfgColor.fontBodySub",
//																														"text": {
//																															"type": "string",
//																															"valText": "API 文件，如有多个文件，用分号隔开",
//																															"localize": {
//																																"EN": "API file, separate multiple files with semicolon",
//																																"CN": "API 文件，如有多个文件，用分号隔开"
//																															},
//																															"localizable": true
//																														},
//																														"font": "",
//																														"fontSize": "#txtSize.small",
//																														"bold": "false",
//																														"italic": "false",
//																														"underline": "false",
//																														"alignH": "Left",
//																														"alignV": "Top",
//																														"wrap": "false",
//																														"ellipsis": "false",
//																														"lineClamp": "0",
//																														"select": "false",
//																														"shadow": "false",
//																														"shadowX": "0",
//																														"shadowY": "2",
//																														"shadowBlur": "3",
//																														"shadowColor": "[0,0,0,1.00]",
//																														"shadowEx": "",
//																														"maxTextW": "0",
//																														"autoSizeW": "false",
//																														"autoSizeH": "false"
//																													}
//																												},
//																												"subHuds": {
//																													"attrs": []
//																												},
//																												"faces": {
//																													"jaxId": "1HAG5CML24",
//																													"attrs": {
//																														"1H0MSV9FC0": {
//																															"type": "hudface",
//																															"def": "HudFace",
//																															"jaxId": "1HAG5CML25",
//																															"attrs": {
//																																"properties": {
//																																	"jaxId": "1HAG5CML26",
//																																	"attrs": {}
//																																},
//																																"anis": {
//																																	"attrs": []
//																																}
//																															},
//																															"faceTagId": "1H0MSV9FC0",
//																															"faceTagName": "execOn"
//																														},
//																														"1H16JA01P0": {
//																															"type": "hudface",
//																															"def": "HudFace",
//																															"jaxId": "1HAG5CML27",
//																															"attrs": {
//																																"properties": {
//																																	"jaxId": "1HAG5CML28",
//																																	"attrs": {}
//																																},
//																																"anis": {
//																																	"attrs": []
//																																}
//																															},
//																															"faceTagId": "1H16JA01P0",
//																															"faceTagName": "checkCy"
//																														},
//																														"1H0MT4FFD0": {
//																															"type": "hudface",
//																															"def": "HudFace",
//																															"jaxId": "1HAG5CML30",
//																															"attrs": {
//																																"properties": {
//																																	"jaxId": "1HAG5CML31",
//																																	"attrs": {}
//																																},
//																																"anis": {
//																																	"attrs": []
//																																}
//																															},
//																															"faceTagId": "1H0MT4FFD0",
//																															"faceTagName": "execOff"
//																														}
//																													}
//																												},
//																												"functions": {
//																													"jaxId": "1HAG5CML32",
//																													"attrs": {}
//																												},
//																												"extraPpts": {
//																													"jaxId": "1HAG5CML33",
//																													"attrs": {}
//																												},
//																												"mockup": "false",
//																												"codes": "false",
//																												"locked": "false",
//																												"container": "false",
//																												"nameVal": "false"
//																											}
//																										}
//																									]
//																								},
//																								"faces": {
//																									"jaxId": "1HAG5CML34",
//																									"attrs": {
//																										"1H16JA01P0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HAG5CML35",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HAG5CML36",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H16JA01P0",
//																											"faceTagName": "checkCy"
//																										},
//																										"1H0MSV9FC0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HAG5CML37",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HAG5CML38",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H0MSV9FC0",
//																											"faceTagName": "execOn"
//																										},
//																										"1H0MT4FFD0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HAG5CML39",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HAG5CML310",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1H0MT4FFD0",
//																											"faceTagName": "execOff"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1HAG5CML311",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1HAG5CML312",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "true",
//																								"nameVal": "false",
//																								"exposeContainer": "false"
//																							}
//																						},
//																						{
//																							"type": "hudobj",
//																							"def": "hud",
//																							"jaxId": "1HAG63NJR0",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HAG63NJR1",
//																									"attrs": {
//																										"type": "hud",
//																										"id": "",
//																										"position": "relative",
//																										"x": "0",
//																										"y": "0",
//																										"w": "100%",
//																										"h": "30",
//																										"anchorH": "Left",
//																										"anchorV": "Top",
//																										"autoLayout": "false",
//																										"display": "On",
//																										"clip": "Off",
//																										"uiEvent": "On",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "",
//																										"zIndex": "0",
//																										"margin": "",
//																										"padding": "",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": ""
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": [
//																										{
//																											"type": "hudobj",
//																											"def": "edit",
//																											"jaxId": "1HAG64K3H0",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HAG64K3H1",
//																													"attrs": {
//																														"type": "edit",
//																														"id": "EdBotAPIFile",
//																														"position": "relative",
//																														"x": "35",
//																														"y": "0",
//																														"w": "100%-50",
//																														"h": "20",
//																														"anchorH": "Left",
//																														"anchorV": "Top",
//																														"autoLayout": "false",
//																														"display": "On",
//																														"clip": "Off",
//																														"uiEvent": "On",
//																														"alpha": "1",
//																														"rotate": "0",
//																														"scale": "",
//																														"filter": "",
//																														"cursor": "",
//																														"zIndex": "0",
//																														"margin": "[5,0,5,0]",
//																														"padding": "",
//																														"minW": "",
//																														"minH": "",
//																														"maxW": "",
//																														"maxH": "",
//																														"face": "",
//																														"styleClass": "",
//																														"inputType": "Text",
//																														"text": "",
//																														"placeHolder": "path-to-file1;path-to-file2;...",
//																														"color": "[0,0,0]",
//																														"bgColor": "[255,255,255,1.00]",
//																														"font": "",
//																														"fontSize": "#txtSize.smallMid",
//																														"outline": "0",
//																														"border": "[0,0,1,0]",
//																														"borderStyle": "Solid",
//																														"borderColor": "#cfgColor[\"fontBodySub\"]",
//																														"corner": "0",
//																														"selectOnFocus": "true",
//																														"spellCheck": "true"
//																													}
//																												},
//																												"subHuds": {
//																													"attrs": []
//																												},
//																												"faces": {
//																													"jaxId": "1HAG64K3I0",
//																													"attrs": {}
//																												},
//																												"functions": {
//																													"jaxId": "1HAG64K3I1",
//																													"attrs": {
//																														"OnChange": {
//																															"type": "fixedFunc",
//																															"jaxId": "1HAG64K3I2",
//																															"attrs": {
//																																"callArgs": {
//																																	"jaxId": "1HAG64K3I3",
//																																	"attrs": {}
//																																},
//																																"seg": ""
//																															}
//																														}
//																													}
//																												},
//																												"extraPpts": {
//																													"jaxId": "1HAG64K3I4",
//																													"attrs": {}
//																												},
//																												"mockup": "false",
//																												"codes": "false",
//																												"locked": "false",
//																												"container": "false",
//																												"nameVal": "true"
//																											}
//																										},
//																										{
//																											"type": "hudobj",
//																											"def": "Gear/@StdUI/ui/BtnIcon.js",
//																											"jaxId": "1HAG63NJR2",
//																											"attrs": {
//																												"createArgs": {
//																													"jaxId": "1HAG63NJR3",
//																													"attrs": {
//																														"style": "front",
//																														"w": "26",
//																														"h": "0",
//																														"icon": "/~/-tabos/shared/assets/folder.svg",
//																														"colorBG": "null"
//																													}
//																												},
//																												"properties": {
//																													"jaxId": "1HAG63NJR4",
//																													"attrs": {
//																														"type": "#null#>BtnIcon(\"front\",26,0,\"/~/-tabos/shared/assets/folder.svg\",null)",
//																														"id": "",
//																														"position": "Absolute",
//																														"x": "5",
//																														"y": "50%",
//																														"display": "On",
//																														"face": "",
//																														"enable": "true",
//																														"anchorV": "Center",
//																														"padding": "2"
//																													}
//																												},
//																												"subHuds": {
//																													"attrs": []
//																												},
//																												"faces": {
//																													"jaxId": "1HAG63NJR5",
//																													"attrs": {}
//																												},
//																												"functions": {
//																													"jaxId": "1HAG63NJR6",
//																													"attrs": {
//																														"OnClick": {
//																															"type": "fixedFunc",
//																															"jaxId": "1HBGDNPJJ0",
//																															"attrs": {
//																																"callArgs": {
//																																	"jaxId": "1HBGDO6AQ0",
//																																	"attrs": {
//																																		"event": ""
//																																	}
//																																},
//																																"seg": ""
//																															}
//																														}
//																													}
//																												},
//																												"extraPpts": {
//																													"jaxId": "1HAG63NJR7",
//																													"attrs": {}
//																												},
//																												"mockup": "false",
//																												"codes": "false",
//																												"locked": "false",
//																												"container": "false",
//																												"nameVal": "false",
//																												"containerSlots": {
//																													"jaxId": "1HAG63NJR8",
//																													"attrs": {}
//																												}
//																											}
//																										}
//																									]
//																								},
//																								"faces": {
//																									"jaxId": "1HAG63NJS3",
//																									"attrs": {}
//																								},
//																								"functions": {
//																									"jaxId": "1HAG63NJS4",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1HAG63NJS5",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "true",
//																								"nameVal": "false",
//																								"exposeContainer": "false"
//																							}
//																						}
//																					]
//																				},
//																				"faces": {
//																					"jaxId": "1HAG5CML320",
//																					"attrs": {
//																						"1H0MSV9FC0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAG5CML321",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HAG5CML322",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MSV9FC0",
//																							"faceTagName": "execOn"
//																						},
//																						"1H16JA01P0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAG5CML323",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HAG5CML324",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H16JA01P0",
//																							"faceTagName": "checkCy"
//																						},
//																						"1H0MT4FFD0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HAG5CML325",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HAG5CML326",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1H0MT4FFD0",
//																							"faceTagName": "execOff"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1HAG5CML327",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1HAG5CML328",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "Gear/@StdUI/ui/BtnText.js",
//																			"jaxId": "1HA809PPQ0",
//																			"attrs": {
//																				"createArgs": {
//																					"jaxId": "1HA80CAPV0",
//																					"attrs": {
//																						"style": "",
//																						"w": "100",
//																						"h": "20",
//																						"text": {
//																							"type": "string",
//																							"valText": "应用",
//																							"localize": {
//																								"EN": "Apply",
//																								"CN": "应用"
//																							},
//																							"localizable": true
//																						},
//																						"outlined": "false",
//																						"icon": ""
//																					}
//																				},
//																				"properties": {
//																					"jaxId": "1HA80CAPV1",
//																					"attrs": {
//																						"type": "#null#>BtnText(\"\",100,20,(($ln===\"CN\")?(\"应用\"):(\"Apply\")),false,\"\")",
//																						"id": "",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"display": "On",
//																						"face": "",
//																						"corner": "3"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1HA80CAPV2",
//																					"attrs": {}
//																				},
//																				"functions": {
//																					"jaxId": "1HA80CAPV3",
//																					"attrs": {
//																						"OnClick": {
//																							"type": "fixedFunc",
//																							"jaxId": "1HA80I71C0",
//																							"attrs": {
//																								"callArgs": {
//																									"jaxId": "1HA80IC6K0",
//																									"attrs": {
//																										"event": ""
//																									}
//																								},
//																								"seg": ""
//																							}
//																						}
//																					}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1HA80CAPV4",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "false",
//																				"containerSlots": {
//																					"jaxId": "1HA80CAPV5",
//																					"attrs": {
//																						"Slot1H2F6U36O0": {
//																							"jaxId": "1IA2I3ORQ0",
//																							"attrs": {
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"container": "true"
//																							}
//																						}
//																					}
//																				}
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"jaxId": "1HA7V2GVE1",
//																	"attrs": {}
//																},
//																"functions": {
//																	"jaxId": "1HA7V2GVE2",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HA7V2GVE3",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "true",
//																"exposeContainer": "false"
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1H04VDE1U1",
//													"attrs": {
//														"1H0MSV9FC0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H0MT60MB126",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1H0MT60MB127",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H0MSV9FC0",
//															"faceTagName": "execOn"
//														},
//														"1H16JA01P0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H16JAUVC84",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1H16JAUVC85",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H16JA01P0",
//															"faceTagName": "checkCy"
//														},
//														"1H0MT4FFD0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H9FCTHPC79",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1H9FCTHPC80",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H0MT4FFD0",
//															"faceTagName": "execOff"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1H04VDE1U2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1H04VDE1U3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1H04VDHIR0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H04VDHIR1",
//													"attrs": {
//														"type": "hud",
//														"id": "HudBtm",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "${state.hudBtmH},state",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": ""
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnText.js",
//															"jaxId": "1H04VHO0Q0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1H04VS9LA0",
//																	"attrs": {
//																		"style": "success",
//																		"w": "100",
//																		"h": "24",
//																		"text": {
//																			"type": "string",
//																			"valText": "提交",
//																			"localize": {
//																				"EN": "Submit",
//																				"CN": "提交"
//																			},
//																			"localizable": true
//																		},
//																		"outlined": "false",
//																		"icon": ""
//																	}
//																},
//																"properties": {
//																	"jaxId": "1H04VS9LA1",
//																	"attrs": {
//																		"type": "#null#>BtnText(\"success\",100,24,(($ln===\"CN\")?(\"提交\"):(\"Submit\")),false,\"\")",
//																		"id": "BtnExec",
//																		"position": "Absolute",
//																		"x": "10",
//																		"y": "10",
//																		"display": "On",
//																		"face": "",
//																		"corner": "3"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1H04VS9LA2",
//																	"attrs": {
//																		"1H0MSV9FC0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H0MT262A0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H0MT262A1",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H0MSV9FC0",
//																			"faceTagName": "execOn"
//																		},
//																		"1H0MT4FFD0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H0MT60MB128",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H0MT60MB129",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H0MT4FFD0",
//																			"faceTagName": "execOff"
//																		},
//																		"1H16JA01P0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H16JAUVC88",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H16JAUVC89",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H16JA01P0",
//																			"faceTagName": "checkCy"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1H04VS9LA3",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1H0MPPA5E0",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1H0MPQ3SL0",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1H04VS9LA4",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1H7A209593",
//																	"attrs": {
//																		"Slot1H2F6U36O0": {
//																			"jaxId": "1IA2I3ORQ1",
//																			"attrs": {
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"container": "true"
//																			}
//																		}
//																	}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnText.js",
//															"jaxId": "1H0MT30BJ0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1H0MT30BJ1",
//																	"attrs": {
//																		"style": "warning",
//																		"w": "100",
//																		"h": "24",
//																		"text": "Cancel",
//																		"outlined": "false",
//																		"icon": ""
//																	}
//																},
//																"properties": {
//																	"jaxId": "1H0MT30BJ2",
//																	"attrs": {
//																		"type": "#null#>BtnText(\"warning\",100,24,\"Cancel\",false,\"\")",
//																		"id": "BtnCancel",
//																		"position": "Absolute",
//																		"x": "10",
//																		"y": "10",
//																		"display": "Off",
//																		"face": "",
//																		"corner": "3"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1H0MT30BJ3",
//																	"attrs": {
//																		"1H0MSV9FC0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H0MT30BJ4",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H0MT30BJ5",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H0MSV9FC0",
//																			"faceTagName": "execOn"
//																		},
//																		"1H0MT4FFD0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H0MT60MB134",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H0MT60MB135",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H0MT4FFD0",
//																			"faceTagName": "execOff"
//																		},
//																		"1H16JA01P0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H16JAUVC92",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H16JAUVC93",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H16JA01P0",
//																			"faceTagName": "checkCy"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1H0MT30BJ6",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1H0MT30BJ7",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1H0MT30BJ8",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1H0MT30BJ9",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1H7A209594",
//																	"attrs": {
//																		"Slot1H2F6U36O0": {
//																			"jaxId": "1IA2I3ORQ2",
//																			"attrs": {
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"container": "true"
//																			}
//																		}
//																	}
//																}
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1H04VDHIS0",
//													"attrs": {
//														"1H0MSV9FC0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H0MT60MB138",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1H0MT60MB139",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H0MSV9FC0",
//															"faceTagName": "execOn"
//														},
//														"1H16JA01P0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H16JAUVC96",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1H16JAUVC97",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H16JA01P0",
//															"faceTagName": "checkCy"
//														},
//														"1H0MT4FFD0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H9FCTHPD0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1H9FCTHPD1",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H0MT4FFD0",
//															"faceTagName": "execOff"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1H04VDHIS1",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1H04VDHIS2",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1H04SO18D18",
//									"attrs": {
//										"1H0MSV9FC0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H0MT60MB142",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H0MT60MB143",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H0MSV9FC0",
//											"faceTagName": "execOn"
//										},
//										"1H16JA01P0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H16JAUVC100",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H16JAUVC101",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H16JA01P0",
//											"faceTagName": "checkCy"
//										},
//										"1H0MT4FFD0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H9FCTHPD2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H9FCTHPD3",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H0MT4FFD0",
//											"faceTagName": "execOff"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1H04SO18D19",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H04SO18D20",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1H04Q8C9M9",
//					"attrs": {
//						"1H0MSV9FC0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H0MT60MB146",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H0MT60MB147",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H0MSV9FC0",
//							"faceTagName": "execOn"
//						},
//						"1H16JA01P0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H16JAUVC104",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H16JAUVC105",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H16JA01P0",
//							"faceTagName": "checkCy"
//						},
//						"1H0MT4FFD0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H9FCTHPD4",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H9FCTHPD5",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H0MT4FFD0",
//							"faceTagName": "execOff"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1H04Q8C9M10",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1H04Q8C9M11",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1H04Q8C9M12",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"innerLayout": {
//					"valText": "false"
//				},
//				"marginL": {
//					"valText": "false"
//				},
//				"marginR": {
//					"valText": "false"
//				},
//				"marginT": {
//					"valText": "false"
//				},
//				"marginB": {
//					"valText": "false"
//				},
//				"paddingL": {
//					"valText": "false"
//				},
//				"paddingR": {
//					"valText": "false"
//				},
//				"paddingT": {
//					"valText": "false"
//				},
//				"paddingB": {
//					"valText": "false"
//				},
//				"attach": {
//					"valText": "false"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}