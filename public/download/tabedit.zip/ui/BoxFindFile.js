//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
/*#{1G9LCK1N20StartDoc*/
/*}#1G9LCK1N20StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BoxFindFile=function(app,text,node,treeBox){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1G9LCK1N27LocalVals*/
	let isOpen=0;
	/*}#1G9LCK1N27LocalVals*/
	
	/*#{1G9LCK1N27PreState*/
	/*}#1G9LCK1N27PreState*/
	/*#{1G9LCK1N27PostState*/
	/*}#1G9LCK1N27PostState*/
	cssVO={
		"hash":"1G9LCK1N27",nameHost:true,
		"type":"button","x":0,"y":0,"w":"100%","h":24,"autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x","itemsAlign":1,
		children:[
			{
				"hash":"1IA0IJ1AA0",
				"type":BtnIcon("front",14,0,appCfg.sharedAssets+"/collapse.svg",null),"id":"BtnOpen","position":"relative","x":8,"y":7,"anchorX":1,"anchorY":1,
				/*#{1IA0IJ1AA0Codes*/
				OnClick(){
					self.OnClick();
				}
				/*}#1IA0IJ1AA0Codes*/
			},
			{
				"hash":"1G9LCO8R20",
				"type":"box","id":"BoxIcon","position":"relative","x":0,"y":0,"w":"","h":">calc(100% - 6px)","uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","background":cfgColor.fontToolSub,"maskImage":appCfg.sharedAssets+"/file.svg","aspect":"1",
			},
			{
				"hash":"1G9LCQVAR0",
				"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
				"text":text,"fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,
			}
		],
		/*#{1G9LCK1N27ExtraCSS*/
		/*}#1G9LCK1N27ExtraCSS*/
		faces:{
			"open":{
				/*BtnOpen*/"#1IA0IJ1AA0":{
					"rotate":90
				},
				/*#{1G9LD1PCG0Code*/
				$(){
					isOpen=1;
				}
				/*}#1G9LD1PCG0Code*/
			},"close":{
				/*BtnOpen*/"#1IA0IJ1AA0":{
					"rotate":0
				},
				/*#{1G9LD201P0Code*/
				$(){
					isOpen=0;
				}
				/*}#1G9LD201P0Code*/
			}
		},
		OnCreate:function(){
			self=this;
			
			/*#{1G9LCK1N27Create*/
			/*}#1G9LCK1N27Create*/
		},
		/*#{1G9LCK1N27EndCSS*/
		/*}#1G9LCK1N27EndCSS*/
	};
	/*#{1G9LCK1N27PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.OnClick=function(){
		if(isOpen){
			treeBox.closeNode(node);
		}else{
			treeBox.openNode(node);
		}
	}
	/*}#1G9LCK1N27PostCSSVO*/
	return cssVO;
};
/*#{1G9LCK1N27ExCodes*/
/*}#1G9LCK1N27ExCodes*/


/*#{1G9LCK1N20EndDoc*/
/*}#1G9LCK1N20EndDoc*/

export default BoxFindFile;
export{BoxFindFile};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearButton",
//	"jaxId": "1G9LCK1N20",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1G9LCK1N21",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1G9LCK1N22",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1IA0IC4GC0",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1G9LCK1N23",
//			"attrs": {
//				"app": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"text": {
//					"type": "string",
//					"valText": "/coke/disk.json (10)"
//				},
//				"node": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"treeBox": {
//					"type": "auto",
//					"valText": "null"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1G9LCK1N24",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1G9LCK1N25",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "VFACT document",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1G9LCK1N26",
//			"attrs": {
//				"open": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1G9LD1PCG0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1G9LD9RR30",
//							"attrs": {}
//						}
//					}
//				},
//				"close": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1G9LD201P0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1G9LD9RR31",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1IA0IC4GC1",
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "button",
//			"jaxId": "1G9LCK1N27",
//			"attrs": {
//				"properties": {
//					"jaxId": "1G9LCK1N28",
//					"attrs": {
//						"type": "button",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "24",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "true",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "[0,0,0,0]",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "\"\"",
//						"styleClass": "",
//						"enable": "true",
//						"drag": "NA",
//						"contentLayout": "Flex X",
//						"itemsAlign": "Center"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "Gear/@StdUI/ui/BtnIcon.js",
//							"jaxId": "1IA0IJ1AA0",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1IA0IMJNJ0",
//									"attrs": {
//										"style": "\"front\"",
//										"w": "14",
//										"h": "0",
//										"icon": "#appCfg.sharedAssets+\"/collapse.svg\"",
//										"colorBG": "null"
//									}
//								},
//								"properties": {
//									"jaxId": "1IA0IMJNJ1",
//									"attrs": {
//										"type": "#null#>BtnIcon(\"front\",14,0,appCfg.sharedAssets+\"/collapse.svg\",null)",
//										"id": "BtnOpen",
//										"position": "relative",
//										"x": "8",
//										"y": "7",
//										"display": "On",
//										"face": "",
//										"anchorH": "Center",
//										"anchorV": "Center"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1IA0IMJNJ2",
//									"attrs": {
//										"1G9LD1PCG0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IA0IMJNJ3",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IA0IMJNJ4",
//													"attrs": {
//														"rotate": {
//															"type": "number",
//															"valText": "90"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9LD1PCG0",
//											"faceTagName": "open"
//										},
//										"1G9LD201P0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IA0IMJNJ5",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IA0IMJNJ6",
//													"attrs": {
//														"rotate": {
//															"type": "number",
//															"valText": "0"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9LD201P0",
//											"faceTagName": "close"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1IA0IMJNJ7",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IA0IMJNJ8",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "true",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false",
//								"containerSlots": {
//									"jaxId": "1IA0IMJNJ9",
//									"attrs": {}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1G9LCO8R20",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G9LCV5EP4",
//									"attrs": {
//										"type": "box",
//										"id": "BoxIcon",
//										"position": "Relative",
//										"x": "0",
//										"y": "0",
//										"w": "",
//										"h": "100%-6",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "\"\"",
//										"styleClass": "",
//										"background": "#cfgColor.fontToolSub",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"maskImage": "#appCfg.sharedAssets+\"/file.svg\"",
//										"aspect": "1"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1G9LCV5EP5",
//									"attrs": {
//										"1G9LD1PCG0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9LD9RR36",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9LD9RR37",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9LD1PCG0",
//											"faceTagName": "open"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1G9LCV5EP6",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IA0IC4GC4",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1G9LCQVAR0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G9LCV5EP7",
//									"attrs": {
//										"type": "text",
//										"id": "",
//										"position": "Relative",
//										"x": "0",
//										"y": "0",
//										"w": "",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "\"\"",
//										"styleClass": "",
//										"color": "#cfgColor[\"fontBody\"]",
//										"text": "#text",
//										"font": "",
//										"fontSize": "#txtSize.smallMid",
//										"bold": "false",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Center",
//										"wrap": "false",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0",
//										"autoSizeW": "false",
//										"autoSizeH": "false"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1G9LCV5EP8",
//									"attrs": {
//										"1G9LD1PCG0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9LD9RR38",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9LD9RR39",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9LD1PCG0",
//											"faceTagName": "open"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1G9LCV5EP9",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IA0IC4GC5",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1G9LCK1N29",
//					"attrs": {
//						"1G9LD1PCG0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1G9LD9RR310",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G9LD9RR311",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1G9LD1PCG0",
//							"faceTagName": "open"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1G9LCK1N210",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1IA0IC4GC6",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1G9LCK1N211",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"enable": "false",
//				"drag": "false",
//				"innerLayout": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"face": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"marginL": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"marginR": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"marginT": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"marginB": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"paddingL": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"paddingT": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"paddingR": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"paddingB": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"attach": {
//					"type": "bool",
//					"valText": "false"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}