//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
import {BtnText} from "/@StdUI/ui/BtnText.js";
/*#{1HD3B4CR20StartDoc*/
import pathLib from "/@path";
import {tabOS,tabFS,tabNT} from "/@tabos";
import {mergeCodeWithSeg} from "../lib/codesegs.js";
import {BoxAIAsset} from "./BoxAIAsset.js";
import {assetDef} from "../AssetDef.js";
import {ChatSession} from "/@aichat/chatsession.js";

/**
* pLimit(max, gapWait)
* - 同时最多 max 个在跑
* - 初始可以立刻启动最多 max 个
* - 之后每次“新启动”至少间隔 gapWait 毫秒
*/
function pLimit(max, gapWait = 0) {
	let active = 0;
	const q = [];

	let initialBurstLeft = max;  // 允许一开始立刻启动 max 个
	let nextStartAt = 0;         // 下一次允许启动的时间戳（ms）

	function tryStartMore() {
		// 尽可能多地启动（会受 active/max、gapWait、队列影响）
		while (active < max && q.length > 0) {
			const now = Date.now();

			// 如果已经用完初始 burst，则需要满足 gapWait 节流
			if (initialBurstLeft <= 0 && gapWait > 0 && now < nextStartAt) {
				const waitMs = nextStartAt - now;

				// 安排一个“到点再尝试”的定时器，避免 busy loop
				setTimeout(tryStartMore, waitMs);
				return;
			}

			const job = q.shift();
			startJob(job);
		}
	}

	async function startJob(job) {
		active++;

		// 记录启动时间：初始 burst 不受 gapWait 限制
		if (initialBurstLeft > 0) {
			initialBurstLeft--;
		} else if (gapWait > 0) {
			nextStartAt = Date.now() + gapWait;
		}

		try {
			const v = await job.fn();
			job.resolve(v);
		} catch (e) {
			job.reject(e);
		} finally {
			active--;
			tryStartMore();
		}
	}

	return (fn) =>
	new Promise((resolve, reject) => {
		q.push({ fn, resolve, reject });
		tryStartMore();
	});
}
/*}#1HD3B4CR20StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let DlgAICoder=function(){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let boxBG,btnPlatform,txtPlatform,btnModel,txtModel,boxAssets,btnAssets,btnOpenAssets,btnSaveAssets,btnCodeMode,txtCodeMode,btnCodeTask,edPrompt,btnStart,boxCodeFrame,boxCode,boxFooter;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1HD3B4CR21LocalVals*/
	let app=VFACT.app;
	let dlgVO=null;
	let cm=null;
	let docObj=null;
	let codyDoc=null;
	let orgCode="";
	let newCode="";
	let editBox="";
	
	let aiModel={platform:"OpenAI",model:"gpt-5"};
	let codeMode="Cursor";
	let assets=[];
	/*}#1HD3B4CR21LocalVals*/
	
	/*#{1HD3B4CR21PreState*/
	/*}#1HD3B4CR21PreState*/
	/*#{1HD3B4CR21PostState*/
	/*}#1HD3B4CR21PostState*/
	cssVO={
		"hash":"1HD3B4CR21",nameHost:true,
		"type":"hud","x":"50%","y":"50%","w":"90%","h":"","anchorX":1,"anchorY":1,"padding":10,"minW":320,"minH":"","maxW":800,"maxH":"","styleClass":"","contentLayout":"flex-y",
		children:[
			{
				"hash":"1HD3B5UBD0",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":[255,255,255,1],"border":1,
				"corner":6,"shadow":true,"shadowY":6,"shadowBlur":8,"shadowColor":[0,0,0,0.3],
			},
			{
				"hash":"1HD3BAJND0",
				"type":"text","id":"TxtTitle","position":"relative","x":0,"y":0,"w":"100%","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodySub"],
				"text":(($ln==="CN")?("AI 编码"):("AI Coding")),"fontSize":txtSize.smallBig,"fontWeight":"bold","fontStyle":"normal","textDecoration":"",
			},
			{
				"hash":"1J7NT8F6D0",
				"type":"hud","id":"BoxStartOpts","position":"relative","x":0,"y":0,"w":"100%","h":"","padding":5,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"contentLayout":"flex-y",
				children:[
					{
						"hash":"1J7NVHQIU0",
						"type":"box","position":"relative","x":0,"y":0,"w":"100%","h":1,"margin":[0,0,10,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["fontBodyLit"],
					},
					{
						"hash":"1J7NTALEN0",
						"type":"hud","id":"LineModel","position":"relative","x":0,"y":0,"w":"100%","h":30,"padding":[0,0,0,15],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						"contentLayout":"flex-x","itemsAlign":1,
						children:[
							{
								"hash":"1J7NTJ6AI0",
								"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
								"text":(($ln==="CN")?("AI模型:"):("AI Model:")),"fontWeight":"bold","fontStyle":"normal","textDecoration":"",
							},
							{
								"hash":"1J7NTDIT50",
								"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/btncombo.svg",null),"id":"BtnPlatform","position":"relative","x":0,"y":0,
								"OnClick":function(event){
									self.choosePlatform(this,event);
								},
							},
							{
								"hash":"1J7NTBD3G0",
								"type":"text","id":"TxtPlatform","position":"relative","x":0,"y":0,"w":"","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
								"text":(($ln==="CN")?("OpenAI"):("OpenAI")),"fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
							},
							{
								"hash":"1J7NTEKHL0",
								"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/btncombo.svg",null),"id":"BtnModel","position":"relative","x":0,"y":0,"margin":[0,0,0,3],
								"OnClick":function(event){
									self.chooseModel(this,event);
								},
							},
							{
								"hash":"1J7NTF21L0",
								"type":"text","id":"TxtModel","position":"relative","x":0,"y":0,"w":"","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
								"text":(($ln==="CN")?("GPT-5"):("GPT-5")),"fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
							}
						],
					},
					{
						"hash":"1JF30H78O0",
						"type":"hud","id":"BoxAssets","position":"relative","x":0,"y":0,"w":"100%","h":"","overflow":"auto-y","padding":[0,15,0,15],"minW":"","minH":"",
						"maxW":"","maxH":300,"styleClass":"","contentLayout":"flex-y",
					},
					{
						"hash":"1J7NTMJK10",
						"type":"hud","id":"LineAssets","position":"relative","x":0,"y":0,"w":"100%","h":24,"margin":[5,0,0,0],"padding":[0,15,0,15],"minW":"","minH":"",
						"maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x","itemsAlign":1,
						children:[
							{
								"hash":"1J7NTMJK20",
								"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/inc.svg",null),"id":"BtnAssets","position":"relative","x":0,"y":0,
								"OnClick":function(event){
									self.addAsset(this,event);
								},
							},
							{
								"hash":"1J7NTMJK12",
								"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
								"text":(($ln==="CN")?("添加附件"):("Add assets")),"fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","flex":true,
							},
							{
								"hash":"1JF3O91Q40",
								"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/folder.svg",null),"id":"BtnOpenAssets","position":"relative","x":0,"y":0,
								"tip":(($ln==="CN")?("打开附件组"):("Open assets")),
								"OnClick":function(event){
									self.OnLoadAssets(this,event);
								},
							},
							{
								"hash":"1JF3OA4HC0",
								"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/save.svg",null),"id":"BtnSaveAssets","position":"relative","x":0,"y":0,
								"tip":(($ln==="CN")?("保存附件组"):("Save assets")),
								"OnClick":function(event){
									self.OnSaveAssets(this,event);
								},
							}
						],
					},
					{
						"hash":"1J7NTQQCC0",
						"type":"hud","id":"LinePrompt","position":"relative","x":0,"y":0,"w":"100%","h":"","margin":[5,0,0,0],"padding":[0,10,0,5],"minW":"","minH":30,"maxW":"",
						"maxH":"","styleClass":"","contentLayout":"flex-x",
						children:[
							{
								"hash":"1J7NTSQ0C0",
								"type":"box","id":"BoxInputFrame","position":"relative","x":0,"y":0,"w":"100%","h":"","margin":[0,0,0,5],"padding":[5,5,5,5],"minW":"","minH":"",
								"maxW":"","maxH":"","styleClass":"","background":cfgColor["body"],"corner":6,"shadow":true,"shadowX":0,"shadowBlur":5,"shadowSpread":3,"shadowColor":[0,0,0,0.25],
								"flex":true,"contentLayout":"flex-x","itemsAlign":1,
								children:[
									{
										"hash":"1J7NU7CSQ0",
										"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/btncombo.svg",null),"id":"BtnCodeMode","position":"relative","x":0,"y":0,
										"OnClick":function(event){
											self.chooseMode(this,event);
										},
									},
									{
										"hash":"1J7NV7KE80",
										"type":"text","id":"TxtCodeMode","position":"relative","x":0,"y":0,"w":"","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodySub"],
										"text":"在光标处：","fontSize":txtSize.smallMid,"fontWeight":"bold","fontStyle":"normal","textDecoration":"",
									},
									{
										"hash":"1J7V6HGCU0",
										"type":BtnIcon("front",24,0,appCfg.sharedAssets+"/btncombo.svg",null),"id":"BtnCodeTask","position":"relative","x":0,"y":0,
										"OnClick":function(event){
											self.chooseTask(this,event);
										},
									},
									{
										"hash":"1J7NU25LJ0",
										"type":"memo","id":"EdPrompt","position":"relative","x":0,"y":0,"w":200,"h":"","minW":"","minH":25,"maxW":"","maxH":300,"styleClass":"","color":[0,0,0],
										"fontSize":txtSize.smallMid,"outline":0,"border":[0,0,1,0],"borderColor":[0,0,0,1],"flex":true,
										"OnInput":function(){
											/*#{1J7O5VU810FunctionBody*/
											/*}#1J7O5VU810FunctionBody*/
										},
										"OnKeyDown":function(event){
											/*#{1J7O6064H0FunctionBody*/
											if(event.code==="Enter"){
												if((!event.isComposing) &&(!event.shiftKey)){
													event.stopPropagation();
													event.preventDefault();
													self.startCoding();
												}
											}
											/*}#1J7O6064H0FunctionBody*/
										},
									},
									{
										"hash":"1J7NTUH550",
										"type":BtnIcon("front",30,0,appCfg.sharedAssets+"/run.svg",null),"id":"BtnStart","position":"relative","x":0,"y":0,
										"OnClick":function(event){
											self.startCoding(this,event);
										},
									}
								],
							}
						],
					}
				],
			},
			{
				"hash":"1HD3BC0360",
				"type":"hud","id":"BoxCodeFrame","position":"relative","x":0,"y":0,"w":"100%","h":"","display":0,"margin":[10,0,0,0],"padding":1,"minW":"","minH":"",
				"maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
				children:[
					{
						"hash":"1HD3BEJ1V0",
						"type":"box","id":"BoxCodeBG","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["body"],
						"border":1,
					},
					{
						"hash":"1HD3BG7QU0",
						"type":"box","id":"BoxHeader","position":"relative","x":0,"y":0,"w":"100%","h":16,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["fontSecondarySub"],
						"border":[0,0,1,0],"borderColor":cfgColor["fontBody"],
					},
					{
						"hash":"1HD3BIMSS0",
						"type":"hud","id":"BoxCode","position":"relative","x":0,"y":0,"w":"100%","h":300,"minW":"","minH":"","maxW":"","maxH":300,"styleClass":"",
					},
					{
						"hash":"1HD3BL81T0",
						"type":"box","id":"BoxFooter","position":"relative","x":0,"y":0,"w":"100%","h":8,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["secondary"],
						"borderColor":cfgColor["fontBody"],
					}
				],
			},
			{
				"hash":"1HD3PUF820",
				"type":"hud","id":"BoxButtons","position":"relative","x":0,"y":0,"w":"100%","h":30,"margin":[10,0,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"contentLayout":"flex-x","itemsAlign":1,"subAlign":1,"itemsWrap":1,
				children:[
					{
						"hash":"1HD3PVC7N0",
						"type":BtnText("success",100,25,"Apply",false,""),"position":"relative","x":0,"y":0,"corner":3,
						"OnClick":function(event){
							/*#{1HD4061LH0FunctionBody*/
							self.applyCode();
							/*}#1HD4061LH0FunctionBody*/
						},
					},
					{
						"hash":"1HD3Q2UAE0",
						"type":BtnText("warning",100,25,"Cancel",false,""),"position":"relative","x":0,"y":0,"margin":[0,0,0,20],"corner":3,
						"OnClick":function(event){
							/*#{1HD405KCP0FunctionBody*/
							self.close();
							/*}#1HD405KCP0FunctionBody*/
						},
					}
				],
			}
		],
		/*#{1HD3B4CR21ExtraCSS*/
		/*}#1HD3B4CR21ExtraCSS*/
		faces:{
			"start":{
				/*TxtTitle*/"#1HD3BAJND0":{
					"text":(($ln==="CN")?("AI Coding"):("AI 编码"))
				},
				/*BoxStartOpts*/"#1J7NT8F6D0":{
					"display":1
				},
				/*EdPrompt*/"#1J7NU25LJ0":{
					"readOnly":false
				},
				/*BtnStart*/"#1J7NTUH550":{
					"enable":true
				},
				/*BoxCodeFrame*/"#1HD3BC0360":{
					"display":0
				},
				"#1HD3PVC7N0":{
					"display":0
				},
				"#1HD3Q2UAE0":{
					"enable":true
				}
			},"wait":{
				/*TxtTitle*/"#1HD3BAJND0":{
					"text":(($ln==="CN")?("AI正在编写代码……"):("AI is coding..."))
				},
				/*BoxStartOpts*/"#1J7NT8F6D0":{
					"display":0
				},
				/*BoxCodeFrame*/"#1HD3BC0360":{
					"display":0
				},
				/*BoxButtons*/"#1HD3PUF820":{
					"display":0
				}
			},"code":{
				/*TxtTitle*/"#1HD3BAJND0":{
					"text":(($ln==="CN")?("请检查AI编写的代码"):("Please review AI's code"))
				},
				/*BoxStartOpts*/"#1J7NT8F6D0":{
					"display":0
				},
				/*BoxCodeFrame*/"#1HD3BC0360":{
					"display":1
				},
				/*BoxButtons*/"#1HD3PUF820":{
					"display":1
				},
				"#1HD3PVC7N0":{
					"display":1
				},
				"#1HD3Q2UAE0":{
					"enable":true
				}
			},"index":{
				/*EdPrompt*/"#1J7NU25LJ0":{
					"readOnly":true
				},
				/*BtnStart*/"#1J7NTUH550":{
					"enable":false
				},
				"#1HD3Q2UAE0":{
					"display":1,"enable":false
				}
			}
		},
		OnCreate:function(){
			self=this;
			boxBG=self.BoxBG;btnPlatform=self.BtnPlatform;txtPlatform=self.TxtPlatform;btnModel=self.BtnModel;txtModel=self.TxtModel;boxAssets=self.BoxAssets;btnAssets=self.BtnAssets;btnOpenAssets=self.BtnOpenAssets;btnSaveAssets=self.BtnSaveAssets;btnCodeMode=self.BtnCodeMode;txtCodeMode=self.TxtCodeMode;btnCodeTask=self.BtnCodeTask;edPrompt=self.EdPrompt;btnStart=self.BtnStart;boxCodeFrame=self.BoxCodeFrame;boxCode=self.BoxCode;boxFooter=self.BoxFooter;
			/*#{1HD3B4CR21Create*/
			VFACT.applyMoveDrag(boxBG,self);
			/*}#1HD3B4CR21Create*/
		},
		/*#{1HD3B4CR21EndCSS*/
		/*}#1HD3B4CR21EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.choosePlatform=async function(){
		/*#{1J7O0NN2I0Start*/
		let items,item;
		async function getPlatforms(){
			let res,list;
			res=await tabNT.makeCall("AIGetPlatforms",{});
			if(!res||res.code!==200){
				return [
					["OpenAI","OpenAI","OpenAI"],
					["Google","Google","Google"],
					["Claude","Claude","Claude"],
					["Ollama","Ollama","Ollama"],
				].map((item)=>{
					return {text:item[2],platform:item[0]};
				});
			}else{
				list=res.platforms;
				return list.map((item)=>{
					return {text:item,platform:item};
				});
			}
		};
		btnPlatform.enable=false;
		items=await getPlatforms();
		item=await app.modalDlg("/@StdUI/ui/DlgMenu.js",{
			items:items,hud:btnPlatform
		});
		if(!item){
			btnPlatform.enable=true;
			return;
		}
		aiModel.platform=item.platform;
		txtPlatform.text=item.text;
		btnPlatform.enable=true;
		self.chooseModel();
		/*}#1J7O0NN2I0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.chooseModel=async function(){
		/*#{1J7O0O5I60Start*/
		let items,item;
		async function getModels(){
			let platform;
			platform=aiModel.platform;
			let res=await tabNT.makeCall("AIGetModels",{platform:platform});
			if(res && res.code===200){
				let list=res.models;
				list=list.map((item)=>{
					return {text:item.label,model:item.model};
				});
				return list;
			}
			switch(platform){
				default:
				case "OpenAI":{
					return [
						["gpt-5-codex","GPT-5-CodeX","GPT-5 CodeX"],
						["gpt-5","GPT-5","GPT-5 Standard"],
						["gpt-5-mini","GPT-5-Mini","GPT-5 Mini"],
					].map((item)=>{
						return {text:item[2],model:item[0]};
					});
				}
				case "Google":{
					return [
						["gemini-pro","Gemini Pro","Gemini Pro"],
					].map((item)=>{
						return {text:item[2],model:item[0]};
					});
				}
				case "Claude":{
					return [
						["claude-3-7-sonnet-latest","Claude 3.7 Sonnet","Claude 3.7 Sonnet"],
						["claude-3-5-sonnet-latest","Claude 3.5 Sonnet","Claude 3.5 Sonnet"],
					].map((item)=>{
						return {text:item[2],model:item[0]};
					});
				}
			}
		}
		btnModel.enable=false;
		items=await getModels();
		item=await app.modalDlg("/@StdUI/ui/DlgMenu.js",{
			items:items,hud:btnModel
		});
		if(!item){
			btnModel.enable=true;
			return;
		}
		aiModel.model=item.model;
		txtModel.text=item.text;
		btnModel.enable=true;
		callAfter(()=>{edPrompt.focus();});
		/*}#1J7O0O5I60Start*/
	};
	//------------------------------------------------------------------------
	cssVO.chooseMode=async function(){
		/*#{1J7O0SS210Start*/
		let items,item,cursorPos,selRange;
		cursorPos=editBox.getCursorIndex();
		selRange=editBox.getSelectionRange();
		items=[
			{text:(($ln==="CN")?("在光标处"):/*EN*/("Code at cursor")),mode:"Cursor"},
			{text:(($ln==="CN")?("选中区域"):/*EN*/("Code with selection")),mode:"Selection"},
			{text:(($ln==="CN")?("整个文件"):/*EN*/("Code with doc")),mode:"Doc"},
		];
		items[0].enable=cursorPos>=0;
		items[1].enable=!!selRange;
		item=await app.modalDlg("/@StdUI/ui/DlgMenu.js",{
			items:items,hud:btnCodeMode
		});
		if(!item){
			return;
		}
		codeMode=item.mode;
		txtCodeMode.text=item.text;
		switch(codeMode){
			case "Cursor":{
				edPrompt.text=(($ln==="CN")?("写代码"):/*EN*/("Write code"));
				break;
			}
			case "Selection":{
				edPrompt.text=(($ln==="CN")?("完善/重写选中的代码"):/*EN*/("Refine or rewrite the selected code"));
				break;
			}
			case "Doc":{
				edPrompt.text=(($ln==="CN")?("修改Bug: "):/*EN*/("Debug: "));
				break;
			}
		}
		callAfter(()=>{edPrompt.focus();});
		/*}#1J7O0SS210Start*/
	};
	//------------------------------------------------------------------------
	cssVO.chooseTask=async function(){
		/*#{1J7V6JRB60Start*/
		let items,item;
		switch(codeMode){
			case "Cursor":{
				items=[
					{text:(($ln==="CN")?("写代码"):/*EN*/("Write code"))},
					{text:(($ln==="CN")?("写注释"):/*EN*/("Write comment"))},
				];
				break;
			}
			case "Selection":{
				items=[
					{text:(($ln==="CN")?("完善/重写选中的代码"):/*EN*/("Refine or rewrite the selected code"))},
					{text:(($ln==="CN")?("指出选中的代码中存在的问题/Bug"):/*EN*/("Point out bugs/issue in the selected code"))},
					{text:(($ln==="CN")?("简化选中的代码"):/*EN*/("Simplify selected code"))},
					{text:(($ln==="CN")?("为选中的代码编写/添加注释"):/*EN*/("Write / improve / add comments for selected code"))},
				];
				break;
			}
			default:{
				items=[
					{text:(($ln==="CN")?("修改Bug: "):/*EN*/("Debug: "))},
					{text:(($ln==="CN")?("指出代码中存在的问题/Bug"):/*EN*/("Point out bugs/issue in the code"))},
					{text:(($ln==="CN")?("总结代码"):/*EN*/("Summarize code"))},
					{text:(($ln==="CN")?("给出下一步工作的建议"):/*EN*/("Provide recommendations for the next coding steps"))},
					{text:(($ln==="CN")?("为代码编写/添加注释"):/*EN*/("Write / improve / add comments for the code"))},
				];
				break;
			}
		}
		item=await app.modalDlg("/@StdUI/ui/DlgMenu.js",{
			items:items,hud:btnCodeMode
		});
		if(!item){
			return;
		}
		edPrompt.text=item.text;
		callAfter(()=>{edPrompt.focus();});
		/*}#1J7V6JRB60Start*/
	};
	//------------------------------------------------------------------------
	cssVO.loadAssets=async function(jsonPath){
		/*#{1JF3OR3CJ0Start*/
		let docPath,editPrj,prjPath;
		let docAssets,asset;
		boxAssets.clearChildren();
		if(!jsonPath){
			docPath=docObj.path;
			editPrj=app.prj;
			prjPath=editPrj.path;
			docPath=pathLib.relative(prjPath,docPath);
			jsonPath=docPath.replaceAll("/","_");
			jsonPath=jsonPath.replaceAll(".","_");
			jsonPath=pathLib.join(prjPath,".aiindex",jsonPath);
			jsonPath+=".json";
		}
		try{
			docAssets=await tabFS.readFile(jsonPath,"utf8");
			docAssets=JSON.parse(docAssets);
		}catch(err){
			docAssets=null;
		}
		if(!docAssets || !docAssets.assets){
			return;
		}
		docAssets=docAssets.assets;
		for(asset of docAssets){
			//Add asset line
			boxAssets.appendNewChild({
				type:BoxAIAsset(asset),position:"relative"
			});
		}
		/*}#1JF3OR3CJ0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.saveAssets=async function(jsonPath){
		/*#{1JF3OKDRA0Start*/
		let docPath,editPrj,prjPath,jsonDir;
		let lines,i,n,docAssets;
		docAssets=[];
		lines=boxAssets.children;
		n=lines.length;
		for(i=0;i<n;i++){
			docAssets.push(lines[i].file);
		}
		docAssets={assets:docAssets};
		if(!jsonPath){
			docPath=docObj.path;
			editPrj=app.prj;
			prjPath=editPrj.path;
			docPath=pathLib.relative(prjPath,docPath);
			jsonPath=docPath.replaceAll("/","_");
			jsonPath=jsonPath.replaceAll(".","_");
			jsonDir=pathLib.join(prjPath,".aiindex");
			jsonPath=pathLib.join(jsonDir,jsonPath);
			jsonPath+=".json";
		}
		await tabFS.writeFile(jsonPath,JSON.stringify(docAssets,null,"\t"),"utf8");
		/*}#1JF3OKDRA0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.addAsset=async function(){
		/*#{1J7O0QKAJ0Start*/
		let path,files;
		path=app.prj.path;
		files=await app.modalDlg("/@StdUI/ui/DlgFile.js",{
			mode:"Open",title:"Add asset file",path:path,multiSelect:true
		});
		if(!path){
			return;
		}
		if(Array.isArray(files)){
			for(path of files){
				boxAssets.appendNewChild({type:BoxAIAsset({path:path,active:true,type:"ref"}),position:"relative"});
			}
		}else{
			boxAssets.appendNewChild({type:BoxAIAsset({path:files,active:true,type:"ref"}),position:"relative"});
		}
		/*}#1J7O0QKAJ0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.openAssets=async function(){
		/*#{1JF3OK46B0Start*/
		/*}#1JF3OK46B0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.removeAsset=async function(){
		/*#{1J7O0R0FB0Start*/
		/*}#1J7O0R0FB0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.indexAsset=async function(file,assets,line){
		/*#{1JF52TT0O0Start*/
		let codes,path,prjDir,codePath,codeDir;
		path=file.path;
		codePath=docObj.path;
		codeDir=pathLib.dirname(codePath);
		prjDir=app.prj.path;
		if(file.active){
			if(file.type!=="image"){
				codes=await tabFS.readFile(path,"utf8");
				if(codes){
					if(path.startsWith(prjDir)){
						path=pathLib.relative(codeDir,path);
					}
					if(file.digest==="index"){
						let index;
						line && line.showFace("working");
						try{
							index=await ChatSession.execAgent(null,null,"/@tabedit/ai/IndexSource.js",{path:file.path});
							if(index){
								assets.push({path:path,digest:file.digest,index:index,typeDesc:assetDef[file.type]||file.type,type:file.type});
							}
						}catch(err){
							console.log("Index source code error:",err);
						}
						line && line.showFace("ready");
					}else if(file.digest==="abridge"){
						let index;
						line && line.showFace("working");
						try{
							index=await ChatSession.execAgent(null,null,"/@tabedit/ai/AbridgeSource.js",{path:file.path});
							if(index){
								assets.push({path:path,digest:file.digest,abridged:index,typeDesc:assetDef[file.type]||file.type,type:file.type});
							}
						}catch(err){
							console.log("Abridge source code error:",err);
						}
						line && line.showFace("ready");
					}else{
						assets.push({path:path,codes:codes,typeDesc:assetDef[file.type]||file.type,type:file.type});
					}
				}
			}else{
				//TODO: Code this images.
			}
		}
		/*}#1JF52TT0O0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.startCoding=async function(){
		/*#{1J7O0T50L0Start*/
		let cursorPos,selRange,preCode,postCode,callCode,callBot,prompt,result,mergedCode;
		let assets;
		cursorPos=editBox.getCursorIndex();
		selRange=editBox.getSelectionRange();
		preCode=postCode="";
		prompt=edPrompt.text||"Go";
		self.showFace("index");
		{
			let lines,i,n,path,codes,prjDir,codePath,codeDir;
			assets=[];
			codePath=docObj.path;
			codeDir=pathLib.dirname(codePath);
			prjDir=app.prj.path;
			lines=boxAssets.children;
			n=lines.length;
			if(n>0){
				const limit = pLimit(3, 1000);
				const pms=[];
				for(i=0;i<n;i++){
					const line=lines[i];
					line.showFace("wait");					
				}
				for(i=0;i<n;i++){
					const line=lines[i];
					const file=line.file;
					pms.push(limit(() => self.indexAsset(file, assets, line)));
				}
				await Promise.all(pms);
				if(!assets.length){
					assets=null;
				}
			}
		}
		switch(codeMode){
			case "Cursor":{
				if(cursorPos>=0){
					preCode=orgCode.substring(0,cursorPos);
					postCode=orgCode.substring(cursorPos);
					callCode=orgCode.substring(0,cursorPos)+"[-AI-]"+orgCode.substring(cursorPos);
				}else{
					//TODO: Tell user no cursor?
					return;
				}
				callCode=`<code>\n${callCode}\n</code>\n\n<instruction>\n${prompt}\n</instruction>`;
				callBot="ai/CodeAtCursor.js";
				break;
			}
			case "Selection":{
				if(selRange){
					preCode=orgCode.substring(0,selRange[0]);
					postCode=orgCode.substring(selRange[1]);
					callCode=orgCode.substring(0,selRange[0])+"[-AI->]"+orgCode.substring(selRange[0],selRange[1])+"[<-AI-]"+orgCode.substring(selRange[1]);
					callCode=`<code>\n${callCode}\n</code>\n\n<instruction>\n${prompt}\n</instruction>`;
				}else{
					//TODO: Tell user no range?
					return;
				}
				callBot="ai/CodeWithSelection.js";
				break;
			}
			default:
			case "Doc":{
				preCode="";
				postCode="";
				callCode=orgCode;
				callCode=`<code>\n${callCode}\n</code>\n\n<instruction>\n${prompt}\n</instruction>`;
				callBot="ai/CodeWithDoc.js";
				break;
			}
		}
		self.showFace("wait");
		result=await app.modalDlg(pathLib.join("/@aichat/ui/DlgAIChat.js"),{
			url:app.path2AppURL(callBot),
			prompt:{
				code:callCode,
				plaform:aiModel.platform,
				model:aiModel.model,
				assets:assets
			},
			clearChat:true,
			allowEmptyChat:false,
			allowReset:false,
			autoClose:true
		});
		if(result){
			console.log(result);
			if(result && result.replaceCode){
				newCode=result.replaceCode;
			}else{
				return false;
			}
			newCode=preCode+newCode+postCode;
			if(codyDoc){
				mergedCode=mergeCodeWithSeg(orgCode,newCode,{});
				newCode=mergedCode;
			}
		}
		if(newCode){
			self.showFace("code");
			callAfter(self.showCode);
		}else{
			self.close();
		}
		/*}#1J7O0T50L0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.OnLoadAssets=async function(){
		/*#{1JF5279TH0Start*/
		let path;
		path=app.prj.path;
		path=await app.modalDlg("/@StdUI/ui/DlgFile.js",{
			mode:"Open",path:path,filter:["*.json"],title:"Open assets"
		});
		if(!path){
			return;
		}
		await self.loadAssets(path);
		/*}#1JF5279TH0Start*/
	};
	//------------------------------------------------------------------------
	cssVO.OnSaveAssets=async function(){
		/*#{1JF527NER0Start*/
		let path;
		path=app.prj.path;
		path=await app.modalDlg("/@StdUI/ui/DlgFile.js",{
			mode:"Save",path:path,filter:["*.json"],title:"Save assets"
		});
		if(!path){
			return;
		}
		await self.saveAssets(path);
		/*}#1JF527NER0Start*/
	};
	/*#{1HD3B4CR21PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.showDlg=function(vo){
		let cursorPos,selRange;
		dlgVO=vo;
		docObj=vo.doc;
		codyDoc=docObj.codyDoc;
		editBox=docObj.editBox;
		orgCode=docObj.getDocText();
		cursorPos=editBox.getCursorIndex();
		selRange=editBox.getSelectionRange();
		if(selRange){
			codeMode="Selection";
			txtCodeMode.text=(($ln==="CN")?("选中区域"):/*EN*/("Code with selection"));
			edPrompt.text=(($ln==="CN")?("完善/重写选中的代码"):/*EN*/("Refine or rewrite the selected code"));
		}else if(cursorPos>=0){
			codeMode="Cursor";
			txtCodeMode.text=(($ln==="CN")?("在光标处"):/*EN*/("Code at cursor"));
			edPrompt.text=(($ln==="CN")?("写代码"):/*EN*/("Write code"));
		}else{
			codeMode="Doc";
			txtCodeMode.text=(($ln==="CN")?("整个文件"):/*EN*/("Code with doc"));
			edPrompt.text=(($ln==="CN")?("指出代码中存在的问题/Bug"):/*EN*/("Point out bugs/issue in the code"));
		}
		self.showFace("start");
		self.loadAssets();
		callAfter(()=>{edPrompt.focus();});
		return;
	};
	
	//------------------------------------------------------------------------
	cssVO.execAI=async function(){
		let action,cursorPos,selRange,result,callCode,callBot;
		let resVO,mergedCode,aiChat,preCode,postCode;
		aiChat=app.aiChat;
		action=dlgVO.action;
		cursorPos=editBox.getCursorIndex();
		selRange=editBox.getSelectionRange();
		if(!action){
			if(selRange){
				action="Range";
			}else{
				if(cursorPos>=0){
					action="Cursor";
				}else{
					action="Fixer";
				}
			}
		}
		preCode=postCode="";
		switch(action){
			case "Cursor":{
				if(cursorPos>=0){
					preCode=orgCode.substring(0,cursorPos);
					postCode=orgCode.substring(cursorPos);
					callCode=orgCode.substring(0,cursorPos)+"[-AI-]"+orgCode.substring(cursorPos);
				}else{
					//TODO: Tell user no cursor?
					return;
				}
				callBot="ai/CodeAtCursor.js";
				break;
			}
			case "Range":{
				if(selRange){
					preCode=orgCode.substring(0,selRange[0]);
					postCode=orgCode.substring(selRange[1]);
					callCode=orgCode.substring(0,selRange[0])+"[-AI->]"+orgCode.substring(selRange[0],selRange[1])+"[<-AI-]"+orgCode.substring(selRange[1]);
				}else{
					//TODO: Tell user no range?
					return;
				}
				callBot="ai/CodeAtRange.js";
				break;
			}
			default:
			case "Refine":{
				preCode="";
				postCode="";
				callCode="[-AI->]"+orgCode+"[<-AI-]";
				callBot="ai/CodeAtRange.js";
				break;
			}
		}
		result=await app.modalDlg(pathLib.join("/@aichat/ui/DlgAIChat.js"),{
			url:app.path2AppURL(callBot),
			prompt:callCode,
			clearChat:true,
			allowEmptyChat:false,
			allowReset:false,
			autoClose:true
		});
		if(result){
			console.log(result);
			if(typeof(result)==="string"){
				resVO=aiChat.parseCodes(result);
				if(!resVO.codes || !resVO.codes[0]){
					return false;
				}
				newCode=resVO.codes[0][1];
				newCode=newCode.trimLeft();
				let prefix;
				prefix="javascript\n";
				if(newCode.startsWith(prefix)){
					newCode=newCode.substring(prefix.length);
				}
				prefix="js\n";
				if(newCode.startsWith(prefix)){
					newCode=newCode.substring(prefix.length);
				}
			}else if(result && result.replaceCode){
				newCode=result.replaceCode;
			}else{
				return false;
			}
			newCode=preCode+newCode+postCode;
			if(codyDoc){
				mergedCode=mergeCodeWithSeg(orgCode,newCode,{});
				newCode=mergedCode;
			}
			return true;
		}
		return false;
	};
	
	//------------------------------------------------------------------------
	cssVO.showCode=async function(){
		let dv,code;
		let target = boxCode.webObj;
		await VFACT.appendScript("/@codemirror/extern/diff_match_patch.js");
		await VFACT.appendScript("/@codemirror/addon/merge.js");
		target.innerHTML = "";
		dv = CodeMirror.MergeView(target, {
			value: newCode,
			orig: orgCode,
			lineNumbers: true,
			mode: "text",
			highlightDifferences: true,
			connect: true,
			collapseIdentical: 5
		});
		cm=dv.edit;
	};
	
	//------------------------------------------------------------------------
	cssVO.applyCode=function(){
		newCode=cm?cm.doc.getValue():orgCode;
		if(!newCode){
			return false;
		}
		editBox.setEditText(newCode,true);
		self.close();
	};
	
	//------------------------------------------------------------------------
	cssVO.close=function(){
		self.saveAssets();
		app.closeDlg(self);
	};
	
	//------------------------------------------------------------------------
	cssVO.OnKeyDown=function(key,evt){
		if(key==="Escape"){
			app.closeDlg(self);
			return true;
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.handleShortcut=function(cmd){
		if(cmd==="Escape"){
			app.closeDlg(self);
			return true;
		}
	};
	
	/*}#1HD3B4CR21PostCSSVO*/
	cssVO.constructor=DlgAICoder;
	return cssVO;
};
/*#{1HD3B4CR21ExCodes*/
/*}#1HD3B4CR21ExCodes*/

//----------------------------------------------------------------------------
DlgAICoder.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1HD3B4CR21PreAISpot*/
	/*}#1HD3B4CR21PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1HD3B4CR21PostAISpot*/
	/*}#1HD3B4CR21PostAISpot*/
	return exposeVO;
};

/*#{1HD3B4CR20EndDoc*/
/*}#1HD3B4CR20EndDoc*/

export default DlgAICoder;
export{DlgAICoder};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1HD3B4CR20",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1HD3B4CR30",
//			"attrs": {
//				"device": "Desktop 800x600",
//				"screenW": "800",
//				"screenH": "600",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1HD3B4CR31",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1HD3B4CR32",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1HD3B4CR33",
//			"attrs": {}
//		},
//		"localVars": {
//			"jaxId": "1HD3B4CR34",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1HD3B4CR35",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1J7O0NN2I0",
//					"attrs": {
//						"id": "choosePlatform",
//						"label": "New AI Seg",
//						"x": "65",
//						"y": "85",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1J7O0O1HB0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1J7O0O1HB1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1J7O0O1HB2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1J7O0O5I60",
//					"attrs": {
//						"id": "chooseModel",
//						"label": "New AI Seg",
//						"x": "305",
//						"y": "85",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1J7O0QEDQ0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1J7O0QEDQ1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1J7O0QEDQ2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1J7O0SS210",
//					"attrs": {
//						"id": "chooseMode",
//						"label": "New AI Seg",
//						"x": "65",
//						"y": "305",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1J7O0T38B0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1J7O0T38B1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1J7O0T38B2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1J7V6JRB60",
//					"attrs": {
//						"id": "chooseTask",
//						"label": "New AI Seg",
//						"x": "540",
//						"y": "85",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1J7V6K5GI0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1J7V6K5GI1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1J7V6K5GI2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1JF3OR3CJ0",
//					"attrs": {
//						"id": "loadAssets",
//						"label": "New AI Seg",
//						"x": "65",
//						"y": "190",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1JF3ORQLM0",
//							"attrs": {
//								"jsonPath": {
//									"type": "string",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1JF3ORQLM1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1JF3ORQLM2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1JF3OKDRA0",
//					"attrs": {
//						"id": "saveAssets",
//						"label": "New AI Seg",
//						"x": "305",
//						"y": "190",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1JF3OKIOH3",
//							"attrs": {
//								"jsonPath": {
//									"type": "string",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1JF3OKIOH4",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1JF3OKIOH5",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1J7O0QKAJ0",
//					"attrs": {
//						"id": "addAsset",
//						"label": "New AI Seg",
//						"x": "540",
//						"y": "190",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1J7O0R7150",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1J7O0R7151",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1J7O0R7152",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1JF3OK46B0",
//					"attrs": {
//						"id": "openAssets",
//						"label": "New AI Seg",
//						"x": "1005",
//						"y": "190",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1JF3OKIOH0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1JF3OKIOH1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1JF3OKIOH2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1J7O0R0FB0",
//					"attrs": {
//						"id": "removeAsset",
//						"label": "New AI Seg",
//						"x": "775",
//						"y": "190",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1J7O0R7153",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1J7O0R7154",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1J7O0R7155",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1JF52TT0O0",
//					"attrs": {
//						"id": "indexAsset",
//						"label": "New AI Seg",
//						"x": "540",
//						"y": "305",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1JF52V1NS0",
//							"attrs": {
//								"file": {
//									"type": "auto",
//									"valText": ""
//								},
//								"assets": {
//									"type": "auto",
//									"valText": ""
//								},
//								"line": {
//									"type": "auto",
//									"valText": ""
//								}
//							}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1JF52V1NS1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1JF52V1NS2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1J7O0T50L0",
//					"attrs": {
//						"id": "startCoding",
//						"label": "New AI Seg",
//						"x": "305",
//						"y": "305",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1J7O0TEK90",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1J7O0TEK91",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1J7O0TEK92",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1JF5279TH0",
//					"attrs": {
//						"id": "OnLoadAssets",
//						"label": "New AI Seg",
//						"x": "65",
//						"y": "400",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1JF52CQAE0",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1JF52CQAE1",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1JF52CQAE2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				},
//				{
//					"type": "flowseg",
//					"def": "Entry",
//					"jaxId": "1JF527NER0",
//					"attrs": {
//						"id": "OnSaveAssets",
//						"label": "New AI Seg",
//						"x": "305",
//						"y": "400",
//						"desc": "",
//						"codes": "false",
//						"args": {
//							"jaxId": "1JF52CQAE3",
//							"attrs": {}
//						},
//						"async": "true",
//						"returnType": "void",
//						"localVars": {
//							"jaxId": "1JF52CQAE4",
//							"attrs": {}
//						},
//						"segs": {
//							"attrs": []
//						},
//						"outlet": {
//							"jaxId": "1JF52CQAE5",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						},
//						"exposeToAI": "false"
//					},
//					"icon": "func.svg"
//				}
//			]
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1HD3B4CR36",
//			"attrs": {
//				"start": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1J7NT43RB0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1J7NT48PL0",
//							"attrs": {}
//						}
//					}
//				},
//				"wait": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HD3Q3L7K0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HD3Q9Q8M0",
//							"attrs": {}
//						}
//					}
//				},
//				"code": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HD3PTVPO0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HD3Q9Q8M1",
//							"attrs": {}
//						}
//					}
//				},
//				"index": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1JF7VG8AK0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1JF7VHN6M0",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1HD3B4CR37",
//			"attrs": {}
//		},
//		"exposeToAI": "true",
//		"descAI": "",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1HD3B4CR21",
//			"attrs": {
//				"properties": {
//					"jaxId": "1HD3B4CR38",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "50%",
//						"y": "50%",
//						"w": "90%",
//						"h": "",
//						"anchorH": "Center",
//						"anchorV": "Center",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "10",
//						"minW": "320",
//						"minH": "",
//						"maxW": "800",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Flex Y"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1HD3B5UBD0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HD3B84DH0",
//									"attrs": {
//										"type": "box",
//										"id": "BoxBG",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "[255,255,255,1.00]",
//										"border": "1",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "6",
//										"shadow": "true",
//										"shadowX": "2",
//										"shadowY": "6",
//										"shadowBlur": "8",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.30]"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HD3B84DH1",
//									"attrs": {
//										"1HD3Q3L7K0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1J7NVOFB80",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J7NVOFB81",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HD3Q3L7K0",
//											"faceTagName": "wait"
//										},
//										"1JF7VG8AK0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1JF7VHN6M1",
//											"attrs": {
//												"properties": {
//													"jaxId": "1JF7VHN6M2",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1JF7VG8AK0",
//											"faceTagName": "index"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HD3B84DH2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HD3B84DH3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1HD3BAJND0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HD3C81M70",
//									"attrs": {
//										"type": "text",
//										"id": "TxtTitle",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#cfgColor[\"fontBodySub\"]",
//										"text": {
//											"type": "string",
//											"valText": "AI 编码",
//											"localize": {
//												"EN": "AI Coding",
//												"CN": "AI 编码"
//											},
//											"localizable": true
//										},
//										"font": "",
//										"fontSize": "#txtSize.smallBig",
//										"bold": "true",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Top",
//										"wrap": "false",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HD3C81M71",
//									"attrs": {
//										"1HD3Q3L7K0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HD3Q9Q8M4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HD3Q9Q8M5",
//													"attrs": {
//														"text": {
//															"type": "string",
//															"valText": "AI正在编写代码……",
//															"localize": {
//																"EN": "AI is coding...",
//																"CN": "AI正在编写代码……"
//															},
//															"localizable": true
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HD3Q3L7K0",
//											"faceTagName": "wait"
//										},
//										"1HD3PTVPO0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HD3Q9Q8M6",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HD3Q9Q8M7",
//													"attrs": {
//														"text": {
//															"type": "string",
//															"valText": "请检查AI编写的代码",
//															"localize": {
//																"EN": "Please review AI's code",
//																"CN": "请检查AI编写的代码"
//															},
//															"localizable": true
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HD3PTVPO0",
//											"faceTagName": "code"
//										},
//										"1J7NT43RB0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1JF7VAV5G0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1JF7VAV5G1",
//													"attrs": {
//														"text": {
//															"type": "string",
//															"valText": "AI Coding",
//															"localize": {
//																"EN": "AI 编码",
//																"CN": "AI Coding"
//															},
//															"localizable": true
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1J7NT43RB0",
//											"faceTagName": "start"
//										},
//										"1JF7VG8AK0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1JF7VHN6M5",
//											"attrs": {
//												"properties": {
//													"jaxId": "1JF7VHN6M6",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1JF7VG8AK0",
//											"faceTagName": "index"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HD3C81M72",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HD3C81M73",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1J7NT8F6D0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1J7NT9GNN0",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxStartOpts",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,0]",
//										"padding": "5",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex Y"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1J7NVHQIU0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J7NVJ6PG0",
//													"attrs": {
//														"type": "box",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "1",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[0,0,10,0]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "#cfgColor[\"fontBodyLit\"]",
//														"border": "0",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1J7NVJ6PG1",
//													"attrs": {
//														"1HD3Q3L7K0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J7NVOFB82",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J7NVOFB83",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HD3Q3L7K0",
//															"faceTagName": "wait"
//														},
//														"1JF7VG8AK0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1JF7VHN6M7",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1JF7VHN6M8",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1JF7VG8AK0",
//															"faceTagName": "index"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1J7NVJ6PG2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1J7NVJ6PG3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1J7NTALEN0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J7NTMFNA0",
//													"attrs": {
//														"type": "hud",
//														"id": "LineModel",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "30",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "[0,0,0,15]",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex X",
//														"itemsAlign": "Center"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1J7NTJ6AI0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J7NTK7570",
//																	"attrs": {
//																		"type": "text",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontBody\"]",
//																		"text": {
//																			"type": "string",
//																			"valText": "AI模型:",
//																			"localize": {
//																				"EN": "AI Model:",
//																				"CN": "AI模型:"
//																			},
//																			"localizable": true
//																		},
//																		"font": "",
//																		"fontSize": "16",
//																		"bold": "true",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Top",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"lineClamp": "0",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1J7NTK7571",
//																	"attrs": {
//																		"1HD3Q3L7K0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J7NVOFB84",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J7NVOFB85",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HD3Q3L7K0",
//																			"faceTagName": "wait"
//																		},
//																		"1JF7VG8AK0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1JF7VHN6M11",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1JF7VHN6M12",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1JF7VG8AK0",
//																			"faceTagName": "index"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1J7NTK7572",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1J7NTK7573",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1J7NTDIT50",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1J7NTEJ920",
//																	"attrs": {
//																		"style": "\"front\"",
//																		"w": "24",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/btncombo.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1J7NTEJ921",
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"front\",24,0,appCfg.sharedAssets+\"/btncombo.svg\",null)",
//																		"id": "BtnPlatform",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1J7NTEJ930",
//																	"attrs": {
//																		"1HD3Q3L7K0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J7NVOFB86",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J7NVOFB87",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HD3Q3L7K0",
//																			"faceTagName": "wait"
//																		},
//																		"1JF7VG8AK0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1JF7VHN6M15",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1JF7VHN6M16",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1JF7VG8AK0",
//																			"faceTagName": "index"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1J7NTEJ931",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1J7O13VRN0",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1J7O13VRN1",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": "1J7O0NN2I0"
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1J7NTEJ932",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1J7NTEJ933",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1J7NTBD3G0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J7NTD32T0",
//																	"attrs": {
//																		"type": "text",
//																		"id": "TxtPlatform",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontBody\"]",
//																		"text": {
//																			"type": "string",
//																			"valText": "OpenAI",
//																			"localize": {
//																				"EN": "OpenAI",
//																				"CN": "OpenAI"
//																			},
//																			"localizable": true
//																		},
//																		"font": "",
//																		"fontSize": "#txtSize.smallMid",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Top",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"lineClamp": "0",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1J7NTD32T1",
//																	"attrs": {
//																		"1HD3Q3L7K0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J7NVOFB88",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J7NVOFB89",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HD3Q3L7K0",
//																			"faceTagName": "wait"
//																		},
//																		"1JF7VG8AK0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1JF7VHN6M19",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1JF7VHN6M20",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1JF7VG8AK0",
//																			"faceTagName": "index"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1J7NTD32T2",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1J7NTD32T3",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1J7NTEKHL0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1J7NTEKHL1",
//																	"attrs": {
//																		"style": "\"front\"",
//																		"w": "24",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/btncombo.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1J7NTEKHL2",
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"front\",24,0,appCfg.sharedAssets+\"/btncombo.svg\",null)",
//																		"id": "BtnModel",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"margin": "[0,0,0,3]"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1J7NTEKHM0",
//																	"attrs": {
//																		"1HD3Q3L7K0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J7NVOFB810",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J7NVOFB811",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HD3Q3L7K0",
//																			"faceTagName": "wait"
//																		},
//																		"1JF7VG8AK0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1JF7VHN6M23",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1JF7VHN6M24",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1JF7VG8AK0",
//																			"faceTagName": "index"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1J7NTEKHM1",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1J7O13VRN2",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1J7O13VRN3",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": "1J7O0O5I60"
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1J7NTEKHM2",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1J7NTEKHM3",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1J7NTF21L0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J7NTF21L1",
//																	"attrs": {
//																		"type": "text",
//																		"id": "TxtModel",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontBody\"]",
//																		"text": {
//																			"type": "string",
//																			"valText": "GPT-5",
//																			"localize": {
//																				"EN": "GPT-5",
//																				"CN": "GPT-5"
//																			},
//																			"localizable": true
//																		},
//																		"font": "",
//																		"fontSize": "#txtSize.smallMid",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Top",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"lineClamp": "0",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1J7NTF21M0",
//																	"attrs": {
//																		"1HD3Q3L7K0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J7NVOFB812",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J7NVOFB813",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HD3Q3L7K0",
//																			"faceTagName": "wait"
//																		},
//																		"1JF7VG8AK0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1JF7VHN6M27",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1JF7VHN6M28",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1JF7VG8AK0",
//																			"faceTagName": "index"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1J7NTF21M1",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1J7NTF21M2",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true"
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1J7NTMFNB0",
//													"attrs": {
//														"1HD3Q3L7K0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J7NVOFB814",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J7NVOFB815",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HD3Q3L7K0",
//															"faceTagName": "wait"
//														},
//														"1JF7VG8AK0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1JF7VHN6N0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1JF7VHN6N1",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1JF7VG8AK0",
//															"faceTagName": "index"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1J7NTMFNB1",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1J7NTMFNB2",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1JF30H78O0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1JF30K8HK0",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxAssets",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Auto Scroll Y",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "[0,15,0,15]",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "300",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex Y"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1JF30K8HK1",
//													"attrs": {
//														"1HD3Q3L7K0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1JF7VAV5G18",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1JF7VAV5G19",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HD3Q3L7K0",
//															"faceTagName": "wait"
//														},
//														"1JF7VG8AK0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1JF7VHN6N4",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1JF7VHN6N5",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1JF7VG8AK0",
//															"faceTagName": "index"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1JF30K8HK2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1JF30K8HK3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "true",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1J7NTMJK10",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J7NTMJK11",
//													"attrs": {
//														"type": "hud",
//														"id": "LineAssets",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "24",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[5,0,0,0]",
//														"padding": "[0,15,0,15]",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex X",
//														"itemsAlign": "Center"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1J7NTMJK20",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1J7NTMJK21",
//																	"attrs": {
//																		"style": "\"front\"",
//																		"w": "24",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/inc.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1J7NTMJK22",
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"front\",24,0,appCfg.sharedAssets+\"/inc.svg\",null)",
//																		"id": "BtnAssets",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1J7NTMJK23",
//																	"attrs": {
//																		"1HD3Q3L7K0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J7NVOFB818",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J7NVOFB819",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HD3Q3L7K0",
//																			"faceTagName": "wait"
//																		},
//																		"1JF7VG8AK0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1JF7VHN6N8",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1JF7VHN6N9",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1JF7VG8AK0",
//																			"faceTagName": "index"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1J7NTMJK24",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1JF3OG6J80",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1JF3OG6J81",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": "1J7O0QKAJ0"
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1J7NTMJK25",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1J7NTMJK26",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1J7NTMJK12",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J7NTMJK13",
//																	"attrs": {
//																		"type": "text",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontBody\"]",
//																		"text": {
//																			"type": "string",
//																			"valText": "添加附件",
//																			"localize": {
//																				"EN": "Add assets",
//																				"CN": "添加附件"
//																			},
//																			"localizable": true
//																		},
//																		"font": "",
//																		"fontSize": "#txtSize.small",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Top",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"lineClamp": "0",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0",
//																		"flex": "true"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1J7NTMJK14",
//																	"attrs": {
//																		"1HD3Q3L7K0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J7NVOFB816",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J7NVOFB817",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HD3Q3L7K0",
//																			"faceTagName": "wait"
//																		},
//																		"1JF7VG8AK0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1JF7VHN6N12",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1JF7VHN6N13",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1JF7VG8AK0",
//																			"faceTagName": "index"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1J7NTMJK15",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1J7NTMJK16",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1JF3O91Q40",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1JF3O91Q41",
//																	"attrs": {
//																		"style": "\"front\"",
//																		"w": "24",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/folder.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1JF3O91Q42",
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"front\",24,0,appCfg.sharedAssets+\"/folder.svg\",null)",
//																		"id": "BtnOpenAssets",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1JF3O91Q43",
//																	"attrs": {
//																		"1HD3Q3L7K0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1JF3O91Q46",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1JF3O91Q47",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HD3Q3L7K0",
//																			"faceTagName": "wait"
//																		},
//																		"1JF7VG8AK0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1JF7VHN6N16",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1JF7VHN6N17",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1JF7VG8AK0",
//																			"faceTagName": "index"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1JF3O91Q48",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1JF52H3H40",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1JF52H3H41",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": "1JF5279TH0"
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1JF3O91Q49",
//																	"attrs": {
//																		"tip": {
//																			"type": "string",
//																			"valText": "打开附件组",
//																			"localize": {
//																				"EN": "Open assets",
//																				"CN": "打开附件组"
//																			},
//																			"localizable": true
//																		}
//																	}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1JF3O91Q410",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1JF3OA4HC0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1JF3OA4HC1",
//																	"attrs": {
//																		"style": "\"front\"",
//																		"w": "24",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/save.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1JF3OA4HC2",
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"front\",24,0,appCfg.sharedAssets+\"/save.svg\",null)",
//																		"id": "BtnSaveAssets",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1JF3OA4HC3",
//																	"attrs": {
//																		"1HD3Q3L7K0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1JF3OA4HC6",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1JF3OA4HC7",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HD3Q3L7K0",
//																			"faceTagName": "wait"
//																		},
//																		"1JF7VG8AK0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1JF7VHN6N20",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1JF7VHN6N21",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1JF7VG8AK0",
//																			"faceTagName": "index"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1JF3OA4HC8",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1JF52H3H42",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1JF52H3H43",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": "1JF527NER0"
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1JF3OA4HC9",
//																	"attrs": {
//																		"tip": {
//																			"type": "string",
//																			"valText": "保存附件组",
//																			"localize": {
//																				"EN": "Save assets",
//																				"CN": "保存附件组"
//																			},
//																			"localizable": true
//																		}
//																	}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1JF3OA4HC10",
//																	"attrs": {}
//																}
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1J7NTMJK224",
//													"attrs": {
//														"1HD3Q3L7K0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J7NVOFB820",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J7NVOFB821",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HD3Q3L7K0",
//															"faceTagName": "wait"
//														},
//														"1JF7VG8AK0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1JF7VHN6N24",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1JF7VHN6N25",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1JF7VG8AK0",
//															"faceTagName": "index"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1J7NTMJK225",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1J7NTMJK226",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1J7NTQQCC0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J7NTQQCC1",
//													"attrs": {
//														"type": "hud",
//														"id": "LinePrompt",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[5,0,0,0]",
//														"padding": "[0,10,0,5]",
//														"minW": "",
//														"minH": "30",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex X",
//														"itemsAlign": "Start"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "box",
//															"jaxId": "1J7NTSQ0C0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J7NUAAAC0",
//																	"attrs": {
//																		"type": "box",
//																		"id": "BoxInputFrame",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[0,0,0,5]",
//																		"padding": "[5,5,5,5]",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"background": "#cfgColor[\"body\"]",
//																		"border": "0",
//																		"borderStyle": "Solid",
//																		"borderColor": "[0,0,0,1.00]",
//																		"corner": "6",
//																		"shadow": "true",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "5",
//																		"shadowSpread": "3",
//																		"shadowColor": "[0,0,0,0.25]",
//																		"flex": "true",
//																		"contentLayout": "Flex X",
//																		"itemsAlign": "Center"
//																	}
//																},
//																"subHuds": {
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "Gear/@StdUI/ui/BtnIcon.js",
//																			"jaxId": "1J7NU7CSQ0",
//																			"attrs": {
//																				"createArgs": {
//																					"jaxId": "1J7NU7CSQ1",
//																					"attrs": {
//																						"style": "\"front\"",
//																						"w": "24",
//																						"h": "0",
//																						"icon": "#appCfg.sharedAssets+\"/btncombo.svg\"",
//																						"colorBG": "null"
//																					}
//																				},
//																				"properties": {
//																					"jaxId": "1J7NU7CSQ2",
//																					"attrs": {
//																						"type": "#null#>BtnIcon(\"front\",24,0,appCfg.sharedAssets+\"/btncombo.svg\",null)",
//																						"id": "BtnCodeMode",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"display": "On",
//																						"face": "",
//																						"attach": "true"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1J7NU7CSQ3",
//																					"attrs": {
//																						"1HD3Q3L7K0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1J7NVOFB824",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1J7NVOFB825",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HD3Q3L7K0",
//																							"faceTagName": "wait"
//																						},
//																						"1JF7VG8AK0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1JF7VHN6N28",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1JF7VHN6N29",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1JF7VG8AK0",
//																							"faceTagName": "index"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1J7NU7CSQ4",
//																					"attrs": {
//																						"OnClick": {
//																							"type": "fixedFunc",
//																							"jaxId": "1J7O13VRN4",
//																							"attrs": {
//																								"callArgs": {
//																									"jaxId": "1J7O13VRN5",
//																									"attrs": {
//																										"event": ""
//																									}
//																								},
//																								"seg": "1J7O0SS210"
//																							}
//																						}
//																					}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1J7NU7CSQ5",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "true",
//																				"containerSlots": {
//																					"jaxId": "1J7NU7CSQ6",
//																					"attrs": {}
//																				}
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "text",
//																			"jaxId": "1J7NV7KE80",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J7NV8PC60",
//																					"attrs": {
//																						"type": "text",
//																						"id": "TxtCodeMode",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "",
//																						"h": "",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"color": "#cfgColor[\"fontBodySub\"]",
//																						"text": "在光标处：",
//																						"font": "",
//																						"fontSize": "#txtSize.smallMid",
//																						"bold": "true",
//																						"italic": "false",
//																						"underline": "false",
//																						"alignH": "Left",
//																						"alignV": "Top",
//																						"wrap": "false",
//																						"ellipsis": "false",
//																						"lineClamp": "0",
//																						"select": "false",
//																						"shadow": "false",
//																						"shadowX": "0",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowColor": "[0,0,0,1.00]",
//																						"shadowEx": "",
//																						"maxTextW": "0"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1J7NV8PC61",
//																					"attrs": {
//																						"1HD3Q3L7K0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1J7NVOFB826",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1J7NVOFB827",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HD3Q3L7K0",
//																							"faceTagName": "wait"
//																						},
//																						"1JF7VG8AK0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1JF7VHN6N32",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1JF7VHN6N33",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1JF7VG8AK0",
//																							"faceTagName": "index"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1J7NV8PC62",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1J7NV8PC63",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "true"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "Gear/@StdUI/ui/BtnIcon.js",
//																			"jaxId": "1J7V6HGCU0",
//																			"attrs": {
//																				"createArgs": {
//																					"jaxId": "1J7V6HGCU1",
//																					"attrs": {
//																						"style": "\"front\"",
//																						"w": "24",
//																						"h": "0",
//																						"icon": "#appCfg.sharedAssets+\"/btncombo.svg\"",
//																						"colorBG": "null"
//																					}
//																				},
//																				"properties": {
//																					"jaxId": "1J7V6HGCU2",
//																					"attrs": {
//																						"type": "#null#>BtnIcon(\"front\",24,0,appCfg.sharedAssets+\"/btncombo.svg\",null)",
//																						"id": "BtnCodeTask",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"display": "On",
//																						"face": "",
//																						"attach": "true"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1J7V6HGCU3",
//																					"attrs": {
//																						"1HD3Q3L7K0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1J7V6HGCU6",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1J7V6HGCU7",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HD3Q3L7K0",
//																							"faceTagName": "wait"
//																						},
//																						"1JF7VG8AK0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1JF7VHN6N36",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1JF7VHN6N37",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1JF7VG8AK0",
//																							"faceTagName": "index"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1J7V6HGCU8",
//																					"attrs": {
//																						"OnClick": {
//																							"type": "fixedFunc",
//																							"jaxId": "1J7V6HGCU9",
//																							"attrs": {
//																								"callArgs": {
//																									"jaxId": "1J7V6HGCU10",
//																									"attrs": {
//																										"event": ""
//																									}
//																								},
//																								"seg": "1J7V6JRB60"
//																							}
//																						}
//																					}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1J7V6HGCU11",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "true",
//																				"containerSlots": {
//																					"jaxId": "1J7V6HGCV0",
//																					"attrs": {}
//																				}
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "memo",
//																			"jaxId": "1J7NU25LJ0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J7NUAAAC1",
//																					"attrs": {
//																						"type": "memo",
//																						"id": "EdPrompt",
//																						"position": "Relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "200",
//																						"h": "",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "25",
//																						"maxW": "",
//																						"maxH": "300",
//																						"face": "",
//																						"styleClass": "",
//																						"text": "",
//																						"color": "[0,0,0]",
//																						"bgColor": "[255,255,255,1.00]",
//																						"font": "",
//																						"fontSize": "#txtSize.smallMid",
//																						"outline": "0",
//																						"border": "[0,0,1,0]",
//																						"borderStyle": "Solid",
//																						"borderColor": "[0,0,0,1.00]",
//																						"corner": "0",
//																						"readOnly": "false",
//																						"selectOnFocus": "true",
//																						"spellCheck": "true",
//																						"flex": "true"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1J7NUAAAC2",
//																					"attrs": {
//																						"1HD3Q3L7K0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1J7NVOFB828",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1J7NVOFB829",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HD3Q3L7K0",
//																							"faceTagName": "wait"
//																						},
//																						"1JF7VG8AK0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1JF7VHN6N40",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1JF7VHN6N41",
//																									"attrs": {
//																										"readOnly": "true"
//																									}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1JF7VG8AK0",
//																							"faceTagName": "index"
//																						},
//																						"1J7NT43RB0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1JF7VHN6N42",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1JF7VHN6N43",
//																									"attrs": {
//																										"readOnly": "false"
//																									}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J7NT43RB0",
//																							"faceTagName": "start"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1J7NUAAAC3",
//																					"attrs": {
//																						"OnInput": {
//																							"type": "fixedFunc",
//																							"jaxId": "1J7O5VU810",
//																							"attrs": {
//																								"callArgs": {
//																									"jaxId": "1J7O609RQ0",
//																									"attrs": {}
//																								},
//																								"seg": ""
//																							}
//																						},
//																						"OnKeyDown": {
//																							"type": "fixedFunc",
//																							"jaxId": "1J7O6064H0",
//																							"attrs": {
//																								"callArgs": {
//																									"jaxId": "1J7O609RQ1",
//																									"attrs": {
//																										"event": ""
//																									}
//																								},
//																								"seg": ""
//																							}
//																						}
//																					}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1J7NUAAAC4",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "true"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "Gear/@StdUI/ui/BtnIcon.js",
//																			"jaxId": "1J7NTUH550",
//																			"attrs": {
//																				"createArgs": {
//																					"jaxId": "1J7NTUH551",
//																					"attrs": {
//																						"style": "\"front\"",
//																						"w": "30",
//																						"h": "0",
//																						"icon": "#appCfg.sharedAssets+\"/run.svg\"",
//																						"colorBG": "null"
//																					}
//																				},
//																				"properties": {
//																					"jaxId": "1J7NTUH552",
//																					"attrs": {
//																						"type": "#null#>BtnIcon(\"front\",30,0,appCfg.sharedAssets+\"/run.svg\",null)",
//																						"id": "BtnStart",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"display": "On",
//																						"face": ""
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1J7NTUH553",
//																					"attrs": {
//																						"1HD3Q3L7K0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1J7NVOFB830",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1J7NVOFB831",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HD3Q3L7K0",
//																							"faceTagName": "wait"
//																						},
//																						"1JF7VG8AK0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1JF7VHN6N44",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1JF7VHN6N45",
//																									"attrs": {
//																										"enable": "false"
//																									}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1JF7VG8AK0",
//																							"faceTagName": "index"
//																						},
//																						"1J7NT43RB0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1JF7VHN6N46",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1JF7VHN6N47",
//																									"attrs": {
//																										"enable": "true"
//																									}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J7NT43RB0",
//																							"faceTagName": "start"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1J7NTUH554",
//																					"attrs": {
//																						"OnClick": {
//																							"type": "fixedFunc",
//																							"jaxId": "1J7O13VRO0",
//																							"attrs": {
//																								"callArgs": {
//																									"jaxId": "1J7O13VRO1",
//																									"attrs": {
//																										"event": ""
//																									}
//																								},
//																								"seg": "1J7O0T50L0"
//																							}
//																						}
//																					}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1J7NTUH555",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "true",
//																				"containerSlots": {
//																					"jaxId": "1J7NTUH556",
//																					"attrs": {}
//																				}
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"jaxId": "1J7NUAAAC5",
//																	"attrs": {
//																		"1HD3Q3L7K0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J7NVOFB832",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J7NVOFB833",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HD3Q3L7K0",
//																			"faceTagName": "wait"
//																		},
//																		"1JF7VG8AK0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1JF7VHN6N48",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1JF7VHN6N49",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1JF7VG8AK0",
//																			"faceTagName": "index"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1J7NUAAAC6",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1J7NUAAAC7",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false"
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1J7NTQQCD12",
//													"attrs": {
//														"1HD3Q3L7K0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J7NVOFB834",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J7NVOFB835",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HD3Q3L7K0",
//															"faceTagName": "wait"
//														},
//														"1JF7VG8AK0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1JF7VHN6N52",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1JF7VHN6N53",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1JF7VG8AK0",
//															"faceTagName": "index"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1J7NTQQCD13",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1J7NTQQCD14",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1J7NT9GNN1",
//									"attrs": {
//										"1J7NT43RB0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1J7NUK4US90",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J7NUK4US91",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1J7NT43RB0",
//											"faceTagName": "start"
//										},
//										"1HD3Q3L7K0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1J7NUK4US92",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J7NUK4US93",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HD3Q3L7K0",
//											"faceTagName": "wait"
//										},
//										"1HD3PTVPO0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1J7NUK4US94",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J7NUK4US95",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HD3PTVPO0",
//											"faceTagName": "code"
//										},
//										"1JF7VG8AK0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1JF7VHN6N56",
//											"attrs": {
//												"properties": {
//													"jaxId": "1JF7VHN6N57",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1JF7VG8AK0",
//											"faceTagName": "index"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1J7NT9GNN2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1J7NT9GNN3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1HD3BC0360",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HD3C81M74",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxCodeFrame",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "Off",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[10,0,0,0]",
//										"padding": "1",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex Y"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1HD3BEJ1V0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HD3C81M75",
//													"attrs": {
//														"type": "box",
//														"id": "BoxCodeBG",
//														"position": "Absolute",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "#cfgColor[\"body\"]",
//														"border": "1",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HD3C81M76",
//													"attrs": {
//														"1HD3Q3L7K0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J7NVOFB836",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J7NVOFB837",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HD3Q3L7K0",
//															"faceTagName": "wait"
//														},
//														"1JF7VG8AK0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1JF7VHN6N58",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1JF7VHN6N59",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1JF7VG8AK0",
//															"faceTagName": "index"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HD3C81M77",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HD3C81M78",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1HD3BG7QU0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HD3BL6CT0",
//													"attrs": {
//														"type": "box",
//														"id": "BoxHeader",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "16",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "#cfgColor[\"fontSecondarySub\"]",
//														"border": "[0,0,1,0]",
//														"borderStyle": "Solid",
//														"borderColor": "#cfgColor[\"fontBody\"]",
//														"corner": "0",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HD3BL6CT1",
//													"attrs": {
//														"1HD3Q3L7K0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J7NVOFB838",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J7NVOFB839",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HD3Q3L7K0",
//															"faceTagName": "wait"
//														},
//														"1JF7VG8AK0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1JF7VHN6N62",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1JF7VHN6N63",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1JF7VG8AK0",
//															"faceTagName": "index"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HD3BL6CT2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HD3BL6CT3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1HD3BIMSS0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HD3C81M79",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxCode",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "300",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "300",
//														"face": "",
//														"styleClass": ""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HD3C81M710",
//													"attrs": {
//														"1HD3Q3L7K0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J7NVOFB840",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J7NVOFB841",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HD3Q3L7K0",
//															"faceTagName": "wait"
//														},
//														"1JF7VG8AK0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1JF7VHN6N66",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1JF7VHN6N67",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1JF7VG8AK0",
//															"faceTagName": "index"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HD3C81M711",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HD3C81M712",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "true",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1HD3BL81T0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HD3BL81T1",
//													"attrs": {
//														"type": "box",
//														"id": "BoxFooter",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "8",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "#cfgColor[\"secondary\"]",
//														"border": "0",
//														"borderStyle": "Solid",
//														"borderColor": "#cfgColor[\"fontBody\"]",
//														"corner": "0",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HD3BL81T2",
//													"attrs": {
//														"1HD3Q3L7K0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J7NVOFB842",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J7NVOFB843",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HD3Q3L7K0",
//															"faceTagName": "wait"
//														},
//														"1JF7VG8AK0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1JF7VHN6N70",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1JF7VHN6N71",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1JF7VG8AK0",
//															"faceTagName": "index"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HD3BL81T3",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HD3BL81T4",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "true"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1HD3C81M713",
//									"attrs": {
//										"1HD3PTVPO0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HD3Q9Q8M16",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HD3Q9Q8M17",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HD3PTVPO0",
//											"faceTagName": "code"
//										},
//										"1HD3Q3L7K0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HD3Q9Q8M18",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HD3Q9Q8M19",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HD3Q3L7K0",
//											"faceTagName": "wait"
//										},
//										"1J7NT43RB0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1J7NUK4US112",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J7NUK4US113",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1J7NT43RB0",
//											"faceTagName": "start"
//										},
//										"1JF7VG8AK0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1JF7VHN6N74",
//											"attrs": {
//												"properties": {
//													"jaxId": "1JF7VHN6N75",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1JF7VG8AK0",
//											"faceTagName": "index"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HD3C81M714",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HD3C81M715",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1HD3PUF820",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HD3Q9Q8M20",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxButtons",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[10,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex X",
//										"itemsAlign": "Center",
//										"subAlign": "Center",
//										"itemsWrap": "Wrap"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnText.js",
//											"jaxId": "1HD3PVC7N0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1HD3Q1O0D0",
//													"attrs": {
//														"style": "success",
//														"w": "100",
//														"h": "25",
//														"text": "Apply",
//														"outlined": "false",
//														"icon": ""
//													}
//												},
//												"properties": {
//													"jaxId": "1HD3Q1O0D1",
//													"attrs": {
//														"type": "#null#>BtnText(\"success\",100,25,\"Apply\",false,\"\")",
//														"id": "",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"corner": "3"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HD3Q1O0D2",
//													"attrs": {
//														"1HD3PTVPO0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J7NT48PM8",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J7NT48PM9",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HD3PTVPO0",
//															"faceTagName": "code"
//														},
//														"1J7NT43RB0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J7NUK4US114",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J7NUK4US115",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J7NT43RB0",
//															"faceTagName": "start"
//														},
//														"1HD3Q3L7K0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J7NVOFB844",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J7NVOFB845",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HD3Q3L7K0",
//															"faceTagName": "wait"
//														},
//														"1JF7VG8AK0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1JF7VHN6N76",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1JF7VHN6N77",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1JF7VG8AK0",
//															"faceTagName": "index"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HD3Q1O0D3",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1HD4061LH0",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1HD4069S80",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1HD3Q1O0D4",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1HD3Q1O0D5",
//													"attrs": {
//														"Slot1H2F6U36O0": {
//															"jaxId": "1IA2IOQ580",
//															"attrs": {
//																"subHuds": {
//																	"attrs": []
//																},
//																"container": "true"
//															}
//														}
//													}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnText.js",
//											"jaxId": "1HD3Q2UAE0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1HD3Q2UAE1",
//													"attrs": {
//														"style": "warning",
//														"w": "100",
//														"h": "25",
//														"text": "Cancel",
//														"outlined": "false",
//														"icon": ""
//													}
//												},
//												"properties": {
//													"jaxId": "1HD3Q2UAE2",
//													"attrs": {
//														"type": "#null#>BtnText(\"warning\",100,25,\"Cancel\",false,\"\")",
//														"id": "",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"margin": "[0,0,0,20]",
//														"corner": "3"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HD3Q2UAE3",
//													"attrs": {
//														"1HD3PTVPO0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J7NT48PM10",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J7NT48PM11",
//																	"attrs": {
//																		"enable": "true"
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HD3PTVPO0",
//															"faceTagName": "code"
//														},
//														"1HD3Q3L7K0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J7NVOFB90",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J7NVOFB91",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HD3Q3L7K0",
//															"faceTagName": "wait"
//														},
//														"1JF7VG8AK0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1JF7VHN6N78",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1JF7VHN6N79",
//																	"attrs": {
//																		"display": "On",
//																		"enable": "false"
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1JF7VG8AK0",
//															"faceTagName": "index"
//														},
//														"1J7NT43RB0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1JF7VHN6N80",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1JF7VHN6N81",
//																	"attrs": {
//																		"enable": "true"
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J7NT43RB0",
//															"faceTagName": "start"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HD3Q2UAE4",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1HD405KCP0",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1HD405QRK0",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1HD3Q2UAE5",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1HD3Q2UAE6",
//													"attrs": {
//														"Slot1H2F6U36O0": {
//															"jaxId": "1IA2IOQ581",
//															"attrs": {
//																"subHuds": {
//																	"attrs": []
//																},
//																"container": "true"
//															}
//														}
//													}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1HD3Q9Q8M25",
//									"attrs": {
//										"1HD3Q3L7K0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HD3Q9Q8N0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HD3Q9Q8N1",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HD3Q3L7K0",
//											"faceTagName": "wait"
//										},
//										"1HD3PTVPO0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HD3Q9Q8N2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HD3Q9Q8N3",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HD3PTVPO0",
//											"faceTagName": "code"
//										},
//										"1JF7VG8AK0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1JF7VHN6N82",
//											"attrs": {
//												"properties": {
//													"jaxId": "1JF7VHN6N83",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1JF7VG8AK0",
//											"faceTagName": "index"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HD3Q9Q8N4",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HD3Q9Q8N5",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1HD3B4CR39",
//					"attrs": {
//						"1HD3Q3L7K0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1J7NVOFB92",
//							"attrs": {
//								"properties": {
//									"jaxId": "1J7NVOFB93",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HD3Q3L7K0",
//							"faceTagName": "wait"
//						},
//						"1JF7VG8AK0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1JF7VHN6N86",
//							"attrs": {
//								"properties": {
//									"jaxId": "1JF7VHN6N87",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1JF7VG8AK0",
//							"faceTagName": "index"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1HD3B4CR310",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1HD3B4CR311",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1HD3B4CR312",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}