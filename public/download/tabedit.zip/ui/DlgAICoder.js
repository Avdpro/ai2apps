//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnText} from "/@StdUI/ui/BtnText.js";
/*#{1HD3B4CR20StartDoc*/
import pathLib from "/@path";
import {mergeCodeWithSeg} from "../lib/codesegs.js";
/*}#1HD3B4CR20StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let DlgAICoder=function(){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let boxBG,boxCodeFrame,boxCode,boxFooter;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1HD3B4CR21LocalVals*/
	let app=VFACT.app;
	let dlgVO=null;
	let cm=null;
	let docObj=null;
	let codyDoc=null;
	let orgCode="";
	let newCode="";
	let editBox="";
	/*}#1HD3B4CR21LocalVals*/
	
	/*#{1HD3B4CR21PreState*/
	/*}#1HD3B4CR21PreState*/
	/*#{1HD3B4CR21PostState*/
	/*}#1HD3B4CR21PostState*/
	cssVO={
		"hash":"1HD3B4CR21",nameHost:true,
		"type":"hud","x":"50%","y":"50%","w":"90%","h":"","anchorX":1,"anchorY":1,"padding":10,"minW":320,"minH":"","maxW":800,"maxH":"","styleClass":"","contentLayout":"flex-y",
		children:[
			{
				"hash":"1HD3B5UBD0",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":[255,255,255,1],"border":1,
				"corner":6,"shadow":true,"shadowY":6,"shadowBlur":8,"shadowColor":[0,0,0,0.3],
			},
			{
				"hash":"1HD3BAJND0",
				"type":"text","id":"TxtTitle","position":"relative","x":0,"y":0,"w":"100%","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodySub"],
				"text":"AI is coding...","fontSize":txtSize.smallBig,"fontWeight":"bold","fontStyle":"normal","textDecoration":"",
			},
			{
				"hash":"1HD3BC0360",
				"type":"hud","id":"BoxCodeFrame","position":"relative","x":0,"y":0,"w":"100%","h":"","margin":[10,0,0,0],"padding":1,"minW":"","minH":"","maxW":"",
				"maxH":"","styleClass":"","contentLayout":"flex-y",
				children:[
					{
						"hash":"1HD3BEJ1V0",
						"type":"box","id":"BoxCodeBG","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["body"],
						"border":1,
					},
					{
						"hash":"1HD3BG7QU0",
						"type":"box","id":"BoxHeader","position":"relative","x":0,"y":0,"w":"100%","h":16,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["fontSecondarySub"],
						"border":[0,0,1,0],"borderColor":cfgColor["fontBody"],
					},
					{
						"hash":"1HD3BIMSS0",
						"type":"hud","id":"BoxCode","position":"relative","x":0,"y":0,"w":"100%","h":300,"minW":"","minH":"","maxW":"","maxH":300,"styleClass":"",
					},
					{
						"hash":"1HD3BL81T0",
						"type":"box","id":"BoxFooter","position":"relative","x":0,"y":0,"w":"100%","h":8,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["secondary"],
						"borderColor":cfgColor["fontBody"],
					}
				],
			},
			{
				"hash":"1HD3PUF820",
				"type":"hud","id":"BoxButtons","position":"relative","x":0,"y":0,"w":"100%","h":30,"margin":[10,0,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"contentLayout":"flex-x","itemsAlign":1,"subAlign":1,"itemsWrap":1,
				children:[
					{
						"hash":"1HD3PVC7N0",
						"type":BtnText("success",100,25,"Apply",false,""),"position":"relative","x":0,"y":0,"corner":3,
						"OnClick":function(event){
							/*#{1HD4061LH0FunctionBody*/
							self.applyCode();
							/*}#1HD4061LH0FunctionBody*/
						},
					},
					{
						"hash":"1HD3Q2UAE0",
						"type":BtnText("warning",100,25,"Cancel",false,""),"position":"relative","x":0,"y":0,"margin":[0,0,0,20],"corner":3,
						"OnClick":function(event){
							/*#{1HD405KCP0FunctionBody*/
							self.close();
							/*}#1HD405KCP0FunctionBody*/
						},
					}
				],
			}
		],
		/*#{1HD3B4CR21ExtraCSS*/
		/*}#1HD3B4CR21ExtraCSS*/
		faces:{
			"wait":{
				/*TxtTitle*/"#1HD3BAJND0":{
					"text":"AI is coding..."
				},
				/*BoxCodeFrame*/"#1HD3BC0360":{
					"display":0
				},
				/*BoxButtons*/"#1HD3PUF820":{
					"display":0
				}
			},"code":{
				/*TxtTitle*/"#1HD3BAJND0":{
					"text":"Please review AI's code"
				},
				/*BoxCodeFrame*/"#1HD3BC0360":{
					"display":1
				},
				/*BoxButtons*/"#1HD3PUF820":{
					"display":1
				}
			}
		},
		OnCreate:function(){
			self=this;
			boxBG=self.BoxBG;boxCodeFrame=self.BoxCodeFrame;boxCode=self.BoxCode;boxFooter=self.BoxFooter;
			/*#{1HD3B4CR21Create*/
			VFACT.applyMoveDrag(boxBG,self);
			/*}#1HD3B4CR21Create*/
		},
		/*#{1HD3B4CR21EndCSS*/
		/*}#1HD3B4CR21EndCSS*/
	};
	/*#{1HD3B4CR21PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.showDlg=function(vo){
		dlgVO=vo;
		docObj=vo.doc;
		codyDoc=docObj.codyDoc;
		editBox=docObj.editBox;
		orgCode=docObj.getDocText();
		self.showFace("wait");
		self.execAI().then((coded)=>{
			if(coded){
				/*boxCodeFrame.removeChild(boxCode);
				boxCode=boxCodeFrame.insertNewBefore({
					type:"hud","position":"relative","x":0,"y":0,"w":"100%","h":"","minH":50,"maxH":300
				},boxFooter);*/
				self.showFace("code");
				callAfter(self.showCode);
			}else{
				//TODO: Show error?
				self.close();
			}
		});
	};
	
	//------------------------------------------------------------------------
	cssVO.execAI=async function(){
		let action,cursorPos,selRange,result,callCode,callBot;
		let resVO,mergedCode,aiChat,preCode,postCode;
		aiChat=app.aiChat;
		action=dlgVO.action;
		cursorPos=editBox.getCursorIndex();
		selRange=editBox.getSelectionRange();
		if(!action){
			if(selRange){
				action="Range";
			}else{
				if(cursorPos>=0){
					action="Cursor";
				}else{
					action="Fixer";
				}
			}
		}
		preCode=postCode="";
		switch(action){
			case "Cursor":{
				if(cursorPos>=0){
					preCode=orgCode.substring(0,cursorPos);
					postCode=orgCode.substring(cursorPos);
					callCode=orgCode.substring(0,cursorPos)+"[-AI-]"+orgCode.substring(cursorPos);
				}else{
					//TODO: Tell user no cursor?
					return;
				}
				callBot="ai/CodeAtCursor.js";
				break;
			}
			case "Range":{
				if(selRange){
					preCode=orgCode.substring(0,selRange[0]);
					postCode=orgCode.substring(selRange[1]);
					callCode=orgCode.substring(0,selRange[0])+"[-AI->]"+orgCode.substring(selRange[0],selRange[1])+"[<-AI-]"+orgCode.substring(selRange[1]);
				}else{
					//TODO: Tell user no range?
					return;
				}
				callBot="ai/CodeAtRange.js";
				break;
			}
			default:
			case "Refine":{
				preCode="";
				postCode="";
				callCode="[-AI->]"+orgCode+"[<-AI-]";
				callBot="ai/CodeAtRange.js";
				break;
			}
		}
		result=await app.modalDlg(pathLib.join("/@aichat/ui/DlgAIChat.js"),{
			url:app.path2AppURL(callBot),
			prompt:callCode,
			clearChat:true,
			allowEmptyChat:false,
			allowReset:false,
			autoClose:true
		});
		if(result){
			console.log(result);
			if(typeof(result)==="string"){
				resVO=aiChat.parseCodes(result);
				if(!resVO.codes || !resVO.codes[0]){
					return false;
				}
				newCode=resVO.codes[0][1];
				newCode=newCode.trimLeft();
				let prefix;
				prefix="javascript\n";
				if(newCode.startsWith(prefix)){
					newCode=newCode.substring(prefix.length);
				}
				prefix="js\n";
				if(newCode.startsWith(prefix)){
					newCode=newCode.substring(prefix.length);
				}
			}else if(result && result.replaceCode){
				newCode=result.replaceCode;
			}else{
				return false;
			}
			newCode=preCode+newCode+postCode;
			if(codyDoc){
				mergedCode=mergeCodeWithSeg(orgCode,newCode,{});
				newCode=mergedCode;
			}
			return true;
		}
		return false;
	};
	
	//------------------------------------------------------------------------
	cssVO.showCode=async function(){
		let dv,code;
		let target = boxCode.webObj;
		await VFACT.appendScript("/@codemirror/extern/diff_match_patch.js");
		await VFACT.appendScript("/@codemirror/addon/merge.js");
		target.innerHTML = "";
		dv = CodeMirror.MergeView(target, {
			value: newCode,
			orig: orgCode,
			lineNumbers: true,
			mode: "text",
			highlightDifferences: true,
			connect: true,
			collapseIdentical: 5
		});
		cm=dv.edit;
	};
	
	//------------------------------------------------------------------------
	cssVO.applyCode=function(){
		newCode=cm?cm.doc.getValue():orgCode;
		if(!newCode){
			return false;
		}
		editBox.setEditText(newCode,true);
		self.close();
	};
	
	//------------------------------------------------------------------------
	cssVO.close=function(){
		app.closeDlg(self);
	};
	
	/*}#1HD3B4CR21PostCSSVO*/
	return cssVO;
};
/*#{1HD3B4CR21ExCodes*/
/*}#1HD3B4CR21ExCodes*/


/*#{1HD3B4CR20EndDoc*/
/*}#1HD3B4CR20EndDoc*/

export default DlgAICoder;
export{DlgAICoder};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1HD3B4CR20",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1HD3B4CR30",
//			"attrs": {
//				"device": "Desktop 800x600",
//				"screenW": "800",
//				"screenH": "600",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1HD3B4CR31",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1HD3B4CR32",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1HD3B4CR33",
//			"attrs": {}
//		},
//		"localVars": {
//			"jaxId": "1HD3B4CR34",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1HD3B4CR35",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1HD3B4CR36",
//			"attrs": {
//				"wait": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HD3Q3L7K0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HD3Q9Q8M0",
//							"attrs": {}
//						}
//					}
//				},
//				"code": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HD3PTVPO0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HD3Q9Q8M1",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1HD3B4CR37",
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1HD3B4CR21",
//			"attrs": {
//				"properties": {
//					"jaxId": "1HD3B4CR38",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "50%",
//						"y": "50%",
//						"w": "90%",
//						"h": "",
//						"anchorH": "Center",
//						"anchorV": "Center",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "10",
//						"minW": "320",
//						"minH": "",
//						"maxW": "800",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Flex Y"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1HD3B5UBD0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HD3B84DH0",
//									"attrs": {
//										"type": "box",
//										"id": "BoxBG",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "[255,255,255,1.00]",
//										"border": "1",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "6",
//										"shadow": "true",
//										"shadowX": "2",
//										"shadowY": "6",
//										"shadowBlur": "8",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.30]"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HD3B84DH1",
//									"attrs": {
//										"1HD3Q3L7K0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HRT45FSS0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HRT45FSS1",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HD3Q3L7K0",
//											"faceTagName": "wait"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HD3B84DH2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HD3B84DH3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1HD3BAJND0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HD3C81M70",
//									"attrs": {
//										"type": "text",
//										"id": "TxtTitle",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#cfgColor[\"fontBodySub\"]",
//										"text": "AI is coding...",
//										"font": "",
//										"fontSize": "#txtSize.smallBig",
//										"bold": "true",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Top",
//										"wrap": "false",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HD3C81M71",
//									"attrs": {
//										"1HD3Q3L7K0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HD3Q9Q8M4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HD3Q9Q8M5",
//													"attrs": {
//														"text": {
//															"type": "string",
//															"valText": "AI is coding...",
//															"localizable": true
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HD3Q3L7K0",
//											"faceTagName": "wait"
//										},
//										"1HD3PTVPO0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HD3Q9Q8M6",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HD3Q9Q8M7",
//													"attrs": {
//														"text": {
//															"type": "string",
//															"valText": "Please review AI's code",
//															"localizable": true
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HD3PTVPO0",
//											"faceTagName": "code"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HD3C81M72",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HD3C81M73",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1HD3BC0360",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HD3C81M74",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxCodeFrame",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[10,0,0,0]",
//										"padding": "1",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex Y"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1HD3BEJ1V0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HD3C81M75",
//													"attrs": {
//														"type": "box",
//														"id": "BoxCodeBG",
//														"position": "Absolute",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "#cfgColor[\"body\"]",
//														"border": "1",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HD3C81M76",
//													"attrs": {
//														"1HD3Q3L7K0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HRT45FSS2",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HRT45FSS3",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HD3Q3L7K0",
//															"faceTagName": "wait"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HD3C81M77",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HD3C81M78",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1HD3BG7QU0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HD3BL6CT0",
//													"attrs": {
//														"type": "box",
//														"id": "BoxHeader",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "16",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "#cfgColor[\"fontSecondarySub\"]",
//														"border": "[0,0,1,0]",
//														"borderStyle": "Solid",
//														"borderColor": "#cfgColor[\"fontBody\"]",
//														"corner": "0",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HD3BL6CT1",
//													"attrs": {
//														"1HD3Q3L7K0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HRT45FSS4",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HRT45FSS5",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HD3Q3L7K0",
//															"faceTagName": "wait"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HD3BL6CT2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HD3BL6CT3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1HD3BIMSS0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HD3C81M79",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxCode",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "300",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "300",
//														"face": "",
//														"styleClass": ""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HD3C81M710",
//													"attrs": {
//														"1HD3Q3L7K0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HRT45FSS6",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HRT45FSS7",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HD3Q3L7K0",
//															"faceTagName": "wait"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HD3C81M711",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HD3C81M712",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "true",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1HD3BL81T0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HD3BL81T1",
//													"attrs": {
//														"type": "box",
//														"id": "BoxFooter",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "8",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "#cfgColor[\"secondary\"]",
//														"border": "0",
//														"borderStyle": "Solid",
//														"borderColor": "#cfgColor[\"fontBody\"]",
//														"corner": "0",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HD3BL81T2",
//													"attrs": {
//														"1HD3Q3L7K0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HRT45FSS8",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HRT45FSS9",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HD3Q3L7K0",
//															"faceTagName": "wait"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HD3BL81T3",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HD3BL81T4",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "true"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1HD3C81M713",
//									"attrs": {
//										"1HD3PTVPO0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HD3Q9Q8M16",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HD3Q9Q8M17",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HD3PTVPO0",
//											"faceTagName": "code"
//										},
//										"1HD3Q3L7K0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HD3Q9Q8M18",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HD3Q9Q8M19",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HD3Q3L7K0",
//											"faceTagName": "wait"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HD3C81M714",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HD3C81M715",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1HD3PUF820",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HD3Q9Q8M20",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxButtons",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[10,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex X",
//										"itemsAlign": "Center",
//										"subAlign": "Center",
//										"itemsWrap": "Wrap"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnText.js",
//											"jaxId": "1HD3PVC7N0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1HD3Q1O0D0",
//													"attrs": {
//														"style": "success",
//														"w": "100",
//														"h": "25",
//														"text": "Apply",
//														"outlined": "false",
//														"icon": ""
//													}
//												},
//												"properties": {
//													"jaxId": "1HD3Q1O0D1",
//													"attrs": {
//														"type": "#null#>BtnText(\"success\",100,25,\"Apply\",false,\"\")",
//														"id": "",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"corner": "3"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HD3Q1O0D2",
//													"attrs": {
//														"1HD3Q3L7K0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HRT45FSS10",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HRT45FSS11",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HD3Q3L7K0",
//															"faceTagName": "wait"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HD3Q1O0D3",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1HD4061LH0",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1HD4069S80",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1HD3Q1O0D4",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1HD3Q1O0D5",
//													"attrs": {
//														"Slot1H2F6U36O0": {
//															"jaxId": "1IA2IOQ580",
//															"attrs": {
//																"subHuds": {
//																	"attrs": []
//																},
//																"container": "true"
//															}
//														}
//													}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnText.js",
//											"jaxId": "1HD3Q2UAE0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1HD3Q2UAE1",
//													"attrs": {
//														"style": "warning",
//														"w": "100",
//														"h": "25",
//														"text": "Cancel",
//														"outlined": "false",
//														"icon": ""
//													}
//												},
//												"properties": {
//													"jaxId": "1HD3Q2UAE2",
//													"attrs": {
//														"type": "#null#>BtnText(\"warning\",100,25,\"Cancel\",false,\"\")",
//														"id": "",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"margin": "[0,0,0,20]",
//														"corner": "3"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HD3Q2UAE3",
//													"attrs": {
//														"1HD3Q3L7K0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HRT45FSS12",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HRT45FSS13",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HD3Q3L7K0",
//															"faceTagName": "wait"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HD3Q2UAE4",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1HD405KCP0",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1HD405QRK0",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1HD3Q2UAE5",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1HD3Q2UAE6",
//													"attrs": {
//														"Slot1H2F6U36O0": {
//															"jaxId": "1IA2IOQ581",
//															"attrs": {
//																"subHuds": {
//																	"attrs": []
//																},
//																"container": "true"
//															}
//														}
//													}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1HD3Q9Q8M25",
//									"attrs": {
//										"1HD3Q3L7K0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HD3Q9Q8N0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HD3Q9Q8N1",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HD3Q3L7K0",
//											"faceTagName": "wait"
//										},
//										"1HD3PTVPO0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HD3Q9Q8N2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HD3Q9Q8N3",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HD3PTVPO0",
//											"faceTagName": "code"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HD3Q9Q8N4",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HD3Q9Q8N5",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1HD3B4CR39",
//					"attrs": {
//						"1HD3Q3L7K0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HRT45FSS14",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HRT45FSS15",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HD3Q3L7K0",
//							"faceTagName": "wait"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1HD3B4CR310",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1HD3B4CR311",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1HD3B4CR312",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}