//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1G9G34DVP0StartDoc*/
/*}#1G9G34DVP0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let StateMsg=function(app,w){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1G9G34DVP7LocalVals*/
	let callback=null;
	/*}#1G9G34DVP7LocalVals*/
	
	/*#{1G9G34DVP7PreState*/
	/*}#1G9G34DVP7PreState*/
	/*#{1G9G34DVP7PostState*/
	/*}#1G9G34DVP7PostState*/
	cssVO={
		"hash":"1G9G34DVP7",nameHost:true,
		"type":"hud","x":0,"y":0,"w":w,"h":24,"autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
		children:[
			{
				"hash":"1G9G39GUU0",
				"type":"image","id":"ImgIcon","position":"relative","x":0,"y":2,"w":"FH-4","h":"FH-4","margin":[0,0,0,3],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
			},
			{
				"hash":"1G9G3B3RD0",
				"type":"text","id":"TxtInfo","position":"relative","x":0,"y":0,"w":100,"h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodySub"],
				"text":"text","fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,"autoW":true,
			},
			{
				"hash":"1G9G3K2E70",
				"type":"text","id":"TxtInfoU","position":"relative","x":0,"y":0,"w":100,"h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodySub"],
				"text":"text","fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"underline","alignV":1,"autoW":true,
				/*#{1G9G3K2E70Codes*/
				OnClick(){
					callback && callback();
				}
				/*}#1G9G3K2E70Codes*/
			}
		],
		/*#{1G9G34DVP7ExtraCSS*/
		/*}#1G9G34DVP7ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			self=this;
			
			/*#{1G9G34DVP7Create*/
			/*}#1G9G34DVP7Create*/
		},
		/*#{1G9G34DVP7EndCSS*/
		/*}#1G9G34DVP7EndCSS*/
	};
	/*#{1G9G34DVP7PostCSSVO*/
	cssVO.showMsg=function(icon,info,infoU,func){
		callback=func||null;
		self.ImgIcon.display=!!icon;
		if(icon){
			self.ImgIcon.image=icon;
		}
		self.TxtInfo.text=info;
		self.TxtInfoU.text=infoU;
	};
	/*}#1G9G34DVP7PostCSSVO*/
	return cssVO;
};
/*#{1G9G34DVP7ExCodes*/
/*}#1G9G34DVP7ExCodes*/


/*#{1G9G34DVP0EndDoc*/
/*}#1G9G34DVP0EndDoc*/

export default StateMsg;
export{StateMsg};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1G9G34DVP0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1G9G34DVP1",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "25",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1G9G34DVP2",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1IA4B6O7T0",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1G9G34DVP3",
//			"attrs": {
//				"app": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"w": {
//					"type": "auto",
//					"valText": "\"FW\""
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1G9G34DVP4",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1G9G34DVP5",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "VFACT document",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1G9G34DVP6",
//			"attrs": {}
//		},
//		"mockupStates": {
//			"jaxId": "1IA4B6O7T1",
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1G9G34DVP7",
//			"attrs": {
//				"properties": {
//					"jaxId": "1G9G34DVP8",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "#w",
//						"h": "24",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "true",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "[0,0,0,0]",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "\"\"",
//						"styleClass": "",
//						"contentLayout": "Flex X"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "image",
//							"jaxId": "1G9G39GUU0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G9G60GF30",
//									"attrs": {
//										"type": "image",
//										"id": "ImgIcon",
//										"position": "Relative",
//										"x": "0",
//										"y": "2",
//										"w": "\"FH-4\"",
//										"h": "\"FH-4\"",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,3]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "\"\"",
//										"styleClass": "",
//										"image": "",
//										"autoSize": "false",
//										"fitSize": "false",
//										"repeat": "true",
//										"alignX": "Left",
//										"alignY": "Top"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1G9G60GF31",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1G9G60GF32",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IA4B6O7T2",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1G9G3B3RD0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G9G3K0100",
//									"attrs": {
//										"type": "text",
//										"id": "TxtInfo",
//										"position": "Relative",
//										"x": "0",
//										"y": "0",
//										"w": "100",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "\"\"",
//										"styleClass": "",
//										"color": "#cfgColor[\"fontBodySub\"]",
//										"text": "text",
//										"font": "",
//										"fontSize": "#txtSize.smallMid",
//										"bold": "false",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Center",
//										"wrap": "false",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0",
//										"autoSizeW": "true",
//										"autoSizeH": "false"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1G9G3K0101",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1G9G3K0102",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IA4B6O7T3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1G9G3K2E70",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G9G3K2E71",
//									"attrs": {
//										"type": "text",
//										"id": "TxtInfoU",
//										"position": "Relative",
//										"x": "0",
//										"y": "0",
//										"w": "100",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "\"\"",
//										"styleClass": "",
//										"color": "#cfgColor[\"fontBodySub\"]",
//										"text": "text",
//										"font": "",
//										"fontSize": "#txtSize.smallMid",
//										"bold": "false",
//										"italic": "false",
//										"underline": "true",
//										"alignH": "Left",
//										"alignV": "Center",
//										"wrap": "false",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0",
//										"autoSizeW": "true",
//										"autoSizeH": "false"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1G9G3K2E72",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1G9G3K2E73",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IA4B6O7T4",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "true",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1G9G34DVP9",
//					"attrs": {}
//				},
//				"functions": {
//					"jaxId": "1G9G34DVP10",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1IA4B6O7T5",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1G9G34DVP11",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"innerLayout": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"face": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"marginL": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"marginR": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"marginT": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"marginB": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"paddingL": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"paddingT": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"paddingR": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"paddingB": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"attach": {
//					"type": "bool",
//					"valText": "false"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}