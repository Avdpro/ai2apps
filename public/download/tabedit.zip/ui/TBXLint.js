//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnText} from "/@StdUI/ui/BtnText.js";
import {BtnCheck} from "/@StdUI/ui/BtnCheck.js";
/*#{1G9HCT4SI0StartDoc*/
import {FindInFiles,FindFile,FindLine} from "../lib/findfile.js";
import {LintResult,LintDoc,LintPrj} from "../lib/lint.js";
import {BoxFindFile} from "./BoxFindFile.js";
import {BoxFindLine} from "./BoxFindLine.js";
/*}#1G9HCT4SI0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let TBXLint=function(app,box,tab){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let btnError,btnAuto;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1G9HCT4SI7LocalVals*/
	let appPrj,dataDocs;
	let isFocused=0;
	let isLintPrj=0;
	let isErrorOnly=0;
	let listBox;
	/*}#1G9HCT4SI7LocalVals*/
	
	/*#{1G9HCT4SI7PreState*/
	/*}#1G9HCT4SI7PreState*/
	/*#{1G9HCT4SI7PostState*/
	/*}#1G9HCT4SI7PostState*/
	cssVO={
		"hash":"1G9HCT4SI7",nameHost:true,
		"type":"hud","x":0,"y":0,"w":"FW","h":"FH","autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
		children:[
			{
				"hash":"1G9MDTO5U0",
				"type":"hud","id":"BoxToolBtn","x":0,"y":0,"w":"FW","h":30,"autoLayout":true,"display":0,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
				children:[
					{
						"hash":"1G9MDTO5V0",
						"type":"text","position":"relative","x":0,"y":0,"w":100,"h":"FH","margin":[0,0,0,3],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor.fontToolSub,
						"text":(($ln==="CN")?("代码检查:"):("Lint Codes:")),"fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,
						"autoW":true,
					}
				],
			},
			{
				"hash":"1IA0787DC0",
				"type":BtnText("primary",100,30,(($ln==="CN")?("检查代码"):("Lint Code")),false,""),"id":"BtnLint","x":20,"y":10,"corner":3,"fontSize":txtSize.smallMid,
				/*#{1IA0787DC0Codes*/
				OnClick(){
					if(self.BtnAll.checked){
						self.lintPrj();
					}else{
						self.lintDoc();
					}
				}
				/*}#1IA0787DC0Codes*/
			},
			{
				"hash":"1IA0D5L0G0",
				"type":BtnCheck(20,"",false,false),"id":"BtnAll","x":130,"y":24,"padding":2,"checked":false,
			},
			{
				"hash":"1G9ME1T6C0",
				"type":"text","x":150,"y":24,"w":100,"h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],"text":(($ln==="CN")?("整个项目"):("Whole project")),
				"fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,
			},
			{
				"hash":"1G9MES8OJ0",
				"type":"text","id":"TxtState","x":10,"y":48,"w":100,"h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor.fontToolSub,"text":(($ln==="CN")?("代码检查结果："):("Lint result:")),
				"fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
			},
			{
				"hash":"1G9MEF4HH0",
				"type":"tree","id":"ListBox","x":10,"y":70,"w":"FW-20","h":"FH-80","autoLayout":true,"contentLayout":"flex-y","overflow":"auto-y","minW":"","minH":"",
				"maxW":"","maxH":"","styleClass":"",
				/*#{1G9MEF4HH0Codes*/
				nodeDef(obj,node){
					if(obj.line>=0){
						//This is a line:
						if(obj.type==="error"){
							return {
								type:BoxFindLine(app,appCfg.sharedAssets+"/lint_bug.svg",`[${obj.line}]: ${obj.message}`,isLintPrj?10:0,{tip:obj.message,iconColor:cfgColor.error}),info:obj,
								OnClick:function(){
									self.showLine(this.info.path,this.info.line);
								}
							};
						}else{
							return {
								type:BoxFindLine(app,appCfg.sharedAssets+"/lint_warning.svg",`[${obj.line}]: ${obj.message}`,isLintPrj?10:0,{tip:obj.message,iconColor:cfgColor.warning}),info:obj,
								OnClick:function(){
									self.showLine(this.info.path,this.info.line);
								}
							};
						}
					}else{
						//This is a file:
						if(isErrorOnly){
							return BoxFindFile(app,`${obj.path} E(${obj.errors.length})`,node,listBox);
						}else{
							return BoxFindFile(app,`${obj.path} E(${obj.errors.length}) W(${obj.warnings.length})`,node,listBox);
						}
					}
				},
				getSubObjs(obj,node){
					if(isErrorOnly){
						return obj.errors;
					}
					return obj.errors.concat(obj.warnings);
				}
				/*}#1G9MEF4HH0Codes*/
			},
			{
				"hash":"1IA0D423V0",
				"type":BtnCheck(20,"",false,false),"id":"BtnError","x":130,"y":43,"padding":2,"checked":false,
				/*#{1IA0D423V0Codes*/
				OnCheck(check){
					isErrorOnly=check;
				}
				/*}#1IA0D423V0Codes*/
			},
			{
				"hash":"1G9O1U1GC0",
				"type":"text","x":150,"y":43,"w":100,"h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["front"],"text":(($ln==="CN")?("只显示错误"):("Only errors")),
				"fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,
			},
			{
				"hash":"1IA0BB9QP0",
				"type":BtnCheck(20,"",false,false),"id":"BtnAuto","x":130,"y":5,"padding":2,"checked":false,
				/*#{1IA0BB9QP0Codes*/
				/*}#1IA0BB9QP0Codes*/
			},
			{
				"hash":"1HTGGS8S00",
				"type":"text","x":150,"y":5,"w":100,"h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],"text":(($ln==="CN")?("保存文档时自动检测"):("Auto check on save doc")),
				"fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,
			}
		],
		/*#{1G9HCT4SI7ExtraCSS*/
		/*}#1G9HCT4SI7ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			self=this;
			btnError=self.BtnError;btnAuto=self.BtnAuto;
			/*#{1G9HCT4SI7Create*/
			appPrj=app.prj;
			if(appPrj.prjConfig.autoLint){
				btnAuto.checked=true;
			}
			dataDocs=appPrj.docs;
			listBox=self.ListBox;
			
			self.toolBtnBox=self.BoxToolBtn;
			self.toolBtnBox.hold();
			self.removeChild(self.toolBtnBox);
			self.toolBtnBox.h="FH";
			self.toolBtnBox.display=1;
			dataDocs.on("DocSaved",self.OnDocSave);
			/*}#1G9HCT4SI7Create*/
		},
		/*#{1G9HCT4SI7EndCSS*/
		/*}#1G9HCT4SI7EndCSS*/
	};
	/*#{1G9HCT4SI7PostCSSVO*/
	
	//------------------------------------------------------------------------
	cssVO.OnShow=function(){
		dataDocs.on("FocusDoc",self.maybeLint);
		self.maybeLint();
		isFocused=1;
		tab.showFace("!mark");
	};
	
	//------------------------------------------------------------------------
	cssVO.OnHide=function(){
		dataDocs.off("FocusDoc",self.maybeLint);
		//dataDocs.off("DocSaved",self.maybeLint);
		isFocused=0;
	};
	
	//------------------------------------------------------------------------
	cssVO.OnDocSave=function(){
		if(isFocused){
			self.maybeLint();
		}else if(btnAuto.checked){
			self.lintDoc(true);
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.maybeLint=function(){
		if(self.BtnAll.checked){
			return;
		}
		self.lintDoc(false);
	};
	
	//------------------------------------------------------------------------
	cssVO.lintDoc=async function(background){
		let curDoc,result;
		listBox.clear();
		isLintPrj=0;
		curDoc=dataDocs.hotDoc;
		if(!curDoc){
			return;
		}
		self.BtnLint.enable=0;
		self.TxtState.display=1;
		self.TxtState.text=(($ln==="CN")?("检查文件中..."):("Linting file..."));
		result=await LintDoc(curDoc);
		if(result){
			self.TxtState.text=(($ln==="CN")?("Lint结果:"):("Lint results:"));
			self.showDocResult(result.result,background);
		}else{
			self.TxtState.text=(($ln==="CN")?("无法对此文件进行代码检查。"):("Can't lint this file."));
		}
		self.BtnLint.enable=true;
	};
	
	//------------------------------------------------------------------------
	cssVO.lintPrj=async function(){
		let curDoc,result,cnt=0;
		isLintPrj=1;
		listBox.clear();
		self.BtnLint.enable=0;
		listBox.display=0;
		self.TxtState.display=1;
		self.TxtState.text=(($ln==="CN")?("项目检查中..."):("Linting project..."));
		await LintPrj(appPrj.path,(item)=>{
			if(isErrorOnly){
				if(item.errors.length>0){
					if(!cnt){
						listBox.display=1;
					}
					cnt++;
					listBox.addNode(item,null);
				}
			}else{
				if(!cnt){
					listBox.display=1;
				}
				cnt++;
				listBox.addNode(item,null);
			}
		});
		self.TxtState.text=(($ln==="CN")?("Lint结果:"):("Lint results:"));
		self.BtnLint.enable=true;
	};
	
	//------------------------------------------------------------------------
	cssVO.showDocResult=function(result,background=false){
		let list,i,n,item,cnt;
		tab.showFace("!mark");
		if(background){
			list=result.errors;
			if(list && list.length>0){
				//TODO: Code this:
				tab.showFace("mark");
				app.showTip(tab,"Error detected in doc.");
			}
			return;
		}
		cnt=0;
		list=result.errors;
		if(list){
			n=list.length;
			if(n>0){
				listBox.display=1;
			}
			for(i=0;i<n;i++){
				item=list[i];
				listBox.addNode(item,null,{
					type:BoxFindLine(app,appCfg.sharedAssets+"/lint_bug.svg",`[${item.line}]: ${item.message}`,0,{tip:item.message,iconColor:cfgColor.error}),info:item,
					OnClick:function(){
						self.showLine(this.info.doc.path,this.info.line);
					}
				});
			}
			cnt+=n;
		}
		if(!isErrorOnly){
			list=result.warnings;
			if(list){
				n=list.length;
				if(n>0){
					listBox.display=1;
				}
				for(i=0;i<n;i++){
					item=list[i];
					listBox.addNode(item,null,{
						type:BoxFindLine(app,appCfg.sharedAssets+"/lint_warning.svg",`[${item.line}]: ${item.message}`,0,{tip:item.message,iconColor:cfgColor.warning}),info:item,
						OnClick:function(){
							self.showLine(this.info.doc.path,this.info.line);
						}
					});
				}
				cnt+=n;
			}
		}
		if(!cnt){
			self.TxtState.text=(($ln==="CN")?("没有问题，干得好。"):("Zero issues, good job."));
			listBox.display=0;
		}else{
			self.TxtState.text=("Lint result:");
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.showLine=async function(path,line){
		let file,lineIdx,doc,editor;
		doc=await dataDocs.openDoc(path);
		if(doc){
			dataDocs.focusDoc(doc);
			editor=doc.editBox;
			if(editor){
				editor.gotoLine(line);
			}
		}
	};
	/*}#1G9HCT4SI7PostCSSVO*/
	return cssVO;
};
/*#{1G9HCT4SI7ExCodes*/
TBXLint.tbxCodeName="Lint";
TBXLint.tbxTip=(($ln==="CN")?("代码检查"):("Lint Codes"));
TBXLint.tbxIcon=appCfg.sharedAssets+"/lint.svg";
TBXLint.tbxIconPad=2;
TBXLint.scoreDoc=function(doc){
	return 10;
};
TBXLint.loadOnInit=true;
/*}#1G9HCT4SI7ExCodes*/


/*#{1G9HCT4SI0EndDoc*/
/*}#1G9HCT4SI0EndDoc*/

export default TBXLint;
export{TBXLint};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1G9HCT4SI0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1G9HCT4SI1",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1G9HCT4SI2",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1H7J1D2GB0",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1G9HCT4SI3",
//			"attrs": {
//				"app": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"box": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"tab": {
//					"type": "auto",
//					"valText": "null"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1G9HCT4SI4",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1G9HCT4SI5",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "VFACT document",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1G9HCT4SI6",
//			"attrs": {}
//		},
//		"mockupStates": {
//			"jaxId": "1HTGGL9RJ0",
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1G9HCT4SI7",
//			"attrs": {
//				"properties": {
//					"jaxId": "1G9HCT4SI8",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "\"FW\"",
//						"h": "\"FH\"",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "true",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "[0,0,0,0]",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "\"\"",
//						"styleClass": ""
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1G9MDTO5U0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G9MDTO5U1",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxToolBtn",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "\"FW\"",
//										"h": "30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "true",
//										"display": "Off",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "\"\"",
//										"styleClass": "",
//										"contentLayout": "Flex X"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1G9MDTO5V0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9MDTO5V1",
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"w": "100",
//														"h": "\"FH\"",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[0,0,0,3]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "\"\"",
//														"styleClass": "",
//														"color": "#cfgColor.fontToolSub",
//														"text": {
//															"type": "string",
//															"valText": "代码检查:",
//															"localize": {
//																"EN": "Lint Codes:",
//																"CN": "代码检查:"
//															},
//															"localizable": true
//														},
//														"font": "",
//														"fontSize": "#txtSize.smallMid",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Center",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0",
//														"autoSizeW": "true",
//														"autoSizeH": "false"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1G9MDTO5V2",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1G9MDTO5V3",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1H7J1D2GB1",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1G9MDTO5V4",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1G9MDTO5V5",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H7J1D2GB2",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear/@StdUI/ui/BtnText.js",
//							"jaxId": "1IA0787DC0",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1IA07C8FV0",
//									"attrs": {
//										"style": "primary",
//										"w": "100",
//										"h": "30",
//										"text": {
//											"type": "string",
//											"valText": "检查代码",
//											"localize": {
//												"EN": "Lint Code",
//												"CN": "检查代码"
//											},
//											"localizable": true
//										},
//										"outlined": "false",
//										"icon": ""
//									}
//								},
//								"properties": {
//									"jaxId": "1IA07C8FV1",
//									"attrs": {
//										"type": "#null#>BtnText(\"primary\",100,30,(($ln===\"CN\")?(\"检查代码\"):(\"Lint Code\")),false,\"\")",
//										"id": "BtnLint",
//										"position": "Absolute",
//										"x": "20",
//										"y": "10",
//										"display": "On",
//										"face": "",
//										"corner": "3",
//										"fontSize": "#txtSize.smallMid"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1IA07C8FV2",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1IA07C8FV3",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IA07C8FV4",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "true",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false",
//								"containerSlots": {
//									"jaxId": "1IA07C8FV5",
//									"attrs": {
//										"Slot1H2F6U36O0": {
//											"jaxId": "1IA07C8FV6",
//											"attrs": {
//												"subHuds": {
//													"attrs": []
//												},
//												"container": "true"
//											}
//										}
//									}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear/@StdUI/ui/BtnCheck.js",
//							"jaxId": "1IA0D5L0G0",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1IA0D5L0G1",
//									"attrs": {
//										"size": "20",
//										"text": "",
//										"checked": "false",
//										"radio": "false"
//									}
//								},
//								"properties": {
//									"jaxId": "1IA0D5L0G2",
//									"attrs": {
//										"type": "#null#>BtnCheck(20,\"\",false,false)",
//										"id": "BtnAll",
//										"position": "Absolute",
//										"x": "130",
//										"y": "24",
//										"display": "On",
//										"face": "",
//										"padding": "2",
//										"zIndex": "0",
//										"checked": "false"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1IA0D5L0G3",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1IA0D5L0G4",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IA0D5L0G5",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false",
//								"containerSlots": {
//									"jaxId": "1IA0D5L0G6",
//									"attrs": {}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1G9ME1T6C0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G9ME3M9N8",
//									"attrs": {
//										"type": "text",
//										"id": "",
//										"position": "Absolute",
//										"x": "150",
//										"y": "24",
//										"w": "100",
//										"h": "20",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "\"\"",
//										"styleClass": "",
//										"color": "#cfgColor[\"fontBody\"]",
//										"text": {
//											"type": "string",
//											"valText": "整个项目",
//											"localize": {
//												"EN": "Whole project",
//												"CN": "整个项目"
//											},
//											"localizable": true
//										},
//										"font": "",
//										"fontSize": "#txtSize.smallMid",
//										"bold": "false",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Center",
//										"wrap": "false",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0",
//										"autoSizeW": "false",
//										"autoSizeH": "false"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1G9ME3M9N9",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1G9ME3M9N10",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H7J1D2GB7",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1G9MES8OJ0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G9MEV8450",
//									"attrs": {
//										"type": "text",
//										"id": "TxtState",
//										"position": "Absolute",
//										"x": "10",
//										"y": "48",
//										"w": "100",
//										"h": "20",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "\"\"",
//										"styleClass": "",
//										"color": "#cfgColor.fontToolSub",
//										"text": {
//											"type": "string",
//											"valText": "代码检查结果：",
//											"localize": {
//												"EN": "Lint result:",
//												"CN": "代码检查结果："
//											},
//											"localizable": true
//										},
//										"font": "",
//										"fontSize": "#txtSize.smallMid",
//										"bold": "false",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Top",
//										"wrap": "false",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0",
//										"autoSizeW": "false",
//										"autoSizeH": "false"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1G9MEV8451",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1G9MEV8452",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H7J1D2GB8",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "TreeBox",
//							"jaxId": "1G9MEF4HH0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G9MEFUK40",
//									"attrs": {
//										"type": "tree",
//										"id": "ListBox",
//										"position": "Absolute",
//										"x": "10",
//										"y": "70",
//										"w": "\"FW-20\"",
//										"h": "\"FH-80\"",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "true",
//										"display": "On",
//										"contentLayout": "flex-y",
//										"clip": "Auto Scroll Y",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "\"\"",
//										"styleClass": ""
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1G9MEFUK41",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1G9MEFUK42",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H7J1D2GB9",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "true",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear/@StdUI/ui/BtnCheck.js",
//							"jaxId": "1IA0D423V0",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1IA0D423V1",
//									"attrs": {
//										"size": "20",
//										"text": "",
//										"checked": "false",
//										"radio": "false"
//									}
//								},
//								"properties": {
//									"jaxId": "1IA0D423V2",
//									"attrs": {
//										"type": "#null#>BtnCheck(20,\"\",false,false)",
//										"id": "BtnError",
//										"position": "Absolute",
//										"x": "130",
//										"y": "43",
//										"display": "On",
//										"face": "",
//										"padding": "2",
//										"zIndex": "0",
//										"checked": "false"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1IA0D42400",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1IA0D42401",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IA0D42402",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "true",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true",
//								"containerSlots": {
//									"jaxId": "1IA0D42403",
//									"attrs": {}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1G9O1U1GC0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G9O1U1GC1",
//									"attrs": {
//										"type": "text",
//										"id": "",
//										"position": "Absolute",
//										"x": "150",
//										"y": "43",
//										"w": "100",
//										"h": "20",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "\"\"",
//										"styleClass": "",
//										"color": "#cfgColor[\"front\"]",
//										"text": {
//											"type": "string",
//											"valText": "只显示错误",
//											"localize": {
//												"EN": "Only errors",
//												"CN": "只显示错误"
//											},
//											"localizable": true
//										},
//										"font": "",
//										"fontSize": "#txtSize.smallMid",
//										"bold": "false",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Center",
//										"wrap": "false",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0",
//										"autoSizeW": "false",
//										"autoSizeH": "false"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1G9O1U1GD0",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1G9O1U1GD1",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H7J1D2GB12",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear/@StdUI/ui/BtnCheck.js",
//							"jaxId": "1IA0BB9QP0",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1IA0CRPPV0",
//									"attrs": {
//										"size": "20",
//										"text": "",
//										"checked": "false",
//										"radio": "false"
//									}
//								},
//								"properties": {
//									"jaxId": "1IA0CRPPV1",
//									"attrs": {
//										"type": "#null#>BtnCheck(20,\"\",false,false)",
//										"id": "BtnAuto",
//										"position": "Absolute",
//										"x": "130",
//										"y": "5",
//										"display": "On",
//										"face": "",
//										"padding": "2",
//										"zIndex": "0",
//										"checked": "false"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1IA0CRPPV2",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1IA0CRPPV3",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IA0CRPPV4",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "true",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true",
//								"containerSlots": {
//									"jaxId": "1IA0CRPPV5",
//									"attrs": {}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1HTGGS8S00",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HTGGS8S01",
//									"attrs": {
//										"type": "text",
//										"id": "",
//										"position": "Absolute",
//										"x": "150",
//										"y": "5",
//										"w": "100",
//										"h": "20",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "\"\"",
//										"styleClass": "",
//										"color": "#cfgColor[\"fontBody\"]",
//										"text": {
//											"type": "string",
//											"valText": "保存文档时自动检测",
//											"localize": {
//												"EN": "Auto check on save doc",
//												"CN": "保存文档时自动检测"
//											},
//											"localizable": true
//										},
//										"font": "",
//										"fontSize": "#txtSize.smallMid",
//										"bold": "false",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Center",
//										"wrap": "false",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0",
//										"autoSizeW": "false",
//										"autoSizeH": "false"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HTGGS8S10",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1HTGGS8S11",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HTGGS8S12",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1G9HCT4SI9",
//					"attrs": {}
//				},
//				"functions": {
//					"jaxId": "1G9HCT4SI10",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1H7J1D2GB13",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1G9HCT4SI11",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"innerLayout": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"face": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"marginL": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"marginR": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"marginT": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"marginB": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"paddingL": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"paddingT": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"paddingR": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"paddingB": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"attach": {
//					"type": "bool",
//					"valText": "false"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}