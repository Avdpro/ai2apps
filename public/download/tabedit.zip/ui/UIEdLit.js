//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
import {DocTabTrk} from "./DocTabTrk.js";
import {BtnCheck} from "/@StdUI/ui/BtnCheck.js";
import {BoxSteps} from "/@StdUI/ui/BoxSteps.js";
/*#{1G9EINO550StartDoc*/
import pathLib from "/@path";
import {tabFS} from "/@tabos";
import {DataDoc,DataDocs} from "../data/DataDoc.js";
import {DocEditor} from "./DocEditor.js";
import {UIEditMD} from "./UIEditMD.js";
import {UIEditVersion} from "./UIEditVersion.js";
import {UIComparePath} from "./UIComparePath.js";
import {UIEditAI} from "./UIEditAI.js";
import {StateMsg} from "./StateMsg.js";
import markdownit from "/@markdownit";
const DlgFile="/@StdUI/ui/DlgFile.js";
/*}#1G9EINO550StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let UIEdLit=function(app,appFrame,mode){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let txtCursor;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let userOpts=app.userOpts;
	
	/*#{1G9EINO557LocalVals*/
	let dataDocs=app.docs;
	let boxStateInfo=null;
	let boxInfos=[];
	let curInfoIdx=0;
	let isMac=/Mac/.test(navigator.platform);
	/*}#1G9EINO557LocalVals*/
	
	/*#{1G9EINO557PreState*/
	/*}#1G9EINO557PreState*/
	state={
		"indentSize":userOpts.IndentSize,"useTab":userOpts.UseTab,
		/*#{1G9EINO555ExState*/
		/*}#1G9EINO555ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1G9EINO557PostState*/
	/*}#1G9EINO557PostState*/
	cssVO={
		"hash":"1G9EINO557",nameHost:true,
		"type":"view","x":0,"y":0,"w":"FW","h":"FH","autoLayout":true,"display":"On","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
		children:[
			{
				"hash":"1G9EIOM5B0",
				"type":"box","id":"BoxHeader","x":0,"y":0,"w":"FW","h":cfgSize.headerH,"autoLayout":true,"padding":[0,0,0,3],"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","background":cfgColor.head,"border":[0,0,1,0],"borderColor":cfgColor.lineBodySub,"contentLayout":"flex-x","itemsAlign":1,
				children:[
					{
						"hash":"1I9VBKROJ0",
						"type":BtnIcon("front",28,0,appCfg.sharedAssets+"/labadd.svg",null),"id":"BtnNewPG","position":"relative","x":0,"y":0,"padding":1,
						"tip":(($ln==="CN")?("新实验"):("New playground")),
						/*#{1I9VBKROJ0Codes*/
						OnClick(){
							self.newPlayground();
						}
						/*}#1I9VBKROJ0Codes*/
					},
					{
						"hash":"1I9VBQPL70",
						"type":BtnIcon("front",28,0,appCfg.sharedAssets+"/fileadd.svg",null),"id":"BtnNewDoc","position":"relative","x":0,"y":0,"padding":1,
						"tip":(($ln==="CN")?("新建文档"):("New doc")),
						/*#{1I9VBQPL70Codes*/
						OnClick:function(e){
							self.doNewDoc();
						}
						/*}#1I9VBQPL70Codes*/
					},
					{
						"hash":"1I9VBV7TB0",
						"type":BtnIcon("front",28,0,appCfg.sharedAssets+"/folder.svg",null),"id":"BtnOpenDoc","position":"relative","x":0,"y":0,"padding":1,
						"tip":(($ln==="CN")?("打开文档"):("Open doc")),
						/*#{1I9VBV7TB0Codes*/
						OnClick:function(e){
							self.doOpenDoc();
						}
						/*}#1I9VBV7TB0Codes*/
					},
					{
						"hash":"1I9VC36RV0",
						"type":BtnIcon("front",28,0,appCfg.sharedAssets+"/recent.svg",null),"id":"BtnRecent","position":"relative","x":0,"y":0,"padding":1,
						"tip":(($ln==="CN")?("最近的文档"):("Recent docs")),
						/*#{1I9VC36RV0Codes*/
						OnClick(e){
							self.doOpenRecent();
						}
						/*}#1I9VC36RV0Codes*/
					},
					{
						"hash":"1I9VC6DIF0",
						"type":BtnIcon("front",28,0,appCfg.sharedAssets+"/save.svg",null),"id":"BtnSaveDoc","position":"relative","x":0,"y":0,"padding":1,
						"tip":(($ln==="CN")?("保存文档"):("Save Doc")),
						/*#{1I9VC6DIF0Codes*/
						OnClick(e){
							self.doSave();
						}
						/*}#1I9VC6DIF0Codes*/
					},
					{
						"hash":"1IA1TDQ7A0",
						"type":"hud","position":"relative","x":0,"y":0,"w":30,"h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
					},
					{
						"hash":"1IA1TE3MM0",
						"type":"box","position":"relative","x":0,"y":0,"w":1,"h":">calc(100% - 10px)","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["fontSecondaryLit"],
					},
					{
						"hash":"1IA1TDL2H0",
						"type":BtnIcon("front",28,0,appCfg.sharedAssets+"/gas_e.svg",null),"id":"BtnScript","position":"relative","x":0,"y":0,"padding":3,
						"tip":(($ln==="CN")?("执行脚本"):("Run script")),
						"OnClick":function(event){
							/*#{1IA1TIFJM0FunctionBody*/
							self.runScriptOnDoc();
							/*}#1IA1TIFJM0FunctionBody*/
						},
						/*#{1IA1TDL2H0Codes*/
						/*}#1IA1TDL2H0Codes*/
					}
				],
			},
			{
				"hash":"1G9EIQC960",
				"type":"hud","id":"BoxEditFrame","x":0,"y":cfgSize.headerH,"w":"FW","h":`FH-${cfgSize.headerH+cfgSize.footerH}`,"autoLayout":true,"minW":"","minH":"",
				"maxW":"","maxH":"","styleClass":"",
				children:[
					{
						"hash":"1G9EJ10IP0",
						"type":"box","id":"BoxTabs","x":0,"y":0,"w":"FW","h":25,"autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.tabTrack,
						"borderColor":cfgColor.lineBodySub,"contentLayout":"flex-x",
						children:[
							{
								"hash":"1G9GGD4750",
								"type":"box","x":0,"y":"FH-1","w":"FW","h":1,"autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.lineBodySub,
							},
							{
								"hash":"1G9EJ2OD30",
								"type":DocTabTrk(app,"FW"),"id":"BoxTabTrk","x":0,"y":0,
							}
						],
					},
					{
						"hash":"1G9EJ4KRJ0",
						"type":"hud","id":"BoxEdit","x":0,"y":25,"w":"FW","h":"FH-25","autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
					}
				],
			},
			{
				"hash":"1G9EIPNHM0",
				"type":"box","id":"BoxFooter","x":0,"y":"100%","w":"100%","h":cfgSize.footerH,"anchorY":2,"autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","background":cfgColor.footer,"border":[1,0,0,0],"borderColor":cfgColor.lineBodySub,
				children:[
					{
						"hash":"1G9FS2U6I0",
						"type":"hud","id":"BoxState","x":0,"y":0,"w":"100%","h":"100%","autoLayout":true,"overflow":1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						"contentLayout":"flex-xr","itemsAlign":1,
						children:[
							{
								"hash":"1G9FS45I30",
								"type":"text","position":"relative","x":0,"y":0,"w":100,"h":"FH","autoLayout":true,"margin":[0,10,0,0],"minW":"","minH":"","maxW":"","maxH":"",
								"styleClass":"","color":cfgColor["fontBody"],"text":(($ln==="CN")?("使用Tab符"):("Use Tab")),"fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal",
								"textDecoration":"","alignV":1,"autoW":true,
							},
							{
								"hash":"1I9VCUP0T0",
								"type":BtnCheck(18,"",true,false),"position":"relative","x":0,"y":0,"margin":[0,2,0,10],
								/*#{1I9VCUP0T0Codes*/
								OnCheck(checked){
									state.useTab=userOpts.UseTab=checked;
									self.updateEditConfigs();
								}
								/*}#1I9VCUP0T0Codes*/
							},
							{
								"hash":"1I9VCI01U0",
								"type":BoxSteps(18),"position":"relative","x":0,"y":0,
								/*#{1I9VCI01U0Codes*/
								OnStep(dir){
									state.indentSize+=dir;
									state.indentSize=state.indentSize<0?0:(state.indentSize>15?15:state.indentSize);
									userOpts.IndentSize=userOpts.TabSize=state.indentSize;
									self.updateEditConfigs();
								}
								/*}#1I9VCI01U0Codes*/
							},
							{
								"hash":"1G9FTHGH80",
								"type":"text","position":"relative","x":0,"y":0,"w":100,"h":"FH","autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
								"text":(($ln==="CN")?($P(()=>(`缩进：${state.indentSize}`),state)):($P(()=>(`Indent Size: ${state.indentSize}`),state))),"fontSize":txtSize.smallMid,
								"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,"autoW":true,
							},
							{
								"hash":"1IQ6O9K6U0",
								"type":"text","id":"TxtCursor","position":"relative","x":0,"y":0,"w":100,"h":"FH","autoLayout":true,"margin":12,"minW":"","minH":"","maxW":"",
								"maxH":"","styleClass":"","color":cfgColor["fontBody"],"text":"-:-","fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
								"alignV":1,"autoW":true,
							}
						],
					}
				],
			},
			{
				"hash":"1G9G7EJ6A0",
				"type":"hud","id":"BoxTips","x":"FW/8","y":100,"w":"FW*3/4","h":"FH-200","autoLayout":true,"alpha":0.6,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
			}
		],
		/*#{1G9EINO557ExtraCSS*/
		/*}#1G9EINO557ExtraCSS*/
		faces:{
			"nodoc":{
				/*BtnSaveDoc*/"#1I9VC6DIF0":{
					"enable":false
				},
				/*BtnScript*/"#1IA1TDL2H0":{
					"enable":false
				},
				/*BoxTabs*/"#1G9EJ10IP0":{
					"display":0
				},
				/*BoxTips*/"#1G9G7EJ6A0":{
					"display":1
				}
			},"hasdoc":{
				/*BtnSaveDoc*/"#1I9VC6DIF0":{
					"enable":true
				},
				/*BtnScript*/"#1IA1TDL2H0":{
					"enable":true
				},
				/*BoxTabs*/"#1G9EJ10IP0":{
					"display":1
				},
				/*BoxTips*/"#1G9G7EJ6A0":{
					"display":0
				}
			},"edlit":{
				/*BtnNewPG*/"#1I9VBKROJ0":{
					"display":0
				},
				/*BtnNewDoc*/"#1I9VBQPL70":{
					"display":1
				},
				"#1G9FS45I30":{
					"display":1
				},
				"#1I9VCUP0T0":{
					"display":1
				},
				"#1I9VCI01U0":{
					"display":1
				},
				"#1G9FTHGH80":{
					"display":1
				},
				/*TxtCursor*/"#1IQ6O9K6U0":{
					"display":1
				}
			},"playground":{
				/*BtnNewPG*/"#1I9VBKROJ0":{
					"display":1
				},
				/*BtnNewDoc*/"#1I9VBQPL70":{
					"display":0
				},
				"#1G9FS45I30":{
					"display":0
				},
				"#1I9VCUP0T0":{
					"display":0
				},
				"#1I9VCI01U0":{
					"display":0
				},
				"#1G9FTHGH80":{
					"display":0
				},
				/*TxtCursor*/"#1IQ6O9K6U0":{
					"display":0
				}
			}
		},
		OnCreate:function(){
			self=this;
			txtCursor=self.TxtCursor;
			/*#{1G9EINO557Create*/
			app.mainUI=self;
			
			//Tab track scroll by mouse wheel:
			self.BoxTabTrk.webObj.onwheel=function(e){
				let dx,dy;
				if(e.deltaMode!==0){
					return;
				}
				dx=e.deltaX;
				dy=e.deltaY;
				if(dx===0 && dy){
					dy=dy>20?20:dy;
					dy=dy<-20?-20:dy;
					dx=-dy;
				}
				self.BoxTabTrk.webObj.scrollLeft+=dx;
			};
			
			if(mode==="playground"){
				self.showFace("playground");
			}else{
				self.showFace("edlit");
			}
			
			app.setFocusBox(self);
			self.showFace("nodoc");
			dataDocs.on("NewDoc",self.OnNewDoc);
			dataDocs.on("CloseDoc",self.OnCloseDoc);
			dataDocs.on("FocusDoc",self.OnFocusDoc);
			dataDocs.on("BlurDoc",self.OnBlurDoc);
			dataDocs.on("DocChanged",self.OnDocChanged);
			dataDocs.on("DocSaved",self.OnDocSaved);
			dataDocs.on("DocLoaded",self.OnDocLoaded);
			
			//Init environment:
			self.loadOpts().then(async ()=>{
				let hState,doc;
				hState=history.state;
				if(hState && hState.docs){
					await self.openFile(hState.docs);
					if(hState.hotDoc){
						setTimeout(()=>{
							doc=dataDocs.docHash[hState.hotDoc];
							if(doc){
								dataDocs.focusDoc(doc);
							}
						},300);
					}
				}else{
					let appPm;
					appPm=app.appParams;
					if(appPm.file){
						await self.openFile(appPm.file);
					}else if(appPm.compath){
						dataDocs.openCompath(appPm.compath);
					}else if(appPm.compare){
						dataDocs.openCompare(appPm.compare);
					}
				}
				if(mode==="playground"){
					self.newPlayground();
				}
			});
			//init state-message stuffs:
			boxStateInfo=self.BoxState;
			boxInfos[0]=boxStateInfo.appendNewChild({type:StateMsg(app),x:5});
			boxInfos[1]=boxStateInfo.appendNewChild({type:StateMsg(app),x:5});
			self.showStateText("Ready",0);
			
			//load and show tips:
			let showTip=async function(){
				let dir,path;
				dir=app.appDir;
				dir=dir.startsWith("//")?dir.substring(1):dir;
				if(mode==="playground"){
					path=pathLib.join(dir,(($ln==="CN")?("playground_cn.md"):/*EN*/("playground.md")));
				}else{
					path=pathLib.join(dir,(($ln==="CN")?("tip_cn.md"):/*EN*/("tip.md")));
				}
				try{
					let text=await tabFS.readFile(path,"utf8");
					text=markdownit().render(text);
					self.BoxTips.webObj.innerHTML=text;
				}catch(err){
					console.error(err);
				}
			}
			showTip();
			/*}#1G9EINO557Create*/
		},
		/*#{1G9EINO557EndCSS*/
		/*}#1G9EINO557EndCSS*/
	};
	/*#{1G9EINO557PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.loadOpts=async function(){
		let text,cfg,userOpts;
		userOpts=app.userOpts;
		try{
			text=await tabFS.readFile("/doc/edlit/options.json","utf8");
			cfg=JSON.parse(text);
			userOpts.UseTab=cfg.UseTab||true;
			userOpts.TabSize=cfg.IndentSize||4;
			userOpts.IndentSize=cfg.IndentSize||4;
			state.indentSize=userOpts.IndentSize;
			state.useTab=userOpts.UseTab;
		}catch(e){
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.saveOpts=async function(){
		let text,cfg,userOpts;
		userOpts=app.userOpts;
		try{
			await tabFS.writeFile("/doc/edlit/options.json",JSON.stringify(userOpts),"utf8");
		}catch(e){
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.openFile=async function(filePath){
		let list,doc;
		if(!filePath){
			return;
		}
		if(Array.isArray(filePath)){
			list=filePath;
		}else{
			list=[filePath];
		}
		for(filePath of list){
			if(filePath[0]==="/"){
				await dataDocs.openDoc(filePath);
			}
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.saveDocsState=function(all){
		let tab,docs,state,tabs,i,n;
		if(all || !history.state){
			docs=[];
			tabs=self.BoxTabTrk.children;
			n=tabs.length;
			for(i=0;i<n;i++){
				tab=tabs[i]
				if(tab.doc){
					docs.push(tab.doc.path);
				}
			}
			state={docs:docs,hotDoc:dataDocs.hotDoc?dataDocs.hotDoc.path:null};
			history.replaceState(state,"",document.location.href);
		}else{
			state={...history.state};
			state.hotDoc=dataDocs.hotDoc?dataDocs.hotDoc.path:null;
			history.replaceState(state,"",document.location.href);
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.isAnyChanged=function(){
		let list,doc;
		list=dataDocs.docList;
		for(doc of list){
			if(doc.isChanged()){
				return true;
			}
		}
		return false;
	};
	
	//************************************************************************
	//UI-Actions:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		cssVO.doNewDoc=function(){
			app.showDlg("/@StdUI/ui/DlgMenu.js",{
				hud:self.BtnNewDoc,
				y:self.BtnNewDoc.h,
				items:[
					{text:(($ln==="CN")?("带路径的新文档"):("New doc with path")),code:"create",icon:appCfg.sharedAssets+"/folder.svg"},
					{text:(($ln==="CN")?("没有路径的新文件"):("New doc without path")),code:"empty",icon:appCfg.sharedAssets+"/fileadd.svg"},
					"_",
					{text:(($ln==="CN")?("比较路径"):("Compare path")),code:"Compath",icon:appCfg.sharedAssets+"/folderequ.svg"},
					{text:(($ln==="CN")?("新实验项目：AI-聊天"):("New Playground: AI-Chat")),code:"PG-AIChat",icon:appCfg.sharedAssets+"/lab.svg",enable:false},
					{text:(($ln==="CN")?("新实验项目：HTML"):("New Playground: HTML")),code:"PG-HTML",icon:appCfg.sharedAssets+"/lab.svg",enable:false},
				],
				callback(item){
					if(!item){
						return;
					}
					if(item.code==="create"){
						return self.createNewDoc();
					}else if(item.code==="PG-AIChat"){
						dataDocs.newEmptyDoc(".aichat");
					}else if(item.code==="PG-HTML"){
						dataDocs.newEmptyDoc(".pghtml");
					}else if(item.code==="Compath"){
						dataDocs.openCompath({leftPath:"/",rightPath:"/"});
					}else{
						app.showDlg("/@StdUI/ui/DlgMenu.js",{
							hud:self.BtnNewDoc,
							items:[
								{text:"Javascript file: .js",code:".js"},
								{text:"Javascript modual file: .mjs",code:".js"},
								{text:"HTML file: .html",code:".html"},
								{text:"CSS file: .css",code:".css"},
								{text:"Markdonwn file: .md",code:".md"},
								{text:"Text file: .txt",code:".txt"},
							],
							callback(item){
								if(!item){
									return;
								}
								dataDocs.newEmptyDoc(item.code);
							}
						});
					}
				}
			});
		};
		//--------------------------------------------------------------------
		cssVO.createNewDoc=function(){
			let hotDoc,path;
			hotDoc=dataDocs.hotDoc;
			if(hotDoc){
				path=pathLib.dirname(hotDoc.path);
			}else{
				path="/";
			}
			app.showDlg(DlgFile,{
				mode:"save",
				path:path,
				buttonText:(($ln==="CN")?("创建"):/*EN*/("Create")),
				options:{
					multiSelect:0,
					preview:1,
				},
				callback:async function(filePath){
					if(!filePath){
						return;
					}
					try{
						await tabFS.writeFile(filePath,"","utf8");
						dataDocs.openDoc(filePath);
					}catch(e){
					}
				}
			});
		};
	
		//--------------------------------------------------------------------
		cssVO.newPlayground=async function(){
			let dlgDef;
			dlgDef=(await import("./DlgNewPlayground.js")).DlgNewPlayground;
			app.showDlg(dlgDef,{});
		};
		
		//--------------------------------------------------------------------
		cssVO.doOpenDoc=function(){
			let hotDoc,path;
			hotDoc=dataDocs.hotDoc;
			if(hotDoc){
				path=pathLib.dirname(hotDoc.path);
			}else{
				path="/";
			}
			app.showDlg(DlgFile,{
				mode:"open",
				path:path,
				options:{
					multiSelect:1,
					preview:1,
				},
				callback:async function(filePath){
					self.openFile(filePath);
				}
			});
		};
	
		//----------------------------------------------------------------
		cssVO.doOpenRecent=async function(){
			let list;
			list=await dataDocs.getUsage();
			list=list.reverse();
			list=list.map(item=>{return {text:item,icon:appCfg.sharedAssets+"/file.svg",path:item}});
			list=list.filter(item=>item.path[0]==="/");
			if(!list.length){
				list.push({text:(($ln==="CN")?("未找到最近的文档"):("No recent doc found")),enable:false});
			}
			app.showDlg("/@StdUI/ui/DlgMenu.js",{
				hud:self.BtnRecent,
				x:0,y:self.BtnRecent.h*0.5,
				items:list,
				callback:function(item){
					if(!item){
						return;
					}
					dataDocs.openDoc(item.path);
				}
			});
		};
	
		//----------------------------------------------------------------
		cssVO.doSave=async function(){
			let doc;
			doc=dataDocs.hotDoc;
			if(doc){
				if(doc.path.startsWith("/")){
					app.showDlg("/@StdUI/ui/DlgMenu.js",{
						hud:self.BtnSaveDoc,
						items:[
							{
								text:(($ln==="CN")?(isMac?"保存 (Cmd+S)" : "保存 (Ctrl+S)"):(isMac?"Save (Cmd+S)":"Save (Ctrl+S)")),
								code:"Save"
							},
							{
								text:(($ln==="CN")?(isMac? '另存为（Cmd+Shift+S）' : '另存为（Ctrl+Shift+S）'):(isMac?"Save as (Cmd+Shift+S)":"Save as (Ctrl+Shift+S)")),
								code:"SaveAs"
							},
						],
						callback(item){
							if(!item){
								return;
							}
							if(item.code==="Save"){
								self.doSaveDoc();
							}else{
								self.doSaveAsDoc();
							}
						}
					});					
				}else{
					await self.doSaveAsDoc(true);
				}
			}
		};
	
		//----------------------------------------------------------------
		cssVO.doSaveDoc=async function(){
			let doc,ext;
			doc=dataDocs.hotDoc;
			if(doc){
				ext=pathLib.extname(doc.path);
				if(ext===".compare"){
					return;
				}
				if(doc.path.startsWith("/")){
					await doc.saveDoc();
				}else{
					await self.doSaveAsDoc(true);
				}
			}
		};
	
		//----------------------------------------------------------------
		cssVO.doSaveAsDoc=async function(closeCurDoc=false){
			let hotDoc,path,fname,extName;
			hotDoc=dataDocs.hotDoc;
			if(!hotDoc){
				return;
			}
			extName=hotDoc.fileExt||pathLib.extname(hotDoc.path);
			if(extName===".compare"){
				return;
			}
			path=pathLib.dirname(hotDoc.path);
			if(!path || path==="."){
				path="/doc";
			}
			fname=pathLib.basename(hotDoc.path);
			app.showDlg(DlgFile,{
				mode:"save",
				path:path,
				fileName:fname,
				options:{
					multiSelect:1,
					preview:1,
				},
				callback:async function(filePath){
					let list,doc;
					if(!filePath){
						return;
					}
					if(filePath===hotDoc.path){
						return;
					}
					await tabFS.writeFile(filePath,hotDoc.getDocText(),"utf8");
					if(closeCurDoc){
						dataDocs.closeDoc(hotDoc);
					}
					dataDocs.openDoc(filePath);
				}
			});
		};
	
		//--------------------------------------------------------------------
		cssVO.doCloseDoc=function(){
			let doc;
			doc=dataDocs.hotDoc;
			if(doc){
				if(doc.isChanged()){
					if(!window.confirm((($ln==="CN")?(`${doc.path} 已修改，您确定要放弃更改并关闭吗？`):(`${doc.path} is changed, are you sure to abort changes and close it?`)))){
						return;
					}
				}
				dataDocs.closeDoc(doc);
			}
		};
	
		//--------------------------------------------------------------------
		cssVO.updateEditConfigs=function(){
			let doc,docs,editBox;
			docs=dataDocs.docList;
			for(doc of docs){
				editBox=doc.editBox;
				if(editBox){
					editBox.applyCfg();
				}
			}
			self.saveOpts();
		};
	
		//--------------------------------------------------------------------
		cssVO.openWatcher=function(){
			//TODO: Code this:
		};
	
		//--------------------------------------------------------------------
		cssVO.checkDocsModify=function(){
			dataDocs.checkDocsModify();
		};
	}
	//************************************************************************
	//Handle shortcuts:
	//************************************************************************
	{
		let altKeyDown=0;
		let altHotDoc=null;
		let ctrlKeyDown=0;
		let ctrlHotDoc=null;
		let docPos;
		//--------------------------------------------------------------------
		cssVO.OnKeyDown=function(code,e){
			let doc;
			if(!altKeyDown && e.key==="Alt"){
				altKeyDown=1;
				altHotDoc=null;
				docPos=dataDocs.docList.length-1;//Cur hot doc:
				doc=dataDocs.hotDoc;
				if(doc && doc.editBox){
					doc.editBox.blur();
				}
			}
			if(e.key==="Escape" && e.ctrlKey){
				if(!ctrlKeyDown){
					ctrlKeyDown=1;
					ctrlHotDoc=null;
					docPos=dataDocs.docList.length-1;//Cur hot doc:
					doc=dataDocs.hotDoc;
					if(doc && doc.editBox){
						doc.editBox.blur();
					}
				}
				if(e.shiftKey){
					docPos++;
					if(docPos>=dataDocs.docList.length){
						docPos=0;
					}
				}else{
					docPos--;
					if(docPos<0){
						docPos=dataDocs.docList.length-1;
					}
				}
				doc=dataDocs.docList[docPos];
				if(doc){
					dataDocs.focusDoc(doc,false);
					ctrlHotDoc=doc;
				}
				return 1;
			}
			if(altKeyDown && e.key==="Tab"){
				//Quick switch between docs:
				if(e.shiftKey){
					docPos++;
					if(docPos>=dataDocs.docList.length){
						docPos=0;
					}
				}else{
					docPos--;
					if(docPos<0){
						docPos=dataDocs.docList.length-1;
					}
				}
				doc=dataDocs.docList[docPos];
				if(doc){
					dataDocs.focusDoc(doc,false);
					altHotDoc=doc;
				}
				return 1;
			}
		};
	
		//--------------------------------------------------------------------
		cssVO.OnKeyUp=function(code,e){
			if(ctrlKeyDown && e.key==="Control"){
				ctrlKeyDown=0;
				if(ctrlHotDoc){
					dataDocs.focusDoc(ctrlHotDoc,true);
					return 1;
				}else{
					let doc;
					doc=dataDocs.hotDoc;
					if(doc && doc.editBox){
						doc.editBox.focus();
					}
				}
			}else if(altKeyDown && e.key==="Alt"){
				altKeyDown=0;
				if(altHotDoc){
					dataDocs.focusDoc(altHotDoc,true);
					return 1;
				}else{
					let doc;
					doc=dataDocs.hotDoc;
					if(doc && doc.editBox){
						doc.editBox.focus();
					}
				}
			}
		};
	
		//--------------------------------------------------------------------
		cssVO.handleShortcut=function(cmd){
			let hotDoc;
			switch(cmd){
				case "NewDoc":{
					self.doNewDoc();
					return 1;
				}
				case "Save":{
					self.doSaveDoc();
					return 1;
				}
				case "SaveAs":{
					self.doSaveAsDoc();
					return 1;
				}
				case "Open":{
					self.doOpenDoc();
					return 1;
				}
				case "Close":{
					self.doCloseDoc();
					return 1;
				}
				//AI Dialog:
				case "AIChat":{
					let rootApp;
					rootApp=app.appFrame?app.appFrame.app:app;
					rootApp.showDlg("/@aichat/ui/DlgAIChat.js",{url:"/@aichat/ai/default.aichat"});
					return 1;
				}
			}
			hotDoc=dataDocs.hotDoc;
			if(hotDoc && hotDoc.editBox){
				return hotDoc.editBox.handleShortcut(cmd);
			}
			return 0;
		};
	}
	
	//************************************************************************
	//Doc management event handlers:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		cssVO.OnNewDoc=async function(doc){
			let docText,editBox,docTab,css,hotDoc,hotTab,nextTab;
			//Create Editor and tab:
			docText=doc.getDocText();
			if(doc.fileExt===".md"){
				css=UIEditMD(app,pathLib.extname(doc.path),docText,app.userOpts,doc);
			}else if(doc.fileExt===".baseversion"){
				css=UIEditVersion(app,pathLib.extname(doc.path),docText,app.userOpts,doc);
			}else if(doc.fileExt===".conflict"){
				css=UIEditVersion(app,pathLib.extname(doc.path),docText,app.userOpts,doc);
			}else if(doc.fileExt===".aichat"){
				css=UIEditAI(app,pathLib.extname(doc.path),docText,app.userOpts,doc);
			}else if(doc.fileExt===".compare"){
				css=UIEditVersion(app,pathLib.extname(doc.path),docText,app.userOpts,doc);
			}else if(doc.fileExt===".compath"){
				css=UIComparePath(app,pathLib.extname(doc.path),docText,app.userOpts,doc);
			}else{
				css=DocEditor(app,pathLib.extname(doc.path),docText,app.userOpts,doc);
			}
			editBox=self.BoxEdit.appendNewChild(css);
			doc.assignEditor(editBox);
			//await editBox.init(doc);
			dataDocs.focusDoc(doc);
			//Check if sigle doc
			if(dataDocs.docList.length>0){
				self.showFace("hasdoc");
			}else{
				self.showFace("nodoc");
			}
			self.saveDocsState(1);
		};
	
		//--------------------------------------------------------------------
		cssVO.OnCloseDoc=async function(doc){
			let editBox,docTab;
			editBox=doc.editBox;
			if(editBox){
				self.BoxEdit.removeChild(editBox);
				doc.editBox=null;
			}
			//Check if sigle doc
			if(dataDocs.docList.length>0){
				self.showFace("hasdoc");
			}else{
				self.showFace("nodoc");
				app.setTitle(mode==="playground"?"Playground":"Edit Pad");
			}
			self.saveDocsState(1);
		};
	
		//--------------------------------------------------------------------
		cssVO.OnFocusDoc=function(doc){
			let editBox,text;
			editBox=doc.editBox;
			if(editBox){
				editBox.display=1;
				editBox.focus();
				if(doc.isChanged()){
					text="*"+doc.name;
				}else{
					text=doc.name;
				}
			}else{
				text=doc.name;
			}
			app.setTitle(text);
			self.saveDocsState(0);
		};
	
		//--------------------------------------------------------------------
		cssVO.OnDocChanged=function(doc){
			let text;
			if(doc===dataDocs.hotDoc){
				text="*"+doc.name;
				app.setTitle(text);
			}
		};
	
		//--------------------------------------------------------------------
		cssVO.OnDocSaved=function(doc){
			let text;
			if(doc===dataDocs.hotDoc){
				app.setTitle(doc.name);
			}
			self.showStateText((($ln==="CN")?(`文件 ${doc.path} 已保存。`):(`File ${doc.path} saved.`)));
		};
	
		//--------------------------------------------------------------------
		cssVO.OnDocLoaded=function(doc){
			let text;
			if(doc===dataDocs.hotDoc){
				app.setTitle(doc.name);
			}
			self.showStateText((($ln==="CN")?(`文件 ${doc.path} 已加载。`):(`File ${doc.path} loaded.`)));
		};
	
		//--------------------------------------------------------------------
		cssVO.OnBlurDoc=function(doc){
			let editBox;
			editBox=doc.editBox;
			if(editBox){
				editBox.display=0;
			}
		};
	}
	
	//************************************************************************
	//App state message:
	//************************************************************************
	{
		let outTimer=null;
		//--------------------------------------------------------------------
		app.showStateText=cssVO.showStateText=function(text,time=5000,utext="",onclick=null){
			let opts,icon,oldBox,newBox;
			//boxStateInfo.w=self.TxtIndent.webObj.offsetLeft-10;
			if(outTimer){
				clearTimeout(outTimer);
				outTimer=null;
			}
			if(time instanceof Object){
				time=opts.time||5000;
				utext=opts.utext||"";
				onclick=opts.callback||null;
				icon=opts.icon||null;
			}
			oldBox=boxInfos[curInfoIdx];
			if(oldBox.display){
				oldBox.y=0;
				oldBox.animate({type:"out",dx:0,dy:-25,time:60})
			}
			curInfoIdx=curInfoIdx?0:1;
			newBox=boxInfos[curInfoIdx];
			newBox.showMsg(icon,text,utext,onclick);
			newBox.y=0;
			newBox.animate({type:"in",dx:0,dy:25,time:100})
			if(time){
				outTimer=setTimeout(()=>{
					self.showStateText("Ready",0);
				},time);
			}
		};
		
		//--------------------------------------------------------------------
		app.setCursorText=cssVO.setCursorText=function(text){
			txtCursor.text=text;
		};
	}
	
	//************************************************************************
	//Run script on doc text:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		let scriptPath="";
		cssVO.runScriptOnDoc=async function(){
			let doc,path,code,script;
			doc=dataDocs.hotDoc;
			if(!doc){
				return;
			}
			if(!scriptPath){
				path=pathLib.dirname(doc.path);
			}else{
				path=scriptPath;
			}
			path=await app.modalDlg(DlgFile,{
				mode:"open",
				path:path,
				filter:"*.js",
				options:{
					multiSelect:0,
					preview:1,
				}
			});
			if(!path){
				return;
			}
			scriptPath=pathLib.dirname(path);
			try{
				code=doc.getDocText();
				script=(await import("/~"+path)).default;
				code=await script(code,app,doc);
				if(code){
					doc.setDocText(code,true);
				}
			}catch(err){
				window.alert(`Run script "${path}" error: ${err}. See log in browser console.`);
				console.error(err);
			}
		};
	}
	
	if(appFrame){
		appFrame.openFileInFrame=function(path){
			dataDocs.openDoc(path).then(doc=>{
				dataDocs.focusDoc(doc);
			});
			return true;
		};
		appFrame.openNewParam=function(param){
			if(param.path){
				dataDocs.openDoc(param.path).then(doc=>{
					dataDocs.focusDoc(doc);
				});
				return true;
			}
			if(param.compare){
				dataDocs.openCompare(param.compare).then(doc=>{
					dataDocs.focusDoc(doc);
				});
				return true;
			}
			if(param.compath){
				dataDocs.openCompath(param.compath).then(doc=>{
					dataDocs.focusDoc(doc);
				});
				return true;
			}
		}
	}
	/*}#1G9EINO557PostCSSVO*/
	cssVO.constructor=UIEdLit;
	return cssVO;
};
/*#{1G9EINO557ExCodes*/
/*}#1G9EINO557ExCodes*/

//----------------------------------------------------------------------------
UIEdLit.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1G9EINO557PreAISpot*/
	/*}#1G9EINO557PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1G9EINO557PostAISpot*/
	/*}#1G9EINO557PostAISpot*/
	return exposeVO;
};

/*#{1G9EINO550EndDoc*/
/*}#1G9EINO550EndDoc*/

export default UIEdLit;
export{UIEdLit};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "UIView",
//	"jaxId": "1G9EINO550",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1G9EINO551",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "500",
//				"screenH": "600",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1G9EINO552",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1H7HLOGQ60",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1G9EINO553",
//			"attrs": {
//				"app": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"appFrame": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"mode": {
//					"type": "string",
//					"valText": "edit"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1G9EINO554",
//			"attrs": {
//				"userOpts": {
//					"type": "auto",
//					"valText": "#null#>app.userOpts"
//				}
//			}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1G9EINO555",
//			"attrs": {
//				"indentSize": {
//					"type": "int",
//					"valText": "#4#>userOpts.IndentSize"
//				},
//				"useTab": {
//					"type": "bool",
//					"valText": "#true#>userOpts.UseTab"
//				}
//			}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "VFACT document",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1G9EINO556",
//			"attrs": {
//				"nodoc": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1G9FUG1N20",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1G9FUG1O00",
//							"attrs": {}
//						}
//					}
//				},
//				"hasdoc": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1G9FUG7200",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1G9FUG72Q0",
//							"attrs": {}
//						}
//					}
//				},
//				"edlit": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H0VKFUDI0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H0VKMSF00",
//							"attrs": {}
//						}
//					}
//				},
//				"playground": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H0VKGKI40",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H0VKMSF01",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1HD8HJKTA0",
//			"attrs": {}
//		},
//		"exposeToAI": "true",
//		"descAI": "",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "view",
//			"jaxId": "1G9EINO557",
//			"attrs": {
//				"properties": {
//					"jaxId": "1G9EINO558",
//					"attrs": {
//						"type": "view",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "\"FW\"",
//						"h": "\"FH\"",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "true",
//						"display": "\"On\"",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "[0,0,0,0]",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "\"\"",
//						"styleClass": ""
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1G9EIOM5B0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G9EIOM5B1",
//									"attrs": {
//										"type": "box",
//										"id": "BoxHeader",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "\"FW\"",
//										"h": "#cfgSize.headerH",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "true",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,0]",
//										"padding": "[0,0,0,3]",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "\"\"",
//										"styleClass": "",
//										"background": "#cfgColor.head",
//										"border": "[0,0,1,0]",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor.lineBodySub",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"contentLayout": "Flex X",
//										"itemsAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1I9VBKROJ0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1I9VBNRP62",
//													"attrs": {
//														"style": "\"front\"",
//														"w": "28",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/labadd.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1I9VBNRP70",
//													"attrs": {
//														"type": "#null#>BtnIcon(\"front\",28,0,appCfg.sharedAssets+\"/labadd.svg\",null)",
//														"id": "BtnNewPG",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"padding": "1"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I9VBNRP71",
//													"attrs": {
//														"1H0VKFUDI0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I9VBNRP76",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I9VBNRP77",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H0VKFUDI0",
//															"faceTagName": "edlit"
//														},
//														"1H0VKGKI40": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I9VBQ9K20",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I9VBQ9K21",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H0VKGKI40",
//															"faceTagName": "playground"
//														},
//														"1G9FUG1N20": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I9VC8J8U0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I9VC8J8U1",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1G9FUG1N20",
//															"faceTagName": "nodoc"
//														},
//														"1G9FUG7200": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I9VC8J8U2",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I9VC8J8U3",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1G9FUG7200",
//															"faceTagName": "hasdoc"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I9VBNRP78",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I9VBNRP79",
//													"attrs": {
//														"tip": {
//															"type": "string",
//															"valText": "新实验",
//															"localize": {
//																"EN": "New playground",
//																"CN": "新实验"
//															},
//															"localizable": true
//														}
//													}
//												},
//												"mockup": "false",
//												"codes": "true",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1I9VBNRP710",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1I9VBQPL70",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1I9VBQPL71",
//													"attrs": {
//														"style": "\"front\"",
//														"w": "28",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/fileadd.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1I9VBQPL72",
//													"attrs": {
//														"type": "#null#>BtnIcon(\"front\",28,0,appCfg.sharedAssets+\"/fileadd.svg\",null)",
//														"id": "BtnNewDoc",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"padding": "1"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I9VBQPL73",
//													"attrs": {
//														"1H0VKFUDI0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I9VBQPL78",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I9VBQPL79",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H0VKFUDI0",
//															"faceTagName": "edlit"
//														},
//														"1H0VKGKI40": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I9VBQPL710",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I9VBQPL711",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H0VKGKI40",
//															"faceTagName": "playground"
//														},
//														"1G9FUG1N20": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I9VC8J8U4",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I9VC8J8U5",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1G9FUG1N20",
//															"faceTagName": "nodoc"
//														},
//														"1G9FUG7200": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I9VC8J8U6",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I9VC8J8U7",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1G9FUG7200",
//															"faceTagName": "hasdoc"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I9VBQPL712",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I9VBQPL713",
//													"attrs": {
//														"tip": {
//															"type": "string",
//															"valText": "新建文档",
//															"localize": {
//																"EN": "New doc",
//																"CN": "新建文档"
//															},
//															"localizable": true
//														}
//													}
//												},
//												"mockup": "false",
//												"codes": "true",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1I9VBQPL714",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1I9VBV7TB0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1I9VBV7TB1",
//													"attrs": {
//														"style": "\"front\"",
//														"w": "28",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/folder.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1I9VBV7TB2",
//													"attrs": {
//														"type": "#null#>BtnIcon(\"front\",28,0,appCfg.sharedAssets+\"/folder.svg\",null)",
//														"id": "BtnOpenDoc",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"padding": "1"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I9VBV7TB3",
//													"attrs": {
//														"1G9FUG1N20": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I9VC8J8U8",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I9VC8J8U9",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1G9FUG1N20",
//															"faceTagName": "nodoc"
//														},
//														"1G9FUG7200": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I9VC8J8U10",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I9VC8J8U11",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1G9FUG7200",
//															"faceTagName": "hasdoc"
//														},
//														"1H0VKGKI40": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I9VD1DDI0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I9VD1DDI1",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H0VKGKI40",
//															"faceTagName": "playground"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I9VBV7TC6",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I9VBV7TC7",
//													"attrs": {
//														"tip": {
//															"type": "string",
//															"valText": "打开文档",
//															"localize": {
//																"EN": "Open doc",
//																"CN": "打开文档"
//															},
//															"localizable": true
//														}
//													}
//												},
//												"mockup": "false",
//												"codes": "true",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1I9VBV7TC8",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1I9VC36RV0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1I9VC36RV1",
//													"attrs": {
//														"style": "\"front\"",
//														"w": "28",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/recent.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1I9VC36RV2",
//													"attrs": {
//														"type": "#null#>BtnIcon(\"front\",28,0,appCfg.sharedAssets+\"/recent.svg\",null)",
//														"id": "BtnRecent",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"padding": "1"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I9VC36RV3",
//													"attrs": {
//														"1G9FUG1N20": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I9VC8J8U12",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I9VC8J8U13",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1G9FUG1N20",
//															"faceTagName": "nodoc"
//														},
//														"1G9FUG7200": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I9VC8J8U14",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I9VC8J8U15",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1G9FUG7200",
//															"faceTagName": "hasdoc"
//														},
//														"1H0VKGKI40": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I9VD1DDI2",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I9VD1DDI3",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H0VKGKI40",
//															"faceTagName": "playground"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I9VC36S06",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I9VC36S07",
//													"attrs": {
//														"tip": {
//															"type": "string",
//															"valText": "最近的文档",
//															"localize": {
//																"EN": "Recent docs",
//																"CN": "最近的文档"
//															},
//															"localizable": true
//														}
//													}
//												},
//												"mockup": "false",
//												"codes": "true",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1I9VC36S08",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1I9VC6DIF0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1I9VC6DIF1",
//													"attrs": {
//														"style": "\"front\"",
//														"w": "28",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/save.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1I9VC6DIF2",
//													"attrs": {
//														"type": "#null#>BtnIcon(\"front\",28,0,appCfg.sharedAssets+\"/save.svg\",null)",
//														"id": "BtnSaveDoc",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"padding": "1"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I9VC6DIF3",
//													"attrs": {
//														"1G9FUG7200": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I9VC6DIG0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I9VC6DIG1",
//																	"attrs": {
//																		"enable": {
//																			"type": "bool",
//																			"valText": "true"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1G9FUG7200",
//															"faceTagName": "hasdoc"
//														},
//														"1G9FUG1N20": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I9VC8J8U16",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I9VC8J8U17",
//																	"attrs": {
//																		"enable": {
//																			"type": "bool",
//																			"valText": "false"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1G9FUG1N20",
//															"faceTagName": "nodoc"
//														},
//														"1H0VKGKI40": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I9VD1DDI4",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I9VD1DDI5",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H0VKGKI40",
//															"faceTagName": "playground"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I9VC6DIG2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I9VC6DIG3",
//													"attrs": {
//														"tip": {
//															"type": "string",
//															"valText": "保存文档",
//															"localize": {
//																"EN": "Save Doc",
//																"CN": "保存文档"
//															},
//															"localizable": true
//														}
//													}
//												},
//												"mockup": "false",
//												"codes": "true",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1I9VC6DIG4",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1IA1TDQ7A0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IA1TFT7R0",
//													"attrs": {
//														"type": "hud",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "30",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": ""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IA1TFT7R1",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1IA1TFT7R2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IA1TFT7R3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1IA1TE3MM0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IA1TFT7R4",
//													"attrs": {
//														"type": "box",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "1",
//														"h": "100%-10",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "#cfgColor[\"fontSecondaryLit\"]",
//														"border": "0",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IA1TFT7R5",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1IA1TFT7R6",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IA1TFT7R7",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1IA1TDL2H0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1IA1TDL2H1",
//													"attrs": {
//														"style": "\"front\"",
//														"w": "28",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/gas_e.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1IA1TDL2H2",
//													"attrs": {
//														"type": "#null#>BtnIcon(\"front\",28,0,appCfg.sharedAssets+\"/gas_e.svg\",null)",
//														"id": "BtnScript",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"padding": "3"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IA1TDL2H3",
//													"attrs": {
//														"1G9FUG7200": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IA1TDL2H4",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IA1TDL2H5",
//																	"attrs": {
//																		"enable": {
//																			"type": "bool",
//																			"valText": "true"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1G9FUG7200",
//															"faceTagName": "hasdoc"
//														},
//														"1G9FUG1N20": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IA1TDL2I0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IA1TDL2I1",
//																	"attrs": {
//																		"enable": {
//																			"type": "bool",
//																			"valText": "false"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1G9FUG1N20",
//															"faceTagName": "nodoc"
//														},
//														"1H0VKGKI40": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IA1TDL2I2",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IA1TDL2I3",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H0VKGKI40",
//															"faceTagName": "playground"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IA1TDL2I4",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1IA1TIFJM0",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1IA1TJLFD0",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1IA1TDL2I5",
//													"attrs": {
//														"tip": {
//															"type": "string",
//															"valText": "执行脚本",
//															"localize": {
//																"EN": "Run script",
//																"CN": "执行脚本"
//															},
//															"localizable": true
//														}
//													}
//												},
//												"mockup": "false",
//												"codes": "true",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1IA1TDL2I6",
//													"attrs": {}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1G9EIOM5G6",
//									"attrs": {
//										"1G9FUG1N20": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I9VC8J8U18",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I9VC8J8U19",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9FUG1N20",
//											"faceTagName": "nodoc"
//										},
//										"1G9FUG7200": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I9VC8J8U20",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I9VC8J8U21",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9FUG7200",
//											"faceTagName": "hasdoc"
//										},
//										"1H0VKGKI40": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I9VD1DDI6",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I9VD1DDI7",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H0VKGKI40",
//											"faceTagName": "playground"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1G9EIOM5G7",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1GI4V78G84",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1G9EIQC960",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G9EIUQF60",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxEditFrame",
//										"position": "Absolute",
//										"x": "0",
//										"y": "#cfgSize.headerH",
//										"w": "\"FW\"",
//										"h": "#`FH-${cfgSize.headerH+cfgSize.footerH}`",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "true",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "\"\"",
//										"styleClass": ""
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1G9EJ10IP0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9EJ10IP1",
//													"attrs": {
//														"type": "box",
//														"id": "BoxTabs",
//														"position": "Absolute",
//														"x": "0",
//														"y": "0",
//														"w": "\"FW\"",
//														"h": "25",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "true",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[0,0,0,0]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "\"\"",
//														"styleClass": "",
//														"background": "#cfgColor.tabTrack",
//														"border": "0",
//														"borderStyle": "Solid",
//														"borderColor": "#cfgColor.lineBodySub",
//														"corner": "0",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]",
//														"contentLayout": "Flex X"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "box",
//															"jaxId": "1G9GGD4750",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1G9GGESV00",
//																	"attrs": {
//																		"type": "box",
//																		"id": "",
//																		"position": "Absolute",
//																		"x": "0",
//																		"y": "\"FH-1\"",
//																		"w": "\"FW\"",
//																		"h": "1",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "true",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[0,0,0,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "\"\"",
//																		"styleClass": "",
//																		"background": "#cfgColor.lineBodySub",
//																		"border": "0",
//																		"borderStyle": "Solid",
//																		"borderColor": "[0,0,0,1.00]",
//																		"corner": "0",
//																		"shadow": "false",
//																		"shadowX": "2",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowSpread": "0",
//																		"shadowColor": "[0,0,0,0.50]"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1G9GGESV01",
//																	"attrs": {
//																		"1G9FUG1N20": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I9VC8J8U22",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I9VC8J8U23",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1G9FUG1N20",
//																			"faceTagName": "nodoc"
//																		},
//																		"1G9FUG7200": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I9VC8J8U24",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I9VC8J8U25",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1G9FUG7200",
//																			"faceTagName": "hasdoc"
//																		},
//																		"1H0VKGKI40": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I9VD1DDI8",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I9VD1DDI9",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H0VKGKI40",
//																			"faceTagName": "playground"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1G9GGESV02",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1GI4V78G85",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear1G9EHTP730",
//															"jaxId": "1G9EJ2OD30",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1G9EJ5J6Q0",
//																	"attrs": {
//																		"app": "#app",
//																		"w": "\"FW\""
//																	}
//																},
//																"properties": {
//																	"jaxId": "1G9EJ5J6Q1",
//																	"attrs": {
//																		"type": "#null#>DocTabTrk(app,\"FW\")",
//																		"id": "BoxTabTrk",
//																		"position": "Absolute",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1G9EJ5J6Q2",
//																	"attrs": {
//																		"1G9FUG1N20": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I9VC8J8U26",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I9VC8J8U27",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1G9FUG1N20",
//																			"faceTagName": "nodoc"
//																		},
//																		"1G9FUG7200": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I9VC8J8U28",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I9VC8J8U29",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1G9FUG7200",
//																			"faceTagName": "hasdoc"
//																		},
//																		"1H0VKGKI40": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I9VD1DDI10",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I9VD1DDI11",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H0VKGKI40",
//																			"faceTagName": "playground"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1G9EJ5J6Q3",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1GI4V78G86",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1H7HLOGQ66",
//																	"attrs": {}
//																}
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1G9EJ10IQ0",
//													"attrs": {
//														"1G9FUG1N20": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1G9G7KF9V24",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1G9G7KF9V25",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1G9FUG1N20",
//															"faceTagName": "nodoc"
//														},
//														"1G9FUG7200": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1G9G7KF9V26",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1G9G7KF9V27",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1G9FUG7200",
//															"faceTagName": "hasdoc"
//														},
//														"1H0VKGKI40": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I9VD1DDI12",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I9VD1DDI13",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H0VKGKI40",
//															"faceTagName": "playground"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1G9EJ10IQ1",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1GI4V78G87",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1G9EJ4KRJ0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9EJ5J6Q4",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxEdit",
//														"position": "Absolute",
//														"x": "0",
//														"y": "25",
//														"w": "\"FW\"",
//														"h": "\"FH-25\"",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "true",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[0,0,0,0]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "\"\"",
//														"styleClass": ""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1G9EJ5J6Q5",
//													"attrs": {
//														"1G9FUG1N20": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I9VC8J8U30",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I9VC8J8U31",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1G9FUG1N20",
//															"faceTagName": "nodoc"
//														},
//														"1G9FUG7200": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I9VC8J8U32",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I9VC8J8U33",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1G9FUG7200",
//															"faceTagName": "hasdoc"
//														},
//														"1H0VKGKI40": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I9VD1DDI14",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I9VD1DDI15",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H0VKGKI40",
//															"faceTagName": "playground"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1G9EJ5J6Q6",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1GI4V78G88",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1G9EIUQF61",
//									"attrs": {
//										"1G9FUG1N20": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I9VC8J8U34",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I9VC8J8U35",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9FUG1N20",
//											"faceTagName": "nodoc"
//										},
//										"1G9FUG7200": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I9VC8J8U36",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I9VC8J8U37",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9FUG7200",
//											"faceTagName": "hasdoc"
//										},
//										"1H0VKGKI40": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I9VD1DDI16",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I9VD1DDI17",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H0VKGKI40",
//											"faceTagName": "playground"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1G9EIUQF62",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1GI4V78G89",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1G9EIPNHM0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G9EIPNHM1",
//									"attrs": {
//										"type": "box",
//										"id": "BoxFooter",
//										"position": "Absolute",
//										"x": "0",
//										"y": "100%",
//										"w": "100%",
//										"h": "#cfgSize.footerH",
//										"anchorH": "Left",
//										"anchorV": "Bottom",
//										"autoLayout": "true",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "\"\"",
//										"styleClass": "",
//										"background": "#cfgColor.footer",
//										"border": "[1,0,0,0]",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor.lineBodySub",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1G9FS2U6I0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9FS3MTB0",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxState",
//														"position": "Absolute",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "true",
//														"display": "On",
//														"clip": "On",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[0,0,0,0]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "\"\"",
//														"styleClass": "",
//														"contentLayout": "Flex XR",
//														"itemsAlign": "Center"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1G9FS45I30",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1G9FSB24C0",
//																	"attrs": {
//																		"type": "text",
//																		"id": "",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100",
//																		"h": "\"FH\"",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "true",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[0,10,0,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "\"\"",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontBody\"]",
//																		"text": {
//																			"type": "string",
//																			"valText": "使用Tab符",
//																			"localize": {
//																				"EN": "Use Tab",
//																				"CN": "使用Tab符"
//																			},
//																			"localizable": true
//																		},
//																		"font": "",
//																		"fontSize": "#txtSize.smallMid",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Center",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"lineClamp": "0",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0",
//																		"autoSizeW": "true",
//																		"autoSizeH": "false"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1G9FSB24C1",
//																	"attrs": {
//																		"1H0VKFUDI0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H0VKMSF028",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H0VKMSF029",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H0VKFUDI0",
//																			"faceTagName": "edlit"
//																		},
//																		"1H0VKGKI40": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H0VKMSF030",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H0VKMSF031",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H0VKGKI40",
//																			"faceTagName": "playground"
//																		},
//																		"1G9FUG1N20": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I9VC8J8U38",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I9VC8J8U39",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1G9FUG1N20",
//																			"faceTagName": "nodoc"
//																		},
//																		"1G9FUG7200": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I9VC8J8U40",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I9VC8J8U41",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1G9FUG7200",
//																			"faceTagName": "hasdoc"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1G9FSB24C2",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1GI4V78G90",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnCheck.js",
//															"jaxId": "1I9VCUP0T0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1I9VD1DDI18",
//																	"attrs": {
//																		"size": "18",
//																		"text": "",
//																		"checked": "true",
//																		"radio": "false"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1I9VD1DDI19",
//																	"attrs": {
//																		"type": "#null#>BtnCheck(18,\"\",true,false)",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"margin": "[0,2,0,10]"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1I9VD1DDI20",
//																	"attrs": {
//																		"1H0VKGKI40": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I9VD1DDI21",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I9VD1DDI22",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H0VKGKI40",
//																			"faceTagName": "playground"
//																		},
//																		"1H0VKFUDI0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I9VD1DDI23",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I9VD1DDI24",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H0VKFUDI0",
//																			"faceTagName": "edlit"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1I9VD1DDI25",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1I9VD1DDI26",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "true",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1I9VD1DDI27",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BoxSteps.js",
//															"jaxId": "1I9VCI01U0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1I9VCJV000",
//																	"attrs": {
//																		"size": "18"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1I9VCJV001",
//																	"attrs": {
//																		"type": "#null#>BoxSteps(18)",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1I9VCJV010",
//																	"attrs": {
//																		"1G9FUG1N20": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I9VCSNQ536",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I9VCSNQ537",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1G9FUG1N20",
//																			"faceTagName": "nodoc"
//																		},
//																		"1G9FUG7200": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I9VCSNQ538",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I9VCSNQ539",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1G9FUG7200",
//																			"faceTagName": "hasdoc"
//																		},
//																		"1H0VKFUDI0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I9VCSNQ540",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I9VCSNQ541",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H0VKFUDI0",
//																			"faceTagName": "edlit"
//																		},
//																		"1H0VKGKI40": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I9VCSNQ542",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I9VCSNQ543",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H0VKGKI40",
//																			"faceTagName": "playground"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1I9VCJV011",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1I9VCJV012",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "true",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1I9VCJV013",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1G9FTHGH80",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1G9FTHGH81",
//																	"attrs": {
//																		"type": "text",
//																		"id": "",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100",
//																		"h": "\"FH\"",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "true",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[0,0,0,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "\"\"",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontBody\"]",
//																		"text": {
//																			"type": "string",
//																			"valText": "${`缩进：${state.indentSize}`},state",
//																			"localize": {
//																				"EN": "${`Indent Size: ${state.indentSize}`},state",
//																				"CN": "${`缩进：${state.indentSize}`},state"
//																			},
//																			"localizable": true
//																		},
//																		"font": "",
//																		"fontSize": "#txtSize.smallMid",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Center",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"lineClamp": "0",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0",
//																		"autoSizeW": "true",
//																		"autoSizeH": "false"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1G9FTHGH90",
//																	"attrs": {
//																		"1H0VKFUDI0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H0VKMSF040",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H0VKMSF041",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H0VKFUDI0",
//																			"faceTagName": "edlit"
//																		},
//																		"1H0VKGKI40": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1H0VKMSF042",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1H0VKMSF043",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H0VKGKI40",
//																			"faceTagName": "playground"
//																		},
//																		"1G9FUG1N20": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I9VC8J8U50",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I9VC8J8U51",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1G9FUG1N20",
//																			"faceTagName": "nodoc"
//																		},
//																		"1G9FUG7200": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I9VC8J8U52",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I9VC8J8U53",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1G9FUG7200",
//																			"faceTagName": "hasdoc"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1G9FTHGH91",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1GI4V78G93",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1IQ6O9K6U0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IQ6O9K6U1",
//																	"attrs": {
//																		"type": "text",
//																		"id": "TxtCursor",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100",
//																		"h": "\"FH\"",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "true",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "12",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "\"\"",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontBody\"]",
//																		"text": "-:-",
//																		"font": "",
//																		"fontSize": "#txtSize.smallMid",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Center",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"lineClamp": "0",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0",
//																		"autoSizeW": "true",
//																		"autoSizeH": "false"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IQ6O9K6V0",
//																	"attrs": {
//																		"1H0VKFUDI0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IQ6O9K6V1",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IQ6O9K6V2",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H0VKFUDI0",
//																			"faceTagName": "edlit"
//																		},
//																		"1H0VKGKI40": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IQ6O9K6V3",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IQ6O9K6V4",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1H0VKGKI40",
//																			"faceTagName": "playground"
//																		},
//																		"1G9FUG1N20": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IQ6O9K6V5",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IQ6O9K6V6",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1G9FUG1N20",
//																			"faceTagName": "nodoc"
//																		},
//																		"1G9FUG7200": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IQ6O9K6V7",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IQ6O9K6V8",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1G9FUG7200",
//																			"faceTagName": "hasdoc"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1IQ6O9K6V9",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1IQ6O9K6V10",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true"
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1G9FS3MTB1",
//													"attrs": {
//														"1G9FUG1N20": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I9VC8J8U54",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I9VC8J8U55",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1G9FUG1N20",
//															"faceTagName": "nodoc"
//														},
//														"1G9FUG7200": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I9VC8J8U56",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I9VC8J8U57",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1G9FUG7200",
//															"faceTagName": "hasdoc"
//														},
//														"1H0VKGKI40": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I9VD1DDI28",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I9VD1DDI29",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1H0VKGKI40",
//															"faceTagName": "playground"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1G9FS3MTB2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1GI4V78G94",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1G9EIPNHN0",
//									"attrs": {
//										"1G9FUG1N20": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I9VC8J8U58",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I9VC8J8U59",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9FUG1N20",
//											"faceTagName": "nodoc"
//										},
//										"1G9FUG7200": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I9VC8J8U60",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I9VC8J8U61",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9FUG7200",
//											"faceTagName": "hasdoc"
//										},
//										"1H0VKGKI40": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I9VD1DDI30",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I9VD1DDI31",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H0VKGKI40",
//											"faceTagName": "playground"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1G9EIPNHN1",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1GI4V78G95",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "true",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1G9G7EJ6A0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G9G7FRJ30",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxTips",
//										"position": "Absolute",
//										"x": "\"FW/8\"",
//										"y": "100",
//										"w": "\"FW*3/4\"",
//										"h": "\"FH-200\"",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "true",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "0.60",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "\"\"",
//										"styleClass": ""
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1G9G7FRJ31",
//									"attrs": {
//										"1G9FUG1N20": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9G7KF9V60",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9G7KF9V61",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9FUG1N20",
//											"faceTagName": "nodoc"
//										},
//										"1G9FUG7200": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9G7KF9V62",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9G7KF9V63",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9FUG7200",
//											"faceTagName": "hasdoc"
//										},
//										"1H0VKGKI40": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1I9VD1DDI32",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I9VD1DDI33",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H0VKGKI40",
//											"faceTagName": "playground"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1G9G7FRJ32",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1GI4V78G96",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1G9EINO559",
//					"attrs": {
//						"1G9FUG1N20": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1I9VC8J8U62",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I9VC8J8U63",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1G9FUG1N20",
//							"faceTagName": "nodoc"
//						},
//						"1G9FUG7200": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1I9VC8J8U64",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I9VC8J8U65",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1G9FUG7200",
//							"faceTagName": "hasdoc"
//						},
//						"1H0VKGKI40": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1I9VD1DDI34",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I9VD1DDI35",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H0VKGKI40",
//							"faceTagName": "playground"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1G9EINO5510",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1GI4V78G97",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1G9EINO5511",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false",
//				"innerLayout": {
//					"valText": "false"
//				},
//				"marginL": {
//					"valText": "false"
//				},
//				"marginR": {
//					"valText": "false"
//				},
//				"marginT": {
//					"valText": "false"
//				},
//				"marginB": {
//					"valText": "false"
//				},
//				"paddingL": {
//					"valText": "false"
//				},
//				"paddingR": {
//					"valText": "false"
//				},
//				"paddingT": {
//					"valText": "false"
//				},
//				"paddingB": {
//					"valText": "false"
//				},
//				"attach": {
//					"valText": "false"
//				},
//				"face": {
//					"type": "bool",
//					"valText": "false"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}