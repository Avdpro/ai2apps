//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
/*#{1GBSD19800StartDoc*/
import pathLib from "/@path";
import {BtnObject} from "/@StdUI/ui/BtnObject.js";
/*}#1GBSD19800StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let DlgDocs=function(app){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let boxHeader;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1GBSD19807LocalVals*/
	let dlgVO=null;
	let byKey=false;
	let appPrj,dataDocs;
	let listBox,txtPath;
	let docIdx;
	let curLine=null;
	appPrj=app.prj;
	dataDocs=appPrj.docs;
	/*}#1GBSD19807LocalVals*/
	
	/*#{1GBSD19807PreState*/
	/*}#1GBSD19807PreState*/
	/*#{1GBSD19807PostState*/
	/*}#1GBSD19807PostState*/
	cssVO={
		"hash":"1GBSD19807",nameHost:true,
		"type":"box","id":"DlgDocs","x":0,"y":0,"w":380,"h":500,"overflow":1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.body,
		"border":2,"borderColor":cfgColor.lineBodySub,"corner":6,"shadow":true,"shadowX":6,"shadowY":12,"shadowBlur":8,"shadowColor":[0,0,0,0.15],
		children:[
			{
				"hash":"1IA0JCE2C0",
				"type":"box","id":"BoxHeader","x":0,"y":0,"w":"100%","h":24,"cursor":"move","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":[255,255,255,1],
				"border":[0,0,1,0],"borderColor":cfgColor["fontBodyLit"],
				children:[
					{
						"hash":"1IA0JGB380",
						"type":"text","x":5,"y":0,"w":100,"h":"100%","uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],"text":"切换文档",
						"fontSize":txtSize.smallMid,"fontWeight":"bold","fontStyle":"normal","textDecoration":"","alignV":1,
					},
					{
						"hash":"1IA0JIE9E0",
						"type":BtnIcon("front",20,0,appCfg.sharedAssets+"/close.svg",null),"x":">calc(100% - 24px)","y":2,"padding":3,
						"OnClick":function(event){
							/*#{1IA0JLLI80FunctionBody*/
							app.closeDlg(self);
							/*}#1IA0JLLI80FunctionBody*/
						},
					}
				],
			},
			{
				"hash":"1GBSDF1810",
				"type":"box","id":"ListBox","x":10,"y":52,"w":"FW-20","h":"FH-60","overflow":"auto-y","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":[255,255,255,1],
				"border":1,"contentLayout":"flex-y",
			},
			{
				"hash":"1GBSDIBM80",
				"type":"text","id":"TxtPath","x":10,"y":28,"w":"FW-20","h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor.fontBodySub,
				"text":"text","fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,
			}
		],
		/*#{1GBSD19807ExtraCSS*/
		/*}#1GBSD19807ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			self=this;
			boxHeader=self.BoxHeader;
			/*#{1GBSD19807Create*/
			VFACT.applyMoveDrag(boxHeader,self);
			listBox=self.ListBox;
			txtPath=self.TxtPath;
			txtPath.text="Choose document to switch:"
			/*}#1GBSD19807Create*/
		},
		/*#{1GBSD19807EndCSS*/
		/*}#1GBSD19807EndCSS*/
	};
	/*#{1GBSD19807PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.showDlg=function(vo){
		let docList,doc,css,children,line,hud,i,n;
		dlgVO=vo;
		byKey=vo.byKey;
		hud=vo.hud;
		docList=dataDocs.docList;
		listBox.clearChildren();
		curLine=null;
		docIdx=0;
		listBox.display=0;
		n=docList.length;
		for(i=n-1;i>=0;i--){
			doc=docList[i];
			css={
				type:BtnObject({text:pathLib.basename(doc.path),icon:appCfg.sharedAssets+"/file.svg"}),doc:doc,position:"relative",path:doc.path,
				OnClick(evt){
					app.closeDlg(self);
					if(dlgVO.callback){
						dlgVO.callback(this.doc);
					}else{
						dataDocs.focusDoc(this.doc);
					}
				},
				OnMouseInOut(isIn){
					if(isIn){
						txtPath.text=this.path;
					}
				}
			};
			listBox.appendNewChild(css);
		}
		children=listBox.children;
		listBox.display=1;
		docIdx=0;
		self.setCurLine(0);
		if(hud){
			let rect;
			rect=hud.getBoundingClientRect();
			self.x=rect.x;
			self.y=rect.y+rect.height+5;
		}else{
			self.x="(FW-380)/2";
			self.y=50;
		}
		self.h=450;
		self.animate({type:"pose",h:500,time:80});
	};
	
	//------------------------------------------------------------------------
	cssVO.setCurLine=function(idx){
		let children=listBox.children;
		let line,i,n;
		if(idx>=0){
			line=children[idx];
			if(!line){
				line=null;
				idx=-1;
			}
		}else{
			line=idx;
			FindIdx:{
				n=children.length;
				for(i=0;i<n;i++){
					if(line===children[i]){
						idx=i;
						break FindIdx;
					}
				}
				line=null;idx=-1;
			}
		}
		if(curLine){
			curLine.showFace("blur");
		}
		curLine=line;
		if(line){
			line.showFace("focus");
			docIdx=idx;
		}else{
			docIdx=-1;
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.nextDoc=function(){
		let maxIdx,idx;
		maxIdx=listBox.children.length-1;
		idx=docIdx+1;
		if(idx>maxIdx){
			idx=0;
		}
		cssVO.setCurLine(idx);
	};
	
	//------------------------------------------------------------------------
	cssVO.preDoc=function(){
		let maxIdx,idx;
		maxIdx=listBox.children.length-1;
		idx=docIdx-1;
		if(idx<0){
			idx=maxIdx;
		}
		cssVO.setCurLine(idx);
	};
	
	//------------------------------------------------------------------------
	cssVO.OnKeyDown=function(code,e){
		if(!byKey)
			return;
		if(e.key==="Escape" && e.ctrlKey){
			if(e.shiftKey){
				self.preDoc();
			}else{
				self.nextDoc();
			}
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.OnKeyUp=function(code,e){
		if(!byKey){
			return;
		}
		if(e.key==="Control"){
			if(curLine){
				dataDocs.focusDoc(curLine.doc);
			}
			app.closeDlg(self);
		}
	};
	/*}#1GBSD19807PostCSSVO*/
	return cssVO;
};
/*#{1GBSD19807ExCodes*/
/*}#1GBSD19807ExCodes*/


/*#{1GBSD19800EndDoc*/
/*}#1GBSD19800EndDoc*/

export default DlgDocs;
export{DlgDocs};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearBox",
//	"jaxId": "1GBSD19800",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1GBSD19801",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1GBSD19802",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1H7J2HQB30",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1GBSD19803",
//			"attrs": {
//				"app": {
//					"type": "auto",
//					"valText": "null"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1GBSD19804",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1GBSD19805",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "VFACT document",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1GBSD19806",
//			"attrs": {}
//		},
//		"mockupStates": {
//			"jaxId": "1IA0IPL5L0",
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "box",
//			"jaxId": "1GBSD19807",
//			"attrs": {
//				"properties": {
//					"jaxId": "1GBSD19808",
//					"attrs": {
//						"type": "box",
//						"id": "DlgDocs",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "380",
//						"h": "500",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "On",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "[0,0,0,0]",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "\"\"",
//						"styleClass": "",
//						"background": "#cfgColor.body",
//						"border": "2",
//						"borderStyle": "Solid",
//						"borderColor": "#cfgColor.lineBodySub",
//						"corner": "6",
//						"shadow": "true",
//						"shadowX": "6",
//						"shadowY": "12",
//						"shadowBlur": "8",
//						"shadowSpread": "0",
//						"shadowColor": "[0,0,0,0.15]"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1IA0JCE2C0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IA0JFI2N0",
//									"attrs": {
//										"type": "box",
//										"id": "BoxHeader",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "24",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "move",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "[255,255,255,1.00]",
//										"border": "[0,0,1,0]",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor[\"fontBodyLit\"]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1IA0JGB380",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IA0JL8BO0",
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "Absolute",
//														"x": "5",
//														"y": "0",
//														"w": "100",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "Tree Off",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBody\"]",
//														"text": "切换文档",
//														"font": "",
//														"fontSize": "#txtSize.smallMid",
//														"bold": "true",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Center",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IA0JL8BO1",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1IA0JL8BO2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IA0JL8BO3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1IA0JIE9E0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1IA0JL8BO4",
//													"attrs": {
//														"style": "\"front\"",
//														"w": "20",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/close.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1IA0JL8BO5",
//													"attrs": {
//														"type": "#null#>BtnIcon(\"front\",20,0,appCfg.sharedAssets+\"/close.svg\",null)",
//														"id": "",
//														"position": "Absolute",
//														"x": "100%-24",
//														"y": "2",
//														"display": "On",
//														"face": "",
//														"padding": "3"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IA0JL8BO6",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1IA0JL8BO7",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1IA0JLLI80",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1IA0JLRNI0",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1IA0JL8BO8",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1IA0JL8BO9",
//													"attrs": {}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1IA0JFI2N1",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1IA0JFI2N2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IA0JFI2N3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1GBSDF1810",
//							"attrs": {
//								"properties": {
//									"jaxId": "1GBSDPQK24",
//									"attrs": {
//										"type": "box",
//										"id": "ListBox",
//										"position": "Absolute",
//										"x": "10",
//										"y": "52",
//										"w": "\"FW-20\"",
//										"h": "\"FH-60\"",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Auto Scroll Y",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "\"\"",
//										"styleClass": "",
//										"background": "[255,255,255,1.00]",
//										"border": "1",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"contentLayout": "Flex Y"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1GBSDPQK25",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1GBSDPQK26",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H7J2HQB33",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1GBSDIBM80",
//							"attrs": {
//								"properties": {
//									"jaxId": "1GBSDPQK27",
//									"attrs": {
//										"type": "text",
//										"id": "TxtPath",
//										"position": "Absolute",
//										"x": "10",
//										"y": "28",
//										"w": "\"FW-20\"",
//										"h": "20",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "\"\"",
//										"styleClass": "",
//										"color": "#cfgColor.fontBodySub",
//										"text": "text",
//										"font": "",
//										"fontSize": "#txtSize.smallMid",
//										"bold": "false",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Center",
//										"wrap": "false",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0",
//										"autoSizeW": "false",
//										"autoSizeH": "false"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1GBSDPQK28",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1GBSDPQK29",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H7J2HQB34",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1GBSD19809",
//					"attrs": {}
//				},
//				"functions": {
//					"jaxId": "1GBSD198010",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1H7J2HQB35",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1GBSD198011",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"background": "false",
//				"color": "false",
//				"gradient": "false",
//				"border": "false",
//				"borders": "false",
//				"borderStyle": "false",
//				"borderColor": "false",
//				"borderColors": "false",
//				"corner": "false",
//				"coner": "false",
//				"coners": "false",
//				"shadow": "false",
//				"shadowX": "false",
//				"shadowY": "false",
//				"shadowBlur": "false",
//				"shadowSpread": "false",
//				"shadowColor": "false",
//				"maskImage": "false",
//				"innerLayout": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"face": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"marginL": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"marginR": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"marginT": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"marginB": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"paddingL": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"paddingT": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"paddingR": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"paddingB": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"attach": {
//					"type": "bool",
//					"valText": "false"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}