//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
import {BtnText} from "/@StdUI/ui/BtnText.js";
/*#{1HH1HHL570StartDoc*/
import pathLib from "/@path";
import Base64 from "/@tabos/utils/base64.js";
import {tabFS,tabNT} from "/@tabos";
import {path2Zip} from "/@zippath";
import QRCode from "/@qrcode";
/*}#1HH1HHL570StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let DlgShare=function(){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let edName,edEntry,txtSlot,txtLink,boxQRCode,btnShare;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1HH1HHL571LocalVals*/
	let editPrj;
	let app=VFACT.app;
	let slots=null;
	let pvSlot=-1;
	/*}#1HH1HHL571LocalVals*/
	
	/*#{1HH1HHL571PreState*/
	/*}#1HH1HHL571PreState*/
	/*#{1HH1HHL571PostState*/
	/*}#1HH1HHL571PostState*/
	cssVO={
		"hash":"1HH1HHL571",nameHost:true,
		"type":"view","x":"50%","y":20,"w":360,"h":"","anchorX":1,"padding":[10,20,20,20],"minW":"","minH":200,"maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
		children:[
			{
				"hash":"1HH1HIVN20",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":[255,255,255,1],"border":1,
				"corner":8,"shadow":true,"shadowX":6,"shadowY":12,"shadowBlur":8,"shadowColor":[0,0,0,0.15],
			},
			{
				"hash":"1HH1HLF2D0",
				"type":"text","position":"relative","x":0,"y":0,"w":"100%","h":"","margin":[0,0,10,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodySub"],
				"text":(($ln==="CN")?("分享预览"):("Share Preview")),"fontSize":txtSize.big,"fontWeight":"bold","fontStyle":"normal","textDecoration":"","alignH":1,
			},
			{
				"hash":"1HH1HO7GC0",
				"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":20,"margin":[0,0,10,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
				children:[
					{
						"hash":"1HH1HOJNL0",
						"type":"text","position":"relative","x":0,"y":0,"w":"","h":"100%","margin":[0,5,0,0],"minW":50,"minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
						"text":(($ln==="CN")?("名称:"):("Name:")),"fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignH":2,"alignV":1,
					},
					{
						"hash":"1HH1HPSI30",
						"type":"edit","id":"EdName","position":"relative","x":0,"y":0,"w":100,"h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","placeHolder":(($ln==="CN")?("项目名称"):("Project Name")),
						"color":[0,0,0],"fontSize":txtSize.smallMid,"outline":0,"border":[0,0,1,0],"flex":true,
					}
				],
			},
			{
				"hash":"1HH1HSA500",
				"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":20,"margin":[0,0,10,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
				children:[
					{
						"hash":"1HH1HSA510",
						"type":"text","position":"relative","x":0,"y":0,"w":"","h":"100%","margin":[0,5,0,0],"minW":50,"minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
						"text":(($ln==="CN")?("入口:"):("Entry:")),"fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignH":2,"alignV":1,
					},
					{
						"hash":"1HH1HSA515",
						"type":"edit","id":"EdEntry","position":"relative","x":0,"y":0,"w":100,"h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","placeHolder":(($ln==="CN")?("入口HTML文件"):("Entry HTML file")),
						"color":[0,0,0],"fontSize":txtSize.smallMid,"outline":0,"border":[0,0,1,0],"flex":true,
					}
				],
			},
			{
				"hash":"1HH1IFN5C0",
				"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
				"itemsAlign":1,
				children:[
					{
						"hash":"1HH1IGAN40",
						"type":"text","position":"relative","x":0,"y":0,"w":"","h":"100%","margin":[0,5,0,0],"minW":50,"minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
						"text":(($ln==="CN")?("分享槽:"):("Slot:")),"fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignH":2,"alignV":1,
					},
					{
						"hash":"1IA1PHVKR0",
						"type":BtnIcon("front",20,0,appCfg.sharedAssets+"/btncombo.svg",null),"position":"relative","x":0,"y":0,"padding":1,
						"OnClick":function(event){
							/*#{1IA1PLAL30FunctionBody*/
							self.chooseSlot(this);
							/*}#1IA1PLAL30FunctionBody*/
						},
					},
					{
						"hash":"1HH1IK0SE0",
						"type":"text","id":"TxtSlot","position":"relative","x":0,"y":0,"w":100,"h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
						"text":"Loading...","fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,
					}
				],
			},
			{
				"hash":"1HH1ILC8V0",
				"type":"text","id":"TxtRank","position":"relative","x":30,"y":0,"w":">calc(100% - 60px)","h":"","margin":[0,0,10,0],"minW":"","minH":"","maxW":"",
				"maxH":"","styleClass":"","color":cfgColor["fontBodySub"],"text":(($ln==="CN")?("可用的预览槽数量是根据用户等级决定的，用户等级高的用户可以同时拥有5个预览分享。"):("The number of available preview slots is determined by the user's rank. Users with a higher rank can have up to 5 previews at the same time.")),
				"fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,"wrap":true,
			},
			{
				"hash":"1HH24NSOM0",
				"type":"text","position":"relative","x":0,"y":0,"w":"100%","h":"","display":0,"margin":[0,0,5,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"color":cfgColor["fontBody"],"text":(($ln==="CN")?("预览分享链接"):("Preview link:")),"fontSize":txtSize.mid,"fontWeight":"normal","fontStyle":"normal",
				"textDecoration":"",
			},
			{
				"hash":"1HH24FRBF0",
				"type":"text","id":"TxtLink","position":"relative","x":0,"y":0,"w":"100%","h":"","display":0,"padding":[0,0,10,0],"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","color":cfgColor["fontBody"],"text":"https://pv.ai2apps.com/pv?userId=10001&slot=1&key=1028374817","fontSize":txtSize.smallMid,"fontWeight":"normal",
				"fontStyle":"normal","textDecoration":"","wrap":true,"selectable":true,
			},
			{
				"hash":"1HH2NCMPH0",
				"type":"hud","id":"BoxQRCode","position":"relative","x":"50%","y":0,"w":256,"h":256,"anchorX":1,"display":0,"margin":[0,0,15,0],"minW":"","minH":"",
				"maxW":"","maxH":"","styleClass":"",
			},
			{
				"hash":"1HH1IQMCD0",
				"type":"hud","id":"BoxButtons","position":"relative","x":0,"y":0,"w":"100%","h":30,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
				"subAlign":1,"itemsAlign":1,
				children:[
					{
						"hash":"1IA1P6KM60",
						"type":BtnText("primary",100,24,(($ln==="CN")?("分享"):("Share")),false,""),"id":"BtnShare","position":"relative","x":0,"y":0,"margin":[0,20,0,0],
						"enable":false,
						"OnClick":function(event){
							/*#{1IA1P6KM77FunctionBody*/
							self.makePreview();
							/*}#1IA1P6KM77FunctionBody*/
						},
					},
					{
						"hash":"1IA1OVGAQ0",
						"type":BtnText("warning",100,24,(($ln==="CN")?("取消"):("Cancel")),false,""),"id":"BtnCancel","position":"relative","x":0,"y":0,
						"OnClick":function(event){
							/*#{1IA1P1NTG0FunctionBody*/
							app.closeDlg(self);
							/*}#1IA1P1NTG0FunctionBody*/
						},
					},
					{
						"hash":"1IA1PED8M0",
						"type":BtnText("primary",100,24,(($ln==="CN")?("完成"):("Close")),false,""),"id":"BtnClose","position":"relative","x":0,"y":0,"display":0,
						"OnClick":function(event){
							/*#{1IA1PED8M11FunctionBody*/
							app.closeDlg(self);
							/*}#1IA1PED8M11FunctionBody*/
						},
					}
				],
			}
		],
		/*#{1HH1HHL571ExtraCSS*/
		/*}#1HH1HHL571ExtraCSS*/
		faces:{
			"loadSlots":{
				"#1HH1HO7GC0":{
					"display":1
				},
				"#1HH1HSA500":{
					"display":1
				},
				"#1HH1IFN5C0":{
					"display":1
				},
				"#1IA1PHVKR0":{
					"enable":false
				},
				/*TxtSlot*/"#1HH1IK0SE0":{
					"text":"Loading..."
				},
				/*TxtRank*/"#1HH1ILC8V0":{
					"display":1
				},
				"#1HH24NSOM0":{
					"display":0
				},
				/*TxtLink*/"#1HH24FRBF0":{
					"display":0
				},
				/*BoxQRCode*/"#1HH2NCMPH0":{
					"display":0
				},
				/*BtnShare*/"#1IA1P6KM60":{
					"display":1
				},
				/*BtnCancel*/"#1IA1OVGAQ0":{
					"display":1
				},
				/*BtnClose*/"#1IA1PED8M0":{
					"display":0
				}
			},"slotsLoaded":{
				"#1IA1PHVKR0":{
					"enable":true
				}
			},"shared":{
				"#1HH1HO7GC0":{
					"display":0
				},
				"#1HH1HSA500":{
					"display":0
				},
				"#1HH1IFN5C0":{
					"display":0
				},
				/*TxtRank*/"#1HH1ILC8V0":{
					"display":0
				},
				"#1HH24NSOM0":{
					"display":1
				},
				/*TxtLink*/"#1HH24FRBF0":{
					"display":1
				},
				/*BoxQRCode*/"#1HH2NCMPH0":{
					"display":1
				},
				/*BtnShare*/"#1IA1P6KM60":{
					"display":0
				},
				/*BtnCancel*/"#1IA1OVGAQ0":{
					"display":0
				},
				/*BtnClose*/"#1IA1PED8M0":{
					"display":1
				}
			}
		},
		OnCreate:function(){
			self=this;
			edName=self.EdName;edEntry=self.EdEntry;txtSlot=self.TxtSlot;txtLink=self.TxtLink;boxQRCode=self.BoxQRCode;btnShare=self.BtnShare;
			/*#{1HH1HHL571Create*/
			/*}#1HH1HHL571Create*/
		},
		/*#{1HH1HHL571EndCSS*/
		/*}#1HH1HHL571EndCSS*/
	};
	/*#{1HH1HHL571PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.showDlg=function(vo){
		let path;
		editPrj=vo.prj;
		path=editPrj.path;
		edName.text=path.substring(1);
		edEntry.text="app.html";
		self.showFace("loadSlots");
		pvSlot=-1;
		self.loadSlots();
	};
	//------------------------------------------------------------------------
	cssVO.updateButton=function(){
		if(pvSlot>=0 && edName.text && edEntry.text){
			btnShare.enable=true;
		}else{
			btnShare.enable=false;
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.loadSlots=async function(){
		let resVO;
		resVO=await tabNT.makeCall("getPreviewSlots",{});
		if(resVO.code!==200){
			txtSlot.text="Error: "+resVO.info;
			return;
		}
		slots=resVO.slots;
		if(slots[0].useable){
			txtSlot.text=`Slot1`;
			pvSlot=0;
		}
		self.showFace("slotsLoaded");
		self.updateButton();
	};
	
	//------------------------------------------------------------------------
	cssVO.chooseSlot=async function(btn){
		let items,item,time;
		items=slots.map((item,index)=>{
			time=item.time;
			if(time>0){
				time=new Date(time);
				time=time.toLocaleDateString();
			}else{
				time=""
			}
			return {text:`Slot${index+1}: ${item.name} ${time}`,slot:index,enable:item.useable||false}
		});
		item=await app.modalDlg("/@StdUI/ui/DlgMenu.js",{items:items,hud:btn});
		if(item){
			txtSlot.text=`Slot${item.slot+1}`;
			pvSlot=item.slot;
			self.updateButton();
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.makePreview=async function(){
		let path,zipData,url,slot;
		if(!(await tabNT.checkLogin(false))){
			let logined=await app.modalDlg("/@homekit/ui/DlgLogin.js",{x:app.width/2,y:100,alignH:1});
			if(!logined){
				return;
			}
			await tabNT.checkLogin(false);
		}
		//Check slot:
		slot=slots[pvSlot];
		if(slot.name){
			if(!window.confirm((($ln==="CN")?("预览分享槽位已有内容，是否确认替换原有内容"):/*EN*/("Preview slot is not empty, are you sure to overwrite it?")))){
				return;
			}
		}
		path=editPrj.path;
		url=await app.modalDlg("/@homekit/ui/DlgCloud.js",{
			mode:"Work",
			title:"Preview",
			workingText:"Sharing preview...",
			work:async function(tty){
				let json,resVO;
				tty.textOut("Make preview.json...");
				json={
					name:edName.text,
					entry:edEntry.text,
					user:tabNT.loginVO.email,
					time:(new Date()).getTime()
				};
				await tabFS.writeFile(pathLib.join(path,"preview.json"),JSON.stringify(json,null,"\t"),"utf8");
				tty.textOut("Packing zip...");
				zipData=await path2Zip(path,null,tty);
				tty.textOut("Packing zip done.");
				zipData=Base64.encode(zipData);
				resVO=await tabNT.makeCall("sharePreview",{name:edName.text,slot:pvSlot,data:zipData});
				if(resVO.code!==200){
					throw Error(`Share preview error ${resVO.code}: ${resVO.info}`);
				}
				return resVO.url;
			}
		});
		if(url){
			let qrCode,location,host,protocal,pos;
			location=document.location;
			host=location.host;
			pos=host.indexOf(".");
			if(pos>0){
				host="pv"+host.substring(pos);
			}
			url=location.protocol+"//"+host+url;
			self.showFace("shared");
			txtLink.text=url;
			boxQRCode.webObj.innerHTML="";
			qrCode=new QRCode(boxQRCode.webObj,{text:url,width:256,height:256});
		}
	};
	/*}#1HH1HHL571PostCSSVO*/
	return cssVO;
};
/*#{1HH1HHL571ExCodes*/
/*}#1HH1HHL571ExCodes*/


/*#{1HH1HHL570EndDoc*/
/*}#1HH1HHL570EndDoc*/

export default DlgShare;
export{DlgShare};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "UIView",
//	"jaxId": "1HH1HHL570",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1HH1HHL572",
//			"attrs": {
//				"device": "Desktop 800x600",
//				"screenW": "800",
//				"screenH": "600",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1HH1HHL573",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1HH1HHL574",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1HH1HHL575",
//			"attrs": {}
//		},
//		"localVars": {
//			"jaxId": "1HH1HHL576",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1HH1HHL577",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1HH1HHL578",
//			"attrs": {
//				"loadSlots": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HH1O2L9I0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HH1O8PBU0",
//							"attrs": {}
//						}
//					}
//				},
//				"slotsLoaded": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HH1O3FCH0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HH1O8PBU1",
//							"attrs": {}
//						}
//					}
//				},
//				"shared": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HH24DTEL0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HH24DTEL1",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1HH1HHL579",
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "view",
//			"jaxId": "1HH1HHL571",
//			"attrs": {
//				"properties": {
//					"jaxId": "1HH1HHL5710",
//					"attrs": {
//						"type": "view",
//						"id": "",
//						"position": "Absolute",
//						"x": "50%",
//						"y": "20",
//						"w": "360",
//						"h": "",
//						"anchorH": "Center",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "[10,20,20,20]",
//						"minW": "",
//						"minH": "200",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Flex Y"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1HH1HIVN20",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HH1IUIQ30",
//									"attrs": {
//										"type": "box",
//										"id": "BoxBG",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "[255,255,255,1.00]",
//										"border": "1",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "8",
//										"shadow": "true",
//										"shadowX": "6",
//										"shadowY": "12",
//										"shadowBlur": "8",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.15]"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HH1IUIQ31",
//									"attrs": {
//										"1HH1O3FCH0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HH250PRV4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HH250PRV5",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HH1O3FCH0",
//											"faceTagName": "slotsLoaded"
//										},
//										"1HH1O2L9I0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IA1PGT7C0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IA1PGT7C1",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HH1O2L9I0",
//											"faceTagName": "loadSlots"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HH1IUIQ32",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HH1IUIQ33",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "true",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1HH1HLF2D0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HH1IUIQ34",
//									"attrs": {
//										"type": "text",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,10,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#cfgColor[\"fontBodySub\"]",
//										"text": {
//											"type": "string",
//											"valText": "分享预览",
//											"localize": {
//												"EN": "Share Preview",
//												"CN": "分享预览"
//											},
//											"localizable": true
//										},
//										"font": "",
//										"fontSize": "#txtSize.big",
//										"bold": "true",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Center",
//										"alignV": "Top",
//										"wrap": "false",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HH1IUIQ35",
//									"attrs": {
//										"1HH1O3FCH0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HH250PRV10",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HH250PRV11",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HH1O3FCH0",
//											"faceTagName": "slotsLoaded"
//										},
//										"1HH1O2L9I0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IA1PGT7C2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IA1PGT7C3",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HH1O2L9I0",
//											"faceTagName": "loadSlots"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HH1IUIQ36",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HH1IUIQ37",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1HH1HO7GC0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HH1HS8HC0",
//									"attrs": {
//										"type": "hud",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "20",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,10,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex X"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1HH1HOJNL0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HH1HS8HC1",
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[0,5,0,0]",
//														"padding": "",
//														"minW": "50",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBody\"]",
//														"text": {
//															"type": "string",
//															"valText": "名称:",
//															"localize": {
//																"EN": "Name:",
//																"CN": "名称:"
//															},
//															"localizable": true
//														},
//														"font": "",
//														"fontSize": "#txtSize.smallMid",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Right",
//														"alignV": "Center",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HH1HS8HC2",
//													"attrs": {
//														"1HH1O3FCH0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HH250PRV16",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HH250PRV17",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HH1O3FCH0",
//															"faceTagName": "slotsLoaded"
//														},
//														"1HH1O2L9I0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IA1PGT7C4",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IA1PGT7C5",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HH1O2L9I0",
//															"faceTagName": "loadSlots"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HH1HS8HC3",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HH1HS8HC4",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "edit",
//											"jaxId": "1HH1HPSI30",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HH1HS8HC5",
//													"attrs": {
//														"type": "edit",
//														"id": "EdName",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100",
//														"h": "20",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"inputType": "Text",
//														"text": "",
//														"placeHolder": {
//															"type": "string",
//															"valText": "项目名称",
//															"localize": {
//																"EN": "Project Name",
//																"CN": "项目名称"
//															},
//															"localizable": true
//														},
//														"color": "[0,0,0]",
//														"bgColor": "[255,255,255,1.00]",
//														"font": "",
//														"fontSize": "#txtSize.smallMid",
//														"outline": "0",
//														"border": "[0,0,1,0]",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"selectOnFocus": "true",
//														"spellCheck": "true",
//														"flex": "true"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HH1HS8HC6",
//													"attrs": {
//														"1HH1O3FCH0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HH250PS04",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HH250PS05",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HH1O3FCH0",
//															"faceTagName": "slotsLoaded"
//														},
//														"1HH1O2L9I0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IA1PGT7C6",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IA1PGT7C7",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HH1O2L9I0",
//															"faceTagName": "loadSlots"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HH1HS8HC7",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HH1HS8HC8",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1HH1HS8HC9",
//									"attrs": {
//										"1HH24DTEL0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HH250PS06",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HH250PS07",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HH24DTEL0",
//											"faceTagName": "shared"
//										},
//										"1HH1O2L9I0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HH250PS08",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HH250PS09",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HH1O2L9I0",
//											"faceTagName": "loadSlots"
//										},
//										"1HH1O3FCH0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HH250PS010",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HH250PS011",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HH1O3FCH0",
//											"faceTagName": "slotsLoaded"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HH1HS8HC10",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HH1HS8HC11",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1HH1HSA500",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HH1HSA501",
//									"attrs": {
//										"type": "hud",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "20",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,10,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex X"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1HH1HSA510",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HH1HSA511",
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[0,5,0,0]",
//														"padding": "",
//														"minW": "50",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBody\"]",
//														"text": {
//															"type": "string",
//															"valText": "入口:",
//															"localize": {
//																"EN": "Entry:",
//																"CN": "入口:"
//															},
//															"localizable": true
//														},
//														"font": "",
//														"fontSize": "#txtSize.smallMid",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Right",
//														"alignV": "Center",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HH1HSA512",
//													"attrs": {
//														"1HH1O3FCH0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HH250PS016",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HH250PS017",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HH1O3FCH0",
//															"faceTagName": "slotsLoaded"
//														},
//														"1HH1O2L9I0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IA1PGT7C8",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IA1PGT7C9",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HH1O2L9I0",
//															"faceTagName": "loadSlots"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HH1HSA513",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HH1HSA514",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "edit",
//											"jaxId": "1HH1HSA515",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HH1HSA516",
//													"attrs": {
//														"type": "edit",
//														"id": "EdEntry",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100",
//														"h": "20",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"inputType": "Text",
//														"text": "",
//														"placeHolder": {
//															"type": "string",
//															"valText": "入口HTML文件",
//															"localize": {
//																"EN": "Entry HTML file",
//																"CN": "入口HTML文件"
//															},
//															"localizable": true
//														},
//														"color": "[0,0,0]",
//														"bgColor": "[255,255,255,1.00]",
//														"font": "",
//														"fontSize": "#txtSize.smallMid",
//														"outline": "0",
//														"border": "[0,0,1,0]",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"selectOnFocus": "true",
//														"spellCheck": "true",
//														"flex": "true"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HH1HSA517",
//													"attrs": {
//														"1HH1O3FCH0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HH250PS022",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HH250PS023",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HH1O3FCH0",
//															"faceTagName": "slotsLoaded"
//														},
//														"1HH1O2L9I0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IA1PGT7C10",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IA1PGT7C11",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HH1O2L9I0",
//															"faceTagName": "loadSlots"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HH1HSA518",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HH1HSA519",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1HH1HSA5110",
//									"attrs": {
//										"1HH24DTEL0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HH250PS024",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HH250PS025",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HH24DTEL0",
//											"faceTagName": "shared"
//										},
//										"1HH1O2L9I0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HH250PS026",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HH250PS027",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HH1O2L9I0",
//											"faceTagName": "loadSlots"
//										},
//										"1HH1O3FCH0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HH250PS028",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HH250PS029",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HH1O3FCH0",
//											"faceTagName": "slotsLoaded"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HH1HSA5111",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HH1HSA5112",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1HH1IFN5C0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HH1IUIQ38",
//									"attrs": {
//										"type": "hud",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "20",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex X",
//										"itemsAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1HH1IGAN40",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HH1IUIQ39",
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"w": "",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[0,5,0,0]",
//														"padding": "",
//														"minW": "50",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBody\"]",
//														"text": {
//															"type": "string",
//															"valText": "分享槽:",
//															"localize": {
//																"EN": "Slot:",
//																"CN": "分享槽:"
//															},
//															"localizable": true
//														},
//														"font": "",
//														"fontSize": "#txtSize.smallMid",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Right",
//														"alignV": "Center",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HH1IUIQ310",
//													"attrs": {
//														"1HH1O3FCH0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HH250PS034",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HH250PS035",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HH1O3FCH0",
//															"faceTagName": "slotsLoaded"
//														},
//														"1HH1O2L9I0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IA1PGT7C12",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IA1PGT7C13",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HH1O2L9I0",
//															"faceTagName": "loadSlots"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HH1IUIQ311",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HH1IUIQ312",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1IA1PHVKR0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1IA1PLGCN0",
//													"attrs": {
//														"style": "\"front\"",
//														"w": "20",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/btncombo.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1IA1PLGCN1",
//													"attrs": {
//														"type": "#null#>BtnIcon(\"front\",20,0,appCfg.sharedAssets+\"/btncombo.svg\",null)",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"padding": "1"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IA1PLGCN2",
//													"attrs": {
//														"1HH1O2L9I0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IA1PLGCN3",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IA1PLGCN4",
//																	"attrs": {
//																		"enable": {
//																			"type": "bool",
//																			"valText": "false"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HH1O2L9I0",
//															"faceTagName": "loadSlots"
//														},
//														"1HH1O3FCH0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IA1PLGCN5",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IA1PLGCN6",
//																	"attrs": {
//																		"enable": {
//																			"type": "bool",
//																			"valText": "true"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HH1O3FCH0",
//															"faceTagName": "slotsLoaded"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IA1PLGCN7",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1IA1PLAL30",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1IA1PLGCN8",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1IA1PLGCN9",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1IA1PLGCN10",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1HH1IK0SE0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HH1IUIQ319",
//													"attrs": {
//														"type": "text",
//														"id": "TxtSlot",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBody\"]",
//														"text": "Loading...",
//														"font": "",
//														"fontSize": "#txtSize.smallMid",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Center",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HH1IUIQ320",
//													"attrs": {
//														"1HH1O2L9I0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HH1O8PBV20",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HH1O8PBV21",
//																	"attrs": {
//																		"text": {
//																			"type": "string",
//																			"valText": "Loading...",
//																			"localizable": true
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HH1O2L9I0",
//															"faceTagName": "loadSlots"
//														},
//														"1HH1O3FCH0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HH250PS040",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HH250PS041",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HH1O3FCH0",
//															"faceTagName": "slotsLoaded"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HH1IUIQ321",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HH1IUIQ322",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1HH1IUIQ323",
//									"attrs": {
//										"1HH24DTEL0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HH250PS042",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HH250PS043",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HH24DTEL0",
//											"faceTagName": "shared"
//										},
//										"1HH1O2L9I0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HH250PS044",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HH250PS045",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HH1O2L9I0",
//											"faceTagName": "loadSlots"
//										},
//										"1HH1O3FCH0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HH250PS046",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HH250PS047",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HH1O3FCH0",
//											"faceTagName": "slotsLoaded"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HH1IUIQ324",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HH1IUIQ325",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1HH1ILC8V0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HH1IUIQ326",
//									"attrs": {
//										"type": "text",
//										"id": "TxtRank",
//										"position": "relative",
//										"x": "30",
//										"y": "0",
//										"w": "100%-60",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,10,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#cfgColor[\"fontBodySub\"]",
//										"text": {
//											"type": "string",
//											"valText": "可用的预览槽数量是根据用户等级决定的，用户等级高的用户可以同时拥有5个预览分享。",
//											"localize": {
//												"EN": "The number of available preview slots is determined by the user's rank. Users with a higher rank can have up to 5 previews at the same time.",
//												"CN": "可用的预览槽数量是根据用户等级决定的，用户等级高的用户可以同时拥有5个预览分享。"
//											},
//											"localizable": true
//										},
//										"font": "",
//										"fontSize": "#txtSize.small",
//										"bold": "false",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Center",
//										"wrap": "true",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HH1IUIQ327",
//									"attrs": {
//										"1HH24DTEL0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HH250PS048",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HH250PS049",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HH24DTEL0",
//											"faceTagName": "shared"
//										},
//										"1HH1O2L9I0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HH250PS050",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HH250PS051",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HH1O2L9I0",
//											"faceTagName": "loadSlots"
//										},
//										"1HH1O3FCH0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HH250PS052",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HH250PS053",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HH1O3FCH0",
//											"faceTagName": "slotsLoaded"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HH1IUIQ328",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HH1IUIQ329",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1HH24NSOM0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HH250PS054",
//									"attrs": {
//										"type": "text",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "Off",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,5,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#cfgColor[\"fontBody\"]",
//										"text": {
//											"type": "string",
//											"valText": "预览分享链接",
//											"localize": {
//												"EN": "Preview link:",
//												"CN": "预览分享链接"
//											},
//											"localizable": true
//										},
//										"font": "",
//										"fontSize": "#txtSize.mid",
//										"bold": "false",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Top",
//										"wrap": "false",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HH250PS055",
//									"attrs": {
//										"1HH24DTEL0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HH250PS056",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HH250PS057",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HH24DTEL0",
//											"faceTagName": "shared"
//										},
//										"1HH1O2L9I0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HH250PS058",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HH250PS059",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HH1O2L9I0",
//											"faceTagName": "loadSlots"
//										},
//										"1HH1O3FCH0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HH250PS060",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HH250PS061",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HH1O3FCH0",
//											"faceTagName": "slotsLoaded"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HH250PS062",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HH250PS063",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1HH24FRBF0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HH250PS064",
//									"attrs": {
//										"type": "text",
//										"id": "TxtLink",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "Off",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "[0,0,10,0]",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#cfgColor[\"fontBody\"]",
//										"text": "https://pv.ai2apps.com/pv?userId=10001&slot=1&key=1028374817",
//										"font": "",
//										"fontSize": "#txtSize.smallMid",
//										"bold": "false",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Top",
//										"wrap": "true",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "true",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HH250PS065",
//									"attrs": {
//										"1HH24DTEL0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HH250PS066",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HH250PS067",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HH24DTEL0",
//											"faceTagName": "shared"
//										},
//										"1HH1O2L9I0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HH250PS068",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HH250PS069",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HH1O2L9I0",
//											"faceTagName": "loadSlots"
//										},
//										"1HH1O3FCH0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HH250PS070",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HH250PS071",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HH1O3FCH0",
//											"faceTagName": "slotsLoaded"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HH250PS072",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HH250PS073",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1HH2NCMPH0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HH2NQQ4618",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxQRCode",
//										"position": "relative",
//										"x": "50%",
//										"y": "0",
//										"w": "256",
//										"h": "256",
//										"anchorH": "Center",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "Off",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,15,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": ""
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HH2NQQ4619",
//									"attrs": {
//										"1HH1O3FCH0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HH2NQQ4620",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HH2NQQ4621",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HH1O3FCH0",
//											"faceTagName": "slotsLoaded"
//										},
//										"1HH24DTEL0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HH2NQQ4622",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HH2NQQ4623",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HH24DTEL0",
//											"faceTagName": "shared"
//										},
//										"1HH1O2L9I0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HH2NQQ4624",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HH2NQQ4625",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HH1O2L9I0",
//											"faceTagName": "loadSlots"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HH2NQQ4626",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HH2NQQ4627",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1HH1IQMCD0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HH1IUIQ330",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxButtons",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex X",
//										"subAlign": "Center",
//										"itemsAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnText.js",
//											"jaxId": "1IA1P6KM60",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1IA1P6KM61",
//													"attrs": {
//														"style": "primary",
//														"w": "100",
//														"h": "24",
//														"text": {
//															"type": "string",
//															"valText": "分享",
//															"localize": {
//																"EN": "Share",
//																"CN": "分享"
//															},
//															"localizable": true
//														},
//														"outlined": "false",
//														"icon": ""
//													}
//												},
//												"properties": {
//													"jaxId": "1IA1P6KM62",
//													"attrs": {
//														"type": "#null#>BtnText(\"primary\",100,24,(($ln===\"CN\")?(\"分享\"):(\"Share\")),false,\"\")",
//														"id": "BtnShare",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"margin": "[0,20,0,0]",
//														"enable": "false"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IA1P6KM63",
//													"attrs": {
//														"1HH1O2L9I0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IA1P6KM70",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IA1P6KM71",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HH1O2L9I0",
//															"faceTagName": "loadSlots"
//														},
//														"1HH1O3FCH0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IA1P6KM72",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IA1P6KM73",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HH1O3FCH0",
//															"faceTagName": "slotsLoaded"
//														},
//														"1HH24DTEL0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IA1P6KM74",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IA1P6KM75",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HH24DTEL0",
//															"faceTagName": "shared"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IA1P6KM76",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1IA1P6KM77",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1IA1P6KM78",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1IA1P6KM79",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1IA1P6KM710",
//													"attrs": {
//														"Slot1H2F6U36O0": {
//															"jaxId": "1IA1P6KM711",
//															"attrs": {
//																"subHuds": {
//																	"attrs": []
//																},
//																"container": "true"
//															}
//														}
//													}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnText.js",
//											"jaxId": "1IA1OVGAQ0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1IA1P3SFH0",
//													"attrs": {
//														"style": "warning",
//														"w": "100",
//														"h": "24",
//														"text": {
//															"type": "string",
//															"valText": "取消",
//															"localize": {
//																"EN": "Cancel",
//																"CN": "取消"
//															},
//															"localizable": true
//														},
//														"outlined": "false",
//														"icon": ""
//													}
//												},
//												"properties": {
//													"jaxId": "1IA1P3SFH1",
//													"attrs": {
//														"type": "#null#>BtnText(\"warning\",100,24,(($ln===\"CN\")?(\"取消\"):(\"Cancel\")),false,\"\")",
//														"id": "BtnCancel",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": ""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IA1P3SFH2",
//													"attrs": {
//														"1HH1O2L9I0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IA1P6HA10",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IA1P6HA11",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HH1O2L9I0",
//															"faceTagName": "loadSlots"
//														},
//														"1HH1O3FCH0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IA1P6HA12",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IA1P6HA13",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HH1O3FCH0",
//															"faceTagName": "slotsLoaded"
//														},
//														"1HH24DTEL0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IA1P6HA14",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IA1P6HA15",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HH24DTEL0",
//															"faceTagName": "shared"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IA1P3SFH3",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1IA1P1NTG0",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1IA1P3SFH4",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1IA1P3SFH5",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1IA1P3SFH6",
//													"attrs": {
//														"Slot1H2F6U36O0": {
//															"jaxId": "1IA1P3SFH7",
//															"attrs": {
//																"subHuds": {
//																	"attrs": []
//																},
//																"container": "true"
//															}
//														}
//													}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnText.js",
//											"jaxId": "1IA1PED8M0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1IA1PED8M1",
//													"attrs": {
//														"style": "primary",
//														"w": "100",
//														"h": "24",
//														"text": {
//															"type": "string",
//															"valText": "完成",
//															"localize": {
//																"EN": "Close",
//																"CN": "完成"
//															},
//															"localizable": true
//														},
//														"outlined": "false",
//														"icon": ""
//													}
//												},
//												"properties": {
//													"jaxId": "1IA1PED8M2",
//													"attrs": {
//														"type": "#null#>BtnText(\"primary\",100,24,(($ln===\"CN\")?(\"完成\"):(\"Close\")),false,\"\")",
//														"id": "BtnClose",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "Off",
//														"face": ""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IA1PED8M3",
//													"attrs": {
//														"1HH1O2L9I0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IA1PED8M4",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IA1PED8M5",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HH1O2L9I0",
//															"faceTagName": "loadSlots"
//														},
//														"1HH1O3FCH0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IA1PED8M6",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IA1PED8M7",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HH1O3FCH0",
//															"faceTagName": "slotsLoaded"
//														},
//														"1HH24DTEL0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IA1PED8M8",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IA1PED8M9",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HH24DTEL0",
//															"faceTagName": "shared"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IA1PED8M10",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1IA1PED8M11",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1IA1PED8M12",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1IA1PED8M13",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1IA1PED8M14",
//													"attrs": {
//														"Slot1H2F6U36O0": {
//															"jaxId": "1IA1PED8M15",
//															"attrs": {
//																"subHuds": {
//																	"attrs": []
//																},
//																"container": "true"
//															}
//														}
//													}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1HH1IUIQ331",
//									"attrs": {
//										"1HH1O3FCH0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HH250PS11",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HH250PS12",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HH1O3FCH0",
//											"faceTagName": "slotsLoaded"
//										},
//										"1HH1O2L9I0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IA1PGT7D0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IA1PGT7D1",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HH1O2L9I0",
//											"faceTagName": "loadSlots"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HH1IUIQ332",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HH1IUIQ333",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1HH1HHL5711",
//					"attrs": {
//						"1HH1O3FCH0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HH250PS17",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HH250PS18",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HH1O3FCH0",
//							"faceTagName": "slotsLoaded"
//						},
//						"1HH1O2L9I0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1IA1PGT7D2",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IA1PGT7D3",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HH1O2L9I0",
//							"faceTagName": "loadSlots"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1HH1HHL5712",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1HH1HHL5713",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1HH1HHL5714",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}