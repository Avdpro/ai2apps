//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnText} from "/@StdUI/ui/BtnText.js";
import {BtnCheck} from "/@StdUI/ui/BtnCheck.js";
/*#{1GDI1RVQG0StartDoc*/
import pathLib from "/@path";
import {tabFS} from "/@tabos";
import {DataPrj} from "../data/DataPrj.js";
import {BtnObject} from "/@StdUI/ui/BtnObject.js";
/*}#1GDI1RVQG0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let DlgStart=function(app){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1GDI1RVQG7LocalVals*/
	let listBox,dlgVO;
	/*}#1GDI1RVQG7LocalVals*/
	
	/*#{1GDI1RVQG7PreState*/
	/*}#1GDI1RVQG7PreState*/
	/*#{1GDI1RVQG7PostState*/
	/*}#1GDI1RVQG7PostState*/
	cssVO={
		"hash":"1GDI1RVQG7",nameHost:true,
		"type":"box","x":"(FW-500)/2","y":"(FH-360)/2-50","w":500,"h":360,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["body"],
		"border":2,"borderColor":cfgColor["fontBodySub"],"corner":8,"shadow":true,"shadowX":6,"shadowY":12,"shadowBlur":8,"shadowColor":[0,0,0,0.15],
		children:[
			{
				"hash":"1GDI20C3M0",
				"type":"text","x":5,"y":22,"w":100,"h":20,"anchorY":2,"uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodySub"],
				"text":(($ln==="CN")?("最近的工程:"):("Recent Projects:")),"fontSize":txtSize.smallMid,"fontWeight":"bold","fontStyle":"normal","textDecoration":"","alignV":2,
			},
			{
				"hash":"1GDI21LNS0",
				"type":"box","id":"ListBox","x":5,"y":25,"w":300,"h":325,"overflow":"auto-y","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["body"],
				"border":1,"borderColor":cfgColor["fontBody"],"contentLayout":"flex-y",
			},
			{
				"hash":"1IA0VVDR90",
				"type":BtnText("primary",160,30,(($ln==="CN")?("打开工程路径"):("Open Project Path")),false,""),"x":320,"y":25,"fontSize":txtSize.smallMid,"corner":3,
				/*#{1IA0VVDR90Codes*/
				OnClick(){
					self.getPrjPath();
				}
				/*}#1IA0VVDR90Codes*/
			},
			{
				"hash":"1IA103B840",
				"type":BtnText("primary",160,30,(($ln==="CN")?("创建新工程"):("Create New Project")),false,""),"x":320,"y":70,"fontSize":txtSize.smallMid,"corner":3,"enable":false,
				/*#{1IA103B840Codes*/
				OnClick(){
					self.createNewPrj();
				}
				/*}#1IA103B840Codes*/
			},
			{
				"hash":"1IAROB5400",
				"type":"box","x":320,"y":152,"w":160,"h":160,"styleClass":"","background":cfgColor["fontBodyLit"],"maskImage":appCfg.sharedAssets+"/aalogo.svg",
			},
			{
				"hash":"1GDIHOFLR0",
				"type":"text","x":"FW-10","y":">calc(100% - 22px)","w":100,"h":20,"anchorX":2,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodySub"],
				"text":"Tab-OS IDE v"+appCfg.version,"fontSize":txtSize.small,"fontWeight":"bold","fontStyle":"normal","textDecoration":"","alignH":2,"alignV":1,
			},
			{
				"hash":"1IA10617P0",
				"type":BtnCheck(20,"",false,false),"id":"BtnSafeMode","x":320,"y":110,"padding":2,
			},
			{
				"hash":"1GDSAJLAL0",
				"type":"text","x":342,"y":110,"w":100,"h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],"text":(($ln==="CN")?("用安全模式打开"):("Open in safe mode")),
				"fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,
			}
		],
		/*#{1GDI1RVQG7ExtraCSS*/
		/*}#1GDI1RVQG7ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			self=this;
			
			/*#{1GDI1RVQG7Create*/
			listBox=self.ListBox;
			VFACT.applyMoveDrag(self,self);
			/*}#1GDI1RVQG7Create*/
		},
		/*#{1GDI1RVQG7EndCSS*/
		/*}#1GDI1RVQG7EndCSS*/
	};
	/*#{1GDI1RVQG7PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.showDlg=function(vo){
		let prjs,i,n,item;
		dlgVO=vo;
		listBox.clearChildren();
		DataPrj.getUsage().then((saveVO)=>{
			prjs=saveVO.projects||[];
			n=prjs.length;
			for(i=0;i<n;i++){
				item={text:pathLib.basename(prjs[i]),path:prjs[i],icon:appCfg.sharedAssets+"/prj.svg"};
				listBox.appendNewChild({
					//type:MenuLine(item),
					type:BtnObject(item),
					x:0,y:0,position:"relative",path:prjs[i],
					OnClick(){
						self.openPrjPath(this.path);
					}
				})
			}
		});
	};
	
	//------------------------------------------------------------------------
	cssVO.getPrjPath=function(){
		app.showDlg("/@StdUI/ui/DlgFile.js",{
			mode:"open",
			title:(($ln==="CN")?("选择项目路径"):/*EN*/("Choose Project Path")),
			path:"/",
			options:{dirOnly:1,preview:false},
			callback(prjPath){
				if(!prjPath){
					return;
				}
				self.openPrjPath(prjPath);
			}
		});
	};
	
	//------------------------------------------------------------------------
	cssVO.createNewPrj=function(){
		//TODO: Code this:
	};
	
	//------------------------------------------------------------------------
	cssVO.openPrjPath=function(path){
		let safeMode;
		safeMode=self.BtnSafeMode.checked;
		app.closeDlg(self);
		if(dlgVO.callback){
			dlgVO.callback(path,safeMode);
		}
	};
	/*}#1GDI1RVQG7PostCSSVO*/
	return cssVO;
};
/*#{1GDI1RVQG7ExCodes*/
/*}#1GDI1RVQG7ExCodes*/


/*#{1GDI1RVQG0EndDoc*/
/*}#1GDI1RVQG0EndDoc*/

export default DlgStart;
export{DlgStart};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearBox",
//	"jaxId": "1GDI1RVQG0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1GDI1RVQG1",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1GDI1RVQG2",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1H7J2L5R10",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1GDI1RVQG3",
//			"attrs": {
//				"app": {
//					"type": "auto",
//					"valText": "null"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1GDI1RVQG4",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1GDI1RVQG5",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "VFACT document",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1GDI1RVQG6",
//			"attrs": {}
//		},
//		"mockupStates": {
//			"jaxId": "1IA102R2C0",
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "box",
//			"jaxId": "1GDI1RVQG7",
//			"attrs": {
//				"properties": {
//					"jaxId": "1GDI1RVQG8",
//					"attrs": {
//						"type": "box",
//						"id": "",
//						"position": "Absolute",
//						"x": "\"(FW-500)/2\"",
//						"y": "\"(FH-360)/2-50\"",
//						"w": "500",
//						"h": "360",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "[0,0,0,0]",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "\"\"",
//						"styleClass": "",
//						"background": "#cfgColor[\"body\"]",
//						"border": "2",
//						"borderStyle": "Solid",
//						"borderColor": "#cfgColor[\"fontBodySub\"]",
//						"corner": "8",
//						"shadow": "true",
//						"shadowX": "6",
//						"shadowY": "12",
//						"shadowBlur": "8",
//						"shadowSpread": "0",
//						"shadowColor": "[0,0,0,0.15]"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1GDI20C3M0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1GDIHSL740",
//									"attrs": {
//										"type": "text",
//										"id": "",
//										"position": "Absolute",
//										"x": "5",
//										"y": "22",
//										"w": "100",
//										"h": "20",
//										"anchorH": "Left",
//										"anchorV": "Bottom",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "\"\"",
//										"styleClass": "",
//										"color": "#cfgColor[\"fontBodySub\"]",
//										"text": {
//											"type": "string",
//											"valText": "最近的工程:",
//											"localize": {
//												"EN": "Recent Projects:",
//												"CN": "最近的工程:"
//											},
//											"localizable": true
//										},
//										"font": "",
//										"fontSize": "#txtSize.smallMid",
//										"bold": "true",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Bottom",
//										"wrap": "false",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0",
//										"autoSizeW": "false",
//										"autoSizeH": "false"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1GDIHSL741",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1GDIHSL742",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H7J2L5R20",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1GDI21LNS0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1GDIHSL743",
//									"attrs": {
//										"type": "box",
//										"id": "ListBox",
//										"position": "Absolute",
//										"x": "5",
//										"y": "25",
//										"w": "300",
//										"h": "325",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Auto Scroll Y",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "\"\"",
//										"styleClass": "",
//										"background": "#cfgColor[\"body\"]",
//										"border": "1",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor[\"fontBody\"]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"contentLayout": "Flex Y"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1GDIHSL744",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1GDIHSL745",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H7J2L5R21",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear/@StdUI/ui/BtnText.js",
//							"jaxId": "1IA0VVDR90",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1IA102R2C1",
//									"attrs": {
//										"style": "primary",
//										"w": "160",
//										"h": "30",
//										"text": {
//											"type": "string",
//											"valText": "打开工程路径",
//											"localize": {
//												"EN": "Open Project Path",
//												"CN": "打开工程路径"
//											},
//											"localizable": true
//										},
//										"outlined": "false",
//										"icon": ""
//									}
//								},
//								"properties": {
//									"jaxId": "1IA102R2C2",
//									"attrs": {
//										"type": "#null#>BtnText(\"primary\",160,30,(($ln===\"CN\")?(\"打开工程路径\"):(\"Open Project Path\")),false,\"\")",
//										"id": "",
//										"position": "Absolute",
//										"x": "320",
//										"y": "25",
//										"display": "On",
//										"face": "",
//										"fontSize": "#txtSize.smallMid",
//										"corner": "3"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1IA102R2C3",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1IA102R2C4",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IA102R2C5",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "true",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false",
//								"containerSlots": {
//									"jaxId": "1IA102R2C6",
//									"attrs": {
//										"Slot1H2F6U36O0": {
//											"jaxId": "1IA102R2C7",
//											"attrs": {
//												"subHuds": {
//													"attrs": []
//												},
//												"container": "true"
//											}
//										}
//									}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear/@StdUI/ui/BtnText.js",
//							"jaxId": "1IA103B840",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1IA103B841",
//									"attrs": {
//										"style": "primary",
//										"w": "160",
//										"h": "30",
//										"text": {
//											"type": "string",
//											"valText": "创建新工程",
//											"localize": {
//												"EN": "Create New Project",
//												"CN": "创建新工程"
//											},
//											"localizable": true
//										},
//										"outlined": "false",
//										"icon": ""
//									}
//								},
//								"properties": {
//									"jaxId": "1IA103B842",
//									"attrs": {
//										"type": "#null#>BtnText(\"primary\",160,30,(($ln===\"CN\")?(\"创建新工程\"):(\"Create New Project\")),false,\"\")",
//										"id": "",
//										"position": "Absolute",
//										"x": "320",
//										"y": "70",
//										"display": "On",
//										"face": "",
//										"fontSize": "#txtSize.smallMid",
//										"corner": "3",
//										"enable": "false"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1IA103B843",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1IA103B844",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IA103B845",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "true",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false",
//								"containerSlots": {
//									"jaxId": "1IA103B846",
//									"attrs": {
//										"Slot1H2F6U36O0": {
//											"jaxId": "1IA103B847",
//											"attrs": {
//												"subHuds": {
//													"attrs": []
//												},
//												"container": "true"
//											}
//										}
//									}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1IAROB5400",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IAROD0V00",
//									"attrs": {
//										"type": "box",
//										"id": "",
//										"position": "Absolute",
//										"x": "320",
//										"y": "152",
//										"w": "160",
//										"h": "160",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"fontBodyLit\"]",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"maskImage": "#appCfg.sharedAssets+\"/aalogo.svg\""
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1IAROD0V01",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1IAROD0V02",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IAROD0V03",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1GDIHOFLR0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1GDIHSL749",
//									"attrs": {
//										"type": "text",
//										"id": "",
//										"position": "Absolute",
//										"x": "\"FW-10\"",
//										"y": "100%-22",
//										"w": "100",
//										"h": "20",
//										"anchorH": "Right",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "\"\"",
//										"styleClass": "",
//										"color": "#cfgColor[\"fontBodySub\"]",
//										"text": "#\"Tab-OS IDE v\"+appCfg.version",
//										"font": "",
//										"fontSize": "#txtSize.small",
//										"bold": "true",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Right",
//										"alignV": "Center",
//										"wrap": "false",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0",
//										"autoSizeW": "false",
//										"autoSizeH": "false"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1GDIHSL7410",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1GDIHSL7411",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H7J2L5R27",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear/@StdUI/ui/BtnCheck.js",
//							"jaxId": "1IA10617P0",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1IA10773B0",
//									"attrs": {
//										"size": "20",
//										"text": "",
//										"checked": "false",
//										"radio": "false"
//									}
//								},
//								"properties": {
//									"jaxId": "1IA10773B1",
//									"attrs": {
//										"type": "#null#>BtnCheck(20,\"\",false,false)",
//										"id": "BtnSafeMode",
//										"position": "Absolute",
//										"x": "320",
//										"y": "110",
//										"display": "On",
//										"face": "",
//										"padding": "2"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1IA10773B2",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1IA10773B3",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IA10773B4",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false",
//								"containerSlots": {
//									"jaxId": "1IA10773B5",
//									"attrs": {}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1GDSAJLAL0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1GDSAOLJ22",
//									"attrs": {
//										"type": "text",
//										"id": "",
//										"position": "Absolute",
//										"x": "342",
//										"y": "110",
//										"w": "100",
//										"h": "20",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "\"\"",
//										"styleClass": "",
//										"color": "#cfgColor[\"fontBody\"]",
//										"text": {
//											"type": "string",
//											"valText": "用安全模式打开",
//											"localize": {
//												"EN": "Open in safe mode",
//												"CN": "用安全模式打开"
//											},
//											"localizable": true
//										},
//										"font": "",
//										"fontSize": "#txtSize.smallMid",
//										"bold": "false",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Center",
//										"wrap": "false",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0",
//										"autoSizeW": "false",
//										"autoSizeH": "false"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1GDSAOLJ23",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1GDSAOLJ24",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H7J2L5R210",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1GDI1RVQG9",
//					"attrs": {}
//				},
//				"functions": {
//					"jaxId": "1GDI1RVQG10",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1H7J2L5R211",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1GDI1RVQG11",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"background": "false",
//				"color": "false",
//				"gradient": "false",
//				"border": "false",
//				"borders": "false",
//				"borderStyle": "false",
//				"borderColor": "false",
//				"borderColors": "false",
//				"corner": "false",
//				"coner": "false",
//				"coners": "false",
//				"shadow": "false",
//				"shadowX": "false",
//				"shadowY": "false",
//				"shadowBlur": "false",
//				"shadowSpread": "false",
//				"shadowColor": "false",
//				"maskImage": "false",
//				"innerLayout": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"face": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"marginL": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"marginR": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"marginT": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"marginB": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"paddingL": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"paddingT": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"paddingR": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"paddingB": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"attach": {
//					"type": "bool",
//					"valText": "false"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}