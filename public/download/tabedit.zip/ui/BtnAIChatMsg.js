//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnText} from "/@StdUI/ui/BtnText.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
/*#{1H05H4GKA0StartDoc*/
import {DlgMenu} from "/@StdUI/ui/DlgMenu.js";
/*}#1H05H4GKA0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BtnAIChatMsg=function(app,msg,ui){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let btnRole,edMessage;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let roleText=$ln!=="CN"?{"raw":"Raw User","user":"User","assistant":"Assistant"}:{"raw":"用户无加工","user":"用户","assistant":"AI助理"};
	
	/*#{1H05H4GKA1LocalVals*/
	let editing, tracing, tokenTimer;
	editing=false;
	tracing=false;
	tokenTimer=null;
	/*}#1H05H4GKA1LocalVals*/
	
	/*#{1H05H4GKA1PreState*/
	/*}#1H05H4GKA1PreState*/
	state={
		"tip":"Input a message here",
		/*#{1H05H4GKA6ExState*/
		/*}#1H05H4GKA6ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1H05H4GKA1PostState*/
	/*}#1H05H4GKA1PostState*/
	cssVO={
		"hash":"1H05H4GKA1",nameHost:true,
		"type":"button","position":"relative","x":0,"y":0,"w":">calc(100% - 10px)","h":"","padding":[10,5,10,5],"minW":"","minH":20,"maxW":"","maxH":"","styleClass":"",
		"contentLayout":"flex-y",
		"msg":msg,
		children:[
			{
				"hash":"1H05H63NR0",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":[255,255,255,1],
				"border":[0,0,1,0],"borderColor":cfgColor["lineBodyLit"],
			},
			{
				"hash":"1H05H8N4K0",
				"type":BtnText("secondary",80,24,roleText[msg.role],false,""),"id":"BtnRole","x":8,"y":8,"corner":3,
				"OnClick":function(event){
					/*#{1H05I2L4N0FunctionBody*/
					self.doChangeRole(this);
					/*}#1H05I2L4N0FunctionBody*/
				},
			},
			{
				"hash":"1H0MDDB0B0",
				"type":"text","id":"TxtTip","x":95,"y":10,"w":100,"h":20,"display":$P(()=>(msg.content?false:true),msg),"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"color":cfgColor.fontBodyLit,"text":$P(()=>(state.tip),state),"fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
			},
			{
				"hash":"1H05HEO5U0",
				"type":"memo","id":"EdMessage","position":"relative","x":90,"y":0,"w":">calc(100% - 125px)","h":"","padding":0,"minW":"","minH":30,"maxW":"","maxH":"",
				"styleClass":"","text":msg.content,"color":cfgColor.fontBody,"background":[255,255,255,0],"font":"helvetica, sans-serif","fontSize":txtSize.smallMid,
				"outline":0,"borderColor":cfgColor.lineBodyLit,"corner":6,
				"OnBlur":function(event){
					/*#{1H0MD1E020FunctionBody*/
					self.endEdit();
					/*}#1H0MD1E020FunctionBody*/
				},
				"OnInput":function(){
					/*#{1H0MDSIEC0FunctionBody*/
					self.syncMsg();
					/*}#1H0MDSIEC0FunctionBody*/
				},
			},
			{
				"hash":"1H05HQ8PE0",
				"type":BtnIcon("front",20,0,appCfg.sharedAssets+"/trash.svg",null),"id":"BtnDel","x":">calc(100% - 25px)","y":5,"padding":1,
				"tip":(($ln==="CN")?("删除消息"):("Delete message")),
				"OnClick":function(event){
					/*#{1H0MFQ8KC0FunctionBody*/
					ui.doDelMsg(self,this);
					/*}#1H0MFQ8KC0FunctionBody*/
				},
			},
			{
				"hash":"1H05HNO340",
				"type":BtnIcon("front",20,0,appCfg.sharedAssets+"/arrowup.svg",null),"id":"BtnMoveUp","x":8,"y":40,"padding":2,
				"tip":(($ln==="CN")?("上移"):("Move up")),
				"OnClick":function(event){
					/*#{1H0MFRVEN0FunctionBody*/
					ui.moveMsgUp(self,this);
					/*}#1H0MFRVEN0FunctionBody*/
				},
			},
			{
				"hash":"1H0MF3APN0",
				"type":BtnIcon("front",20,0,appCfg.sharedAssets+"/arrowdown.svg",null),"id":"BtnMoveDown","x":28,"y":40,"padding":2,
				"tip":(($ln==="CN")?("下移"):("Move down")),
				"OnClick":function(event){
					/*#{1H0MFSMJ20FunctionBody*/
					ui.moveMsgDown(self,this);
					/*}#1H0MFSMJ20FunctionBody*/
				},
			},
			{
				"hash":"1H0MF44US0",
				"type":BtnIcon("front",20,0,appCfg.sharedAssets+"/additem.svg",null),"id":"BtnNewMsg","x":48,"y":40,"padding":0,
				"tip":(($ln==="CN")?("插入新消息"):("Insert new message")),
				"OnClick":function(event){
					/*#{1H0MFTVKA0FunctionBody*/
					ui.doAddMsg(self,this);
					/*}#1H0MFTVKA0FunctionBody*/
				},
			},
			{
				"hash":"1H0MF8RD60",
				"type":BtnIcon("front",20,0,appCfg.sharedAssets+"/clone.svg",null),"id":"BtnClone","x":68,"y":40,"padding":1,
				"tip":(($ln==="CN")?("复制消息"):("Clone message")),
				"OnClick":function(event){
					/*#{1H0MKGFP80FunctionBody*/
					ui.doCloneMsg(self,this);
					/*}#1H0MKGFP80FunctionBody*/
				},
			},
			{
				"hash":"1H0NT2NF60",
				"type":"text","id":"TxtTokens","position":"relative","x":90,"y":5,"w":">calc(100% - 125px)","h":15,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"color":cfgColor.fontBodyLit,"text":$P(()=>(msg.tokens>=0?`Tokens: ${msg.tokens}`:"- - -"),msg),"fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal",
				"textDecoration":"","alignV":1,
			},
			{
				"hash":"1H0NV45VA0",
				"type":BtnIcon("front",20,0,appCfg.sharedAssets+"/func.svg",null),"id":"BtnDel","x":">calc(100% - 25px)","y":">calc(100% - 25px)","padding":0,
				"tip":(($ln==="CN")?("生成到此位置的代码"):("Generate code till here.")),
				"OnClick":function(event){
					/*#{1H0NV45VB9FunctionBody*/
					ui.showCode(self);
					/*}#1H0NV45VB9FunctionBody*/
				},
			}
		],
		/*#{1H05H4GKA1ExtraCSS*/
		/*}#1H05H4GKA1ExtraCSS*/
		faces:{
			"up":{
				/*#{1H05HAQES0PreCode*/
				$(){
					return (editing||tracing)?false:true;
				},
				/*}#1H05HAQES0PreCode*/
				/*BoxBG*/"#1H05H63NR0":{
					"background":cfgColor["body"]
				},
				/*BtnRole*/"#1H05H8N4K0":{
					"enable":true
				},
				/*TxtTip*/"#1H0MDDB0B0":{
					"x":95,"y":10
				},
				/*EdMessage*/"#1H05HEO5U0":{
					"border":0,"padding":[0,0,0,0],"color":cfgColor.fontBody
				},
				/*BtnDel*/"#1H05HQ8PE0":{
					"alpha":0
				},
				/*BtnMoveUp*/"#1H05HNO340":{
					"alpha":0
				},
				/*BtnMoveDown*/"#1H0MF3APN0":{
					"alpha":0
				},
				/*BtnNewMsg*/"#1H0MF44US0":{
					"alpha":0
				},
				/*BtnClone*/"#1H0MF8RD60":{
					"alpha":0
				},
				/*BtnDel*/"#1H0NV45VA0":{
					"alpha":0
				}
			},"over":{
				/*#{1H05HB7BH0PreCode*/
				$(){
					return (editing||tracing)?false:true;
				},
				/*}#1H05HB7BH0PreCode*/
				/*BoxBG*/"#1H05H63NR0":{
					"background":cfgColor["tool"]
				},
				/*BtnDel*/"#1H05HQ8PE0":{
					"alpha":1
				},
				/*BtnMoveUp*/"#1H05HNO340":{
					"alpha":1
				},
				/*BtnMoveDown*/"#1H0MF3APN0":{
					"alpha":1
				},
				/*BtnNewMsg*/"#1H0MF44US0":{
					"alpha":1
				},
				/*BtnClone*/"#1H0MF8RD60":{
					"alpha":1
				},
				/*BtnDel*/"#1H0NV45VA0":{
					"alpha":1
				}
			},"down":{
				/*#{1H05HBU9A0PreCode*/
				$(){
					return (editing||tracing)?false:true;
				},
				/*}#1H05HBU9A0PreCode*/
				/*BoxBG*/"#1H05H63NR0":{
					"background":cfgColor["footer"]
				}
			},"edit":{
				/*BoxBG*/"#1H05H63NR0":{
					"background":cfgColor["body"]
				},
				/*TxtTip*/"#1H0MDDB0B0":{
					"x":100,"y":15
				},
				/*EdMessage*/"#1H05HEO5U0":{
					"padding":5,"border":1
				},
				/*BtnDel*/"#1H05HQ8PE0":{
					"alpha":1
				},
				/*BtnMoveUp*/"#1H05HNO340":{
					"alpha":1
				},
				/*BtnMoveDown*/"#1H0MF3APN0":{
					"alpha":1
				},
				/*BtnNewMsg*/"#1H0MF44US0":{
					"alpha":1
				},
				/*BtnClone*/"#1H0MF8RD60":{
					"alpha":1
				},
				/*BtnDel*/"#1H0NV45VA0":{
					"alpha":1
				}
			},"trace":{
				/*BtnRole*/"#1H05H8N4K0":{
					"enable":false
				},
				/*EdMessage*/"#1H05HEO5U0":{
					"color":cfgColor.fontBodyLit
				}
			}
		},
		OnCreate:function(){
			self=this;
			btnRole=self.BtnRole;edMessage=self.EdMessage;
			/*#{1H05H4GKA1Create*/
			msg.block=self;
			/*}#1H05H4GKA1Create*/
		},
		/*#{1H05H4GKA1EndCSS*/
		/*}#1H05H4GKA1EndCSS*/
	};
	/*#{1H05H4GKA1PostCSSVO*/
	
	//------------------------------------------------------------------------
	cssVO.startEdit=function(){
		if(editing || tracing)
			return;
		editing=true;
		self.showFace("edit");
		edMessage.focus();
	};
	
	//------------------------------------------------------------------------
	cssVO.endEdit=function(){
		editing=false;
		self.showFace("up");
	};
	
	//------------------------------------------------------------------------
	cssVO.doChangeRole=function(btn){
		if(tracing){
			return;
		}
		app.showDlg(DlgMenu,{
			hud:btnRole,
			items:[
				{text:(($ln==="CN")?("用户"):/*EN*/("User")),code:"user"},
				{text:(($ln==="CN")?("AI助理"):/*EN*/("Assistant")),code:"assistant"},
				{text:(($ln==="CN")?("用户无加工"):/*EN*/("User Raw")),code:"raw"},
			],
			callback(item){
				if(!item){
					return;
				}
				ui.aboutChangeDoc(self);
				btnRole.text=item.text;
				msg.role=item.code;
				ui.msgChanged(msg,self);
			}
		});
	};
	
	//------------------------------------------------------------------------
	cssVO.syncMsg=function(){
		let text;
		if(tracing)
			return;
		text=edMessage.text;
		if(text!==msg.content){
			ui.aboutChangeDoc(self);
			msg.content=text;
			ui.msgChanged(msg,self);
			msg.tokens=-1;
			self.askToken();
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.askToken=function(){
		if(tokenTimer){
			clearTimeout(tokenTimer);
			tokenTimer=null;
		}
		tokenTimer=setTimeout(()=>{
			tokenTimer=null;
			if(msg.tokens>=0)
				return;
			ui.askToken(self);
		},3000);
	};
	
	//------------------------------------------------------------------------
	let traceObj,tracePrefix,tracePostfix;
	let OnUpdate=function (){
		if(traceObj){
			self.EdMessage.text=msg.content=tracePrefix+traceObj.content+tracePostfix;
		}
	};
	let OnClose=function(){
		if(traceObj){
			traceObj.off("content",OnUpdate);
			traceObj.off("close",OnClose);
			traceObj=null;
		}
		tracing=false;
		self.showFace("up");
	};
	cssVO.traceObj=function(obj,prefix="",postfix=""){
		tracing=true;
		traceObj=obj;
		tracePrefix=prefix;
		tracePostfix=postfix;
		self.showFace("trace");
		obj.on("content",OnUpdate);
		obj.on("close",OnClose);
	};
	
	//------------------------------------------------------------------------
	cssVO.stopTrace=OnClose;
	
	/*}#1H05H4GKA1PostCSSVO*/
	cssVO.constructor=BtnAIChatMsg;
	return cssVO;
};
/*#{1H05H4GKA1ExCodes*/
/*}#1H05H4GKA1ExCodes*/

//----------------------------------------------------------------------------
BtnAIChatMsg.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1H05H4GKA1PreAISpot*/
	/*}#1H05H4GKA1PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1H05H4GKA1PostAISpot*/
	/*}#1H05H4GKA1PostAISpot*/
	return exposeVO;
};

/*#{1H05H4GKA0EndDoc*/
/*}#1H05H4GKA0EndDoc*/

export default BtnAIChatMsg;
export{BtnAIChatMsg};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearButton",
//	"jaxId": "1H05H4GKA0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1H05H4GKA2",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "600",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1H05H4GKA3",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1H9FDVE4O0",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1H05H4GKA4",
//			"attrs": {
//				"app": {
//					"type": "auto",
//					"valText": "{}"
//				},
//				"msg": {
//					"type": "auto",
//					"valText": "{\"role\":\"assistant\",\"content\":\"Hello!\"}"
//				},
//				"ui": {
//					"type": "auto",
//					"valText": "null"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1H05H4GKA5",
//			"attrs": {
//				"roleText": {
//					"type": "auto",
//					"valText": "#$ln!==\"CN\"?{\"raw\":\"Raw User\",\"user\":\"User\",\"assistant\":\"Assistant\"}:{\"raw\":\"用户无加工\",\"user\":\"用户\",\"assistant\":\"AI助理\"}"
//				}
//			}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1H05H4GKA6",
//			"attrs": {
//				"tip": {
//					"type": "string",
//					"valText": "Input a message here",
//					"localizable": true
//				}
//			}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1H05H4GKA7",
//			"attrs": {
//				"up": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H05HAQES0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "true",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H05HL0CO0",
//							"attrs": {}
//						}
//					}
//				},
//				"over": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H05HB7BH0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "true",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H05HL0CO1",
//							"attrs": {}
//						}
//					}
//				},
//				"down": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H05HBU9A0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "true",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H05HL0CO2",
//							"attrs": {}
//						}
//					}
//				},
//				"edit": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H05HL0CO3",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H05HL0CO4",
//							"attrs": {}
//						}
//					}
//				},
//				"trace": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1H0MRO7CB0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1H0MRSS550",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1IA2KENQK0",
//			"attrs": {}
//		},
//		"exposeToAI": "true",
//		"descAI": "",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "button",
//			"jaxId": "1H05H4GKA1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1H05H4GKA8",
//					"attrs": {
//						"type": "button",
//						"id": "",
//						"position": "Relative",
//						"x": "0",
//						"y": "0",
//						"w": "100%-10",
//						"h": "\"\"",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "[10,5,10,5]",
//						"minW": "",
//						"minH": "20",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"enable": "true",
//						"drag": "NA",
//						"contentLayout": "Flex Y"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1H05H63NR0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H05HL0CO5",
//									"attrs": {
//										"type": "box",
//										"id": "BoxBG",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "[255,255,255,1.00]",
//										"border": "[0,0,1,0]",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor[\"lineBodyLit\"]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H05HL0CO6",
//									"attrs": {
//										"1H05HAQES0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H05HL0CO7",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H05HL0CO8",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor[\"body\"]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H05HAQES0",
//											"faceTagName": "up"
//										},
//										"1H05HB7BH0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H05HL0CO9",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H05HL0CO10",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor[\"tool\"]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H05HB7BH0",
//											"faceTagName": "over"
//										},
//										"1H05HBU9A0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H05HL0CO11",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H05HL0CO12",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor[\"footer\"]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H05HBU9A0",
//											"faceTagName": "down"
//										},
//										"1H05HL0CO3": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H05IPR2A0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H05IPR2A1",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor[\"body\"]"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H05HL0CO3",
//											"faceTagName": "edit"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1H05HL0CO13",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H05HL0CO14",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "true",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear/@StdUI/ui/BtnText.js",
//							"jaxId": "1H05H8N4K0",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1H05HL0CO15",
//									"attrs": {
//										"style": "secondary",
//										"w": "80",
//										"h": "24",
//										"text": "#roleText[msg.role]",
//										"outlined": "false",
//										"icon": ""
//									}
//								},
//								"properties": {
//									"jaxId": "1H05HL0CO16",
//									"attrs": {
//										"type": "#null#>BtnText(\"secondary\",80,24,roleText[msg.role],false,\"\")",
//										"id": "BtnRole",
//										"position": "Absolute",
//										"x": "8",
//										"y": "8",
//										"display": "On",
//										"face": "",
//										"corner": "3"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H05HL0CO17",
//									"attrs": {
//										"1H05HB7BH0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H05HL0CO20",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H05HL0CO21",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H05HB7BH0",
//											"faceTagName": "over"
//										},
//										"1H05HAQES0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H0ME7TE50",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H0ME7TE51",
//													"attrs": {
//														"enable": {
//															"type": "bool",
//															"valText": "true"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H05HAQES0",
//											"faceTagName": "up"
//										},
//										"1H0MRO7CB0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H0MRSS551",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H0MRSS552",
//													"attrs": {
//														"enable": {
//															"type": "bool",
//															"valText": "false"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H0MRO7CB0",
//											"faceTagName": "trace"
//										},
//										"1H05HBU9A0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H0MRSS553",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H0MRSS554",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H05HBU9A0",
//											"faceTagName": "down"
//										},
//										"1H05HL0CO3": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H0MRSS555",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H0MRSS556",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H05HL0CO3",
//											"faceTagName": "edit"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1H05HL0CO22",
//									"attrs": {
//										"OnClick": {
//											"type": "fixedFunc",
//											"jaxId": "1H05I2L4N0",
//											"attrs": {
//												"callArgs": {
//													"jaxId": "1H05I3B770",
//													"attrs": {
//														"event": ""
//													}
//												},
//												"seg": ""
//											}
//										}
//									}
//								},
//								"extraPpts": {
//									"jaxId": "1H05HL0CO23",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true",
//								"containerSlots": {
//									"jaxId": "1H9FDVE4O1",
//									"attrs": {
//										"Slot1H2F6U36O0": {
//											"jaxId": "1IA2KENQK1",
//											"attrs": {
//												"subHuds": {
//													"attrs": []
//												},
//												"container": "true"
//											}
//										}
//									}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1H0MDDB0B0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H0MDI9MS0",
//									"attrs": {
//										"type": "text",
//										"id": "TxtTip",
//										"position": "Absolute",
//										"x": "95",
//										"y": "10",
//										"w": "100",
//										"h": "20",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "${msg.content?false:true},msg",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#cfgColor.fontBodyLit",
//										"text": "${state.tip},state",
//										"font": "",
//										"fontSize": "#txtSize.smallMid",
//										"bold": "false",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Top",
//										"wrap": "false",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0",
//										"autoSizeW": "false",
//										"autoSizeH": "false"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H0MDI9MS1",
//									"attrs": {
//										"1H05HAQES0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H0ME7TE52",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H0ME7TE53",
//													"attrs": {
//														"x": {
//															"type": "length",
//															"valText": "95"
//														},
//														"y": {
//															"type": "length",
//															"valText": "10"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H05HAQES0",
//											"faceTagName": "up"
//										},
//										"1H05HL0CO3": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H0ME7TE54",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H0ME7TE55",
//													"attrs": {
//														"x": {
//															"type": "length",
//															"valText": "100"
//														},
//														"y": {
//															"type": "length",
//															"valText": "15"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H05HL0CO3",
//											"faceTagName": "edit"
//										},
//										"1H05HB7BH0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H0MFFSGE0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H0MFFSGE1",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H05HB7BH0",
//											"faceTagName": "over"
//										},
//										"1H05HBU9A0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H0MRSS557",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H0MRSS558",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H05HBU9A0",
//											"faceTagName": "down"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1H0MDI9MS2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H0MDI9MS3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "memo",
//							"jaxId": "1H05HEO5U0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H05HL0CO24",
//									"attrs": {
//										"type": "memo",
//										"id": "EdMessage",
//										"position": "relative",
//										"x": "90",
//										"y": "0",
//										"w": "100%-125",
//										"h": "\"\"",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "0",
//										"minW": "",
//										"minH": "30",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"text": "#msg.content",
//										"color": "#cfgColor.fontBody",
//										"bgColor": "[255,255,255,0.00]",
//										"font": "helvetica, sans-serif",
//										"fontSize": "#txtSize.smallMid",
//										"outline": "0",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor.lineBodyLit",
//										"corner": "6",
//										"readOnly": "false",
//										"selectOnFocus": "true",
//										"spellCheck": "true"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H05HL0CO25",
//									"attrs": {
//										"1H05HB7BH0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H05IPR2A6",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H05IPR2A7",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H05HB7BH0",
//											"faceTagName": "over"
//										},
//										"1H05HL0CO3": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H0MCV82A4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H0MCV82A5",
//													"attrs": {
//														"padding": {
//															"type": "auto",
//															"valText": "5",
//															"editMode": "edges"
//														},
//														"border": {
//															"type": "auto",
//															"valText": "1",
//															"editMode": "edges"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H05HL0CO3",
//											"faceTagName": "edit"
//										},
//										"1H05HAQES0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H0MCV82A6",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H0MCV82A7",
//													"attrs": {
//														"border": {
//															"type": "auto",
//															"valText": "0",
//															"editMode": "edges"
//														},
//														"padding": {
//															"type": "auto",
//															"valText": "[0,0,0,0]",
//															"editMode": "edges"
//														},
//														"color": {
//															"type": "colorRGB",
//															"valText": "#cfgColor.fontBody"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H05HAQES0",
//											"faceTagName": "up"
//										},
//										"1H0MRO7CB0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H0MRSS559",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H0MRSS5510",
//													"attrs": {
//														"color": {
//															"type": "colorRGB",
//															"valText": "#cfgColor.fontBodyLit"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H0MRO7CB0",
//											"faceTagName": "trace"
//										},
//										"1H05HBU9A0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H0MRSS5511",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H0MRSS5512",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H05HBU9A0",
//											"faceTagName": "down"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1H05HL0CO26",
//									"attrs": {
//										"OnBlur": {
//											"type": "fixedFunc",
//											"jaxId": "1H0MD1E020",
//											"attrs": {
//												"callArgs": {
//													"jaxId": "1H0MD2PIG0",
//													"attrs": {
//														"event": ""
//													}
//												},
//												"seg": ""
//											}
//										},
//										"OnInput": {
//											"type": "fixedFunc",
//											"jaxId": "1H0MDSIEC0",
//											"attrs": {
//												"callArgs": {
//													"jaxId": "1H0MDSU300",
//													"attrs": {}
//												},
//												"seg": ""
//											}
//										}
//									}
//								},
//								"extraPpts": {
//									"jaxId": "1H05HL0CO27",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear/@StdUI/ui/BtnIcon.js",
//							"jaxId": "1H05HQ8PE0",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1H05HQ8PE1",
//									"attrs": {
//										"style": "front",
//										"w": "20",
//										"h": "0",
//										"icon": "#appCfg.sharedAssets+\"/trash.svg\"",
//										"colorBG": "null"
//									}
//								},
//								"properties": {
//									"jaxId": "1H05HQ8PE2",
//									"attrs": {
//										"type": "#null#>BtnIcon(\"front\",20,0,appCfg.sharedAssets+\"/trash.svg\",null)",
//										"id": "BtnDel",
//										"position": "Absolute",
//										"x": "100%-25",
//										"y": "5",
//										"display": "On",
//										"face": "",
//										"padding": "1"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H05HQ8PE3",
//									"attrs": {
//										"1H05HAQES0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H05IPR2A18",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H05IPR2A19",
//													"attrs": {
//														"alpha": {
//															"type": "number",
//															"valText": "0",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H05HAQES0",
//											"faceTagName": "up"
//										},
//										"1H05HB7BH0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H05IPR2A20",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H05IPR2A21",
//													"attrs": {
//														"alpha": {
//															"type": "number",
//															"valText": "1",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H05HB7BH0",
//											"faceTagName": "over"
//										},
//										"1H05HL0CO3": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H05IPR2A22",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H05IPR2A23",
//													"attrs": {
//														"alpha": {
//															"type": "number",
//															"valText": "1",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H05HL0CO3",
//											"faceTagName": "edit"
//										},
//										"1H05HBU9A0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H0MRSS560",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H0MRSS561",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H05HBU9A0",
//											"faceTagName": "down"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1H05HQ8PE4",
//									"attrs": {
//										"OnClick": {
//											"type": "fixedFunc",
//											"jaxId": "1H0MFQ8KC0",
//											"attrs": {
//												"callArgs": {
//													"jaxId": "1H0MFQE800",
//													"attrs": {
//														"event": ""
//													}
//												},
//												"seg": ""
//											}
//										}
//									}
//								},
//								"extraPpts": {
//									"jaxId": "1H05HQ8PE5",
//									"attrs": {
//										"tip": {
//											"type": "string",
//											"valText": "删除消息",
//											"localize": {
//												"EN": "Delete message",
//												"CN": "删除消息"
//											},
//											"localizable": true
//										}
//									}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false",
//								"containerSlots": {
//									"jaxId": "1H9FDVE4O2",
//									"attrs": {}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear/@StdUI/ui/BtnIcon.js",
//							"jaxId": "1H05HNO340",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1H05HQ7JT0",
//									"attrs": {
//										"style": "front",
//										"w": "20",
//										"h": "0",
//										"icon": "#appCfg.sharedAssets+\"/arrowup.svg\"",
//										"colorBG": "null"
//									}
//								},
//								"properties": {
//									"jaxId": "1H05HQ7JT1",
//									"attrs": {
//										"type": "#null#>BtnIcon(\"front\",20,0,appCfg.sharedAssets+\"/arrowup.svg\",null)",
//										"id": "BtnMoveUp",
//										"position": "Absolute",
//										"x": "8",
//										"y": "40",
//										"display": "On",
//										"face": "",
//										"padding": "2"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H05HQ7JT2",
//									"attrs": {
//										"1H05HAQES0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H05IPR2A10",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H05IPR2A11",
//													"attrs": {
//														"alpha": {
//															"type": "number",
//															"valText": "0",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H05HAQES0",
//											"faceTagName": "up"
//										},
//										"1H05HB7BH0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H05IPR2A12",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H05IPR2A13",
//													"attrs": {
//														"alpha": {
//															"type": "number",
//															"valText": "1.00",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H05HB7BH0",
//											"faceTagName": "over"
//										},
//										"1H05HL0CO3": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H05IPR2A14",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H05IPR2A15",
//													"attrs": {
//														"alpha": {
//															"type": "number",
//															"valText": "1",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H05HL0CO3",
//											"faceTagName": "edit"
//										},
//										"1H05HBU9A0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H0MRSS562",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H0MRSS563",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H05HBU9A0",
//											"faceTagName": "down"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1H05HQ7JT3",
//									"attrs": {
//										"OnClick": {
//											"type": "fixedFunc",
//											"jaxId": "1H0MFRVEN0",
//											"attrs": {
//												"callArgs": {
//													"jaxId": "1H0MFSIA00",
//													"attrs": {
//														"event": ""
//													}
//												},
//												"seg": ""
//											}
//										}
//									}
//								},
//								"extraPpts": {
//									"jaxId": "1H05HQ7JT4",
//									"attrs": {
//										"tip": {
//											"type": "string",
//											"valText": "上移",
//											"localize": {
//												"EN": "Move up",
//												"CN": "上移"
//											},
//											"localizable": true
//										}
//									}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false",
//								"containerSlots": {
//									"jaxId": "1H9FDVE4O3",
//									"attrs": {}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear/@StdUI/ui/BtnIcon.js",
//							"jaxId": "1H0MF3APN0",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1H0MF3APN1",
//									"attrs": {
//										"style": "front",
//										"w": "20",
//										"h": "0",
//										"icon": "#appCfg.sharedAssets+\"/arrowdown.svg\"",
//										"colorBG": "null"
//									}
//								},
//								"properties": {
//									"jaxId": "1H0MF3APN2",
//									"attrs": {
//										"type": "#null#>BtnIcon(\"front\",20,0,appCfg.sharedAssets+\"/arrowdown.svg\",null)",
//										"id": "BtnMoveDown",
//										"position": "Absolute",
//										"x": "28",
//										"y": "40",
//										"display": "On",
//										"face": "",
//										"padding": "2"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H0MF3APN3",
//									"attrs": {
//										"1H05HAQES0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H0MF3APN4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H0MF3APN5",
//													"attrs": {
//														"alpha": {
//															"type": "number",
//															"valText": "0",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H05HAQES0",
//											"faceTagName": "up"
//										},
//										"1H05HB7BH0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H0MF3APN6",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H0MF3APN7",
//													"attrs": {
//														"alpha": {
//															"type": "number",
//															"valText": "1.00",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H05HB7BH0",
//											"faceTagName": "over"
//										},
//										"1H05HL0CO3": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H0MF3APN8",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H0MF3APN9",
//													"attrs": {
//														"alpha": {
//															"type": "number",
//															"valText": "1",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H05HL0CO3",
//											"faceTagName": "edit"
//										},
//										"1H05HBU9A0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H0MRSS564",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H0MRSS565",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H05HBU9A0",
//											"faceTagName": "down"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1H0MF3APN12",
//									"attrs": {
//										"OnClick": {
//											"type": "fixedFunc",
//											"jaxId": "1H0MFSMJ20",
//											"attrs": {
//												"callArgs": {
//													"jaxId": "1H0MFT2KH0",
//													"attrs": {
//														"event": ""
//													}
//												},
//												"seg": ""
//											}
//										}
//									}
//								},
//								"extraPpts": {
//									"jaxId": "1H0MF3APN13",
//									"attrs": {
//										"tip": {
//											"type": "string",
//											"valText": "下移",
//											"localize": {
//												"EN": "Move down",
//												"CN": "下移"
//											},
//											"localizable": true
//										}
//									}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false",
//								"containerSlots": {
//									"jaxId": "1H9FDVE4O4",
//									"attrs": {}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear/@StdUI/ui/BtnIcon.js",
//							"jaxId": "1H0MF44US0",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1H0MF44US1",
//									"attrs": {
//										"style": "front",
//										"w": "20",
//										"h": "0",
//										"icon": "#appCfg.sharedAssets+\"/additem.svg\"",
//										"colorBG": "null"
//									}
//								},
//								"properties": {
//									"jaxId": "1H0MF44US2",
//									"attrs": {
//										"type": "#null#>BtnIcon(\"front\",20,0,appCfg.sharedAssets+\"/additem.svg\",null)",
//										"id": "BtnNewMsg",
//										"position": "Absolute",
//										"x": "48",
//										"y": "40",
//										"display": "On",
//										"face": "",
//										"padding": "0"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H0MF44US3",
//									"attrs": {
//										"1H05HAQES0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H0MF44UT0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H0MF44UT1",
//													"attrs": {
//														"alpha": {
//															"type": "number",
//															"valText": "0",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H05HAQES0",
//											"faceTagName": "up"
//										},
//										"1H05HB7BH0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H0MF44UT2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H0MF44UT3",
//													"attrs": {
//														"alpha": {
//															"type": "number",
//															"valText": "1.00",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H05HB7BH0",
//											"faceTagName": "over"
//										},
//										"1H05HL0CO3": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H0MF44UT4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H0MF44UT5",
//													"attrs": {
//														"alpha": {
//															"type": "number",
//															"valText": "1",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H05HL0CO3",
//											"faceTagName": "edit"
//										},
//										"1H05HBU9A0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H0MRSS566",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H0MRSS567",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H05HBU9A0",
//											"faceTagName": "down"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1H0MF44UT8",
//									"attrs": {
//										"OnClick": {
//											"type": "fixedFunc",
//											"jaxId": "1H0MFTVKA0",
//											"attrs": {
//												"callArgs": {
//													"jaxId": "1H0MFU5NF0",
//													"attrs": {
//														"event": ""
//													}
//												},
//												"seg": ""
//											}
//										}
//									}
//								},
//								"extraPpts": {
//									"jaxId": "1H0MF44UT9",
//									"attrs": {
//										"tip": {
//											"type": "string",
//											"valText": "插入新消息",
//											"localize": {
//												"EN": "Insert new message",
//												"CN": "插入新消息"
//											},
//											"localizable": true
//										}
//									}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false",
//								"containerSlots": {
//									"jaxId": "1H9FDVE4O5",
//									"attrs": {}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear/@StdUI/ui/BtnIcon.js",
//							"jaxId": "1H0MF8RD60",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1H0MF8RD61",
//									"attrs": {
//										"style": "front",
//										"w": "20",
//										"h": "0",
//										"icon": "#appCfg.sharedAssets+\"/clone.svg\"",
//										"colorBG": "null"
//									}
//								},
//								"properties": {
//									"jaxId": "1H0MF8RD62",
//									"attrs": {
//										"type": "#null#>BtnIcon(\"front\",20,0,appCfg.sharedAssets+\"/clone.svg\",null)",
//										"id": "BtnClone",
//										"position": "Absolute",
//										"x": "68",
//										"y": "40",
//										"display": "On",
//										"face": "",
//										"padding": "1"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H0MF8RD63",
//									"attrs": {
//										"1H05HAQES0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H0MF8RD70",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H0MF8RD71",
//													"attrs": {
//														"alpha": {
//															"type": "number",
//															"valText": "0",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H05HAQES0",
//											"faceTagName": "up"
//										},
//										"1H05HB7BH0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H0MF8RD72",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H0MF8RD73",
//													"attrs": {
//														"alpha": {
//															"type": "number",
//															"valText": "1.00",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H05HB7BH0",
//											"faceTagName": "over"
//										},
//										"1H05HL0CO3": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H0MF8RD74",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H0MF8RD75",
//													"attrs": {
//														"alpha": {
//															"type": "number",
//															"valText": "1",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H05HL0CO3",
//											"faceTagName": "edit"
//										},
//										"1H05HBU9A0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H0MRSS568",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H0MRSS569",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H05HBU9A0",
//											"faceTagName": "down"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1H0MF8RD78",
//									"attrs": {
//										"OnClick": {
//											"type": "fixedFunc",
//											"jaxId": "1H0MKGFP80",
//											"attrs": {
//												"callArgs": {
//													"jaxId": "1H0MKGNUD0",
//													"attrs": {
//														"event": ""
//													}
//												},
//												"seg": ""
//											}
//										}
//									}
//								},
//								"extraPpts": {
//									"jaxId": "1H0MF8RD79",
//									"attrs": {
//										"tip": {
//											"type": "string",
//											"valText": "复制消息",
//											"localize": {
//												"EN": "Clone message",
//												"CN": "复制消息"
//											},
//											"localizable": true
//										}
//									}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false",
//								"containerSlots": {
//									"jaxId": "1H9FDVE4O6",
//									"attrs": {}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1H0NT2NF60",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H0NT7G0J0",
//									"attrs": {
//										"type": "text",
//										"id": "TxtTokens",
//										"position": "relative",
//										"x": "90",
//										"y": "5",
//										"w": "100%-125",
//										"h": "15",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#cfgColor.fontBodyLit",
//										"text": "${msg.tokens>=0?`Tokens: ${msg.tokens}`:\"- - -\"},msg",
//										"font": "",
//										"fontSize": "#txtSize.small",
//										"bold": "false",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Center",
//										"wrap": "false",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0",
//										"autoSizeW": "false",
//										"autoSizeH": "false"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H0NT7G0J1",
//									"attrs": {
//										"1H05HL0CO3": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H0NT7G0J2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H0NT7G0J3",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H05HL0CO3",
//											"faceTagName": "edit"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1H0NT7G0J4",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H0NT7G0J5",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear/@StdUI/ui/BtnIcon.js",
//							"jaxId": "1H0NV45VA0",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1H0NV45VA1",
//									"attrs": {
//										"style": "front",
//										"w": "20",
//										"h": "0",
//										"icon": "#appCfg.sharedAssets+\"/func.svg\"",
//										"colorBG": "null"
//									}
//								},
//								"properties": {
//									"jaxId": "1H0NV45VA2",
//									"attrs": {
//										"type": "#null#>BtnIcon(\"front\",20,0,appCfg.sharedAssets+\"/func.svg\",null)",
//										"id": "BtnDel",
//										"position": "Absolute",
//										"x": "100%-25",
//										"y": "100%-25",
//										"display": "On",
//										"face": "",
//										"padding": "0"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1H0NV45VA3",
//									"attrs": {
//										"1H05HAQES0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H0NV45VB0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H0NV45VB1",
//													"attrs": {
//														"alpha": {
//															"type": "number",
//															"valText": "0",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H05HAQES0",
//											"faceTagName": "up"
//										},
//										"1H05HB7BH0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H0NV45VB2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H0NV45VB3",
//													"attrs": {
//														"alpha": {
//															"type": "number",
//															"valText": "1",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H05HB7BH0",
//											"faceTagName": "over"
//										},
//										"1H05HL0CO3": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H0NV45VB4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H0NV45VB5",
//													"attrs": {
//														"alpha": {
//															"type": "number",
//															"valText": "1",
//															"editMode": "range",
//															"editType": "range"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H05HL0CO3",
//											"faceTagName": "edit"
//										},
//										"1H05HBU9A0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H0NV45VB6",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H0NV45VB7",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1H05HBU9A0",
//											"faceTagName": "down"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1H0NV45VB8",
//									"attrs": {
//										"OnClick": {
//											"type": "fixedFunc",
//											"jaxId": "1H0NV45VB9",
//											"attrs": {
//												"callArgs": {
//													"jaxId": "1H0NV45VB10",
//													"attrs": {
//														"event": ""
//													}
//												},
//												"seg": ""
//											}
//										}
//									}
//								},
//								"extraPpts": {
//									"jaxId": "1H0NV45VB11",
//									"attrs": {
//										"tip": {
//											"type": "string",
//											"valText": "生成到此位置的代码",
//											"localize": {
//												"EN": "Generate code till here.",
//												"CN": "生成到此位置的代码"
//											},
//											"localizable": true
//										}
//									}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false",
//								"containerSlots": {
//									"jaxId": "1H9FDVE4O7",
//									"attrs": {}
//								}
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1H05H4GKA9",
//					"attrs": {
//						"1H05HB7BH0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H05HL0CO30",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H05HL0CO31",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H05HB7BH0",
//							"faceTagName": "over"
//						},
//						"1H05HBU9A0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H0MRSS5610",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H0MRSS5611",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H05HBU9A0",
//							"faceTagName": "down"
//						},
//						"1H05HL0CO3": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H0MRSS5612",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H0MRSS5613",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1H05HL0CO3",
//							"faceTagName": "edit"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1H05H4GKA10",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1H05H4GKA11",
//					"attrs": {
//						"msg": {
//							"type": "auto",
//							"valText": "#msg"
//						}
//					}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1H05H4GKA12",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false",
//				"enable": "false",
//				"drag": "false",
//				"innerLayout": {
//					"valText": "false"
//				},
//				"marginL": {
//					"valText": "false"
//				},
//				"marginR": {
//					"valText": "false"
//				},
//				"marginT": {
//					"valText": "false"
//				},
//				"marginB": {
//					"valText": "false"
//				},
//				"paddingL": {
//					"valText": "false"
//				},
//				"paddingR": {
//					"valText": "false"
//				},
//				"paddingT": {
//					"valText": "false"
//				},
//				"paddingB": {
//					"valText": "false"
//				},
//				"attach": {
//					"valText": "false"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}