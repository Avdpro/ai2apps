//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1G9E42NEU0StartDoc*/
/*}#1G9E42NEU0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let ToolTabBtn=function(app,view,def,pad){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1G9E42NEU7LocalVals*/
	let isFocused=0;
	/*}#1G9E42NEU7LocalVals*/
	
	/*#{1G9E42NEU7PreState*/
	/*}#1G9E42NEU7PreState*/
	/*#{1G9E42NEU7PostState*/
	/*}#1G9E42NEU7PostState*/
	cssVO={
		"hash":"1G9E42NEU7",nameHost:true,
		"type":"button","position":"relative","x":0,"y":0,"w":"FH","h":"FH-3","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
		children:[
			{
				"hash":"1G9E446230",
				"type":"box","id":"BoxHot","x":0,"y":0,"w":"FW","h":"FH","display":0,"uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.tool,
				"border":[0,1,1,1],"borderColor":cfgColor.lineBodySub,"corner":[0,0,5,5],
			},
			{
				"hash":"1G9E4KI9G0",
				"type":"box","id":"BoxOver","x":0,"y":2,"w":"FH","h":"FH","display":0,"uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.hot,
			},
			{
				"hash":"1G9E48QHF0",
				"type":"box","id":"BoxIcon","x":"FW/2","y":5,"w":`FH-${pad*2}`,"h":`FH-${pad*2}`,"anchorX":1,"uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","background":cfgColor.fontToolSub,"border":1,"maskImage":def.icon,
			},
			{
				"hash":"1HTGLQBDV0",
				"type":"box","id":"BoxMark","x":">calc(100% - 12px)","y":3,"w":10,"h":10,"display":0,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["error"],
				"corner":6,
			}
		],
		/*#{1G9E42NEU7ExtraCSS*/
		/*}#1G9E42NEU7ExtraCSS*/
		faces:{
			"up":{
				/*#{1G9E4J4FE0PreCode*/
				$(){
					return isFocused?false:true;
				},
				/*}#1G9E4J4FE0PreCode*/
				/*BoxOver*/"#1G9E4KI9G0":{
					"display":0
				}
			},"over":{
				/*#{1G9E4J7CS0PreCode*/
				$(){
					return isFocused?false:true;
				},
				/*}#1G9E4J7CS0PreCode*/
				/*BoxOver*/"#1G9E4KI9G0":{
					"background":[...cfgColor.hot,50],"display":1
				}
			},"down":{
				/*#{1G9E4JARP0PreCode*/
				$(){
					return isFocused?false:true;
				},
				/*}#1G9E4JARP0PreCode*/
				/*BoxOver*/"#1G9E4KI9G0":{
					"display":1,"background":cfgColor.hot
				}
			},"gray":{
			},"focus":{
				/*BoxHot*/"#1G9E446230":{
					"display":1
				},
				/*BoxOver*/"#1G9E4KI9G0":{
					"display":0
				},
				/*BoxIcon*/"#1G9E48QHF0":{
					"background":cfgColor["fontBody"],"y":2
				},
				/*BoxMark*/"#1HTGLQBDV0":{
					"y":0
				},
				/*#{1G9E4JGMM0Code*/
				$(){
					isFocused=1;
				},
				/*}#1G9E4JGMM0Code*/
			},"blur":{
				/*BoxHot*/"#1G9E446230":{
					"display":0
				},
				/*BoxIcon*/"#1G9E48QHF0":{
					"background":cfgColor.fontToolSub,"y":5
				},
				/*BoxMark*/"#1HTGLQBDV0":{
					"y":3
				},
				/*#{1G9E4JL3E0Code*/
				$(){
					isFocused=0;
				},
				/*}#1G9E4JL3E0Code*/
			},"mark":{
				/*BoxMark*/"#1HTGLQBDV0":{
					"display":1
				}
			},"!mark":{
				/*BoxMark*/"#1HTGLQBDV0":{
					"display":0
				}
			}
		},
		OnCreate:function(){
			self=this;
			
			/*#{1G9E42NEU7Create*/
			/*}#1G9E42NEU7Create*/
		},
		/*#{1G9E42NEU7EndCSS*/
		/*}#1G9E42NEU7EndCSS*/
	};
	/*#{1G9E42NEU7PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.OnClick=function(){
		view.showView(def.codeName||def.name);
	};
	
	//------------------------------------------------------------------------
	cssVO.OnMouseInOut=function(isIn){
		if(isIn){
			if(!isFocused){
				app.showTip(self,def.info,self.w*0.5,0,1,2);
			}
		}else{
			app.abortTip(self);
		}
	};
	/*}#1G9E42NEU7PostCSSVO*/
	return cssVO;
};
/*#{1G9E42NEU7ExCodes*/
/*}#1G9E42NEU7ExCodes*/

ToolTabBtn.gearExport={
	framework: "vfact",
	hudType: "button",
	"showName":"",icon:"gears.svg",previewImg:false,
	fixPose:false,initW:100,initH:100,
	catalog:"Buttons",
	args: {
		"app": {
			"name": "app", "showName": "app", "type": "auto", "key": true, "fixed": true, 
			"initVal": null
		}, 
		"view": {
			"name": "view", "showName": "view", "type": "auto", "key": true, "fixed": true, 
			"initVal": null
		}, 
		"def": {
			"name": "def", "showName": "def", "type": "auto", "key": true, "fixed": true, 
			"initVal": {
				"icon": "/~/-tabos/shared/assets/folder.svg", "name": "Files", "Info": "Project files"
			}, 
			"initValText": "#{\"icon\":appCfg.sharedAssets+\"/folder.svg\",\"name\":\"Files\",\"Info\":\"Project files\"}"
		}, 
		"pad": {
			"name": "pad", "showName": "pad", "type": "int", "key": true, "fixed": true, "initVal": 2
		}
	},
	state:{
	},
	properties:["id","position","x","y","display"],
	faces:["up","over","down","gray","focus","blur","mark","!mark"],
	subContainers:{
	},
	/*#{1G9E42NEU0ExGearInfo*/
	/*}#1G9E42NEU0ExGearInfo*/
};
/*#{1G9E42NEU0EndDoc*/
/*}#1G9E42NEU0EndDoc*/

export default ToolTabBtn;
export{ToolTabBtn};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearButton",
//	"jaxId": "1G9E42NEU0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1G9E42NEU1",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "30",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1G9E42NEU2",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1HTGM08PM0",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1G9E42NEU3",
//			"attrs": {
//				"app": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"view": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"def": {
//					"type": "auto",
//					"valText": "#{\"icon\":appCfg.sharedAssets+\"/folder.svg\",\"name\":\"Files\",\"Info\":\"Project files\"}"
//				},
//				"pad": {
//					"type": "int",
//					"valText": "2"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1G9E42NEU4",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1G9E42NEU5",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "VFACT document",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "Buttons",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1G9E42NEU6",
//			"attrs": {
//				"up": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1G9E4J4FE0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "true",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1G9E4V44M0",
//							"attrs": {}
//						}
//					}
//				},
//				"over": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1G9E4J7CS0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "true",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1G9E4V44M1",
//							"attrs": {}
//						}
//					}
//				},
//				"down": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1G9E4JARP0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "true",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1G9E4V44M2",
//							"attrs": {}
//						}
//					}
//				},
//				"gray": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1G9E4JDSC0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1G9E4V44M3",
//							"attrs": {}
//						}
//					}
//				},
//				"focus": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1G9E4JGMM0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1G9E4V44M4",
//							"attrs": {}
//						}
//					}
//				},
//				"blur": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1G9E4JL3E0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1G9E4V44M5",
//							"attrs": {}
//						}
//					}
//				},
//				"mark": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HTGM1FRK0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HTGM22FI0",
//							"attrs": {}
//						}
//					}
//				},
//				"!mark": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HTGM1TU00",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HTGM22FI1",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1HTGM08PM1",
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "button",
//			"jaxId": "1G9E42NEU7",
//			"attrs": {
//				"properties": {
//					"jaxId": "1G9E42NEU8",
//					"attrs": {
//						"type": "button",
//						"id": "",
//						"position": "Relative",
//						"x": "0",
//						"y": "0",
//						"w": "\"FH\"",
//						"h": "\"FH-3\"",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "[0,0,0,0]",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "\"\"",
//						"styleClass": "",
//						"enable": "true",
//						"drag": "NA"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1G9E446230",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G9E47M690",
//									"attrs": {
//										"type": "box",
//										"id": "BoxHot",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "\"FW\" ",
//										"h": "\"FH\"",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "Off",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "\"\"",
//										"styleClass": "",
//										"background": "#cfgColor.tool",
//										"border": "[0,1,1,1]",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor.lineBodySub",
//										"corner": "[0,0,5,5]",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1G9E47M691",
//									"attrs": {
//										"1G9E4J7CS0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9E4V44M6",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9E4V44M7",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9E4J7CS0",
//											"faceTagName": "over"
//										},
//										"1G9E4JARP0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9E4V44M8",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9E4V44M9",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9E4JARP0",
//											"faceTagName": "down"
//										},
//										"1G9E4JGMM0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9E4V44M10",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9E4V44M11",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9E4JGMM0",
//											"faceTagName": "focus"
//										},
//										"1G9E4JL3E0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9E4V44M12",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9E4V44M13",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9E4JL3E0",
//											"faceTagName": "blur"
//										},
//										"1G9E4JDSC0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9ITCN1V0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9ITCN1V1",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9E4JDSC0",
//											"faceTagName": "gray"
//										},
//										"1G9E4J4FE0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9IUTKOP0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9IUTKOP1",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9E4J4FE0",
//											"faceTagName": "up"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1G9E47M692",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HTGM08PN0",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1G9E4KI9G0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G9E4V44M14",
//									"attrs": {
//										"type": "box",
//										"id": "BoxOver",
//										"position": "Absolute",
//										"x": "0",
//										"y": "2",
//										"w": "\"FH\"",
//										"h": "\"FH\"",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "Off",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "\"\"",
//										"styleClass": "",
//										"background": "#cfgColor.hot",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1G9E4V44M15",
//									"attrs": {
//										"1G9E4J4FE0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9E4V44M16",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9E4V44M17",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9E4J4FE0",
//											"faceTagName": "up"
//										},
//										"1G9E4J7CS0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9E4V44M18",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9E4V44M19",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#[...cfgColor.hot,50]"
//														},
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9E4J7CS0",
//											"faceTagName": "over"
//										},
//										"1G9E4JARP0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9E4V44M20",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9E4V44M21",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														},
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor.hot"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9E4JARP0",
//											"faceTagName": "down"
//										},
//										"1G9E4JGMM0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9E4V44M22",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9E4V44M23",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9E4JGMM0",
//											"faceTagName": "focus"
//										},
//										"1G9E4JDSC0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9ITCN1V2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9ITCN1V3",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9E4JDSC0",
//											"faceTagName": "gray"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1G9E4V44M24",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HTGM08PN1",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1G9E48QHF0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G9E4FD8A0",
//									"attrs": {
//										"type": "box",
//										"id": "BoxIcon",
//										"position": "Absolute",
//										"x": "\"FW/2\"",
//										"y": "5",
//										"w": "#`FH-${pad*2}`",
//										"h": "#`FH-${pad*2}`",
//										"anchorH": "Center",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "\"\"",
//										"styleClass": "",
//										"background": "#cfgColor.fontToolSub",
//										"border": "1",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"maskImage": "#def.icon"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1G9E4FD8A1",
//									"attrs": {
//										"1G9E4J7CS0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9E4V44M25",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9E4V44M26",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9E4J7CS0",
//											"faceTagName": "over"
//										},
//										"1G9E4JARP0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9E4V44M27",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9E4V44M28",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9E4JARP0",
//											"faceTagName": "down"
//										},
//										"1G9E4JGMM0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9E4V44M29",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9E4V44M30",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor[\"fontBody\"]"
//														},
//														"y": {
//															"type": "length",
//															"valText": "2"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9E4JGMM0",
//											"faceTagName": "focus"
//										},
//										"1G9E4JL3E0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9E4V44M31",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9E4V44M32",
//													"attrs": {
//														"background": {
//															"type": "colorRGBA",
//															"valText": "#cfgColor.fontToolSub"
//														},
//														"y": {
//															"type": "length",
//															"valText": "5"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9E4JL3E0",
//											"faceTagName": "blur"
//										},
//										"1G9E4JDSC0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9ITCN1V4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9ITCN1V5",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9E4JDSC0",
//											"faceTagName": "gray"
//										},
//										"1G9E4J4FE0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9IUTKOP2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9IUTKOP3",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9E4J4FE0",
//											"faceTagName": "up"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1G9E4FD8A2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HTGM08PN2",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1HTGLQBDV0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HTGLS5VD0",
//									"attrs": {
//										"type": "box",
//										"id": "BoxMark",
//										"position": "Absolute",
//										"x": "100%-12",
//										"y": "3",
//										"w": "10",
//										"h": "10",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "Off",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"error\"]",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "6",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HTGLS5VD1",
//									"attrs": {
//										"1G9E4JGMM0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HTGM08PN3",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HTGM08PN4",
//													"attrs": {
//														"y": {
//															"type": "length",
//															"valText": "0"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9E4JGMM0",
//											"faceTagName": "focus"
//										},
//										"1G9E4JL3E0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HTGM08PN5",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HTGM08PN6",
//													"attrs": {
//														"y": {
//															"type": "length",
//															"valText": "3"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9E4JL3E0",
//											"faceTagName": "blur"
//										},
//										"1HTGM1FRK0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HTGM22FI8",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HTGM22FI9",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HTGM1FRK0",
//											"faceTagName": "mark"
//										},
//										"1HTGM1TU00": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HTGM22FI10",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HTGM22FI11",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HTGM1TU00",
//											"faceTagName": "!mark"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HTGLS5VD2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HTGLS5VD3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1G9E42NEU9",
//					"attrs": {
//						"1G9E4J7CS0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1G9E4V44M33",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G9E4V44M34",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1G9E4J7CS0",
//							"faceTagName": "over"
//						},
//						"1G9E4JARP0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1G9E4V44M35",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G9E4V44M36",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1G9E4JARP0",
//							"faceTagName": "down"
//						},
//						"1G9E4JDSC0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1G9ITCN1V6",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G9ITCN1V7",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1G9E4JDSC0",
//							"faceTagName": "gray"
//						},
//						"1G9E4J4FE0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1G9IUTKOP4",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G9IUTKOP5",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1G9E4J4FE0",
//							"faceTagName": "up"
//						},
//						"1G9E4JGMM0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HTGM08PN7",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HTGM08PN8",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1G9E4JGMM0",
//							"faceTagName": "focus"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1G9E42NEU10",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1HTGM08PN9",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1G9E42NEU11",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"enable": "false",
//				"drag": "false",
//				"innerLayout": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"face": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"marginL": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"marginR": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"marginT": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"marginB": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"paddingL": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"paddingT": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"paddingR": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"paddingB": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"attach": {
//					"type": "bool",
//					"valText": "false"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}