//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {PathNaviView} from "/@StdUI/ui/PathNaviView.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
/*#{1G9HATHL00StartDoc*/
import {tabFS} from "/@tabos";
import pathLib from "/@path";
/*}#1G9HATHL00StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let TBXPath=function(app,view){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let boxPath;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1G9HATHL07LocalVals*/
	let appPrj=null;
	let dataDocs=null;
	let isFocused=0;
	//$ln=VFACT.lanCode;
	/*}#1G9HATHL07LocalVals*/
	
	/*#{1G9HATHL07PreState*/
	/*}#1G9HATHL07PreState*/
	/*#{1G9HATHL07PostState*/
	/*}#1G9HATHL07PostState*/
	cssVO={
		"hash":"1G9HATHL07",nameHost:true,
		"type":"hud","x":0,"y":0,"w":"FW","h":"FH","autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
		children:[
			{
				"hash":"1IA36OELE0",
				"type":PathNaviView({"path":"","dirOnly":false,"multiSelect":false,"allowDrop":false,"cacheSub":false,"prescanSub":false,"sort":"Name","filter":null},{"fontSize":txtSize.smallPlus,"allowDrop":true,"allowDrag":false,"height":24,"iconSize":20,"color":cfgColor.fontBody,"checkBox":false,"expandBtn":true,"indentSize":15,"fileSize":false,"fileMenu":false}),
				"id":"BoxPath","x":0,"y":0,"w":"100%","h":"100%",
			},
			{
				"hash":"1G9IS0IS20",
				"type":"hud","id":"BoxToolBtn","x":0,"y":0,"w":"100%","h":30,"autoLayout":true,"padding":[0,5,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"contentLayout":"flex-x","itemsAlign":1,
				children:[
					{
						"hash":"1I9VDSFHL0",
						"type":BtnIcon(cfgColor.fontBody,24,0,appCfg.sharedAssets+"/fileadd.svg",null),"id":"BtnNewDoc","position":"relative","x":0,"y":0,"padding":1,"margin":[0,0,0,3],
						"tip":(($ln==="CN")?("新建文档"):("New doc")),
						/*#{1I9VDSFHL0Codes*/
						OnClick(){
							self.newDoc();
						}
						/*}#1I9VDSFHL0Codes*/
					},
					{
						"hash":"1I9VE34PC0",
						"type":BtnIcon(cfgColor.fontBody,24,0,appCfg.sharedAssets+"/folder.svg",null),"id":"BtnOpenDoc","position":"relative","x":0,"y":0,"padding":1,
						"tip":(($ln==="CN")?("打开文档"):("Open doc")),
						/*#{1I9VE34PC0Codes*/
						OnClick(){
							self.openDoc();
						}
						/*}#1I9VE34PC0Codes*/
					},
					{
						"hash":"1I9VE6OS00",
						"type":BtnIcon(cfgColor.fontBody,24,0,appCfg.sharedAssets+"/save.svg",null),"id":"BtnSave","position":"relative","x":0,"y":0,"padding":1,
						"tip":(($ln==="CN")?("保存文档"):("Save doc")),
						/*#{1I9VE6OS00Codes*/
						OnClick(){
							self.doSave();
						}
						/*}#1I9VE6OS00Codes*/
					},
					{
						"hash":"1I9VEAQ4S0",
						"type":BtnIcon(cfgColor.fontBody,24,0,appCfg.sharedAssets+"/run.svg",null),"id":"BtnRun","position":"relative","x":0,"y":0,"padding":1,
						"tip":(($ln==="CN")?("运行项目"):("Run project")),
						/*#{1I9VEAQ4S0Codes*/
						OnClick(){
							app.runPrj(this);
						}
						/*}#1I9VEAQ4S0Codes*/
					},
					{
						"hash":"1I05E59LE0",
						"type":"hud","position":"relative","x":0,"y":0,"w":10,"h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","flex":true,
					},
					{
						"hash":"1I9VEE3GC0",
						"type":BtnIcon(cfgColor.fontBody,24,0,appCfg.sharedAssets+"/settings.svg",null),"id":"BtnCfg","position":"relative","x":0,"y":0,"padding":1,
						"tip":(($ln==="CN")?("项目设置"):("Project settings")),
						/*#{1I9VEE3GC0Codes*/
						OnClick(){
							app.cfgPrj(this);
						}
						/*}#1I9VEE3GC0Codes*/
					}
				],
			}
		],
		/*#{1G9HATHL07ExtraCSS*/
		/*}#1G9HATHL07ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			self=this;
			boxPath=self.BoxPath;
			/*#{1G9HATHL07Create*/
			self.toolBtnBox=self.BoxToolBtn;
			self.toolBtnBox.hold();
			self.removeChild(self.toolBtnBox);
			self.toolBtnBox.h="FH";
			self.init();
			/*}#1G9HATHL07Create*/
		},
		/*#{1G9HATHL07EndCSS*/
		/*}#1G9HATHL07EndCSS*/
	};
	/*#{1G9HATHL07PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.init=function(){
		let prjCfg;
		appPrj=app.prj;
		dataDocs=appPrj.docs;
		if(appPrj.path){
			boxPath.initRootPath(appPrj.path,true);
			//boxPath.addRootPath(appPrj.path,true);
		}
		boxPath.onNotify("FocusPath",self.OnFocusPath);
		boxPath.onNotify("OpenFile",self.OnOpenFile);
		dataDocs.on("FocusDoc",self.OnFocusDoc);
		prjCfg=appPrj.prjConfig;
		if(prjCfg){
			self.BtnRun.enable=!!prjCfg.run;
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.newDoc=function(){
		app.showDlg("/@StdUI/ui/DlgMenu.js",{
			hud:self.BtnNewDoc,
			y:self.BtnNewDoc.h,
			items:[
				{text:(($ln==="CN")?("带路径的新文档"):/*EN*/("New doc with path")),code:"create"},
				{text:(($ln==="CN")?("没有路径的空文本文件"):/*EN*/("Empty text file without path")),code:"empty"},
			],
			callback(item){
				if(!item){
					return;
				}
				if(item.code==="create"){
					return self.createNewDoc();
				}else{
					dataDocs.newEmptyDoc(".txt").then(doc=>{
						dataDocs.focusDoc(doc);
					});
				}
			}
		});
	};
	
	//------------------------------------------------------------------------
	cssVO.createNewDoc=function(){
		let hotDoc,path,doc;
		hotDoc=dataDocs.hotDoc;
		if(hotDoc){
			path=pathLib.dirname(hotDoc.path);
		}else{
			path="/";
		}
		app.showDlg("/@StdUI/ui/DlgFile.js",{
			mode:"save",
			path:path,
			buttonText:(($ln==="CN")?("创建"):/*EN*/("Create")),
			options:{
				multiSelect:0,
				preview:1,
			},
			callback:async function(filePath){
				if(!filePath){
					return;
				}
				try{
					await tabFS.writeFile(filePath,"","utf8");
					doc=await dataDocs.openDoc(filePath);
					if(doc){
						dataDocs.focusDoc(doc);
					}
				}catch(e){
				}
			}
		});
	};
	
	//------------------------------------------------------------------------
	cssVO.openDoc=function(){
		let path=appPrj.path;
		app.showDlg("/@StdUI/ui/DlgFile.js",{
			mode:"open",
			path:path,
			buttonText:(($ln==="CN")?("打开"):/*EN*/("Open")),
			options:{
				multiSelect:0,
				preview:1,
			},
			callback:async function(filePath){
				let doc;
				if(!filePath){
					return;
				}
				try{
					doc=await dataDocs.openDoc(filePath);
					if(doc){
						dataDocs.focusDoc(doc);
					}
				}catch(e){
					console.error("Import UI-Component file error:");
					console.error(e);
				}
			}
		});
	};
	
	//------------------------------------------------------------------------
	cssVO.OnShow=function(){
		isFocused=1;
	};
	
	//------------------------------------------------------------------------
	cssVO.OnHide=function(){
		isFocused=0;
	};
	
	//------------------------------------------------------------------------
	cssVO.OnFocusDoc=function(doc){
		boxPath.showPath(doc.path,true);
	};
	
	//------------------------------------------------------------------------
	cssVO.OnFocusPath=async function(){
		let entry,doc;
		entry=boxPath.hotEntry;
		if(!entry){
			return;
		}
		doc=await dataDocs.openDoc(entry.path,true);
		if(doc){
			dataDocs.focusDoc(doc);
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.OnOpenFile=async function(){
		let entry,doc;
		entry=boxPath.hotEntry;
		if(!entry){
			return;
		}
		doc=dataDocs.getDoc(entry.path);
		if(doc.tempOpen){
			dataDocs.openDoc(entry.path,false);
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.doSave=function(){
		app.mainUI.doSaveDoc();
	};
	/*}#1G9HATHL07PostCSSVO*/
	return cssVO;
};
/*#{1G9HATHL07ExCodes*/
TBXPath.tbxCodeName="Path";
TBXPath.tbxTip=(($ln==="CN")?("项目文件"):("Project Files"));
TBXPath.tbxIcon=appCfg.sharedAssets+"/folder.svg";
TBXPath.tbxIconPad=2;
/*}#1G9HATHL07ExCodes*/


/*#{1G9HATHL00EndDoc*/
/*}#1G9HATHL00EndDoc*/

export default TBXPath;
export{TBXPath};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1G9HATHL00",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1G9HATHL01",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1G9HATHL02",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1H7HUT8V30",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1G9HATHL03",
//			"attrs": {
//				"app": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"view": {
//					"type": "auto",
//					"valText": "null"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1G9HATHL04",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1G9HATHL05",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "VFACT document",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1G9HATHL06",
//			"attrs": {}
//		},
//		"mockupStates": {
//			"jaxId": "1I05E6FAB0",
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1G9HATHL07",
//			"attrs": {
//				"properties": {
//					"jaxId": "1G9HATHL08",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "\"FW\"",
//						"h": "\"FH\"",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "true",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "[0,0,0,0]",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "\"\"",
//						"styleClass": ""
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "Gear/@StdUI/ui/PathNaviView.js",
//							"jaxId": "1IA36OELE0",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1IA36OSF10",
//									"attrs": {
//										"options": {
//											"jaxId": "1IA36OSF11",
//											"attrs": {
//												"path": "",
//												"dirOnly": "false",
//												"multiSelect": "false",
//												"allowDrop": "false",
//												"cacheSub": "false",
//												"prescanSub": "false",
//												"sort": "Name",
//												"filter": "null"
//											}
//										},
//										"lineOpts": {
//											"jaxId": "1IA36OSF12",
//											"attrs": {
//												"fontSize": "#txtSize.smallPlus",
//												"allowDrop": "true",
//												"allowDrag": "false",
//												"height": "24",
//												"iconSize": "20",
//												"color": "#cfgColor.fontBody",
//												"checkBox": "false",
//												"expandBtn": "true",
//												"indentSize": "15",
//												"fileSize": "false",
//												"fileMenu": "false"
//											}
//										}
//									}
//								},
//								"properties": {
//									"jaxId": "1IA36OSF13",
//									"attrs": {
//										"type": "#null#>PathNaviView({\"path\":\"\",\"dirOnly\":false,\"multiSelect\":false,\"allowDrop\":false,\"cacheSub\":false,\"prescanSub\":false,\"sort\":\"Name\",\"filter\":null},{\"fontSize\":txtSize.smallPlus,\"allowDrop\":true,\"allowDrag\":false,\"height\":24,\"iconSize\":20,\"color\":cfgColor.fontBody,\"checkBox\":false,\"expandBtn\":true,\"indentSize\":15,\"fileSize\":false,\"fileMenu\":false})",
//										"id": "BoxPath",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"display": "On",
//										"face": "",
//										"w": "100%",
//										"h": "100%"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1IA36OSF14",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1IA36OSF15",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IA36OSF16",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true",
//								"containerSlots": {
//									"jaxId": "1IA36OSF17",
//									"attrs": {}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1G9IS0IS20",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G9IS16LV0",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxToolBtn",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "true",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,0]",
//										"padding": "[0,5,0,0]",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "\"\"",
//										"styleClass": "",
//										"contentLayout": "Flex X",
//										"itemsAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1I9VDSFHL0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1I9VDVEVB0",
//													"attrs": {
//														"style": "#cfgColor.fontBody",
//														"w": "24",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/fileadd.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1I9VDVEVB1",
//													"attrs": {
//														"type": "#null#>BtnIcon(cfgColor.fontBody,24,0,appCfg.sharedAssets+\"/fileadd.svg\",null)",
//														"id": "BtnNewDoc",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"padding": "1",
//														"margin": "[0,0,0,3]"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I9VDVEVB2",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1I9VDVEVB3",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I9VDVEVB4",
//													"attrs": {
//														"tip": {
//															"type": "string",
//															"valText": "新建文档",
//															"localize": {
//																"EN": "New doc",
//																"CN": "新建文档"
//															},
//															"localizable": true
//														}
//													}
//												},
//												"mockup": "false",
//												"codes": "true",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1I9VDVEVB5",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1I9VE34PC0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1I9VE34PC1",
//													"attrs": {
//														"style": "#cfgColor.fontBody",
//														"w": "24",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/folder.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1I9VE34PC2",
//													"attrs": {
//														"type": "#null#>BtnIcon(cfgColor.fontBody,24,0,appCfg.sharedAssets+\"/folder.svg\",null)",
//														"id": "BtnOpenDoc",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"padding": "1",
//														"margin": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I9VE34PC3",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1I9VE34PC4",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I9VE34PC5",
//													"attrs": {
//														"tip": {
//															"type": "string",
//															"valText": "打开文档",
//															"localize": {
//																"EN": "Open doc",
//																"CN": "打开文档"
//															},
//															"localizable": true
//														}
//													}
//												},
//												"mockup": "false",
//												"codes": "true",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1I9VE34PC6",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1I9VE6OS00",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1I9VE6OS01",
//													"attrs": {
//														"style": "#cfgColor.fontBody",
//														"w": "24",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/save.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1I9VE6OS10",
//													"attrs": {
//														"type": "#null#>BtnIcon(cfgColor.fontBody,24,0,appCfg.sharedAssets+\"/save.svg\",null)",
//														"id": "BtnSave",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"padding": "1",
//														"margin": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I9VE6OS11",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1I9VE6OS12",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I9VE6OS13",
//													"attrs": {
//														"tip": {
//															"type": "string",
//															"valText": "保存文档",
//															"localize": {
//																"EN": "Save doc",
//																"CN": "保存文档"
//															},
//															"localizable": true
//														}
//													}
//												},
//												"mockup": "false",
//												"codes": "true",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1I9VE6OS14",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1I9VEAQ4S0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1I9VEAQ4S1",
//													"attrs": {
//														"style": "#cfgColor.fontBody",
//														"w": "24",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/run.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1I9VEAQ4S2",
//													"attrs": {
//														"type": "#null#>BtnIcon(cfgColor.fontBody,24,0,appCfg.sharedAssets+\"/run.svg\",null)",
//														"id": "BtnRun",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"padding": "1",
//														"margin": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I9VEAQ4S3",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1I9VEAQ4S4",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I9VEAQ4S5",
//													"attrs": {
//														"tip": {
//															"type": "string",
//															"valText": "运行项目",
//															"localize": {
//																"EN": "Run project",
//																"CN": "运行项目"
//															},
//															"localizable": true
//														}
//													}
//												},
//												"mockup": "false",
//												"codes": "true",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1I9VEAQ4T0",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1I05E59LE0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I05E6FAB1",
//													"attrs": {
//														"type": "hud",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "10",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"flex": "true"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I05E6FAB2",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1I05E6FAB3",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I05E6FAB4",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1I9VEE3GC0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1I9VEE3GC1",
//													"attrs": {
//														"style": "#cfgColor.fontBody",
//														"w": "24",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/settings.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1I9VEE3GC2",
//													"attrs": {
//														"type": "#null#>BtnIcon(cfgColor.fontBody,24,0,appCfg.sharedAssets+\"/settings.svg\",null)",
//														"id": "BtnCfg",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"padding": "1",
//														"margin": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I9VEE3GC3",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1I9VEE3GC4",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I9VEE3GC5",
//													"attrs": {
//														"tip": {
//															"type": "string",
//															"valText": "项目设置",
//															"localize": {
//																"EN": "Project settings",
//																"CN": "项目设置"
//															},
//															"localizable": true
//														}
//													}
//												},
//												"mockup": "false",
//												"codes": "true",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1I9VEE3GC6",
//													"attrs": {}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1G9IS16LV1",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1G9IS16LV2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H7HUT8V48",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1G9HATHL09",
//					"attrs": {}
//				},
//				"functions": {
//					"jaxId": "1G9HATHL010",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1H7HUT8V411",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1G9HATHL011",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"innerLayout": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"face": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"marginL": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"marginR": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"marginT": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"marginB": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"paddingL": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"paddingT": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"paddingR": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"paddingB": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"attach": {
//					"type": "bool",
//					"valText": "false"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}