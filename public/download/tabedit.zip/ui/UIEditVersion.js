//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
/*#{1GDLSND480StartDoc*/
import {tabFS} from "/@tabos";
import {AddOn} from "../data/AddOn.js";
import {makeObjEventEmitter,makeNotify} from "/@events";
let CodeMirror=window.CodeMirror;
/*}#1GDLSND480StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let UIEditVersion=function(app,mode,codeText,cfgVO,dataDoc){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let txtLeftDoc,btnSaveLeft,txtMidDoc,btnSaveMid,btnSaveRight;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let headerH=20;
	
	/*#{1GDLSND495LocalVals*/
	let appPrj,dataDocs;
	let cm,cmDoc,leftDoc,midDoc,rightDoc,docExt;
	let editConfig=null;
	let aboutRefresh=0;
	let targetLine=-1;
	let setupPms=null;
	let initPms=null;
	let boxCode=null;
	let editMode="";
	let mergeView=null;
	let midCM=null;
	let leftDiffView=null
	let leftCM=null;
	let rightDiffView=null;
	let rightCM=null;
	
	let leftChanged=false;
	let midChanged=false;
	let rightChanged=false;
	
	appPrj=app.prj;
	if(appPrj){
		dataDocs=appPrj.docs;
	}else{
		dataDocs=app.docs;
	}
	/*}#1GDLSND495LocalVals*/
	
	/*#{1GDLSND495PreState*/
	/*}#1GDLSND495PreState*/
	/*#{1GDLSND495PostState*/
	/*}#1GDLSND495PostState*/
	cssVO={
		"hash":"1GDLSND495",nameHost:true,
		"type":"view","x":0,"y":0,"w":"FW","h":"FH","autoLayout":true,"display":"On","overflow":1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
		children:[
			{
				"hash":"1I9V1LUA20",
				"type":"box","id":"BoxHeader","x":0,"y":0,"w":"100%","h":30,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["body"],
				"border":[0,0,1,0],"borderColor":cfgColor["fontBody"],"contentLayout":"flex-x",
				children:[
					{
						"hash":"1I9V1NNS90",
						"type":"hud","id":"BoxLeftHeader","position":"relative","x":0,"y":0,"w":"50%","h":"100%","padding":[0,0,0,3],"minW":"","minH":"","maxW":"","maxH":"",
						"styleClass":"","contentLayout":"flex-x","itemsAlign":1,
						children:[
							{
								"hash":"1I9V5UC990",
								"type":BtnIcon("fontSuccess",24,0,appCfg.sharedAssets+"/check_fat.svg",cfgColor.success),"id":"BtnCheck","position":"relative","x":0,"y":0,"padding":2,
								"margin":[0,3,0,0],"corner":6,
								/*#{1I9V5UC990Codes*/
								tip:(($ln==="CN")?("解决冲突"):/*EN*/("Resolve conflict")),
								OnClick(){
									self.resolveConflict();
								}
								/*}#1I9V5UC990Codes*/
							},
							{
								"hash":"1I9V1TA4F0",
								"type":"box","position":"relative","x":0,"y":0,"w":1,"h":">calc(100% - 6px)","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.lineBodyLit,
							},
							{
								"hash":"1I9V1U0AP0",
								"type":"box","id":"IconLeft","position":"relative","x":0,"y":0,"w":24,"h":24,"margin":[0,2,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
								"background":cfgColor.success,"maskImage":appCfg.sharedAssets+"/recent.svg",
							},
							{
								"hash":"1I9V1V8TQ0",
								"type":"text","id":"TxtLeftDoc","position":"relative","x":0,"y":0,"w":"","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor.fontBodySub,
								"text":(($ln==="CN")?("基础版本"):("Base Version")),"fontSize":txtSize.smallMid,"fontWeight":"bold","fontStyle":"normal","textDecoration":"","alignV":1,
							},
							{
								"hash":"1I9V5O9700",
								"type":BtnIcon("front",26,0,appCfg.sharedAssets+"/save.svg",null),"id":"BtnSaveLeft","position":"relative","x":0,"y":0,"padding":2,
								/*#{1I9V5O9700Codes*/
								OnClick(evt){
									self.saveLeft();
								}
								/*}#1I9V5O9700Codes*/
							}
						],
					},
					{
						"hash":"1I9V21DV00",
						"type":"hud","id":"BoxMidHeader","position":"relative","x":0,"y":0,"w":100,"h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","flex":true,
						"contentLayout":"flex-x","itemsAlign":1,
						children:[
							{
								"hash":"1I9V23GCO0",
								"type":"box","position":"relative","x":0,"y":0,"w":1,"h":">calc(100% - 6px)","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.lineBodyLit,
							},
							{
								"hash":"1I9V244ED0",
								"type":"box","id":"IconMid","position":"relative","x":0,"y":0,"w":24,"h":24,"autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
								"background":cfgColor.primary,"maskImage":appCfg.sharedAssets+"/edit.svg",
							},
							{
								"hash":"1I9V253560",
								"type":"text","id":"TxtMidDoc","position":"relative","x":0,"y":0,"w":"","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor.fontBodySub,
								"text":(($ln==="CN")?("当前版本"):("Current Version")),"fontSize":txtSize.smallMid,"fontWeight":"bold","fontStyle":"normal","textDecoration":"","alignV":1,
							},
							{
								"hash":"1I9V5SF3L0",
								"type":BtnIcon("front",26,0,appCfg.sharedAssets+"/save.svg",null),"id":"BtnSaveMid","position":"relative","x":0,"y":0,"padding":2,
								/*#{1I9V5SF3L0Codes*/
								OnClick(evt){
									self.saveMid();
								}
								/*}#1I9V5SF3L0Codes*/
							}
						],
					},
					{
						"hash":"1I9V22H8F0",
						"type":"hud","id":"BoxRightHeader","position":"relative","x":0,"y":0,"w":"33%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						"contentLayout":"flex-x","itemsAlign":1,
						children:[
							{
								"hash":"1I9V23I920",
								"type":"box","position":"relative","x":0,"y":0,"w":1,"h":">calc(100% - 6px)","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.lineBodyLit,
							},
							{
								"hash":"1I9V28NSL0",
								"type":"box","id":"IconRIght","position":"relative","x":0,"y":0,"w":24,"h":24,"autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
								"background":cfgColor.error,"maskImage":appCfg.sharedAssets+"/cloud.svg",
							},
							{
								"hash":"1I9V297070",
								"type":"text","id":"TxtRightDoc","position":"relative","x":0,"y":0,"w":"","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor.fontBodySub,
								"text":(($ln==="CN")?("云端代码库版本"):("Cloud Repo Version")),"fontSize":txtSize.smallMid,"fontWeight":"bold","fontStyle":"normal","textDecoration":"",
								"alignV":1,
							},
							{
								"hash":"1I9V5SP4E0",
								"type":BtnIcon("front",26,0,appCfg.sharedAssets+"/save.svg",null),"id":"BtnSaveRight","position":"relative","x":0,"y":0,"padding":2,
								/*#{1I9V5SP4E0Codes*/
								OnClick(evt){
									self.saveRight();
								}
								/*}#1I9V5SP4E0Codes*/
							}
						],
					}
				],
			},
			{
				"hash":"1GDLUH7F90",
				"type":"hud","id":"BoxCode","x":0,"y":30,"w":"100%","h":">calc(100% - 30px)","autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				/*#{1GDLUH7F90Codes*/
				traceSize:1,
				OnSize(){
					if(self){
						self.adjustSize();
					}
				}
				/*}#1GDLUH7F90Codes*/
			}
		],
		/*#{1GDLSND495ExtraCSS*/
		/*}#1GDLSND495ExtraCSS*/
		faces:{
			"editChange":{
				/*BtnSaveLeft*/"#1I9V5O9700":{
					"display":1,"enable":false
				},
				/*BoxRightHeader*/"#1I9V22H8F0":{
					"display":0
				}
			},"editConflict":{
				/*BoxLeftHeader*/"#1I9V1NNS90":{
					"w":"33%"
				},
				/*BoxRightHeader*/"#1I9V22H8F0":{
					"display":1
				},
				/*IconRIght*/"#1I9V28NSL0":{
					"display":1
				}
			},"editCompare":{
				/*BtnCheck*/"#1I9V5UC990":{
					"display":0
				},
				/*IconLeft*/"#1I9V1U0AP0":{
					"maskImage":appCfg.sharedAssets+"/file.svg","background":cfgColor["front"]
				},
				/*IconMid*/"#1I9V244ED0":{
					"background":cfgColor["fontBody"],"maskImage":appCfg.sharedAssets+"/file.svg"
				},
				/*BoxRightHeader*/"#1I9V22H8F0":{
					"display":0
				}
			}
		},
		OnCreate:function(){
			self=this;
			txtLeftDoc=self.TxtLeftDoc;btnSaveLeft=self.BtnSaveLeft;txtMidDoc=self.TxtMidDoc;btnSaveMid=self.BtnSaveMid;btnSaveRight=self.BtnSaveRight;
			/*#{1GDLSND495Create*/
			boxCode=self.BoxCode;
			if(dataDoc.fileExt===".compare"){
				leftDoc=dataDoc.subDocs[0];
				midDoc=dataDoc.subDocs[1];
				self.showFace("editCompare");
				editMode="Compare";
			}else if(dataDoc.subDocs.length>1){//Conflict
				leftDoc=dataDoc.subDocs[1];
				midDoc=dataDoc.subDocs[0];
				rightDoc=dataDoc;
				self.showFace("editConflict");
				editMode="Conflict";
			}else{//Base Version Changes:
				leftDoc=dataDoc;
				midDoc=dataDoc.subDocs[0];
				self.showFace("editChange");
				editMode="Change";
			}
			docExt=midDoc.fileExt.toLowerCase();
			makeNotify(self);
			makeObjEventEmitter(self);
			/*}#1GDLSND495Create*/
		},
		/*#{1GDLSND495EndCSS*/
		/*}#1GDLSND495EndCSS*/
	};
	/*#{1GDLSND495PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.init=async function(){
		if(cm){
			return;
		}
		await VFACT.appendScript("/@codemirror/extern/diff_match_patch.js");
		await VFACT.appendScript("/@codemirror/addon/merge.js");
		switch(docExt){
			case "js":
			case "mjs":
			case ".js":
			case ".mjs":
				mode="javascript";
				await VFACT.appendScript("/@codemirror/mode/javascript.js");
				await VFACT.appendCSS("/@codemirror/mode/javascript.css");
				break;
			case "htm":
			case "html":
			case ".htm":
			case ".html":
				mode="text/html";
				await VFACT.appendCSS("/@codemirror/mode/javascript.css");
	
				await VFACT.appendScript("/@codemirror/mode/css.js");
				await VFACT.appendScript("/@codemirror/mode/javascript.js");
				await VFACT.appendScript("/@codemirror/mode/xml.js");
				await VFACT.appendScript("/@codemirror/mode/htmlmixed.js");
				break;
			case "markdown":
			case "md":
			case ".md":
				mode="text/x-markdown";
				await VFACT.appendScript("/@codemirror/mode/markdown.js");
				break;
			case "json":
			case ".json":
				mode={name: "javascript", json: true};
				await VFACT.appendCSS("/@codemirror/mode/javascript.css");
				await VFACT.appendScript("/@codemirror/mode/javascript.js");
				break;
			case "css":
			case ".css":
				mode={name: "css"};
				await VFACT.appendCSS("/@codemirror/mode/css.js");
				break;
			case "jsx":
			case ".jsx":
				mode="text/jsx";
				await VFACT.appendCSS("/@codemirror/mode/jsx.js");
				break;
			case ".c":
			case ".cpp":
			case ".h":
			case ".hpp":
			case ".c":
			case ".cpp":
			case ".h":
			case ".hpp":
				mode="text/x-c++src";
				await VFACT.appendCSS("/@codemirror/mode/clike.js");
				break;
			case ".java":
				mode="text/x-java";
				await VFACT.appendCSS("/@codemirror/mode/clike.js");
				break;
			default:
				mode="text";
				break;
		}
		if(editMode==="Compare"){
			self.initCompareMode();
		}else if(editMode==="Change"){
			self.initChangeMode();
		}else if(editMode==="Conflict"){
			self.initConflictMode();
		}
		cm=this.cm=this.mergeView.editor();
		this.cm.on("focus", this.OnCMFocus.bind(this));
		this.cm.on("blur", this.OnCMBlur.bind(this));
		this.cm.on("input", this.OnCMInput.bind(this));
		//this.cm.on("changes", this.OnCMChanges.bind(this));
		this.cm.on("cursorActivity", this.OnCMCursorAct.bind(this));
		cmDoc=this.cmDoc=this.cm.doc;
		cm.uiCodeEditor=this;
		this.dataDoc=dataDoc;
		
		midCM=mergeView.edit;
		leftDiffView=mergeView.left;
		rightDiffView=mergeView.right;
		leftCM=leftDiffView?leftDiffView.orig:null;
		rightCM=rightDiffView?rightDiffView.orig:null;
		
		if(leftCM){
			leftCM.on("changes", this.OnLeftCMChanges.bind(this));
		}
		if(rightCM){
			rightCM.on("changes", this.OnRightCMChanges.bind(this));
		}
		if(midCM){
			midCM.on("changes", this.OnMidCMChanges.bind(this));
		}
		
		//Emit event
		this.emit("InitDone");
		this.emitNotify("InitDone");
	};
	
	//------------------------------------------------------------------------
	cssVO.initCompareMode=function(){
		let leftText,midText,h;
		leftText=leftDoc.getDocText();
		midText=midDoc.getDocText();
		this.mergeView = mergeView=CodeMirror.MergeView(boxCode.webObj, {
			value: midText,
			origLeft: leftText,
			mode: mode,
			indentUnit: 4,
			indentWithTabs: true,
			lineNumbers: true,
			rulers: [{color: "#CCC", column: 78, lineStyle: "dashed"}],
			styleActiveLine: true,
			highlightDifferences: true,
			connect: true,
			allowEditingOriginals:true,
		});
		
		self.adjustSize();
		self.TxtLeftDoc.text=leftDoc.path;
		self.TxtMidDoc.text=midDoc.path;
		btnSaveLeft.enable=false;
		btnSaveMid.enable=false;
		btnSaveRight.enable=false;
	};
	
	//------------------------------------------------------------------------
	cssVO.initChangeMode=function(){
		let leftText,midText,h;
		leftText=leftDoc.getDocText();
		midText=midDoc.getDocText();
		this.mergeView = mergeView=CodeMirror.MergeView(boxCode.webObj, {
			value: midText,
			origLeft: leftText,
			mode: mode,
			indentUnit: 4,
			indentWithTabs: true,
			lineNumbers: true,
			rulers: [{color: "#CCC", column: 78, lineStyle: "dashed"}],
			styleActiveLine: true,
			highlightDifferences: true,
			connect: true,
		});
		
		self.adjustSize();
	
		self.TxtLeftDoc.text=leftDoc.versionName;
		self.TxtLeftDoc.color=cfgColor.success;
		self.TxtMidDoc.text=midDoc.name;
		self.TxtMidDoc.color=cfgColor.primary;
	};
	
	//------------------------------------------------------------------------
	cssVO.initConflictMode=function(){
		let leftText,midText,rightText,h;
		leftText=leftDoc.getDocText();
		midText=midDoc.getDocText();
		rightText=rightDoc.getDocText();
		this.mergeView = CodeMirror.MergeView(boxCode.webObj, {
			value: midText,
			origLeft: leftText,
			origRight: rightText,
			mode: mode,
			indentUnit: 4,
			indentWithTabs: true,
			lineNumbers: true,
			rulers: [{color: "#CCC", column: 78, lineStyle: "dashed"}],
			styleActiveLine: true,
			highlightDifferences: true,
			connect: true,
		});
		
		self.adjustSize();
	
		self.TxtLeftDoc.text=leftDoc.versionName;
		self.TxtLeftDoc.color=cfgColor.success;
		self.TxtMidDoc.text=midDoc.name;
		self.TxtMidDoc.color=cfgColor.primary;
		self.TxtRightDoc.text=rightDoc.versionName;
		self.TxtRightDoc.color=cfgColor.error;
	};
	
	//------------------------------------------------------------------------
	cssVO.adjustSize=function(){
		let h,mergeView,view;
		h=boxCode.clientHeight;
		mergeView=this.mergeView;
		if(!mergeView){
			return;
		}
		mergeView.editor().setSize(null, h);
		view=mergeView.leftOriginal();
		if(view){
			view.setSize(null, h);
		}
		view=mergeView.rightOriginal();
		if(view){
			view.setSize(null, h);
		}
		mergeView.wrap.style.height = h+"px";
	};
	
	//------------------------------------------------------------------------
	cssVO.applyCfg=function(opts){
		opts=opts||editConfig;
		if(cm){
			cm.setOption("indentUnit",opts["IndentSize"]);		
			cm.setOption("tabSize",opts["TabSize"]);		
			cm.setOption("indentWithTabs",opts["UseTab"]);
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.setEditText=function(text,undo=true){
		let sinfo,cpos;
		codeText=text;
		if(cm){
			sinfo=cm.getScrollInfo();
			cpos=cmDoc.getCursor();
			if(undo){
				cmDoc.setValue(codeText);
			}else{
				cmDoc.setValueNoUndo(codeText);
			}
			self.emit("DocReplace");
			cmDoc.setCursor(cpos);
			cm.scrollTo(sinfo.left,sinfo.top);
			if(!cm.hasFocus()){
				aboutRefresh=1;
			}
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.getEditText=function(slot){
		if(slot==="left" && leftCM){
			return leftCM.getValue();
		}
		if(slot==="right" && rightCM){
			return rightCM.getValue();
		}
		if(cmDoc){
			codeText=cmDoc.getValue();
		}
		return codeText;
	};
	
	//------------------------------------------------------------------------
	cssVO.getEditVersion=function(){
		if(!cmDoc){
			return 0;
		}
		return cmDoc.changeGeneration();
	};
	
	//------------------------------------------------------------------------
	cssVO.focus=function(){
		if(cm){
			cm.focus();
			if(aboutRefresh){
				cm.refresh();
				aboutRefresh=0;
			}
		}else{
			if(!initPms){
				initPms=self.init();
			}
			initPms.then(()=>{
				if(cm){
					cm.focus();
				}
			});
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.blur=function(){
		if(cm){
			cm.blur();
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.gotoLine=function(line){
		if(cmDoc){
			cmDoc.setCursor({line:line-1,ch:0});
			cm.scrollIntoView({line:line-1,ch:0},150);
			targetLine=-1;
		}else{
			targetLine=line;
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.getSelection=function(){
		if(cmDoc){
			return cmDoc.getSelection();
		}
		return "";
	};
	
	//--------------------------------------------------------------------
	cssVO.replaceSelection=function(text,select){
		if(cmDoc){
			cmDoc.replaceSelection(text,select);
		}
	};
		
	//------------------------------------------------------------------------
	cssVO.getCursorPos=function(){
		return {line:0,ch:0};
	};
	
	//------------------------------------------------------------------------
	cssVO.getCursorIndex=function(){
		return 0;
	};
	
	//------------------------------------------------------------------------
	cssVO.getSelectionRange=function(){
		return [0,0];
	};
	
	//------------------------------------------------------------------------
	cssVO.saveLeft=async function(){
		let codeText,path,cmpVO;
		path=leftDoc.path;
		codeText=leftCM.getValue();
		await tabFS.writeFile(path,codeText);
		cmpVO=dataDoc.compareVO;
		if(cmpVO && cmpVO.OnSave){
			cmpVO.OnSave();
		}
		btnSaveLeft.enable=false;
		leftChanged=false;
		if(!leftChanged && !rightChanged && !midChanged){
			dataDoc.emitNotify("Saved");
			dataDoc.docs.emit("DocSaved",this);
			dataDoc.compareChanged=false;
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.saveMid=async function(){
		let codeText,path,cmpVO;
		path=midDoc.path;
		codeText=cmDoc.getValue();
		await tabFS.writeFile(path,codeText);
		cmpVO=dataDoc.compareVO;
		if(cmpVO && cmpVO.OnSave){
			cmpVO.OnSave();
		}
		btnSaveMid.enable=false;
		midChanged=false;
		if(!leftChanged && !rightChanged && !midChanged){
			dataDoc.emitNotify("Saved");
			dataDoc.docs.emit("DocSaved",this);
			dataDoc.compareChanged=false;
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.saveRight=async function(){
		let codeText,path,cmpVO;
		path=rightDoc.path;
		codeText=rightCM.getValue();
		await tabFS.writeFile(path,codeText);
		cmpVO=dataDoc.compareVO;
		if(cmpVO && cmpVO.OnSave){
			cmpVO.OnSave();
		}
		btnSaveRight.enable=false;
		rightChanged=false;
		if(!leftChanged && !rightChanged && !midChanged){
			dataDoc.emitNotify("Saved");
			dataDoc.docs.emit("DocSaved",this);
			dataDoc.compareChanged=false;
		}
	};
	
	//************************************************************************
	//Work with cody
	//************************************************************************
	{
		//--------------------------------------------------------------------
		cssVO.peekUndoAction=function(){
			return null;
		};
		
		//--------------------------------------------------------------------
		cssVO.peekRedoAction=function(){
			return null;
		};
		
		//--------------------------------------------------------------------
		cssVO.undo=function(){
			cmDoc.undo();
		};
	
		//--------------------------------------------------------------------
		cssVO.redo=function(){
			cmDoc.redo();
		};
		
		//--------------------------------------------------------------------
		cssVO.addCodyEditAction=function(action){
			//Do nothing...
		};
	}	
	
	//************************************************************************
	//Code mirror events:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		cssVO.OnCMInput=function(){
			self.emit("Input");
			self.emitNotify("Input");
		};
	
		//--------------------------------------------------------------------
		cssVO.OnLeftCMChanges=function(){
			leftChanged=true;
			self.emit("Input");
			self.emitNotify("Input");
			self.emit("Change");
			self.emitNotify("Change");
			dataDoc.emitNotify("Changed");
			btnSaveLeft.enable=true;
			dataDoc.compareChanged=true;
		};
	
		//--------------------------------------------------------------------
		cssVO.OnMidCMChanges=function(){
			midChanged=true;
			self.emit("Input");
			self.emitNotify("Input");
			self.emit("Change");
			self.emitNotify("Change");
			dataDoc.emitNotify("Changed");
			btnSaveMid.enable=true;
			dataDoc.compareChanged=true;
		};
	
		//--------------------------------------------------------------------
		cssVO.OnRightCMChanges=function(){
			rightChanged=true;
			self.emit("Input");
			self.emitNotify("Input");
			self.emit("Change");
			self.emitNotify("Change");
			dataDoc.emitNotify("Changed");
			btnSaveRight.enable=true;
			dataDoc.compareChanged=true;
		};
	
		//--------------------------------------------------------------------
		cssVO.OnCMChanges=function(){
			self.emit("Change");
			self.emitNotify("Change");
		};
	
		//--------------------------------------------------------------------
		cssVO.OnCMCursorAct=function(){
			//TODO: Code this:
		};
	
		//--------------------------------------------------------------------
		cssVO.OnCMFocus=function(){
			self.emit("Focus");
			self.emitNotify("Focus");
		};
	
		//--------------------------------------------------------------------
		cssVO.OnCMBlur=function(){
			self.emit("Blur");
			self.emitNotify("Blur");
		};
	}
	
	//------------------------------------------------------------------------
	cssVO.resolveConflict=function(){
		dataDoc.resolveConflict().then(()=>{
			dataDocs.closeDoc(dataDoc);
		});
	};
	
	//------------------------------------------------------------------------
	//Handle shortcut, only handle "Find"/Replace
	cssVO.handleShortcut=function(cmd){
		if(cmd==="Find"){
			return 1;
		}else if(cmd==="FindNext"){
			return 1;
		}else if(cmd==="FindPre"){
			return 1;
		}
		return 0;
	};
	/*}#1GDLSND495PostCSSVO*/
	cssVO.constructor=UIEditVersion;
	return cssVO;
};
/*#{1GDLSND495ExCodes*/
VFACT.appendCSS("/@codemirror/addon/merge.css");
UIEditVersion.scoreDoc=function(doc){
	let path;
	path=doc.path.toLowerCase();
	if(path.endsWith(".compare")){
		return 100;
	}
	if(path.endsWith(".baseversion")){
		return 100;
	}
	if(path.endsWith(".conflict")){
		return 100;
	}
	return 0;
};
AddOn.regAddOn("DocEditor","VersionEditor",UIEditVersion);
/*}#1GDLSND495ExCodes*/

//----------------------------------------------------------------------------
UIEditVersion.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1GDLSND495PreAISpot*/
	/*}#1GDLSND495PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1GDLSND495PostAISpot*/
	/*}#1GDLSND495PostAISpot*/
	return exposeVO;
};

/*#{1GDLSND480EndDoc*/
/*}#1GDLSND480EndDoc*/

export default UIEditVersion;
export{UIEditVersion};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "UIView",
//	"jaxId": "1GDLSND480",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1GDLSND481",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "800",
//				"screenH": "500",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1GDLSND490",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1H7A1R3OB0",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1GDLSND491",
//			"attrs": {
//				"app": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"mode": {
//					"type": "string",
//					"valText": "\".baseversion\""
//				},
//				"codeText": {
//					"type": "string",
//					"valText": ""
//				},
//				"cfgVO": {
//					"type": "auto",
//					"valText": "{}"
//				},
//				"dataDoc": {
//					"type": "auto",
//					"valText": "null"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1GDLSND492",
//			"attrs": {
//				"headerH": {
//					"type": "int",
//					"valText": "20"
//				}
//			}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1GDLSND493",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "VFACT document",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1GDLSND494",
//			"attrs": {
//				"editChange": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1GDLTFRQJ0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1GDLUH39N0",
//							"attrs": {}
//						}
//					}
//				},
//				"editConflict": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1GDLTGRF60",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1GDLUH39N1",
//							"attrs": {}
//						}
//					}
//				},
//				"editCompare": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IM35DB500",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IM35EQ5Q0",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1I9T5I4DP0",
//			"attrs": {}
//		},
//		"exposeToAI": "true",
//		"descAI": "",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "view",
//			"jaxId": "1GDLSND495",
//			"attrs": {
//				"properties": {
//					"jaxId": "1GDLSND496",
//					"attrs": {
//						"type": "view",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "\"FW\"",
//						"h": "\"FH\"",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "true",
//						"display": "\"On\"",
//						"clip": "On",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "[0,0,0,0]",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "\"\"",
//						"styleClass": ""
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1I9V1LUA20",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I9V2B1R90",
//									"attrs": {
//										"type": "box",
//										"id": "BoxHeader",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"body\"]",
//										"border": "[0,0,1,0]",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor[\"fontBody\"]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"contentLayout": "Flex X"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1I9V1NNS90",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I9V2B1R91",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxLeftHeader",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "50%",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "[0,0,0,3]",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex X",
//														"itemsAlign": "Center"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1I9V5UC990",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1I9V5UC991",
//																	"attrs": {
//																		"style": "fontSuccess",
//																		"w": "24",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/check_fat.svg\"",
//																		"colorBG": "#cfgColor.success"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1I9V5UC992",
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"fontSuccess\",24,0,appCfg.sharedAssets+\"/check_fat.svg\",cfgColor.success)",
//																		"id": "BtnCheck",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"padding": "2",
//																		"margin": "[0,3,0,0]",
//																		"corner": "6"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1I9V5UC993",
//																	"attrs": {
//																		"1IM35DB500": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IM35JCSE0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IM35JCSE1",
//																					"attrs": {
//																						"display": "Off"
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IM35DB500",
//																			"faceTagName": "editCompare"
//																		},
//																		"1GDLTFRQJ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IM36EOH90",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IM36EOH91",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1GDLTFRQJ0",
//																			"faceTagName": "editChange"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1I9V5UC994",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1I9V5UC995",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "true",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1I9V5UC996",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "box",
//															"jaxId": "1I9V1TA4F0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I9V1TA4F1",
//																	"attrs": {
//																		"type": "box",
//																		"id": "",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "1",
//																		"h": "100%-6",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[0,0,0,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "\"\"",
//																		"styleClass": "",
//																		"background": "#cfgColor.lineBodyLit",
//																		"border": "0",
//																		"borderStyle": "Solid",
//																		"borderColor": "[0,0,0,1.00]",
//																		"corner": "0",
//																		"shadow": "false",
//																		"shadowX": "2",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowSpread": "0",
//																		"shadowColor": "[0,0,0,0.50]"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1I9V1TA4F2",
//																	"attrs": {
//																		"1GDLTFRQJ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IM36EOH92",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IM36EOH93",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1GDLTFRQJ0",
//																			"faceTagName": "editChange"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1I9V1TA4F3",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1I9V1TA4F4",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "box",
//															"jaxId": "1I9V1U0AP0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I9V1U0AP1",
//																	"attrs": {
//																		"type": "box",
//																		"id": "IconLeft",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "24",
//																		"h": "24",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[0,2,0,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "\"\"",
//																		"styleClass": "",
//																		"background": "#cfgColor.success",
//																		"border": "0",
//																		"borderStyle": "Solid",
//																		"borderColor": "[0,0,0,1.00]",
//																		"corner": "0",
//																		"shadow": "false",
//																		"shadowX": "2",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowSpread": "0",
//																		"shadowColor": "[0,0,0,0.50]",
//																		"maskImage": "#appCfg.sharedAssets+\"/recent.svg\""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1I9V1U0AQ0",
//																	"attrs": {
//																		"1IM35DB500": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IM35JCSE4",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IM35JCSE5",
//																					"attrs": {
//																						"maskImage": "#appCfg.sharedAssets+\"/file.svg\"",
//																						"background": "#cfgColor[\"front\"]"
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IM35DB500",
//																			"faceTagName": "editCompare"
//																		},
//																		"1GDLTFRQJ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IM36EOH94",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IM36EOH95",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1GDLTFRQJ0",
//																			"faceTagName": "editChange"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1I9V1U0AQ1",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1I9V1U0AQ2",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1I9V1V8TQ0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I9V1V8TQ1",
//																	"attrs": {
//																		"type": "text",
//																		"id": "TxtLeftDoc",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[0,0,0,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "\"\"",
//																		"styleClass": "",
//																		"color": "#cfgColor.fontBodySub",
//																		"text": {
//																			"type": "string",
//																			"valText": "基础版本",
//																			"localize": {
//																				"EN": "Base Version",
//																				"CN": "基础版本"
//																			},
//																			"localizable": true
//																		},
//																		"font": "",
//																		"fontSize": "#txtSize.smallMid",
//																		"bold": "true",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Center",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"lineClamp": "0",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0",
//																		"autoSizeW": "false",
//																		"autoSizeH": "false"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1I9V1V8TR0",
//																	"attrs": {
//																		"1GDLTFRQJ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IM36EOH96",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IM36EOH97",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1GDLTFRQJ0",
//																			"faceTagName": "editChange"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1I9V1V8TR1",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1I9V1V8TR2",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1I9V5O9700",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1I9V5SDCK0",
//																	"attrs": {
//																		"style": "\"front\"",
//																		"w": "26",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/save.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1I9V5SDCL0",
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"front\",26,0,appCfg.sharedAssets+\"/save.svg\",null)",
//																		"id": "BtnSaveLeft",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"padding": "2"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1I9V5SDCL1",
//																	"attrs": {
//																		"1GDLTFRQJ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IM36EOH98",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IM36EOH99",
//																					"attrs": {
//																						"display": "On",
//																						"enable": "false"
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1GDLTFRQJ0",
//																			"faceTagName": "editChange"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1I9V5SDCL2",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1I9V5SDCL3",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "true",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1I9V5SDCL4",
//																	"attrs": {}
//																}
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1I9V2B1R92",
//													"attrs": {
//														"1GDLTGRF60": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I9V2E26H40",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I9V2E26H41",
//																	"attrs": {
//																		"w": {
//																			"type": "length",
//																			"valText": "33%"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1GDLTGRF60",
//															"faceTagName": "editConflict"
//														},
//														"1GDLTFRQJ0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IM36EOH910",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IM36EOH911",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1GDLTFRQJ0",
//															"faceTagName": "editChange"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I9V2B1R93",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I9V2B1R94",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1I9V21DV00",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I9V22E4H0",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxMidHeader",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"flex": "true",
//														"contentLayout": "Flex X",
//														"itemsAlign": "Center"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "box",
//															"jaxId": "1I9V23GCO0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I9V23GCO1",
//																	"attrs": {
//																		"type": "box",
//																		"id": "",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "1",
//																		"h": "100%-6",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[0,0,0,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "\"\"",
//																		"styleClass": "",
//																		"background": "#cfgColor.lineBodyLit",
//																		"border": "0",
//																		"borderStyle": "Solid",
//																		"borderColor": "[0,0,0,1.00]",
//																		"corner": "0",
//																		"shadow": "false",
//																		"shadowX": "2",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowSpread": "0",
//																		"shadowColor": "[0,0,0,0.50]"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1I9V23GCO2",
//																	"attrs": {
//																		"1GDLTFRQJ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IM36EOH912",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IM36EOH913",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1GDLTFRQJ0",
//																			"faceTagName": "editChange"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1I9V23GCO3",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1I9V23GCO4",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "box",
//															"jaxId": "1I9V244ED0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I9V244ED1",
//																	"attrs": {
//																		"type": "box",
//																		"id": "IconMid",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "24",
//																		"h": "24",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "true",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[0,0,0,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "\"\"",
//																		"styleClass": "",
//																		"background": "#cfgColor.primary",
//																		"border": "0",
//																		"borderStyle": "Solid",
//																		"borderColor": "[0,0,0,1.00]",
//																		"corner": "0",
//																		"shadow": "false",
//																		"shadowX": "2",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowSpread": "0",
//																		"shadowColor": "[0,0,0,0.50]",
//																		"maskImage": "#appCfg.sharedAssets+\"/edit.svg\""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1I9V244EE0",
//																	"attrs": {
//																		"1IM35DB500": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IM35JCSE14",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IM35JCSE15",
//																					"attrs": {
//																						"background": "#cfgColor[\"fontBody\"]",
//																						"maskImage": "#appCfg.sharedAssets+\"/file.svg\""
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IM35DB500",
//																			"faceTagName": "editCompare"
//																		},
//																		"1GDLTFRQJ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IM36EOH914",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IM36EOH915",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1GDLTFRQJ0",
//																			"faceTagName": "editChange"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1I9V244EE5",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1I9V244EE6",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1I9V253560",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I9V253561",
//																	"attrs": {
//																		"type": "text",
//																		"id": "TxtMidDoc",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[0,0,0,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "\"\"",
//																		"styleClass": "",
//																		"color": "#cfgColor.fontBodySub",
//																		"text": {
//																			"type": "string",
//																			"valText": "当前版本",
//																			"localize": {
//																				"EN": "Current Version",
//																				"CN": "当前版本"
//																			},
//																			"localizable": true
//																		},
//																		"font": "",
//																		"fontSize": "#txtSize.smallMid",
//																		"bold": "true",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Center",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"lineClamp": "0",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0",
//																		"autoSizeW": "false",
//																		"autoSizeH": "false"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1I9V253570",
//																	"attrs": {
//																		"1GDLTFRQJ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IM36EOH916",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IM36EOH917",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1GDLTFRQJ0",
//																			"faceTagName": "editChange"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1I9V253571",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1I9V253572",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1I9V5SF3L0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1I9V5SF3L1",
//																	"attrs": {
//																		"style": "\"front\"",
//																		"w": "26",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/save.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1I9V5SF3L2",
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"front\",26,0,appCfg.sharedAssets+\"/save.svg\",null)",
//																		"id": "BtnSaveMid",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"padding": "2"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1I9V5SF3L3",
//																	"attrs": {
//																		"1GDLTFRQJ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IM36EOH918",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IM36EOH919",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1GDLTFRQJ0",
//																			"faceTagName": "editChange"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1I9V5SF3L4",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1I9V5SF3L5",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "true",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1I9V5SF3L6",
//																	"attrs": {}
//																}
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1I9V22E4H1",
//													"attrs": {
//														"1GDLTFRQJ0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IM36EOH920",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IM36EOH921",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1GDLTFRQJ0",
//															"faceTagName": "editChange"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I9V22E4H2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I9V22E4H3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1I9V22H8F0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I9V22H8F1",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxRightHeader",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "33%",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex X",
//														"itemsAlign": "Center"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "box",
//															"jaxId": "1I9V23I920",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I9V23I921",
//																	"attrs": {
//																		"type": "box",
//																		"id": "",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "1",
//																		"h": "100%-6",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[0,0,0,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "\"\"",
//																		"styleClass": "",
//																		"background": "#cfgColor.lineBodyLit",
//																		"border": "0",
//																		"borderStyle": "Solid",
//																		"borderColor": "[0,0,0,1.00]",
//																		"corner": "0",
//																		"shadow": "false",
//																		"shadowX": "2",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowSpread": "0",
//																		"shadowColor": "[0,0,0,0.50]"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1I9V23I930",
//																	"attrs": {
//																		"1GDLTFRQJ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IM36EOH922",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IM36EOH923",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1GDLTFRQJ0",
//																			"faceTagName": "editChange"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1I9V23I931",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1I9V23I932",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "box",
//															"jaxId": "1I9V28NSL0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I9V28NSL1",
//																	"attrs": {
//																		"type": "box",
//																		"id": "IconRIght",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "24",
//																		"h": "24",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "true",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[0,0,0,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "\"\"",
//																		"styleClass": "",
//																		"background": "#cfgColor.error",
//																		"border": "0",
//																		"borderStyle": "Solid",
//																		"borderColor": "[0,0,0,1.00]",
//																		"corner": "0",
//																		"shadow": "false",
//																		"shadowX": "2",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowSpread": "0",
//																		"shadowColor": "[0,0,0,0.50]",
//																		"maskImage": "#appCfg.sharedAssets+\"/cloud.svg\""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1I9V28NSM0",
//																	"attrs": {
//																		"1GDLTGRF60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I9V28NSM3",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I9V28NSM4",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1GDLTGRF60",
//																			"faceTagName": "editConflict"
//																		},
//																		"1GDLTFRQJ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IM36EOH924",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IM36EOH925",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1GDLTFRQJ0",
//																			"faceTagName": "editChange"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1I9V28NSM5",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1I9V28NSM6",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1I9V297070",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I9V297071",
//																	"attrs": {
//																		"type": "text",
//																		"id": "TxtRightDoc",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[0,0,0,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "\"\"",
//																		"styleClass": "",
//																		"color": "#cfgColor.fontBodySub",
//																		"text": {
//																			"type": "string",
//																			"valText": "云端代码库版本",
//																			"localize": {
//																				"EN": "Cloud Repo Version",
//																				"CN": "云端代码库版本"
//																			},
//																			"localizable": true
//																		},
//																		"font": "",
//																		"fontSize": "#txtSize.smallMid",
//																		"bold": "true",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Center",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"lineClamp": "0",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0",
//																		"autoSizeW": "false",
//																		"autoSizeH": "false"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1I9V297080",
//																	"attrs": {
//																		"1GDLTFRQJ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IM36EOH926",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IM36EOH927",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1GDLTFRQJ0",
//																			"faceTagName": "editChange"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1I9V297081",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1I9V297082",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1I9V5SP4E0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1I9V5SP4E1",
//																	"attrs": {
//																		"style": "\"front\"",
//																		"w": "26",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/save.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1I9V5SP4E2",
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"front\",26,0,appCfg.sharedAssets+\"/save.svg\",null)",
//																		"id": "BtnSaveRight",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"padding": "2"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1I9V5SP4F0",
//																	"attrs": {
//																		"1GDLTFRQJ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IM36EOH928",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IM36EOH929",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1GDLTFRQJ0",
//																			"faceTagName": "editChange"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1I9V5SP4F1",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1I9V5SP4F2",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "true",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1I9V5SP4F3",
//																	"attrs": {}
//																}
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1I9V22H8F2",
//													"attrs": {
//														"1GDLTFRQJ0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I9V2E26H74",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I9V2E26H75",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1GDLTFRQJ0",
//															"faceTagName": "editChange"
//														},
//														"1GDLTGRF60": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I9V2KUQ60",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I9V2KUQ61",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1GDLTGRF60",
//															"faceTagName": "editConflict"
//														},
//														"1IM35DB500": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IM35EQ5R15",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IM35EQ5R16",
//																	"attrs": {
//																		"display": "Off"
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IM35DB500",
//															"faceTagName": "editCompare"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I9V22H8F3",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I9V22H8F4",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1I9V2B1R95",
//									"attrs": {
//										"1GDLTFRQJ0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IM36EOH930",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IM36EOH931",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1GDLTFRQJ0",
//											"faceTagName": "editChange"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1I9V2B1R96",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1I9V2B1R97",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1GDLUH7F90",
//							"attrs": {
//								"properties": {
//									"jaxId": "1GDLUJ0CT0",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxCode",
//										"position": "Absolute",
//										"x": "0",
//										"y": "30",
//										"w": "100%",
//										"h": "100%-30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "true",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "\"\"",
//										"styleClass": ""
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1GDLUJ0CT1",
//									"attrs": {
//										"1GDLTFRQJ0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IM36EOH932",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IM36EOH933",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1GDLTFRQJ0",
//											"faceTagName": "editChange"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1GDLUJ0CT2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H04FKAF011",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "true",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1GDLSND497",
//					"attrs": {
//						"1GDLTFRQJ0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1IM36EOH934",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IM36EOH935",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1GDLTFRQJ0",
//							"faceTagName": "editChange"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1GDLSND498",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1H04FKAF012",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1GDLSND499",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false",
//				"innerLayout": {
//					"valText": "false"
//				},
//				"marginL": {
//					"valText": "false"
//				},
//				"marginR": {
//					"valText": "false"
//				},
//				"marginT": {
//					"valText": "false"
//				},
//				"marginB": {
//					"valText": "false"
//				},
//				"paddingL": {
//					"valText": "false"
//				},
//				"paddingR": {
//					"valText": "false"
//				},
//				"paddingT": {
//					"valText": "false"
//				},
//				"paddingB": {
//					"valText": "false"
//				},
//				"attach": {
//					"valText": "false"
//				},
//				"face": {
//					"type": "bool",
//					"valText": "false"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}