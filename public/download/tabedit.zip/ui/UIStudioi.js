//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
import {DocTabTrk} from "./DocTabTrk.js";
import {ToolView} from "./ToolView.js";
import {BtnSlideSizeX} from "/@StdUI/ui/BtnSlideSizeX.js";
/*#{1G9DJTQHM0StartDoc*/
import pathLib from "/@path";
import {tabFS,tabNT} from "/@tabos";
import {getSyncInfo} from "/@disk/sync.js";
import {AddOn} from "../data/AddOn.js";
import {DlgFile} from "/@StdUI/ui/DlgFile.js";
import {DataDoc,DataDocs} from "../data/DataDoc.js";
import {DocEditor} from "./DocEditor.js";
import {UIEditMD} from "./UIEditMD.js";
import {UIEditVersion} from "./UIEditVersion.js";
import {UIEditAI} from "./UIEditAI.js";
import {StateMsg} from "./StateMsg.js";
import {DlgDocs} from "./DlgDocs.js";
import {DlgStart} from "./DlgStart.js";
import {DlgEditLocString} from "./DlgEditLocString.js";
import markdownit from "/@markdownit";
import {aiLocalizeDoc} from "../ai/AILocalizer.js";
import {DlgAICoder} from "./DlgAICoder.js";
import {CfgProject} from "../data/AppData.js";

const minNaviW=200;
const minInfoW=250;
/*}#1G9DJTQHM0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let UIStudioi=function(app){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let btnRun,btnSync,btnShare,btnAI,btnAICoding,btnTranslate,btnAIUI,btnFiles,btnTerminal,txtCursor;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let layout=VFACT.flexState({
		"naviW":200,"infoW":320
	});
	
	/*#{1G9DJTQHM7LocalVals*/
	let appPrj,dataDocs;
	let naviView,infoView;
	let boxTabTrk;
	let isReady=0;
	let boxStateInfo=null;
	let boxInfos=[];
	let curInfoIdx=0;
	let isMac=/Mac/.test(navigator.platform);
	let isFocused=0;
	/*}#1G9DJTQHM7LocalVals*/
	
	/*#{1G9DJTQHM7PreState*/
	let slideMinX=0;
	let slideMaxX=0;
	/*}#1G9DJTQHM7PreState*/
	/*#{1G9DJTQHM7PostState*/
	/*}#1G9DJTQHM7PostState*/
	cssVO={
		"hash":"1G9DJTQHM7",nameHost:true,
		"type":"view","id":"MainUI","x":0,"y":0,"w":"FW","h":"FH","autoLayout":true,"display":"On","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
		children:[
			{
				"hash":"1G9H8KADJ0",
				"type":"hud","id":"BoxEditFrame","x":$P(()=>(layout.naviW),layout),"y":cfgSize.headerH,"w":$P(()=>(`FW-${layout.naviW+layout.infoW}`),layout),"h":`FH-${cfgSize.headerH+cfgSize.footerH}`,
				"autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
				children:[
					{
						"hash":"1GP72RDRC0",
						"type":"hud","id":"BoxEdit","position":"relative","x":0,"y":0,"w":"FW","h":"FH-30","autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						"traceSize":true,"flex":"1 1 auto",
					},
					{
						"hash":"1GP739JAG0",
						"type":"box","id":"BoxChat","position":"relative","x":0,"y":0,"w":"100%","h":30,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":[255,255,255,1],
						"border":[1,0,0,0],"shadowY":0,"contentLayout":"flex-x",
						"flex":"0 0 auto",
						children:[
							{
								"hash":"1I9V8SBVP0",
								"type":BtnIcon("front",28,0,appCfg.sharedAssets+"/save.svg",null),"id":"BtnSave","position":"relative","x":0,"y":0,"padding":4,
								"tip":(($ln==="CN")?("保存文档"):("Save document")),
								"OnClick":function(event){
									/*#{1I9V8U2N60FunctionBody*/
									self.doSaveDoc();
									/*}#1I9V8U2N60FunctionBody*/
								},
							},
							{
								"hash":"1I9V8V2AT0",
								"type":BtnIcon("front",28,0,appCfg.sharedAssets+"/run.svg",null),"id":"BtnRun","position":"relative","x":0,"y":0,"padding":4,
								"tip":(($ln==="CN")?("运行项目"):("Run project")),
								"OnClick":function(event){
									/*#{1I9V8V2AU4FunctionBody*/
									self.runPrj(this);
									/*}#1I9V8V2AU4FunctionBody*/
								},
							},
							{
								"hash":"1I9V90P020",
								"type":BtnIcon("front",28,0,appCfg.sharedAssets+"/dbsave.svg",null),"id":"BtnSync","position":"relative","x":0,"y":0,"padding":4,
								"tip":(($ln==="CN")?("与设备目录同步"):("Sync with device")),
								"OnClick":function(event){
									/*#{1I9V90P030FunctionBody*/
									self.syncPrj();
									/*}#1I9V90P030FunctionBody*/
								},
							},
							{
								"hash":"1I9V94ES80",
								"type":BtnIcon("front",28,0,appCfg.sharedAssets+"/share.svg",null),"id":"BtnShare","position":"relative","x":0,"y":0,"padding":4,
								"tip":(($ln==="CN")?("分享预览"):("Share preview")),
								"OnClick":function(event){
									/*#{1I9V94ES92FunctionBody*/
									self.sharePrj();
									/*}#1I9V94ES92FunctionBody*/
								},
							},
							{
								"hash":"1HHJF013P0",
								"type":"box","position":"relative","x":0,"y":5,"w":1,"h":">calc(100% - 10px)","margin":[0,3,0,3],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
								"background":cfgColor["fontBodyLit"],
							},
							{
								"hash":"1I9V96RRB0",
								"type":BtnIcon("front",28,0,appCfg.sharedAssets+"/aichat.svg",null),"id":"BtnAI","position":"relative","x":0,"y":0,"padding":4,
								"tip":(($ln==="CN")?("AI 对话 (Cmd+K 或 Ctrl+K)"):("AI chat (Cmd+K or Ctrl+K)")),
								"OnClick":function(event){
									/*#{1I9V96RRB5FunctionBody*/
									self.showAIDlg();
									/*}#1I9V96RRB5FunctionBody*/
								},
							},
							{
								"hash":"1I9V98GMU0",
								"type":BtnIcon("front",28,0,appCfg.sharedAssets+"/aicoding.svg",null),"id":"BtnAICoding","position":"relative","x":0,"y":0,"padding":4,
								"tip":(($ln==="CN")?("AI 编码 (Cmd+J 或 Ctrl+J)"):("AI coding (Cmd+J or Ctrl+J)")),
								"OnClick":function(event){
									/*#{1I9V98GMU5FunctionBody*/
									self.showAICoder();
									/*}#1I9V98GMU5FunctionBody*/
								},
							},
							{
								"hash":"1I9V9B7BC0",
								"type":BtnIcon("front",28,0,appCfg.sharedAssets+"/translate.svg",null),"id":"BtnTranslate","position":"relative","x":0,"y":0,"padding":4,
								"tip":(($ln==="CN")?("AI 翻译"):("AI Translate")),
								"OnClick":function(event){
									/*#{1I9V9B7BD0FunctionBody*/
									self.showLocalizer();
									/*}#1I9V9B7BD0FunctionBody*/
								},
							},
							{
								"hash":"1I9V9D1VP0",
								"type":BtnIcon("front",28,0,appCfg.sharedAssets+"/aiui.svg",null),"id":"BtnAIUI","position":"relative","x":0,"y":0,"padding":4,"enable":false,
								"OnClick":function(event){
									/*#{1I9V9D1VP9FunctionBody*/
									/*}#1I9V9D1VP9FunctionBody*/
								},
							},
							{
								"hash":"1HHJF1UA70",
								"type":"box","position":"relative","x":0,"y":5,"w":1,"h":">calc(100% - 10px)","margin":[0,3,0,3],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
								"background":cfgColor["fontBodyLit"],
							},
							{
								"hash":"1I9V9EL9P0",
								"type":BtnIcon("front",28,0,appCfg.sharedAssets+"/disk.svg",null),"id":"BtnFiles","position":"relative","x":0,"y":0,"padding":4,
								"tip":(($ln==="CN")?("文件管理器"):("File manager")),
								"OnClick":function(event){
									/*#{1I9V9EL9Q7FunctionBody*/
									app.openAppMeta("Files@files");
									/*}#1I9V9EL9Q7FunctionBody*/
								},
							},
							{
								"hash":"1I9V9GFPA0",
								"type":BtnIcon("front",28,0,appCfg.sharedAssets+"/terminal.svg",null),"id":"BtnTerminal","position":"relative","x":0,"y":0,"padding":4,
								"tip":(($ln==="CN")?("命令行终端"):("Terminal")),
								"OnClick":function(event){
									/*#{1I9V9GFPA9FunctionBody*/
									app.openAppMeta("Terminal@terminal");
									/*}#1I9V9GFPA9FunctionBody*/
								},
							}
						],
					}
				],
			},
			{
				"hash":"1G9DKQA040",
				"type":"box","id":"BoxHeader","x":0,"y":0,"w":"FW","h":cfgSize.headerH,"autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.head,
				"border":[0,0,1,0],"borderColor":cfgColor.lineBodySub,
				children:[
					{
						"hash":"1G9DKTTIR0",
						"type":"hud","id":"BoxNaviBtns","x":0,"y":0,"w":$P(()=>(layout.naviW),layout),"h":"FH","autoLayout":true,"overflow":1,"minW":"","minH":"","maxW":"",
						"maxH":"","styleClass":"",
					},
					{
						"hash":"1G9DL0FRS0",
						"type":"hud","id":"BoxDocTabs","x":$P(()=>(layout.naviW),layout),"y":0,"w":$P(()=>(`FW-${layout.naviW+layout.infoW}`),layout),"h":"FH+1","autoLayout":true,
						"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x","itemsAlign":1,
						children:[
							{
								"hash":"1G9EI761G0",
								"type":"box","position":"relative","x":0,"y":0,"w":1,"h":"FH-8","margin":[0,3,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.fontToolLit,
							},
							{
								"hash":"1I9V8OIU10",
								"type":BtnIcon("front",20,0,appCfg.sharedAssets+"/btncombo.svg",null),"id":"BtnDockList","position":"relative","x":0,"y":0,"padding":1,
								/*#{1I9V8OIU10Codes*/
								OnClick(){
									app.showDlg(DlgDocs,{hud:this});
								}
								/*}#1I9V8OIU10Codes*/
							},
							{
								"hash":"1G9EI49UV0",
								"type":DocTabTrk(app,"FW-32"),"id":"BoxTabTrk","x":28,"y":0,
							},
							{
								"hash":"1G9L3H7SE0",
								"type":"box","x":"FW-1","y":3,"w":1,"h":"FH-6","autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.fontToolLit,
							}
						],
					},
					{
						"hash":"1G9DL447S0",
						"type":"hud","id":"BoxInfoBtns","x":"FW","y":0,"w":$P(()=>(layout.infoW),layout),"h":"FH","anchorX":2,"autoLayout":true,"minW":"","minH":"","maxW":"",
						"maxH":"","styleClass":"",
					}
				],
			},
			{
				"hash":"1G9DL61ER0",
				"type":"box","id":"BoxFooter","x":0,"y":"FH","w":"FW","h":cfgSize.footerH,"anchorY":2,"autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"background":cfgColor.footer,"border":[1,0,0,0],"borderColor":cfgColor.lineBodySub,
				children:[
					{
						"hash":"1G9L1HMKT0",
						"type":"hud","id":"BoxState","x":10,"y":0,"w":"FW-20","h":"FH","autoLayout":true,"overflow":1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						children:[
							{
								"hash":"1IQ6L43S10",
								"type":"text","id":"TxtCursor","x":"100%","y":"50%","w":100,"h":"","anchorX":2,"anchorY":1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
								"color":cfgColor["fontBodySub"],"text":"-:-","fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignH":2,
							}
						],
					}
				],
			},
			{
				"hash":"1G9DLH6MV0",
				"type":"box","id":"BoxNaviFrame","x":0,"y":cfgSize.headerH,"w":$P(()=>(layout.naviW),layout),"h":`FH-${cfgSize.headerH+cfgSize.footerH}`,"autoLayout":true,
				"overflow":1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.tool,"border":[0,1,0,0],"borderColor":cfgColor.lineBody,
				children:[
					{
						"hash":"1G9EIBIBC0",
						"type":ToolView(app,"NaviTool"),"id":"TVNavi","x":0,"y":0,
					}
				],
			},
			{
				"hash":"1G9DM0LS60",
				"type":"box","id":"BoxInfoFrame","x":"FW","y":cfgSize.headerH,"w":$P(()=>(layout.infoW),layout),"h":`FH-${cfgSize.headerH+cfgSize.footerH}`,"anchorX":2,
				"autoLayout":true,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor.tool,"border":[0,0,0,1],"borderColor":cfgColor.lineBodySub,
				children:[
					{
						"hash":"1G9EID4G30",
						"type":ToolView(app,"InfoTool"),"id":"TVInfo","x":0,"y":0,
					}
				],
			},
			{
				"hash":"1G9HE4Q8K0",
				"type":"box","id":"BoxCover","x":"FW/2","y":"FH/2","w":"FH/2","h":"FH/2","anchorX":1,"anchorY":1,"display":0,"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","background":cfgColor.lineBodyLit,"maskImage":appCfg.sharedAssets+"/prj.svg",
			},
			{
				"hash":"1GCDMBNRO0",
				"type":BtnSlideSizeX(null,null,null),"id":"SldNavi","x":layout.naviW,"y":0,"autoLayout":true,"zIndex":10,"h":`FH-${cfgSize.footerH}`,
				/*#{1GCDMBNRO0Codes*/
				OnSlideStart(){
					let w;
					slideMinX=minNaviW;
					w=self.w;
					slideMaxX=w-layout.infoW-200;
				},
				OnSlideUpdate(evt,x,dx){
					let w;
					if(x<slideMinX){
						x=slideMinX;
					}
					if(x>slideMaxX){
						x=slideMaxX;
					}
					return x;
				},
				OnSlideFin(evt,x,dx){
					layout.naviW=x;
				}
				/*}#1GCDMBNRO0Codes*/
			},
			{
				"hash":"1GCDV7T9A0",
				"type":BtnSlideSizeX(null,null,null),"id":"SldInfo","x":`FW-${layout.infoW}`,"y":0,"autoLayout":true,"zIndex":10,"h":`FH-${cfgSize.footerH}`,
				/*#{1GCDV7T9A0Codes*/
				OnSlideStart(){
					let w;
					slideMaxX=w-minInfoW;
					w=self.w;
					slideMinX=w-layout.naviW-200;
				},
				OnSlideUpdate(evt,x,dx){
					let w;
					if(x<slideMinX){
						x=slideMinX;
					}
					if(x>slideMaxX){
						x=slideMaxX;
					}
					return x;
				},
				OnSlideFin(evt,x,dx){
					layout.infoW=self.w-x;
				}
				/*}#1GCDV7T9A0Codes*/
			}
		],
		/*#{1G9DJTQHM7ExtraCSS*/
		/*}#1G9DJTQHM7ExtraCSS*/
		faces:{
			"startup":{
				/*BoxEditFrame*/"#1G9H8KADJ0":{
					"display":0
				},
				/*BoxHeader*/"#1G9DKQA040":{
					"display":0
				},
				/*BoxNaviFrame*/"#1G9DLH6MV0":{
					"display":0
				},
				/*BoxInfoFrame*/"#1G9DM0LS60":{
					"display":0
				},
				/*BoxCover*/"#1G9HE4Q8K0":{
					"display":1
				},
				/*SldNavi*/"#1GCDMBNRO0":{
					"display":0
				},
				/*SldInfo*/"#1GCDV7T9A0":{
					"display":0
				}
			},"ready":{
				/*BoxEditFrame*/"#1G9H8KADJ0":{
					"display":1
				},
				/*BoxHeader*/"#1G9DKQA040":{
					"display":1
				},
				/*BoxNaviFrame*/"#1G9DLH6MV0":{
					"display":1
				},
				/*BoxInfoFrame*/"#1G9DM0LS60":{
					"display":1
				},
				/*BoxCover*/"#1G9HE4Q8K0":{
					"display":0
				},
				/*SldNavi*/"#1GCDMBNRO0":{
					"display":1
				},
				/*SldInfo*/"#1GCDV7T9A0":{
					"display":1
				}
			}
		},
		OnCreate:function(){
			self=this;
			btnRun=self.BtnRun;btnSync=self.BtnSync;btnShare=self.BtnShare;btnAI=self.BtnAI;btnAICoding=self.BtnAICoding;btnTranslate=self.BtnTranslate;btnAIUI=self.BtnAIUI;btnFiles=self.BtnFiles;btnTerminal=self.BtnTerminal;txtCursor=self.TxtCursor;
			/*#{1G9DJTQHM7Create*/
			appPrj=app.prj;
			dataDocs=appPrj.docs;
			self.showFace("startup");
			app.mainUI=self;
			
			boxTabTrk=self.BoxTabTrk;
			boxTabTrk.bind2Docs(appPrj.docs);
			naviView=self.TVNavi;
			infoView=self.TVInfo;
			app.naviView=naviView;
			app.infoView=infoView;
			
			//init state-message stuffs:
			boxStateInfo=self.BoxState;
			boxInfos[0]=boxStateInfo.appendNewChild(StateMsg(app));
			boxInfos[1]=boxStateInfo.appendNewChild(StateMsg(app));
			self.showStateText((($ln==="CN")?("开始..."):("Starting...")),0);
			
			let webObj=self.webObj;
			webObj.addEventListener('contextmenu', e => {
				e.preventDefault();
			});
			
			app.showAIDlg=function(vo){
				app.showDlg("/@aichat/ui/DlgAIChat.js",{url:"/@aichat/ai/default.aichat"});
			};
			
			app.showLocalizerDlg=function(vo){
				return app.showDlg(DlgEditLocString,vo);
			};
			/*}#1G9DJTQHM7Create*/
		},
		/*#{1G9DJTQHM7EndCSS*/
		/*}#1G9DJTQHM7EndCSS*/
	};
	/*#{1G9DJTQHM7PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.start=function(){
		let prjPath;
		prjPath=VFACT.appParams.path;
		if(!prjPath){
			self.askPrjPath();
			return;
		}
		//load prj:
		if(!prjPath.startsWith("/")){
			prjPath="/"+prjPath;
		}
		self.loadPrj(prjPath);
	};
	
	//------------------------------------------------------------------------
	cssVO.askPrjPath=function(){
		app.showDlg(DlgStart,{
			callback(prjPath,safeMode){
				if(!prjPath){
					self.askPrjPath();
					return;
				}
				self.loadPrj(prjPath,safeMode);
			}
		});
	};
	
	//------------------------------------------------------------------------
	cssVO.OnAppActive=function(){
		dataDocs.checkDocsModify();
	};
	
	//------------------------------------------------------------------------
	cssVO.loadPrj=async function(prjPath,safeMode){
		let naviName,infoName;
		appPrj.on("LoadInfo",self.setStateText);
		try{
			let doc;
			await appPrj.load(prjPath,safeMode);
	
			//Init side tool views:
			naviView.initViews(self.BoxNaviBtns);
			infoView.initViews(self.BoxInfoBtns);
			
			//Show default view:
			naviName=appPrj.startNaviView||"Path";
			infoName=appPrj.startInfoView||"Cloud";
			naviView.showView(naviName);
			infoView.showView(infoName);
			
			//init AI handlers:
			{
				let addOns,addOn;
				addOns=AddOn.getAddOns("AICommand");
				if(addOns){
					let mod,def,path;
					for(addOn of addOns){
						try{
							def=addOn.def;
							if(def && def.init){
								await def.init(app,this);
							}else{
								throw new Error("Can't locate addOn entry.");
							}
						}catch(err){
							console.log("Load addon Error: ");
							console.error(err);
							console.log("AddOn: ");
							console.error(addOn);
						}
					}
				}
			}
			
	
			//Show ready face:
			isReady=1;
			self.showFace("ready");
			self.showStateText((($ln==="CN")?("就绪"):("Ready")),0);
			
			dataDocs.on("NewDoc",self.OnNewDoc);
			dataDocs.on("CloseDoc",self.OnCloseDoc);
			dataDocs.on("FocusDoc",self.OnFocusDoc);
			dataDocs.on("BlurDoc",self.OnBlurDoc);
			dataDocs.on("DocChanged",self.OnDocChanged);
			dataDocs.on("DocSaved",self.OnDocSaved);
			dataDocs.on("DocLoaded",self.OnDocLoaded);
			
			doc=dataDocs.hotDoc;
			if(doc){
				self.OnFocusDoc(doc);
			}
			
			app.setFocusBox(self);
			app.setTitle(pathLib.basename(prjPath));
	
			history.replaceState(null, '', document.location.origin+document.location.pathname+"?path="+encodeURIComponent(prjPath.substring(1)));
			window.editPrjLoaded=true;
		}catch(err){
			console.error(err);
			window.alert((($ln==="CN")?("加载项目出错。项目路径可能错误或项目文件已损坏。请检查控制台获取更多详细信息。"):("Load project error. The project path maybe wrong or your project files be damaged. Please check the console for more details.")));
		}
		appPrj.off("LoadInfo",self.setStateText);
	};
	
	//************************************************************************
	//:App state(footer) message:
	//************************************************************************
	{
		let outTimer=null;
		//--------------------------------------------------------------------
		app.showStateText=cssVO.showStateText=function(text,time=5000,utext="",onclick=null){
			let opts,icon,oldBox,newBox;
			//boxStateInfo.w=self.TxtIndent.webObj.offsetLeft-10;
			if(outTimer){
				clearTimeout(outTimer);
				outTimer=null;
			}
			if(time instanceof Object){
				time=opts.time||5000;
				utext=opts.utext||"";
				onclick=opts.callback||null;
				icon=opts.icon||null;
			}
			oldBox=boxInfos[curInfoIdx];
			if(oldBox.display){
				oldBox.y=0;
				oldBox.animate({type:"out",dx:0,dy:-25,time:60})
			}
			curInfoIdx=curInfoIdx?0:1;
			newBox=boxInfos[curInfoIdx];
			newBox.showMsg(icon,text,utext,onclick);
			newBox.y=0;
			newBox.animate({type:"in",dx:0,dy:25,time:100})
			if(time){
				outTimer=setTimeout(()=>{
					self.showStateText((($ln==="CN")?("就绪"):("Ready")),0);
				},time);
			}
		};
	
		//--------------------------------------------------------------------
		app.setStateText=cssVO.setStateText=function(text,time=5000){
			let oldBox;
			if(outTimer){
				clearTimeout(outTimer);
				outTimer=null;
			}
			oldBox=boxInfos[curInfoIdx];
			if(!oldBox.display){
				oldBox.display=1;
				oldBox.y=0;
			}
			oldBox.showMsg(null,text,"",null);
			if(time){
				outTimer=setTimeout(()=>{
					self.setStateText((($ln==="CN")?("就绪"):("Ready")),0);
				},time);
			}
		};
		
		//--------------------------------------------------------------------
		app.setCursorText=cssVO.setCursorText=function(text){
			txtCursor.text=text;
		};
	}
	
	//************************************************************************
	//:Trace docs:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		cssVO.chooseEditorDef=function(doc){
			let addOns,addOn,uiDef,score,maxScore,maxDef;
			maxScore=0;
			maxDef=null;
			addOns=AddOn.getAddOns("DocEditor");
			for(addOn of addOns){
				uiDef=addOn.def;
				score=uiDef.scoreDoc(doc);
				if(score>maxScore){
					maxDef=uiDef;
					maxScore=score;
				}
			}
			return maxDef||DocEditor;
		};
	
		//--------------------------------------------------------------------
		cssVO.OnNewDoc=function(doc){
			let docText,editBox,docTab,def,css,hotDoc,hotTab,nextTab,extName;
			extName=pathLib.extname(doc.path);
			docText=doc.getDocText();
			def=self.chooseEditorDef(doc);
			css=def(app,extName,docText,appPrj.editorOpts,doc);
			editBox=self.BoxEdit.appendNewChild(css);
			doc.assignEditor(editBox);
		};
		
		//--------------------------------------------------------------------
		cssVO.OnCloseDoc=async function(doc){
			let editBox,docTab;
			editBox=doc.editBox;
			if(editBox){
				self.BoxEdit.removeChild(editBox);
				doc.editBox=null;
			}
			//Check if sigle doc
			if(dataDocs.docList.length>0){
				self.showFace("hasdoc");
			}else{
				self.showFace("nodoc");
			}
			//self.saveDocsState(1);
		};
	
		//--------------------------------------------------------------------
		cssVO.OnFocusDoc=function(doc){
			let editBox,text;
			editBox=doc.editBox;
			if(editBox){
				editBox.display=1;
				editBox.focus();
				if(doc.isChanged()){
					text="*"+doc.name;
				}else{
					text=doc.name;
				}
			}else{
				self.OnNewDoc(doc);
				editBox=doc.editBox;
				if(editBox){
					editBox.display=1;
					editBox.focus();
				}
				text=doc.name;
			}
			//app.setTitle(text);
			//self.saveDocsState(0);
		};
	
		//--------------------------------------------------------------------
		cssVO.OnBlurDoc=function(doc){
			let editBox;
			editBox=doc.editBox;
			if(editBox){
				editBox.blur();
				editBox.display=0;
			}
		};
	
		//--------------------------------------------------------------------
		cssVO.OnDocChanged=function(doc){
			let text;
			if(doc===dataDocs.hotDoc){
				if(doc.tempOpen){
					dataDocs.pinDoc(doc);
				}
				text="*"+doc.name;
				//app.setTitle(text);
			}
		};
		
		//--------------------------------------------------------------------
		cssVO.OnDocSaved=function(doc){
			let text;
			if(doc===dataDocs.hotDoc){
				//app.setTitle(doc.name);
			}
			self.showStateText((($ln==="CN")?(`文件 ${doc.path} 已保存。`):(`File ${doc.path} saved.`)));
		};
		
		//--------------------------------------------------------------------
		cssVO.OnDocLoaded=function(doc){
			let text;
			if(doc===dataDocs.hotDoc){
				//app.setTitle(doc.name);
			}
			self.showStateText((($ln==="CN")?(`文件 ${doc.path} 已加载。`):(`File ${doc.path} loaded.`)));
		};
		
	}
	
	//************************************************************************
	//:Focus box, handle shortcuts:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		cssVO.OnAppFocus=function(){
			self.showFace("focus");
			isFocused=1;
		};
	
		//--------------------------------------------------------------------
		cssVO.OnAppBlur=function(){
			self.showFace("blur");
			isFocused=1;
		};
		
		let altKeyDown=0;
		let altHotDoc=null;
		let ctrlKeyDown=0;
		let ctrlHotDoc=null;
		let docPos;
	
		//--------------------------------------------------------------------
		cssVO.OnKeyDown=function(code,e){
			let doc;
			if(!altKeyDown && e.key==="Alt"){
				altKeyDown=1;
				altHotDoc=null;
				docPos=dataDocs.docList.length-1;//Cur hot doc:
			}
			if(e.key==="Escape" && e.ctrlKey){
				if(!ctrlKeyDown){
					let dlg;
					//ctrlKeyDown=1;
					ctrlHotDoc=null;
					docPos=dataDocs.docList.length-1;//Cur hot doc:
					doc=dataDocs.hotDoc;
					if(doc && doc.editBox){
						doc.editBox.blur();
					}
					dlg=app.showDlg(DlgDocs,{
						hud:null,byKey:1
					});
					if(e.shiftKey){
						dlg.preDoc();
					}else{
						dlg.nextDoc();
					}
				}
				return 1;
			}
			if(altKeyDown && e.key==="Tab"){
				//Quick switch between docs:
				if(e.shiftKey){
					//TODO: Show DlgDocs;
				}else{
					//TODO: Show DlgDocs;
				}
				return 1;
			}
		};
	
		//--------------------------------------------------------------------
		cssVO.OnKeyUp=function(code,e){
			if(ctrlKeyDown && e.key==="Control"){
				ctrlKeyDown=0;
			}else if(altKeyDown && e.key==="Alt"){
				altKeyDown=0;
			}
		};
	
		//--------------------------------------------------------------------
		cssVO.handleShortcut=function(cmd){
			let hotDoc,editBox;
			switch(cmd){
				case "NewDoc":{
					self.doNewDoc();
					return 1;
				}
				case "Save":{
					self.doSaveDoc();
					return 1;
				}
				case "SaveAs":{
					self.doSaveAsDoc();
					return 1;
				}
				case "Open":{
					self.doOpenDoc();
					return 1;
				}
				case "Close":{
					self.doCloseDoc();
					return 1;
				}
				case "Sync":{
					self.syncPrj(true);
					return 1;
				}
			}
			hotDoc=dataDocs.hotDoc;
			if(hotDoc && hotDoc.editBox){
				return hotDoc.editBox.handleShortcut(cmd);
			}
			return 0;
		};
	}
	
	//************************************************************************
	//New/ Load/ Save doc:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		cssVO.openFile=async function(filePath){
			let list,doc;
			if(!filePath){
				return;
			}
			if(Array.isArray(filePath)){
				list=filePath;
			}else{
				list=[filePath];
			}
			for(filePath of list){
				await dataDocs.openDoc(filePath);
			}
		};
	
		//--------------------------------------------------------------------
		cssVO.doNewDoc=function(){
			let hotDoc,path;
			hotDoc=dataDocs.hotDoc;
			if(hotDoc){
				path=pathLib.dirname(hotDoc.path);
			}else{
				path="/";
			}
			app.showDlg(DlgFile,{
				mode:"save",
				path:path,
				buttonText:(($ln==="CN")?("创建"):/*EN*/("Create")),
				options:{
					multiSelect:0,
					preview:1,
				},
				callback:async function(filePath){
					if(!filePath){
						return;
					}
					try{
						await tabFS.writeFile(filePath,"","utf8");
						dataDocs.openDoc(filePath);
					}catch(e){
					}
				}
			});
		};
	
		//--------------------------------------------------------------------
		cssVO.doOpenDoc=function(){
			let hotDoc,path;
			hotDoc=dataDocs.hotDoc;
			if(hotDoc){
				path=pathLib.dirname(hotDoc.path);
			}else{
				path="/";
			}
			app.showDlg(DlgFile,{
				mode:"open",
				path:path,
				options:{
					multiSelect:1,
					preview:1,
				},
				callback:async function(filePath){
					self.openFile(filePath);
				}
			});
		};
	
		//----------------------------------------------------------------
		cssVO.doOpenRecent=async function(btn){
			let list;
			list=await dataDocs.getUsage();
			list=list.reverse();
			list=list.map(item=>{return {text:item,icon:appCfg.sharedAssets+"/file.svg",path:item}});
			list=list.filter(item=>item.path[0]==="/");
			app.showDlg("/@StdUI/ui/DlgMenu.js",{
				hud:btn,
				x:0,y:btn*0.5,
				items:list,
				callback:function(item){
					if(!item){
						return;
					}
					dataDocs.openDoc(item.path);
				}
			});
		};
	
		//--------------------------------------------------------------------
		cssVO.doSaveDoc=async function(){
			let doc,path;
			doc=dataDocs.hotDoc;
			if(doc){
				if(doc.path.startsWith("/")){
					await doc.saveDoc();
				}else{
					await self.doSaveAsDoc(true);
				}
			}
			path=doc.path;
			if(path===`${appPrj.path}/tabstudio.project.json`){
				if(window.confirm("Project config changed, reload it?")){
					document.location.reload();
				}
			}else{
				appPrj.save();
			}
		};
		
		//--------------------------------------------------------------------
		cssVO.doSaveAsDoc=function(closeCurDoc=false){
			let hotDoc,path,fname;
			hotDoc=dataDocs.hotDoc;
			if(!hotDoc){
				return;
			}
			path=pathLib.dirname(hotDoc.path);
			if(!path || path==="."){
				path="/doc";
			}
			fname=pathLib.basename(hotDoc.path);
			app.showDlg(DlgFile,{
				mode:"save",
				path:path,
				fileName:fname,
				options:{
					multiSelect:1,
					preview:1,
				},
				callback:async function(filePath){
					let list,doc;
					if(!filePath){
						return;
					}
					if(filePath===hotDoc.path){
						return;
					}
					if(hotDoc.getSaveAsText){
						await tabFS.writeFile(filePath,hotDoc.getSaveAsText(filePath),"utf8");
					}else{
						await tabFS.writeFile(filePath,hotDoc.getDocText(),"utf8");
					}
					if(closeCurDoc){
						dataDocs.closeDoc(hotDoc);
					}
					dataDocs.openDoc(filePath);
				}
			});
		};
	
		//--------------------------------------------------------------------
		cssVO.doCloseDoc=function(){
			let doc;
			doc=dataDocs.hotDoc;
			if(doc){
				if(doc.isChanged()){
					if(!window.confirm((($ln==="CN")?(`${doc.path} 已更改，确定要放弃更改并关闭吗？`):(`${doc.path} is changed, are you sure to abort changes and close it?`)))){
						return;
					}
				}
				dataDocs.closeDoc(doc);
			}
		};
	}
	
	//************************************************************************
	//Run project:
	//************************************************************************
	{
		let objToQueryString=function (obj) {
			const params = [];
			for (let key in obj) {
				if (obj.hasOwnProperty(key)) {
					let value = obj[key];
	
					if (typeof value !== 'undefined') {
						params.push(`${encodeURIComponent(key)}=${encodeURIComponent(value)}`);
					}
				}
			}
			return params.join('&');
		};
		
		let runMeta=null;
		//--------------------------------------------------------------------
		app.runPrj=
		cssVO.runPrj=async function(hud,runCfg){
			let prjCfg,mode,mainEntry;
			hud=hud||btnRun;
			if(!runCfg){
				prjCfg=appPrj.prjConfig;
				runCfg=prjCfg.run;
				if(!runCfg){
					return;
				}
				if(Array.isArray(runCfg)){
					if(hud && runCfg.length>1){
						let items=runCfg.map((item)=>{
							return {text:item.profileName||item.name||item.runName||"Run",cfg:item,icon:item.profileIcon};
						});
						app.showDlg("/@StdUI/ui/DlgMenu.js",{
							items:items,
							hud:hud,
							callback(item){
								if(!item){
									return;
								}
								runMeta=null;
								self.runPrj(hud,item.cfg);
							}
						});
						return;
					}
					runCfg=runCfg[0];
				}
			}
			mode=runCfg.mode;
			mainEntry=runCfg.main;
			switch(mode){
				case "ViewHTML":{
					if(!mainEntry){
						return;
					}
					if(!mainEntry.startsWith("/")){
						mainEntry=pathLib.join(appPrj.path,mainEntry);
					}
					await infoView.showView("ViewHTML",{path:mainEntry});
					break;
				}
				case "Command":{
					let appLib,meta,frames,frame,startVO;
					if(!mainEntry){
						return;
					}
					appLib=app.appLib;
					meta=appLib.getAppMeta("Terminal@terminal");
					frames=app.getAppFramesByMeta(meta);
					if(frames){
						for(frame of frames){
							if(!frame.isBusy()){
								app.focusAppFrame(frame);
								frame.runCommand(`coke ${mainEntry}`,appPrj.path);
								return;
							}
						}
					}
					//Init start path/command:
					startVO={
						path:appPrj.path,
						commands:`coke ${mainEntry}`,
					};
					frame=await app.newFrameApp(meta,`exec=${encodeURIComponent(JSON.stringify(startVO))}`,{});
					break;
				}
				case "AppFrame":
				case "FrameApp":{
					let frames,frame,arg,entryPath;//We generate run meta every time!
					if(!runMeta){
						let metaPath;
						metaPath=`${appPrj.path}/app.config.js`;
						if((!runCfg.main) && await tabFS.getEntry(metaPath)){
							metaPath=`${document.location.origin}/${appPrj.path}/app.config.js`;
							try{
								runMeta=(await import(metaPath)).default;
								if(runMeta.appFrame){
									runMeta.appFrame.width=runCfg.width||runMeta.appFrame.width;
									runMeta.appFrame.height=runCfg.height||runMeta.appFrame.height;
								}
							}catch(err){
								runMeta=null;
							}
						}
						if(!runMeta){
							entryPath=runCfg.main||"app.html";
							if(entryPath[0]!=="/"){
								entryPath=`/~${appPrj.path}/${entryPath}`;
							}
							runMeta={
								type:"app",
								name:"Dev. App",
								caption:"Dev. App",
								main:entryPath,
								package:"dev",
								catalog:["System"],
								icon:runCfg.icon?(runCfg.icon[0]==="/"?runCfg.icon:`/~${appPrj.path}/${runCfg.icon||"favicon.svg"}`):"/~tabos/shared/assets/app.svg",
								iconApp:null,
								appFrame:{
									main:entryPath,
									group:entryPath,
									title:"Dev. App",
									caption:"Dev. App",
									icon:runCfg.icon?(runCfg.icon[0]==="/"?runCfg.icon:`/~${appPrj.path}/${runCfg.icon||"favicon.svg"}`):"/~tabos/shared/assets/app.svg",
									multiFrame:true,
									width:runCfg.width||360,height:runCfg.height||600,
									maxable:false,
								}
							};
						}
					}else{
						entryPath=runCfg.main||"app.html";
						if(entryPath[0]!=="/"){
							entryPath=`/~${appPrj.path}/${entryPath}`;
						}
						runMeta.appFrame={
							main:entryPath,
							group:entryPath,
							title:"Dev. App",
							caption:"Dev. App",
							icon:runCfg.icon?(runCfg.icon[0]==="/"?runCfg.icon:`/~${appPrj.path}/${runCfg.icon||"favicon.svg"}`):"/~tabos/shared/assets/app.svg",
							multiFrame:true,
							width:runCfg.width||360,height:runCfg.height||600,
							maxable:false,
						};
					}
					frames=app.getAppFramesByGroup(runMeta.appFrame.group);
					if(frames){
						for(frame of frames){
							app.focusAppFrame(frame);
							frame.reloadPage();
							return;
						}
					}
					arg=runCfg.arg;
					if(typeof(arg)==="object"){
						arg=objToQueryString(arg);
					}
					app.newFrameApp(runMeta,arg||"",{});
					break;
				}
				case "Page":{
					if(!mainEntry){
						return;
					}
					if(!mainEntry.startsWith("/")){
						mainEntry=pathLib.join(appPrj.path,mainEntry);
					}
					window.open(document.location.origin+"/"+mainEntry);
					break;
				}
				default:{
					let addOns,addOn,def,score;
					addOns=AddOn.getAddOns("RunPrj");
					FindMode:{
						for(addOn of addOns){
							def=addOn.def;
							if(def.mode===mode){
								break FindMode;
							}
						}
						//No mode match, treat as page:
						if(!mainEntry){
							return;
						}
						if(!mainEntry.startsWith("/")){
							mainEntry=pathLib.join(appPrj.path,mainEntry);
						}
						window.open(document.location.origin+"/"+mainEntry);
						return;
					}
					def.runPrj(app,appPrj,runCfg);
					break;
				}
			}
		};
		
		//--------------------------------------------------------------------
		cssVO.sharePrj=async function(){
			if(!(await tabNT.checkLogin(false))){
				let logined=await app.modalDlg("/@homekit/ui/DlgLogin.js",{x:app.width/2,y:100,alignH:1});
				if(!logined){
					return;
				}
				await tabNT.checkLogin(false);
			}
			app.showDlg("/@tabedit/DlgShare.js",{prj:appPrj});
		};
	
		//--------------------------------------------------------------------
		app.checkSyncPrj=cssVO.syncPrj=async function(run){
			let syncInfo;
			syncInfo=await getSyncInfo(appPrj.path);
			if(syncInfo){
				let doSync=false;
				if(syncInfo.totalUpChange>0){
					if(window.confirm((($ln==="CN")?("项目有未同步到后端的内容，是否现在同步？"):/*EN*/("There are unsynchronized local changes in the project. Would you like to sync now?")))){
						doSync=true;
					}
				}else if(syncInfo.totalDownChange>0){
					if(window.confirm((($ln==="CN")?("有未同步到本地的后端的内容，是否现在同步？"):/*EN*/("There is unsynced backend changes, do you want to sync now?")))){
						doSync=true;
					}
				}
				if(doSync){
					await app.syncPrj(true);
					return true;
				}
			}
			return false;
		};
		
		//--------------------------------------------------------------------
		app.syncPrj=cssVO.syncPrj=async function(run){
			let synced;
			synced=await app.modalDlg("/@StdUI/ui/DlgSyncDir.js",{path:appPrj.path,run:run});
			if(synced){
				app.showStateText((($ln==="CN")?("工程已和服务器同步完毕."):/*EN*/("Project synced with server.")));
				dataDocs.checkDocsModify();
			}
		};
		
		//--------------------------------------------------------------------
		app.cfgPrj=cssVO.cfgPrj=async function(hud){
			let prjCfg,newCfg,path;
			path=appPrj.path;
			prjCfg=appPrj.prjConfig;
			CfgProject.properties.addOns.element.path=path;
			newCfg=await app.modalDlg("/@StdUI/ui/DlgDataView.js",{
				hud:hud,width:500,x:0,y:20,alignX:0,alignY:0,
				template:"CfgProject",object:prjCfg
			});
			if(newCfg){
				console.log(newCfg);
				path=`${appPrj.path}/tabstudio.project.json`;
				await tabFS.writeFile(path,JSON.stringify(newCfg,null,"\t"),"utf8");
				if(window.confirm((($ln==="CN")?("项目配置已更改，重新加载吗?"):/*EN*/("Project config changed, reload it?")))){
					document.location.reload();
				}
			}
		};
	}
	
	//************************************************************************
	//AIChat
	//************************************************************************
	{
		//--------------------------------------------------------------------
		cssVO.showAIDlg=function(){
			app.showDlg("/@aichat/ui/DlgAIChat.js",{url:"/@aichat/ai/default.aichat"});
		};
		
		//--------------------------------------------------------------------
		cssVO.showLocalizer=function(){
			let curDoc,text,codyDoc,sourceType;
			text="";
			curDoc=dataDocs.hotDoc;
			if(curDoc){
				codyDoc=curDoc.codyDoc;
				if(curDoc.editBox){
					text=curDoc.editBox.getSelection();
				}
				if(curDoc.path.endsWith(".py")){
					sourceType="Python";
				}
			}else{
				sourceType="Javascript";
			}
			if(codyDoc){
				app.showDlg("/@StdUI/ui/DlgMenu.js",{
					hud:btnTranslate,anchorV:2,
					items:[
						{text:(($ln==="CN")?("打开本地化器"):("Open Localizer")),code:"Open",icon:appCfg.sharedAssets+"/translate.svg"},
						{text:(($ln==="CN")?("自动本地化文档"):("Auto Localize Doc")),code:"Doc",icon:appCfg.sharedAssets+"/lab.svg"}
					],
					callback:function(item){
						if(!item){
							return;
						}
						if(item.code==="Open"){
							app.showLocalizerDlg({mode:"locCode",doc:codyDoc,dataDoc:curDoc,text:text,sourceType:sourceType});
						}else if(item.code==="Doc"){
							//aiLocalizeDoc(app,app.aiChat,codyDoc,codyDoc.prj.curLanguage);
						}
					}
				});
			}else{
				app.showLocalizerDlg({mode:"locCode",codyPrj:appPrj.codyPrj||null,doc:codyDoc,dataDoc:curDoc,text:text,sourceType:sourceType});
			}
		};
		
		//--------------------------------------------------------------------
		cssVO.showAICoder=async function(){
			let doc,item,editBox,selRange;
			doc=dataDocs.hotDoc;
			editBox=doc.editBox;
			selRange=editBox.getSelectionRange();
			item=await app.modalDlg("/@StdUI/ui/DlgMenu.js",{
				hud:btnAICoding,anchorV:2,
				items:[
					{text:(($ln==="CN")?(selRange?"完善选择部分代码 (Cmd+J / Ctrl+J)":"在光标处编写 (Cmd+J / Ctrl+J)"):(selRange?"Refine selected codes (Cmd+J / Ctrl+J)":"Coding by cursor (Cmd+J / Ctrl+J)")),code:"Cursor",icon:appCfg.sharedAssets+"/edit.svg"},
					{text:(($ln==="CN")?("优化整个文档"):("Refine whole doc")),code:"Doc",icon:appCfg.sharedAssets+"/file.svg"},
					{text:(($ln==="CN")?("AI代码设定"):("AI coding settings")),code:"Config",icon:appCfg.sharedAssets+"/config.svg"},
				],
			});
			if(!item){
				return;
			}
			if(item.code==="Cursor"){
				app.showDlg(DlgAICoder,{
					doc:doc
				});
			}else if(item.code==="Doc"){
				app.showDlg(DlgAICoder,{
					doc:doc,action:"Refine"
				});
			}else if(item.code==="Config"){
				let prjCfg=appPrj.prjConfig.aiCoder;
				let newCfg=await app.modalDlg("/@StdUI/ui/DlgDataView.js",{
					hud:btnAICoding,width:500,x:0,y:20,alignX:0,alignY:0,
					template:"CfgAICode",object:prjCfg
				});
				if(newCfg){
					let path;
					Object.assign(prjCfg,newCfg);
					console.log(prjCfg);
					path=`${appPrj.path}/tabstudio.project.json`;
					await tabFS.writeFile(path,JSON.stringify(appPrj.prjConfig,null,"\t"),"utf8");
				}
			}
	
		};
	}
	/*}#1G9DJTQHM7PostCSSVO*/
	cssVO.constructor=UIStudioi;
	return cssVO;
};
/*#{1G9DJTQHM7ExCodes*/
/*}#1G9DJTQHM7ExCodes*/

//----------------------------------------------------------------------------
UIStudioi.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1G9DJTQHM7PreAISpot*/
	/*}#1G9DJTQHM7PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1G9DJTQHM7PostAISpot*/
	/*}#1G9DJTQHM7PostAISpot*/
	return exposeVO;
};

/*#{1G9DJTQHM0EndDoc*/
/*}#1G9DJTQHM0EndDoc*/

export default UIStudioi;
export{UIStudioi};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "UIView",
//	"jaxId": "1G9DJTQHM0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1G9DJTQHM1",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "800",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1G9DJTQHM2",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1H7HJ8FR30",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1G9DJTQHM3",
//			"attrs": {
//				"app": {
//					"type": "auto",
//					"valText": "null"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1G9DJTQHM4",
//			"attrs": {
//				"layout": {
//					"type": "uistate",
//					"def": "StateObj",
//					"jaxId": "1G9DL5TJ50",
//					"attrs": {
//						"naviW": {
//							"type": "int",
//							"valText": "200"
//						},
//						"infoW": {
//							"type": "int",
//							"valText": "320"
//						}
//					}
//				}
//			}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1G9DJTQHM5",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "VFACT document",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1G9DJTQHM6",
//			"attrs": {
//				"startup": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1G9HDVSD80",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1G9HEDO1B0",
//							"attrs": {}
//						}
//					}
//				},
//				"ready": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1G9HE1MK90",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1G9HEDO1B1",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1HCTVAPG00",
//			"attrs": {}
//		},
//		"exposeToAI": "true",
//		"descAI": "",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "view",
//			"jaxId": "1G9DJTQHM7",
//			"attrs": {
//				"properties": {
//					"jaxId": "1G9DJTQHM8",
//					"attrs": {
//						"type": "view",
//						"id": "MainUI",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "\"FW\"",
//						"h": "\"FH\"",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "true",
//						"display": "\"On\"",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "[0,0,0,0]",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "\"\"",
//						"styleClass": ""
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1G9H8KADJ0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G9H8N5EK0",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxEditFrame",
//										"position": "Absolute",
//										"x": "${layout.naviW},layout",
//										"y": "#cfgSize.headerH",
//										"w": "${`FW-${layout.naviW+layout.infoW}`},layout",
//										"h": "#`FH-${cfgSize.headerH+cfgSize.footerH}`",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "true",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "\"\"",
//										"styleClass": "",
//										"contentLayout": "Flex Y"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1GP72RDRC0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1GP72UUSF0",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxEdit",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"w": "\"FW\"",
//														"h": "\"FH-30\"",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "true",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": ""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1GP72UUSF1",
//													"attrs": {
//														"1G9HDVSD80": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I9V9AH2B0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I9V9AH2B1",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1G9HDVSD80",
//															"faceTagName": "startup"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1GP72UUSF2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1GP72UUSF3",
//													"attrs": {
//														"traceSize": {
//															"type": "bool",
//															"valText": "true"
//														},
//														"flex": {
//															"type": "string",
//															"valText": "1 1 auto"
//														}
//													}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1GP739JAG0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1GP74HGPJ0",
//													"attrs": {
//														"type": "box",
//														"id": "BoxChat",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "30",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "[255,255,255,1.00]",
//														"border": "[1,0,0,0]",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "0",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]",
//														"contentLayout": "Flex X"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1I9V8SBVP0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1I9V8UBLM0",
//																	"attrs": {
//																		"style": "\"front\"",
//																		"w": "28",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/save.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1I9V8UBLM1",
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"front\",28,0,appCfg.sharedAssets+\"/save.svg\",null)",
//																		"id": "BtnSave",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"padding": "4"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1I9V8UBLM2",
//																	"attrs": {
//																		"1G9HDVSD80": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I9V9AH2B4",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I9V9AH2B5",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1G9HDVSD80",
//																			"faceTagName": "startup"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1I9V8UBLM3",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1I9V8U2N60",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1I9V8UBLM4",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1I9V8UBLM5",
//																	"attrs": {
//																		"tip": {
//																			"type": "string",
//																			"valText": "保存文档",
//																			"localize": {
//																				"EN": "Save document",
//																				"CN": "保存文档"
//																			},
//																			"localizable": true
//																		}
//																	}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1I9V8UBLM6",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1I9V8V2AT0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1I9V8V2AU0",
//																	"attrs": {
//																		"style": "\"front\"",
//																		"w": "28",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/run.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1I9V8V2AU1",
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"front\",28,0,appCfg.sharedAssets+\"/run.svg\",null)",
//																		"id": "BtnRun",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"padding": "4"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1I9V8V2AU2",
//																	"attrs": {
//																		"1G9HDVSD80": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I9V9AH2B8",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I9V9AH2B9",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1G9HDVSD80",
//																			"faceTagName": "startup"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1I9V8V2AU3",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1I9V8V2AU4",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1I9V8V2AU5",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1I9V8V2AU6",
//																	"attrs": {
//																		"tip": {
//																			"type": "string",
//																			"valText": "运行项目",
//																			"localize": {
//																				"EN": "Run project",
//																				"CN": "运行项目"
//																			},
//																			"localizable": true
//																		}
//																	}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1I9V8V2AU7",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1I9V90P020",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1I9V90P021",
//																	"attrs": {
//																		"style": "\"front\"",
//																		"w": "28",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/dbsave.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1I9V90P022",
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"front\",28,0,appCfg.sharedAssets+\"/dbsave.svg\",null)",
//																		"id": "BtnSync",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"padding": "4"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1I9V90P023",
//																	"attrs": {
//																		"1G9HDVSD80": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I9V9AH2B12",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I9V9AH2B13",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1G9HDVSD80",
//																			"faceTagName": "startup"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1I9V90P024",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1I9V90P030",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1I9V90P031",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1I9V90P032",
//																	"attrs": {
//																		"tip": {
//																			"type": "string",
//																			"valText": "与设备目录同步",
//																			"localize": {
//																				"EN": "Sync with device",
//																				"CN": "与设备目录同步"
//																			},
//																			"localizable": true
//																		}
//																	}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1I9V90P033",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1I9V94ES80",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1I9V94ES81",
//																	"attrs": {
//																		"style": "\"front\"",
//																		"w": "28",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/share.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1I9V94ES82",
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"front\",28,0,appCfg.sharedAssets+\"/share.svg\",null)",
//																		"id": "BtnShare",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"padding": "4"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1I9V94ES90",
//																	"attrs": {
//																		"1G9HDVSD80": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I9V9AH2B16",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I9V9AH2B17",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1G9HDVSD80",
//																			"faceTagName": "startup"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1I9V94ES91",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1I9V94ES92",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1I9V94ES93",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1I9V94ES94",
//																	"attrs": {
//																		"tip": {
//																			"type": "string",
//																			"valText": "分享预览",
//																			"localize": {
//																				"EN": "Share preview",
//																				"CN": "分享预览"
//																			},
//																			"localizable": true
//																		}
//																	}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1I9V94ES95",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "box",
//															"jaxId": "1HHJF013P0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HHJF1THI0",
//																	"attrs": {
//																		"type": "box",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "5",
//																		"w": "1",
//																		"h": "100%-10",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[0,3,0,3]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"background": "#cfgColor[\"fontBodyLit\"]",
//																		"border": "0",
//																		"borderStyle": "Solid",
//																		"borderColor": "[0,0,0,1.00]",
//																		"corner": "0",
//																		"shadow": "false",
//																		"shadowX": "2",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowSpread": "0",
//																		"shadowColor": "[0,0,0,0.50]"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HHJF1THI1",
//																	"attrs": {
//																		"1G9HDVSD80": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I9V9AH2B20",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I9V9AH2B21",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1G9HDVSD80",
//																			"faceTagName": "startup"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HHJF1THI2",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HHJF1THI3",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1I9V96RRB0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1I9V96RRB1",
//																	"attrs": {
//																		"style": "\"front\"",
//																		"w": "28",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/aichat.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1I9V96RRB2",
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"front\",28,0,appCfg.sharedAssets+\"/aichat.svg\",null)",
//																		"id": "BtnAI",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"padding": "4"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1I9V96RRB3",
//																	"attrs": {
//																		"1G9HDVSD80": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I9V9AH2B24",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I9V9AH2B25",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1G9HDVSD80",
//																			"faceTagName": "startup"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1I9V96RRB4",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1I9V96RRB5",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1I9V96RRB6",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1I9V96RRB7",
//																	"attrs": {
//																		"tip": {
//																			"type": "string",
//																			"valText": "AI 对话 (Cmd+K 或 Ctrl+K)",
//																			"localize": {
//																				"EN": "AI chat (Cmd+K or Ctrl+K)",
//																				"CN": "AI 对话 (Cmd+K 或 Ctrl+K)"
//																			},
//																			"localizable": true
//																		}
//																	}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1I9V96RRC0",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1I9V98GMU0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1I9V98GMU1",
//																	"attrs": {
//																		"style": "\"front\"",
//																		"w": "28",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/aicoding.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1I9V98GMU2",
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"front\",28,0,appCfg.sharedAssets+\"/aicoding.svg\",null)",
//																		"id": "BtnAICoding",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"padding": "4"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1I9V98GMU3",
//																	"attrs": {
//																		"1G9HDVSD80": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I9V9AH2B28",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I9V9AH2B29",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1G9HDVSD80",
//																			"faceTagName": "startup"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1I9V98GMU4",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1I9V98GMU5",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1I9V98GMU6",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1I9V98GMU7",
//																	"attrs": {
//																		"tip": {
//																			"type": "string",
//																			"valText": "AI 编码 (Cmd+J 或 Ctrl+J)",
//																			"localize": {
//																				"EN": "AI coding (Cmd+J or Ctrl+J)",
//																				"CN": "AI 编码 (Cmd+J 或 Ctrl+J)"
//																			},
//																			"localizable": true
//																		}
//																	}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1I9V98GMV0",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1I9V9B7BC0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1I9V9B7BC1",
//																	"attrs": {
//																		"style": "\"front\"",
//																		"w": "28",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/translate.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1I9V9B7BC2",
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"front\",28,0,appCfg.sharedAssets+\"/translate.svg\",null)",
//																		"id": "BtnTranslate",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"padding": "4"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1I9V9B7BC3",
//																	"attrs": {
//																		"1G9HDVSD80": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I9V9B7BC4",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I9V9B7BC5",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1G9HDVSD80",
//																			"faceTagName": "startup"
//																		},
//																		"1G9HE1MK90": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I9V9B7BC6",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I9V9B7BC7",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1G9HE1MK90",
//																			"faceTagName": "ready"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1I9V9B7BC8",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1I9V9B7BD0",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1I9V9B7BD1",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1I9V9B7BD2",
//																	"attrs": {
//																		"tip": {
//																			"type": "string",
//																			"valText": "AI 翻译",
//																			"localize": {
//																				"EN": "AI Translate",
//																				"CN": "AI 翻译"
//																			},
//																			"localizable": true
//																		}
//																	}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1I9V9B7BD3",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1I9V9D1VP0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1I9V9D1VP1",
//																	"attrs": {
//																		"style": "\"front\"",
//																		"w": "28",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/aiui.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1I9V9D1VP2",
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"front\",28,0,appCfg.sharedAssets+\"/aiui.svg\",null)",
//																		"id": "BtnAIUI",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"padding": "4",
//																		"enable": "false"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1I9V9D1VP3",
//																	"attrs": {
//																		"1G9HDVSD80": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I9V9D1VP4",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I9V9D1VP5",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1G9HDVSD80",
//																			"faceTagName": "startup"
//																		},
//																		"1G9HE1MK90": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I9V9D1VP6",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I9V9D1VP7",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1G9HE1MK90",
//																			"faceTagName": "ready"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1I9V9D1VP8",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1I9V9D1VP9",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1I9V9D1VP10",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1I9V9D1VP11",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1I9V9D1VP12",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "box",
//															"jaxId": "1HHJF1UA70",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HHJF1UA71",
//																	"attrs": {
//																		"type": "box",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "5",
//																		"w": "1",
//																		"h": "100%-10",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[0,3,0,3]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"background": "#cfgColor[\"fontBodyLit\"]",
//																		"border": "0",
//																		"borderStyle": "Solid",
//																		"borderColor": "[0,0,0,1.00]",
//																		"corner": "0",
//																		"shadow": "false",
//																		"shadowX": "2",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowSpread": "0",
//																		"shadowColor": "[0,0,0,0.50]"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HHJF1UA80",
//																	"attrs": {
//																		"1G9HDVSD80": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I9V9AH2B40",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I9V9AH2B41",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1G9HDVSD80",
//																			"faceTagName": "startup"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HHJF1UA81",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HHJF1UA82",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1I9V9EL9P0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1I9V9EL9P1",
//																	"attrs": {
//																		"style": "\"front\"",
//																		"w": "28",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/disk.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1I9V9EL9Q0",
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"front\",28,0,appCfg.sharedAssets+\"/disk.svg\",null)",
//																		"id": "BtnFiles",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"padding": "4"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1I9V9EL9Q1",
//																	"attrs": {
//																		"1G9HDVSD80": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I9V9EL9Q2",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I9V9EL9Q3",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1G9HDVSD80",
//																			"faceTagName": "startup"
//																		},
//																		"1G9HE1MK90": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I9V9EL9Q4",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I9V9EL9Q5",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1G9HE1MK90",
//																			"faceTagName": "ready"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1I9V9EL9Q6",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1I9V9EL9Q7",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1I9V9EL9Q8",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1I9V9EL9Q9",
//																	"attrs": {
//																		"tip": {
//																			"type": "string",
//																			"valText": "文件管理器",
//																			"localize": {
//																				"EN": "File manager",
//																				"CN": "文件管理器"
//																			},
//																			"localizable": true
//																		}
//																	}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1I9V9EL9Q10",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1I9V9GFPA0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1I9V9GFPA1",
//																	"attrs": {
//																		"style": "\"front\"",
//																		"w": "28",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/terminal.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1I9V9GFPA2",
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"front\",28,0,appCfg.sharedAssets+\"/terminal.svg\",null)",
//																		"id": "BtnTerminal",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"padding": "4"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1I9V9GFPA3",
//																	"attrs": {
//																		"1G9HDVSD80": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I9V9GFPA4",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I9V9GFPA5",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1G9HDVSD80",
//																			"faceTagName": "startup"
//																		},
//																		"1G9HE1MK90": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I9V9GFPA6",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I9V9GFPA7",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1G9HE1MK90",
//																			"faceTagName": "ready"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1I9V9GFPA8",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1I9V9GFPA9",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1I9V9GFPA10",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1I9V9GFPA11",
//																	"attrs": {
//																		"tip": {
//																			"type": "string",
//																			"valText": "命令行终端",
//																			"localize": {
//																				"EN": "Terminal",
//																				"CN": "命令行终端"
//																			},
//																			"localizable": true
//																		}
//																	}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1I9V9GFPA12",
//																	"attrs": {}
//																}
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1GP74HGPJ10",
//													"attrs": {
//														"1G9HDVSD80": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1I9V9AH2B52",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1I9V9AH2B53",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1G9HDVSD80",
//															"faceTagName": "startup"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1GP74HGPJ11",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1GP74HGPJ12",
//													"attrs": {
//														"flex": {
//															"type": "string",
//															"valText": "0 0 auto"
//														}
//													}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1G9H8N5EK1",
//									"attrs": {
//										"1G9HE1MK90": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9HEDO1B2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9HEDO1B3",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9HE1MK90",
//											"faceTagName": "ready"
//										},
//										"1G9HDVSD80": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9HEDO1B4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9HEDO1B5",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9HDVSD80",
//											"faceTagName": "startup"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1G9H8N5EK2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1GH4JH1850",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "true",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1G9DKQA040",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G9DL5TJ51",
//									"attrs": {
//										"type": "box",
//										"id": "BoxHeader",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "\"FW\"",
//										"h": "#cfgSize.headerH",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "true",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "\"\"",
//										"styleClass": "",
//										"background": "#cfgColor.head",
//										"border": "[0,0,1,0]",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor.lineBodySub",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1G9DKTTIR0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9DL5TJ52",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxNaviBtns",
//														"position": "Absolute",
//														"x": "0",
//														"y": "0",
//														"w": "${layout.naviW},layout",
//														"h": "\"FH\"",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "true",
//														"display": "On",
//														"clip": "On",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[0,0,0,0]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "\"\"",
//														"styleClass": ""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1G9DL5TJ53",
//													"attrs": {
//														"1G9HDVSD80": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1G9HEE1EJ0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1G9HEE1EJ1",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1G9HDVSD80",
//															"faceTagName": "startup"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1G9DL5TJ54",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1GH4JH1851",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "true",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1G9DL0FRS0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9DL5TJ55",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxDocTabs",
//														"position": "Absolute",
//														"x": "${layout.naviW},layout",
//														"y": "0",
//														"w": "${`FW-${layout.naviW+layout.infoW}`},layout",
//														"h": "\"FH+1\"",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "true",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[0,0,0,0]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "\"\"",
//														"styleClass": "",
//														"contentLayout": "Flex X",
//														"itemsAlign": "Center"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "box",
//															"jaxId": "1G9EI761G0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1G9EI9N1M0",
//																	"attrs": {
//																		"type": "box",
//																		"id": "",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "1",
//																		"h": "\"FH-8\"",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[0,3,0,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "\"\"",
//																		"styleClass": "",
//																		"background": "#cfgColor.fontToolLit",
//																		"border": "0",
//																		"borderStyle": "Solid",
//																		"borderColor": "[0,0,0,1.00]",
//																		"corner": "0",
//																		"shadow": "false",
//																		"shadowX": "2",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowSpread": "0",
//																		"shadowColor": "[0,0,0,0.50]"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1G9EI9N1M1",
//																	"attrs": {
//																		"1G9HDVSD80": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1G9HEE1EJ6",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1G9HEE1EJ7",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1G9HDVSD80",
//																			"faceTagName": "startup"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1G9EI9N1M2",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1GH4JH1852",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1I9V8OIU10",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1I9V8PDMK0",
//																	"attrs": {
//																		"style": "\"front\"",
//																		"w": "20",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/btncombo.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1I9V8PDMK1",
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"front\",20,0,appCfg.sharedAssets+\"/btncombo.svg\",null)",
//																		"id": "BtnDockList",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"padding": "1"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1I9V8PDMK2",
//																	"attrs": {
//																		"1G9HDVSD80": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1I9V9AH2B60",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1I9V9AH2B61",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1G9HDVSD80",
//																			"faceTagName": "startup"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1I9V8PDMK3",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1I9V8PDMK4",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "true",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1I9V8PDMK5",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear1G9EHTP730",
//															"jaxId": "1G9EI49UV0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1G9EI6CMV0",
//																	"attrs": {
//																		"app": "#app",
//																		"w": "\"FW-32\""
//																	}
//																},
//																"properties": {
//																	"jaxId": "1G9EI6CMV1",
//																	"attrs": {
//																		"type": "#null#>DocTabTrk(app,\"FW-32\")",
//																		"id": "BoxTabTrk",
//																		"position": "Absolute",
//																		"x": "28",
//																		"y": "0",
//																		"display": "On"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1G9EI6CMV2",
//																	"attrs": {
//																		"1G9HDVSD80": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1G9HEE1EJ4",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1G9HEE1EJ5",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1G9HDVSD80",
//																			"faceTagName": "startup"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1G9EI6CMV3",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1GH4JH1854",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1H7HJ8FR310",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "box",
//															"jaxId": "1G9L3H7SE0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1G9L3H7SE1",
//																	"attrs": {
//																		"type": "box",
//																		"id": "",
//																		"position": "Absolute",
//																		"x": "\"FW-1\"",
//																		"y": "3",
//																		"w": "1",
//																		"h": "\"FH-6\"",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "true",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[0,0,0,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "\"\"",
//																		"styleClass": "",
//																		"background": "#cfgColor.fontToolLit",
//																		"border": "0",
//																		"borderStyle": "Solid",
//																		"borderColor": "[0,0,0,1.00]",
//																		"corner": "0",
//																		"shadow": "false",
//																		"shadowX": "2",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowSpread": "0",
//																		"shadowColor": "[0,0,0,0.50]"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1G9L3H7SE2",
//																	"attrs": {
//																		"1G9HDVSD80": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1G9L3H7SF0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1G9L3H7SF1",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1G9HDVSD80",
//																			"faceTagName": "startup"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1G9L3H7SF2",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1GH4JH1855",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false"
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1G9DL5TJ56",
//													"attrs": {
//														"1G9HDVSD80": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1G9HEE1EJ8",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1G9HEE1EJ9",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1G9HDVSD80",
//															"faceTagName": "startup"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1G9DL5TJ57",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1GH4JH1856",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "true",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1G9DL447S0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9DL5TJ58",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxInfoBtns",
//														"position": "Absolute",
//														"x": "\"FW\"",
//														"y": "0",
//														"w": "${layout.infoW},layout",
//														"h": "\"FH\"",
//														"anchorH": "Right",
//														"anchorV": "Top",
//														"autoLayout": "true",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[0,0,0,0]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "\"\"",
//														"styleClass": ""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1G9DL5TJ59",
//													"attrs": {
//														"1G9HDVSD80": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1G9HEE1EJ12",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1G9HEE1EJ13",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1G9HDVSD80",
//															"faceTagName": "startup"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1G9DL5TJ510",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1GH4JH1857",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "true",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1G9DL5TJ511",
//									"attrs": {
//										"1G9HE1MK90": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9HEDO1C14",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9HEDO1C15",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9HE1MK90",
//											"faceTagName": "ready"
//										},
//										"1G9HDVSD80": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9HEDO1C16",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9HEDO1C17",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9HDVSD80",
//											"faceTagName": "startup"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1G9DL5TJ512",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1GH4JH1860",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1G9DL61ER0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G9DLD2AC0",
//									"attrs": {
//										"type": "box",
//										"id": "BoxFooter",
//										"position": "Absolute",
//										"x": "0",
//										"y": "\"FH\"",
//										"w": "\"FW\"",
//										"h": "#cfgSize.footerH",
//										"anchorH": "Left",
//										"anchorV": "Bottom",
//										"autoLayout": "true",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "\"\"",
//										"styleClass": "",
//										"background": "#cfgColor.footer",
//										"border": "[1,0,0,0]",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor.lineBodySub",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1G9L1HMKT0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9L1IFV90",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxState",
//														"position": "Absolute",
//														"x": "10",
//														"y": "0",
//														"w": "\"FW-20\"",
//														"h": "\"FH\"",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "true",
//														"display": "On",
//														"clip": "On",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[0,0,0,0]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "\"\"",
//														"styleClass": ""
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1IQ6L43S10",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IQ6LHFB20",
//																	"attrs": {
//																		"type": "text",
//																		"id": "TxtCursor",
//																		"position": "Absolute",
//																		"x": "100%",
//																		"y": "50%",
//																		"w": "100",
//																		"h": "",
//																		"anchorH": "Right",
//																		"anchorV": "Center",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontBodySub\"]",
//																		"text": "-:-",
//																		"font": "",
//																		"fontSize": "#txtSize.smallMid",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Right",
//																		"alignV": "Top",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"lineClamp": "0",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IQ6LHFB21",
//																	"attrs": {}
//																},
//																"functions": {
//																	"jaxId": "1IQ6LHFB22",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1IQ6LHFB23",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true"
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1G9L1IFV91",
//													"attrs": {
//														"1G9HDVSD80": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1GE3MI6IK14",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1GE3MI6IK15",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1G9HDVSD80",
//															"faceTagName": "startup"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1G9L1IFV92",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1GH4JH1861",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1G9DLD2AC1",
//									"attrs": {
//										"1G9HDVSD80": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9HEE1EJ14",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9HEE1EJ15",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9HDVSD80",
//											"faceTagName": "startup"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1G9DLD2AC2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1GH4JH1862",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "true",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1G9DLH6MV0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G9DLTPGU0",
//									"attrs": {
//										"type": "box",
//										"id": "BoxNaviFrame",
//										"position": "Absolute",
//										"x": "0",
//										"y": "#cfgSize.headerH",
//										"w": "${layout.naviW},layout",
//										"h": "#`FH-${cfgSize.headerH+cfgSize.footerH}`",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "true",
//										"display": "On",
//										"clip": "On",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "\"\"",
//										"styleClass": "",
//										"background": "#cfgColor.tool",
//										"border": "[0,1,0,0]",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor.lineBody",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "Gear1G9E2UOKI0",
//											"jaxId": "1G9EIBIBC0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1G9EIO1EA0",
//													"attrs": {
//														"app": "#app",
//														"addOnCode": "NaviTool"
//													}
//												},
//												"properties": {
//													"jaxId": "1G9EIO1EA1",
//													"attrs": {
//														"type": "#null#>ToolView(app,\"NaviTool\")",
//														"id": "TVNavi",
//														"position": "Absolute",
//														"x": "0",
//														"y": "0",
//														"display": "On"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1G9EIO1EA2",
//													"attrs": {
//														"1G9HDVSD80": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1G9HEE1EJ16",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1G9HEE1EJ17",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1G9HDVSD80",
//															"faceTagName": "startup"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1G9EIO1EA3",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1GH4JH1863",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1H7HJ8FR311",
//													"attrs": {}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1G9DLTPGV9",
//									"attrs": {
//										"1G9HDVSD80": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9HEDO1C22",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9HEDO1C23",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9HDVSD80",
//											"faceTagName": "startup"
//										},
//										"1G9HE1MK90": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9HEDO1C24",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9HEDO1C25",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9HE1MK90",
//											"faceTagName": "ready"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1G9DLTPGV10",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1GH4JH1864",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "true",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1G9DM0LS60",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G9DM57220",
//									"attrs": {
//										"type": "box",
//										"id": "BoxInfoFrame",
//										"position": "Absolute",
//										"x": "\"FW\"",
//										"y": "#cfgSize.headerH",
//										"w": "${layout.infoW},layout",
//										"h": "#`FH-${cfgSize.headerH+cfgSize.footerH}`",
//										"anchorH": "Right",
//										"anchorV": "Top",
//										"autoLayout": "true",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "\"\"",
//										"styleClass": "",
//										"background": "#cfgColor.tool",
//										"border": "[0,0,0,1]",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor.lineBodySub",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "Gear1G9E2UOKI0",
//											"jaxId": "1G9EID4G30",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1G9EIO1EA4",
//													"attrs": {
//														"app": "#app",
//														"addOnCode": "InfoTool"
//													}
//												},
//												"properties": {
//													"jaxId": "1G9EIO1EA5",
//													"attrs": {
//														"type": "#null#>ToolView(app,\"InfoTool\")",
//														"id": "TVInfo",
//														"position": "Absolute",
//														"x": "0",
//														"y": "0",
//														"display": "On"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1G9EIO1EA6",
//													"attrs": {
//														"1G9HDVSD80": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1G9HEE1EJ18",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1G9HEE1EJ19",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1G9HDVSD80",
//															"faceTagName": "startup"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1G9EIO1EA7",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1GH4JH1865",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1H7HJ8FR312",
//													"attrs": {}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1G9DM57221",
//									"attrs": {
//										"1G9HE1MK90": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9HEDO1C28",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9HEDO1C29",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9HE1MK90",
//											"faceTagName": "ready"
//										},
//										"1G9HDVSD80": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9HEDO1C30",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9HEDO1C31",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9HDVSD80",
//											"faceTagName": "startup"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1G9DM57222",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1GH4JH1866",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1G9HE4Q8K0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G9HEDO1C32",
//									"attrs": {
//										"type": "box",
//										"id": "BoxCover",
//										"position": "Absolute",
//										"x": "\"FW/2\"",
//										"y": "\"FH/2\"",
//										"w": "\"FH/2\"",
//										"h": "\"FH/2\"",
//										"anchorH": "Center",
//										"anchorV": "Center",
//										"autoLayout": "false",
//										"display": "Off",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "\"\"",
//										"styleClass": "",
//										"background": "#cfgColor.lineBodyLit",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"maskImage": "#appCfg.sharedAssets+\"/prj.svg\""
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1G9HEDO1C33",
//									"attrs": {
//										"1G9HDVSD80": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9HEE1EJ20",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9HEE1EJ21",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9HDVSD80",
//											"faceTagName": "startup"
//										},
//										"1G9HE1MK90": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1G9HEEBSB0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1G9HEEBSB1",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9HE1MK90",
//											"faceTagName": "ready"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1G9HEDO1C34",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1GH4JH1867",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear/@StdUI/ui/BtnSlideSizeX.js",
//							"jaxId": "1GCDMBNRO0",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1GCDMFJBS0",
//									"attrs": {
//										"start": "null",
//										"update": "null",
//										"fin": "null"
//									}
//								},
//								"properties": {
//									"jaxId": "1GCDMFJBS1",
//									"attrs": {
//										"type": "#null#>BtnSlideSizeX(null,null,null)",
//										"id": "SldNavi",
//										"position": "Absolute",
//										"x": "#layout.naviW",
//										"y": "0",
//										"display": "On",
//										"face": "",
//										"autoLayout": "true",
//										"zIndex": "10",
//										"h": "#`FH-${cfgSize.footerH}`"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1GCDMFJBS2",
//									"attrs": {
//										"1G9HDVSD80": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1GE3MI6IK24",
//											"attrs": {
//												"properties": {
//													"jaxId": "1GE3MI6IK25",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9HDVSD80",
//											"faceTagName": "startup"
//										},
//										"1G9HE1MK90": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1GE3MI6IK26",
//											"attrs": {
//												"properties": {
//													"jaxId": "1GE3MI6IK27",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9HE1MK90",
//											"faceTagName": "ready"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1GCDMFJBS3",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1GH4JH1868",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "true",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false",
//								"containerSlots": {
//									"jaxId": "1H7HJ8FR313",
//									"attrs": {}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear/@StdUI/ui/BtnSlideSizeX.js",
//							"jaxId": "1GCDV7T9A0",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1GCDV7T9A1",
//									"attrs": {
//										"start": "null",
//										"update": "null",
//										"fin": "null"
//									}
//								},
//								"properties": {
//									"jaxId": "1GCDV7T9A2",
//									"attrs": {
//										"type": "#null#>BtnSlideSizeX(null,null,null)",
//										"id": "SldInfo",
//										"position": "Absolute",
//										"x": "#`FW-${layout.infoW}`",
//										"y": "0",
//										"display": "On",
//										"face": "",
//										"autoLayout": "true",
//										"zIndex": "10",
//										"h": "#`FH-${cfgSize.footerH}`"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1GCDV7T9A3",
//									"attrs": {
//										"1G9HDVSD80": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1GE3MI6IK28",
//											"attrs": {
//												"properties": {
//													"jaxId": "1GE3MI6IK29",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9HDVSD80",
//											"faceTagName": "startup"
//										},
//										"1G9HE1MK90": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1GE3MI6IK30",
//											"attrs": {
//												"properties": {
//													"jaxId": "1GE3MI6IK31",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1G9HE1MK90",
//											"faceTagName": "ready"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1GCDV7T9A4",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1GH4JH1869",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "true",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false",
//								"containerSlots": {
//									"jaxId": "1H7HJ8FR314",
//									"attrs": {}
//								}
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1G9DJTQHM9",
//					"attrs": {
//						"1G9HDVSD80": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1G9HEE1EJ22",
//							"attrs": {
//								"properties": {
//									"jaxId": "1G9HEE1EJ23",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1G9HDVSD80",
//							"faceTagName": "startup"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1G9DJTQHM10",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1GH4JH18610",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1G9DJTQHM11",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false",
//				"innerLayout": {
//					"valText": "false"
//				},
//				"marginL": {
//					"valText": "false"
//				},
//				"marginR": {
//					"valText": "false"
//				},
//				"marginT": {
//					"valText": "false"
//				},
//				"marginB": {
//					"valText": "false"
//				},
//				"paddingL": {
//					"valText": "false"
//				},
//				"paddingR": {
//					"valText": "false"
//				},
//				"paddingT": {
//					"valText": "false"
//				},
//				"paddingB": {
//					"valText": "false"
//				},
//				"attach": {
//					"valText": "false"
//				},
//				"face": {
//					"type": "bool",
//					"valText": "false"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}