//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnCheck} from "/@StdUI/ui/BtnCheck.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
import {BtnText} from "/@StdUI/ui/BtnText.js";
/*#{1GUROU01U0StartDoc*/
import {aiLocalizeAttr} from "../ai/AILocalizer.js";
import {EditLocLine} from "./EditLocLine.js";

function mergeCode(locs){
	let code,lans,text;
	function packLans(lans){
		let lan,code;
		if(lans.length>1){
			lan=lans.pop();
			text=locs[lan];
			if(text===undefined){
				text=locs["EN"];
			}
			code=`(($ln==="${lan}")?(${text}):${packLans(lans)})`;
		}else{
			lan=lans.pop();
			code=`/*EN*/(${locs[lan]})`
		}
		return code;
	}
	lans=Object.keys(locs);
	return packLans(lans);
};

//--------------------------------------------------------------------
function mergeCodePy(locs){
	let code,lans,text,isPy;
	function packLans(lans){
		let lan,code;
		if(lans.length>1){
			lan=lans.pop();
			text=locs[lan];
			if(text===undefined){
				text=locs["EN"];
			}
			code=`((${text}) if(__Ln=="${lan}") else ${packLans(lans)})`
		}else{
			lan=lans.pop();
			code=`(${locs[lan]})`
		}
		return code;
	}
	lans=Object.keys(locs);
	return packLans(lans);
};

function mergeCodeJSON(locs){
	let code,lans,lan;
	lans=Object.keys(locs);
	code="{";
	for(lan of lans){
		code+='"'+lan+'":'+locs[lan]+",";
	}
	if(code[code.length-1]===","){
		code=code.substring(0,code.length-1);
	}
	code+="}";
	return code;
};

const tsLib=new Map();
/*}#1GUROU01U0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let DlgEditLocString=function(app){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let boxBG,boxLocEdits,cbMerge1,cbMerge2,edMerged,txtAITip,btnBaseLan;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1GUROU01U1LocalVals*/
	let mode,dlgVO,attrObj,curLocs;
	let mergeTimer=null;
	let locEdits={};
	let theLastVO=null;
	/*}#1GUROU01U1LocalVals*/
	
	/*#{1GUROU01U1PreState*/
	/*}#1GUROU01U1PreState*/
	state={
		"baseLan":"EN","mergeMode":"CDN",
		/*#{1GUROU01V4ExState*/
		/*}#1GUROU01V4ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1GUROU01U1PostState*/
	/*}#1GUROU01U1PostState*/
	cssVO={
		"hash":"1GUROU01U1",nameHost:true,
		"type":"hud","x":584,"y":239,"w":500,"h":"","anchorX":2,"anchorY":1,"padding":5,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
		children:[
			{
				"hash":"1GURP1D7G0",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":[255,255,255,1],"border":2,
				"borderColor":cfgColor.fontBodySub,"corner":8,"shadow":true,"shadowX":6,"shadowY":12,"shadowBlur":8,"shadowColor":[0,0,0,0.15],
			},
			{
				"hash":"1GURP4ADU0",
				"type":"text","position":"relative","x":5,"y":0,"w":">calc(100% - 10px)","h":"","uiEvent":-1,"margin":[0,0,5,0],"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","color":cfgColor.fontBodySub,"text":(($ln==="CN")?("编辑本地化"):("Edit Localize")),"fontSize":txtSize.smallBig,"fontWeight":"bold","fontStyle":"normal",
				"textDecoration":"",
			},
			{
				"hash":"1GURP6N600",
				"type":"hud","id":"BoxLocEdits","position":"relative","x":0,"y":0,"w":"100%","h":"","margin":[0,0,5,0],"minW":"","minH":50,"maxW":"","maxH":"","styleClass":"",
				"contentLayout":"flex-y",
			},
			{
				"hash":"1H776DGVG0",
				"type":"hud","id":"BoxMergeMode","position":"relative","x":0,"y":0,"w":"100%","h":30,"padding":[0,10,0,10],"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","contentLayout":"flex-x","itemsAlign":1,
				children:[
					{
						"hash":"1H776FURS0",
						"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","margin":[0,10,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
						"text":(($ln==="CN")?("代码模式:"):("Merge mode:")),"fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
					},
					{
						"hash":"1IA0UJU0V0",
						"type":BtnCheck(20,"",true,true),"id":"CbMerge1","position":"relative","x":0,"y":0,"padding":2,"uiEvent":-1,
						/*#{1IA0UJU0V0Codes*/
						OnCheck(check){
							if(check){
								state.mergeMode="CDN";
								self.genMerge();
								cbMerge2.checked=false;
								cbMerge2.uiEvent=1;
								this.uiEvent=-1;
							}
						}
						/*}#1IA0UJU0V0Codes*/
					},
					{
						"hash":"1H776IJU20",
						"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","margin":[0,10,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
						"text":(($ln==="CN")?("条件判断"):("Condition")),"fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
					},
					{
						"hash":"1IA0UGOKI0",
						"type":BtnCheck(20,"",false,true),"id":"CbMerge2","position":"relative","x":0,"y":0,"padding":2,
						/*#{1IA0UGOKI0Codes*/
						OnCheck(check){
							if(check){
								state.mergeMode="JSON";
								self.genMerge();
								cbMerge1.checked=false;
								cbMerge1.uiEvent=1;
								this.uiEvent=-1;
							}
						}
						/*}#1IA0UGOKI0Codes*/
					},
					{
						"hash":"1H776KM730",
						"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","margin":[0,10,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
						"text":"JSON","fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
					}
				],
			},
			{
				"hash":"1GUV6MIBG0",
				"type":"hud","id":"BoxMerged","position":"relative","x":0,"y":0,"w":"100%","h":"","margin":[0,0,10,0],"padding":[0,10,0,10],"minW":"","minH":30,"maxW":"",
				"maxH":"","styleClass":"","contentLayout":"flex-x",
				children:[
					{
						"hash":"1GUV6ODH50",
						"type":"text","position":"relative","x":0,"y":0,"w":"","h":30,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
						"text":(($ln==="CN")?("生成的:"):("Merged:")),"fontSize":txtSize.smallMid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignH":2,
						"alignV":1,
					},
					{
						"hash":"1GUV6QGEM0",
						"type":"memo","id":"EdMerged","position":"relative","x":0,"y":0,"w":"50%","h":"","minW":"","minH":30,"maxW":"","maxH":100,"styleClass":"","color":cfgColor["fontBody"],
						"fontSize":txtSize.smallMid,"outline":0,"border":[0,0,1,0],"borderColor":[0,0,0,1],"flex":true,
					}
				],
			},
			{
				"hash":"1H82R7U6E0",
				"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":20,"margin":[0,0,5,0],"padding":[0,0,0,10],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"contentLayout":"flex-x","itemsAlign":1,
				children:[
					{
						"hash":"1H82R89SP0",
						"type":"text","id":"TxtAITip","position":"relative","x":0,"y":0,"w":"","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor.fontBodySub,
						"text":(($ln==="CN")?($P(()=>(`AI将根据${state.baseLan}翻译已选语言的文本。`),state)):($P(()=>(`AI will translate checked language text based on: ${state.baseLan}.`),state))),
						"fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
					},
					{
						"hash":"1IA0UAPUV0",
						"type":BtnIcon("front",20,0,appCfg.sharedAssets+"/btncombo.svg",null),"id":"BtnBaseLan","position":"relative","x":0,"y":0,"padding":1,
						"OnClick":function(event){
							/*#{1IA0UDLIK0FunctionBody*/
							self.chooseBaseLan();
							/*}#1IA0UDLIK0FunctionBody*/
						},
					}
				],
			},
			{
				"hash":"1GURP8IDS0",
				"type":"hud","id":"BoxButtons","position":"relative","x":0,"y":0,"w":"100%","h":30,"margin":[0,0,5,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"contentLayout":"flex-x","subAlign":2,"itemsAlign":1,
				children:[
					{
						"hash":"1IA0U6EHA0",
						"type":BtnText("success",100,24,(($ln==="CN")?("AI 翻译"):("AI Translate")),false,""),"position":"relative","x":0,"y":0,"margin":[0,50,0,0],"corner":3,
						"OnClick":function(event){
							/*#{1IA0U6EHA5FunctionBody*/
							self.doAITranslate();
							/*}#1IA0U6EHA5FunctionBody*/
						},
					},
					{
						"hash":"1IA0U4QIJ0",
						"type":BtnText("primary",100,24,(($ln==="CN")?("应用"):("Apply")),false,""),"position":"relative","x":0,"y":0,"margin":[0,20,0,0],"corner":3,
						"OnClick":function(event){
							/*#{1IA0U4QIJ5FunctionBody*/
							self.close(true);
							/*}#1IA0U4QIJ5FunctionBody*/
						},
					},
					{
						"hash":"1IA0U05NK0",
						"type":BtnText("warning",100,24,(($ln==="CN")?("取消"):("Cancel")),false,""),"position":"relative","x":0,"y":0,"margin":[0,20,0,0],"corner":3,
						"OnClick":function(event){
							/*#{1IA0U3SRH0FunctionBody*/
							self.close(false);
							/*}#1IA0U3SRH0FunctionBody*/
						},
					}
				],
			}
		],
		/*#{1GUROU01U1ExtraCSS*/
		/*}#1GUROU01U1ExtraCSS*/
		faces:{
			"locAttr":{
				/*BoxMergeMode*/"#1H776DGVG0":{
					"display":0
				},
				/*BoxMerged*/"#1GUV6MIBG0":{
					"display":0
				},
				/*BoxButtons*/"#1GURP8IDS0":{
					"subAlign":2
				}
			},"locCode":{
				/*BoxMergeMode*/"#1H776DGVG0":{
					"display":1
				},
				/*BoxMerged*/"#1GUV6MIBG0":{
					"display":1
				}
			}
		},
		OnCreate:function(){
			self=this;
			boxBG=self.BoxBG;boxLocEdits=self.BoxLocEdits;cbMerge1=self.CbMerge1;cbMerge2=self.CbMerge2;edMerged=self.EdMerged;txtAITip=self.TxtAITip;btnBaseLan=self.BtnBaseLan;
			/*#{1GUROU01U1Create*/
			VFACT.applyMoveDrag(boxBG,self);
			/*}#1GUROU01U1Create*/
		},
		/*#{1GUROU01U1EndCSS*/
		/*}#1GUROU01U1EndCSS*/
	};
	/*#{1GUROU01U1PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.showDlg=function(vo){
		let hud,rect,x,y,doc,prj,docApp,locAttr;
		let locCode,editLine;
		mode=vo.mode||"locAttr";
		dlgVO=vo;
		theLastVO=null;
		if(mode==="locAttr"){
			self.showFace("locAttr");
			attrObj=vo.attrObj;
			doc=attrObj.owner.doc;
			prj=doc.prj;
			docApp=prj.docApp;
			locAttr=docApp.attrLocalize;
	
			boxLocEdits.clearChildren();
			//Show Edit;
			curLocs=locAttr.attrList.map((attr)=>{return attr.val});
			for(locCode of curLocs){
				editLine=locEdits[locCode];
				if(!editLine){
					editLine=boxLocEdits.appendNewChild(EditLocLine(app));
					editLine.hold();
					locEdits[locCode]=editLine;
					editLine.OnLineFocus=(line)=>{
						state.baseLan=line.lanCode;
						if(mergeTimer){
							clearTimeout(mergeTimer);
						}
						mergeTimer=setTimeout(self.genMerge,1000);
					};
					editLine.OnChanged=function(now){
						if(now){
							self.genMerge();
							return;
						}
						if(mergeTimer){
							clearTimeout(mergeTimer);
						}
						mergeTimer=setTimeout(self.genMerge,1000);
					};
				}else{
					boxLocEdits.appendChild(editLine);
				}
				editLine.startEdit(attrObj,locCode);
			}
		}else if(mode==="locCode"){
			let srcText,stub;
			const testSeg1=`(($ln==="`;
			const testSeg2=`")?(`;
			const testSeg3=`):(($ln==="`;
			const testSeg4=`):/*EN*/(`;
			const testSeg5=`):(`;
			self.showFace("locCode");
			edMerged.text="";
			doc=vo.doc;
			if(doc){
				prj=dlgVO.codyPrj||doc.prj;
				docApp=prj.docApp;
				locAttr=docApp.attrLocalize;
				curLocs=locAttr.attrList.map((attr)=>{return attr.val});
			}else{
				prj=dlgVO.codyPrj;
				if(prj){
				docApp=prj.docApp;
					locAttr=docApp.attrLocalize;
					curLocs=locAttr.attrList.map((attr)=>{return attr.val});
				}else{
					curLocs=["EN","CN","FR","DE","ES","PT","JP"];
				}
			}
			//Show Edit;
			boxLocEdits.clearChildren();
			for(locCode of curLocs){
				editLine=locEdits[locCode];
				if(!editLine){
					editLine=boxLocEdits.appendNewChild(EditLocLine(app));
					editLine.hold();
					locEdits[locCode]=editLine;
					editLine.OnLineFocus=(line)=>{
						state.baseLan=line.lanCode;
					};
					editLine.OnChanged=function(now){
						if(now){
							self.genMerge();
							return;
						}
						if(mergeTimer){
							clearTimeout(mergeTimer);
						}
						mergeTimer=setTimeout(self.genMerge,1000);
					};
				}else{
					boxLocEdits.appendChild(editLine);
				}
				editLine.startEdit(null,locCode);
				editLine.setText(vo.code||vo.text||"");
			}
			state.baseLan="EN";
			srcText=vo.code||vo.text;
			try{
				stub=JSON.parse(srcText);
				if(typeof(stub)!=="object" || !stub.EN){
					stub=null;
				}
			}catch(err){
				stub=null;
			}
			
			if(stub===null && srcText.startsWith(testSeg1)){
				let pos,pos2;
				let lan,cnt,num;
				stub={};
				pos=testSeg1.length;
				num=0;
				do{
					num+=1;
					pos2=srcText.indexOf(testSeg2,pos);
					if(pos2<0){
						break;
					}
					lan=srcText.substring(pos,pos2);
					pos=pos2+testSeg2.length;
					pos2=srcText.indexOf(testSeg3,pos);
					if(pos2<0){//Cnt for EN:
						pos2=srcText.indexOf(testSeg4,pos);
						if(pos2>0){
							cnt=srcText.substring(pos,pos2);
							stub[lan]=cnt;
							cnt=srcText.substring(pos2+testSeg4.length,srcText.length-num-1);
							stub["EN"]=cnt;
						}else{
							pos2=srcText.indexOf(testSeg5,pos);
							if(pos2>0){
								cnt=srcText.substring(pos,pos2);
								stub[lan]=cnt;
								cnt=srcText.substring(pos2+testSeg5.length,srcText.length-num-1);
								stub["EN"]=cnt;
							}else{
								stub=null;
							}
						}
						pos=-1;
					}else{
						cnt=srcText.substring(pos,pos2);
						pos=pos2+testSeg3.length;
						stub[lan]=cnt;
					}
				}while(pos>0);
			}else{
				let lan;
				if(srcText){
					stub=tsLib.get(srcText);
				}
			}
			if(stub){
				let lan;
				for(lan in stub){
					editLine=locEdits[lan];
					if(editLine){
						editLine.setText(stub[lan]);
					}
				}
			}
		}
		
		//Animate show dlg:
		hud=vo.hud;
		if(hud){
			rect=hud.getBoundingClientRect();
			x=rect.x-10;
			y=rect.y+rect.height*0.5;
		}else{
			x=(app.width+500)/2;
			y=app.height/2;
		}
		self.x=x;self.y=y;
		self.animate({type:"in",scale:0.9,alpha:0,time:100});
	};
	
	//------------------------------------------------------------------------
	cssVO.doAITranslate=async function(){
		let locObj,lanCode,editLine,newObj;
		locObj={};
		//Make up orgCode:
		for(lanCode of curLocs){
			editLine=locEdits[lanCode];
			if(editLine.isChecked()){
				locObj[lanCode]=editLine.getText();
			}
		}
		if(!locObj[state.baseLan]){
			return;
		}
		newObj=await aiLocalizeAttr(app,app.aiChat,locObj,state.baseLan);
		if(newObj){
			for(lanCode in newObj){
				editLine=locEdits[lanCode];
				if(editLine){
					editLine.setText(newObj[lanCode]);
				}
			}
			if(mode==="locCode"){
				self.genMerge();
			}
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.genMerge=function(){
		let lanCode,edit;
		let locVO={};
		if(mergeTimer){
			clearTimeout(mergeTimer);
			mergeTimer=null;
		}
		for(lanCode of curLocs){
			edit=locEdits[lanCode];
			if(edit.isChecked()){
				locVO[lanCode]=edit.getText();
			}
		}
		if(state.mergeMode==="CDN"){
			if(dlgVO.sourceType==="Python"){
				edMerged.text=mergeCodePy(locVO);
			}else{
				edMerged.text=mergeCode(locVO);
			}
		}else{
			edMerged.text=mergeCodeJSON(locVO);
		}
		theLastVO=locVO;
	};
	
	//------------------------------------------------------------------------
	cssVO.close=function(applyEdit){
		let lanCode,edit;
		//Apply edits?
		if(applyEdit){
			if(mode==="locAttr"){
				let locVO={};
				for(lanCode of curLocs){
					edit=locEdits[lanCode];
					locVO[lanCode]=edit.getText();
				}
				dlgVO.box.setAttrLocalize(attrObj,locVO,dlgVO.hud);
			}else if(dlgVO.dataDoc && dlgVO.text){//Replace selected text in code?
				let editor,editDoc;
				editDoc=dlgVO.dataDoc;
				if(editDoc){
					editor=editDoc.editBox;
					if(editor && editor.getSelection()===dlgVO.text){
						editor.replaceSelection(edMerged.text);
					}
				}
			}
		}
		if(theLastVO){
			let key=theLastVO.EN;
			if(key && key.length<50){
				tsLib.set(key,theLastVO);
			}
		}
		app.closeDlg(self);
	};
	
	//------------------------------------------------------------------------
	cssVO.chooseBaseLan=function(){
		let items=[],locCode;
		for(locCode of curLocs){
			items.push({text:locCode,code:locCode});
		}
		app.showDlg("/@StdUI/ui/DlgMenu.js",{
			items:items,hud:btnBaseLan,
			callback(item){
				if(!item)
					return;
				state.baseLan=item.code;
			}
		});
	};
	/*}#1GUROU01U1PostCSSVO*/
	cssVO.constructor=DlgEditLocString;
	return cssVO;
};
/*#{1GUROU01U1ExCodes*/
/*}#1GUROU01U1ExCodes*/

//----------------------------------------------------------------------------
DlgEditLocString.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1GUROU01U1PreAISpot*/
	/*}#1GUROU01U1PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1GUROU01U1PostAISpot*/
	/*}#1GUROU01U1PostAISpot*/
	return exposeVO;
};

/*#{1GUROU01U0EndDoc*/
/*}#1GUROU01U0EndDoc*/

export default DlgEditLocString;
export{DlgEditLocString};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1GUROU01U0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1GUROU01V0",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "600",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1GUROU01V1",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1H776M1QR0",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1GUROU01V2",
//			"attrs": {
//				"app": {
//					"type": "auto",
//					"valText": "null"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1GUROU01V3",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1GUROU01V4",
//			"attrs": {
//				"baseLan": {
//					"type": "string",
//					"valText": "EN"
//				},
//				"mergeMode": {
//					"type": "string",
//					"valText": "CDN"
//				}
//			}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1GUROU01V5",
//			"attrs": {
//				"locAttr": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1GUV6KR8S0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1GUV6KR8S1",
//							"attrs": {}
//						}
//					}
//				},
//				"locCode": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1GUV6KR8S2",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1GUV6KR8S3",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1HD33UHUI0",
//			"attrs": {}
//		},
//		"exposeToAI": "true",
//		"descAI": "",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1GUROU01U1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1GUROU01V6",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "584",
//						"y": "239",
//						"w": "500",
//						"h": "\"\"",
//						"anchorH": "Right",
//						"anchorV": "Center",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "5",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Flex Y"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1GURP1D7G0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1GURPOJN50",
//									"attrs": {
//										"type": "box",
//										"id": "BoxBG",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "[255,255,255,1.00]",
//										"border": "2",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor.fontBodySub",
//										"corner": "8",
//										"shadow": "true",
//										"shadowX": "6",
//										"shadowY": "12",
//										"shadowBlur": "8",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.15]"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1GURPOJN51",
//									"attrs": {
//										"1GUV6KR8S0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H77D7GNP0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H77D7GNP1",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1GUV6KR8S0",
//											"faceTagName": "locAttr"
//										},
//										"1GUV6KR8S2": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H7J4BPJN0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H7J4BPJN1",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1GUV6KR8S2",
//											"faceTagName": "locCode"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1GURPOJN52",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1GURPOJN53",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1GURP4ADU0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1GURPOJN54",
//									"attrs": {
//										"type": "text",
//										"id": "",
//										"position": "relative",
//										"x": "5",
//										"y": "0",
//										"w": "100%-10",
//										"h": "\"\"",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,5,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#cfgColor.fontBodySub",
//										"text": {
//											"type": "string",
//											"valText": "编辑本地化",
//											"localize": {
//												"EN": "Edit Localize",
//												"CN": "编辑本地化"
//											},
//											"localizable": true
//										},
//										"font": "",
//										"fontSize": "#txtSize.smallBig",
//										"bold": "true",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Top",
//										"wrap": "false",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0",
//										"autoSizeW": "false",
//										"autoSizeH": "false"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1GURPOJN55",
//									"attrs": {
//										"1GUV6KR8S0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H77D7GNP2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H77D7GNP3",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1GUV6KR8S0",
//											"faceTagName": "locAttr"
//										},
//										"1GUV6KR8S2": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H7J4BPJN2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H7J4BPJN3",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1GUV6KR8S2",
//											"faceTagName": "locCode"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1GURPOJN56",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1GURPOJN57",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1GURP6N600",
//							"attrs": {
//								"properties": {
//									"jaxId": "1GURPOJN58",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxLocEdits",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "\"\"",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,5,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "50",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex Y"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1GURPOJN59",
//									"attrs": {
//										"1GUV6KR8S0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H77D7GNP4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H77D7GNP5",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1GUV6KR8S0",
//											"faceTagName": "locAttr"
//										},
//										"1GUV6KR8S2": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H7J4BPJO0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H7J4BPJO1",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1GUV6KR8S2",
//											"faceTagName": "locCode"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1GURPOJN510",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1GURPOJN511",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1H776DGVG0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H777PEI56",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxMergeMode",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "[0,10,0,10]",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex X",
//										"itemsAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1H776FURS0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H776IIN80",
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "\"\"",
//														"h": "\"\"",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[0,10,0,0]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBody\"]",
//														"text": {
//															"type": "string",
//															"valText": "代码模式:",
//															"localize": {
//																"EN": "Merge mode:",
//																"CN": "代码模式:"
//															},
//															"localizable": true
//														},
//														"font": "",
//														"fontSize": "#txtSize.smallMid",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0",
//														"autoSizeW": "false",
//														"autoSizeH": "false"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1H776IIN81",
//													"attrs": {
//														"1GUV6KR8S0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H77D7GNP6",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1H77D7GNP7",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1GUV6KR8S0",
//															"faceTagName": "locAttr"
//														},
//														"1GUV6KR8S2": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H7J4BPJO2",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1H7J4BPJO3",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1GUV6KR8S2",
//															"faceTagName": "locCode"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1H776IIN82",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1H776IIN83",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnCheck.js",
//											"jaxId": "1IA0UJU0V0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1IA0UJU0V1",
//													"attrs": {
//														"size": "20",
//														"text": "",
//														"checked": "true",
//														"radio": "true"
//													}
//												},
//												"properties": {
//													"jaxId": "1IA0UJU0V2",
//													"attrs": {
//														"type": "#null#>BtnCheck(20,\"\",true,true)",
//														"id": "CbMerge1",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"padding": "2",
//														"uiEvent": "Tree Off"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IA0UJU0V3",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1IA0UJU0V4",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IA0UJU0V5",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "true",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1IA0UJU0V6",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1H776IJU20",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H776IJU21",
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "\"\"",
//														"h": "\"\"",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[0,10,0,0]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBody\"]",
//														"text": {
//															"type": "string",
//															"valText": "条件判断",
//															"localize": {
//																"EN": "Condition",
//																"CN": "条件判断"
//															},
//															"localizable": true
//														},
//														"font": "",
//														"fontSize": "#txtSize.smallMid",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0",
//														"autoSizeW": "false",
//														"autoSizeH": "false"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1H776IJU22",
//													"attrs": {
//														"1GUV6KR8S0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H77D7GNP10",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1H77D7GNP11",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1GUV6KR8S0",
//															"faceTagName": "locAttr"
//														},
//														"1GUV6KR8S2": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H7J4BPJO6",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1H7J4BPJO7",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1GUV6KR8S2",
//															"faceTagName": "locCode"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1H776IJU23",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1H776IJU24",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnCheck.js",
//											"jaxId": "1IA0UGOKI0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1IA0UIN1G0",
//													"attrs": {
//														"size": "20",
//														"text": "",
//														"checked": "false",
//														"radio": "true"
//													}
//												},
//												"properties": {
//													"jaxId": "1IA0UIN1G1",
//													"attrs": {
//														"type": "#null#>BtnCheck(20,\"\",false,true)",
//														"id": "CbMerge2",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"padding": "2"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IA0UIN1G2",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1IA0UIN1G3",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IA0UIN1G4",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "true",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1IA0UIN1G5",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1H776KM730",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H776KM731",
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "\"\"",
//														"h": "\"\"",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[0,10,0,0]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBody\"]",
//														"text": "JSON",
//														"font": "",
//														"fontSize": "#txtSize.smallMid",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0",
//														"autoSizeW": "false",
//														"autoSizeH": "false"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1H776KM732",
//													"attrs": {
//														"1GUV6KR8S0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H77D7GNP14",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1H77D7GNP15",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1GUV6KR8S0",
//															"faceTagName": "locAttr"
//														},
//														"1GUV6KR8S2": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H7J4BPJO10",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1H7J4BPJO11",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1GUV6KR8S2",
//															"faceTagName": "locCode"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1H776KM733",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1H776KM734",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1H777PEI57",
//									"attrs": {
//										"1GUV6KR8S0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H7782CJJ16",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H7782CJJ17",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1GUV6KR8S0",
//											"faceTagName": "locAttr"
//										},
//										"1GUV6KR8S2": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H7782CJJ18",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H7782CJJ19",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1GUV6KR8S2",
//											"faceTagName": "locCode"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1H777PEI58",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H777PEI59",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1GUV6MIBG0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1GUV71AUQ0",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxMerged",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "\"\"",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,10,0]",
//										"padding": "[0,10,0,10]",
//										"minW": "",
//										"minH": "30",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex X"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1GUV6ODH50",
//											"attrs": {
//												"properties": {
//													"jaxId": "1GUV71AUQ1",
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"w": "\"\"",
//														"h": "30",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBody\"]",
//														"text": {
//															"type": "string",
//															"valText": "生成的:",
//															"localize": {
//																"EN": "Merged:",
//																"CN": "生成的:"
//															},
//															"localizable": true
//														},
//														"font": "",
//														"fontSize": "#txtSize.smallMid",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Right",
//														"alignV": "Center",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0",
//														"autoSizeW": "false",
//														"autoSizeH": "false"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1GUV71AUQ2",
//													"attrs": {
//														"1GUV6KR8S0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H77D7GNP16",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1H77D7GNP17",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1GUV6KR8S0",
//															"faceTagName": "locAttr"
//														},
//														"1GUV6KR8S2": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H7J4BPJO12",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1H7J4BPJO13",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1GUV6KR8S2",
//															"faceTagName": "locCode"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1GUV71AUQ3",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1GUV71AUQ4",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "memo",
//											"jaxId": "1GUV6QGEM0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1GUV71AUQ5",
//													"attrs": {
//														"type": "memo",
//														"id": "EdMerged",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "50%",
//														"h": "\"\"",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "30",
//														"maxW": "",
//														"maxH": "100",
//														"face": "",
//														"styleClass": "",
//														"text": "",
//														"color": "#cfgColor[\"fontBody\"]",
//														"bgColor": "[255,255,255,1.00]",
//														"font": "",
//														"fontSize": "#txtSize.smallMid",
//														"outline": "0",
//														"border": "[0,0,1,0]",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"readOnly": "false",
//														"selectOnFocus": "true",
//														"spellCheck": "true",
//														"flex": "true"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1GUV71AUQ6",
//													"attrs": {
//														"1GUV6KR8S0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H77D7GNP18",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1H77D7GNP19",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1GUV6KR8S0",
//															"faceTagName": "locAttr"
//														},
//														"1GUV6KR8S2": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H7J4BPJO14",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1H7J4BPJO15",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1GUV6KR8S2",
//															"faceTagName": "locCode"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1GUV71AUQ7",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1GUV71AUQ8",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1GUV71AUQ9",
//									"attrs": {
//										"1GUV6KR8S0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1GUV7GU182",
//											"attrs": {
//												"properties": {
//													"jaxId": "1GUV7GU183",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1GUV6KR8S0",
//											"faceTagName": "locAttr"
//										},
//										"1GUV6KR8S2": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1GUV7GU184",
//											"attrs": {
//												"properties": {
//													"jaxId": "1GUV7GU185",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1GUV6KR8S2",
//											"faceTagName": "locCode"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1GUV71AUQ10",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1GUV71AUQ11",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1H82R7U6E0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H82RFM8D0",
//									"attrs": {
//										"type": "hud",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "20",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,5,0]",
//										"padding": "[0,0,0,10]",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex X",
//										"itemsAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1H82R89SP0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H82R89SP1",
//													"attrs": {
//														"type": "text",
//														"id": "TxtAITip",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "\"\"",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[0,0,0,0]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor.fontBodySub",
//														"text": {
//															"type": "string",
//															"valText": "${`AI将根据${state.baseLan}翻译已选语言的文本。`},state",
//															"localize": {
//																"EN": "${`AI will translate checked language text based on: ${state.baseLan}.`},state",
//																"CN": "${`AI将根据${state.baseLan}翻译已选语言的文本。`},state"
//															},
//															"localizable": true
//														},
//														"font": "",
//														"fontSize": "#txtSize.small",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0",
//														"autoSizeW": "false",
//														"autoSizeH": "false"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1H82R89SP2",
//													"attrs": {
//														"1GUV6KR8S0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H82R89SP3",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1H82R89SP4",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1GUV6KR8S0",
//															"faceTagName": "locAttr"
//														},
//														"1GUV6KR8S2": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1H82R89SP5",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1H82R89SP6",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1GUV6KR8S2",
//															"faceTagName": "locCode"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1H82R89SP7",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1H82R89SP8",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1IA0UAPUV0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1IA0UDS340",
//													"attrs": {
//														"style": "\"front\"",
//														"w": "20",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/btncombo.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1IA0UDS341",
//													"attrs": {
//														"type": "#null#>BtnIcon(\"front\",20,0,appCfg.sharedAssets+\"/btncombo.svg\",null)",
//														"id": "BtnBaseLan",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"padding": "1"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IA0UDS342",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1IA0UDS343",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1IA0UDLIK0",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1IA0UDS344",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1IA0UDS345",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1IA0UDS346",
//													"attrs": {}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1H82RFM8D8",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1H82RFM8D9",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1H82RFM8D10",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1GURP8IDS0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1GURPOJN512",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxButtons",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,5,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"attach": "true",
//										"contentLayout": "Flex X",
//										"subAlign": "End",
//										"itemsAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnText.js",
//											"jaxId": "1IA0U6EHA0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1IA0U6EHA1",
//													"attrs": {
//														"style": "success",
//														"w": "100",
//														"h": "24",
//														"text": {
//															"type": "string",
//															"valText": "AI 翻译",
//															"localize": {
//																"EN": "AI Translate",
//																"CN": "AI 翻译"
//															},
//															"localizable": true
//														},
//														"outlined": "false",
//														"icon": ""
//													}
//												},
//												"properties": {
//													"jaxId": "1IA0U6EHA2",
//													"attrs": {
//														"type": "#null#>BtnText(\"success\",100,24,(($ln===\"CN\")?(\"AI 翻译\"):(\"AI Translate\")),false,\"\")",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"margin": "[0,50,0,0]",
//														"corner": "3"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IA0U6EHA3",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1IA0U6EHA4",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1IA0U6EHA5",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1IA0U6EHA6",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1IA0U6EHA7",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1IA0U6EHA8",
//													"attrs": {
//														"Slot1H2F6U36O0": {
//															"jaxId": "1IA0U6EHA9",
//															"attrs": {
//																"subHuds": {
//																	"attrs": []
//																},
//																"container": "true"
//															}
//														}
//													}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnText.js",
//											"jaxId": "1IA0U4QIJ0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1IA0U4QIJ1",
//													"attrs": {
//														"style": "primary",
//														"w": "100",
//														"h": "24",
//														"text": {
//															"type": "string",
//															"valText": "应用",
//															"localize": {
//																"EN": "Apply",
//																"CN": "应用"
//															},
//															"localizable": true
//														},
//														"outlined": "false",
//														"icon": ""
//													}
//												},
//												"properties": {
//													"jaxId": "1IA0U4QIJ2",
//													"attrs": {
//														"type": "#null#>BtnText(\"primary\",100,24,(($ln===\"CN\")?(\"应用\"):(\"Apply\")),false,\"\")",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"margin": "[0,20,0,0]",
//														"corner": "3"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IA0U4QIJ3",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1IA0U4QIJ4",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1IA0U4QIJ5",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1IA0U4QIJ6",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1IA0U4QIJ7",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1IA0U4QIJ8",
//													"attrs": {
//														"Slot1H2F6U36O0": {
//															"jaxId": "1IA0U4QIJ9",
//															"attrs": {
//																"subHuds": {
//																	"attrs": []
//																},
//																"container": "true"
//															}
//														}
//													}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnText.js",
//											"jaxId": "1IA0U05NK0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1IA0U3SRQ0",
//													"attrs": {
//														"style": "warning",
//														"w": "100",
//														"h": "24",
//														"text": {
//															"type": "string",
//															"valText": "取消",
//															"localize": {
//																"EN": "Cancel",
//																"CN": "取消"
//															},
//															"localizable": true
//														},
//														"outlined": "false",
//														"icon": ""
//													}
//												},
//												"properties": {
//													"jaxId": "1IA0U3SRQ1",
//													"attrs": {
//														"type": "#null#>BtnText(\"warning\",100,24,(($ln===\"CN\")?(\"取消\"):(\"Cancel\")),false,\"\")",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"margin": "[0,20,0,0]",
//														"corner": "3"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IA0U3SRQ2",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1IA0U3SRQ3",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1IA0U3SRH0",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1IA0U3SRQ4",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1IA0U3SRQ5",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1IA0U3SRQ6",
//													"attrs": {
//														"Slot1H2F6U36O0": {
//															"jaxId": "1IA0U3SRQ7",
//															"attrs": {
//																"subHuds": {
//																	"attrs": []
//																},
//																"container": "true"
//															}
//														}
//													}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1GURPOJN513",
//									"attrs": {
//										"1GUV6KR8S0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1GUV6LU4G28",
//											"attrs": {
//												"properties": {
//													"jaxId": "1GUV6LU4G29",
//													"attrs": {
//														"subAlign": {
//															"type": "choice",
//															"valText": "End"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1GUV6KR8S0",
//											"faceTagName": "locAttr"
//										},
//										"1GUV6KR8S2": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1H7J4BPJO22",
//											"attrs": {
//												"properties": {
//													"jaxId": "1H7J4BPJO23",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1GUV6KR8S2",
//											"faceTagName": "locCode"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1GURPOJN514",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1GURPOJN515",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1GUROU01V7",
//					"attrs": {
//						"1GUV6KR8S0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H77D7GNP26",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H77D7GNP27",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1GUV6KR8S0",
//							"faceTagName": "locAttr"
//						},
//						"1GUV6KR8S2": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1H7J4BPJO24",
//							"attrs": {
//								"properties": {
//									"jaxId": "1H7J4BPJO25",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1GUV6KR8S2",
//							"faceTagName": "locCode"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1GUROU01V8",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1GUROU01V9",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1GUROU01V10",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false",
//				"innerLayout": {
//					"valText": "false"
//				},
//				"marginL": {
//					"valText": "false"
//				},
//				"marginR": {
//					"valText": "false"
//				},
//				"marginT": {
//					"valText": "false"
//				},
//				"marginB": {
//					"valText": "false"
//				},
//				"paddingL": {
//					"valText": "false"
//				},
//				"paddingR": {
//					"valText": "false"
//				},
//				"paddingT": {
//					"valText": "false"
//				},
//				"paddingB": {
//					"valText": "false"
//				},
//				"attach": {
//					"valText": "false"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}