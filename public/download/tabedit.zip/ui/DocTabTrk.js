//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1G9EHTP730StartDoc*/
import {DocTabBtn} from "./DocTabBtn.js";
/*}#1G9EHTP730StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let DocTabTrk=function(app,w){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1G9EHTP737LocalVals*/
	let appPrj=app.prj;
	let dataDocs=app.docs;
	let curTab=null;
	let tabHash=new Map();
	let isDragging=0;
	/*}#1G9EHTP737LocalVals*/
	
	/*#{1G9EHTP737PreState*/
	let placeHolder=null;
	let tabWebObjs=null;
	let boxTabs=null;
	/*}#1G9EHTP737PreState*/
	/*#{1G9EHTP737PostState*/
	/*}#1G9EHTP737PostState*/
	cssVO={
		"hash":"1G9EHTP737",nameHost:true,
		"type":"hud","x":0,"y":0,"w":w,"h":"FH","autoLayout":true,"overflow":1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
		children:[
			{
				"hash":"1GDIVGMGI0",
				"type":"hud","id":"BoxTabs","x":0,"y":0,"w":"","h":"FH","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
			}
		],
		/*#{1G9EHTP737ExtraCSS*/
		/*}#1G9EHTP737ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			self=this;
			
			/*#{1G9EHTP737Create*/
			if(dataDocs){
				self.bind2Docs(dataDocs);
			}
			self.removeChild(self.BoxTabs);//Remove it
			boxTabs=self;
			placeHolder=boxTabs.appendNewChild({"type":"hud",x:0,y:0,w:0,h:"FH","autoLayout":true,position:"relative",margin:[0,1,0,1]});
			placeHolder.hold();
			boxTabs.removeChild(placeHolder);
			tabWebObjs=boxTabs.webObj.children;
			//self.webObj.style.transition="scroll-left 80ms";//Make some animations
			self.webObj.onwheel=function(e){
				let dx,dy;
				if(e.deltaMode!==0){
					return;
				}
				dx=e.deltaX;
				dy=e.deltaY;
				if(dx===0 && dy){
					dy=dy>20?20:dy;
					dy=dy<-20?-20:dy;
					dx=-dy;
				}
				//boxTabs.x+=dx;
				self.webObj.scrollLeft-=dx;
			};
			if(appPrj){
				appPrj.getTabDocs=function(){
					let children,i,n,tab,list;
					list=[];
					children=self.children;
					n=children.length;
					for(i=0;i<n;i++){
						tab=children[i];
						list.push(tab.doc.path);
					}
					return list;
				};
			}
			/*}#1G9EHTP737Create*/
		},
		/*#{1G9EHTP737EndCSS*/
		/*}#1G9EHTP737EndCSS*/
	};
	/*#{1G9EHTP737PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.bind2Docs=function(docs){
		dataDocs=docs;
		dataDocs.on("NewDoc",self.OnNewDoc);
		dataDocs.on("CloseDoc",self.OnCloseDoc);
		dataDocs.on("BlurDoc",self.OnBlurDoc);
		dataDocs.on("FocusDoc",self.OnFocusDoc);
		dataDocs.on("PinDoc",self.OnPinDoc);
	};
	
	//------------------------------------------------------------------------
	cssVO.OnNewDoc=function(doc){
		let tab;
		if(curTab){
			let nxtTab;
			nxtTab=curTab.nextSibling;
			if(nxtTab){
				tab=boxTabs.insertNewBefore(DocTabBtn(app,doc,self),nxtTab);
			}else{
				tab=boxTabs.appendNewChild(DocTabBtn(app,doc,self));
			}
		}else{
			tab=boxTabs.appendNewChild(DocTabBtn(app,doc,self));
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.OnFocusDoc=function(doc){
		let tab;
		if(curTab){
			if(curTab.doc===doc){
				return;
			}
			curTab.showFace("blur");
		}
		if(!doc){
			curTab=null;
			return;
		}
		tab=doc.tabBox;
		curTab=tab;
		if(doc.tempOpen){
			tab.showFace("temp");
		}else{
			tab.showFace("focus");
		}
		self.showTab(tab);
		if(!isDragging){
			doc.tabFocused();
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.OnPinDoc=function(doc){
		let tab;
		if(curTab){
			if(curTab.doc===doc){
				curTab.showFace("focus");
				return;
			}
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.OnBlurDoc=function(doc){
		//TODO: Do nothing?
	};
	
	//------------------------------------------------------------------------
	cssVO.OnCloseDoc=function(doc){
		let tab;
		tab=doc.tabBox;
		if(tab){
			boxTabs.removeChild(tab);
			if(tab===curTab){
				curTab=null;
			}
		}
	};
	
	//************************************************************************
	//Drag and drop related:
	//************************************************************************
	{
		let dragOrgX;
		//--------------------------------------------------------------------
		cssVO.dragTabStart=function(tab){
			let x;
			x=tab.webObj.offsetLeft-1;
			placeHolder.w=tab.w;
			boxTabs.insertBefore(placeHolder,tab);
			tab.display=0;
			tab.position="absolute";
			dragOrgX=x;
			tab.x=x;
			boxTabs.appendChild(tab);
			tab.display=1;
			isDragging=1;
		};
	
		//--------------------------------------------------------------------
		cssVO.dragTab=function(dragTab,dx,dy){
			let x,tab,tabs,i,n,tabx1,tabx2,webObj,center,preTab,nxtTab;
			x=dragOrgX+dx;
			dragTab.x=x;
			x+=dragTab.w*0.5;
			tabs=tabWebObjs;
			n=tabs.length;
			for(i=0;i<n;i++){
				webObj=tabs[i];
				tabx1=webObj.offsetLeft;
				tabx2=tabx1+webObj.offsetWidth;
				if(tabx1>x){
					//TODO: 
					return;
				}
				if(tabx1<=x && tabx2>x){
					tab=webObj.$_pxy;
					if(tab===placeHolder){
						return;
					}
					center=(tabx1+tabx2)*0.5;
					if(center>x){
						preTab=tab.previousSibling;
						if(preTab===placeHolder){
							return;
						}
						boxTabs.insertBefore(placeHolder,tab);
						return;
					}else{
						nxtTab=tab.nextSibling;
						if(nxtTab===placeHolder){
							return;
						}
						boxTabs.insertBefore(placeHolder,nxtTab);
						return;
					}
					break;
				}
			}
			boxTabs.appendChild(placeHolder);
		};
		
		//--------------------------------------------------------------------
		cssVO.dragTabEnd=function(dragTab,dx,dy){
			let dataDoc;
			dragTab.display=0;
			dragTab.position="relative";
			dragTab.x=0;
			boxTabs.insertBefore(dragTab,placeHolder);
			boxTabs.removeChild(placeHolder);
			dragTab.display=1;
			isDragging=0;
		};
		
	}
	
	//------------------------------------------------------------------------
	cssVO.showTab=function(tab,retry=0){
		let tabX,tabW,tabRect,trkRect,trkX,trkW,dx;
		tabRect=tab.getBoundingClientRect();
		trkRect=self.getBoundingClientRect();
		if(!trkRect.height && retry<3){
			setTimeout(()=>{this.showTab(tab,retry>0?retry+1:1);},1000);
		}
		tabX=tabRect.x;tabW=tabRect.width;
		trkX=trkRect.x;trkW=trkRect.width;
		if(tabX<trkX){
			dx=trkX-tabX;
			//boxTabs.x+=dx;
			self.webObj.scrollLeft-=dx;
		}else if(tabX+tabW>trkX+trkW){
			dx=tabX+tabW-(trkX+trkW);
			//boxTabs.x-=dx;
			self.webObj.scrollLeft+=dx;
		}
	}
	/*}#1G9EHTP737PostCSSVO*/
	cssVO.constructor=DocTabTrk;
	return cssVO;
};
/*#{1G9EHTP737ExCodes*/
/*}#1G9EHTP737ExCodes*/

//----------------------------------------------------------------------------
DocTabTrk.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1G9EHTP737PreAISpot*/
	/*}#1G9EHTP737PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1G9EHTP737PostAISpot*/
	/*}#1G9EHTP737PostAISpot*/
	return exposeVO;
};

//----------------------------------------------------------------------------
DocTabTrk.gearExport={
	framework: "vfact",
	hudType: "hud",
	"showName":"",icon:"gears.svg",previewImg:false,
	fixPose:false,initW:100,initH:100,
	catalog:"Views",
	args: {
		"app": {
			"name": "app", "showName": "app", "type": "auto", "key": true, "fixed": true, 
			"initVal": null
		}, 
		"w": {
			"name": "w", "showName": "w", "type": "auto", "key": true, "fixed": true, "initVal": "FW"
		}
	},
	state:{
	},
	properties:["id","position","x","y","display"],
	faces:[],
	subContainers:{
	},
	/*#{1G9EHTP730ExGearInfo*/
	/*}#1G9EHTP730ExGearInfo*/
};
/*#{1G9EHTP730EndDoc*/
/*}#1G9EHTP730EndDoc*/

export default DocTabTrk;
export{DocTabTrk};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1G9EHTP730",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1G9EHTP731",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "30",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1G9EHTP732",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1IHT3IQRO0",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1G9EHTP733",
//			"attrs": {
//				"app": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"w": {
//					"type": "auto",
//					"valText": "\"FW\""
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1G9EHTP734",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1G9EHTP735",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "VFACT document",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "Views",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1G9EHTP736",
//			"attrs": {}
//		},
//		"mockupStates": {
//			"jaxId": "1IHT3IQRO1",
//			"attrs": {}
//		},
//		"exposeToAI": "true",
//		"descAI": "",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1G9EHTP737",
//			"attrs": {
//				"properties": {
//					"jaxId": "1G9EHTP738",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "#w",
//						"h": "\"FH\"",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "true",
//						"display": "On",
//						"clip": "On",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "[0,0,0,0]",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "\"\"",
//						"styleClass": "",
//						"contentLayout": "Flex X"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1GDIVGMGI0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1GDIVHB880",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxTabs",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "\"\"",
//										"h": "\"FH\"",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "\"\"",
//										"styleClass": "",
//										"contentLayout": "Flex X"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1GDIVHB881",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1GDIVHB882",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IHT3IQRP0",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1G9EHTP739",
//					"attrs": {}
//				},
//				"functions": {
//					"jaxId": "1G9EHTP7310",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1IHT3IQRP1",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1G9EHTP7311",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false",
//				"innerLayout": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"face": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"marginL": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"marginR": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"marginT": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"marginB": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"paddingL": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"paddingT": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"paddingR": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"paddingB": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"attach": {
//					"type": "bool",
//					"valText": "false"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}