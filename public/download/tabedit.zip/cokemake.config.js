import {tabFS} from "/@tabos";
import pathLib from "/@path";
import terser from "/@terser/cokemake-plugin.js";
import terserRorllup from "/@terser/rollup-plugin.js";
//----------------------------------------------------------------------------
//Make dev with HRM:
let dist={
	steps:[
		{
			action:"clean",
			dirs:["dist"]
		},
		{
			action:"copy",
			files:{
				"/tabedit/disk.json":"dist/"
			},
		},
		{
			action:"clean",
			dirs:["/tabedit"]
		},
		/*
		{
			action:"rollup",
			config:{
				input:["./app.js","./edlit.js","./playground.js"],
				external:[/\/@/],
				output:{
					format:"es",
					exportDir:"dist",
				},
				plugins:[
					{
						name:"importPatch",
						renderChunk: async function(code, chunk, outputOptions) {
							code=code.replaceAll("import('../@","import('/@");
							code=code.replaceAll(`import("../@`,`import("/@`);
							return code;
						},					
					},
					terserRorllup()
				]
			}
		},*/
		{
			action:"copy",
			dirs:{
				".":"/tabedit",
				"dist":"/tabedit",
			},
			/*
			files:{
				"app.html":"/tabedit/",
				"tabedit.css":"/tabedit/",
				"app.config.js":"/tabedit/",
				"edlit.html":"/tabedit/",
				"playground.html":"/tabedit/",
				"testchat.html":"/tabedit/",
				"favicon.svg":"/tabedit/",
				"prj.svg":"/tabedit/",
				"lab.svg":"/tabedit/",
				"aichat.svg":"/tabedit/",
				"tip.md":"/tabedit/",
				"tip_cn.md":"/tabedit/",
				"playground.md":"/tabedit/",
				"playground_cn.md":"/tabedit/",
				"marks.md":"/tabedit/",
				"marks_cn.md":"/tabedit/",
				"license.txt":"/tabedit/",
			}*/
		},
		{
			action:"clean",
			dirs:["dist"]
		},
	],
	options:{
	}
};
export default dist;
export {dist};

