### Edit Pad tips

#### Edit Pad:
This is a lite-weighted text/ code editor. To start and work on app/ web projects, use the "Project" app.

#### Under construction:
This editor is still under coding. More features incomming.

#### Shortcut keys:
- Switch docs: `Alt+tab`/`Ctrl+~(The key on left of key "1")`
- Save doc: `Cmd+S`
- Save doc as: `Shift+Cmd+S`
- Copy: `Cmd+C`(macOS)/`Ctrl+C`(PC)
- Paste: `Cmd+V`(macOS)/`Ctrl+V`(PC)
- Undo: `Cmd+Z`(macOS)/`Ctrl+Z`(PC)
- Redo: `Shift+Cmd+Z`,`Cmd+Y`(macOS)/`Shift+Ctrl+V`,`Ctrl+Y`(PC)
- Find: `Cmd+F`(macOS)/`Ctrl+F`(PC)
- Find Next: `Cmt+G`(macOS)/`Ctrl+G`(PC)
- Replace: `Cmd+Alt+F`(macOS)/`Ctrl+Alt+F`(PC)

