## Tab Studio Addons

### The AddOn API object:
- To get the AddOn API object: `import {AddOn} from "/@tabedit";`

- AddOn.regAddOns:

- AddOn.regAddOn(catalog, def, init=false): register one addon, **def** can be a string (path to import addon-script) or an object. If **def** is a string and **!!init** is true, will import the addon script.


### Catalog "NaviTool" / "InfoTool":
- Each addon def is a UI-Def-function: (app)=>{}:UI-Def-Object.

- **def.tbxIcon**: the icon path of the view

- **def.tbxTip**: the show name of the view

- **def.tbxCode**: the code-name of the view, can be used in mainUI.showToolBox(codeName);

### Catalog "Project":
- "Project" addon is used to add features/properties to the app-project-object of TabStudio.

- Each Project-AddOn registered to AddOn system should be a addOn function: (dataPrj)=>{...}.

- When called, the add-on-function can add properties and functions into the app-project-object and **add more addons to the AddOn object**.

### Catalog "DocReader": TBD

### Catalog "DocSaver": TBD