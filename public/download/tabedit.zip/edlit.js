import {tabOS,tabFS,tabTask} from "/@tabos";
import {VFACT} from "/@vfact";
import {} from "/@vfact/vfact_app.js";
import {appCfg} from "./cfg/appCfg.js";
import {} from "/@homekit/cfg/appCfg.js";
import {AppLib} from "/@homekit/data/AppLib.js";
import pathLib from "/@path";
import {UIEdLit} from "./ui/UIEdLit.js";
import {DlgTask} from "/@homekit/ui/DlgTask.js";
import {DataDocs} from "./data/DataDoc.js";
import {DataAIChat} from "./data/DataAIChat.js";
//Prefix extern-lib's appCfgs:
{
	let cfgs,name;
	cfgs=window.codyAppCfgs;
	for(name in cfgs){
		cfgs[name].applyCfg();
	}
}
//----------------------------------------------------------------------------
//Start the app:
async function startApp() {
	let app,uiDef,mode;
	
	document.title="Playground";
	//------------------------------------------------------------------------
	//Check if we are in appFrame:
	let appFrame=null;
	//CheckAppFrame:
	{
		let pw;
		appFrame=null;
		pw=window.parent;
		if(pw!==window){
			if(pw.getAppFrame){
				appFrame=window.appFrame=pw.getAppFrame(window);
			}
		}
	}
	window.tabOSApp=app=await VFACT.createApp();
	mode=VFACT.appParams.mode||"edit";
	
	app.docs=new DataDocs();
	if(mode==="playground"){
		app.docs.usagePath="/doc/playground/recent.json";
	}
	
	app.userOpts={
		IndentSize:4,
		UseTab:true,
		AutoIndent:true,
		TabSize:4,
		LineNum:true,
	};
	app.aiChat=new DataAIChat();
	
	//setup open (openPath, openMeta...) API:
	await AppLib.setupOpenAPI(app,appFrame);

	uiDef=UIEdLit(app,appFrame,mode);
	if(!appFrame){
		uiDef=AppLib.setupMiniDocker(app,uiDef);
	}
	//init app, create app UI tree:
	await VFACT.initApp(app,uiDef,{
		wait:1,
		shortcuts:appCfg.shortcuts,
		DlgTask:DlgTask,
		appFrame:appFrame,
	});
}
tabOS.allowRoot=true;
tabOS.setup().then(()=>{startApp();});
