import pathLib from "/@path";
import {VFACT} from "/@vfact";
let url=import.meta.url;
let dir=pathLib.dirname(url);
const $ln=VFACT.lanCode;
export default [
	{
		type:"app",
		name:"EditPad",
		caption:(($ln==="CN")?("编辑板"):/*EN*/("Edit Pad")),
		main:dir+`/edlit.html`,
		package:"tabedit",
		catalog:["System"],
		icon:`${dir}/favicon.svg`,
		iconApp:null,
		appFrame:{
			//main:document.location.origin+`//tabedit/edlit.html`,
			main:dir+`/edlit.html`,
			group:`${dir}/editlit.html`,
			title:(($ln==="CN")?("编辑板"):/*EN*/("Edit Pad")),
			icon:`${dir}/favicon.svg`,
			multiFrame:true,
			width:800,height:800,
			maxable:false,
		},
		acceptFileType:{
			"edit":[".js",".mjs",".json",".css",".jsx",".ts",".html",".htm",".svg",".md",".c",".cpp",".h",".hpp",".py",".ini",".inf",".link",".sh",".conflict"],
			"open":[".js",".mjs",".json",".css",".jsx",".ts",".svg",".c",".cpp",".h",".hpp",".py",".ini",".inf",".link",".conflict"]
		}
	},
	{
		type:"app",
		name:"Playground",
		caption:(($ln==="CN")?("代码实验室"):/*EN*/("Playground")),
		main:dir+`/playground.html`,
		package:"tabedit",
		catalog:["System"],
		icon:`${dir}/lab.svg`,
		iconApp:null,
		appFrame:{
			main:dir+`/playground.html`,
			group:`${dir}/playgorund.html`,
			title:(($ln==="CN")?("代码实验室"):/*EN*/("Playground")),
			icon:`${dir}/lab.svg`,
			multiFrame:false,
			width:1000,height:800,
			maxable:true,
		},
		acceptFileType:{
			"edit":[".aichat",".pghtml"],
			"open":[".aichat",".pghtml"]
		}
	},
	{
		type:"app",
		name:"TabStudio",
		caption:"Tab-OS IDE",
		main:dir+`/app.html`,
		//main:document.location.origin+`//tabedit/app.html`,
		package:"tabedit",
		catalog:["Dev."],
		icon:`${dir}/prj.svg`,
		iconApp:null,
		acceptFileType:{
			"edit":[".project.json"],
			"open":[".project.json"]
		}
	},
];
