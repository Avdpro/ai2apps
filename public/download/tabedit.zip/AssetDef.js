const assetDef={
	"ref": "Reference implementation",
	"api": "API contract",
	"schema": "Data model spec",
	"ctx": "Existing code context",
	"stub": "Interface stub",
	"deps": "Dependency usage examples",
	"image": "Image file",
	"audio": "Audio file",
	"video": "Vudio file",

	"pov": "Project overview",
	"req": "Product requirements",
	"arch": "Architecture doc",
	"mech": "Mechanism spec",
	"why": "Design rationale",

	"conf": "Runtime config",
	"build": "Build instructions",
	"dev": "Local dev setup",
	"deploy": "Deployment notes",
	"compat": "Compatibility matrix",

	"style": "Coding standards",
	"sec": "Security guidelines",
	"perf": "Performance constraints",

	"tplan": "Test plan",
	"fx": "Test fixtures",
	"gold": "Golden outputs",
	"repro": "Bug repro steps",

	"log": "Actual log files / runtime output",
	"trace": "Stack traces / tracing / profiling outputs",
	"lspec": "Logging spec",

	"metric": "Metrics spec",
	"pm": "Incident postmortem",

	"ui": "UI assets",
	"i18n": "i18n resources",
	"prompt": "Prompt templates",
	"data": "Sample data",

	"rmap": "Roadmap context"
};
let assetDefItems=[];
for(let key in assetDef){
	assetDefItems.push({text:`${assetDef[key]}: [${key}]`,code:key});
}
export default assetDef;
export {assetDef,assetDefItems};