//Auto genterated by Cody
import {VFACT} from "/@vfact";
/*#{Imports*/
/*}#Imports*/
var cfgURL=import.meta.url+"1G9DJJECJ0;"
/*#{StartDoc*/
function isDarkMode() {
	return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
}
VFACT.loadConfig("TabOS-Config");
VFACT.darkMode=false;
if(VFACT.lanCode===null){
	let userLanguages = navigator.languages || [navigator.language || navigator.userLanguage];
	let userLanguage = userLanguages[0];
	let languageCode = userLanguage.substring(0, 2).toUpperCase();
	switch(languageCode){
		case "ZH":
			languageCode="CN";
			break;
	}
	VFACT.lanCode=languageCode;
}
/*}#StartDoc*/
let darkMode=false;
let colors={
	"primary":[13,110,253,1],"secondary":[108,117,125,1],"success":[0,128,0,1],"warning":[255,128,12,1],"error":[240,0,0,1]
};
darkMode=VFACT.darkMode===null?darkMode:VFACT.darkMode;
VFACT.darkMode=darkMode;
if(!window.codyAppCfgs){
	window.codyAppCfgs={};
}
/*#{StartObj*/
/*}#StartObj*/
//----------------------------------------------------------------------------
let appCfg=window.codyAppCfgs[cfgURL]||{//"jaxId":"1G9DJJECJ2"
	"darkMode":darkMode,"version":"0.6.0",
	"txtSize":{
		"small":12,"mid":16,"big":20,"smallMid":14,"smallBig":18,"smallLarge":24,"large":28,"smallLarger":32,"larger":36,"smallHuge":42,"huge":48,"bigHuge":56,
		"smallHuger":64,"huger":72,"bigHuger":80,"smallPlus":14,"midPlus":18,"bigPlus":25,"largePlus":35,"hugePlus":50
	},
	"size":{
		"menuLineH":24,"pathLineH":24,"dockerW":90,"dockerWMini":50,"dlgHeaderH":20,"headerH":30,"footerH":25
	},
	"color":{
		"body":darkMode?[36,38,45,1]:[255,255,255,1.00],"primary":colors.primary,"secondary":colors.secondary,"success":colors.success,"warning":colors.warning,
		"front":darkMode?[255,255,255,1]:[0,0,0,1.00],"error":colors.error,"fontBody":darkMode?[228,228,230,1]:[0,0,0,1.00],"fontBodySub":darkMode?[190,190,193,1.00]:[80,80,80,1.00],
		"fontBodyLit":darkMode?[110,110,115,1]:[180,180,180,1.00],"fontPrimary":[255,255,255,1],"fontPrimarySub":[...colors.primary,80],"fontPrimaryLit":[...colors.primary,40],
		"fontSecondary":[255,255,255,1],"fontSecondarySub":[...colors.secondary,80.00],"fontSecondaryLit":[...colors.secondary,40.00],"fontSuccess":[255,255,255,1],
		"fontSuccessSub":[...colors.success,80.00],"fontSuccessLit":[...colors.success,40.00],"fontWarning":[255,255,255,1],"fontWarningSub":[...colors.warning,80],
		"fontWarningLit":[...colors.warning,40],"fontError":[255,255,255,1],"fontErrorSub":[...colors.error,80],"fontErrorLit":[...colors.error,40],"fontFront":darkMode?[0,0,0,1]:[255,255,255,1.00],
		"fontFrontSub":darkMode?[80,80,80,1]:[240,240,240,1.00],"fontFrontLit":darkMode?[240,240,240,1]:[80,80,80,1.00],"lineBody":darkMode?[255,255,255,1]:[0,0,0,1.00],
		"lineBodySub":darkMode?[255,255,255,1]:[0,0,0,1.00],"lineBodyLit":darkMode?[120,120,120,1]:[180,180,180,1.00],"itemOver":darkMode?[255,255,255,0.1]:[0,0,0,0.1],
		"itemDown":darkMode?[255,255,255,0.4]:[0,0,0,0.2],"itemFocus":darkMode?[...colors.primary,-20]:[...colors.primary,80],"itemGray":darkMode?[80,80,80,1]:[200,200,200,1.00],
		"gntFocus":darkMode?"linear-gradient(to right, rgba(190,220,255,0.3), 50%, rgba(220,240,255,0.0))":"linear-gradient(to right, rgba(190,220,2550,1), 50%, rgba(220,240,255,0.5))",
		"subFocus":darkMode?"linear-gradient(to right, rgba(250,250,250,0.2), 50%, rgba(250,250,250,0.05))":"linear-gradient(to right, rgba(0,0,0,0.2), 50%, rgba(0,0,0,0.05))",
		"menuBG":darkMode?[12,12,12,1]:[243,243,242,1.00],"disable":[200,200,200,1],"fontDisable":[255,255,255,1],"fontDisableSub":[244,244,244,1],"fontDisableLit":[227.5,227.5,227.5,1],
		"iconBtnOver":[206.6,226,254.6,1],"iconBtnDown":[158.2,197,254.2,1],"iconBtnUp":[255,255,255,0],"hot":darkMode?[50,70,95,1]:[220,240,255,1],"iconFace":[50,50,50,1],
		"tabTrack":darkMode?[105,100,95,1.00]:[180,185,190,1.00],"gntSelected":"linear-gradient(to right, rgba(220,220,220,1), 50%, rgba(220,220,220,0.1))",
		"gntSelect":"linear-gradient(to right, rgba(220,220,220,1), 50%, rgba(220,220,220,0.1))","gntDlgHeader":"linear-gradient(to right, rgba(35,105,200,1), 60%, rgba(220,240,255,1.0), 95%, rgba(220,240,255,1.0))",
		"gntHotText":"linear-gradient(to right, rgba(190,220,255,0),rgba(190,220,255,1), rgba(190,220,255,1),rgba(220,240,255,0.0))","tool":darkMode?[75,75,75,1]:[240,240,240,1],
		"fontTool":darkMode?[240,240,240,1,100]:[240,240,240,1,-100],"fontToolSub":darkMode?[240,240,240,1,60]:[240,240,240,1,-60],"fontToolLit":darkMode?[240,240,240,1,30]:[240,240,240,1,-30],
		"head":darkMode?[60,60,60,1.00]:[230,230,230,1.00],"footer":darkMode?[85,85,85,1]:[220,220,220,1],"gntLineBreak":"linear-gradient(to right, rgba(0,0,0,1),rgba(0,0,0,1), rgba(0,0,0,0))"
	},
	"sharedAssets":"/~/-tabos/shared/assets","assetsDir":"/@homekit/assets",
	"desktopColors":{
		"0":[220,220,220,1],"1":[50,100,160,1],"2":[220,150,80,1],"3":[50,110,55,1],"4":[255,255,255,1]
	},
	"desktopColorIdx":0,
	"dockerColors":{
		"0":[82,94,107,1],"1":[198,77,13,1],"2":[15,107,34,11]
	},
	"shortcuts":{
	},
	"dockerColor":{
		"0":82,"1":94,"2":107,"3":1
	},
	"lanCode":"CN","isAI2Apps":true,
	"colorDK":{
		"body":[255,255,255,1],"primary":[13,110,253,1],"fontPrimary":[255,255,255,1],"fontPrimarySub":[206.6,226,254.6,1],"fontPrimaryLit":[134,182.5,254,1],
		"secondary":[108,117,125,1],"fontSecondary":[255,255,255,1],"fontSecondarySub":[225.6,227.4,229,1],"fontSecondaryLit":[181.5,186,190,1],"fontBody":[0,0,0,1],
		"fontBodySub":[80,80,80,1],"fontBodyLit":[180,180,180,1],"lineBody":[0,0,0,1],"lineBodySub":[80,80,80,1],"lineBodyLit":[180,180,180,1],"success":[0,128,0,1],
		"fontSuccess":[255,255,255,1],"fontSuccessSub":[204,229.6,204,1],"fontSuccessLit":[127.5,191.5,127.5,1],"warning":[255,128,12,1],"fontWarning":[255,255,255,1],
		"fontWarningSub":[255,229.6,206.4,1],"fontWarningLit":[255,191.5,133.5,1],"disable":[200,200,200,1],"fontDisable":[255,255,255,1],"fontDisableSub":[244,244,244,1],
		"fontDisableLit":[227.5,227.5,227.5,1],"error":[240,0,0,1],"fontError":[255,255,255,1],"fontErrorSub":[252,204,204,1],"fontErrorLit":[247.5,127.5,127.5,1],
		"iconBtnOver":[206.6,226,254.6,1],"iconBtnDown":[158.2,197,254.2,1],"iconBtnUp":[255,255,255,0],"hot":[220,240,255,1],"iconFace":[50,50,50,1],"gntFocus":"linear-gradient(to right, rgba(190,220,2550,1), 50%, rgba(220,240,255,0.5))",
		"gntSelected":"linear-gradient(to right, rgba(220,220,220,1), 50%, rgba(220,220,220,0.1))","gntSelect":"linear-gradient(to right, rgba(220,220,220,1), 50%, rgba(220,220,220,0.1))",
		"gntDlgHeader":"linear-gradient(to right, rgba(35,105,200,1), 60%, rgba(220,240,255,1.0), 95%, rgba(220,240,255,1.0))","gntHotText":"linear-gradient(to right, rgba(190,220,255,0),rgba(190,220,255,1), rgba(190,220,255,1),rgba(220,240,255,0.0))",
		"tool":[240,240,240,1],"fontTool":[0,0,0,1],"fontToolSub":[96,96,96,1],"fontToolLit":[168,168,168,1],"gntLineBreak":"linear-gradient(to right, rgba(0,0,0,1),rgba(0,0,0,1), rgba(0,0,0,0))",
		"head":[230,230,230,1],"footer":[220,220,220,1],"tabTrack":[180,185,190,1],"front":[0,0,0,1],"fontFront":[255,255,255,1],"fontFrontSub":[240,240,240,1],
		"fontFrontLit":[80,80,80,1],"itemOver":[0,0,0,0.1],"itemDown":[0,0,0,0.2],"itemFocus":[13,110,253,1,80],"itemGray":[200,200,200,1],"subFocus":"linear-gradient(to right, rgba(0,0,0,0.2), 50%, rgba(0,0,0,0.05))",
		"menuBG":[243,243,242,1]
	},
	/*#{ExAttrs*/
	/*}#ExAttrs*/
};
window.codyAppCfgs[cfgURL]=appCfg;
appCfg.lanCode=VFACT.lanCode===null?"CN":(VFACT.lanCode||"EN");
VFACT.lanCode=appCfg.lanCode;
if(!VFACT.appCfg){
	VFACT.appCfg=appCfg;
	window.jaxAppCfg=appCfg;
}
appCfg.applyCfg=function(){
	let majorCfg,attrName,cAttr,mAttr;
	majorCfg=VFACT.appCfg||window.jaxAppCfg;
	if(majorCfg && majorCfg!==appCfg){
		for(attrName in appCfg){
			if(attrName in majorCfg){
				cAttr=appCfg[attrName];
				mAttr=majorCfg[attrName];
				if(typeof(cAttr)==="object"){
					if(typeof(mAttr)==="object"){
						Object.assign(cAttr,mAttr);
					}
				}else if(attrName!=="applyCfg" && attrName!=="proxyCfg"){
					appCfg[attrName]=mAttr;
				}
			}
		}
	}
};
appCfg.proxyCfg=function(proxy){
	if(window.codyAppCfgs[cfgURL]===appCfg){
		window.codyAppCfgs[cfgURL]=proxy;
	}
	appCfg=proxy;
};

/*#{EndDoc*/

appCfg.shortcuts={
	"KeyS": [
		{
			"action": "Save", "shiftKey": false, "metaKey": true, "ctrlKey": false, "altKey": false
		},{        
			"action": "Save", "shiftKey": false, "metaKey": false, "ctrlKey": true, "altKey": false
		},{
			"action": "SaveAs", "shiftKey": true, "metaKey": true, "ctrlKey": false, "altKey": false
		},{
			"action": "SaveAs", "shiftKey": true, "metaKey": false, "ctrlKey": true, "altKey": false
		}
	],
	"87": {
		"action": "Close", "altKey": true, "ctrlKey": false, "metaKey": false, "shiftKey": false
	},
	"KeyO":[
		{
			"action": "Open", "shiftKey": false, "metaKey": false, "ctrlKey": true, "altKey": false
		},{
			"action": "Open", "shiftKey": true, "metaKey": true, "ctrlKey": false, "altKey": false
		}
	],
	"KeyN":[
		{
			"action": "NewDoc", "shiftKey": false, "metaKey": false, "ctrlKey": true, "altKey": false
		},{
			"action": "NewDoc", "shiftKey": true, "metaKey": true, "ctrlKey": false, "altKey": false
		}
	],
	"KeyB": [
		{
			"action": "Sync", "altKey": false, "ctrlKey": false, "metaKey": true, "shiftKey": false
		},
		{
			"action": "Sync", "altKey": false, "ctrlKey": true, "metaKey": false, "shiftKey": false
		},
	],
	"KeyC": [
		{
			"action": "Copy", "altKey": false, "ctrlKey": false, "metaKey": true, "shiftKey": false
		},
		{
			"action": "Copy", "altKey": false, "ctrlKey": true, "metaKey": false, "shiftKey": false
		},
	],
	"KeyX": [
		{
			"action": "Cut", "altKey": false, "ctrlKey": false, "metaKey": true, "shiftKey": false
		},
		{
			"action": "Cut", "altKey": false, "ctrlKey": true, "metaKey": false, "shiftKey": false
		},
	],
	"KeyV": [
		{
			"action": "Paste", "altKey": false, "ctrlKey": false, "metaKey": true, "shiftKey": false
		},
		{
			"action": "Paste", "altKey": false, "ctrlKey": true, "metaKey": false, "shiftKey": false
		},
	],
	"KeyZ": [
		{
			"action": "Undo", "altKey": false, "ctrlKey": false, "metaKey": true, "shiftKey": false
		},{
			"action": "Redo", "altKey": false, "ctrlKey": false, "metaKey": true, "shiftKey": true
		},
		{
			"action": "Undo", "altKey": false, "ctrlKey": true, "metaKey": false, "shiftKey": false
		},{
			"action": "Redo", "altKey": false, "ctrlKey": true, "metaKey": false, "shiftKey": true
		},
	],
	"KeyK":[
		{
			"action": "AIChat", "altKey": false, "ctrlKey": false, "metaKey": true, "shiftKey": false
		},
		{
			"action": "AIChat", "altKey": false, "ctrlKey": true, "metaKey": false, "shiftKey": false
		},
	],
	"KeyJ":[
		{
			"action": "AICode", "altKey": false, "ctrlKey": false, "metaKey": true, "shiftKey": false
		},
		{
			"action": "AICode", "altKey": false, "ctrlKey": true, "metaKey": false, "shiftKey": false
		},
	],
	"Escape":{
		"action": "Escape", "altKey": false, "ctrlKey": false, "metaKey": false, "shiftKey": false
	},
	"Backspace":{
		"action": "Delete", "altKey": false, "ctrlKey": false, "metaKey": false, "shiftKey": false
	},
	"Space":{
		"action": "HitSpace", "altKey": false, "ctrlKey": false, "metaKey": false, "shiftKey": false
	},
	"Delete":{
		"action": "Delete", "altKey": false, "ctrlKey": false, "metaKey": false, "shiftKey": false
	},
	"ArrowUp":[
		{
			"action": "MoveUp", "altKey": false, "ctrlKey": false, "metaKey": false, "shiftKey": false
		},
		{
			"action": "MoveUpMore", "altKey": false, "ctrlKey": false, "metaKey": false, "shiftKey": true
		}
	],
	"ArrowDown":[
		{
			"action": "MoveDown", "altKey": false, "ctrlKey": false, "metaKey": false, "shiftKey": false
		},
		{
			"action": "MoveDownMore", "altKey": false, "ctrlKey": false, "metaKey": false, "shiftKey": true
		}
	],
	"ArrowLeft":[
		{
			"action": "MoveLeft", "altKey": false, "ctrlKey": false, "metaKey": false, "shiftKey": false
		},
		{
			"action": "MoveLeftMore", "altKey": false, "ctrlKey": false, "metaKey": false, "shiftKey": true
		}
	],
	"ArrowRight":[
		{
			"action": "MoveRight", "altKey": false, "ctrlKey": false, "metaKey": false, "shiftKey": false
		},
		{
			"action": "MoveRightMore", "altKey": false, "ctrlKey": false, "metaKey": false, "shiftKey": true
		}
	]
};
/*}#EndDoc*/

export{appCfg};
/*Cody Project Doc*/
//{
//	"jaxId": "1G9DJJECJ0",
//	"attrs": {
//		"localVars": {
//			"jaxId": "1G9DJJECJ6",
//			"attrs": {
//				"darkMode": "false",
//				"colors": {
//					"type": "object",
//					"def": "Object",
//					"jaxId": "1IA48KMBD0",
//					"attrs": {
//						"primary": {
//							"type": "colorRGBA",
//							"valText": "[13,110,253,1]"
//						},
//						"secondary": {
//							"type": "colorRGBA",
//							"valText": "[108,117,125,1]"
//						},
//						"success": {
//							"type": "colorRGBA",
//							"valText": "[0,128,0,1.00]"
//						},
//						"warning": {
//							"type": "colorRGBA",
//							"valText": "[255,128,12,1]"
//						},
//						"error": {
//							"type": "colorRGBA",
//							"valText": "[240,0,0,1.00]"
//						}
//					}
//				}
//			}
//		},
//		"editObjs": {
//			"jaxId": "1G9DJJECJ1",
//			"attrs": {
//				"appCfg": {
//					"jaxId": "1G9DJJECJ2",
//					"attrs": {
//						"darkMode": "#darkMode",
//						"version": "0.6.0",
//						"txtSize": {
//							"jaxId": "1G9DJJECJ3",
//							"attrs": {
//								"small": "12",
//								"mid": "16",
//								"big": "20",
//								"smallMid": {
//									"type": "auto",
//									"valText": "14"
//								},
//								"smallBig": {
//									"type": "auto",
//									"valText": "18"
//								},
//								"smallLarge": {
//									"type": "auto",
//									"valText": "24"
//								},
//								"large": {
//									"type": "auto",
//									"valText": "28"
//								},
//								"smallLarger": {
//									"type": "auto",
//									"valText": "32"
//								},
//								"larger": {
//									"type": "auto",
//									"valText": "36"
//								},
//								"smallHuge": {
//									"type": "auto",
//									"valText": "42"
//								},
//								"huge": {
//									"type": "auto",
//									"valText": "48"
//								},
//								"bigHuge": {
//									"type": "auto",
//									"valText": "56"
//								},
//								"smallHuger": {
//									"type": "auto",
//									"valText": "64"
//								},
//								"huger": {
//									"type": "auto",
//									"valText": "72"
//								},
//								"bigHuger": {
//									"type": "auto",
//									"valText": "80"
//								},
//								"smallPlus": {
//									"valText": "14"
//								},
//								"midPlus": {
//									"valText": "18"
//								},
//								"bigPlus": {
//									"valText": "25"
//								},
//								"largePlus": {
//									"valText": "35"
//								},
//								"hugePlus": {
//									"valText": "50"
//								}
//							}
//						},
//						"size": {
//							"jaxId": "1G9DJJECJ4",
//							"attrs": {
//								"menuLineH": {
//									"type": "auto",
//									"valText": "24"
//								},
//								"pathLineH": {
//									"type": "auto",
//									"valText": "24"
//								},
//								"dockerW": {
//									"type": "auto",
//									"valText": "90"
//								},
//								"dockerWMini": {
//									"type": "auto",
//									"valText": "50"
//								},
//								"dlgHeaderH": {
//									"type": "auto",
//									"valText": "20"
//								},
//								"headerH": {
//									"type": "int",
//									"valText": "30"
//								},
//								"footerH": {
//									"type": "int",
//									"valText": "25"
//								}
//							}
//						},
//						"color": {
//							"jaxId": "1G9DJJECJ5",
//							"attrs": {
//								"body": {
//									"type": "colorRGBA",
//									"valText": "#darkMode?[36,38,45,1]:[255,255,255,1.00]"
//								},
//								"primary": {
//									"type": "colorRGBA",
//									"valText": "#colors.primary"
//								},
//								"secondary": {
//									"type": "colorRGBA",
//									"valText": "#colors.secondary"
//								},
//								"success": {
//									"type": "colorRGBA",
//									"valText": "#colors.success"
//								},
//								"warning": {
//									"type": "colorRGBA",
//									"valText": "#colors.warning"
//								},
//								"front": {
//									"type": "colorRGBA",
//									"valText": "#darkMode?[255,255,255,1]:[0,0,0,1.00]"
//								},
//								"error": {
//									"type": "colorRGBA",
//									"valText": "#colors.error"
//								},
//								"fontBody": {
//									"type": "colorRGBA",
//									"valText": "#darkMode?[228,228,230,1]:[0,0,0,1.00]"
//								},
//								"fontBodySub": {
//									"type": "colorRGBA",
//									"valText": "#darkMode?[190,190,193,1.00]:[80,80,80,1.00]"
//								},
//								"fontBodyLit": {
//									"type": "colorRGBA",
//									"valText": "#darkMode?[110,110,115,1]:[180,180,180,1.00]"
//								},
//								"fontPrimary": {
//									"type": "colorRGBA",
//									"valText": "[255,255,255,1]"
//								},
//								"fontPrimarySub": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.primary,80]"
//								},
//								"fontPrimaryLit": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.primary,40]"
//								},
//								"fontSecondary": {
//									"type": "colorRGBA",
//									"valText": "[255,255,255,1]"
//								},
//								"fontSecondarySub": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.secondary,80.00]"
//								},
//								"fontSecondaryLit": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.secondary,40.00]"
//								},
//								"fontSuccess": {
//									"type": "colorRGBA",
//									"valText": "[255,255,255,1]"
//								},
//								"fontSuccessSub": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.success,80.00]"
//								},
//								"fontSuccessLit": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.success,40.00]"
//								},
//								"fontWarning": {
//									"type": "colorRGBA",
//									"valText": "[255,255,255,1]"
//								},
//								"fontWarningSub": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.warning,80]"
//								},
//								"fontWarningLit": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.warning,40]"
//								},
//								"fontError": {
//									"type": "colorRGBA",
//									"valText": "[255,255,255,1]"
//								},
//								"fontErrorSub": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.error,80]"
//								},
//								"fontErrorLit": {
//									"type": "colorRGBA",
//									"valText": "#[...colors.error,40]"
//								},
//								"fontFront": {
//									"type": "colorRGBA",
//									"valText": "#darkMode?[0,0,0,1]:[255,255,255,1.00]"
//								},
//								"fontFrontSub": {
//									"type": "colorRGBA",
//									"valText": "#darkMode?[80,80,80,1]:[240,240,240,1.00]"
//								},
//								"fontFrontLit": {
//									"type": "colorRGBA",
//									"valText": "#darkMode?[240,240,240,1]:[80,80,80,1.00]"
//								},
//								"lineBody": {
//									"type": "colorRGBA",
//									"valText": "#darkMode?[255,255,255,1]:[0,0,0,1.00]"
//								},
//								"lineBodySub": {
//									"type": "colorRGBA",
//									"valText": "#darkMode?[255,255,255,1]:[0,0,0,1.00]"
//								},
//								"lineBodyLit": {
//									"type": "colorRGBA",
//									"valText": "#darkMode?[120,120,120,1]:[180,180,180,1.00]"
//								},
//								"itemOver": {
//									"type": "colorRGBA",
//									"valText": "#darkMode?[255,255,255,0.1]:[0,0,0,0.1]"
//								},
//								"itemDown": {
//									"type": "colorRGBA",
//									"valText": "#darkMode?[255,255,255,0.4]:[0,0,0,0.2]"
//								},
//								"itemFocus": {
//									"type": "colorRGBA",
//									"valText": "#darkMode?[...colors.primary,-20]:[...colors.primary,80]"
//								},
//								"itemGray": {
//									"type": "colorRGBA",
//									"valText": "#darkMode?[80,80,80,1]:[200,200,200,1.00]"
//								},
//								"gntFocus": {
//									"type": "colorRGBA",
//									"valText": "#darkMode?\"linear-gradient(to right, rgba(190,220,255,0.3), 50%, rgba(220,240,255,0.0))\":\"linear-gradient(to right, rgba(190,220,2550,1), 50%, rgba(220,240,255,0.5))\""
//								},
//								"subFocus": {
//									"type": "colorRGBA",
//									"valText": "#darkMode?\"linear-gradient(to right, rgba(250,250,250,0.2), 50%, rgba(250,250,250,0.05))\":\"linear-gradient(to right, rgba(0,0,0,0.2), 50%, rgba(0,0,0,0.05))\""
//								},
//								"menuBG": {
//									"type": "colorRGBA",
//									"valText": "#darkMode?[12,12,12,1]:[243,243,242,1.00]"
//								},
//								"disable": {
//									"type": "colorRGBA",
//									"valText": "[200,200,200,1]"
//								},
//								"fontDisable": {
//									"type": "colorRGBA",
//									"valText": "[255,255,255,1]"
//								},
//								"fontDisableSub": {
//									"type": "colorRGBA",
//									"valText": "[200,200,200,1,80]"
//								},
//								"fontDisableLit": {
//									"type": "colorRGBA",
//									"valText": "[200,200,200,1,50]"
//								},
//								"iconBtnOver": {
//									"type": "colorRGBA",
//									"valText": "[13,110,253,1,80]"
//								},
//								"iconBtnDown": {
//									"type": "colorRGBA",
//									"valText": "[13,110,253,1,60]"
//								},
//								"iconBtnUp": {
//									"type": "colorRGBA",
//									"valText": "[255,255,255,0]"
//								},
//								"hot": {
//									"type": "colorRGBA",
//									"valText": "#darkMode?[50,70,95,1]:[220,240,255,1]"
//								},
//								"iconFace": {
//									"type": "colorRGBA",
//									"valText": "[50,50,50,1]"
//								},
//								"tabTrack": {
//									"type": "colorRGBA",
//									"valText": "#darkMode?[105,100,95,1.00]:[180,185,190,1.00]"
//								},
//								"gntSelected": {
//									"type": "string",
//									"valText": "linear-gradient(to right, rgba(220,220,220,1), 50%, rgba(220,220,220,0.1))"
//								},
//								"gntSelect": {
//									"type": "string",
//									"valText": "linear-gradient(to right, rgba(220,220,220,1), 50%, rgba(220,220,220,0.1))"
//								},
//								"gntDlgHeader": {
//									"type": "string",
//									"valText": "linear-gradient(to right, rgba(35,105,200,1), 60%, rgba(220,240,255,1.0), 95%, rgba(220,240,255,1.0))"
//								},
//								"gntHotText": {
//									"type": "string",
//									"valText": "linear-gradient(to right, rgba(190,220,255,0),rgba(190,220,255,1), rgba(190,220,255,1),rgba(220,240,255,0.0))"
//								},
//								"tool": {
//									"type": "colorRGBA",
//									"valText": "#darkMode?[75,75,75,1]:[240,240,240,1]"
//								},
//								"fontTool": {
//									"type": "colorRGBA",
//									"valText": "#darkMode?[240,240,240,1,100]:[240,240,240,1,-100]"
//								},
//								"fontToolSub": {
//									"type": "colorRGBA",
//									"valText": "#darkMode?[240,240,240,1,60]:[240,240,240,1,-60]"
//								},
//								"fontToolLit": {
//									"type": "colorRGBA",
//									"valText": "#darkMode?[240,240,240,1,30]:[240,240,240,1,-30]"
//								},
//								"head": {
//									"type": "colorRGBA",
//									"valText": "#darkMode?[60,60,60,1.00]:[230,230,230,1.00]"
//								},
//								"footer": {
//									"type": "colorRGBA",
//									"valText": "#darkMode?[85,85,85,1]:[220,220,220,1]"
//								},
//								"gntLineBreak": {
//									"valText": "\"linear-gradient(to right, rgba(0,0,0,1),rgba(0,0,0,1), rgba(0,0,0,0))\""
//								}
//							}
//						},
//						"sharedAssets": {
//							"type": "auto",
//							"valText": "\"/~/-tabos/shared/assets\""
//						},
//						"assetsDir": {
//							"type": "auto",
//							"valText": "\"/@homekit/assets\""
//						},
//						"desktopColors": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1G9DJKUMV0",
//							"attrs": {
//								"0": {
//									"type": "auto",
//									"valText": "[220,220,220,1]"
//								},
//								"1": {
//									"type": "auto",
//									"valText": "[50,100,160,1]"
//								},
//								"2": {
//									"type": "auto",
//									"valText": "[220,150,80,1]"
//								},
//								"3": {
//									"type": "auto",
//									"valText": "[50,110,55,1]"
//								},
//								"4": {
//									"type": "auto",
//									"valText": "[255,255,255,1]"
//								}
//							}
//						},
//						"desktopColorIdx": {
//							"type": "auto",
//							"valText": "0"
//						},
//						"dockerColors": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1G9DJKUMV1",
//							"attrs": {
//								"0": {
//									"type": "auto",
//									"valText": "[82,94,107,1]"
//								},
//								"1": {
//									"type": "auto",
//									"valText": "[198,77,13,1]"
//								},
//								"2": {
//									"type": "auto",
//									"valText": "[15,107,34,11]"
//								}
//							}
//						},
//						"shortcuts": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1G9G7397V0",
//							"attrs": {}
//						},
//						"dockerColor": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1GMGPEHJE0",
//							"attrs": {
//								"0": {
//									"valText": "82"
//								},
//								"1": {
//									"valText": "94"
//								},
//								"2": {
//									"valText": "107"
//								},
//								"3": {
//									"valText": "1"
//								}
//							}
//						},
//						"lanCode": {
//							"valText": "\"CN\""
//						},
//						"isAI2Apps": {
//							"valText": "true"
//						},
//						"colorDK": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1IA48KMBE0",
//							"attrs": {
//								"body": {
//									"valText": "[255,255,255,1]"
//								},
//								"primary": {
//									"valText": "[13,110,253,1]"
//								},
//								"fontPrimary": {
//									"valText": "[255,255,255,1]"
//								},
//								"fontPrimarySub": {
//									"valText": "[206.6,226,254.6,1]"
//								},
//								"fontPrimaryLit": {
//									"valText": "[134,182.5,254,1]"
//								},
//								"secondary": {
//									"valText": "[108,117,125,1]"
//								},
//								"fontSecondary": {
//									"valText": "[255,255,255,1]"
//								},
//								"fontSecondarySub": {
//									"valText": "[225.6,227.4,229,1]"
//								},
//								"fontSecondaryLit": {
//									"valText": "[181.5,186,190,1]"
//								},
//								"fontBody": {
//									"valText": "[0,0,0,1]"
//								},
//								"fontBodySub": {
//									"valText": "[80,80,80,1]"
//								},
//								"fontBodyLit": {
//									"valText": "[180,180,180,1]"
//								},
//								"lineBody": {
//									"valText": "[0,0,0,1]"
//								},
//								"lineBodySub": {
//									"valText": "[80,80,80,1]"
//								},
//								"lineBodyLit": {
//									"valText": "[180,180,180,1]"
//								},
//								"success": {
//									"valText": "[0,128,0,1]"
//								},
//								"fontSuccess": {
//									"valText": "[255,255,255,1]"
//								},
//								"fontSuccessSub": {
//									"valText": "[204,229.6,204,1]"
//								},
//								"fontSuccessLit": {
//									"valText": "[127.5,191.5,127.5,1]"
//								},
//								"warning": {
//									"valText": "[255,128,12,1]"
//								},
//								"fontWarning": {
//									"valText": "[255,255,255,1]"
//								},
//								"fontWarningSub": {
//									"valText": "[255,229.6,206.4,1]"
//								},
//								"fontWarningLit": {
//									"valText": "[255,191.5,133.5,1]"
//								},
//								"disable": {
//									"valText": "[200,200,200,1]"
//								},
//								"fontDisable": {
//									"valText": "[255,255,255,1]"
//								},
//								"fontDisableSub": {
//									"valText": "[244,244,244,1]"
//								},
//								"fontDisableLit": {
//									"valText": "[227.5,227.5,227.5,1]"
//								},
//								"error": {
//									"valText": "[240,0,0,1]"
//								},
//								"fontError": {
//									"valText": "[255,255,255,1]"
//								},
//								"fontErrorSub": {
//									"valText": "[252,204,204,1]"
//								},
//								"fontErrorLit": {
//									"valText": "[247.5,127.5,127.5,1]"
//								},
//								"iconBtnOver": {
//									"valText": "[206.6,226,254.6,1]"
//								},
//								"iconBtnDown": {
//									"valText": "[158.2,197,254.2,1]"
//								},
//								"iconBtnUp": {
//									"valText": "[255,255,255,0]"
//								},
//								"hot": {
//									"valText": "[220,240,255,1]"
//								},
//								"iconFace": {
//									"valText": "[50,50,50,1]"
//								},
//								"gntFocus": {
//									"valText": "\"linear-gradient(to right, rgba(190,220,2550,1), 50%, rgba(220,240,255,0.5))\""
//								},
//								"gntSelected": {
//									"valText": "\"linear-gradient(to right, rgba(220,220,220,1), 50%, rgba(220,220,220,0.1))\""
//								},
//								"gntSelect": {
//									"valText": "\"linear-gradient(to right, rgba(220,220,220,1), 50%, rgba(220,220,220,0.1))\""
//								},
//								"gntDlgHeader": {
//									"valText": "\"linear-gradient(to right, rgba(35,105,200,1), 60%, rgba(220,240,255,1.0), 95%, rgba(220,240,255,1.0))\""
//								},
//								"gntHotText": {
//									"valText": "\"linear-gradient(to right, rgba(190,220,255,0),rgba(190,220,255,1), rgba(190,220,255,1),rgba(220,240,255,0.0))\""
//								},
//								"tool": {
//									"valText": "[240,240,240,1]"
//								},
//								"fontTool": {
//									"valText": "[0,0,0,1]"
//								},
//								"fontToolSub": {
//									"valText": "[96,96,96,1]"
//								},
//								"fontToolLit": {
//									"valText": "[168,168,168,1]"
//								},
//								"gntLineBreak": {
//									"valText": "\"linear-gradient(to right, rgba(0,0,0,1),rgba(0,0,0,1), rgba(0,0,0,0))\""
//								},
//								"head": {
//									"valText": "[230,230,230,1]"
//								},
//								"footer": {
//									"valText": "[220,220,220,1]"
//								},
//								"tabTrack": {
//									"valText": "[180,185,190,1]"
//								},
//								"front": {
//									"valText": "[0,0,0,1]"
//								},
//								"fontFront": {
//									"valText": "[255,255,255,1]"
//								},
//								"fontFrontSub": {
//									"valText": "[240,240,240,1]"
//								},
//								"fontFrontLit": {
//									"valText": "[80,80,80,1]"
//								},
//								"itemOver": {
//									"valText": "[0,0,0,0.1]"
//								},
//								"itemDown": {
//									"valText": "[0,0,0,0.2]"
//								},
//								"itemFocus": {
//									"valText": "[13,110,253,1,80]"
//								},
//								"itemGray": {
//									"valText": "[200,200,200,1]"
//								},
//								"subFocus": {
//									"valText": "\"linear-gradient(to right, rgba(0,0,0,0.2), 50%, rgba(0,0,0,0.05))\""
//								},
//								"menuBG": {
//									"valText": "[243,243,242,1]"
//								}
//							}
//						}
//					}
//				}
//			}
//		}
//	}
//}