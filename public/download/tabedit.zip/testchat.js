import {tabOS,tabFS,tabTask} from "/@tabos";
import {VFACT} from "/@vfact";
import {} from "/@vfact/vfact_app.js";
import {appCfg} from "./cfg/appCfg.js";
import {} from "/@homekit/cfg/appCfg.js";
import pathLib from "/@path";
import {UITestChat} from "./ui/UITestChat.js";
//Prefix extern-lib's appCfgs:
{
	let cfgs,name;
	cfgs=window.codyAppCfgs;
	for(name in cfgs){
		cfgs[name].applyCfg();
	}
}
//----------------------------------------------------------------------------
//Start the app:
async function startApp() {
	let app,uiDef;
	
	document.title="Test Chat";
	//------------------------------------------------------------------------
	//Check if we are in appFrame:
	let appFrame=null;
	//CheckAppFrame:
	{
		let pw;
		appFrame=null;
		pw=window.parent;
		if(pw!==window){
			if(pw.getAppFrame){
				appFrame=window.appFrame=pw.getAppFrame(window);
			}
		}
	}
	window.tabOSApp=app=await VFACT.createApp();

	uiDef=UITestChat(app,appFrame);
	//init app, create app UI tree:
	await VFACT.initApp(app,uiDef,{
		shortcuts:appCfg.shortcuts,
		appFrame:appFrame,
	});
}
tabOS.allowRoot=true;
tabOS.setup().then(()=>{startApp();});
