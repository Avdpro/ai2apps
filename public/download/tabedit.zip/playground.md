## Playground tips

#### Notice: AI-Playground need login Tab-OS to access AI-API calls.


#### Features:
- Create AIChat or HTML playground, try you ideas.
- AI-Playground can show your token usage.
- AI-Playground can generate AI-Call codes.
- AI-Playgournd: Test your chat via Chat-Bot

#### Under construction:
Playground App is still under coding. HTML snippet will come soon.

#### Shortcut keys:
- Switch docs: `Alt+tab`/`Ctrl+~(The key on left of key "1")`
- Save doc: `Cmd+S`
- Save doc as: `Shift+Cmd+S`
- Undo: `Cmd+Z`(macOS)/`Ctrl+Z`(PC)
- Redo: `Shift+Cmd+Z`,`Cmd+Y`(macOS)/`Shift+Ctrl+V`,`Ctrl+Y`(PC)
