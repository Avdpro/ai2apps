import {DlgShare} from "./ui/DlgShare.js";
export default DlgShare;
export {DlgShare};