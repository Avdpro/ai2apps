//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import pathLib from "/@path";
import inherits from "/@inherits";
import Base64 from "/@tabos/utils/base64.js";
import {trimJSON} from "/@aichat/utils.js";
/*#{1HRS3QLCP0MoreImports*/
/*}#1HRS3QLCP0MoreImports*/
const agentURL=(new URL(import.meta.url)).pathname;
const basePath=pathLib.dirname(agentURL);
const $ln=VFACT.lanCode||"EN";
/*#{1HRS3QLCP0StartDoc*/
/*}#1HRS3QLCP0StartDoc*/
//----------------------------------------------------------------------------
let CodeAtCursor=async function(session){
	let execInput;
	const $ln=session.language||"EN";
	let context,globalContext=session.globalContext;
	let self;
	let AICoder;
	let aiCfg={platform:"OpenAI",model:"gpt-4o"};
	
	/*#{1HRS3QLCP0LocalVals*/
	/*}#1HRS3QLCP0LocalVals*/
	
	function parseAgentArgs(input){
		execInput=input;
		/*#{1HRS3QLCP0ParseArgs*/
		/*}#1HRS3QLCP0ParseArgs*/
	}
	
	/*#{1HRS3QLCP0PreContext*/
	/*}#1HRS3QLCP0PreContext*/
	context={};
	context=VFACT.flexState(context);
	/*#{1HRS3QLCP0PostContext*/
	/*}#1HRS3QLCP0PostContext*/
	let agent,segs={};
	segs["AICoder"]=AICoder=async function(input){//:1HRS3R7KU0
		let prompt;
		let result=null;
		/*#{1HRS3R7KU0Input*/
		let app=VFACT.app;
		let appPrj=app.prj;
		aiCfg=(appPrj?appPrj.prjConfig.aiCoder:{})||{};
		/*}#1HRS3R7KU0Input*/
		
		let opts={
			platform:aiCfg.platform||"OpenAI",
			mode:aiCfg.model||"gpt-4o",
			maxToken:4050,
			temperature:0,
			topP:1,
			fqcP:0,
			prcP:0,
			secret:false,
			responseFormat:"json_object"
		};
		let chatMem=AICoder.messages
		let seed="";
		if(seed!==undefined){opts.seed=seed;}
		let messages=[
			{role:"system",content:"You are a code-completion AI Agent. \nThe input is a piece of code. Carefully read through the code, locate the “[-AI-]” marker, and based on the context of the code, return the code or comment content to replace the “[-AI-]” marker.  \n\nExample: Input: \n\n```\nfunction sum(a, b)\n{\n\t[-AI-]\n}\n```\n\nOutput: \n```\n{ \n\t\"replaceCode\": \"return a + b;\" \n}\n```\n###  \nPlease note:  \n- 1. Your output must be in JSON format, with the content to replace “[-AI-]” assigned to the “replaceCode” variable.  \n- 2. Output only the replacement part, not the entire code. \n- 3. You may add necessary comments to the generated code.\n- 4. If the “[-AI-]” part is a comment, provide a reasonable comment as the value of the “replaceCode” variable in JSON."},
		];
		/*#{1HRS3R7KU0PrePrompt*/
		opts.coder=true;
		/*}#1HRS3R7KU0PrePrompt*/
		prompt=input;
		if(prompt!==null){
			if(typeof(prompt)!=="string"){
				prompt=JSON.stringify(prompt,null,"	");
			}
			messages.push({role:"user",content:prompt});
		}
		/*#{1HRS3R7KU0PreCall*/
		/*}#1HRS3R7KU0PreCall*/
		result=(result===null)?(await session.callSegLLM("AICoder@"+agentURL,opts,messages,true)):result;
		result=trimJSON(result);
		/*#{1HRS3R7KU0PostCall*/
		/*}#1HRS3R7KU0PostCall*/
		return {result:result};
	};
	AICoder.jaxId="1HRS3R7KU0"
	AICoder.url="AICoder@"+agentURL
	
	agent={
		isAIAgent:true,
		session:session,
		name:"CodeAtCursor",
		url:agentURL,
		autoStart:true,
		jaxId:"1HRS3QLCP0",
		context:context,
		livingSeg:null,
		execChat:async function(input){
			let result;
			parseAgentArgs(input);
			/*#{1HRS3QLCP0PreEntry*/
			/*}#1HRS3QLCP0PreEntry*/
			result={seg:AICoder,"input":input};
			/*#{1HRS3QLCP0PostEntry*/
			/*}#1HRS3QLCP0PostEntry*/
			return result;
		},
		/*#{1HRS3QLCP0MoreAgentAttrs*/
		/*}#1HRS3QLCP0MoreAgentAttrs*/
	};
	/*#{1HRS3QLCP0PostAgent*/
	/*}#1HRS3QLCP0PostAgent*/
	return agent;
};
/*#{1HRS3QLCP0ExCodes*/
/*}#1HRS3QLCP0ExCodes*/

//#CodyExport>>>
//#CodyExport<<<
/*#{1HRS3QLCP0PostDoc*/
/*}#1HRS3QLCP0PostDoc*/


export default CodeAtCursor;
export{CodeAtCursor};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DocAIAgent",
//	"jaxId": "1HRS3QLCP0",
//	"attrs": {
//		"editObjs": {
//			"jaxId": "1HRS3QLCQ0",
//			"attrs": {
//				"CodeAtCursor": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1HRS3QLCQ6",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1HRS3QLCQ7",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1HRS3QLCQ8",
//							"attrs": {}
//						},
//						"functions": {
//							"jaxId": "1HRS3QLCQ9",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false",
//						"exportClass": "false"
//					},
//					"mockups": {}
//				}
//			}
//		},
//		"agent": {
//			"jaxId": "1HRS3QLCQ1",
//			"attrs": {}
//		},
//		"entry": "",
//		"autoStart": "true",
//		"inBrowser": "true",
//		"debug": "true",
//		"apiArgs": {
//			"jaxId": "1HRS3QLCQ5",
//			"attrs": {}
//		},
//		"localVars": {
//			"jaxId": "1HRS3QLCQ2",
//			"attrs": {
//				"aiCfg": {
//					"type": "auto",
//					"valText": "#{platform:\"OpenAI\",model:\"gpt-4o\"}"
//				}
//			}
//		},
//		"context": {
//			"jaxId": "1HRS3QLCQ3",
//			"attrs": {}
//		},
//		"globalMockup": {
//			"jaxId": "1HRS3QLCQ4",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "aiseg",
//					"def": "callLLM",
//					"jaxId": "1HRS3R7KU0",
//					"attrs": {
//						"id": "AICoder",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "190",
//						"y": "150",
//						"desc": "Excute a LLM call.",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1HRS3R7L10",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1HRS3R7L11",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"platform": "#aiCfg.platform||\"OpenAI\"",
//						"mode": "#aiCfg.model||\"gpt-4o\"",
//						"system": "You are a code-completion AI Agent. \nThe input is a piece of code. Carefully read through the code, locate the “[-AI-]” marker, and based on the context of the code, return the code or comment content to replace the “[-AI-]” marker.  \n\nExample: Input: \n\n```\nfunction sum(a, b)\n{\n\t[-AI-]\n}\n```\n\nOutput: \n```\n{ \n\t\"replaceCode\": \"return a + b;\" \n}\n```\n###  \nPlease note:  \n- 1. Your output must be in JSON format, with the content to replace “[-AI-]” assigned to the “replaceCode” variable.  \n- 2. Output only the replacement part, not the entire code. \n- 3. You may add necessary comments to the generated code.\n- 4. If the “[-AI-]” part is a comment, provide a reasonable comment as the value of the “replaceCode” variable in JSON.",
//						"temperature": "0",
//						"maxToken": "4050",
//						"topP": "1",
//						"fqcP": "0",
//						"prcP": "0",
//						"messages": {
//							"attrs": []
//						},
//						"prompt": "#input",
//						"seed": "",
//						"outlet": {
//							"jaxId": "1HRS3R7KV0",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							}
//						},
//						"secret": "false",
//						"allowCheat": "false",
//						"GPTCheats": {
//							"attrs": []
//						},
//						"shareChatName": "",
//						"keepChat": "No",
//						"clearChat": "2",
//						"apiFiles": {
//							"attrs": []
//						},
//						"parallelFunction": "false",
//						"responseFormat": "json_object",
//						"formatDef": "\"\""
//					}
//				}
//			]
//		},
//		"desc": "This is an AI agent.",
//		"exportAPI": "false",
//		"exportAddOn": "false",
//		"addOnOpts": ""
//	}
//}