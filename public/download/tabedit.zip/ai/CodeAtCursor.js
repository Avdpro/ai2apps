//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import pathLib from "/@path";
import inherits from "/@inherits";
import Base64 from "/@tabos/utils/base64.js";
import {trimJSON} from "/@aichat/utils.js";
/*#{1HRS3QLCP0MoreImports*/
/*}#1HRS3QLCP0MoreImports*/
const agentURL=(new URL(import.meta.url)).pathname;
const basePath=pathLib.dirname(agentURL);
const $ln=VFACT.lanCode||"EN";
/*#{1HRS3QLCP0StartDoc*/
/*}#1HRS3QLCP0StartDoc*/
//----------------------------------------------------------------------------
let CodeAtCursor=async function(session){
	let context,globalContext;
	let self;
	let AICoder;
	/*#{1HRS3QLCP0LocalVals*/
	/*}#1HRS3QLCP0LocalVals*/
	
	/*#{1HRS3QLCP0PreContext*/
	/*}#1HRS3QLCP0PreContext*/
	globalContext=session.globalContext;
	context={};
	context=VFACT.flexState(context);
	/*#{1HRS3QLCP0PostContext*/
	/*}#1HRS3QLCP0PostContext*/
	let agent,segs={};
	segs["AICoder"]=AICoder=async function(input){//:1HRS3R7KU0
		let prompt;
		let result;
		
		let opts={
			platform:"OpenAI",
			mode:"gpt-4-1106-preview",
			maxToken:4050,
			temperature:0,
			topP:1,
			fqcP:0,
			prcP:0,
			secret:false,
			responseFormat:"json_object"
		};
		let chatMem=AICoder.messages
		let seed="";
		if(seed!==undefined){opts.seed=seed;}
		let messages=[
			{role:"system",content:"你是一个代码补全AI Agent。\n对话输入是一段代码，请仔细阅读代码，找到\"[-AI-]\"标记，根据代码上下文，返回用于替换\"[-AI-]\"标记的代码或者注释内容。\n例如：\n输入:\n```\nfunction sum(a,b){\n\t[-AI-]\n}\n```\n输出：\n{\n\t\"replacCode\":\"return a+b;\"\n}\n\n请注意\n1）你的输出必须是JSON格式，把要替换\"[-AI-]\"的内容放在\"replaceCode\"变量里。\n2）仅输出需要替换的部分，而不是输出完整的代码。\n3）对你生成代码，你可以添加必要的注释。\n4）如果标记\"[-AI-]\"部分是注释，请给出合理的注释内容作为JSON的\"relaceCode\"变量。"},
		];
		prompt=input;
		if(prompt!==null){
			messages.push({role:"user",content:prompt});
		}
		result=await session.callSegLLM("AICoder@"+agentURL,opts,messages,true);
		result=trimJSON(result);
		return {result:result};
	};
	AICoder.jaxId="1HRS3R7KU0"
	AICoder.url="AICoder@"+agentURL
	
	agent={
		isAIAgent:true,
		session:session,
		name:"CodeAtCursor",
		url:agentURL,
		autoStart:true,
		jaxId:"1HRS3QLCP0",
		context:context,
		livingSeg:null,
		execChat:async function(input){
			let result;
			/*#{1HRS3QLCP0PreEntry*/
			/*}#1HRS3QLCP0PreEntry*/
			result={seg:AICoder,"input":input};
			/*#{1HRS3QLCP0PostEntry*/
			/*}#1HRS3QLCP0PostEntry*/
			return result;
		},
		/*#{1HRS3QLCP0MoreAgentAttrs*/
		/*}#1HRS3QLCP0MoreAgentAttrs*/
	};
	/*#{1HRS3QLCP0PostAgent*/
	/*}#1HRS3QLCP0PostAgent*/
	return agent;
};
/*#{1HRS3QLCP0ExCodes*/
/*}#1HRS3QLCP0ExCodes*/


export default CodeAtCursor;
export{CodeAtCursor};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DocAIAgent",
//	"jaxId": "1HRS3QLCP0",
//	"attrs": {
//		"editObjs": {
//			"jaxId": "1HRS3QLCQ0",
//			"attrs": {
//				"CodeAtCursor": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1HRS3QLCQ6",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1HRS3QLCQ7",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1HRS3QLCQ8",
//							"attrs": {}
//						},
//						"functions": {
//							"jaxId": "1HRS3QLCQ9",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false"
//					},
//					"mockups": {}
//				}
//			}
//		},
//		"agent": {
//			"jaxId": "1HRS3QLCQ1",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "aiseg",
//					"def": "callLLM",
//					"jaxId": "1HRS3R7KU0",
//					"attrs": {
//						"id": "AICoder",
//						"label": "New AI Seg",
//						"x": "190",
//						"y": "150",
//						"context": {
//							"jaxId": "1HRS3R7L10",
//							"attrs": {}
//						},
//						"global": {
//							"jaxId": "1HRS3R7L11",
//							"attrs": {}
//						},
//						"desc": "Excute a LLM call.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"platform": "OpenAI",
//						"mode": "GPT-4 Turbo",
//						"system": "你是一个代码补全AI Agent。\n对话输入是一段代码，请仔细阅读代码，找到\"[-AI-]\"标记，根据代码上下文，返回用于替换\"[-AI-]\"标记的代码或者注释内容。\n例如：\n输入:\n```\nfunction sum(a,b){\n\t[-AI-]\n}\n```\n输出：\n{\n\t\"replacCode\":\"return a+b;\"\n}\n\n请注意\n1）你的输出必须是JSON格式，把要替换\"[-AI-]\"的内容放在\"replaceCode\"变量里。\n2）仅输出需要替换的部分，而不是输出完整的代码。\n3）对你生成代码，你可以添加必要的注释。\n4）如果标记\"[-AI-]\"部分是注释，请给出合理的注释内容作为JSON的\"relaceCode\"变量。",
//						"temperature": "0",
//						"maxToken": "4050",
//						"topP": "1",
//						"fqcP": "0",
//						"prcP": "0",
//						"messages": {
//							"attrs": []
//						},
//						"prompt": "#input",
//						"seed": "",
//						"outlet": {
//							"jaxId": "1HRS3R7KV0",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							}
//						},
//						"secret": "false",
//						"allowCheat": "false",
//						"GPTCheats": {
//							"attrs": []
//						},
//						"shareChatName": "",
//						"keepChat": "No",
//						"clearChat": "2",
//						"apiFiles": {
//							"attrs": []
//						},
//						"parallelFunction": "false",
//						"responseFormat": "json_object"
//					}
//				}
//			]
//		},
//		"entry": "",
//		"autoStart": "true",
//		"debug": "true",
//		"localVars": {
//			"jaxId": "1HRS3QLCQ2",
//			"attrs": {}
//		},
//		"context": {
//			"jaxId": "1HRS3QLCQ3",
//			"attrs": {}
//		},
//		"globalMockup": {
//			"jaxId": "1HRS3QLCQ4",
//			"attrs": {}
//		},
//		"desc": "This is an AI agent.",
//		"exportAPI": "false",
//		"apiArgs": {
//			"jaxId": "1HRS3QLCQ5",
//			"attrs": {}
//		}
//	}
//}