//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import pathLib from "/@path";
import inherits from "/@inherits";
import Base64 from "/@tabos/utils/base64.js";
import {trimJSON} from "/@aichat/utils.js";
/*#{1JF6KMOJI0MoreImports*/
import {tabOS,tabFS,tabNT} from "/@tabos";
/*}#1JF6KMOJI0MoreImports*/
const agentURL=(new URL(import.meta.url)).pathname;
const baseURL=pathLib.dirname(agentURL);
const basePath=baseURL.startsWith("file://")?decodeURI(baseURL):baseURL;
const $ln=VFACT.lanCode||"EN";
const argsTemplate={
	properties:{
		"path":{
			"name":"path","type":"auto",
			"defaultValue":"",
			"desc":"",
		},
		"prj":{
			"name":"prj","type":"auto",
			"defaultValue":"",
			"desc":"",
		}
	},
	/*#{1JF6KMOJI0ArgsView*/
	/*}#1JF6KMOJI0ArgsView*/
};

/*#{1JF6KMOJI0StartDoc*/
//Return sha-256 of given text:
async function sha256(text){
	// Return the hex-encoded SHA-256 hash of the input text.
	if (globalThis.crypto && globalThis.crypto.subtle && globalThis.crypto.subtle.digest) {
		// Browser or Deno environment
		const data = new TextEncoder().encode(text);
		const hashBuffer = await globalThis.crypto.subtle.digest('SHA-256', data);
		// Convert ArrayBuffer to hex string
		return Array.from(new Uint8Array(hashBuffer)).map(b=>b.toString(16).padStart(2,'0')).join('');
	} else {
		// Node.js fallback
		let crypto;
		try {
			crypto = await import('node:crypto').then(mod => mod.default || mod).catch(()=>null);
			if (!crypto) crypto = await import('crypto').then(mod=>mod.default||mod);
		} catch(e) {}
		if(crypto?.createHash){
			return crypto.createHash('sha256').update(text, 'utf8').digest('hex');
		}
		// If neither API is available, return empty string
		return '';
	}
}
/*}#1JF6KMOJI0StartDoc*/
//----------------------------------------------------------------------------
let AbridgeSource=async function(session){
	let path,prj;
	const $ln=session.language||"EN";
	let context,globalContext=session.globalContext;
	let self;
	let ReadFile,CheckCache,CheckLogin,AIIndex,SaveCache,Finish,Error;
	let cacheJson=null;
	let code="";
	let codeSha="";
	
	/*#{1JF6KMOJI0LocalVals*/
	/*}#1JF6KMOJI0LocalVals*/
	
	function parseAgentArgs(input){
		if(typeof(input)=='object'){
			path=input.path;
			prj=input.prj;
		}else{
			path=undefined;
			prj=undefined;
		}
		/*#{1JF6KMOJI0ParseArgs*/
		/*}#1JF6KMOJI0ParseArgs*/
	}
	
	/*#{1JF6KMOJI0PreContext*/
	/*}#1JF6KMOJI0PreContext*/
	context={};
	context=VFACT.flexState(context);
	/*#{1JF6KMOJI0PostContext*/
	/*}#1JF6KMOJI0PostContext*/
	let $agent,agent,segs={};
	segs["ReadFile"]=ReadFile=async function(input){//:1JF4DALRN0
		let result=input
		try{
			/*#{1JF4DALRN0Code*/
			let app,prjDir,jsonPath;
			try{
				code=await tabFS.readFile(path,"utf8");
			}catch(err){
				try{
					code=await (await fetch(path)).text();
				}catch(err){
					code="";
				}
			}
			if(code){
				let pos;
				//Remove code post-fix:
				pos=code.indexOf("\n/*Cody Project Doc*/\n");
				if(pos>0){
					code=code.substring(0,pos);
				}
				pos=code.indexOf("\n#Cody Project Doc\n");
				if(pos>0){
					code=code.substring(0,pos);
				}
				codeSha=await sha256(code);
			}else{
				throw "Can't read file."
			}
			if(prj){
				prjDir=prj.path;
			}else{
				app=VFACT.app;
				prj=app.prj;
				if(prj){
					prjDir=prj.path;
				}else{
					prjDir="/doc/tabedit";
				}
			}
			jsonPath=path.replaceAll("/","_");
			jsonPath=jsonPath.replaceAll(".","_");
			jsonPath=jsonPath.replaceAll("@","_");
			jsonPath=pathLib.join(prjDir,"_aiindex",jsonPath+".abridge.json");
			try{
				cacheJson=await tabFS.readFile(jsonPath,"utf8");
				cacheJson=JSON.parse(cacheJson);
			}catch(err){
				cacheJson=null;
			}
			/*}#1JF4DALRN0Code*/
		}catch(error){
			/*#{1JF4DALRN0ErrorCode*/
			/*}#1JF4DALRN0ErrorCode*/
			return {seg:Error,result:error,preSeg:"1JF4DALRN0",outlet:null};
		}
		return {seg:CheckCache,result:(result),preSeg:"1JF4DALRN0",outlet:"1JF4DCIB50"};
	};
	ReadFile.jaxId="1JF4DALRN0"
	ReadFile.url="ReadFile@"+agentURL
	
	segs["CheckCache"]=CheckCache=async function(input){//:1JF4DAVK00
		let result=input;
		/*#{1JF4DAVK00Start*/
		let cached;
		cached=false;
		if(cacheJson && cacheJson.sha===codeSha && cacheJson.abridged){
			cached=true;
		}
		/*}#1JF4DAVK00Start*/
		if(cached){
			let output=cacheJson.abridged;
			return {seg:Finish,result:(output),preSeg:"1JF4DAVK00",outlet:"1JF4DCIB51"};
		}
		/*#{1JF4DAVK00Post*/
		/*}#1JF4DAVK00Post*/
		return {seg:CheckLogin,result:(result),preSeg:"1JF4DAVK00",outlet:"1JF4DCIB52"};
	};
	CheckCache.jaxId="1JF4DAVK00"
	CheckCache.url="CheckCache@"+agentURL
	
	segs["CheckLogin"]=CheckLogin=async function(input){//:1JF56KRPP0
		let result=input;
		/*#{1JF56KRPP0Start*/
		let online;
		online=await tabNT.checkLogin(true);
		/*}#1JF56KRPP0Start*/
		if(online){
			return {seg:AIIndex,result:(input),preSeg:"1JF56KRPP0",outlet:"1JF56MRQL0"};
		}
		/*#{1JF56KRPP0Post*/
		/*}#1JF56KRPP0Post*/
		return {seg:Error,result:(result),preSeg:"1JF56KRPP0",outlet:"1JF56MRQL1"};
	};
	CheckLogin.jaxId="1JF56KRPP0"
	CheckLogin.url="CheckLogin@"+agentURL
	
	segs["AIIndex"]=AIIndex=async function(input){//:1JF4D90N70
		let prompt;
		let $platform="OpenAI";
		let $model="gpt-4.1";
		let $agent;
		let result;
		
		let opts={
			platform:$platform,
			mode:$model,
			maxToken:2000,
			temperature:0,
			topP:1,
			fqcP:0,
			prcP:0,
			secret:false,
			responseFormat:"text"
		};
		let chatMem=AIIndex.messages
		let seed="";
		if(seed!==undefined){opts.seed=seed;}
		let messages=[
			{role:"system",content:"You are AI Single-File Source Abridger (API-first, Preserve-Shapes).\n\nGoal\n- Abridge ONE source file for AI coding context.\n- Minimize token usage while preserving ALL externally-relevant API SHAPES, especially object shapes created inside functions.\n\nCore idea\n- Preserve “shapes” (object keys, method names, signatures) for anything that can be observed/called from outside.\n- Elide implementations, not interfaces.\n\nHard rules\n1) Abridge ONLY the provided file. Do not assume other files’ content.\n2) Preserve import/export names and shapes accurately.\n3) Do not invent behavior. Any added contract text must be derived from explicit code behavior or existing docs; otherwise mark UNKNOWN.\n4) Output ONLY one code block, in the same language as input. No prose outside.\n5) Avoid verbatim dumping; rewrite into abridged form is allowed.\n\nDefinitions\n- SHORT function: <= 8 non-empty statement lines in body AND low complexity.\n  -> Keep code as-is. Do NOT add new docs.\n- NON-SHORT function: everything else.\n  -> Usually elide body, BUT with the boundary-shape preservation rules below.\n\nBoundary object (MUST preserve shape)\nAn object is a “Boundary Object” if ANY of the following holds:\nA) It is exported (directly or as default export).\nB) It is returned from an exported function / exported class method (including factory/builders).\nC) It is assigned to a property of an exported object/class instance (public field).\nD) It is passed as an argument to an imported symbol (likely external API), e.g. createX({...}), app.use({...}), router({...}), new X({...}).\nE) It is stored in a module-level variable that is exported or used by exported APIs.\nF) It is used as “options/handlers/hooks” object for integration points (heuristic): keys like handler, middleware, hooks, on*, before*, after*, render, resolve, serialize, deserialize.\n\nBoundary-shape preservation rules (non-negotiable)\n- For any Boundary Object that is an object literal or clearly an object shape:\n  1) Preserve ALL top-level keys.\n  2) For function-valued keys, preserve function signature and name.\n  3) For nested objects, preserve one more level of keys (2 levels total) if it is a config/handlers object; deeper levels may be elided.\n  4) Function bodies inside the object may be elided, but must remain syntactically valid.\n- If the object is returned, ensure the returned object structure is visible in the abridged output.\n\nHow to represent Boundary Objects when eliding\n- Prefer showing the object literal with elided bodies:\n  const x = {\n    foo(a, b) { /* … elided … */ },\n    bar: (opts) => { /* … elided … */ },\n    nested: { key1: /* … */, key2: /* … */ }\n  };\n- For values that are large/complex, replace only the value, not the key:\n  key: /* … elided: big literal … */\n\nExternally relevant callable APIs\n- exported functions\n- exported class constructors / public methods / static methods\n- exported object members that are functions\nFor these:\n- If NON-SHORT, add a contract comment (JSDoc/docstring) and elide implementation, while preserving boundary object shapes created/returned/passed out.\n\nContract comment for NON-SHORT externally-relevant callables\n- Summary (1 line)\n- Params (including opts.* keys if options object)\n- Returns (shape/meaning if derivable; else UNKNOWN)\n- Errors/Throws only if explicit\n- Side effects only if explicit\n- @contractSource FROM_DOC or FROM_CODE\n- @contractGaps if important unknowns\n\nDefault elision style for NON-SHORT functions\n- You may elide most of the body:\n  { /* … elided: implementation … */ }\n- BUT you MUST keep:\n  - returned Boundary Object literals (shape)\n  - options/handlers objects passed to imported APIs (shape)\n  - any explicit throws/returns that define contract\n  - any obvious side-effect call sites (fs/net/db) if they are contract-significant\n\nHandling classes\n- Preserve class name, constructor signature, public methods names.\n- For each method:\n  - SHORT => keep as-is\n  - NON-SHORT => elide body, but preserve any Boundary Object shapes created/returned/passed out inside that method.\n\nTypes/interfaces/constants\n- Keep types/interfaces used by exported signatures; compress bodies.\n- Keep constants tied to contracts (timeouts/retry/TTL); large literals can be elided by value.\n\nUnknowns and snippet requests\n- If a missing detail affects external callers, add inline:\n  // TODO(NEED_SNIPPET): <what> — <why it matters>\n\nOutput check (must satisfy)\n- SHORT functions unchanged, no added docs.\n- NON-SHORT externally relevant callables have contract comments.\n- Any Boundary Object shape is preserved (keys + method signatures), even if bodies elided.\n- You did NOT “erase” useful info by replacing an object with a single elision marker.\n\nNow abridge the single file content provided by the user."},
		];
		prompt=code;
		if(prompt!==null){
			if(typeof(prompt)!=="string"){
				prompt=JSON.stringify(prompt,null,"	");
			}
			let msg={role:"user",content:prompt};messages.push(msg);
		}
		if($agent){
			result=await session.callAgent($agent.agentNode,$agent.path,{messages:messages,maxToken:opts.maxToken,responseFormat:opts.responseFormat});
		}else{
			result=await session.callSegLLM("AIIndex@"+agentURL,opts,messages,true);
		}
		return {seg:SaveCache,result:(result),preSeg:"1JF4D90N70",outlet:"1JF4DA9DV0"};
	};
	AIIndex.jaxId="1JF4D90N70"
	AIIndex.url="AIIndex@"+agentURL
	
	segs["SaveCache"]=SaveCache=async function(input){//:1JF4DBQ990
		let result=input
		try{
			/*#{1JF4DBQ990Code*/
			let app,prjDir,jsonPath;
			cacheJson={
				sha:codeSha,
				abridged:input
			};
			if(prj){
				prjDir=prj.path;
			}else{
				app=VFACT.app;
				prj=app.prj;
				if(prj){
					prjDir=prj.path;
				}else{
					prjDir="/doc/tabedit";
				}
			}
			jsonPath=path.replaceAll("/","_");
			jsonPath=jsonPath.replaceAll(".","_");
			jsonPath=jsonPath.replaceAll("@","_");
			jsonPath=pathLib.join(prjDir,"_aiindex",jsonPath+".abridge.json");
			await tabFS.writeFile(jsonPath,JSON.stringify(cacheJson,null,"\t"));
			jsonPath=path.replaceAll("/","_");
			jsonPath=jsonPath.replaceAll(".","_");
			jsonPath=jsonPath.replaceAll("@","_");
			jsonPath=pathLib.join(prjDir,"_aiindex",jsonPath+".abridge"+pathLib.extname(path));
			await tabFS.writeFile(jsonPath,input,"\t");
			result=input;
			/*}#1JF4DBQ990Code*/
		}catch(error){
			/*#{1JF4DBQ990ErrorCode*/
			/*}#1JF4DBQ990ErrorCode*/
			return {seg:Error,result:error,preSeg:"1JF4DBQ990",outlet:null};
		}
		return {seg:Finish,result:(result),preSeg:"1JF4DBQ990",outlet:"1JF4DCIB53"};
	};
	SaveCache.jaxId="1JF4DBQ990"
	SaveCache.url="SaveCache@"+agentURL
	
	segs["Finish"]=Finish=async function(input){//:1JF4DC79U0
		let result=input
		try{
			/*#{1JF4DC79U0Code*/
			/*}#1JF4DC79U0Code*/
		}catch(error){
			/*#{1JF4DC79U0ErrorCode*/
			/*}#1JF4DC79U0ErrorCode*/
		}
		return {result:result};
	};
	Finish.jaxId="1JF4DC79U0"
	Finish.url="Finish@"+agentURL
	
	segs["Error"]=Error=async function(input){//:1JF53HLB10
		let result=null
		try{
			/*#{1JF53HLB10Code*/
			/*}#1JF53HLB10Code*/
		}catch(error){
			/*#{1JF53HLB10ErrorCode*/
			/*}#1JF53HLB10ErrorCode*/
		}
		return {result:result};
	};
	Error.jaxId="1JF53HLB10"
	Error.url="Error@"+agentURL
	
	agent=$agent={
		isAIAgent:true,
		session:session,
		name:"AbridgeSource",
		url:agentURL,
		autoStart:true,
		jaxId:"1JF6KMOJI0",
		context:context,
		livingSeg:null,
		execChat:async function(input/*{path,prj}*/){
			let result;
			parseAgentArgs(input);
			/*#{1JF6KMOJI0PreEntry*/
			/*}#1JF6KMOJI0PreEntry*/
			result={seg:ReadFile,"input":input};
			/*#{1JF6KMOJI0PostEntry*/
			/*}#1JF6KMOJI0PostEntry*/
			return result;
		},
		/*#{1JF6KMOJI0MoreAgentAttrs*/
		/*}#1JF6KMOJI0MoreAgentAttrs*/
	};
	/*#{1JF6KMOJI0PostAgent*/
	/*}#1JF6KMOJI0PostAgent*/
	return agent;
};
/*#{1JF6KMOJI0ExCodes*/
/*}#1JF6KMOJI0ExCodes*/

//#CodyExport>>>
//#CodyExport<<<
/*#{1JF6KMOJI0PostDoc*/
/*}#1JF6KMOJI0PostDoc*/


export default AbridgeSource;
export{AbridgeSource};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DocAIAgent",
//	"jaxId": "1JF6KMOJI0",
//	"attrs": {
//		"editObjs": {
//			"jaxId": "1JF4D8SHM1",
//			"attrs": {
//				"AbridgeSource": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1JF4D8SHN0",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1JF4D8SHN1",
//							"attrs": {}
//						},
//						"properties": {
//							"jaxId": "1JF4D8SHN2",
//							"attrs": {}
//						},
//						"functions": {
//							"jaxId": "1JF4D8SHN3",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false",
//						"exportClass": "false",
//						"superClass": ""
//					},
//					"mockups": {}
//				}
//			}
//		},
//		"agent": {
//			"jaxId": "1JF4D8SHM2",
//			"attrs": {}
//		},
//		"showName": "",
//		"entry": "",
//		"autoStart": "true",
//		"inBrowser": "true",
//		"debug": "true",
//		"apiArgs": {
//			"jaxId": "1JF4D8SHM3",
//			"attrs": {
//				"path": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1JF4DA9DV1",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				},
//				"prj": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1JF53V6820",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1JF4D8SHM4",
//			"attrs": {
//				"cacheJson": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"code": {
//					"type": "string",
//					"valText": ""
//				},
//				"codeSha": {
//					"type": "string",
//					"valText": ""
//				}
//			}
//		},
//		"context": {
//			"jaxId": "1JF4D8SHM5",
//			"attrs": {}
//		},
//		"globalMockup": {
//			"jaxId": "1JF4D8SHM6",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1JF4DALRN0",
//					"attrs": {
//						"id": "ReadFile",
//						"viewName": "",
//						"label": "",
//						"x": "170",
//						"y": "290",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1JF4DCIB70",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1JF4DCIB71",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1JF4DCIB50",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1JF4DAVK00"
//						},
//						"outlets": {
//							"attrs": []
//						},
//						"result": "#input",
//						"errorSeg": "1JF53HLB10"
//					},
//					"icon": "tab_css.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "brunch",
//					"jaxId": "1JF4DAVK00",
//					"attrs": {
//						"id": "CheckCache",
//						"viewName": "",
//						"label": "",
//						"x": "390",
//						"y": "290",
//						"desc": "这是一个AISeg。",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1JF4DCIB72",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1JF4DCIB73",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1JF4DCIB52",
//							"attrs": {
//								"id": "Miss",
//								"desc": "输出节点。",
//								"output": ""
//							},
//							"linkedSeg": "1JF56KRPP0"
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1JF4DCIB51",
//									"attrs": {
//										"id": "Cached",
//										"desc": "输出节点。",
//										"output": "#cacheJson.abridged",
//										"codes": "false",
//										"context": {
//											"jaxId": "1JF4DCIB74",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1JF4DCIB75",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#cached"
//									},
//									"linkedSeg": "1JF4DC79U0"
//								}
//							]
//						}
//					},
//					"icon": "condition.svg",
//					"reverseOutlets": true
//				},
//				{
//					"type": "aiseg",
//					"def": "brunch",
//					"jaxId": "1JF56KRPP0",
//					"attrs": {
//						"id": "CheckLogin",
//						"viewName": "",
//						"label": "",
//						"x": "645",
//						"y": "400",
//						"desc": "这是一个AISeg。",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1JF56MRQQ0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1JF56MRQQ1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1JF56MRQL1",
//							"attrs": {
//								"id": "Offline",
//								"desc": "输出节点。",
//								"output": ""
//							},
//							"linkedSeg": "1JF53HLB10"
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1JF56MRQL0",
//									"attrs": {
//										"id": "Online",
//										"desc": "输出节点。",
//										"output": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1JF56MRQQ2",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1JF56MRQQ3",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#online"
//									},
//									"linkedSeg": "1JF4D90N70"
//								}
//							]
//						}
//					},
//					"icon": "condition.svg",
//					"reverseOutlets": true
//				},
//				{
//					"type": "aiseg",
//					"def": "callLLM",
//					"jaxId": "1JF4D90N70",
//					"attrs": {
//						"id": "AIIndex",
//						"viewName": "",
//						"label": "",
//						"x": "905",
//						"y": "385",
//						"desc": "执行一次LLM调用。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1JF4DA9DV2",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1JF4DA9DV3",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"platform": "\"OpenAI\"",
//						"mode": "gpt-4.1",
//						"system": "You are AI Single-File Source Abridger (API-first, Preserve-Shapes).\n\nGoal\n- Abridge ONE source file for AI coding context.\n- Minimize token usage while preserving ALL externally-relevant API SHAPES, especially object shapes created inside functions.\n\nCore idea\n- Preserve “shapes” (object keys, method names, signatures) for anything that can be observed/called from outside.\n- Elide implementations, not interfaces.\n\nHard rules\n1) Abridge ONLY the provided file. Do not assume other files’ content.\n2) Preserve import/export names and shapes accurately.\n3) Do not invent behavior. Any added contract text must be derived from explicit code behavior or existing docs; otherwise mark UNKNOWN.\n4) Output ONLY one code block, in the same language as input. No prose outside.\n5) Avoid verbatim dumping; rewrite into abridged form is allowed.\n\nDefinitions\n- SHORT function: <= 8 non-empty statement lines in body AND low complexity.\n  -> Keep code as-is. Do NOT add new docs.\n- NON-SHORT function: everything else.\n  -> Usually elide body, BUT with the boundary-shape preservation rules below.\n\nBoundary object (MUST preserve shape)\nAn object is a “Boundary Object” if ANY of the following holds:\nA) It is exported (directly or as default export).\nB) It is returned from an exported function / exported class method (including factory/builders).\nC) It is assigned to a property of an exported object/class instance (public field).\nD) It is passed as an argument to an imported symbol (likely external API), e.g. createX({...}), app.use({...}), router({...}), new X({...}).\nE) It is stored in a module-level variable that is exported or used by exported APIs.\nF) It is used as “options/handlers/hooks” object for integration points (heuristic): keys like handler, middleware, hooks, on*, before*, after*, render, resolve, serialize, deserialize.\n\nBoundary-shape preservation rules (non-negotiable)\n- For any Boundary Object that is an object literal or clearly an object shape:\n  1) Preserve ALL top-level keys.\n  2) For function-valued keys, preserve function signature and name.\n  3) For nested objects, preserve one more level of keys (2 levels total) if it is a config/handlers object; deeper levels may be elided.\n  4) Function bodies inside the object may be elided, but must remain syntactically valid.\n- If the object is returned, ensure the returned object structure is visible in the abridged output.\n\nHow to represent Boundary Objects when eliding\n- Prefer showing the object literal with elided bodies:\n  const x = {\n    foo(a, b) { /* … elided … */ },\n    bar: (opts) => { /* … elided … */ },\n    nested: { key1: /* … */, key2: /* … */ }\n  };\n- For values that are large/complex, replace only the value, not the key:\n  key: /* … elided: big literal … */\n\nExternally relevant callable APIs\n- exported functions\n- exported class constructors / public methods / static methods\n- exported object members that are functions\nFor these:\n- If NON-SHORT, add a contract comment (JSDoc/docstring) and elide implementation, while preserving boundary object shapes created/returned/passed out.\n\nContract comment for NON-SHORT externally-relevant callables\n- Summary (1 line)\n- Params (including opts.* keys if options object)\n- Returns (shape/meaning if derivable; else UNKNOWN)\n- Errors/Throws only if explicit\n- Side effects only if explicit\n- @contractSource FROM_DOC or FROM_CODE\n- @contractGaps if important unknowns\n\nDefault elision style for NON-SHORT functions\n- You may elide most of the body:\n  { /* … elided: implementation … */ }\n- BUT you MUST keep:\n  - returned Boundary Object literals (shape)\n  - options/handlers objects passed to imported APIs (shape)\n  - any explicit throws/returns that define contract\n  - any obvious side-effect call sites (fs/net/db) if they are contract-significant\n\nHandling classes\n- Preserve class name, constructor signature, public methods names.\n- For each method:\n  - SHORT => keep as-is\n  - NON-SHORT => elide body, but preserve any Boundary Object shapes created/returned/passed out inside that method.\n\nTypes/interfaces/constants\n- Keep types/interfaces used by exported signatures; compress bodies.\n- Keep constants tied to contracts (timeouts/retry/TTL); large literals can be elided by value.\n\nUnknowns and snippet requests\n- If a missing detail affects external callers, add inline:\n  // TODO(NEED_SNIPPET): <what> — <why it matters>\n\nOutput check (must satisfy)\n- SHORT functions unchanged, no added docs.\n- NON-SHORT externally relevant callables have contract comments.\n- Any Boundary Object shape is preserved (keys + method signatures), even if bodies elided.\n- You did NOT “erase” useful info by replacing an object with a single elision marker.\n\nNow abridge the single file content provided by the user.",
//						"temperature": "0",
//						"maxToken": "2000",
//						"topP": "1",
//						"fqcP": "0",
//						"prcP": "0",
//						"messages": {
//							"attrs": []
//						},
//						"prompt": "#code",
//						"seed": "",
//						"outlet": {
//							"jaxId": "1JF4DA9DV0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1JF4DBQ990"
//						},
//						"stream": "true",
//						"secret": "false",
//						"allowCheat": "false",
//						"GPTCheats": {
//							"attrs": []
//						},
//						"shareChatName": "",
//						"keepChat": "No",
//						"clearChat": "2",
//						"apiFiles": {
//							"attrs": []
//						},
//						"parallelFunction": "false",
//						"responseFormat": "text",
//						"formatDef": "\"\"",
//						"outlets": {
//							"attrs": []
//						}
//					},
//					"icon": "llm.svg",
//					"reverseOutlets": true
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1JF4DBQ990",
//					"attrs": {
//						"id": "SaveCache",
//						"viewName": "",
//						"label": "",
//						"x": "1125",
//						"y": "385",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1JF4DCIB76",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1JF4DCIB77",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1JF4DCIB53",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1JF4DC79U0"
//						},
//						"outlets": {
//							"attrs": []
//						},
//						"result": "#input",
//						"errorSeg": "1JF53HLB10"
//					},
//					"icon": "tab_css.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1JF4DC79U0",
//					"attrs": {
//						"id": "Finish",
//						"viewName": "",
//						"label": "",
//						"x": "1370",
//						"y": "275",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1JF4DCIB78",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1JF4DCIB79",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1JF4DCIB60",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							}
//						},
//						"outlets": {
//							"attrs": []
//						},
//						"result": "#input",
//						"errorSeg": ""
//					},
//					"icon": "tab_css.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1JF53HLB10",
//					"attrs": {
//						"id": "Error",
//						"viewName": "",
//						"label": "",
//						"x": "905",
//						"y": "490",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1JF53I6LL0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1JF53I6LL1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1JF53I6LF0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							}
//						},
//						"outlets": {
//							"attrs": []
//						},
//						"result": "#null",
//						"errorSeg": ""
//					},
//					"icon": "tab_css.svg"
//				}
//			]
//		},
//		"desc": "这是一个AI智能体。",
//		"exportAPI": "false",
//		"exportAddOn": "false",
//		"addOnOpts": ""
//	}
//}