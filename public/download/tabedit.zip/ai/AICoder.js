import pathLib from "/@path";
import {tabOS,tabFS,tabNT} from "/@tabos";
import {appCfg} from "../cfg/appCfg.js";
import {BlkAIChat} from "../ui/BlkAIChat.js";
import {BlkAIChatCode} from "../ui/BlkAIChatCode.js";
import {mergeCodeWithSeg} from "../lib/codesegs.js";
const DlgFile="/@homekit/ui/DlgFile.js";
let $ln=appCfg["$ln"]||"EN";
const aiMarkMessagesLead=[
	{
		role:"system",
		content:"You are a code helper"
	},
	{
		role:"user",
		content:`help write codes mark by: //AI:
don't include //AI: mark in your output codes.
\`\`\`
//AI: comment
function sum(a, b){
	//AI:
}
\`\`\``
	},
	{
		role:"assistant",
		content:`\`\`\`
//This function returns sum result of two arguments.
function sum(a, b){
	return a+b;
}
\`\`\``
	}
];

const aiCursorMessagesLead=[
	{
		role:"system",
		content:"You are a JS code helper"
	},
	{
		role:"user",
		content:`write codes should replace the mark: [AI]
your output MUST be just code replaces the [AI] mark
\`\`\`
function sum(a, b){
[AI]
}
\`\`\``
	},
	{
		role:"assistant",
		content:`\`\`\`	return a+b;\`\`\``
	}
];

const aiRangeMessagesLead=[
	{
		role:"system",
		content:"You are a JS code helper"
	},
	{
		role:"user",
		content:`to make better codes or fix possible issues: write codes should replace the codes between: [AI->] and [<-AI]
your output MUST be just code replaces the codes between two marks
\`\`\`
function sum(a, b){
[AI->]return[<-AI]
}
\`\`\``
	},
	{
		role:"assistant",
		content:`\`\`\`	return a+b;\`\`\``
	}
];

const aiFixerMessagesLead=[
	{
		role:"system",
		content:"You are a code helper, you find and fix issues in codes."
	},
	{
		role:"user",
		content:`Make better codes or fix possible issues:
\`\`\`
//TODO: comment
function sum(a,b){
	a+b;
}
\`\`\``
	},
	{
		role:"assistant",
		content:`\`\`\`
//This function returns sum result of two numbers:
function sum(a,b){
	return a+b;
}
\`\`\``
	}
];

//----------------------------------------------------------------------------
async function aiCoderExec(app,aiChat,chatDlg,docObj){
	let orgCode,editBox,codyDoc,hasAITag,hasSelection;
	let menuItems,item;
	chatDlg.clearChats();
	orgCode=docObj.getDocText();
	editBox=docObj.editBox;
	codyDoc=docObj.codyDoc;
	if(orgCode.indexOf("//AI:")>=0 || orgCode.indexOf("[AI]")>=0){
		hasAITag=true;
	}
	hasSelection=editBox.getSelectionRange();
	menuItems=[];
	menuItems.push({text:"Write code with `//AI:` guide",code:"Mark",enable:!!hasAITag});
	menuItems.push({text:"Write code at cursor",code:"Cursor"});
	menuItems.push({text:"Refine code in selection",code:"Range",enable:!!hasSelection});
	menuItems.push({text:"Find and fix issue in code",code:"Fixer"});
	item=await chatDlg.askChoice("How can AI help?",menuItems,{});
	if(!item){
		return;
	}
	console.log(item);
	switch(item.code){
		case "Mark":{
			let messages,resVO,message;
			let blkCode,applyCode,newCode;
			messages=[...aiMarkMessagesLead];
			messages.push({
				role:"user",
				content:`help write codes mark by: //AI:\ndon't include //AI: mark in your output codes, do not remove other comments:\n\`\`\`\n${orgCode}\n\`\`\``
			});
			do{
				chatDlg.wait();
				try{
					resVO=await chatDlg.doAIStreamCall("AICallStream",{messages:messages});
				}catch(err){
					chatDlg.endWait();
					return;
				}
				chatDlg.endWait();
				message=resVO.message;
				resVO=aiChat.parseCodes(message);
				if(!resVO.codes || !resVO.codes[0]){
					return;
				}
				newCode=resVO.codes[0];
				if(codyDoc){
					let mergedCode;
					mergedCode=mergeCodeWithSeg(orgCode,newCode,{});
					message=message.replaceAll(newCode,mergedCode);
				}
				blkCode=chatDlg.addChatBlock(BlkAIChatCode(app,message||"",orgCode));
				applyCode=await chatDlg.askConfirm("Do you like to apply AI's modify to your document?",{textYes:"Apply",textNo:"Reject",txt3rd:"Re-Code"});
			}while(applyCode===2);
			if(!applyCode){
				return false;
			}
			newCode=blkCode.getCode();
			if(!newCode){
				return false;
			}
			editBox.setEditText(newCode,true);
			break;
		}
		case "Cursor":{
			let cursorPos,callCode;
			let messages,resVO,message;
			let blkCode,applyCode,newCode;
			let mergedCode;
			//TODO: Insert [AI] tag at cursor:
			cursorPos=editBox.getCursorIndex();
			if(cursorPos>=0){
				callCode=orgCode.substring(0,cursorPos)+"[AI]"+orgCode.substring(cursorPos);
			}else{
				//TODO: Tell user no cursor?
				return;
			}
			messages=[...aiCursorMessagesLead];
			messages.push({
				role:"user",
				content:`write codes should replace the mark: [AI]. \nyour output MUST be just codes replaces the [AI] mark:\n\`\`\`\n${callCode}\n\`\`\``
			});
			do{
				chatDlg.wait();
				try{
					resVO=await chatDlg.doAIStreamCall("AICallStream",{messages:messages});
				}catch(err){
					chatDlg.endWait();
					return false;
				}
				chatDlg.endWait();
				message=resVO.message;
				resVO=aiChat.parseCodes(message);
				if(!resVO.codes || !resVO.codes[0]){
					return;
				}
				newCode=resVO.codes[0][1];
				mergedCode=orgCode.substring(0,cursorPos)+newCode+orgCode.substring(cursorPos);
				if(codyDoc){
					mergedCode=mergeCodeWithSeg(orgCode,mergedCode,{});
					message=message.replaceAll(newCode,mergedCode);
				}
				//message=message.replaceAll(newCode,mergedCode);
				message="```"+mergedCode+"```";
				blkCode=chatDlg.addChatBlock(BlkAIChatCode(app,message||"",orgCode));
				applyCode=await chatDlg.askConfirm("Do you like to apply AI's modify to your document?",{textYes:"Apply",textNo:"Reject",txt3rd:"Re-Code"});
			}while(applyCode===2);
			if(!applyCode){
				return false;
			}
			newCode=blkCode.getCode();
			if(!newCode){
				return false;
			}
			editBox.setEditText(newCode,true);
			break;
		}
		case "Range":{
			let selRange,callCode;
			let messages,resVO,message;
			let blkCode,applyCode,newCode;
			let mergedCode;
			//Insert [AI->]/[<-AI] tag at cursor:
			selRange=editBox.getSelectionRange();
			if(!selRange){
				//TODO: Tell user no cursor?
				return;
			}else{
				callCode=orgCode.substring(0,selRange[0])+"[AI->]"+orgCode.substring(selRange[0],selRange[1])+"[<-AI]"+orgCode.substring(selRange[1]);
			}
			messages=[...aiRangeMessagesLead];
			messages.push({
				role:"user",
				content:`to make better codes or fix possible issues: write codes should replace the codes between: [AI->] and [<-AI]. \nyour output MUST be just code replaces the codes between two marks:\n\`\`\`\n${callCode}\n\`\`\``
			});
			do{
				chatDlg.wait();
				try{
					resVO=await chatDlg.doAIStreamCall("AICallStream",{messages:messages});
				}catch(err){
					chatDlg.endWait();
					return;
				}
				chatDlg.endWait();
				message=resVO.message;
				resVO=aiChat.parseCodes(message);
				if(!resVO.codes || !resVO.codes[0]){
					return;
				}
				newCode=resVO.codes[0][1];
				mergedCode=orgCode.substring(0,selRange[0])+newCode+orgCode.substring(selRange[1]);
				if(codyDoc){
					mergedCode=mergeCodeWithSeg(orgCode,mergedCode,{});
					message=message.replaceAll(newCode,mergedCode);
				}
				message="```"+mergedCode+"```";
				blkCode=chatDlg.addChatBlock(BlkAIChatCode(app,message||"",orgCode));
				applyCode=await chatDlg.askConfirm("Do you like to apply AI's modify to your document?",{textYes:"Apply",textNo:"Reject",txt3rd:"Re-Code"});
			}while(applyCode===2);
			if(!applyCode){
				return false;
			}
			newCode=blkCode.getCode();
			if(!newCode){
				return false;
			}
			editBox.setEditText(newCode,true);
			break;
		}
		case "Fixer":{
			let selRange,callCode;
			let messages,resVO,message;
			let blkCode,applyCode,newCode;
			let mergedCode;
			//Insert [AI->]/[<-AI] tag at cursor:
			callCode=orgCode;
			messages=[...aiFixerMessagesLead];
			messages.push({
				role:"user",
				content:`Make better codes or fix possible issues:\n\`\`\`\n${callCode}\n\`\`\``
			});
			do{
				chatDlg.wait();
				try{
					resVO=await chatDlg.doAIStreamCall("AICallStream",{messages:messages});
				}catch(err){
					chatDlg.endWait();
					return false;
				}
				chatDlg.endWait();
				message=resVO.message;
				resVO=aiChat.parseCodes(message);
				if(!resVO.codes || !resVO.codes[0]){
					return;
				}
				newCode=resVO.codes[0][1];
				mergedCode=newCode;
				if(codyDoc){
					mergedCode=mergeCodeWithSeg(orgCode,mergedCode,{});
					message=message.replaceAll(newCode,mergedCode);
				}
				message="```"+mergedCode+"```";
				blkCode=chatDlg.addChatBlock(BlkAIChatCode(app,message||"",orgCode));
				applyCode=await chatDlg.askConfirm("Do you like to apply AI's modify to your document?",{textYes:"Apply",textNo:"Reject",txt3rd:"Re-Code"});
			}while(applyCode===2);
			if(!applyCode){
				return false;
			}
			newCode=blkCode.getCode();
			if(!newCode){
				return false;
			}
			editBox.setEditText(newCode,true);
			break;
		}
	}
};

//----------------------------------------------------------------------------
async function aiCoderHelp(app,aiChat,chatDlg,question){
	let messages,resVO,message;
	let endChat=false;
	if(!question){
		try{
			question=await chatDlg.askText("How can I help with your coding?",{text:""});
		}catch(err){
			return;
		}
	}
	messages=[];
	messages.push({
		role:"system",
		content:`You are a web/js code assistant, reply user's coding quesrions.`
	});
	do{
		messages.push({role:"user",content:question});
		chatDlg.wait();
		try{
			resVO=await chatDlg.doAIStreamCall("AICallStream",{messages:messages});
		}catch(err){
			chatDlg.endWait();
			return;
		}
		chatDlg.endWait();
		message=resVO.message;
		messages.push({
			role:"assistant",
			content:message
		});
		resVO=aiChat.parseCodes(message);
		if(!resVO.codes || !resVO.codes[0]){
			chatDlg.addChatBlock(BlkAIChat(app,"chat",message||""));
		}else{
			chatDlg.addChatBlock(BlkAIChatCode(app,message||""));
		}
		endChat=await chatDlg.askConfirm("Do you need more help?",{textYes:"Yes",textNo:"End Chat"});
		endChat=endChat===1?false:true;
		if(!endChat){
			try{
				question=await chatDlg.askText("Chat more about the topic.",{text:""});
			}catch(err){
				return;
			}
		}
	}while(!endChat);
};

//----------------------------------------------------------------------------
async function aiCreateFile(app,aiChat,chatDlg,cmdVO){
	let fname=cmdVO.name||"";
	let path=cmdVO.path||app.prj.path;
	let desc=cmdVO.desc||"";
	let ext=cmdVO.type||pathLib.extname(fname)||".txt";
	let autoCode,codes="";
	let dlgFunc=null;
	let dlgErrorFunc=null;
	
	if(ext[0]!=="."){
		ext="."+ext;
	}
	if(path[0]!=="/"){
		path=pathLib.join(app.prj.path,path);
	}
	if(path[path.length-1]==="/"){
		path=path.substring(0,path.length-1);
	}
	if(!fname){
		fname="NewFile"+ext;
	}
	if(!fname.endsWith(ext)){
		fname=fname+ext;
	}
	if(ext===".js"||ext===".html"||ext===".py"||ext===".ts"){
		autoCode=await chatDlg.askConfirm("Do you like AI generate codes for your new doc?",{textYes:"Generate",textNo:"No thanks"});
		if(autoCode){
			try{
				desc=await chatDlg.askText("Please provide a brief description of the new document, including its purpose, features, and functions.",{text:desc});
			}catch(err){
				return;
			}
			if(desc){
				let codeBlk;
				try{
					codeBlk=await chatDlg.doCode("NewCode",desc,"");
				}catch(err){
					return;
				}
				if(codeBlk){
					codes=codeBlk.getCode();
				}
			}
		}
	}

	app.showDlg(DlgFile,{
		title:(($ln==="CN")?("新建文档:"):/*EN*/("New document:")),
		mode:"save",
		path:path,
		buttonText:(($ln==="CN")?("创建"):/*EN*/("Create")),
		fileName:fname,
		options:{
			multiSelect:0,
			preview:1,
		},
		callback:async function(filePath){
			let doc;
			if(!filePath){
				dlgFunc(false);
			}
			try{
				await tabFS.writeFile(filePath,codes,"utf8");
				doc=await app.docs.openDoc(filePath);
				if(doc){
					app.docs.focusDoc(doc);
					await chatDlg.close();
					dlgFunc(true);
				}else{
					throw new Error("Can't open document.");
				}
			}catch(e){
				dlgErrorFunc(e);
			}
		}
	});
	return new Promise((resolve,reject)=>{
		dlgFunc=resolve;
		dlgErrorFunc=reject;
	});
	
};

//----------------------------------------------------------------------------
async function aiUpdateCode(app,aiChat,chatDlg,editBox,cmdVO){
	let desc=cmdVO.desc||"";
	let orgCode,codeBlk,newCode,applyCode;
	console.log("Command: will update doc");
	console.log(cmdVO);
	orgCode=editBox.getEditText();
	if(!desc){
		try{
			desc=await chatDlg.askText("Please provide more detials of the modification.",{text:desc});
		}catch(err){
			return;
		}
		if(!desc){
			return false;
		}
	}
	try{
		codeBlk=await chatDlg.doCode("Modify",desc,orgCode);
	}catch(err){
		return;
	}
	if(!codeBlk){
		return false;
	}
	applyCode=await chatDlg.askConfirm("Do you like to apply AI's modify to your document?",{textYes:"Apply",textNo:"Reject"});
	if(!applyCode){
		return false;
	}
	newCode=codeBlk.getCode();
	if(!newCode){
		return false;
	}
	editBox.setEditText(newCode,true);
	return true;
};

//----------------------------------------------------------------------------
async function aiChat(app,aiChat,chatDlg){
	
};

export {aiCoderExec,aiCoderHelp,aiCreateFile,aiUpdateCode};