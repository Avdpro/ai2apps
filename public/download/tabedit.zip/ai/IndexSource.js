//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import pathLib from "/@path";
import inherits from "/@inherits";
import Base64 from "/@tabos/utils/base64.js";
import {trimJSON} from "/@aichat/utils.js";
/*#{1JF4D8SHM0MoreImports*/
import {tabOS,tabFS,tabNT} from "/@tabos";
/*}#1JF4D8SHM0MoreImports*/
const agentURL=(new URL(import.meta.url)).pathname;
const baseURL=pathLib.dirname(agentURL);
const basePath=baseURL.startsWith("file://")?decodeURI(baseURL):baseURL;
const $ln=VFACT.lanCode||"EN";
const argsTemplate={
	properties:{
		"path":{
			"name":"path","type":"auto",
			"defaultValue":"",
			"desc":"",
		},
		"prj":{
			"name":"prj","type":"auto",
			"defaultValue":"",
			"desc":"",
		}
	},
	/*#{1JF4D8SHM0ArgsView*/
	/*}#1JF4D8SHM0ArgsView*/
};

/*#{1JF4D8SHM0StartDoc*/
//Return sha-256 of given text:
async function sha256(text){
	// Return the hex-encoded SHA-256 hash of the input text.
	if (globalThis.crypto && globalThis.crypto.subtle && globalThis.crypto.subtle.digest) {
		// Browser or Deno environment
		const data = new TextEncoder().encode(text);
		const hashBuffer = await globalThis.crypto.subtle.digest('SHA-256', data);
		// Convert ArrayBuffer to hex string
		return Array.from(new Uint8Array(hashBuffer)).map(b=>b.toString(16).padStart(2,'0')).join('');
	} else {
		// Node.js fallback
		let crypto;
		try {
			crypto = await import('node:crypto').then(mod => mod.default || mod).catch(()=>null);
			if (!crypto) crypto = await import('crypto').then(mod=>mod.default||mod);
		} catch(e) {}
		if(crypto?.createHash){
			return crypto.createHash('sha256').update(text, 'utf8').digest('hex');
		}
		// If neither API is available, return empty string
		return '';
	}
}
/*}#1JF4D8SHM0StartDoc*/
//----------------------------------------------------------------------------
let IndexSource=async function(session){
	let path,prj;
	const $ln=session.language||"EN";
	let context,globalContext=session.globalContext;
	let self;
	let ReadFile,CheckCache,CheckLogin,AIIndex,SaveCache,Finish,Error;
	let cacheJson=null;
	let code="";
	let codeSha="";
	
	/*#{1JF4D8SHM0LocalVals*/
	/*}#1JF4D8SHM0LocalVals*/
	
	function parseAgentArgs(input){
		if(typeof(input)=='object'){
			path=input.path;
			prj=input.prj;
		}else{
			path=undefined;
			prj=undefined;
		}
		/*#{1JF4D8SHM0ParseArgs*/
		/*}#1JF4D8SHM0ParseArgs*/
	}
	
	/*#{1JF4D8SHM0PreContext*/
	/*}#1JF4D8SHM0PreContext*/
	context={};
	context=VFACT.flexState(context);
	/*#{1JF4D8SHM0PostContext*/
	/*}#1JF4D8SHM0PostContext*/
	let $agent,agent,segs={};
	segs["ReadFile"]=ReadFile=async function(input){//:1JF4DALRN0
		let result=input
		try{
			/*#{1JF4DALRN0Code*/
			let app,prjDir,jsonPath;
			try{
				code=await tabFS.readFile(path,"utf8");
			}catch(err){
				try{
					code=await (await fetch(path)).text();
				}catch(err){
					code="";
				}
			}
			if(code){
				let pos;
				//Remove code post-fix:
				pos=code.indexOf("\n/*Cody Project Doc*/\n");
				if(pos>0){
					code=code.substring(0,pos);
				}
				pos=code.indexOf("\n#Cody Project Doc\n");
				if(pos>0){
					code=code.substring(0,pos);
				}
				codeSha=await sha256(code);
			}else{
				throw "Can't read file."
			}
			if(prj){
				prjDir=prj.path;
			}else{
				app=VFACT.app;
				prj=app.prj;
				if(prj){
					prjDir=prj.path;
				}else{
					prjDir="/doc/tabedit";
				}
			}
			jsonPath=path.replaceAll("/","_");
			jsonPath=jsonPath.replaceAll(".","_");
			jsonPath=jsonPath.replaceAll("@","_");
			jsonPath=pathLib.join(prjDir,"_aiindex",jsonPath+".index.json");
			try{
				cacheJson=await tabFS.readFile(jsonPath,"utf8");
				cacheJson=JSON.parse(cacheJson);
			}catch(err){
				cacheJson=null;
			}
			/*}#1JF4DALRN0Code*/
		}catch(error){
			/*#{1JF4DALRN0ErrorCode*/
			/*}#1JF4DALRN0ErrorCode*/
			return {seg:Error,result:error,preSeg:"1JF4DALRN0",outlet:null};
		}
		return {seg:CheckCache,result:(result),preSeg:"1JF4DALRN0",outlet:"1JF4DCIB50"};
	};
	ReadFile.jaxId="1JF4DALRN0"
	ReadFile.url="ReadFile@"+agentURL
	
	segs["CheckCache"]=CheckCache=async function(input){//:1JF4DAVK00
		let result=input;
		/*#{1JF4DAVK00Start*/
		let cached;
		cached=false;
		if(cacheJson && cacheJson.sha===codeSha && cacheJson.index){
			cached=true;
		}
		/*}#1JF4DAVK00Start*/
		if(cached){
			let output=cacheJson.index;
			return {seg:Finish,result:(output),preSeg:"1JF4DAVK00",outlet:"1JF4DCIB51"};
		}
		/*#{1JF4DAVK00Post*/
		/*}#1JF4DAVK00Post*/
		return {seg:CheckLogin,result:(result),preSeg:"1JF4DAVK00",outlet:"1JF4DCIB52"};
	};
	CheckCache.jaxId="1JF4DAVK00"
	CheckCache.url="CheckCache@"+agentURL
	
	segs["CheckLogin"]=CheckLogin=async function(input){//:1JF56KRPP0
		let result=input;
		/*#{1JF56KRPP0Start*/
		let online;
		online=await tabNT.checkLogin(true);
		/*}#1JF56KRPP0Start*/
		if(online){
			return {seg:AIIndex,result:(input),preSeg:"1JF56KRPP0",outlet:"1JF56MRQL0"};
		}
		/*#{1JF56KRPP0Post*/
		/*}#1JF56KRPP0Post*/
		return {seg:Error,result:(result),preSeg:"1JF56KRPP0",outlet:"1JF56MRQL1"};
	};
	CheckLogin.jaxId="1JF56KRPP0"
	CheckLogin.url="CheckLogin@"+agentURL
	
	segs["AIIndex"]=AIIndex=async function(input){//:1JF4D90N70
		let prompt;
		let $platform="OpenAI";
		let $model="gpt-4.1";
		let $agent;
		let result;
		
		let opts={
			platform:$platform,
			mode:$model,
			maxToken:2000,
			temperature:0,
			topP:1,
			fqcP:0,
			prcP:0,
			secret:false,
			responseFormat:"json_object"
		};
		let chatMem=AIIndex.messages
		let seed="";
		if(seed!==undefined){opts.seed=seed;}
		let messages=[
			{role:"system",content:"You are AI Single-File Indexer (Spec-First).\n\nGoal\n- Index ONE source file into a high-quality, developer-usable API index.\n- The index MUST be sufficient for another AI (or developer) to call the exported API correctly.\n- Prioritize correctness and completeness of callable contracts over extreme token savings.\n- Still avoid dumping raw code.\n\nHard rules\n1) Index ONLY the provided file. Do not assume other files’ content.\n2) No long code pasting. Max 40 lines of verbatim total across the whole output, preferably 0.\n3) Do not guess. If details are not explicitly present, write UNKNOWN.\n4) If a spec cannot be made reliable without more context, request it:\n   NEED_SNIPPET: <symbol or region> :: <what detail is missing> :: <why it matters>\n5) Output a single JSON object ONLY. No prose outside JSON. No markdown.\n\nOutput JSON schema (strict)\n{\n  \"v\": \"fidx@3\",\n  \"file\": \"<path or UNKNOWN>\",\n  \"lang\": \"<ts|js|py|go|rust|java|cpp|other|UNKNOWN>\",\n  \"role\": \"<1 short line: what this file/module does>\",\n\n  \"imports\": [\n    { \"from\": \"<module>\", \"names\": [\"<a>\", \"<b>\"], \"kind\": \"<local|pkg|builtin|UNKNOWN>\" }\n  ],\n\n  \"exports\": [\n    { \"name\": \"<exportName or default>\", \"kind\": \"<fn|class|const|type|obj|ns|mixed|UNKNOWN>\" }\n  ],\n\n  \"symbols\": {\n    \"<symbolPath>\": {\n      \"kind\": \"<fn|method|class|ctor|prop|const|type|UNKNOWN>\",\n      \"vis\": \"<public|internal|UNKNOWN>\",\n\n      \"sig\": \"<signature string or UNKNOWN>\",\n\n      \"doc\": \"<1-3 lines: what it does + when to use; UNKNOWN if not stated>\",\n      \"params\": [\n        {\n          \"name\": \"<param>\",\n          \"type\": \"<type or UNKNOWN>\",\n          \"desc\": \"<meaning/constraint; UNKNOWN if not stated>\",\n          \"optional\": true/false/\"UNKNOWN\",\n          \"default\": \"<value or UNKNOWN>\",\n          \"range\": \"<e.g., 0..1, enum values, regex; or UNKNOWN>\"\n        }\n      ],\n      \"returns\": {\n        \"type\": \"<type or UNKNOWN>\",\n        \"desc\": \"<meaning; edge cases; UNKNOWN if not stated>\"\n      },\n      \"throws\": [\n        { \"type\": \"<ErrorType or UNKNOWN>\", \"when\": \"<when thrown; UNKNOWN if not stated>\" }\n      ],\n\n      \"sidefx\": [\n        \"<external side effects: db write, fs write, network call, global mutation>\",\n        \"...\"\n      ],\n      \"contracts\": [\n        \"<important behavioral rules: init required, ordering, idempotency, retries, caching, locking, resource lifetime>\",\n        \"...\"\n      ],\n      \"examples\": [\n        \"<short call example string; omit if would require too much context>\"\n      ],\n\n      \"members\": [\n        \"<for class/obj/ns: list child symbolPaths>\"\n      ],\n\n      \"loc\": \"<line range if available; else omit>\",\n      \"notes\": [\"<extra short notes>\", \"...\"]\n    }\n  },\n\n  \"globals\": [\n    \"<important module-level state and what it affects>\",\n    \"...\"\n  ],\n\n  \"cfg\": [\"<config key>\", \"...\"],\n  \"io\": [\"<external I/O: fs/net/db/etc>\", \"...\"],\n  \"errs\": [\"<module-level error conventions>\", \"...\"],\n  \"sidefx\": [\"<module-level side effects at import/init time>\", \"...\"],\n  \"contracts\": [\"<module-level contracts>\", \"...\"],\n\n  \"need\": [\n    \"NEED_SNIPPET: <symbol or region> :: <missing detail> :: <why>\"\n  ]\n}\n\nSymbol path convention\n- For named export function: \"export.<name>\"\n- For default export object: \"export.default\"\n- For object member: \"export.<name>.<member>\" or \"export.default.<member>\"\n- For class constructor: \"export.<Class>.ctor\"\n- For class method: \"export.<Class>#<method>\" (instance) or \"export.<Class>.<method>\" (static)\n- For namespace-like bag: \"export.<ns>.<member>\"\n\nWhat to index (priority)\n1) Anything externally callable:\n   - exported functions\n   - exported class constructors + public methods\n   - exported objects’ methods (and important props)\n2) Public data shapes:\n   - exported types/interfaces (name + high-level meaning; don’t dump full definitions unless tiny)\n3) Contracts:\n   - errors, retries, caching, concurrency, ordering, lifecycle\n4) Side effects and global state\n5) Imports only as context\n\nHow to write good specs\n- For params/returns:\n  - Always list each param and the return value.\n  - If no description exists, set desc=UNKNOWN (do NOT invent).\n  - If there are implicit constraints in code (e.g., checks for null, range checks), convert them into a contract line.\n- For errors:\n  - If code throws/returns error objects, record how and when.\n  - If it returns Result-like values, note that in returns.desc and contracts.\n- For async:\n  - Mark in sig and mention awaited effects in sidefx/contracts.\n- For options objects:\n  - If function takes an options object, list known option keys as pseudo-params:\n    name=\"opts.<key>\"\n\nWhen to request NEED_SNIPPET\n- When a function is exported but its behavior depends on a private helper with non-trivial semantics (retry/backoff/caching/locking/validation),\n  and the file alone does not clearly state the contract.\n- When return shape is not obvious (e.g., dynamic object) and would affect callers.\n\nNow produce the JSON index for the single file content provided by the user."},
		];
		prompt=code;
		if(prompt!==null){
			if(typeof(prompt)!=="string"){
				prompt=JSON.stringify(prompt,null,"	");
			}
			let msg={role:"user",content:prompt};messages.push(msg);
		}
		if($agent){
			result=await session.callAgent($agent.agentNode,$agent.path,{messages:messages,maxToken:opts.maxToken,responseFormat:opts.responseFormat});
		}else{
			result=await session.callSegLLM("AIIndex@"+agentURL,opts,messages,true);
		}
		result=trimJSON(result);
		return {seg:SaveCache,result:(result),preSeg:"1JF4D90N70",outlet:"1JF4DA9DV0"};
	};
	AIIndex.jaxId="1JF4D90N70"
	AIIndex.url="AIIndex@"+agentURL
	
	segs["SaveCache"]=SaveCache=async function(input){//:1JF4DBQ990
		let result=input
		try{
			/*#{1JF4DBQ990Code*/
			let app,prjDir,jsonPath;
			cacheJson={
				sha:codeSha,
				index:input
			};
			if(prj){
				prjDir=prj.path;
			}else{
				app=VFACT.app;
				prj=app.prj;
				if(prj){
					prjDir=prj.path;
				}else{
					prjDir="/doc/tabedit";
				}
			}
			jsonPath=path.replaceAll("/","_");
			jsonPath=jsonPath.replaceAll(".","_");
			jsonPath=jsonPath.replaceAll("@","_");
			jsonPath=pathLib.join(prjDir,"_aiindex",jsonPath+".index.json");
			await tabFS.writeFile(jsonPath,JSON.stringify(cacheJson,null,"\t"));
			result=input;
			/*}#1JF4DBQ990Code*/
		}catch(error){
			/*#{1JF4DBQ990ErrorCode*/
			/*}#1JF4DBQ990ErrorCode*/
			return {seg:Error,result:error,preSeg:"1JF4DBQ990",outlet:null};
		}
		return {seg:Finish,result:(result),preSeg:"1JF4DBQ990",outlet:"1JF4DCIB53"};
	};
	SaveCache.jaxId="1JF4DBQ990"
	SaveCache.url="SaveCache@"+agentURL
	
	segs["Finish"]=Finish=async function(input){//:1JF4DC79U0
		let result=input
		try{
			/*#{1JF4DC79U0Code*/
			/*}#1JF4DC79U0Code*/
		}catch(error){
			/*#{1JF4DC79U0ErrorCode*/
			/*}#1JF4DC79U0ErrorCode*/
		}
		return {result:result};
	};
	Finish.jaxId="1JF4DC79U0"
	Finish.url="Finish@"+agentURL
	
	segs["Error"]=Error=async function(input){//:1JF53HLB10
		let result=null
		try{
			/*#{1JF53HLB10Code*/
			/*}#1JF53HLB10Code*/
		}catch(error){
			/*#{1JF53HLB10ErrorCode*/
			/*}#1JF53HLB10ErrorCode*/
		}
		return {result:result};
	};
	Error.jaxId="1JF53HLB10"
	Error.url="Error@"+agentURL
	
	agent=$agent={
		isAIAgent:true,
		session:session,
		name:"IndexSource",
		url:agentURL,
		autoStart:true,
		jaxId:"1JF4D8SHM0",
		context:context,
		livingSeg:null,
		execChat:async function(input/*{path,prj}*/){
			let result;
			parseAgentArgs(input);
			/*#{1JF4D8SHM0PreEntry*/
			/*}#1JF4D8SHM0PreEntry*/
			result={seg:ReadFile,"input":input};
			/*#{1JF4D8SHM0PostEntry*/
			/*}#1JF4D8SHM0PostEntry*/
			return result;
		},
		/*#{1JF4D8SHM0MoreAgentAttrs*/
		/*}#1JF4D8SHM0MoreAgentAttrs*/
	};
	/*#{1JF4D8SHM0PostAgent*/
	/*}#1JF4D8SHM0PostAgent*/
	return agent;
};
/*#{1JF4D8SHM0ExCodes*/
/*}#1JF4D8SHM0ExCodes*/

//#CodyExport>>>
//#CodyExport<<<
/*#{1JF4D8SHM0PostDoc*/
/*}#1JF4D8SHM0PostDoc*/


export default IndexSource;
export{IndexSource};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DocAIAgent",
//	"jaxId": "1JF4D8SHM0",
//	"attrs": {
//		"editObjs": {
//			"jaxId": "1JF4D8SHM1",
//			"attrs": {
//				"IndexSource.js": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1JF4D8SHN0",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1JF4D8SHN1",
//							"attrs": {}
//						},
//						"properties": {
//							"jaxId": "1JF4D8SHN2",
//							"attrs": {}
//						},
//						"functions": {
//							"jaxId": "1JF4D8SHN3",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false",
//						"exportClass": "false",
//						"superClass": ""
//					},
//					"mockups": {}
//				}
//			}
//		},
//		"agent": {
//			"jaxId": "1JF4D8SHM2",
//			"attrs": {}
//		},
//		"showName": "",
//		"entry": "",
//		"autoStart": "true",
//		"inBrowser": "true",
//		"debug": "true",
//		"apiArgs": {
//			"jaxId": "1JF4D8SHM3",
//			"attrs": {
//				"path": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1JF4DA9DV1",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				},
//				"prj": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1JF53V6820",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1JF4D8SHM4",
//			"attrs": {
//				"cacheJson": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"code": {
//					"type": "string",
//					"valText": ""
//				},
//				"codeSha": {
//					"type": "string",
//					"valText": ""
//				}
//			}
//		},
//		"context": {
//			"jaxId": "1JF4D8SHM5",
//			"attrs": {}
//		},
//		"globalMockup": {
//			"jaxId": "1JF4D8SHM6",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1JF4DALRN0",
//					"attrs": {
//						"id": "ReadFile",
//						"viewName": "",
//						"label": "",
//						"x": "170",
//						"y": "290",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1JF4DCIB70",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1JF4DCIB71",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1JF4DCIB50",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1JF4DAVK00"
//						},
//						"outlets": {
//							"attrs": []
//						},
//						"result": "#input",
//						"errorSeg": "1JF53HLB10"
//					},
//					"icon": "tab_css.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "brunch",
//					"jaxId": "1JF4DAVK00",
//					"attrs": {
//						"id": "CheckCache",
//						"viewName": "",
//						"label": "",
//						"x": "390",
//						"y": "290",
//						"desc": "这是一个AISeg。",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1JF4DCIB72",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1JF4DCIB73",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1JF4DCIB52",
//							"attrs": {
//								"id": "Miss",
//								"desc": "输出节点。",
//								"output": ""
//							},
//							"linkedSeg": "1JF56KRPP0"
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1JF4DCIB51",
//									"attrs": {
//										"id": "Cached",
//										"desc": "输出节点。",
//										"output": "#cacheJson.index",
//										"codes": "false",
//										"context": {
//											"jaxId": "1JF4DCIB74",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1JF4DCIB75",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#cached"
//									},
//									"linkedSeg": "1JF4DC79U0"
//								}
//							]
//						}
//					},
//					"icon": "condition.svg",
//					"reverseOutlets": true
//				},
//				{
//					"type": "aiseg",
//					"def": "brunch",
//					"jaxId": "1JF56KRPP0",
//					"attrs": {
//						"id": "CheckLogin",
//						"viewName": "",
//						"label": "",
//						"x": "645",
//						"y": "400",
//						"desc": "这是一个AISeg。",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1JF56MRQQ0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1JF56MRQQ1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1JF56MRQL1",
//							"attrs": {
//								"id": "Offline",
//								"desc": "输出节点。",
//								"output": ""
//							},
//							"linkedSeg": "1JF53HLB10"
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1JF56MRQL0",
//									"attrs": {
//										"id": "Online",
//										"desc": "输出节点。",
//										"output": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1JF56MRQQ2",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1JF56MRQQ3",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#online"
//									},
//									"linkedSeg": "1JF4D90N70"
//								}
//							]
//						}
//					},
//					"icon": "condition.svg",
//					"reverseOutlets": true
//				},
//				{
//					"type": "aiseg",
//					"def": "callLLM",
//					"jaxId": "1JF4D90N70",
//					"attrs": {
//						"id": "AIIndex",
//						"viewName": "",
//						"label": "",
//						"x": "905",
//						"y": "385",
//						"desc": "执行一次LLM调用。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1JF4DA9DV2",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1JF4DA9DV3",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"platform": "\"OpenAI\"",
//						"mode": "gpt-4.1",
//						"system": "You are AI Single-File Indexer (Spec-First).\n\nGoal\n- Index ONE source file into a high-quality, developer-usable API index.\n- The index MUST be sufficient for another AI (or developer) to call the exported API correctly.\n- Prioritize correctness and completeness of callable contracts over extreme token savings.\n- Still avoid dumping raw code.\n\nHard rules\n1) Index ONLY the provided file. Do not assume other files’ content.\n2) No long code pasting. Max 40 lines of verbatim total across the whole output, preferably 0.\n3) Do not guess. If details are not explicitly present, write UNKNOWN.\n4) If a spec cannot be made reliable without more context, request it:\n   NEED_SNIPPET: <symbol or region> :: <what detail is missing> :: <why it matters>\n5) Output a single JSON object ONLY. No prose outside JSON. No markdown.\n\nOutput JSON schema (strict)\n{\n  \"v\": \"fidx@3\",\n  \"file\": \"<path or UNKNOWN>\",\n  \"lang\": \"<ts|js|py|go|rust|java|cpp|other|UNKNOWN>\",\n  \"role\": \"<1 short line: what this file/module does>\",\n\n  \"imports\": [\n    { \"from\": \"<module>\", \"names\": [\"<a>\", \"<b>\"], \"kind\": \"<local|pkg|builtin|UNKNOWN>\" }\n  ],\n\n  \"exports\": [\n    { \"name\": \"<exportName or default>\", \"kind\": \"<fn|class|const|type|obj|ns|mixed|UNKNOWN>\" }\n  ],\n\n  \"symbols\": {\n    \"<symbolPath>\": {\n      \"kind\": \"<fn|method|class|ctor|prop|const|type|UNKNOWN>\",\n      \"vis\": \"<public|internal|UNKNOWN>\",\n\n      \"sig\": \"<signature string or UNKNOWN>\",\n\n      \"doc\": \"<1-3 lines: what it does + when to use; UNKNOWN if not stated>\",\n      \"params\": [\n        {\n          \"name\": \"<param>\",\n          \"type\": \"<type or UNKNOWN>\",\n          \"desc\": \"<meaning/constraint; UNKNOWN if not stated>\",\n          \"optional\": true/false/\"UNKNOWN\",\n          \"default\": \"<value or UNKNOWN>\",\n          \"range\": \"<e.g., 0..1, enum values, regex; or UNKNOWN>\"\n        }\n      ],\n      \"returns\": {\n        \"type\": \"<type or UNKNOWN>\",\n        \"desc\": \"<meaning; edge cases; UNKNOWN if not stated>\"\n      },\n      \"throws\": [\n        { \"type\": \"<ErrorType or UNKNOWN>\", \"when\": \"<when thrown; UNKNOWN if not stated>\" }\n      ],\n\n      \"sidefx\": [\n        \"<external side effects: db write, fs write, network call, global mutation>\",\n        \"...\"\n      ],\n      \"contracts\": [\n        \"<important behavioral rules: init required, ordering, idempotency, retries, caching, locking, resource lifetime>\",\n        \"...\"\n      ],\n      \"examples\": [\n        \"<short call example string; omit if would require too much context>\"\n      ],\n\n      \"members\": [\n        \"<for class/obj/ns: list child symbolPaths>\"\n      ],\n\n      \"loc\": \"<line range if available; else omit>\",\n      \"notes\": [\"<extra short notes>\", \"...\"]\n    }\n  },\n\n  \"globals\": [\n    \"<important module-level state and what it affects>\",\n    \"...\"\n  ],\n\n  \"cfg\": [\"<config key>\", \"...\"],\n  \"io\": [\"<external I/O: fs/net/db/etc>\", \"...\"],\n  \"errs\": [\"<module-level error conventions>\", \"...\"],\n  \"sidefx\": [\"<module-level side effects at import/init time>\", \"...\"],\n  \"contracts\": [\"<module-level contracts>\", \"...\"],\n\n  \"need\": [\n    \"NEED_SNIPPET: <symbol or region> :: <missing detail> :: <why>\"\n  ]\n}\n\nSymbol path convention\n- For named export function: \"export.<name>\"\n- For default export object: \"export.default\"\n- For object member: \"export.<name>.<member>\" or \"export.default.<member>\"\n- For class constructor: \"export.<Class>.ctor\"\n- For class method: \"export.<Class>#<method>\" (instance) or \"export.<Class>.<method>\" (static)\n- For namespace-like bag: \"export.<ns>.<member>\"\n\nWhat to index (priority)\n1) Anything externally callable:\n   - exported functions\n   - exported class constructors + public methods\n   - exported objects’ methods (and important props)\n2) Public data shapes:\n   - exported types/interfaces (name + high-level meaning; don’t dump full definitions unless tiny)\n3) Contracts:\n   - errors, retries, caching, concurrency, ordering, lifecycle\n4) Side effects and global state\n5) Imports only as context\n\nHow to write good specs\n- For params/returns:\n  - Always list each param and the return value.\n  - If no description exists, set desc=UNKNOWN (do NOT invent).\n  - If there are implicit constraints in code (e.g., checks for null, range checks), convert them into a contract line.\n- For errors:\n  - If code throws/returns error objects, record how and when.\n  - If it returns Result-like values, note that in returns.desc and contracts.\n- For async:\n  - Mark in sig and mention awaited effects in sidefx/contracts.\n- For options objects:\n  - If function takes an options object, list known option keys as pseudo-params:\n    name=\"opts.<key>\"\n\nWhen to request NEED_SNIPPET\n- When a function is exported but its behavior depends on a private helper with non-trivial semantics (retry/backoff/caching/locking/validation),\n  and the file alone does not clearly state the contract.\n- When return shape is not obvious (e.g., dynamic object) and would affect callers.\n\nNow produce the JSON index for the single file content provided by the user.",
//						"temperature": "0",
//						"maxToken": "2000",
//						"topP": "1",
//						"fqcP": "0",
//						"prcP": "0",
//						"messages": {
//							"attrs": []
//						},
//						"prompt": "#code",
//						"seed": "",
//						"outlet": {
//							"jaxId": "1JF4DA9DV0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1JF4DBQ990"
//						},
//						"stream": "true",
//						"secret": "false",
//						"allowCheat": "false",
//						"GPTCheats": {
//							"attrs": []
//						},
//						"shareChatName": "",
//						"keepChat": "No",
//						"clearChat": "2",
//						"apiFiles": {
//							"attrs": []
//						},
//						"parallelFunction": "false",
//						"responseFormat": "json_object",
//						"formatDef": "\"\"",
//						"outlets": {
//							"attrs": []
//						}
//					},
//					"icon": "llm.svg",
//					"reverseOutlets": true
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1JF4DBQ990",
//					"attrs": {
//						"id": "SaveCache",
//						"viewName": "",
//						"label": "",
//						"x": "1125",
//						"y": "385",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1JF4DCIB76",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1JF4DCIB77",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1JF4DCIB53",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1JF4DC79U0"
//						},
//						"outlets": {
//							"attrs": []
//						},
//						"result": "#input",
//						"errorSeg": "1JF53HLB10"
//					},
//					"icon": "tab_css.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1JF4DC79U0",
//					"attrs": {
//						"id": "Finish",
//						"viewName": "",
//						"label": "",
//						"x": "1370",
//						"y": "275",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1JF4DCIB78",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1JF4DCIB79",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1JF4DCIB60",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							}
//						},
//						"outlets": {
//							"attrs": []
//						},
//						"result": "#input",
//						"errorSeg": ""
//					},
//					"icon": "tab_css.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1JF53HLB10",
//					"attrs": {
//						"id": "Error",
//						"viewName": "",
//						"label": "",
//						"x": "905",
//						"y": "490",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1JF53I6LL0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1JF53I6LL1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1JF53I6LF0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							}
//						},
//						"outlets": {
//							"attrs": []
//						},
//						"result": "#null",
//						"errorSeg": ""
//					},
//					"icon": "tab_css.svg"
//				}
//			]
//		},
//		"desc": "这是一个AI智能体。",
//		"exportAPI": "false",
//		"exportAddOn": "false",
//		"addOnOpts": ""
//	}
//}