//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import pathLib from "/@path";
import inherits from "/@inherits";
import Base64 from "/@tabos/utils/base64.js";
import {trimJSON} from "/@aichat/utils.js";
/*#{1J7V9TL1R0MoreImports*/
/*}#1J7V9TL1R0MoreImports*/
const agentURL=(new URL(import.meta.url)).pathname;
const baseURL=pathLib.dirname(agentURL);
const basePath=baseURL.startsWith("file://")?decodeURI(baseURL):baseURL;
const $ln=VFACT.lanCode||"EN";
const argsTemplate={
	properties:{
		"platform":{
			"name":"platform","type":"auto",
			"defaultValue":"",
			"desc":"",
		},
		"model":{
			"name":"model","type":"auto",
			"defaultValue":"",
			"desc":"",
		},
		"code":{
			"name":"code","type":"auto",
			"defaultValue":"",
			"desc":"",
		}
	},
	/*#{1J7V9TL1R0ArgsView*/
	/*}#1J7V9TL1R0ArgsView*/
};

/*#{1J7V9TL1R0StartDoc*/
/*}#1J7V9TL1R0StartDoc*/
//----------------------------------------------------------------------------
let CodeWithSelection=async function(session){
	let platform,model,code;
	const $ln=session.language||"EN";
	let context,globalContext=session.globalContext;
	let self;
	let CodeWithSelection,CheckAction,TextOutput,Result;
	let aiCfg={platform:"OpenAI",model:"gpt-4o"};
	
	/*#{1J7V9TL1R0LocalVals*/
	/*}#1J7V9TL1R0LocalVals*/
	
	function parseAgentArgs(input){
		if(typeof(input)=='object'){
			platform=input.platform;
			model=input.model;
			code=input.code;
		}else{
			platform=undefined;
			model=undefined;
			code=undefined;
		}
		/*#{1J7V9TL1R0ParseArgs*/
		/*}#1J7V9TL1R0ParseArgs*/
	}
	
	/*#{1J7V9TL1R0PreContext*/
	/*}#1J7V9TL1R0PreContext*/
	context={};
	context=VFACT.flexState(context);
	/*#{1J7V9TL1R0PostContext*/
	/*}#1J7V9TL1R0PostContext*/
	let $agent,agent,segs={};
	segs["CodeWithSelection"]=CodeWithSelection=async function(input){//:1J7TA6IFO0
		let prompt;
		let result=null;
		/*#{1J7TA6IFO0Input*/
		/*}#1J7TA6IFO0Input*/
		
		let opts={
			platform:platform||"OpenAI",
			mode:model||"gpt-5",
			maxToken:4050,
			temperature:0,
			topP:1,
			fqcP:0,
			prcP:0,
			secret:false,
			responseFormat:"json_object"
		};
		let chatMem=CodeWithSelection.messages
		let seed="";
		if(seed!==undefined){opts.seed=seed;}
		let messages=[
			{role:"system",content:"\n### You are a coding AI Agent. \n- The input is a piece of code and coding instruction. Carefully read through the code, locate the “[-AI-]” marker, and based on user instruction and the context of the code, return the code, comment contentto replace the “[-AI->]” and “[<-AI-]” marker pair, or output chat text to  user for suggestion or discuss.\n- Your ouput must in JSON format.\n\n### Return code:\nIf based on the original code and instruction, you can export code that replace the codes between \"[-AI->]\" and \"[<-AI-]\"marker.\nPut your replacement code in \"replaceCode\" properity of result JOSN.\nExample: \nInput: \n```\n</code>\nfunction sum(a, b)\n{\n\t[-AI->]return a+=b;[<-A-]\n}\n</code>\n<instruction>\ndebug\n</instruction>\n```\nOutput: \n```\n{ \n\t\"replaceCode\": \"return a + b;\" \n}\n```\n**Please note:**  \n- 1. Your output must be in JSON format, with the content to replace code betwwn “[-AI->]” and “[<-AI-]” assigned to the “replaceCode” variable.  \n- 2. Output only the replacement part, not the entire code. \n- 3. You may add necessary comments to the generated code.\n- 4. If the “[-AI->]”/“[<-AI-]” part is a (in) comment, provide a reasonable comment as the value of the “replaceCode” variable in JSON.\n\n### Suggestion / Discuss:\nIf the instruction is finding bug, asking for suggestion, or if you need more information from user to complete the coding task. You can put your output / question in \"textOutput\" property of the result JSON:\nExample:\n```\n{\n\t\"textOutput\":\"When x===0, your code may fail...\"\n}\n```\n"},
		];
		messages.push(...chatMem);
		/*#{1J7TA6IFO0PrePrompt*/
		/*}#1J7TA6IFO0PrePrompt*/
		prompt=input.code||input;
		if(prompt!==null){
			if(typeof(prompt)!=="string"){
				prompt=JSON.stringify(prompt,null,"	");
			}
			let msg={role:"user",content:prompt};
			/*#{1J7TA6IFO0FilterMessage*/
			/*}#1J7TA6IFO0FilterMessage*/
			messages.push(msg);
		}
		/*#{1J7TA6IFO0PreCall*/
		/*}#1J7TA6IFO0PreCall*/
		result=(result===null)?(await session.callSegLLM("CodeWithSelection@"+agentURL,opts,messages,true)):result;
		/*#{1J7TA6IFO0PostLLM*/
		/*}#1J7TA6IFO0PostLLM*/
		chatMem.push({role:"user",content:prompt});
		chatMem.push({role:"assistant",content:result});
		if(chatMem.length>20){
			let removedMsgs=chatMem.splice(0,2);
			/*#{1J7TA6IFO0PostClear*/
			/*}#1J7TA6IFO0PostClear*/
		}
		result=trimJSON(result);
		/*#{1J7TA6IFO0PostCall*/
		/*}#1J7TA6IFO0PostCall*/
		return {seg:CheckAction,result:(result),preSeg:"1J7TA6IFO0",outlet:"1J7TA6IFP1"};
	};
	CodeWithSelection.jaxId="1J7TA6IFO0"
	CodeWithSelection.url="CodeWithSelection@"+agentURL
	CodeWithSelection.messages=[];
	
	segs["CheckAction"]=CheckAction=async function(input){//:1J7TCSL3V0
		let result=input;
		if(!!input.textOutput){
			let output=input;
			return {seg:TextOutput,result:(output),preSeg:"1J7TCSL3V0",outlet:"1J7TCUBPB0"};
		}
		if(!!input.replaceCode){
			return {seg:Result,result:(input),preSeg:"1J7TCSL3V0",outlet:"1J7TD0NAJ0"};
		}
		return {result:result};
	};
	CheckAction.jaxId="1J7TCSL3V0"
	CheckAction.url="CheckAction@"+agentURL
	
	segs["TextOutput"]=TextOutput=async function(input){//:1J7TCV91V0
		let tip=(input.textOutput);
		let tipRole=("assistant");
		let placeholder=("");
		let allowFile=(false)||false;
		let allowEmpty=(false)||false;
		let askUpward=(false);
		let text=("");
		let result="";
		if(askUpward && tip){
			result=await session.askUpward($agent,tip);
		}else{
			if(tip){
				session.addChatText(tipRole,tip);
			}
			result=await session.askChatInput({type:"input",placeholder:placeholder,text:text,allowFile:allowFile,allowEmpty:allowEmpty});
		}
		if(typeof(result)==="string"){
			session.addChatText("user",result);
		}else if(result.assets && result.prompt){
			session.addChatText("user",`${result.prompt}\n- - -\n${result.assets.join("\n- - -\n")}`,{render:true});
		}else{
			session.addChatText("user",result.text||result.prompt||result);
		}
		return {seg:CodeWithSelection,result:(result),preSeg:"1J7TCV91V0",outlet:"1J7TD0NAJ2"};
	};
	TextOutput.jaxId="1J7TCV91V0"
	TextOutput.url="TextOutput@"+agentURL
	
	segs["Result"]=Result=async function(input){//:1J7TD19AA0
		let result=input
		/*#{1J7TD19AA0Code*/
		/*}#1J7TD19AA0Code*/
		return {result:result};
	};
	Result.jaxId="1J7TD19AA0"
	Result.url="Result@"+agentURL
	
	agent=$agent={
		isAIAgent:true,
		session:session,
		name:"CodeWithSelection",
		url:agentURL,
		autoStart:true,
		jaxId:"1J7V9TL1R0",
		context:context,
		livingSeg:null,
		execChat:async function(input/*{platform,model,code}*/){
			let result;
			parseAgentArgs(input);
			/*#{1J7V9TL1R0PreEntry*/
			/*}#1J7V9TL1R0PreEntry*/
			result={seg:CodeWithSelection,"input":input};
			/*#{1J7V9TL1R0PostEntry*/
			/*}#1J7V9TL1R0PostEntry*/
			return result;
		},
		/*#{1J7V9TL1R0MoreAgentAttrs*/
		/*}#1J7V9TL1R0MoreAgentAttrs*/
	};
	/*#{1J7V9TL1R0PostAgent*/
	/*}#1J7V9TL1R0PostAgent*/
	return agent;
};
/*#{1J7V9TL1R0ExCodes*/
/*}#1J7V9TL1R0ExCodes*/

//#CodyExport>>>
//#CodyExport<<<
/*#{1J7V9TL1R0PostDoc*/
/*}#1J7V9TL1R0PostDoc*/


export default CodeWithSelection;
export{CodeWithSelection};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DocAIAgent",
//	"jaxId": "1J7V9TL1R0",
//	"attrs": {
//		"editObjs": {
//			"jaxId": "1HRS3QLCQ0",
//			"attrs": {
//				"CodeWithSelection": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1HRS3QLCQ6",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1HRS3QLCQ7",
//							"attrs": {}
//						},
//						"properties": {
//							"jaxId": "1HRS3QLCQ8",
//							"attrs": {}
//						},
//						"functions": {
//							"jaxId": "1HRS3QLCQ9",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false",
//						"exportClass": "false",
//						"superClass": ""
//					},
//					"mockups": {}
//				}
//			}
//		},
//		"agent": {
//			"jaxId": "1HRS3QLCQ1",
//			"attrs": {}
//		},
//		"showName": "",
//		"entry": "CodeAtCursor",
//		"autoStart": "true",
//		"inBrowser": "true",
//		"debug": "true",
//		"apiArgs": {
//			"jaxId": "1HRS3QLCQ5",
//			"attrs": {
//				"platform": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1J7TA5INA0",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				},
//				"model": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1J7TA5INA1",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				},
//				"code": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1J7TA5INA2",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1HRS3QLCQ2",
//			"attrs": {
//				"aiCfg": {
//					"type": "auto",
//					"valText": "#{platform:\"OpenAI\",model:\"gpt-4o\"}"
//				}
//			}
//		},
//		"context": {
//			"jaxId": "1HRS3QLCQ3",
//			"attrs": {}
//		},
//		"globalMockup": {
//			"jaxId": "1HRS3QLCQ4",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "aiseg",
//					"def": "callLLM",
//					"jaxId": "1J7TA6IFO0",
//					"attrs": {
//						"id": "CodeWithSelection",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "120",
//						"y": "170",
//						"desc": "Excute a LLM call.",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1J7TA6IFO1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1J7TA6IFP0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"platform": "#platform||\"OpenAI\"",
//						"mode": "#model||\"gpt-5\"",
//						"system": "\n### You are a coding AI Agent. \n- The input is a piece of code and coding instruction. Carefully read through the code, locate the “[-AI-]” marker, and based on user instruction and the context of the code, return the code, comment contentto replace the “[-AI->]” and “[<-AI-]” marker pair, or output chat text to  user for suggestion or discuss.\n- Your ouput must in JSON format.\n\n### Return code:\nIf based on the original code and instruction, you can export code that replace the codes between \"[-AI->]\" and \"[<-AI-]\"marker.\nPut your replacement code in \"replaceCode\" properity of result JOSN.\nExample: \nInput: \n```\n</code>\nfunction sum(a, b)\n{\n\t[-AI->]return a+=b;[<-A-]\n}\n</code>\n<instruction>\ndebug\n</instruction>\n```\nOutput: \n```\n{ \n\t\"replaceCode\": \"return a + b;\" \n}\n```\n**Please note:**  \n- 1. Your output must be in JSON format, with the content to replace code betwwn “[-AI->]” and “[<-AI-]” assigned to the “replaceCode” variable.  \n- 2. Output only the replacement part, not the entire code. \n- 3. You may add necessary comments to the generated code.\n- 4. If the “[-AI->]”/“[<-AI-]” part is a (in) comment, provide a reasonable comment as the value of the “replaceCode” variable in JSON.\n\n### Suggestion / Discuss:\nIf the instruction is finding bug, asking for suggestion, or if you need more information from user to complete the coding task. You can put your output / question in \"textOutput\" property of the result JSON:\nExample:\n```\n{\n\t\"textOutput\":\"When x===0, your code may fail...\"\n}\n```\n",
//						"temperature": "0",
//						"maxToken": "4050",
//						"topP": "1",
//						"fqcP": "0",
//						"prcP": "0",
//						"messages": {
//							"attrs": []
//						},
//						"prompt": "#input.code||input",
//						"seed": "",
//						"outlet": {
//							"jaxId": "1J7TA6IFP1",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1J7TCSL3V0"
//						},
//						"stream": "true",
//						"secret": "false",
//						"allowCheat": "false",
//						"GPTCheats": {
//							"attrs": []
//						},
//						"shareChatName": "",
//						"keepChat": "20 messages",
//						"clearChat": "2",
//						"apiFiles": {
//							"attrs": []
//						},
//						"parallelFunction": "false",
//						"responseFormat": "json_object",
//						"formatDef": "\"\""
//					},
//					"icon": "llm.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "brunch",
//					"jaxId": "1J7TCSL3V0",
//					"attrs": {
//						"id": "CheckAction",
//						"viewName": "",
//						"label": "",
//						"x": "385",
//						"y": "170",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1J7TD0NAO0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1J7TD0NAO1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1J7TD0NAJ1",
//							"attrs": {
//								"id": "Default",
//								"desc": "输出节点。",
//								"output": ""
//							}
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1J7TCUBPB0",
//									"attrs": {
//										"id": "Text",
//										"desc": "输出节点。",
//										"output": "#input",
//										"codes": "false",
//										"context": {
//											"jaxId": "1J7TD0NAO4",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1J7TD0NAO5",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#!!input.textOutput"
//									},
//									"linkedSeg": "1J7TCV91V0"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1J7TD0NAJ0",
//									"attrs": {
//										"id": "Code",
//										"desc": "输出节点。",
//										"output": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1J7TD0NAO2",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1J7TD0NAO3",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#!!input.replaceCode"
//									},
//									"linkedSeg": "1J7TD19AA0"
//								}
//							]
//						}
//					},
//					"icon": "condition.svg",
//					"reverseOutlets": true
//				},
//				{
//					"type": "aiseg",
//					"def": "askChat",
//					"jaxId": "1J7TCV91V0",
//					"attrs": {
//						"id": "TextOutput",
//						"viewName": "",
//						"label": "",
//						"x": "655",
//						"y": "140",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1J7TD0NAO6",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1J7TD0NAO7",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"tip": "#input.textOutput",
//						"tipRole": "Assistant",
//						"placeholder": "",
//						"text": "",
//						"file": "false",
//						"allowEmpty": "false",
//						"showText": "true",
//						"askUpward": "false",
//						"outlet": {
//							"jaxId": "1J7TD0NAJ2",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1J7TCVSB90"
//						}
//					},
//					"icon": "chat.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1J7TCVSB90",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "800",
//						"y": "275",
//						"outlet": {
//							"jaxId": "1J7TD0NAO8",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1J7TD0SLG0"
//						},
//						"dir": "R2L"
//					},
//					"icon": "arrowright.svg",
//					"isConnector": true
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1J7TD0SLG0",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "150",
//						"y": "275",
//						"outlet": {
//							"jaxId": "1J7TD13240",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1J7TA6IFO0"
//						},
//						"dir": "R2L"
//					},
//					"icon": "arrowright.svg",
//					"isConnector": true
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1J7TD19AA0",
//					"attrs": {
//						"id": "Result",
//						"viewName": "",
//						"label": "",
//						"x": "655",
//						"y": "215",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1J7TD1EGS0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1J7TD1EGS1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1J7TD1EGO0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							}
//						},
//						"outlets": {
//							"attrs": []
//						},
//						"result": "#input"
//					},
//					"icon": "tab_css.svg"
//				}
//			]
//		},
//		"desc": "This is an AI agent.",
//		"exportAPI": "false",
//		"exportAddOn": "false",
//		"addOnOpts": ""
//	}
//}