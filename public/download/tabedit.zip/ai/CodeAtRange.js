//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import pathLib from "/@path";
import inherits from "/@inherits";
import Base64 from "/@tabos/utils/base64.js";
import {trimJSON} from "/@aichat/utils.js";
/*#{1HRU196360MoreImports*/
/*}#1HRU196360MoreImports*/
const agentURL=(new URL(import.meta.url)).pathname;
const baseURL=pathLib.dirname(agentURL);
const basePath=baseURL.startsWith("file://")?decodeURI(baseURL):baseURL;
const $ln=VFACT.lanCode||"EN";
const argsTemplate={
	properties:{
		"platform":{
			"name":"platform","type":"auto",
			"defaultValue":"OpenAI",
			"desc":"",
		},
		"model":{
			"name":"model","type":"auto",
			"defaultValue":"",
			"desc":"",
		},
		"code":{
			"name":"code","type":"auto",
			"defaultValue":"",
			"desc":"",
		},
		"assets":{
			"name":"assets","type":"auto",
			"defaultValue":"",
			"desc":"",
		}
	},
	/*#{1HRU196360ArgsView*/
	/*}#1HRU196360ArgsView*/
};

/*#{1HRU196360StartDoc*/
/*}#1HRU196360StartDoc*/
//----------------------------------------------------------------------------
let CodeAtRange=async function(session){
	let platform,model,code,assets;
	const $ln=session.language||"EN";
	let context,globalContext=session.globalContext;
	let self;
	let AICoder,CheckResult,Finish,AskUser;
	let aiCfg={platform:"OpenAI",model:"gpt-4o"};
	
	/*#{1HRU196360LocalVals*/
	/*}#1HRU196360LocalVals*/
	
	function parseAgentArgs(input){
		if(typeof(input)=='object'){
			platform=input.platform;
			model=input.model;
			code=input.code;
			assets=input.assets;
		}else{
			platform=undefined;
			model=undefined;
			code=undefined;
			assets=undefined;
		}
		/*#{1HRU196360ParseArgs*/
		/*}#1HRU196360ParseArgs*/
	}
	
	/*#{1HRU196360PreContext*/
	/*}#1HRU196360PreContext*/
	context={};
	context=VFACT.flexState(context);
	/*#{1HRU196360PostContext*/
	/*}#1HRU196360PostContext*/
	let $agent,agent,segs={};
	segs["AICoder"]=AICoder=async function(input){//:1HRU19Q280
		let prompt;
		let $platform=platform||"OpenAI";
		let $model=model||"gpt-5";
		let $agent;
		let result=null;
		/*#{1HRU19Q280Input*/
		let app=VFACT.app;
		let appPrj=app.prj;
		aiCfg=appPrj?appPrj.prjConfig.aiCoder:{};
		/*}#1HRU19Q280Input*/
		
		let opts={
			platform:$platform,
			mode:$model,
			maxToken:4050,
			temperature:0,
			topP:1,
			fqcP:0,
			prcP:0,
			secret:true,
			responseFormat:"json_object"
		};
		let chatMem=AICoder.messages
		let seed="";
		if(seed!==undefined){opts.seed=seed;}
		let messages=[
			{role:"system",content:"You are an AI Agent for code enhancement/completion/correction.  \n\nThe input is a piece of code; please carefully read it, locate the code between the “[-AI-<]” and “[>-AI-]” markers, and based on the surrounding code context, return the code or comment content for completion/correction in the “[-AI->]” and “[<-AI-]” markers.  \n\nFor example:  \nInput:  \n```\nfunction sum(a, b) {\n    [-AI->]return a;[<-AI-]\n}\n```\nOutput：  \n```\n{\n\t\"replacCode\":\"return a+b;\"\n}\n```\n\n###\nPlease note:\n- Your output must be in JSON format, placing the content to replace between “[-AI->]” and “[<-AI-]” in the “replaceCode” variable.\n\n- Carefully read the code context, infer the function of the code, then enhance or correct it. Corrections may include (but are not limited to) spelling mistakes, syntax errors, logical or procedural errors, etc.\n\n- Output only the part that needs replacement, not the entire code.\n\n- **Very important:** Preserve the original indentation, line breaks, and formatting of the code, ensuring the generated code matches the style of the original code.\n\n- You may add necessary comments to the generated code.  \n\n- If the content between “[-AI->]” and “[<-AI-]” is a comment, provide a reasonable comment as the “replaceCode” variable in the JSON.\n\n### Discuss:\nIf you need more information from user to complete the coding task. You can put your question in \"ask\" property of the result JSON:\nExample:\n```\n{\n\t\"ask\":\"What color you want the button to be?\"\n}\n```\n"},
		];
		messages.push(...chatMem);
		/*#{1HRU19Q280PrePrompt*/
		opts.coder=true;
		/*}#1HRU19Q280PrePrompt*/
		prompt=input.code||input;
		if(prompt!==null){
			if(typeof(prompt)!=="string"){
				prompt=JSON.stringify(prompt,null,"	");
			}
			let msg={role:"user",content:prompt};
			/*#{1HRU19Q280FilterMessage*/
			/*}#1HRU19Q280FilterMessage*/
			messages.push(msg);
		}
		/*#{1HRU19Q280PreCall*/
		if(assets && assets.length>0){
			let file;
			for(file of assets){
				switch(file.type){
					default:{
						messages.push({
							role:"user",content:`### Asset: ${file.path}\n#### Asset type:${file.typeDesc}\n\`\`\`\n${file.codes}\n\`\`\`\n`
						});
						break;
					}
					case "image":{
						//TODO: Code this:
						break;
					}
					case "audio":{
						//TODO: Code this:
						break;
					}
					case "video":{
						//TODO: Code this:
						break;
					}
				}
			}
		}
		/*}#1HRU19Q280PreCall*/
		if($agent){
			result=(result===undefined)?(await session.callAgent($agent.agentNode,$agent.path,{messages:messages,maxToken:opts.maxToken,responseFormat:opts.responseFormat})):result;
		}else{
			result=(result===null)?(await session.callSegLLM("AICoder@"+agentURL,opts,messages,true)):result;
		}
		/*#{1HRU19Q280PostLLM*/
		/*}#1HRU19Q280PostLLM*/
		chatMem.push({role:"user",content:prompt});
		chatMem.push({role:"assistant",content:result});
		if(chatMem.length>20){
			let removedMsgs=chatMem.splice(0,2);
			/*#{1HRU19Q280PostClear*/
			/*}#1HRU19Q280PostClear*/
		}
		result=trimJSON(result);
		/*#{1HRU19Q280PostCall*/
		/*}#1HRU19Q280PostCall*/
		/*#{1HRU19Q280PreResult*/
		/*}#1HRU19Q280PreResult*/
		return {seg:CheckResult,result:(result),preSeg:"1HRU19Q280",outlet:"1HRU19Q290"};
	};
	AICoder.jaxId="1HRU19Q280"
	AICoder.url="AICoder@"+agentURL
	AICoder.messages=[];
	
	segs["CheckResult"]=CheckResult=async function(input){//:1JF48J1UR0
		let result=input;
		if(input.replaceCode){
			let output=input;
			return {seg:Finish,result:(output),preSeg:"1JF48J1UR0",outlet:"1JF48KFM90"};
		}
		if(input.ask){
			let output=input;
			return {seg:AskUser,result:(output),preSeg:"1JF48J1UR0",outlet:"1JF48J8CL0"};
		}
		return {result:result};
	};
	CheckResult.jaxId="1JF48J1UR0"
	CheckResult.url="CheckResult@"+agentURL
	
	segs["Finish"]=Finish=async function(input){//:1JF48JMRG0
		let result=input
		try{
			/*#{1JF48JMRG0Code*/
			/*}#1JF48JMRG0Code*/
		}catch(error){
			/*#{1JF48JMRG0ErrorCode*/
			/*}#1JF48JMRG0ErrorCode*/
		}
		return {result:result};
	};
	Finish.jaxId="1JF48JMRG0"
	Finish.url="Finish@"+agentURL
	
	segs["AskUser"]=AskUser=async function(input){//:1JF48MPCU0
		let tip=(input.ask);
		let tipRole=("assistant");
		let placeholder=("");
		let allowFile=(false)||false;
		let allowEmpty=(false)||false;
		let askUpward=(false);
		let text=("");
		let result="";
		if(askUpward && tip){
			result=await session.askUpward($agent,tip);
		}else{
			if(tip){
				session.addChatText(tipRole,tip);
			}
			result=await session.askChatInput({type:"input",placeholder:placeholder,text:text,allowFile:allowFile,allowEmpty:allowEmpty});
		}
		if(typeof(result)==="string"){
			session.addChatText("user",result);
		}else if(result.assets && result.prompt){
			session.addChatText("user",`${result.prompt}\n- - -\n${result.assets.join("\n- - -\n")}`,{render:true});
		}else{
			session.addChatText("user",result.text||result.prompt||result);
		}
		return {seg:AICoder,result:(result),preSeg:"1JF48MPCU0",outlet:"1JF48NBG90"};
	};
	AskUser.jaxId="1JF48MPCU0"
	AskUser.url="AskUser@"+agentURL
	
	agent=$agent={
		isAIAgent:true,
		session:session,
		name:"CodeAtRange",
		url:agentURL,
		autoStart:true,
		jaxId:"1HRU196360",
		context:context,
		livingSeg:null,
		execChat:async function(input/*{platform,model,code,assets}*/){
			let result;
			parseAgentArgs(input);
			/*#{1HRU196360PreEntry*/
			/*}#1HRU196360PreEntry*/
			result={seg:AICoder,"input":input};
			/*#{1HRU196360PostEntry*/
			/*}#1HRU196360PostEntry*/
			return result;
		},
		/*#{1HRU196360MoreAgentAttrs*/
		/*}#1HRU196360MoreAgentAttrs*/
	};
	/*#{1HRU196360PostAgent*/
	/*}#1HRU196360PostAgent*/
	return agent;
};
/*#{1HRU196360ExCodes*/
/*}#1HRU196360ExCodes*/

//#CodyExport>>>
//#CodyExport<<<
/*#{1HRU196360PostDoc*/
/*}#1HRU196360PostDoc*/


export default CodeAtRange;
export{CodeAtRange};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DocAIAgent",
//	"jaxId": "1HRU196360",
//	"attrs": {
//		"editObjs": {
//			"jaxId": "1HRU196361",
//			"attrs": {
//				"CodeAtRange": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1HRU196367",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1HRU196368",
//							"attrs": {}
//						},
//						"properties": {
//							"jaxId": "1HRU196369",
//							"attrs": {}
//						},
//						"functions": {
//							"jaxId": "1HRU1963610",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false",
//						"superClass": "",
//						"exportClass": "false"
//					},
//					"mockups": {}
//				}
//			}
//		},
//		"agent": {
//			"jaxId": "1HRU196362",
//			"attrs": {}
//		},
//		"showName": "",
//		"entry": "",
//		"autoStart": "true",
//		"inBrowser": "true",
//		"debug": "true",
//		"apiArgs": {
//			"jaxId": "1HRU196366",
//			"attrs": {
//				"platform": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1JF48R50M0",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "OpenAI",
//						"desc": ""
//					}
//				},
//				"model": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1JF48R50M1",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				},
//				"code": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1JF48R50M2",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				},
//				"assets": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1JF48R50M3",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1HRU196363",
//			"attrs": {
//				"aiCfg": {
//					"type": "auto",
//					"valText": "#{platform:\"OpenAI\",model:\"gpt-4o\"}"
//				}
//			}
//		},
//		"context": {
//			"jaxId": "1HRU196364",
//			"attrs": {}
//		},
//		"globalMockup": {
//			"jaxId": "1HRU196365",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "aiseg",
//					"def": "callLLM",
//					"jaxId": "1HRU19Q280",
//					"attrs": {
//						"id": "AICoder",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "130",
//						"y": "365",
//						"desc": "Excute a LLM call.",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1HRU19Q2C0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1HRU19Q2C1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"platform": "#platform||\"OpenAI\"",
//						"mode": "#model||\"gpt-5\"",
//						"system": "You are an AI Agent for code enhancement/completion/correction.  \n\nThe input is a piece of code; please carefully read it, locate the code between the “[-AI-<]” and “[>-AI-]” markers, and based on the surrounding code context, return the code or comment content for completion/correction in the “[-AI->]” and “[<-AI-]” markers.  \n\nFor example:  \nInput:  \n```\nfunction sum(a, b) {\n    [-AI->]return a;[<-AI-]\n}\n```\nOutput：  \n```\n{\n\t\"replacCode\":\"return a+b;\"\n}\n```\n\n###\nPlease note:\n- Your output must be in JSON format, placing the content to replace between “[-AI->]” and “[<-AI-]” in the “replaceCode” variable.\n\n- Carefully read the code context, infer the function of the code, then enhance or correct it. Corrections may include (but are not limited to) spelling mistakes, syntax errors, logical or procedural errors, etc.\n\n- Output only the part that needs replacement, not the entire code.\n\n- **Very important:** Preserve the original indentation, line breaks, and formatting of the code, ensuring the generated code matches the style of the original code.\n\n- You may add necessary comments to the generated code.  \n\n- If the content between “[-AI->]” and “[<-AI-]” is a comment, provide a reasonable comment as the “replaceCode” variable in the JSON.\n\n### Discuss:\nIf you need more information from user to complete the coding task. You can put your question in \"ask\" property of the result JSON:\nExample:\n```\n{\n\t\"ask\":\"What color you want the button to be?\"\n}\n```\n",
//						"temperature": "0",
//						"maxToken": "4050",
//						"topP": "1",
//						"fqcP": "0",
//						"prcP": "0",
//						"messages": {
//							"attrs": []
//						},
//						"prompt": "#input.code||input",
//						"seed": "",
//						"outlet": {
//							"jaxId": "1HRU19Q290",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1JF48J1UR0"
//						},
//						"stream": "true",
//						"secret": "true",
//						"allowCheat": "false",
//						"GPTCheats": {
//							"attrs": []
//						},
//						"shareChatName": "",
//						"keepChat": "20 messages",
//						"clearChat": "2",
//						"apiFiles": {
//							"attrs": []
//						},
//						"parallelFunction": "false",
//						"responseFormat": "json_object",
//						"formatDef": "\"\"",
//						"outlets": {
//							"attrs": []
//						}
//					},
//					"icon": "llm.svg",
//					"reverseOutlets": true
//				},
//				{
//					"type": "aiseg",
//					"def": "brunch",
//					"jaxId": "1JF48J1UR0",
//					"attrs": {
//						"id": "CheckResult",
//						"viewName": "",
//						"label": "",
//						"x": "345",
//						"y": "365",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1JF48KFMD0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1JF48KFMD1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1JF48KFMA0",
//							"attrs": {
//								"id": "Default",
//								"desc": "输出节点。",
//								"output": ""
//							}
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1JF48KFM90",
//									"attrs": {
//										"id": "Code",
//										"desc": "输出节点。",
//										"output": "#input",
//										"codes": "false",
//										"context": {
//											"jaxId": "1JF48KFMD2",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1JF48KFMD3",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#input.replaceCode"
//									},
//									"linkedSeg": "1JF48JMRG0"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1JF48J8CL0",
//									"attrs": {
//										"id": "Ask",
//										"desc": "输出节点。",
//										"output": "#input",
//										"codes": "false",
//										"context": {
//											"jaxId": "1JF48KFMD4",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1JF48KFMD5",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#input.ask"
//									},
//									"linkedSeg": "1JF48MPCU0"
//								}
//							]
//						}
//					},
//					"icon": "condition.svg",
//					"reverseOutlets": true
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1JF48JMRG0",
//					"attrs": {
//						"id": "Finish",
//						"viewName": "",
//						"label": "",
//						"x": "600",
//						"y": "290",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1JF48KFMD6",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1JF48KFMD7",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1JF48KFMA1",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							}
//						},
//						"outlets": {
//							"attrs": []
//						},
//						"result": "#input",
//						"errorSeg": ""
//					},
//					"icon": "tab_css.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "askChat",
//					"jaxId": "1JF48MPCU0",
//					"attrs": {
//						"id": "AskUser",
//						"viewName": "",
//						"label": "",
//						"x": "600",
//						"y": "365",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1JF48NBGD0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1JF48NBGD1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"tip": "#input.ask",
//						"tipRole": "Assistant",
//						"placeholder": "",
//						"text": "",
//						"file": "false",
//						"allowEmpty": "false",
//						"showText": "true",
//						"askUpward": "false",
//						"outlet": {
//							"jaxId": "1JF48NBG90",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1JF48O23H0"
//						}
//					},
//					"icon": "chat.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1JF48O23H0",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "720",
//						"y": "490",
//						"outlet": {
//							"jaxId": "1JF48OK7G0",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1JF48O6GD0"
//						},
//						"dir": "R2L"
//					},
//					"icon": "arrowright.svg",
//					"isConnector": true
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1JF48O6GD0",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "170",
//						"y": "490",
//						"outlet": {
//							"jaxId": "1JF48OK7G1",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1HRU19Q280"
//						},
//						"dir": "R2L"
//					},
//					"icon": "arrowright.svg",
//					"isConnector": true
//				}
//			]
//		},
//		"desc": "This is an AI agent.",
//		"exportAPI": "false",
//		"exportAddOn": "false",
//		"addOnOpts": ""
//	}
//}