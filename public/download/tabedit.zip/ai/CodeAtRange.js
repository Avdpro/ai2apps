//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import pathLib from "/@path";
import inherits from "/@inherits";
import Base64 from "/@tabos/utils/base64.js";
import {trimJSON} from "/@aichat/utils.js";
/*#{1HRU196360MoreImports*/
/*}#1HRU196360MoreImports*/
const agentURL=(new URL(import.meta.url)).pathname;
const basePath=pathLib.dirname(agentURL);
const $ln=VFACT.lanCode||"EN";
/*#{1HRU196360StartDoc*/
/*}#1HRU196360StartDoc*/
//----------------------------------------------------------------------------
let CodeAtRange=async function(session){
	let context,globalContext;
	let self;
	let AICoder;
	/*#{1HRU196360LocalVals*/
	/*}#1HRU196360LocalVals*/
	
	/*#{1HRU196360PreContext*/
	/*}#1HRU196360PreContext*/
	globalContext=session.globalContext;
	context={};
	context=VFACT.flexState(context);
	/*#{1HRU196360PostContext*/
	/*}#1HRU196360PostContext*/
	let agent,segs={};
	segs["AICoder"]=AICoder=async function(input){//:1HRU19Q280
		let prompt;
		let result;
		
		let opts={
			platform:"OpenAI",
			mode:"gpt-4-1106-preview",
			maxToken:4050,
			temperature:0,
			topP:1,
			fqcP:0,
			prcP:0,
			secret:false,
			responseFormat:"json_object"
		};
		let chatMem=AICoder.messages
		let seed="";
		if(seed!==undefined){opts.seed=seed;}
		let messages=[
			{role:"system",content:"你是一个代码完善/补全/修正AI Agent。\n对话输入是一段代码，请仔细阅读代码，找到位于\"[-AI-<]\"和\"[>-AI-]\"标记之间的代码，根据代码上下文，返回用于完善/修正后的\"[-AI->]\"\"[<-AI-]\"标记之间的代码或者注释内容。\n例如：\n输入:\n```\nfunction sum(a,b){\n\t[-AI->]return a;[<-AI-]\n}\n```\n输出：\n{\n\t\"replacCode\":\"return a+b;\"\n}\n\n请注意\n1）你的输出必须是JSON格式，把要替换\"[-AI->]\"和\"[-AI->]\"之间的内容放在\"replaceCode\"变量里。\n2）仔细阅读代码上下文，推测代码功能，然后完善并修正代码，修正的情况包括但不限于拼写错误，语法错误，逻辑、流程错误等。\n3）仅输出需要替换的部分，而不是输出完整的代码。\n4）非常重要！你要保留原有代码的缩进，换行等格式，注意生成的代码要符合原始代码的书写风格。\n5）对你生成代码，你可以添加必要的注释。\n6）如果标记\"[-AI->]\"\"[<-AI-]\"内的部分是注释，请给出合理的注释内容作为JSON的\"relaceCode\"变量。"},
		];
		prompt=input;
		if(prompt!==null){
			messages.push({role:"user",content:prompt});
		}
		result=await session.callSegLLM("AICoder@"+agentURL,opts,messages,true);
		result=trimJSON(result);
		return {result:result};
	};
	AICoder.jaxId="1HRU19Q280"
	AICoder.url="AICoder@"+agentURL
	
	agent={
		isAIAgent:true,
		session:session,
		name:"CodeAtRange",
		url:agentURL,
		autoStart:true,
		jaxId:"1HRU196360",
		context:context,
		livingSeg:null,
		execChat:async function(input){
			let result;
			/*#{1HRU196360PreEntry*/
			/*}#1HRU196360PreEntry*/
			result={seg:AICoder,"input":input};
			/*#{1HRU196360PostEntry*/
			/*}#1HRU196360PostEntry*/
			return result;
		},
		/*#{1HRU196360MoreAgentAttrs*/
		/*}#1HRU196360MoreAgentAttrs*/
	};
	/*#{1HRU196360PostAgent*/
	/*}#1HRU196360PostAgent*/
	return agent;
};
/*#{1HRU196360ExCodes*/
/*}#1HRU196360ExCodes*/


export default CodeAtRange;
export{CodeAtRange};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DocAIAgent",
//	"jaxId": "1HRU196360",
//	"attrs": {
//		"editObjs": {
//			"jaxId": "1HRU196361",
//			"attrs": {
//				"CodeAtRange": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1HRU196367",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1HRU196368",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1HRU196369",
//							"attrs": {}
//						},
//						"functions": {
//							"jaxId": "1HRU1963610",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false"
//					},
//					"mockups": {}
//				}
//			}
//		},
//		"agent": {
//			"jaxId": "1HRU196362",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "aiseg",
//					"def": "callLLM",
//					"jaxId": "1HRU19Q280",
//					"attrs": {
//						"id": "AICoder",
//						"label": "New AI Seg",
//						"x": "140",
//						"y": "160",
//						"context": {
//							"jaxId": "1HRU19Q2C0",
//							"attrs": {}
//						},
//						"global": {
//							"jaxId": "1HRU19Q2C1",
//							"attrs": {}
//						},
//						"desc": "Excute a LLM call.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"platform": "OpenAI",
//						"mode": "GPT-4 Turbo",
//						"system": "你是一个代码完善/补全/修正AI Agent。\n对话输入是一段代码，请仔细阅读代码，找到位于\"[-AI-<]\"和\"[>-AI-]\"标记之间的代码，根据代码上下文，返回用于完善/修正后的\"[-AI->]\"\"[<-AI-]\"标记之间的代码或者注释内容。\n例如：\n输入:\n```\nfunction sum(a,b){\n\t[-AI->]return a;[<-AI-]\n}\n```\n输出：\n{\n\t\"replacCode\":\"return a+b;\"\n}\n\n请注意\n1）你的输出必须是JSON格式，把要替换\"[-AI->]\"和\"[-AI->]\"之间的内容放在\"replaceCode\"变量里。\n2）仔细阅读代码上下文，推测代码功能，然后完善并修正代码，修正的情况包括但不限于拼写错误，语法错误，逻辑、流程错误等。\n3）仅输出需要替换的部分，而不是输出完整的代码。\n4）非常重要！你要保留原有代码的缩进，换行等格式，注意生成的代码要符合原始代码的书写风格。\n5）对你生成代码，你可以添加必要的注释。\n6）如果标记\"[-AI->]\"\"[<-AI-]\"内的部分是注释，请给出合理的注释内容作为JSON的\"relaceCode\"变量。",
//						"temperature": "0",
//						"maxToken": "4050",
//						"topP": "1",
//						"fqcP": "0",
//						"prcP": "0",
//						"messages": {
//							"attrs": []
//						},
//						"prompt": "#input",
//						"seed": "",
//						"outlet": {
//							"jaxId": "1HRU19Q290",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							}
//						},
//						"secret": "false",
//						"allowCheat": "false",
//						"GPTCheats": {
//							"attrs": []
//						},
//						"shareChatName": "",
//						"keepChat": "No",
//						"clearChat": "2",
//						"apiFiles": {
//							"attrs": []
//						},
//						"parallelFunction": "false",
//						"responseFormat": "json_object"
//					}
//				}
//			]
//		},
//		"entry": "",
//		"autoStart": "true",
//		"debug": "true",
//		"localVars": {
//			"jaxId": "1HRU196363",
//			"attrs": {}
//		},
//		"context": {
//			"jaxId": "1HRU196364",
//			"attrs": {}
//		},
//		"globalMockup": {
//			"jaxId": "1HRU196365",
//			"attrs": {}
//		},
//		"desc": "This is an AI agent.",
//		"exportAPI": "false",
//		"apiArgs": {
//			"jaxId": "1HRU196366",
//			"attrs": {}
//		}
//	}
//}