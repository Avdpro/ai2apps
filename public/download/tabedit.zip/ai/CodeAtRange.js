//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import pathLib from "/@path";
import inherits from "/@inherits";
import Base64 from "/@tabos/utils/base64.js";
import {trimJSON} from "/@aichat/utils.js";
/*#{1HRU196360MoreImports*/
/*}#1HRU196360MoreImports*/
const agentURL=(new URL(import.meta.url)).pathname;
const basePath=pathLib.dirname(agentURL);
const $ln=VFACT.lanCode||"EN";
/*#{1HRU196360StartDoc*/
/*}#1HRU196360StartDoc*/
//----------------------------------------------------------------------------
let CodeAtRange=async function(session){
	let execInput;
	let context,globalContext;
	let self;
	let AICoder;
	let aiCfg={platform:"OpenAI",model:"gpt-4o"};
	
	/*#{1HRU196360LocalVals*/
	/*}#1HRU196360LocalVals*/
	
	function parseAgentArgs(input){
		execInput=input;
		/*#{1HRU196360ParseArgs*/
		/*}#1HRU196360ParseArgs*/
	}
	
	/*#{1HRU196360PreContext*/
	/*}#1HRU196360PreContext*/
	globalContext=session.globalContext;
	context={};
	context=VFACT.flexState(context);
	/*#{1HRU196360PostContext*/
	/*}#1HRU196360PostContext*/
	let agent,segs={};
	segs["AICoder"]=AICoder=async function(input){//:1HRU19Q280
		let prompt;
		let result=null;
		/*#{1HRU19Q280Input*/
		let app=VFACT.app;
		let appPrj=app.prj;
		aiCfg=appPrj?appPrj.prjConfig.aiCoder:{};
		/*}#1HRU19Q280Input*/
		
		let opts={
			platform:aiCfg.platform||"OpenAI",
			mode:aiCfg.model||"gpt-4o",
			maxToken:4050,
			temperature:0,
			topP:1,
			fqcP:0,
			prcP:0,
			secret:false,
			responseFormat:"json_object"
		};
		let chatMem=AICoder.messages
		let seed="";
		if(seed!==undefined){opts.seed=seed;}
		let messages=[
			{role:"system",content:"You are an AI Agent for code enhancement/completion/correction.  \n\nThe input is a piece of code; please carefully read it, locate the code between the “[-AI-<]” and “[>-AI-]” markers, and based on the surrounding code context, return the code or comment content for completion/correction in the “[-AI->]” and “[<-AI-]” markers.  \n\nFor example:  \nInput:  \n```\nfunction sum(a, b) {\n    [-AI->]return a;[<-AI-]\n}\n```\nOutput：  \n```\n{\n\t\"replacCode\":\"return a+b;\"\n}\n```\n\n###\n\nPlease note:\n- Your output must be in JSON format, placing the content to replace between “[-AI->]” and “[<-AI-]” in the “replaceCode” variable.\n\n- Carefully read the code context, infer the function of the code, then enhance or correct it. Corrections may include (but are not limited to) spelling mistakes, syntax errors, logical or procedural errors, etc.\n\n- Output only the part that needs replacement, not the entire code.\n\n- **Very important:** Preserve the original indentation, line breaks, and formatting of the code, ensuring the generated code matches the style of the original code.\n\n- You may add necessary comments to the generated code.  \n\n- If the content between “[-AI->]” and “[<-AI-]” is a comment, provide a reasonable comment as the “replaceCode” variable in the JSON.\n"},
		];
		/*#{1HRU19Q280PrePrompt*/
		opts.coder=true;
		/*}#1HRU19Q280PrePrompt*/
		prompt=input;
		if(prompt!==null){
			messages.push({role:"user",content:prompt});
		}
		/*#{1HRU19Q280PreCall*/
		/*}#1HRU19Q280PreCall*/
		result=(result===null)?(await session.callSegLLM("AICoder@"+agentURL,opts,messages,true)):result;
		result=trimJSON(result);
		/*#{1HRU19Q280PostCall*/
		/*}#1HRU19Q280PostCall*/
		return {result:result};
	};
	AICoder.jaxId="1HRU19Q280"
	AICoder.url="AICoder@"+agentURL
	
	agent={
		isAIAgent:true,
		session:session,
		name:"CodeAtRange",
		url:agentURL,
		autoStart:true,
		jaxId:"1HRU196360",
		context:context,
		livingSeg:null,
		execChat:async function(input){
			let result;
			parseAgentArgs(input);
			/*#{1HRU196360PreEntry*/
			/*}#1HRU196360PreEntry*/
			result={seg:AICoder,"input":input};
			/*#{1HRU196360PostEntry*/
			/*}#1HRU196360PostEntry*/
			return result;
		},
		/*#{1HRU196360MoreAgentAttrs*/
		/*}#1HRU196360MoreAgentAttrs*/
	};
	/*#{1HRU196360PostAgent*/
	/*}#1HRU196360PostAgent*/
	return agent;
};
/*#{1HRU196360ExCodes*/
/*}#1HRU196360ExCodes*/

/*#{1HRU196360PostDoc*/
/*}#1HRU196360PostDoc*/


export default CodeAtRange;
export{CodeAtRange};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DocAIAgent",
//	"jaxId": "1HRU196360",
//	"attrs": {
//		"editObjs": {
//			"jaxId": "1HRU196361",
//			"attrs": {
//				"CodeAtRange": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1HRU196367",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1HRU196368",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1HRU196369",
//							"attrs": {}
//						},
//						"functions": {
//							"jaxId": "1HRU1963610",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false"
//					},
//					"mockups": {}
//				}
//			}
//		},
//		"agent": {
//			"jaxId": "1HRU196362",
//			"attrs": {}
//		},
//		"entry": "",
//		"autoStart": "true",
//		"debug": "true",
//		"apiArgs": {
//			"jaxId": "1HRU196366",
//			"attrs": {}
//		},
//		"localVars": {
//			"jaxId": "1HRU196363",
//			"attrs": {
//				"aiCfg": {
//					"type": "auto",
//					"valText": "#{platform:\"OpenAI\",model:\"gpt-4o\"}"
//				}
//			}
//		},
//		"context": {
//			"jaxId": "1HRU196364",
//			"attrs": {}
//		},
//		"globalMockup": {
//			"jaxId": "1HRU196365",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "aiseg",
//					"def": "callLLM",
//					"jaxId": "1HRU19Q280",
//					"attrs": {
//						"id": "AICoder",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "140",
//						"y": "160",
//						"desc": "Excute a LLM call.",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1HRU19Q2C0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1HRU19Q2C1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"platform": "#aiCfg.platform||\"OpenAI\"",
//						"mode": "#aiCfg.model||\"gpt-4o\"",
//						"system": "You are an AI Agent for code enhancement/completion/correction.  \n\nThe input is a piece of code; please carefully read it, locate the code between the “[-AI-<]” and “[>-AI-]” markers, and based on the surrounding code context, return the code or comment content for completion/correction in the “[-AI->]” and “[<-AI-]” markers.  \n\nFor example:  \nInput:  \n```\nfunction sum(a, b) {\n    [-AI->]return a;[<-AI-]\n}\n```\nOutput：  \n```\n{\n\t\"replacCode\":\"return a+b;\"\n}\n```\n\n###\n\nPlease note:\n- Your output must be in JSON format, placing the content to replace between “[-AI->]” and “[<-AI-]” in the “replaceCode” variable.\n\n- Carefully read the code context, infer the function of the code, then enhance or correct it. Corrections may include (but are not limited to) spelling mistakes, syntax errors, logical or procedural errors, etc.\n\n- Output only the part that needs replacement, not the entire code.\n\n- **Very important:** Preserve the original indentation, line breaks, and formatting of the code, ensuring the generated code matches the style of the original code.\n\n- You may add necessary comments to the generated code.  \n\n- If the content between “[-AI->]” and “[<-AI-]” is a comment, provide a reasonable comment as the “replaceCode” variable in the JSON.\n",
//						"temperature": "0",
//						"maxToken": "4050",
//						"topP": "1",
//						"fqcP": "0",
//						"prcP": "0",
//						"messages": {
//							"attrs": []
//						},
//						"prompt": "#input",
//						"seed": "",
//						"outlet": {
//							"jaxId": "1HRU19Q290",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							}
//						},
//						"secret": "false",
//						"allowCheat": "false",
//						"GPTCheats": {
//							"attrs": []
//						},
//						"shareChatName": "",
//						"keepChat": "No",
//						"clearChat": "2",
//						"apiFiles": {
//							"attrs": []
//						},
//						"parallelFunction": "false",
//						"responseFormat": "json_object"
//					}
//				}
//			]
//		},
//		"desc": "This is an AI agent.",
//		"exportAPI": "false",
//		"exportAddOn": "false",
//		"addOnOpts": ""
//	}
//}