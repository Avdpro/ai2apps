import pathLib from "/@path";
import {esprima} from "/@tabos/utils/esprima.mjs";

const aiMessagesLead=[
	{
		role:"system",
		content:"You are a JS code localizer"
	},
	{
		role:"user",
		content:`translate code, 
JS syntax should be kept
IMPORTANT: All null properties should be translated!!
\`\`\`
[
	{
		EN:"open",
		CN:null,
	},
	{
		CN:\`这是第\${num}个\`,
		EN:null,	
	},
	{
		EN:side+"is red",
		CN:null,
	},
]
\`\`\``
	},
	{
		role:"assistant",
		content:`\`\`\`
[
	{
		EN:"open",
		CN:"打开",
	},
	{
		CN:\`这是第\${num}个\`,
		EN:\`This is no. \${num}\`,
	},
	{
		EN:side+"is red",
		CN:side+"是红色",
	},
]
\`\`\``
	},
];

//----------------------------------------------------------------------------
async function aiLocalizeAttr(app,aiChat,localizeObj,baseLan){
	let orgCode,valMode,postFix;
	function packBaseLan(){
		let text=localizeObj[baseLan];
		let code;
		if(text.startsWith("${")){
			let pos;
			valMode="${";
			pos=text.lastIndexOf("}");
			if(pos>0){
				code=text.substring(2,pos);
				postFix=text.substring(pos);
			}else{
				code=text.substring(2);
				postFix="";
			}
		}else if(text.startsWith("#")){
			valMode="#"
			code=text.substring(2);
		}else{
			valMode="";
			code=JSON.stringify(text);
		}
		return `${baseLan}:${code}`
	}
	//Generate orgCode:
	{
		orgCode="{\n";
		orgCode+=`\t${packBaseLan()},\n`;
		for(let lanCode in localizeObj){
			if(lanCode!==baseLan){
				orgCode+=`\t${lanCode}:null,\n`;
			}
		}
		orgCode+="}";
	}
	try{
		let resVO,newObj,aiCode,ast;		
		let result=await app.modalDlg(pathLib.join("/@aichat/ui/DlgAIWork.js"),{
			url:app.path2AppURL("ai/translatecode.aichat"),
			prompt:orgCode
		});
		resVO=aiChat.parseCodes(result);
		if(!resVO.codes || !resVO.codes[0]){
			return;
		}
		newObj={};
		aiCode=resVO.codes[0][1];
		aiCode="x="+aiCode;
		try{
			let ppts,ppt,lanCode,text;
			ast=esprima.parse(aiCode,{ range: true });
			ppts=ast.body[0].expression.right.properties;
			for(ppt of ppts){
				lanCode=ppt.key.name;
				text=aiCode.substring(ppt.value.range[0],ppt.value.range[1]);
				switch(valMode){
					case "${":
						text="${"+text+postFix;
						break;
					case "#":
						text="#"+text;
						break;
					default:
						try{
							text=JSON.parse(text);
						}catch(err){
							text=text.substring(1,text.length-1);
						}
						break;
				}
				newObj[lanCode]=text;
			}
		}catch(err){
			return null;
		}
		console.log(ast);
		console.log(newObj);
		return newObj;
	}catch(err){
		return null;
	}
};

//----------------------------------------------------------------------------
async function aiLocalizeAttr_old(app,aiChat,chatDlg,localizeObj,baseLan){
	let orgCode,valMode,postFix,newObj;
	let messages,resVO,message,aiCode,ast;
	function packBaseLan(){
		let text=localizeObj[baseLan];
		let code;
		if(text.startsWith("${")){
			let pos;
			valMode="${";
			pos=text.lastIndexOf("}");
			if(pos>0){
				code=text.substring(2,pos);
				postFix=text.substring(pos);
			}else{
				code=text.substring(2);
				postFix="";
			}
		}else if(text.startsWith("#")){
			valMode="#"
			code=text.substring(2);
		}else{
			valMode="";
			code=JSON.stringify(text);
		}
		return `${baseLan}:${code}`
	}
	//Generate orgCode:
	{
		orgCode="{\n";
		orgCode+=`\t${packBaseLan()},\n`;
		for(let lanCode in localizeObj){
			if(lanCode!==baseLan){
				orgCode+=`\t${lanCode}:null,\n`;
			}
		}
		orgCode+="}";
	}	
	messages=[...aiMessagesLead];
	messages.push({
		role:"user",
		content:`translate code, \nJS syntax should be kept\nIMPORTANT: All null properties should be translated!!\n\`\`\`\n${orgCode}\n\`\`\``
	});
	resVO=await chatDlg.doAIStreamCall("AICallStream",{messages:messages});
	message=resVO.message;
	resVO=aiChat.parseCodes(message);
	if(!resVO.codes || !resVO.codes[0]){
		return;
	}
	newObj={};
	aiCode=resVO.codes[0][1];
	aiCode="x="+aiCode;
	try{
		let ppts,ppt,lanCode,text;
		ast=esprima.parse(aiCode,{ range: true });
		ppts=ast.body[0].expression.right.properties;
		for(ppt of ppts){
			lanCode=ppt.key.name;
			text=aiCode.substring(ppt.value.range[0],ppt.value.range[1]);
			switch(valMode){
				case "${":
					text="${"+text+postFix;
					break;
				case "#":
					text="#"+text;
					break;
				default:
					try{
						text=JSON.parse(text);
					}catch(err){
						text=text.substring(1,text.length-1);
					}
					break;
			}
			newObj[lanCode]=text;
		}
	}catch(err){
		return null;
	}
	console.log(ast);
	console.log(newObj);
	return newObj;
};

function packBaseLan(attr,baseLan,stub){
	let localizeObj=attr.localize;
	let text=localizeObj?localizeObj[baseLan]:attr.valText;
	let code;
	if(text.startsWith("${")){
		let pos;
		stub.valMode="${";
		pos=text.lastIndexOf("}");
		if(pos>0){
			code=text.substring(2,pos);
			stub.postFix=text.substring(pos);
		}else{
			code=text.substring(2);
			stub.postFix="";
		}
	}else if(text.startsWith("#")){
		stub.valMode="#"
		code=text.substring(2);
	}else{
		stub.valMode="";
		code=JSON.stringify(text);
	}
	return `${baseLan}:${code}`
}

function scanObj(obj,locAttrs,locLines,baseLan,tgtLans){
	let attrList,attr,attrDef,stub;
	let codes,lanCode;
	attrList=obj.attrList;
	for(attr of attrList){
		attrDef=attr.def;
		if(attrDef.localizable || attr.localize){
			stub={obj:obj,attr:attr};
			locAttrs.push(stub);
			codes="\t{\n";
			codes+=`\t\t${packBaseLan(attr,baseLan,stub)},\n`;
			for(lanCode of tgtLans){
				if(lanCode!==baseLan){
					codes+=`\t\t${lanCode}:null,\n`
				}
			}
			codes+="\t},\n";
			locLines.push(codes);
		}
	}
	for(attr of attrList){
		if(attr.attrList && attr.objDef){
			scanObj(attr,locAttrs,locLines,baseLan,tgtLans);
		}
	}
};

//----------------------------------------------------------------------------
async function aiLocalizeDoc(app,aiChat,editDoc,baseLan){
	let tgtObjs,prj,docApp,tgtLans,locAttrs,locLines,tgtObj,orgCode;
	tgtObjs=editDoc.getLocalizableObjs();
	if(!tgtObjs||!tgtObjs.length){
		return false;
	}
	prj=editDoc.prj;
	docApp=prj.docApp;
	tgtLans=docApp.attrLocalize.attrList.map((item)=>{return item.val});
	locAttrs=[];
	locLines=[];
	for(tgtObj of tgtObjs){
		scanObj(tgtObj,locAttrs,locLines,baseLan,tgtLans);
	}
	orgCode="[\n";
	orgCode+=locLines.join("");
	orgCode+="]";
	try{
		let list,i,n,ppts,ppt,lanCode,text,stub;
		let resVO,aiCode,ast,newObj;
		let result=await app.modalDlg(pathLib.join("/@aichat/ui/DlgAIWork.js"),{
			url:app.path2AppURL("ai/translatecode.aichat"),
			prompt:orgCode
		});
		resVO=aiChat.parseCodes(result);
		if(!resVO.codes || !resVO.codes[0]){
			return false;
		}
		aiCode=resVO.codes[0][1];
		aiCode="x="+aiCode;
		ast=esprima.parse(aiCode,{ range: true });
		list=ast.body[0].expression.right.elements;
		n=list.length;
		if(n!==locAttrs.length){
			throw new Error("AI return array size error");
		}
		for(i=0;i<n;i++){
			stub=locAttrs[i];
			ppts=list[i].properties
			newObj={};
			for(ppt of ppts){
				lanCode=ppt.key.name;
				text=aiCode.substring(ppt.value.range[0],ppt.value.range[1]);
				switch(stub.valMode){
					case "${":
						text="${"+text+stub.postFix;
						break;
					case "#":
						text="#"+text;
						break;
					default:
						try{
							text=JSON.parse(text);
						}catch(err){
							text=text.substring(1,text.length-1);
						}
						break;
				}
				newObj[lanCode]=text;
			}
			prj.editAttr_SetAttrLocalize(stub.obj,stub.attr,newObj);
			if(editDoc.dataDoc.editBox){
				editDoc.dataDoc.editBox.clearHistory();
			}
		}
		return true;
	}catch(err){
		return false;
	}
	return false;
}

//----------------------------------------------------------------------------
async function aiLocalizeDoc_old(app,aiChat,chatDlg,editDoc,baseLan){
	let tgtObjs,tgtObj,locAttrs,locLines;
	let prj,docApp,tgtLans;
	let orgCode,messages,resVO,message;
	let newObj,aiCode,ast;
	tgtObjs=editDoc.getLocalizableObjs();
	if(!tgtObjs||!tgtObjs.length){
		return;
	}
	prj=editDoc.prj;
	docApp=prj.docApp;
	tgtLans=docApp.attrLocalize.attrList.map((item)=>{return item.val});
	locAttrs=[];
	locLines=[];
	for(tgtObj of tgtObjs){
		scanObj(tgtObj,locAttrs,locLines,baseLan,tgtLans);
	}
	orgCode="[\n";
	orgCode+=locLines.join("");
	orgCode+="]";
	console.log("OrgCode:");
	console.log(orgCode);
	//Call AI:
	try{
		messages=[...aiMessagesLead];
		messages.push({
			role:"user",
			content:`translate code, \nJS syntax should be kept\nIMPORTANT: All null properties should be translated!!\n\`\`\`\n${orgCode}\n\`\`\``
		});
		resVO=await chatDlg.doAIStreamCall("AICallStream",{messages:messages});
		message=resVO.message;
		resVO=aiChat.parseCodes(message);
		if(!resVO.codes || !resVO.codes[0]){
			return;
		}
	}catch(err){
		return;
	}
	aiCode=resVO.codes[0][1];
	aiCode="x="+aiCode;
	try{
		let list,i,n,ppts,ppt,lanCode,text,stub;
		ast=esprima.parse(aiCode,{ range: true });
		console.log(ast);
		list=ast.body[0].expression.right.elements;
		n=list.length;
		if(n!==locAttrs.length){
			throw new Error("AI return array size error");
		}
		for(i=0;i<n;i++){
			stub=locAttrs[i];
			ppts=list[i].properties
			newObj={};
			for(ppt of ppts){
				lanCode=ppt.key.name;
				text=aiCode.substring(ppt.value.range[0],ppt.value.range[1]);
				switch(stub.valMode){
					case "${":
						text="${"+text+stub.postFix;
						break;
					case "#":
						text="#"+text;
						break;
					default:
						try{
							text=JSON.parse(text);
						}catch(err){
							text=text.substring(1,text.length-1);
						}
						break;
				}
				newObj[lanCode]=text;
			}
			prj.editAttr_SetAttrLocalize(stub.obj,stub.attr,newObj);
			if(editDoc.dataDoc.editBox){
				editDoc.dataDoc.editBox.clearHistory();
			}
		}
	}catch(err){
		return null;
	}
	return true;
};

//----------------------------------------------------------------------------
async function aiLocalizeCode(app,aiChat,chatDlg,code,locLans,baseLan){
	//TODO: Code this:
};

export{aiLocalizeAttr,aiLocalizeDoc,aiLocalizeCode};

