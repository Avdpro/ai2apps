import pathLib from "/@path";
import {esprima} from "/@tabos/utils/esprima.mjs";

//----------------------------------------------------------------------------
async function aiLocalizeAttr(app,aiChat,localizeObj,baseLan){
	let orgCode,valMode,postFix;
	function packBaseLan(){
		let text=localizeObj[baseLan];
		let code;
		if(text.startsWith("${")){
			let pos;
			valMode="${";
			pos=text.lastIndexOf("}");
			if(pos>0){
				code=text.substring(2,pos);
				postFix=text.substring(pos);
			}else{
				code=text.substring(2);
				postFix="";
			}
		}else if(text.startsWith("#")){
			valMode="#"
			code=text.substring(2);
		}else{
			valMode="";
			code=JSON.stringify(text);
		}
		return `${baseLan}:${code}`
	}
	//Generate orgCode:
	{
		orgCode="{\n";
		orgCode+=`\t${packBaseLan()},\n`;
		for(let lanCode in localizeObj){
			if(lanCode!==baseLan){
				orgCode+=`\t${lanCode}:null,\n`;
			}
		}
		orgCode+="}";
	}
	try{
		let resVO,newObj,aiCode,ast;		
		let result=await app.modalDlg(pathLib.join("/@aichat/ui/DlgAIChat.js"),{
			url:app.path2AppURL("ai/translate.js"),
			prompt:orgCode,
			clearChat:true,
			allowEmptyChat:false,
			allowReset:false,
			autoClose:true
		});
		resVO=aiChat.parseCodes(result);
		if(!resVO.codes || !resVO.codes[0]){
			return;
		}
		newObj={};
		aiCode=resVO.codes[0][1];
		aiCode="x="+aiCode;
		try{
			let ppts,ppt,lanCode,text;
			ast=esprima.parse(aiCode,{ range: true });
			ppts=ast.body[0].expression.right.properties;
			for(ppt of ppts){
				lanCode=ppt.key.name;
				text=aiCode.substring(ppt.value.range[0],ppt.value.range[1]);
				switch(valMode){
					case "${":
						text="${"+text+postFix;
						break;
					case "#":
						text="#"+text;
						break;
					default:
						try{
							text=JSON.parse(text);
						}catch(err){
							text=text.substring(1,text.length-1);
						}
						break;
				}
				newObj[lanCode]=text;
			}
		}catch(err){
			return null;
		}
		console.log(ast);
		console.log(newObj);
		return newObj;
	}catch(err){
		return null;
	}
};

function packBaseLan(attr,baseLan,stub){
	let localizeObj=attr.localize;
	let text=localizeObj?localizeObj[baseLan]:attr.valText;
	let code;
	if(text.startsWith("${")){
		let pos;
		stub.valMode="${";
		pos=text.lastIndexOf("}");
		if(pos>0){
			code=text.substring(2,pos);
			stub.postFix=text.substring(pos);
		}else{
			code=text.substring(2);
			stub.postFix="";
		}
	}else if(text.startsWith("#")){
		stub.valMode="#"
		code=text.substring(2);
	}else{
		stub.valMode="";
		code=JSON.stringify(text);
	}
	return `${baseLan}:${code}`
}

function scanObj(obj,locAttrs,locLines,baseLan,tgtLans){
	let attrList,attr,attrDef,stub;
	let codes,lanCode;
	attrList=obj.attrList;
	for(attr of attrList){
		attrDef=attr.def;
		if(attrDef.localizable || attr.localize){
			stub={obj:obj,attr:attr};
			locAttrs.push(stub);
			codes="\t{\n";
			codes+=`\t\t${packBaseLan(attr,baseLan,stub)},\n`;
			for(lanCode of tgtLans){
				if(lanCode!==baseLan){
					codes+=`\t\t${lanCode}:null,\n`
				}
			}
			codes+="\t},\n";
			locLines.push(codes);
		}
	}
	for(attr of attrList){
		if(attr.attrList && attr.objDef){
			scanObj(attr,locAttrs,locLines,baseLan,tgtLans);
		}
	}
};

//----------------------------------------------------------------------------
async function aiLocalizeDoc(app,aiChat,editDoc,baseLan){
	let tgtObjs,prj,docApp,tgtLans,locAttrs,locLines,tgtObj,orgCode;
	tgtObjs=editDoc.getLocalizableObjs();
	if(!tgtObjs||!tgtObjs.length){
		return false;
	}
	prj=editDoc.prj;
	docApp=prj.docApp;
	tgtLans=docApp.attrLocalize.attrList.map((item)=>{return item.val});
	locAttrs=[];
	locLines=[];
	for(tgtObj of tgtObjs){
		scanObj(tgtObj,locAttrs,locLines,baseLan,tgtLans);
	}
	orgCode="[\n";
	orgCode+=locLines.join("");
	orgCode+="]";
	try{
		let list,i,n,ppts,ppt,lanCode,text,stub;
		let resVO,aiCode,ast,newObj;
		let result=await app.modalDlg(pathLib.join("/@aichat/ui/DlgAIWork.js"),{
			url:app.path2AppURL("ai/translatecode.aichat"),
			prompt:orgCode
		});
		resVO=aiChat.parseCodes(result);
		if(!resVO.codes || !resVO.codes[0]){
			return false;
		}
		aiCode=resVO.codes[0][1];
		aiCode="x="+aiCode;
		ast=esprima.parse(aiCode,{ range: true });
		list=ast.body[0].expression.right.elements;
		n=list.length;
		if(n!==locAttrs.length){
			throw new Error("AI return array size error");
		}
		for(i=0;i<n;i++){
			stub=locAttrs[i];
			ppts=list[i].properties
			newObj={};
			for(ppt of ppts){
				lanCode=ppt.key.name;
				text=aiCode.substring(ppt.value.range[0],ppt.value.range[1]);
				switch(stub.valMode){
					case "${":
						text="${"+text+stub.postFix;
						break;
					case "#":
						text="#"+text;
						break;
					default:
						try{
							text=JSON.parse(text);
						}catch(err){
							text=text.substring(1,text.length-1);
						}
						break;
				}
				newObj[lanCode]=text;
			}
			prj.editAttr_SetAttrLocalize(stub.obj,stub.attr,newObj);
			if(editDoc.dataDoc.editBox){
				editDoc.dataDoc.editBox.clearHistory();
			}
		}
		return true;
	}catch(err){
		return false;
	}
	return false;
}

//----------------------------------------------------------------------------
async function aiLocalizeCode(app,aiChat,chatDlg,code,locLans,baseLan){
	//TODO: Code this:
};

export{aiLocalizeAttr,aiLocalizeDoc,aiLocalizeCode};

