export default {
	topics:{
		"关于Tab-OS": {
			path:"../help/about.js"
		},
		"快捷键": {
			path:"../help/shortcuts.js"
		},
		"设计编辑UI": {
			path:"../help/wyswyg.js"
		},
		"AI对话": {
			path:"../help/aichat.js"
		},
		"用户账号": {
			path:"../help/aichat.js"
		},
	}
};