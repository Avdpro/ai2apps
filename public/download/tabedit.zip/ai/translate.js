//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import pathLib from "/@path";
import inherits from "/@inherits";
import Base64 from "/@tabos/utils/base64.js";
import {trimJSON} from "/@aichat/utils.js";
/*#{1J7VNINPT0MoreImports*/
/*}#1J7VNINPT0MoreImports*/
const agentURL=(new URL(import.meta.url)).pathname;
const baseURL=pathLib.dirname(agentURL);
const basePath=baseURL.startsWith("file://")?decodeURI(baseURL):baseURL;
const $ln=VFACT.lanCode||"EN";
/*#{1J7VNINPT0StartDoc*/
/*}#1J7VNINPT0StartDoc*/
//----------------------------------------------------------------------------
let translate=async function(session){
	let execInput;
	const $ln=session.language||"EN";
	let context,globalContext=session.globalContext;
	let self;
	let Translate;
	/*#{1J7VNINPT0LocalVals*/
	/*}#1J7VNINPT0LocalVals*/
	
	function parseAgentArgs(input){
		execInput=input;
		/*#{1J7VNINPT0ParseArgs*/
		/*}#1J7VNINPT0ParseArgs*/
	}
	
	/*#{1J7VNINPT0PreContext*/
	/*}#1J7VNINPT0PreContext*/
	context={};
	context=VFACT.flexState(context);
	/*#{1J7VNINPT0PostContext*/
	/*}#1J7VNINPT0PostContext*/
	let $agent,agent,segs={};
	segs["Translate"]=Translate=async function(input){//:1J7VNISCU0
		let prompt;
		let result;
		
		let opts={
			platform:"OpenAI",
			mode:"gpt-4.1",
			maxToken:2000,
			temperature:0,
			topP:1,
			fqcP:0,
			prcP:0,
			secret:false,
			responseFormat:"text"
		};
		let chatMem=Translate.messages
		let seed="";
		if(seed!==undefined){opts.seed=seed;}
		let messages=[
			{role:"system",content:"\n### Role\nYou are a JS code localizer\n\n### Input\nIn each conversation round, the input is a JavaScript snippet, usually an array representing a localized text block.\n\n### Output\nTranslate the text code into the target language according to the language represented by each item in the array. Make sure to preserve the JavaScript syntax and do not remove necessary symbols such as `, \", and ’.\n### Example:\n- Input:\n[\n  {\n    EN:\"open\",\n    CN:null,\n  },\n  {\n    CN:`这是第\\${num}个`,\n    EN:null,\n  },\n  {\n    EN:side+\"is red\",\n    CN:null,\n  }\n]\n\n- Output:\n[\n  {\n    EN:\"open\",\n    CN:\"打开\",\n  },\n  {\n    CN:`这是第\\${num}个`,\n    EN:`This is no. \\${num}`,\n  },\n  {\n    EN:side+\"is red\",\n    CN:side+\"是红色\",\n  }\n]\n\n### 注意\n直接输出翻译后的代码，不要包含其他文字，例如打招呼，分析过程等。"},
		];
		prompt=input;
		if(prompt!==null){
			if(typeof(prompt)!=="string"){
				prompt=JSON.stringify(prompt,null,"	");
			}
			let msg={role:"user",content:prompt};messages.push(msg);
		}
		result=await session.callSegLLM("Translate@"+agentURL,opts,messages,true);
		return {result:result};
	};
	Translate.jaxId="1J7VNISCU0"
	Translate.url="Translate@"+agentURL
	
	agent=$agent={
		isAIAgent:true,
		session:session,
		name:"translate",
		url:agentURL,
		autoStart:true,
		jaxId:"1J7VNINPT0",
		context:context,
		livingSeg:null,
		execChat:async function(input){
			let result;
			parseAgentArgs(input);
			/*#{1J7VNINPT0PreEntry*/
			/*}#1J7VNINPT0PreEntry*/
			result={seg:Translate,"input":input};
			/*#{1J7VNINPT0PostEntry*/
			/*}#1J7VNINPT0PostEntry*/
			return result;
		},
		/*#{1J7VNINPT0MoreAgentAttrs*/
		/*}#1J7VNINPT0MoreAgentAttrs*/
	};
	/*#{1J7VNINPT0PostAgent*/
	/*}#1J7VNINPT0PostAgent*/
	return agent;
};
/*#{1J7VNINPT0ExCodes*/
/*}#1J7VNINPT0ExCodes*/

//#CodyExport>>>
//#CodyExport<<<
/*#{1J7VNINPT0PostDoc*/
/*}#1J7VNINPT0PostDoc*/


export default translate;
export{translate};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DocAIAgent",
//	"jaxId": "1J7VNINPT0",
//	"attrs": {
//		"editObjs": {
//			"jaxId": "1J7VNINPT1",
//			"attrs": {
//				"translate": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1J7VNINPT7",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1J7VNINPT8",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1J7VNINPT9",
//							"attrs": {}
//						},
//						"functions": {
//							"jaxId": "1J7VNINPT10",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false",
//						"exportClass": "false"
//					},
//					"mockups": {}
//				}
//			}
//		},
//		"agent": {
//			"jaxId": "1J7VNINPT2",
//			"attrs": {}
//		},
//		"showName": "",
//		"entry": "",
//		"autoStart": "true",
//		"inBrowser": "true",
//		"debug": "true",
//		"apiArgs": {
//			"jaxId": "1J7VNINPT3",
//			"attrs": {}
//		},
//		"localVars": {
//			"jaxId": "1J7VNINPT4",
//			"attrs": {}
//		},
//		"context": {
//			"jaxId": "1J7VNINPT5",
//			"attrs": {}
//		},
//		"globalMockup": {
//			"jaxId": "1J7VNINPT6",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "aiseg",
//					"def": "callLLM",
//					"jaxId": "1J7VNISCU0",
//					"attrs": {
//						"id": "Translate",
//						"viewName": "",
//						"label": "",
//						"x": "130",
//						"y": "110",
//						"desc": "执行一次LLM调用。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1J7VNN6TQ0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1J7VNN6TQ1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"platform": "OpenAI",
//						"mode": "gpt-4.1",
//						"system": "\n### Role\nYou are a JS code localizer\n\n### Input\nIn each conversation round, the input is a JavaScript snippet, usually an array representing a localized text block.\n\n### Output\nTranslate the text code into the target language according to the language represented by each item in the array. Make sure to preserve the JavaScript syntax and do not remove necessary symbols such as `, \", and ’.\n### Example:\n- Input:\n[\n  {\n    EN:\"open\",\n    CN:null,\n  },\n  {\n    CN:`这是第\\${num}个`,\n    EN:null,\n  },\n  {\n    EN:side+\"is red\",\n    CN:null,\n  }\n]\n\n- Output:\n[\n  {\n    EN:\"open\",\n    CN:\"打开\",\n  },\n  {\n    CN:`这是第\\${num}个`,\n    EN:`This is no. \\${num}`,\n  },\n  {\n    EN:side+\"is red\",\n    CN:side+\"是红色\",\n  }\n]\n\n### 注意\n直接输出翻译后的代码，不要包含其他文字，例如打招呼，分析过程等。",
//						"temperature": "0",
//						"maxToken": "2000",
//						"topP": "1",
//						"fqcP": "0",
//						"prcP": "0",
//						"messages": {
//							"attrs": []
//						},
//						"prompt": "#input",
//						"seed": "",
//						"outlet": {
//							"jaxId": "1J7VNN6TO0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							}
//						},
//						"stream": "true",
//						"secret": "false",
//						"allowCheat": "false",
//						"GPTCheats": {
//							"attrs": []
//						},
//						"shareChatName": "",
//						"keepChat": "No",
//						"clearChat": "2",
//						"apiFiles": {
//							"attrs": []
//						},
//						"parallelFunction": "false",
//						"responseFormat": "text",
//						"formatDef": "\"\""
//					},
//					"icon": "llm.svg"
//				}
//			]
//		},
//		"desc": "这是一个AI智能体。",
//		"exportAPI": "false",
//		"exportAddOn": "false",
//		"addOnOpts": ""
//	}
//}