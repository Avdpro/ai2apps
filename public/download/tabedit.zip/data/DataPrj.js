//Auto genterated by Cody
import VFACT from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1G9H8O8EV0StartDoc*/
import {DataDocs,DataDoc} from "./DataDoc.js";
import pathLib from "/@path";
import {tabOS,tabFS} from "/@tabos";
import {AddOn} from "./AddOn.js";
import {makeObjEventEmitter,makeNotify} from "/@events";
import {DocEditor} from "../ui/DocEditor.js";
/*}#1G9H8O8EV0StartDoc*/
//----------------------------------------------------------------------------
/*#{1G9H8OOTH0Constructor+*/
let DataPrj=function(app){
/*}#1G9H8OOTH0Constructor+*/
	/*#{1G9H8OOTH0PreConstruct*/
	this.app=app;
	this.path="";
	this.DefDocEditor=DocEditor;
	this.docs=app.docs||new DataDocs();
	this.editorOpts={
		IndentSize:4,
		UseTab:true,
		AutoIndent:true,
		TabSize:4,
		LineNum:true,
		lockCodySegs:false,//By default, don't lock code-seg
	};
	this.prjConfig=null;
	this.getTabDocs=null;//A function that return current liveDocs with order.
	this.safeMode=false;//In safe mode, editor will ignore all project's addons.
	this.startNaviView=null;
	this.startInfoView=null;
	makeObjEventEmitter(this);
	makeNotify(this);
	/*}#1G9H8OOTH0PreConstruct*/
	/*#{1G9H8OOTH0Properties+*/
	/*}#1G9H8OOTH0Properties+*/
	/*#{1G9H8OOTH0PostConstruct*/
	/*}#1G9H8OOTH0PostConstruct*/
};
DataPrj.prototype={};
let _DataPrj=DataPrj.prototype;
/*#{1G9H8OOTH0ExCodes*/
let dataPrj=_DataPrj;

//****************************************************************************
//:I/O:
//****************************************************************************
{
	//------------------------------------------------------------------------
	DataPrj.getUsage=async function(){
		let saveVO;
		try{
			saveVO=await tabFS.readFile("/doc/tabstudio/tabstudio.json","utf8");
			saveVO=JSON.parse(saveVO);
		}catch(e){
			saveVO={};
		}
		return saveVO;
	};

	//------------------------------------------------------------------------
	DataPrj.updatePrjUsage=async function(path){
		let saveVO,prjs,idx;
		try{
			saveVO=await tabFS.readFile("/doc/tabstudio/tabstudio.json","utf8");
			saveVO=JSON.parse(saveVO);
		}catch(e){
			saveVO={};
		}
		prjs=saveVO.projects;
		if(!prjs){
			prjs=saveVO.projects=[];
		}
		idx=prjs.indexOf(path);
		if(idx>=0){
			prjs.splice(idx,1);
		}
		prjs.unshift(path);
		await tabFS.writeFile("/doc/tabstudio/tabstudio.json",JSON.stringify(saveVO),"utf8");
	};

	//------------------------------------------------------------------------
	dataPrj.load=async function(path,safeMode=false){
		let pathCfg,docCfg,prjAddOns,addOn,addOns,ext;
		this.path=path;
		tabOS.homePath=path;
		this.safeMode=!!safeMode;
		//Read prj settings in path:
		try{
			pathCfg=await tabFS.readFile(pathLib.join(path,"tabstudio.project.json"),"utf8");
			pathCfg=JSON.parse(pathCfg);
		}catch(err){
			pathCfg={};
		}
		if(pathCfg.run && !Array.isArray(pathCfg.run)){
			pathCfg.run=[pathCfg.run];
		}
		this.prjConfig=pathCfg;
		//Read and load project addons:
		addOns=pathCfg.addOns;
		if(addOns && !safeMode){
			let vo;
			for(addOn of addOns){
				try{
					if(!addOn.startsWith("/@")){
						addOn=document.location.origin+"/"+addOn;
					}
					console.log(`Load addon: ${addOn}`);
					ext=pathLib.extname(addOn);
					if(ext===".js"){
						try{
							vo=(await import(addOn)).default;
							AddOn.regAddOns(vo);
						}catch(err){
							//Try parse CodyExport:
							let code,pos,pos2,mk1,mk2,func;
							console.error(err);
							code=await (await fetch(addOn)).text();
							mk1=`//#CodyExport>>>`;
							mk2=`//#CodyExport<<<`;
							pos=code.indexOf(mk1);
							if(pos>0){
								pos2=code.indexOf(mk2);
								if(pos2>pos){
									code=code.substring(pos+mk1.length,pos2);
								}
								try{
									func=new Function("VFACT",code);
									code=func(VFACT);
								}catch(err){
									console.warn(`Import addon ${addOn} failed:`);								
									console.error(err);
								}
							}
						}
					}else if(ext===".py"){
						let code,pos,pos2,mk1,mk2,func;
						code=await (await fetch(addOn)).text();
						mk1=`""">>>CodyExport`;
						mk2=`>>>CodyExport"""`;
						pos=code.indexOf(mk1);
						if(pos>0){
							pos2=code.indexOf(mk2);
							if(pos2>pos){
								code=code.substring(pos+mk1.length,pos2);
							}
							try{
								func=new Function("VFACT",code);
								code=func(VFACT);
							}catch(err){
								console.warn(`Import addon ${addOn} failed:`);								
								console.error(err);
							}
						}
					}
				}catch(err){
					console.error(err);
					console.log("Error read project addOn: ",path,err);
				}
			}
		}
		this.startNaviView=pathCfg.startNaviView||null;
		this.startInfoView=pathCfg.startInfoView||null;

		//Run project addons
		prjAddOns=AddOn.getAddOns("Project");
		if(prjAddOns){
			let mod,def,path;
			for(addOn of prjAddOns){
				try{
					def=addOn.def;
					if(def){
						await def(this,AddOn);
					}else{
						throw new Error("Can't locate addOn entry.");
					}
				}catch(err){
					console.log(`Load addon Error, addOn:`,addOn,"Error: ");
					console.error(err);
				}
			}
		}
		DataPrj.updatePrjUsage(path);
		//Read project usage:
		try{
			let pathTag;
			pathTag=path.replaceAll("/","_");
			docCfg=await tabFS.readFile(pathLib.join("/doc/tabstudio",pathTag+".json"),"utf8");
			docCfg=JSON.parse(docCfg);
		}catch(err){
			docCfg=null;
		}
		if(docCfg){
			let dataDocs,liveDocs,tabDocs,i,n,path,doc;
			dataDocs=this.docs;
			tabDocs=docCfg.tabDocs;
			liveDocs=docCfg.liveDocs;
			if(tabDocs){
				n=tabDocs.length;
				for(i=0;i<n;i++){
					path=tabDocs[i];
					if(!path.startsWith("/")){
						path=pathLib.join(this.path,path);
						tabDocs[i]=path;
					}
					await dataDocs.openDoc(path);
				}
				if(liveDocs){
					n=liveDocs.length;
					for(i=0;i<n;i++){
						path=liveDocs[i];
						if(!path.startsWith("/")){
							path=pathLib.join(this.path,path);
							liveDocs[i]=path;
						}
					}
					dataDocs.applyDocList(liveDocs);
					doc=dataDocs.docList[dataDocs.docList.length-1];
					if(doc){
						dataDocs.focusDoc(doc,true);
					}
				}
			}
		}
		this.scanHints();
	};

	//------------------------------------------------------------------------
	dataPrj.save=async function(){
		let path,pathCfg;
		path=this.path;
		if(!path){
			return;
		}
		this.emit("AboutSavePrj");//This is for
		pathCfg=this.prjConfig||{};
		//Save settings:
		await tabFS.writeFile(pathLib.join(this.path,"tabstudio.project.json"),JSON.stringify(pathCfg,null,"\t"),"utf8");
		//Save usage:
		{
			let pathTag,usageVO;
			usageVO={
				version:"1.0.0",
				indent:this.editorOpts.TabSize,
			};
			if(this.getTabDocs){
				usageVO.tabDocs=this.getTabDocs();
				usageVO.liveDocs=this.docs.docList.map((item)=>item.path);
			}
			pathTag=path.replaceAll("/","_");
			await tabFS.writeFile(pathLib.join("/doc/tabstudio",pathTag+".json"),JSON.stringify(usageVO,null,"\t"),"utf8");
		}
		this.emit("SavePrj");
	};
}

//****************************************************************************
//:Code Hints:
//****************************************************************************
{
	//------------------------------------------------------------------------
	//Scan all project files for code hint:
	dataPrj.scanHints=async function(){
		let disk,subPath,entries,path;
		let self=this;
		if(this.inScanHint){
			return;
		}
		this.inScanHint=true;
		[disk,subPath]=tabFS.parsePath(this.path);
		disk=await tabFS.openDisk(disk);
		if(!disk){
			return;
		}
		entries=await disk.getAllItemPath();
		if(subPath){
			entries.filter((path)=>path.startsWith(subPath));
		}
		//console.log("Scan file num: "+entries.length);
		async function scanOneFile(){
			let path=entries.pop();
			let ext;
			if(path){
				ext=pathLib.extname(path);
				switch(ext){
					case ".js":
					case ".jsx":
					case ".mjs":
						await DataDoc.scanFileHints(disk,path);
						break;
				}
				setTimeout(scanOneFile,10);
			}else{
				self.inScanHint=false;
			}
		}
		scanOneFile();
	};
}
/*}#1G9H8OOTH0ExCodes*/


/*#{1G9H8O8EV0EndDoc*/
/*}#1G9H8O8EV0EndDoc*/

export{DataPrj};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DataDoc",
//	"jaxId": "1G9H8O8EV0",
//	"attrs": {
//		"editObjs": {
//			"jaxId": "1G9H8O8EV1",
//			"attrs": {
//				"DataPrj": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1G9H8OOTH0",
//					"attrs": {
//						"constructArgs": {
//							"jaxId": "1G9H8OOUN0",
//							"attrs": {
//								"app": {
//									"type": "auto",
//									"valText": "null"
//								}
//							}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1G9H8OOUN1",
//							"attrs": {}
//						},
//						"functions": {
//							"jaxId": "1G9H8OOUN2",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false",
//						"exportType": "Javascript Class",
//						"exportClass": "false"
//					},
//					"mockups": {}
//				}
//			}
//		}
//	}
//}