//Auto genterated by Cody
import VFACT from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1JKLJFAUS0StartDoc*/
/*}#1JKLJFAUS0StartDoc*/
let ComfileCfg={
	name:"ComfileCfg",//1JKLJFAUS2
	type:"object",
	label:undefined,
	properties:{
		diffOnly:{
			name:"diffOnly",type:"bool",
			label:"Show diff only:",
			defaultValue:false,
		},
		/*#{1JKLJFAUS2MoreProperties*/
		/*}#1JKLJFAUS2MoreProperties*/
	},
	desc:undefined,
	newObject(){return VFACT.newUITemplateObj(this)},
	/*#{1JKLJFAUS2MoreFunctions*/
	/*}#1JKLJFAUS2MoreFunctions*/
};
VFACT.regUITemplate("1JKLJFAUS2",ComfileCfg);
VFACT.regUITemplate("ComfileCfg",ComfileCfg);
/*#{1JKLJFAUS2MoreCodes*/
/*}#1JKLJFAUS2MoreCodes*/

/*#{1JKLJFAUS0EndDoc*/
/*}#1JKLJFAUS0EndDoc*/

export{ComfileCfg};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DataDoc",
//	"jaxId": "1JKLJFAUS0",
//	"attrs": {
//		"editObjs": {
//			"jaxId": "1JKLJFAUS1",
//			"attrs": {
//				"ComfileCfg": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1JKLJFAUS2",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1JKLJFAUT0",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1JKLJFAUT1",
//							"attrs": {
//								"diffOnly": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1JKLJGAUT0",
//									"attrs": {
//										"type": "bool",
//										"label": "Show diff only:",
//										"defaultValue": "false"
//									}
//								}
//							}
//						},
//						"functions": {
//							"jaxId": "1JKLJFAUT2",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false",
//						"exportClass": "false"
//					},
//					"mockups": {}
//				}
//			}
//		}
//	}
//}