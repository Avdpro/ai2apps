//Auto genterated by Cody
import VFACT from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1IM7TQOKA0StartDoc*/
let $ln=VFACT.lanCode;
/*}#1IM7TQOKA0StartDoc*/
let CompathPrj={
	name:"CompathPrj",//1IM7TQOKA2
	type:"object",
	label:undefined,
	properties:{
		exFile:{
			name:"exFile",type:"array",
			label:(($ln==="CN")?("排除的文件、目录"):("Excluded files and directories")),
			initLength:0,
			element:{
				"type":"string","label":'###:'
			},
		},
		exType:{
			name:"exType",type:"array",
			label:(($ln==="CN")?("排除文件类型"):("Exclude file types")),
			initLength:0,
			element:{
				"type":"string","label":'###:'
			},
		},
		/*#{1IM7TQOKA2MoreProperties*/
		/*}#1IM7TQOKA2MoreProperties*/
	},
	desc:undefined,
	newObject(){return VFACT.newUITemplateObj(this)},
	/*#{1IM7TQOKA2MoreFunctions*/
	/*}#1IM7TQOKA2MoreFunctions*/
};
VFACT.regUITemplate("1IM7TQOKA2",CompathPrj);
VFACT.regUITemplate("CompathPrj",CompathPrj);
/*#{1IM7TQOKA2MoreCodes*/
/*}#1IM7TQOKA2MoreCodes*/

/*#{1IM7TQOKA0EndDoc*/
/*}#1IM7TQOKA0EndDoc*/

export{CompathPrj};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DataDoc",
//	"jaxId": "1IM7TQOKA0",
//	"attrs": {
//		"editObjs": {
//			"jaxId": "1IM7TQOKA1",
//			"attrs": {
//				"CompathPrj": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1IM7TQOKA2",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1IM7TQOKB0",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1IM7TQOKB1",
//							"attrs": {
//								"exFile": {
//									"type": "object",
//									"def": "EditClassAryPpt",
//									"jaxId": "1IM7TVO9P0",
//									"attrs": {
//										"type": "array",
//										"element": {
//											"jaxId": "1IM7TVO9P1",
//											"attrs": {
//												"type": "String",
//												"label": "#'###:'"
//											}
//										},
//										"initLength": "0",
//										"label": {
//											"type": "string",
//											"valText": "排除的文件、目录",
//											"localize": {
//												"EN": "Excluded files and directories",
//												"CN": "排除的文件、目录"
//											},
//											"localizable": true
//										}
//									}
//								},
//								"exType": {
//									"type": "object",
//									"def": "EditClassAryPpt",
//									"jaxId": "1IM7TVO9P2",
//									"attrs": {
//										"type": "array",
//										"element": {
//											"jaxId": "1IM7TVO9P3",
//											"attrs": {
//												"type": "String",
//												"label": "#'###:'"
//											}
//										},
//										"initLength": "0",
//										"label": {
//											"type": "string",
//											"valText": "排除文件类型",
//											"localize": {
//												"EN": "Exclude file types",
//												"CN": "排除文件类型"
//											},
//											"localizable": true
//										}
//									}
//								}
//							}
//						},
//						"functions": {
//							"jaxId": "1IM7TQOKB2",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false",
//						"exportClass": "false"
//					},
//					"mockups": {}
//				}
//			}
//		}
//	}
//}