//Auto genterated by Cody
import inherits from "/@inherits";
/*#{1GP79NMCP0StartDoc*/
import {tabNT} from "/@tabos";
import {makeNotify,makeObjEventEmitter} from "/@events";
let aiCallPrefix=null;
/*}#1GP79NMCP0StartDoc*/
//----------------------------------------------------------------------------
/*#{1GP79NMCQ1Constructor+*/
let DataAIChat=function(){
/*}#1GP79NMCQ1Constructor+*/
	/*#{1GP79NMCQ1PreConstruct*/
	this.chatLogs=[];
	this.chatHandlers=[];
	this.cmdMap=new Map();
	this.chatLogs=[];
	/*}#1GP79NMCQ1PreConstruct*/
	/*#{1GP79NMCQ1Properties+*/
	/*}#1GP79NMCQ1Properties+*/
	/*#{1GP79NMCQ1PostConstruct*/
	/*}#1GP79NMCQ1PostConstruct*/
};
DataAIChat.prototype={};
let _DataAIChat=DataAIChat.prototype;
/*#{1GP79NMCQ1ExCodes*/
let dataAIChat=_DataAIChat;

//****************************************************************************
//Commands:
//****************************************************************************
{
	//------------------------------------------------------------------------
	dataAIChat.registerHandler=function(handler){
		let list;
		list=this.chatHandlers;
		if(list.indexOf(handler)>=0){
			return;
		}
		list.push(handler);
	};

	//------------------------------------------------------------------------
	dataAIChat.unregisterHandler=function(handler){
		let list,idx;
		list=this.chatHandlers;
		idx=list.indexOf(handler);
		if(idx<0){
			return;
		}
		list.splice(idx,1);
	};

	//------------------------------------------------------------------------
	dataAIChat.makeCmdPmtHeader=function(){
		let lead,list,handler,cmds,cmd,cmdMap;

		function packCmd(cmd){
			let args,arg,mockups,mockup,mkpLine;
			lead+=`\n"${cmd.command}": ${cmd.desc}\n`;
			args=cmd.args;
			if(args){
				lead+=`\t参数:\n`
				for(arg of args){
					lead+=`\t\t${arg.name}: ${arg.desc}`;
				}
			}else{
				lead+=`\t参数: 无\n`
			}
			mockups=cmd.mockups;
			if(mockups){
				lead+=`\t例子:\n`
				for(mockup of mockups){
					mkpLine="\ncmd="+JSON.stringify(mockup,null,"\t")+";";
					mkpLine=mkpLine.replaceAll("\n","\n\t\t");
					lead+=mkpLine;
				}
			}
		}
		cmdMap=this.cmdMap;
		cmdMap.clear();

		lead="";
		list=this.chatHandlers;
		for(handler of list){
			cmds=handler.getAIChatCommands();
			if(cmds){
				for(cmd of cmds){
					cmdMap.set(cmd.command,cmd);			
					packCmd(cmd);
				}
			}
		}
		lead+="\n//-----\n";
		//TODO: Append chat logs:
		return lead;
	};

	//------------------------------------------------------------------------
	dataAIChat.chatToCommand=async function(chatText,opts){
		let res,cmdCode,cmdFunc,cmdVO,cmdList;
		//callAI:
		res=await tabNT.makeCall("AIChat2Cmd",{
			textCommand:this.makeCmdPmtHeader(),textChat:chatText
		});	
		if(res.code!==200){
			return {error:"RPCError",info:`RPC call failed: ${res.code}: ${res.info}`};
		}
		cmdCode=res.completion;
		try{
			cmdVO=JSON.parse(cmdCode);
		}catch(err){
			return {error:"ParseError",info:`Parse completion error: ${err}`,completion:cmdCode};
		};
		if(opts.holdExec){
			cmdList=Array.isArray(cmdVO)?cmdVO:[cmdVO];
			cmdList.chatText=chatText;
			cmdList.completion=res.completion;
			return cmdList;
		}
		await this.execCommand(cmdVO);
		return;	
		cmdCode=`return [${res.completion}`;
		cmdCode=cmdCode.replaceAll("\\","\\\\");
		try{
			cmdFunc=new Function(cmdCode);
			cmdList=cmdFunc();
			if(!cmdList){
				throw "Can't parse command from chat: "+chatText;
			}
		}catch(err){
			console.log("Compile VO error:");
			console.log(cmdCode);
			console.log(err);
			return {error:"ParseError",info:`Parse completion error: ${err}`,completion:res.completion};
		}
		if(opts.holdExec){
			cmdList.chatText=chatText;
			cmdList.completion=res.completion;
			return cmdList;
		}
		await this.execCommands(cmdList);
	};

	//------------------------------------------------------------------------
	dataAIChat.execCommands=async function(cmdList,chatDlg){
		let cmdVO,execRes,finished;
		finished=true;
		for(cmdVO of cmdList){
			execRes=await this.execCommand(cmdVO,chatDlg);
			if(execRes && execRes.finished===false){
				finished=false;
			}
		}
		if(finished){
			this.chatLogs.splice(0);
		}else{
			this.chatLogs.push({input:cmdList.chatText,res:cmdList.completion});
		}
	};

	//------------------------------------------------------------------------
	dataAIChat.execCommand=async function(cmdVO,chatDlg){
		let cmd,cmdObj;
		if(Array.isArray(cmdVO)){
			return await this.execCommands(cmdVO)
		}
		if(cmdVO instanceof Function){
			return await cmdVO(chatDlg);
		}
		cmd=cmdVO.command;
		if(typeof(cmd)==="string"){
			cmdObj=this.cmdMap.get(cmdVO.command);
		}else if(cmd instanceof Function){
			cmdObj=cmd;
		}
		if(!cmdObj){
			return {error:"CommandNotFound",info:`Command "${cmdVO.command}" not found in command list`};
		}
		return await cmdObj.callback(cmdVO,chatDlg);
	};
	
	//------------------------------------------------------------------------
	dataAIChat.getCommandDef=function(cmd){
		return this.cmdMap.get(cmd);
	};
}

//****************************************************************************
//AI-Calls:
//****************************************************************************
{
	//------------------------------------------------------------------------
	dataAIChat.readChatStream=async function(streamId){
		let res,pmt,streamObj;
		streamObj=this.waitStreamObj;
		pmt="";
		do{
			res=await tabNT.makeCall("readAIChatStream",{streamId:streamId});				
			if(res.code!==200){
				console.log("Read chat stream error: ");
				console.log(res);
				break;
			}
			pmt=res.message;
			if(this.waitStreamObj===streamObj){
				streamObj.content=pmt;
				streamObj.emit("content");
			}else{
				//Chat canceled?
				return "";
			}
		}while(!res.closed);
		if(this.waitStreamObj===streamObj){
			streamObj.emit("close");
		}else{
			//Chat canceled?
			return;
		}
		return streamObj.content;
	};

	//------------------------------------------------------------------------
	dataAIChat.doAICall=async function(callname,callVO){
		let res=await tabNT.makeCall(callname,callVO);	
		if(res.code!==200){
			throw new Error(`AIChat failed: ${res.code}: ${res.info}`);
		}
		return res.message;
	};

	//------------------------------------------------------------------------
	dataAIChat.doAIStreamCall=async function(callname,callVO,waitObj){
		waitObj.content="";
		if(!waitObj.emit){
			makeObjEventEmitter(waitObj);
		}
		this.waitStreamObj=waitObj;
		let res=await tabNT.makeCall(callname,callVO);	
		if(res.code!==200){
			throw new Error(`AIStreamCall failed: ${res.code}: ${res.info}`);
		}
		//Read stream:
		return await this.readChatStream(res.streamId);
	};
}

//****************************************************************************
//Coder:
//****************************************************************************
{
	//------------------------------------------------------------------------
	dataAIChat.askCoder=async function(action,desc,orgCode,waitObj){
		waitObj.content="";
		if(!waitObj.emit){
			makeObjEventEmitter(waitObj);
		}
		this.waitStreamObj=waitObj;
		let res=await tabNT.makeCall("AICoderStream",{
			action:action,desc:desc,orgCode:orgCode
		});	
		if(res.code!==200){
			throw new Error(`askCoder RPC call failed: ${res.code}: ${res.info}`);
		}
		//Read stream:
		return await this.readChatStream(res.streamId);
	};
}
/*}#1GP79NMCQ1ExCodes*/


/*#{1GP79NMCP0EndDoc*/
function parseCodes(text){
	let segs,prefix,code,postfix,pos,pos2;
	segs=[];
	pos2=0;
	pos=text.indexOf("```");
	if(pos>=0){
		pos2=text.indexOf("```",pos+3);
		if(pos2>0){
			prefix=text.substring(0,pos).trim();
			code=text.substring(pos+3,pos2);
			segs[0]=[prefix,code];
			pos=text.indexOf(pos2+3);
			while(pos>0){
				prefix=text.substring(pos2+3,pos);
				pos2=text.indexOf("```",pos+3);
				if(pos2>0){
					code=text.substring(pos+3,pos2);
					segs.push([prefix,code]);
					pos=text.indexOf("```",pos2+3);
				}else{
					code=text.substring(pos+3);
					segs.push([prefix,code]);
					pos=-1;
					pos2=text.length;
				}
			}
			postfix=text.substring(pos2+3).trim();
		}else{
			prefix=text.substring(0,pos);
			segs[0]=[prefix,text.substring(pos+3)];
			postfix="";
		}
	}else{
		prefix="AI generated Code:";
		segs[0]=[prefix,text];
		postfix="";
	}
	return {codes:segs,postfix:postfix};
};
dataAIChat.parseCodes=parseCodes;
/*}#1GP79NMCP0EndDoc*/

export{DataAIChat};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DataDoc",
//	"jaxId": "1GP79NMCP0",
//	"editVersion": 6,
//	"attrs": {
//		"editObjs": {
//			"type": "object",
//			"jaxId": "1GP79NMCQ0",
//			"editVersion": 2,
//			"attrs": {
//				"DataAIChat": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1GP79NMCQ1",
//					"editVersion": 20,
//					"attrs": {
//						"constructArgs": {
//							"type": "object",
//							"jaxId": "1GP79NMCQ2",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1GP79NMCQ3",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"functions": {
//							"type": "object",
//							"def": "Functions",
//							"jaxId": "1GP79NMCQ4",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false"
//					},
//					"mockups": {}
//				}
//			}
//		}
//	}
//}