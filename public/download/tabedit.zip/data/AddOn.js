//Auto genterated by Cody
import inherits from "/@inherits";
/*#{1G9DNULHP0StartDoc*/
/*}#1G9DNULHP0StartDoc*/
//----------------------------------------------------------------------------
let AddOn=function(){
	/*#{1G9DNVH4F0PreConstruct*/
	/*}#1G9DNVH4F0PreConstruct*/
	this.catalog="";
	this.name="";
	this.path="";
	this.def=null;
	this.loadPms=null;
	/*#{1G9DNVH4F0PostConstruct*/
	/*}#1G9DNVH4F0PostConstruct*/
};
AddOn.prototype={};
let _AddOn=AddOn.prototype;
/*#{1G9DNVH4F0ExCodes*/
let addOn=_AddOn;
let app=null;

//----------------------------------------------------------------------------
addOn.load=function(){
	let self=this;
	if(this.loadPms){
		return this.loadPms;
	}

	this.loadPms=import(this.path).then((mod)=>{
		let def;
		self.def=def=mod.default;
		if(def.init){
			return def.init();
		}
		return self;
	});
	return this.loadPms;
};

let catalogs={};

//----------------------------------------------------------------------------
AddOn.setupAddOn=function(_app,def){
	let catName,catVO,adoName,adoDef;
	app=_app;
	if(def){
		AddOn.regAddOns(def);
	}
};

//----------------------------------------------------------------------------
AddOn.regAddOns=function(defs){
	let catName,catVO,adoName,adoDef;
	for(catName in defs){
		catVO=defs[catName];
		for(adoName in catVO){
			adoDef=catVO[adoName];
			AddOn.regAddOn(catName,adoName,adoDef);
		}
	}
};

//----------------------------------------------------------------------------
AddOn.regAddOn=async function(catalog,name,def,init=false){
	let addOn,catalogHash;
	addOn=new AddOn();
	addOn.catalog=catalog;
	addOn.name=name;
	if(typeof(def)==="string"){
		addOn.path=def;
		if(!def.startsWith("/@")){
		}
		if(init){
			addOn.def=(await import(def)).default;
		}
	}else{
		addOn.def=def;
	}
	catalogHash=catalogs[catalog];
	if(!catalogHash){
		catalogHash=catalogs[catalog]={};
	}
	catalogHash[name]=addOn;
	return addOn;
};

//----------------------------------------------------------------------------
AddOn.aliasAddOn=function(catalog,name,addOn){
	let catalogHash;
	catalogHash=catalogs[catalog];
	if(!catalogHash){
		catalogHash=catalogs[catalog]={};
	}
	catalogHash[name]=addOn;
};

//----------------------------------------------------------------------------
AddOn.getCatalog=function(catalog){
	return catalogs[catalog];
};

//----------------------------------------------------------------------------
AddOn.getAddOns=function(catalog){
	catalog=catalogs[catalog];
	if(catalog){
		return Object.values(catalog);
	}
	return [];
};

//----------------------------------------------------------------------------
AddOn.getAddOn=function(catalog,name){
	let catalogHash;
	catalogHash=catalogs[catalog];
	if(!catalogHash){
		return null;
	}
	return catalogHash[name];
};

//----------------------------------------------------------------------------
AddOn.useAddOn=async function(catalog,name){
	let addOn;
	addOn=AddOn.getAddOn(catalog,name);
	if(!addOn){
		return null;
	}
	if(addOn.def){
		return addOn;
	}
	await addOn.load();
	return addOn;
};
/*}#1G9DNVH4F0ExCodes*/


/*#{1G9DNULHP0EndDoc*/
/*}#1G9DNULHP0EndDoc*/

export{AddOn};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DataDoc",
//	"jaxId": "1G9DNULHP0",
//	"editVersion": 3,
//	"attrs": {
//		"editObjs": {
//			"type": "object",
//			"jaxId": "1G9DNULHP1",
//			"editVersion": 1,
//			"attrs": {
//				"AddOn": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1G9DNVH4F0",
//					"editVersion": 12,
//					"attrs": {
//						"constructArgs": {
//							"type": "object",
//							"jaxId": "1G9DNVH5J0",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1G9DNVH5J1",
//							"editVersion": 9,
//							"attrs": {
//								"catalog": {
//									"type": "string",
//									"valText": ""
//								},
//								"name": {
//									"type": "string",
//									"valText": ""
//								},
//								"path": {
//									"type": "string",
//									"valText": ""
//								},
//								"def": {
//									"type": "auto",
//									"valText": "null"
//								},
//								"loadPms": {
//									"type": "auto",
//									"valText": "null"
//								}
//							}
//						},
//						"functions": {
//							"type": "object",
//							"def": "Functions",
//							"jaxId": "1G9DNVH5J2",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false"
//					},
//					"mockups": {
//						"AIChat": {
//							"type": "object",
//							"jaxId": "1GPF8ODRG0",
//							"editVersion": 12,
//							"attrs": {
//								"catalog": "",
//								"name": "",
//								"path": "",
//								"def": "null",
//								"loadPms": "null"
//							}
//						}
//					}
//				}
//			}
//		}
//	}
//}