//Auto genterated by Cody
import VFACT from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1G9DSGUKU0StartDoc*/
import pathLib from "/@path";
import {tabFS} from "/@tabos";
import {AddOn} from "./AddOn.js";
import {makeNotify,makeObjEventEmitter} from "/@events";
import wordLib from "../lib/ccjshint.js";
/*}#1G9DSGUKU0StartDoc*/
//----------------------------------------------------------------------------
/*#{1G9DSHIA30Constructor+*/
let DataDocs=function(){
/*}#1G9DSHIA30Constructor+*/
	/*#{1G9DSHIA30PreConstruct*/
	this.docHash={};
	this.docList=[];
	this.hotDoc=null;
	this.saveUsage=true;
	this.usagePath="/doc/edlit/recent.json";
	makeObjEventEmitter(this);
	makeNotify(this);
	
	/*}#1G9DSHIA30PreConstruct*/
	/*#{1G9DSHIA30Properties+*/
	/*}#1G9DSHIA30Properties+*/
	/*#{1G9DSHIA30PostConstruct*/
	/*}#1G9DSHIA30PostConstruct*/
};
DataDocs.prototype={};
let _DataDocs=DataDocs.prototype;
/*#{1G9DSHIA30ExCodes*/
let dataDocs=_DataDocs;

//----------------------------------------------------------------------------
dataDocs.newDoc=async function(path,slient=false){
	let doc,entry,extName,addOn;
	doc=this.docHash[path];
	if(doc){
		return null;
	}
	entry=await tabFS.getEntry(path);
	if(entry){
		return null;
	}
	await tabFS.writeFile(path,"","utf8");
	extName=pathLib.ext2name(path);
	if(!extName){
		extName=pathLib.extname(path);
	}
	addOn=await AddOn.useAddOn("DocType",extName);
	if(addOn){
		doc=addOn.def.newDoc(this);
	}else{
		doc=new DataDoc(this);
	}
	if(!await doc.loadDoc(path)){
		return null;
	}
	this.docHash[path]=doc;
	this.docList.push(doc);
	if(slient){
		return doc;
	}
	this.emit("NewDoc",doc);
	return doc;
};

//----------------------------------------------------------------------------
dataDocs.newEmptyDoc=async function(extType,slient,text=""){
	let name,cnt,doc,addOn;
	if(!extType){
		extType=".txt"
	}else{
		extType=""+extType;
		if(!extType.startsWith(".")){
			extType="."+extType;
		}
	}
	name="Noname"+extType;
	cnt=0;
	while(this.getDoc(name)){
		cnt++;
		name="Noname"+cnt+extType;
	}
	addOn=await AddOn.useAddOn("DocType",extType);
	if(addOn){
		doc=addOn.def.newDoc(this);
	}else{
		doc=new DataDoc(this);
	}
	doc.initEmpty(name,extType,text);
	this.docHash[name]=doc;
	this.docList.push(doc);
	if(slient){
		return doc;
	}
	this.emit("NewDoc",doc);
	return doc;
};

//----------------------------------------------------------------------------
dataDocs.getDoc=function(path){
	return this.docHash[path];
};

//----------------------------------------------------------------------------
dataDocs.loadDoc=async function(path){
	let doc,entry,extName,addOn;
	doc=this.docHash[path];
	if(doc){
		return doc;
	}
	extName=pathLib.ext2name(path);
	if(!extName){
		extName=pathLib.extname(path);
	}
	extName=extName.toLowerCase();
	if(extName.endsWith(".baseversion")){
		extName=".baseversion";
	}else{
		//Check if the file is existed...
		entry=await tabFS.getEntry(path);
		if(!entry || entry.dir){
			return null;
		}
	}
	addOn=await AddOn.useAddOn("DocType",extName);
	if(addOn){
		doc=addOn.def.newDoc(this);
	}else{
		doc=new DataDoc(this);
	}
	if(!await doc.loadDoc(path)){
		return null;
	}
	this.docHash[path]=doc;
	return doc;
};

//----------------------------------------------------------------------------
dataDocs.openDoc=async function(path,tempOpen=false){
	let doc,entry,extName,addOn;
	doc=this.docHash[path];
	if(doc){
		let idx;
		idx=this.docList.indexOf(doc);
		if(idx<0){//is stayInMem doc?
			this.docList.push(doc);
			doc.isOpened=true;
			this.emit("NewDoc",doc);
		}
		if(!tempOpen){
			this.pinDoc(doc);
		}
		return doc;
	}
	doc=await this.loadDoc(path);
	if(doc){
		doc.tempOpen=tempOpen;
		this.docList.push(doc);
		doc.isOpened=true;
		this.emit("NewDoc",doc);
	}
	return doc;
};

//----------------------------------------------------------------------------
dataDocs.pinDoc=function(doc){
	if(!doc.tempOpen){
		return;
	}
	doc.tempOpen=false;
	this.emit("PinDoc",doc);
};

//----------------------------------------------------------------------------
dataDocs.focusDoc=function(doc,updateList=true){
	let list,idx,hotDoc;
	list=this.docList;
	if(doc===this.hotDoc){
		if(updateList){
			idx=list.indexOf(doc);
			if(idx<0){
				return;//This is not possible.
			}
			list.splice(idx,1);
			list.push(doc);
		}
		//this.emit("FocusDoc",doc);
		return;
	}
	if(updateList && doc){
		idx=list.indexOf(doc);
		if(idx<0){
			list.push(doc);
		}else{
			list.splice(idx,1);
			list.push(doc);
		}
	}
	hotDoc=this.hotDoc;
	if(hotDoc){
		if(hotDoc.tempOpen){
			this.hotDoc=null;
			this.closeDoc(hotDoc);
		}else{
			this.hotDoc.blur();
			this.emit("BlurDoc",this.hotDoc);
		}
	}

	this.hotDoc=doc;
	if(doc){
		doc.focus();
		this.emit("FocusDoc",doc);
	}
};

//----------------------------------------------------------------------------
dataDocs.applyDocList=function(list){
	let i,n,doc,path,docHash,docList,idx;
	docList=this.docList;
	docHash=this.docHash;
	n=list.length;
	for(i=0;i<n;i++){
		path=list[i];
		doc=docHash[path];
		if(doc){
			idx=docList.indexOf(doc);
			if(idx<0){
				return;//This is not possible.
			}
			docList.splice(idx,1);
			docList.push(doc);
		}
	}
};

//----------------------------------------------------------------------------
dataDocs.closeDoc=function(doc){
	let list,hash,idx;
	list=this.docList;
	hash=this.docHash;
	idx=list.indexOf(doc);
	if(idx<0){
		return false;
	}
	list.splice(idx,1);
	doc.isOpened=false;
	if(!doc.stayInMem){
		delete hash[doc.path];
	}
	this.emit("CloseDoc",doc);
	if(doc===this.hotDoc){
		this.hotDoc=null;
		doc=list[list.length-1];
		this.focusDoc(doc);
	}
	return true;
};

//----------------------------------------------------------------------------
dataDocs.checkDocsModify=async function(){
	let doc;
	for(doc of this.docList){
		doc.checkModify();
	}
};

//----------------------------------------------------------------------------
dataDocs.updateUsage=async function(doc){
	let path,list,idx;
	if(!this.saveUsage){
		return;
	}
	try{
		path=doc.path;
		list=await tabFS.readFile(this.usagePath,"utf8");
		list=JSON.parse(list);
		idx=list.indexOf(path);
		if(idx>=0){
			list.splice(idx,1);
		}
		list.push(path);
		if(list.length>20){
			list=list.slice(list.length-20);
		}
		list=JSON.stringify(list);
		await tabFS.writeFile(this.usagePath,list,"utf8");
	}catch(e){
		list=[doc.path];
		list=JSON.stringify(list);
		await tabFS.writeFile(this.usagePath,list,"utf8");
	}
};

//----------------------------------------------------------------------------
dataDocs.getUsage=async function(){
	let list;
	try{
		list=await tabFS.readFile(this.usagePath,"utf8");
		list=JSON.parse(list);
	}catch(e){
		list=[];
	}
	return list;
}
//****************************************************************************
//****************************************************************************
/*}#1G9DSHIA30ExCodes*/

//----------------------------------------------------------------------------
/*#{1G9DSHQA80Constructor+*/
let DataDoc=function(docs){
/*}#1G9DSHQA80Constructor+*/
	/*#{1G9DSHQA80PreConstruct*/
	if(!docs)
		return;
	this.docs=docs;
	this.name="";
	this.path=null;
	this.fileExt=null;
	this.docText=null;
	this.changed=0;
	this.loadTime=0;
	this.editVersion=null;
	this.editBox=null;
	this.tabBox=null;
	this.cm=null;
	this.cmDoc=null;
	this.focused=0;
	this.isOpened=false;
	this.subDocs=[];
	this.docStates={};
	makeObjEventEmitter(this);
	makeNotify(this);
	/*}#1G9DSHQA80PreConstruct*/
	/*#{1G9DSHQA80Properties+*/
	/*}#1G9DSHQA80Properties+*/
	/*#{1G9DSHQA80PostConstruct*/
	/*}#1G9DSHQA80PostConstruct*/
};
DataDoc.prototype={};
let _DataDoc=DataDoc.prototype;
/*#{1G9DSHQA80ExCodes*/
let dataDoc=_DataDoc;
//----------------------------------------------------------------------------
dataDoc.initEmpty=async function(path,extType,initText){
	this.path=path;
	this.fileExt=extType;
	this.name=path;
	this.docText=initText||"";
	this.loadTime=Date.now();
	this.docs.updateUsage(this);
	this.stayInMem=false;
	this.tempOpen=false;
	//For version Edit
	this.subDocs=[];
	return true;
};

//----------------------------------------------------------------------------
dataDoc.loadDoc=async function(path){
	let ext;
	this.path=path;
	this.name=pathLib.basename(path);
	ext=this.fileExt=pathLib.extname(path).toLowerCase();
	if(this.fileExt===".baseversion"){
		let baseText,orgPath,entry,curDoc;
		orgPath=path.substring(0,path.length-ext.length);
		//Load the file's baseVersion content:
		baseText=await tabFS.loadFileBase(orgPath,"utf8");
		this.docText=baseText||"";
		curDoc=new DataDoc(this.docs);
		await curDoc.loadDoc(orgPath);
		this.subDocs[0]=curDoc;
		entry=await tabFS.getEntry(orgPath);
		if(entry){
			if(entry.baseVersionIdx>=0){
				this.versionName="Base version index: "+entry.baseVersionIdx;
			}else{
				this.versionName="Base version";
			}
		}
	}else if(this.fileExt===".conflict"){
		let pos,versionIdx,baseText,conflictText,orgPath,entry,baseDoc,curDoc,basePath;
		orgPath=path.substring(0,path.length-".conflict".length);
		pos=orgPath.lastIndexOf(".");
		versionIdx=orgPath.substring(pos+1);
		orgPath=orgPath.substring(0,pos);
		//Load the file's baseVersion content:
		baseDoc=new DataDoc(this.docs);
		await baseDoc.loadDoc(orgPath+".baseversion");
		curDoc=baseDoc.subDocs[0];
		this.subDocs[0]=curDoc;
		this.subDocs[1]=baseDoc;
		this.docText=await tabFS.readFile(this.path,"utf8");
		//Get version name:
		this.versionName="Cluod version index: "+versionIdx;
	}else if(this.fileExt===".compath"){
		let json;
		try{
			json=this.docText=await tabFS.readFile(this.path,"utf8");
			json=JSON.parse(json);
			json.leftPath=json.leftPath||"/";
			json.rightPath=json.rightPath||"/";
		}catch(err){
			json={leftPath:"/",rightPath:"/"};
		}
		json.path=this.path;
		await this.loadCompath(json);
	}else{
		try{
			this.docText=await tabFS.readFile(this.path,"utf8");
		}catch(e){
			this.docText="";
			this.loadTime=Date.now();
			this.docs.updateUsage(this);
			return false;
		}
		this.versionName=this.name;
	}
	this.loadTime=Date.now();
	this.docs.updateUsage(this);
	this.emitNotify("Loaded");
	this.docs.emit("DocLoaded",this);
	return true;
};

//----------------------------------------------------------------------------
dataDoc.loadCompare=async function(cmpVO){
	let leftVO,rightVO,subDoc;
	async function loadDoc(doc,vo){
		if(vo.text){
			doc.docText=vo.text;
			doc.path=vo.path;
			doc.name=vo.name;
			doc.fileExt=pathLib.extname(doc.path);
		}else if(vo.path){
			doc.docText=(await tabFS.readFile(vo.path,"utf8"))||"";
			doc.path=vo.path;
			doc.name=vo.name;
			doc.fileExt=pathLib.extname(doc.path);
		}
	}
	
	if(typeof(cmpVO)==="string"){
		let json;
		try{
			json=await tabFS.readFile(cmpVO,"utf8");
			cmpVO=JSON.parse(json);
		}catch(err){
			json=null;
			return null;
		}
	}

	this.path=cmpVO.path||"NewCompare.compare";
	
	this.compareVO=cmpVO;
	if(cmpVO.left){
		if(typeof(cmpVO.left)==="string"){
			cmpVO.left={path:cmpVO.left};
		}
		subDoc=new DataDoc(this.docs);
		await loadDoc(subDoc,cmpVO.left);
		this.subDocs.push(subDoc);
		cmpVO.left.doc=subDoc;
	}

	if(cmpVO.mid){
		if(typeof(cmpVO.mid)==="string"){
			cmpVO.mid={path:cmpVO.mid};
		}
		subDoc=new DataDoc(this.docs);
		await loadDoc(subDoc,cmpVO.mid);
		this.subDocs.push(subDoc);
		cmpVO.mid.doc=subDoc;
	}
	if(cmpVO.right){
		if(typeof(cmpVO.right)==="string"){
			cmpVO.right={path:cmpVO.right};
		}
		subDoc=new DataDoc(this.docs);
		await loadDoc(subDoc,cmpVO.right);
		this.subDocs.push(subDoc);
		cmpVO.right.doc=subDoc;
	}
	this.fileExt=".compare";
	this.loadTime=Date.now();
	this.emitNotify("Loaded");
	this.docs.emit("DocLoaded",this);
	return this;
};

//----------------------------------------------------------------------------
dataDoc.loadCompath=async function(cmpVO){
	let leftName,rightName,path;
	if(!cmpVO){
		cmpVO={leftPath:"/",rightPath:"/"};
	}else if(typeof(cmpVO)==="string"){
		let json;
		try{
			json=await tabFS.readFile(cmpVO,"utf8");
			cmpVO=JSON.parse(json);
		}catch(err){
			cmpVO={leftPath:"/",rightPath:"/"};
		}
	}
	path=cmpVO.path||"NewCompare.compath";
	this.compathVO=cmpVO;
	this.leftPath=cmpVO.left||cmpVO.leftPath;
	this.rightPath=cmpVO.right||cmpVO.rightPath;
	if(cmpVO.excludeType){
		this.excludeTypeSet=new Set(cmpVO.excludeType);
	}
	if(cmpVO.excludePath){
		this.excludePathSet=new Set(cmpVO.excludePath);
	}
	leftName=this.leftPath?pathLib.basename(this.leftPath):"?";
	rightName=this.rightPath?pathLib.basename(this.rightPath):"?";
	this.path=path;
	this.fileExt=".compath";
};

//----------------------------------------------------------------------------
dataDoc.saveCompareSlot=async function(slotVO,rootDoc,slotName){
	let docText,doc,editBox,editText;
	if(!slotVO || slotVO.allowSave===false){
		return;
	}
	doc=slotVO.doc;
	if(!doc){
		return;
	}
	editBox=rootDoc.editBox;
	if(editBox){
		editText=editBox.getEditText(slotName);
		doc.docText=editText;
	}
	if(slotVO.path || slotVO.save){
		doc.emit("UpdateDoc",true);//AddOn will update the edit text here.
		doc.saveText=this.docText;
		doc.emit("AboutSave");//AddOn can update the about-save text here.
		if(slotVO.save){
			await slotVO.save(doc.saveText);
		}else{
			await tabFS.writeFile(slotVO.path,doc.saveText,"utf8");
		}
		if(editBox){
			this.cleanEditVersion=editBox.getEditVersion()
		}
		this.loadTime=Date.now();
		this.emitNotify("Saved");
		this.docs.emit("DocSaved",this);
		this.docs.updateUsage(this);
	}
};

//----------------------------------------------------------------------------
dataDoc.saveDoc=async function(){
	let editBox,editText;
	if(this.compareVO){//Save compare
		let docVO,doc;
		await this.saveCompareSlot(this.compareVO.left,this,"left");
		await this.saveCompareSlot(this.compareVO.mid,this,"mid");
		await this.saveCompareSlot(this.compareVO.right,this,"right");
		this.emitNotify("Saved");
		this.docs.emit("DocSaved",this);
		return;
	}
	if(this.compathVO){
		let text;
		text=await this.getDocText();
		this.saveText=text;
		await tabFS.writeFile(this.path,text,"utf8");
		this.loadTime=Date.now();
		this.emitNotify("Saved");
		this.docs.emit("DocSaved",this);
		this.compathChanged=false;
		this.docs.updateUsage(this);
		return;
	}
	if(!this.path.startsWith("/")){
		return;
	}
	editBox=this.editBox;
	if(editBox){
		editText=editBox.getEditText();
	}else{
		editText=this.docText;
	}
	if(this.fileExt===".baseversion"){
		this.subDocs[0].docText=editText;
		this.subDocs[0].saveDoc();
	}else if(this.fileExt===".conflict"){
		this.subDocs[0].docText=editText;
		this.subDocs[0].saveDoc();
	}else{
		this.docText=editText;
		this.emit("UpdateDoc",true);//AddOn will update the edit text here.
		this.saveText=this.docText;
		this.emit("AboutSave");//AddOn can update the about-save text here.
		//this.docText=this.saveText;
		await tabFS.writeFile(this.path,this.saveText,"utf8");
	}
	if(editBox){
		this.cleanEditVersion=editBox.getEditVersion()
	}
	this.loadTime=Date.now();
	this.emitNotify("Saved");
	this.docs.emit("DocSaved",this);
	this.docs.updateUsage(this);
	this.scanHint();
};

//----------------------------------------------------------------------------
dataDoc.resolveConflict=async function(){
	let orgPath;
	if(this.fileExt!==".conflict"){
		return;
	}
	orgPath=this.subDocs[0].path;
	await tabFS.setEntryInfo(orgPath,{conflict:false});
	await tabFS.del(this.path);//Delete this conflict file
};

//----------------------------------------------------------------------------
dataDoc.getDocText=function(){
	if(this.fileExt===".compath" && this.compathVO){
		this.compathVO.leftPath=this.leftPath;
		this.compathVO.rightPath=this.rightPath;
		if(this.excludePathSet){
			this.compathVO.excludePath=[...this.excludePathSet.values()];
		}
		if(this.excludeTypeSet){
			this.compathVO.excludeType=[...this.excludeTypeSet.values()];
		}
		return JSON.stringify(this.compathVO,null,"\t");
	}
	if(this.editBox){
		this.docText=this.editBox.getEditText();
	}
	return this.docText;
};

//----------------------------------------------------------------------------
dataDoc.setDocText=function(text,undo=true){
	this.docText=text;
	if(this.editBox){
		this.editBox.setEditText(text,undo);
	}
};

//----------------------------------------------------------------------------
dataDoc.assignEditor=async function(box){
	if(box===this.editBox){
		this.cleanEditVersion=box.getEditVersion();
		return;
	}
	this.editBox=box;
	box.on("Change",()=>{this.changedByEditor()});
	box.on("InitDone",()=>{this.cleanEditVersion=box.getEditVersion()});
	this.cleanEditVersion=box.getEditVersion();
};

//----------------------------------------------------------------------------
dataDoc.resetEditorVersion=function(editBox){
	editBox=editBox||this.editBox;
	if(editBox){
		this.cleanEditVersion=editBox.getEditVersion();
	}
};

//----------------------------------------------------------------------------
dataDoc.assignTabBox=function(tabBox){
	this.tabBox=tabBox;
};

//----------------------------------------------------------------------------
dataDoc.changedByEditor=function(){
	let edVsn;
	edVsn=this.editBox.getEditVersion();
	if(this.cleanEditVersion!==edVsn){
		this.emitNotify("Changed");
		this.docs.emit("DocChanged",this);
	}else{
		this.emitNotify("Saved");
		this.docs.emit("DocSaved",this);
	}
};

//----------------------------------------------------------------------------
dataDoc.focus=function(){
	this.focused=1;
	this.emit("Focused");
	this.emitNotify("Focused");
};

//----------------------------------------------------------------------------
dataDoc.tabFocused=function(){
	this.checkModify();
};

//----------------------------------------------------------------------------
dataDoc.blur=function(){
	this.focused=0;
	this.emit("Blured");
	this.emitNotify("Blured");
};

//----------------------------------------------------------------------------
dataDoc.isChanged=function(){
	let editBox;
	if(this.compareVO){
		return !!this.compareChanged;
	}else if(this.compathVO){
		return this.compathChanged;
	}else{
		editBox=this.editBox;
		if(!editBox){
			return false;
		}
		return this.cleanEditVersion!=editBox.getEditVersion();
	}
};

//----------------------------------------------------------------------------
dataDoc.checkModify=async function(){
	if(this.path.startsWith("/")){
		let entry,editBox;
		if(this.fileExt===".baseversion" || this.fileExt===".conflict"){
			let editDoc;
			editDoc=this.subDocs[0];
			if(editDoc){
				entry=await tabFS.getEntry(editDoc.path);
				if(entry && entry.modifyTime>editDoc.loadTime){
					if(this.isChanged()){
						if(!window.confirm(`${editDoc.name} is changed outside editor, it also has unsaved changes here. Do you want give up changes here to load changes on disk?`)){
							return;
						}
					}
					editDoc.docText=await tabFS.readFile(editDoc.path,"utf8");
					editBox=this.editBox;
					if(editBox){
						editBox.setEditText(editDoc.docText);
						this.cleanEditVersion=editBox.getEditVersion();
					}
					this.loadTime=Date.now();
					this.emitNotify("Loaded");
					this.docs.emit("DocLoaded",this);
				}
			}
		}else{
			entry=await tabFS.getEntry(this.path);
			if(entry && entry.modifyTime>this.loadTime){
				if(this.isChanged()){
					if(!window.confirm(`${this.name} is changed outside editor, it also has unsaved changes here. Do you want give up changes here to load changes on disk?`)){
						return;
					}
				}
				this.saveText=await tabFS.readFile(this.path,"utf8");
				this.emit("AboutLoadModified");//Give addons a chance to modify the docText
				this.docText=this.saveText;
				editBox=this.editBox;
				if(editBox){
					editBox.setEditText(this.docText);
					this.cleanEditVersion=editBox.getEditVersion();
				}
				this.loadTime=Date.now();
				this.emitNotify("Loaded");
				this.docs.emit("DocLoaded",this);
			}
		}
	}
};

//----------------------------------------------------------------------------
//Get state:
dataDoc.getState=function(codeName){
	return this.docStates[codeName];
};

//----------------------------------------------------------------------------
//Set state:
dataDoc.setState=function(codeName,state){
	this.docStates[codeName]=state;
}

//****************************************************************************
//:Hint functions:
//****************************************************************************
{
	let hintBusy=false;
	let hintMode=null;
	let hintModeJS=null;
	let hintModeJSX=null;
	let hintModeState=null;
	let CodeMirror=window.CodeMirror;
	let hintQ=[];

	//------------------------------------------------------------------------
	DataDoc.getHintMode=async function(doc){
		let modeCode;
		if(!doc){
			modeCode="javascript";
		}else{
			switch(doc.fileExt){
				case ".js":
					modeCode="javascript";
					break;
				case ".jsx":
					modeCode="jsx";
					break;
				default:
					return null;
			}
		}
		if(modeCode==="javascript"){
			if(hintModeJS){
				return hintModeJS;
			}
			await VFACT.appendScript("/@codemirror/mode/javascript.js");
			hintModeJS = CodeMirror.getMode(CodeMirror.defaults, "javascript");
			return hintModeJS;
		}
		if(modeCode==="jsx"){
			if(hintModeJSX){
				return hintModeJSX;
			}
			await VFACT.appendScript("/@codemirror/mode/javascript.js");
			await VFACT.appendScript("/@codemirror/mode/xml.js");
			await VFACT.appendScript("/@codemirror/mode/jsx.js");
			hintModeJSX = CodeMirror.getMode(CodeMirror.defaults, "text/jsx");
			return hintModeJSX;
		}
		return null;
	};
	//------------------------------------------------------------------------
	//Scan a file for hint:
	DataDoc.scanCodeHints=async function(codeText,doc){
		let lines,line,style,word,pos,stub,timer;
		if(hintBusy){
			if(!doc){
				//Only text with doc can be wait in Q:
				return;
			}
			for(stub in hintQ){
				if(stub.doc===doc){
					stub.code=codeText;
					return;
				}
			}
			hintQ.push({doc:doc,code:codeText});
		}
		hintBusy=true;
		hintMode=await DataDoc.getHintMode(doc);
		if(!hintMode){
			hintBusy=false;
			//Check Q:
			stub=hintQ.shift();
			if(stub){
				DataDoc.scanCodeHints(stub.code,stub.doc);
			}
			return;
		}
		hintModeState=CodeMirror.startState(hintMode);
		//Filter cody project info:
		pos=codeText.indexOf("/\*\Cody Project Doc*/");
		if(pos>0){
			codeText=codeText.substring(0,pos);
		}
		lines= CodeMirror.splitLines(codeText);
		timer=Date.now();
		try{
			for (var i = 0, e = lines.length; i < e; ++i) {
				line=lines[i];
				if(line.length>300){
					continue;
				}
				var stream = new CodeMirror.StringStream(lines[i], null, {
					lookAhead: function(n) { return lines[i + n] },
					baseToken: function() {}
				});
				while (!stream.eol()) {
					style = hintMode.token(stream, hintModeState);
					switch(style){
						case "property":
							word=stream.current();
							wordLib.addWord(word, style,doc);
							break;
						case "variable":
						case "variable-g":
						case "variable-o":
						case "variable-e":
						case "variable-2":
							word=stream.current();
							wordLib.addWord(word, "variable",doc);
							break;
					}
					stream.start = stream.pos;
				}
				//Scan 50ms per batch
				if(Date.now()-timer>=50){
					await sleep(10);
					timer=Date.now();
				}
			}
		}catch(err){
		}
		hintBusy=false;
		//Check Q:
		stub=hintQ.shift();
		if(stub){
			DataDoc.scanCodeHints(stub.code,stub.doc);
		}
	};

	//--------------------------------------------------------------------
	//Scan a file for hint:
	DataDoc.scanFileHints=async function(disk,path){
		let ext,text,lines;
		ext=pathLib.extname(path);
		if(ext!==".js" && ext!==".mjs"){
			return;
		}
		try{
			text=await disk.loadText(path);
			await DataDoc.scanCodeHints(text);
		}catch(e){
		}
	};

	//--------------------------------------------------------------------
	//Scan a live doc for hint:
	dataDoc.scanHint=async function(){
		let codeText;
		codeText=this.getDocText();
		DataDoc.scanCodeHints(codeText,this);
	};
}
/*}#1G9DSHQA80ExCodes*/


/*#{1G9DSGUKU0EndDoc*/
//----------------------------------------------------------------------------
dataDocs.openCompare=async function(cmpVO){
	let doc;
	doc=new DataDoc(this);
	if(doc){
		doc=await doc.loadCompare(cmpVO);
		if(doc){
			this.docList.push(doc);
			doc.isOpened=true;
			this.emit("NewDoc",doc);
		}
	}
	return doc;
};

//----------------------------------------------------------------------------
dataDocs.openCompath=async function(cmpVO){
	let doc;
	doc=new DataDoc(this);
	if(doc){
		await doc.loadCompath(cmpVO);
		this.docList.push(doc);
		doc.isOpened=true;
		this.emit("NewDoc",doc);
	}
	return doc;
};
/*}#1G9DSGUKU0EndDoc*/

export{DataDocs,DataDoc};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DataDoc",
//	"jaxId": "1G9DSGUKU0",
//	"attrs": {
//		"editObjs": {
//			"jaxId": "1G9DSGUKU1",
//			"attrs": {
//				"DataDocs": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1G9DSHIA30",
//					"attrs": {
//						"constructArgs": {
//							"jaxId": "1G9DSHIBN0",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1G9DSHIBN1",
//							"attrs": {}
//						},
//						"functions": {
//							"jaxId": "1G9DSHIBN2",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false",
//						"exportType": "Data Class",
//						"exportClass": "false"
//					},
//					"mockups": {}
//				},
//				"DataDoc": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1G9DSHQA80",
//					"attrs": {
//						"constructArgs": {
//							"jaxId": "1G9DSHQBB0",
//							"attrs": {
//								"docs": {
//									"type": "auto",
//									"valText": "null"
//								}
//							}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1G9DSHQBB1",
//							"attrs": {}
//						},
//						"functions": {
//							"jaxId": "1G9DSHQBB2",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false",
//						"exportType": "Data Class",
//						"exportClass": "false"
//					},
//					"mockups": {}
//				}
//			}
//		}
//	}
//}