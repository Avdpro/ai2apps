//Auto genterated by Cody
import VFACT from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1I05CUMOT0StartDoc*/
let $ln=VFACT.lanCode;
/*}#1I05CUMOT0StartDoc*/
let AppData={
	name:"AppData",//1I05CUMOU1
	type:"object",
	label:undefined,
	properties:{
		/*#{1I05CUMOU1MoreProperties*/
		/*}#1I05CUMOU1MoreProperties*/
	},
	newObject(){return VFACT.newUITemplateObj(this)},
	/*#{1I05CUMOU1MoreFunctions*/
	/*}#1I05CUMOU1MoreFunctions*/
};
VFACT.regUITemplate("1I05CUMOU1",AppData);
VFACT.regUITemplate("AppData",AppData);
/*#{1I05CUMOU1MoreCodes*/
/*}#1I05CUMOU1MoreCodes*/
let CfgEdit={
	name:"CfgEdit",//1I05DUMME0
	type:"object",
	label:undefined,
	properties:{
		indent:{
			name:"indent",type:"int",
			defaultValue:4,
		},
		/*#{1I05DUMME0MoreProperties*/
		/*}#1I05DUMME0MoreProperties*/
	},
	newObject(){return VFACT.newUITemplateObj(this)},
	/*#{1I05DUMME0MoreFunctions*/
	/*}#1I05DUMME0MoreFunctions*/
};
VFACT.regUITemplate("1I05DUMME0",CfgEdit);
VFACT.regUITemplate("CfgEdit",CfgEdit);
/*#{1I05DUMME0MoreCodes*/
/*}#1I05DUMME0MoreCodes*/
let CfgAICode={
	name:"CfgAICode",//1ICFK2E2E0
	type:"object",
	label:undefined,
	properties:{
		platform:{
			name:"platform",type:"string",
			label:"AI Platform",
			defaultValue:"OpenAI",
			required:true,
			choices:[
				"OpenAI","Claude","Google"
			],
		},
		model:{
			name:"model",type:"string",
			label:"Model",
			defaultValue:"gpt-4o-mini",
			choices:[
				""
			],
		},
		/*#{1ICFK2E2E0MoreProperties*/
		/*}#1ICFK2E2E0MoreProperties*/
	},
	newObject(){return VFACT.newUITemplateObj(this)},
	/*#{1ICFK2E2E0MoreFunctions*/
	/*}#1ICFK2E2E0MoreFunctions*/
};
VFACT.regUITemplate("1ICFK2E2E0",CfgAICode);
VFACT.regUITemplate("CfgAICode",CfgAICode);
/*#{1ICFK2E2E0MoreCodes*/
CfgAICode.properties.model.getChoices=function(obj){
	switch(obj.platform){
		default:
		case "OpenAI":
			return ["gpt-4o","gpt-4o-mini"];
		case "Claude":
			return ["claude-3-5-sonnet-latest"];
		case "Google":
			return ["gemini-pro"];
	}
};
/*}#1ICFK2E2E0MoreCodes*/
let CfgRunPrj={
	name:"CfgRunPrj",//1I05D04GF0
	type:"object",
	label:undefined,
	properties:{
		profileName:{
			name:"profileName",type:"string",
			defaultValue:"Run",
		},
		profileIcon:{
			name:"profileIcon",type:"string",
			defaultValue:"/~/-tabos/shared/assets/lab.svg",
		},
		main:{
			name:"main",type:"string",
		},
		arg:{
			name:"arg",type:"auto",
		},
		mode:{
			name:"mode",type:"string",
			choices:[
				"FrameApp","Page","Terminal"
			],
		},
		width:{
			name:"width",type:"int",
			defaultValue:360,
		},
		height:{
			name:"height",type:"int",
			defaultValue:600,
		},
		icon:{
			name:"icon",type:"string",
			defaultValue:"/~/tabos/shared/assets/aalogo.svg",
		},
		/*#{1I05D04GF0MoreProperties*/
		/*}#1I05D04GF0MoreProperties*/
	},
	newObject(){return VFACT.newUITemplateObj(this)},
	/*#{1I05D04GF0MoreFunctions*/
	/*}#1I05D04GF0MoreFunctions*/
};
VFACT.regUITemplate("1I05D04GF0",CfgRunPrj);
VFACT.regUITemplate("CfgRunPrj",CfgRunPrj);
/*#{1I05D04GF0MoreCodes*/
/*}#1I05D04GF0MoreCodes*/
let CfgProject={
	name:"CfgProject",//1I05DCI110
	type:"object",
	label:undefined,
	properties:{
		edit:{
			name:"edit",type:"object",
			label:"Code editor settings",
			class:"1I05DUMME0",
		},
		autoLint:{
			name:"autoLint",type:"bool",
			defaultValue:true,
		},
		aiCoder:{
			name:"aiCoder",type:"object",
			label:(($ln==="CN")?("AI 编程"):("AI Coder")),
			class:"1ICFK2E2E0",
		},
		run:{
			name:"run",type:"array",
			label:"Run settings:",
			initLength:0,
			element:{
				"type":"object","label":'###:',"class":"1I05D04GF0"
			},
		},
		addOns:{
			name:"addOns",type:"array",
			initLength:0,
			element:{
				"type":"string","label":'###:',"uiMode":"Path"
			},
		},
		/*#{1I05DCI110MoreProperties*/
		/*}#1I05DCI110MoreProperties*/
	},
	newObject(){return VFACT.newUITemplateObj(this)},
	/*#{1I05DCI110MoreFunctions*/
	/*}#1I05DCI110MoreFunctions*/
};
VFACT.regUITemplate("1I05DCI110",CfgProject);
VFACT.regUITemplate("CfgProject",CfgProject);
/*#{1I05DCI110MoreCodes*/
/*}#1I05DCI110MoreCodes*/

/*#{1I05CUMOT0EndDoc*/
/*}#1I05CUMOT0EndDoc*/

export{AppData,CfgEdit,CfgAICode,CfgRunPrj,CfgProject};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DataDoc",
//	"jaxId": "1I05CUMOT0",
//	"attrs": {
//		"editObjs": {
//			"jaxId": "1I05CUMOU0",
//			"attrs": {
//				"AppData": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1I05CUMOU1",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1I05CUMOU2",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1I05CUMOU3",
//							"attrs": {}
//						},
//						"functions": {
//							"jaxId": "1I05CUMOU4",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false"
//					},
//					"mockups": {}
//				},
//				"CfgEdit": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1I05DUMME0",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1I05DURLT0",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1I05DURLT1",
//							"attrs": {
//								"indent": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1I05DVAC60",
//									"attrs": {
//										"type": "int",
//										"defaultValue": "4"
//									}
//								}
//							}
//						},
//						"functions": {
//							"jaxId": "1I05DURLT2",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false"
//					},
//					"mockups": {}
//				},
//				"CfgAICode": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1ICFK2E2E0",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1ICFK4GD50",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1ICFK4GD51",
//							"attrs": {
//								"platform": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1ICFK4GD52",
//									"attrs": {
//										"type": "string",
//										"label": "AI Platform",
//										"defaultValue": "OpenAI",
//										"required": "true",
//										"choices": {
//											"type": "array",
//											"def": "Array",
//											"attrs": [
//												{
//													"type": "string",
//													"valText": "OpenAI"
//												},
//												{
//													"type": "string",
//													"valText": "Claude"
//												},
//												{
//													"type": "string",
//													"valText": "Google"
//												}
//											]
//										}
//									}
//								},
//								"model": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1ICFK4GD53",
//									"attrs": {
//										"type": "string",
//										"label": "Model",
//										"defaultValue": "gpt-4o-mini",
//										"choices": {
//											"type": "array",
//											"def": "Array",
//											"attrs": [
//												{
//													"type": "string",
//													"valText": ""
//												}
//											]
//										}
//									}
//								}
//							}
//						},
//						"functions": {
//							"jaxId": "1ICFK4GD54",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false"
//					},
//					"mockups": {}
//				},
//				"CfgRunPrj": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1I05D04GF0",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1I05D0E4J0",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1I05D0E4J1",
//							"attrs": {
//								"profileName": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1I05D96DK0",
//									"attrs": {
//										"type": "string",
//										"defaultValue": "Run"
//									}
//								},
//								"profileIcon": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1I05D96DK1",
//									"attrs": {
//										"type": "string",
//										"defaultValue": "/~/-tabos/shared/assets/lab.svg"
//									}
//								},
//								"main": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1I05D11L80",
//									"attrs": {
//										"type": "string"
//									}
//								},
//								"arg": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1I05DA7J40",
//									"attrs": {
//										"type": "auto"
//									}
//								},
//								"mode": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1I05D96DK2",
//									"attrs": {
//										"type": "string",
//										"choices": {
//											"type": "array",
//											"def": "Array",
//											"attrs": [
//												{
//													"type": "string",
//													"valText": "FrameApp"
//												},
//												{
//													"type": "string",
//													"valText": "Page"
//												},
//												{
//													"type": "string",
//													"valText": "Terminal"
//												}
//											]
//										}
//									}
//								},
//								"width": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1I05D96DK3",
//									"attrs": {
//										"type": "int",
//										"defaultValue": "360"
//									}
//								},
//								"height": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1I05D96DK4",
//									"attrs": {
//										"type": "int",
//										"defaultValue": "600"
//									}
//								},
//								"icon": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1I05DC67S0",
//									"attrs": {
//										"type": "string",
//										"defaultValue": "/~/tabos/shared/assets/aalogo.svg"
//									}
//								}
//							}
//						},
//						"functions": {
//							"jaxId": "1I05D0E4J2",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false"
//					},
//					"mockups": {}
//				},
//				"CfgProject": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1I05DCI110",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1I05DEB8P0",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1I05DEB8P1",
//							"attrs": {
//								"edit": {
//									"type": "object",
//									"def": "EditClassObjPpt",
//									"jaxId": "1I05E0L3K0",
//									"attrs": {
//										"type": "object",
//										"class": "\"1I05DUMME0\"",
//										"label": "Code editor settings"
//									}
//								},
//								"autoLint": {
//									"type": "object",
//									"def": "EditClassStdPpt",
//									"jaxId": "1I05DEB8P2",
//									"attrs": {
//										"type": "bool",
//										"defaultValue": "true"
//									}
//								},
//								"aiCoder": {
//									"type": "object",
//									"def": "EditClassObjPpt",
//									"jaxId": "1ICHUS0F70",
//									"attrs": {
//										"type": "object",
//										"class": "\"1ICFK2E2E0\"",
//										"label": {
//											"type": "string",
//											"valText": "AI 编程",
//											"localize": {
//												"EN": "AI Coder",
//												"CN": "AI 编程"
//											},
//											"localizable": true
//										}
//									}
//								},
//								"run": {
//									"type": "object",
//									"def": "EditClassAryPpt",
//									"jaxId": "1I05DG06S0",
//									"attrs": {
//										"type": "array",
//										"element": {
//											"jaxId": "1I05DG06S1",
//											"attrs": {
//												"type": "Object",
//												"label": "#'###:'",
//												"class": "\"1I05D04GF0\""
//											}
//										},
//										"initLength": "0",
//										"label": "Run settings:"
//									}
//								},
//								"addOns": {
//									"type": "object",
//									"def": "EditClassAryPpt",
//									"jaxId": "1I05DEB8P3",
//									"attrs": {
//										"type": "array",
//										"element": {
//											"jaxId": "1I05DEB8P4",
//											"attrs": {
//												"type": "String",
//												"label": "#'###:'",
//												"uiMode": "Path"
//											}
//										},
//										"initLength": "0"
//									}
//								}
//							}
//						},
//						"functions": {
//							"jaxId": "1I05DEB8P5",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false"
//					},
//					"mockups": {}
//				}
//			}
//		}
//	}
//}