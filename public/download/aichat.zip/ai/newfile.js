//Auto genterated by Cody
import {$P,VFACT,callAfter} from "/@vfact";
import pathLib from "/@path";
import inherits from "/@inherits";
/*#{1HC1GDHA80MoreImports*/
/*}#1HC1GDHA80MoreImports*/
const agentURL=(new URL(import.meta.url)).pathname;
const basePath=pathLib.dirname(agentURL);
const $ln=VFACT.lanCode||"EN";
/*#{1HC1GDHA80StartDoc*/
/*}#1HC1GDHA80StartDoc*/
//----------------------------------------------------------------------------
let newfile=function(session){
	let state,context;
	let self;
	let Start,chat,ShowInput,CheckInput,AICall,ShowResult,SayBye,CallAI;
	/*#{1HC1GDHA80LocalVals*/
	/*}#1HC1GDHA80LocalVals*/
	
	/*#{1HC1GDHA80PreContext*/
	/*}#1HC1GDHA80PreContext*/
	context={
		"size":5,
		/*#{1HC1GDHA84ExCtxAttrs*/
		/*}#1HC1GDHA84ExCtxAttrs*/
	};
	context=VFACT.flexState(context);
	/*#{1HC1GDHA80PostContext*/
	/*}#1HC1GDHA80PostContext*/
	let agent,segs={};
	segs["Start"]=Start=async function(input){//:1HCJV90CN0
		let result=input;
		let role="assistant";
		let conent="Hello! what can I do for you today?";
		session.addChatText(role,conent);
		return {seg:chat,result:(result),preSeg:"1HCJV90CN0",outlet:"1HCJV90CN2"};
	};
	Start.jaxId="1HCJV90CN0"
	Start.url="Start@"+agentURL
	Start.desc="这是一个AISeg。";
	
	segs["chat"]=chat=async function(input){//:1HCKQCLTN0
		let prompt=("Please input")||input;
		let placeholder=("");
		let text=("");
		let result="";
		result=await session.askChatInput({type:"input",prompt:prompt,placeholder:placeholder,text:text});
		return {seg:ShowInput,result:(result),preSeg:"1HCKQCLTN0",outlet:"1HCKQEL681"};
	};
	chat.jaxId="1HCKQCLTN0"
	chat.url="chat@"+agentURL
	chat.desc="等待用户输入prompt";
	
	segs["ShowInput"]=ShowInput=async function(input){//:1HCK1V1470
		let result=input;
		let role="user";
		let conent=input;
		session.addChatText(role,conent);
		return {seg:CheckInput,result:(result),preSeg:"1HCK1V1470",outlet:"1HCK1V14E4"};
	};
	ShowInput.jaxId="1HCK1V1470"
	ShowInput.url="ShowInput@"+agentURL
	ShowInput.desc="这是一个AISeg。";
	
	segs["CheckInput"]=CheckInput=async function(input){//:1HCK32M7Q0
		/*#{1HCK32M7Q0Start*/
		/*}#1HCK32M7Q0Start*/
		if(input==="exit"){
			/*#{1HCK32M7Q3Codes*/
			/*}#1HCK32M7Q3Codes*/
			return {seg:SayBye,result:(input),preSeg:"1HCK32M7Q0",outlet:"1HCK32M7Q3"};
		}
		/*#{1HCK32M7Q0Post*/
		/*}#1HCK32M7Q0Post*/
		return {seg:CallAI,result:(input),preSeg:"1HCK32M7Q0",outlet:"1HCK32M7Q2"};
	};
	CheckInput.jaxId="1HCK32M7Q0"
	CheckInput.url="CheckInput@"+agentURL
	CheckInput.desc="这是一个AISeg。";
	
	segs["AICall"]=AICall=async function(input){//:1HCK22A9H0
		let result;
		let sourcePath=pathLib.join(basePath,"./default.aichat");
		result= await session.pipeChat(sourcePath,input,false);
		return {seg:ShowResult,result:(result),preSeg:"1HCK22A9H0",outlet:"1HCK22A9H2"};
	};
	AICall.jaxId="1HCK22A9H0"
	AICall.url="AICall@"+agentURL
	AICall.desc="这是一个AISeg。";
	
	segs["ShowResult"]=ShowResult=async function(input){//:1HCK2NR7H0
		let result=input;
		let role="assistant";
		let conent=input;
		/*#{1HCK2NR7H0PreCodes*/
		/*}#1HCK2NR7H0PreCodes*/
		session.addChatText(role,conent);
		/*#{1HCK2NR7H0PostCodes*/
		result="";
		/*}#1HCK2NR7H0PostCodes*/
		return {seg:chat,result:(result),preSeg:"1HCK2NR7H0",outlet:"1HCK2NR7H2"};
	};
	ShowResult.jaxId="1HCK2NR7H0"
	ShowResult.url="ShowResult@"+agentURL
	ShowResult.desc="这是一个AISeg。";
	
	segs["SayBye"]=SayBye=async function(input){//:1HCK32M7Q4
		let result=input;
		let role="assistant";
		let conent="Bye!";
		session.addChatText(role,conent);
		return {result:result};
	};
	SayBye.jaxId="1HCK32M7Q4"
	SayBye.url="SayBye@"+agentURL
	SayBye.desc="这是一个AISeg。";
	
	segs["CallAI"]=CallAI=async function(input){//:1HCQ8270F0
		let result;
		let opts={
			mode:"gpt-3.5-turbo",
			temperature:0,
			maxToken:2000,
			secret:true,
		};
		let messages=[
			{role:"system",content:"Each time you interact with the user, imagine a few things randomly and tell the user their names. Please only answer with the names of the items, without including any other text."},
		];messages.push({role:"user",content:`Imagine ${input} random things, anything is fine, feel free to be imaginative
Please only provide the English names of the things, without including color, size, or other information. Separate the names of the things with semicolons.`});
		
		result=await session.callSegLLM("CallAI@"+agentURL,opts,messages);
		return {seg:ShowResult,result:(result),preSeg:"1HCQ8270F0",outlet:"1HCQ8270G0"};
	};
	CallAI.jaxId="1HCQ8270F0"
	CallAI.url="CallAI@"+agentURL
	CallAI.desc="执行一次LLM调用。";
	
	agent={
		isAIAgent:true,
		name:"newfile",
		url:agentURL,
		jaxId:"1HC1GDHA80",
		context:context,
		livingSeg:null,
		exec:async function(input){
			let result;
			/*#{1HC1GDHA80PreEntry*/
			/*}#1HC1GDHA80PreEntry*/
			result={seg:Start,"input":input};
			/*#{1HC1GDHA80PostEntry*/
			/*}#1HC1GDHA80PostEntry*/
			return result;
		},
		/*#{1HC1GDHA80MoreAgentAttrs*/
		/*}#1HC1GDHA80MoreAgentAttrs*/
	};
	/*#{1HC1GDHA80PostAgent*/
	/*}#1HC1GDHA80PostAgent*/
	return agent;
};
/*#{1HC1GDHA80ExCodes*/
/*}#1HC1GDHA80ExCodes*/


export default newfile;
export{newfile};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DocAIAgent",
//	"jaxId": "1HC1GDHA80",
//	"editVersion": 90,
//	"attrs": {
//		"editObjs": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1HC1GDHA81",
//			"editVersion": 2,
//			"attrs": {
//				"newfile": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1HC1GDHA90",
//					"editVersion": 120,
//					"attrs": {
//						"constructArgs": {
//							"type": "object",
//							"jaxId": "1HC1GDHA91",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HC1GDHA92",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"functions": {
//							"type": "object",
//							"def": "Functions",
//							"jaxId": "1HC1GDHA93",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false"
//					},
//					"mockups": {}
//				}
//			}
//		},
//		"agent": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1HC1GDHA82",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"segs": {
//			"type": "array",
//			"attrs": [
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1HCJV90CN0",
//					"editVersion": 98,
//					"attrs": {
//						"id": "Start",
//						"label": "Greeting to user",
//						"x": "60",
//						"y": "180",
//						"context": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HCJV90CN1",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"role": "assistant",
//						"text": "Hello! what can I do for you today?",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HCJV90CN2",
//							"editVersion": 51,
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。",
//								"showLine": "true"
//							},
//							"linkedSeg": "1HCKQCLTN0"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "askChat",
//					"jaxId": "1HCKQCLTN0",
//					"editVersion": 115,
//					"attrs": {
//						"id": "chat",
//						"label": "Wait chat prompt",
//						"x": "260",
//						"y": "260",
//						"context": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HCKQEL680",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"desc": "等待用户输入prompt",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"prompt": "Please input",
//						"placeholder": "",
//						"text": "",
//						"file": "true",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HCKQEL681",
//							"editVersion": 53,
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。",
//								"showLine": "true"
//							},
//							"linkedSeg": "1HCK1V1470"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1HCK1V1470",
//					"editVersion": 120,
//					"attrs": {
//						"id": "ShowInput",
//						"label": "Show input",
//						"x": "440",
//						"y": "340",
//						"context": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HCK1V14E3",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"role": "user",
//						"text": "#input",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HCK1V14E4",
//							"editVersion": 53,
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。",
//								"showLine": "true"
//							},
//							"linkedSeg": "1HCK32M7Q0"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "brunch",
//					"jaxId": "1HCK32M7Q0",
//					"editVersion": 102,
//					"attrs": {
//						"id": "CheckInput",
//						"label": "Check if exit?",
//						"x": "570",
//						"y": "470",
//						"context": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HCK32M7Q1",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"desc": "这是一个AISeg。",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HCK32M7Q2",
//							"editVersion": 51,
//							"attrs": {
//								"id": "Default",
//								"desc": "输出节点。",
//								"showLine": "true"
//							},
//							"linkedSeg": "1HCQ8270F0"
//						},
//						"outlets": {
//							"type": "array",
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1HCK32M7Q3",
//									"editVersion": 49,
//									"attrs": {
//										"id": "exit",
//										"condition": "",
//										"codes": "true",
//										"ouput": "",
//										"desc": "条件输出节点。"
//									},
//									"linkedSeg": "1HCK32M7Q4"
//								}
//							]
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "aiBot",
//					"jaxId": "1HCK22A9H0",
//					"editVersion": 100,
//					"attrs": {
//						"id": "AICall",
//						"label": "Call ChatGPT",
//						"x": "810",
//						"y": "180",
//						"context": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HCK22A9H1",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"source": "ai/default.aichat",
//						"secret": "false",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HCK22A9H2",
//							"editVersion": 38,
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。",
//								"showLine": "true"
//							},
//							"linkedSeg": "1HCK2NR7H0"
//						},
//						"secrect": {
//							"valText": "false"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1HCK2NR7H0",
//					"editVersion": 95,
//					"attrs": {
//						"id": "ShowResult",
//						"label": "Show AIChat result.",
//						"x": "940",
//						"y": "460",
//						"context": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HCK2NR7H1",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"desc": "这是一个AISeg。",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"role": "assistant",
//						"text": "#input",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HCK2NR7H2",
//							"editVersion": 46,
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。",
//								"showLine": "true"
//							},
//							"linkedSeg": "1HCK1V14E5"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1HCK32M7Q4",
//					"editVersion": 88,
//					"attrs": {
//						"id": "SayBye",
//						"label": "Exit agent",
//						"x": "760",
//						"y": "580",
//						"context": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HCK32M7Q5",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"role": "assistant",
//						"text": "Bye!",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HCK32M7Q6",
//							"editVersion": 35,
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。",
//								"showLine": "true"
//							}
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1HCK1V14E5",
//					"editVersion": 80,
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "1140",
//						"y": "670",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HCK1V14E6",
//							"editVersion": 35,
//							"attrs": {
//								"id": "Summary",
//								"desc": "输出节点。",
//								"showLine": "true"
//							},
//							"linkedSeg": "1HCK1V14E7"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1HCK1V14E7",
//					"editVersion": 76,
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "210",
//						"y": "620",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HCK1V14E8",
//							"editVersion": 35,
//							"attrs": {
//								"id": "Summary",
//								"desc": "输出节点。",
//								"showLine": "true"
//							},
//							"linkedSeg": "1HCKQCLTN0"
//						},
//						"dir": "B2T"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "callLLM",
//					"jaxId": "1HCQ8270F0",
//					"editVersion": 116,
//					"attrs": {
//						"id": "CallAI",
//						"label": "Call GPT",
//						"x": "770",
//						"y": "350",
//						"context": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HCQ8270J0",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"desc": "执行一次LLM调用。",
//						"codes": "false",
//						"mkpInput": "10",
//						"mode": "GPT-3.5",
//						"system": "Each time you interact with the user, imagine a few things randomly and tell the user their names. Please only answer with the names of the items, without including any other text.",
//						"temperature": "0",
//						"maxToken": "2000",
//						"messages": {
//							"type": "array",
//							"attrs": []
//						},
//						"prompt": "#`Imagine ${input} random things, anything is fine, feel free to be imaginative\nPlease only provide the English names of the things, without including color, size, or other information. Separate the names of the things with semicolons.`",
//						"secret": "true",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HCQ8270G0",
//							"editVersion": 24,
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。",
//								"showLine": "true"
//							},
//							"linkedSeg": "1HCK2NR7H0"
//						},
//						"secrect": {
//							"valText": "true"
//						}
//					}
//				}
//			]
//		},
//		"entry": "",
//		"debug": "true",
//		"localVars": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1HC1GDHA83",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"context": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1HC1GDHA84",
//			"editVersion": 14,
//			"attrs": {
//				"size": {
//					"type": "int",
//					"valText": "5"
//				}
//			}
//		},
//		"desc": "这是一个AI代理。"
//	}
//}