//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import pathLib from "/@path";
import inherits from "/@inherits";
import Base64 from "/@tabos/utils/base64.js";
import {trimJSON} from "/@aichat/utils.js";
/*#{1HS3MSB070MoreImports*/
import {tabFS} from "/@tabos";
import {TMPCreatePrj} from "../data/AppData.js";
/*}#1HS3MSB070MoreImports*/
const agentURL=(new URL(import.meta.url)).pathname;
const basePath=pathLib.dirname(agentURL);
const $ln=VFACT.lanCode||"EN";
/*#{1HS3MSB070StartDoc*/
const app=VFACT.app;
/*}#1HS3MSB070StartDoc*/
//----------------------------------------------------------------------------
let CreatePrj=async function(session){
	let context,globalContext;
	let self;
	let ShowPrjData,CheckOutPrj,FixCode,OpenPrj;
	/*#{1HS3MSB070LocalVals*/
	/*}#1HS3MSB070LocalVals*/
	
	/*#{1HS3MSB070PreContext*/
	/*}#1HS3MSB070PreContext*/
	globalContext=session.globalContext;
	context={
		"sysPrompt":"","prjName":"","prjData":undefined,"startURL":"",
		/*#{1HS3MSB074ExCtxAttrs*/
		/*}#1HS3MSB074ExCtxAttrs*/
	};
	context=VFACT.flexState(context);
	/*#{1HS3MSB070PostContext*/
	/*}#1HS3MSB070PostContext*/
	let agent,segs={};
	segs["ShowPrjData"]=ShowPrjData=async function(input){//:1HS4RBC9O0
		let result,resultText;
		let role="assistant";
		let md=await import("/@StdUI/ui/AIAskDataBlock.js");
		let func=md.default;
		let text=(($ln==="CN")?("请确认要创建的 AI Agent 的基本信息。然后系统会为你创建这个AI Agent的基础工程。你可以在工程里完善你的 AI Agent，例如：绑定知识库，添加绘图、视图、语音交互等。"):("Please confirm the basic information of the AI Agent you want to create. The system will then create the basic project for this AI Agent. You can enhance your AI Agent in the project, such as binding knowledge base, adding drawing, views, voice interactions, etc."));
		let template="1HS4QQSEP0";
		let data=context.prjData;
		let edit=true;
		let inputVO={template:template,data:data,options:{edit:edit}};
		/*#{1HS4RBC9O0Pre*/
		const varNameRegex = /^[a-zA-Z_$][a-zA-Z0-9_$]*$/;
		inputVO.OnEdit=async function(session,dv,vo){
			let name=vo.name;
			if(!name || !varNameRegex.test(name)){
				dv.showErrorTip("name","Project name error.");
				return 1;
			}
			let entry=await tabFS.getEntry("/"+name);
			if(entry){
				dv.showErrorTip("name","Project path is taken.");
				return 1;
			}
		};
		/*}#1HS4RBC9O0Pre*/
		[resultText,result]=await session.askUserRaw({type:"block",text:text,block:func(session,{}),input:inputVO,role:role});
		/*#{1HS4RBC9O0Codes*/
		context.prjData=result;
		/*}#1HS4RBC9O0Codes*/
		return {seg:CheckOutPrj,result:(result),preSeg:"1HS4RBC9O0",outlet:"1HS4T79P50"};
	};
	ShowPrjData.jaxId="1HS4RBC9O0"
	ShowPrjData.url="ShowPrjData@"+agentURL
	
	segs["CheckOutPrj"]=CheckOutPrj=async function(input){//:1HS3N4BE61
		let result=""
		/*#{1HS3N4BE61Code*/
		let prjData=context.prjData;
		//Show DlgCloud:
		await app.modalDlg("/@homekit/ui/DlgCloud.js",{
			mode:"CreateProject",
			diskId:"prj_ai_helper@avdpro@me.com",
			diskName:prjData.name,
			editPrj:{
				"version": "1.0.0","indent": 4,
				"tabDocs": ["ai/agent.js","ui/MainUI.js","cfg/appCfg.js","app.html","app.js"],
				"liveDocs": ["cfg/appCfg.js","app.html","app.js","ui/MainUI.js","ai/agent.js"]
			},
			callback(vo){
				if(vo){
					context.startURL=vo.startURL;
				}
			}
		});
		/*}#1HS3N4BE61Code*/
		return {seg:FixCode,result:(result),preSeg:"1HS3N4BE61",outlet:"1HS3N4BE62"};
	};
	CheckOutPrj.jaxId="1HS3N4BE61"
	CheckOutPrj.url="CheckOutPrj@"+agentURL
	
	segs["FixCode"]=FixCode=async function(input){//:1HS3N4BE66
		let result=""
		/*#{1HS3N4BE66Code*/
		let code;
		let prjData=context.prjData;
		code=await tabFS.readFile(`/${prjData.name}/ai/agent.js`,"utf8");
		code=code.replaceAll("-SystemPrompt-",prjData.sysPrompt);
		code=code.replaceAll("-Greeting-",prjData.greeting);
		code=code.replaceAll("0.12345",prjData.temperature);
		await tabFS.writeFile(`/${prjData.name}/ai/agent.js`,code,"utf8");
		/*}#1HS3N4BE66Code*/
		return {seg:OpenPrj,result:(result),preSeg:"1HS3N4BE66",outlet:"1HS3N4BE67"};
	};
	FixCode.jaxId="1HS3N4BE66"
	FixCode.url="FixCode@"+agentURL
	
	segs["OpenPrj"]=OpenPrj=async function(input){//:1HS3N4BE68
		let result=""
		/*#{1HS3N4BE68Code*/
		if(context.startURL){
			window.open(context.startURL);
		}
		/*}#1HS3N4BE68Code*/
		return {result:result};
	};
	OpenPrj.jaxId="1HS3N4BE68"
	OpenPrj.url="OpenPrj@"+agentURL
	
	agent={
		isAIAgent:true,
		session:session,
		name:"CreatePrj",
		url:agentURL,
		autoStart:true,
		jaxId:"1HS3MSB070",
		context:context,
		livingSeg:null,
		execChat:async function(input){
			let result;
			/*#{1HS3MSB070PreEntry*/
			context.startURL="";
			context.prjData=TMPCreatePrj.newObject();
			if(input){
				console.log(input);
				if(input.name){
					context.prjData.name=input.name;
				}
				if(input.system){
					context.prjData.sysPrompt=input.system;
				}
				if(input.greeting){
					context.prjData.greeting=input.greeting;
				}
			}
			/*}#1HS3MSB070PreEntry*/
			result={seg:ShowPrjData,"input":input};
			/*#{1HS3MSB070PostEntry*/
			/*}#1HS3MSB070PostEntry*/
			return result;
		},
		/*#{1HS3MSB070MoreAgentAttrs*/
		/*}#1HS3MSB070MoreAgentAttrs*/
	};
	/*#{1HS3MSB070PostAgent*/
	/*}#1HS3MSB070PostAgent*/
	return agent;
};
/*#{1HS3MSB070ExCodes*/
/*}#1HS3MSB070ExCodes*/


export default CreatePrj;
export{CreatePrj};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DocAIAgent",
//	"jaxId": "1HS3MSB070",
//	"attrs": {
//		"editObjs": {
//			"jaxId": "1HS3MSB071",
//			"attrs": {
//				"CreatePrj": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1HS3MSB077",
//					"attrs": {
//						"constructArgs": {
//							"jaxId": "1HS3MSB078",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1HS3MSB079",
//							"attrs": {}
//						},
//						"functions": {
//							"jaxId": "1HS3MSB0710",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false",
//						"exportType": "UI Data Template"
//					},
//					"mockups": {}
//				}
//			}
//		},
//		"agent": {
//			"jaxId": "1HS3MSB072",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "aiseg",
//					"def": "askDataView",
//					"jaxId": "1HS4RBC9O0",
//					"attrs": {
//						"id": "ShowPrjData",
//						"label": "New AI Seg",
//						"x": "130",
//						"y": "140",
//						"context": {
//							"jaxId": "1HS4T7ATH0",
//							"attrs": {}
//						},
//						"global": {
//							"jaxId": "1HS4T7ATH1",
//							"attrs": {}
//						},
//						"desc": "This is an AISeg.",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"outlet": {
//							"jaxId": "1HS4T79P50",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1HS3N4BE61"
//						},
//						"text": {
//							"type": "string",
//							"valText": "Please confirm the basic information of the AI Agent you want to create. The system will then create the basic project for this AI Agent. You can enhance your AI Agent in the project, such as binding knowledge base, adding drawing, views, voice interactions, etc.",
//							"localize": {
//								"EN": "Please confirm the basic information of the AI Agent you want to create. The system will then create the basic project for this AI Agent. You can enhance your AI Agent in the project, such as binding knowledge base, adding drawing, views, voice interactions, etc.",
//								"CN": "请确认要创建的 AI Agent 的基本信息。然后系统会为你创建这个AI Agent的基础工程。你可以在工程里完善你的 AI Agent，例如：绑定知识库，添加绘图、视图、语音交互等。"
//							},
//							"localizable": true
//						},
//						"role": "Assistant",
//						"data": "#context.prjData",
//						"template": "\"1HS4QQSEP0\"",
//						"editData": "true"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1HS3N4BE61",
//					"attrs": {
//						"id": "CheckOutPrj",
//						"label": "New AI Seg",
//						"x": "370",
//						"y": "140",
//						"context": {
//							"jaxId": "1HS3N4BE90",
//							"attrs": {}
//						},
//						"global": {
//							"jaxId": "1HS3N4BE91",
//							"attrs": {}
//						},
//						"desc": "This is an AISeg.",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"outlet": {
//							"jaxId": "1HS3N4BE62",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1HS3N4BE66"
//						},
//						"result": ""
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1HS3N4BE66",
//					"attrs": {
//						"id": "FixCode",
//						"label": "New AI Seg",
//						"x": "600",
//						"y": "140",
//						"context": {
//							"jaxId": "1HS3N4BE96",
//							"attrs": {}
//						},
//						"global": {
//							"jaxId": "1HS3N4BE97",
//							"attrs": {}
//						},
//						"desc": "This is an AISeg.",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"outlet": {
//							"jaxId": "1HS3N4BE67",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1HS3N4BE68"
//						},
//						"result": ""
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1HS3N4BE68",
//					"attrs": {
//						"id": "OpenPrj",
//						"label": "New AI Seg",
//						"x": "810",
//						"y": "140",
//						"context": {
//							"jaxId": "1HS3N4BE98",
//							"attrs": {}
//						},
//						"global": {
//							"jaxId": "1HS3N4BE99",
//							"attrs": {}
//						},
//						"desc": "This is an AISeg.",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"outlet": {
//							"jaxId": "1HS3N4BE69",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							}
//						},
//						"result": ""
//					}
//				}
//			]
//		},
//		"entry": "",
//		"autoStart": "true",
//		"debug": "true",
//		"localVars": {
//			"jaxId": "1HS3MSB073",
//			"attrs": {}
//		},
//		"context": {
//			"jaxId": "1HS3MSB074",
//			"attrs": {
//				"sysPrompt": {
//					"type": "string",
//					"valText": ""
//				},
//				"prjName": {
//					"type": "string",
//					"valText": ""
//				},
//				"prjData": {
//					"type": "auto",
//					"valText": ""
//				},
//				"startURL": {
//					"type": "string",
//					"valText": ""
//				}
//			}
//		},
//		"globalMockup": {
//			"jaxId": "1HS3MSB075",
//			"attrs": {}
//		},
//		"desc": "This is an AI agent.",
//		"exportAPI": "false",
//		"apiArgs": {
//			"jaxId": "1HS3MSB076",
//			"attrs": {}
//		}
//	}
//}