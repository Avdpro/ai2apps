import {esprima} from "/@tabos/utils/esprima.mjs";

//----------------------------------------------------------------------------
function briefCode(fullCode,lite=false){
	let ast,nodes,node,i,n;
	let funcNodes=[];
	let globalNames=new Set();
	
	function compressFunction(node){
		let bodyNode;
		bodyNode=node.body;
		fullCode=fullCode.substring(0,bodyNode.range[0])+"{/*TBD*/}"+fullCode.substring(bodyNode.range[1]);
	};
	
	function removeNode(node){
		fullCode=fullCode.substring(0,node.range[0])+"\n\n"+fullCode.substring(node.range[1]);
	}
	
	function getLineNum(node){
		let range,i,n,lines;
		range=node.range;
		lines=0;
		n=range[1];
		for(i=range[0];i<n;i++){
			if(fullCode[i]==="\n"){
				lines++;
			}
		}
		return lines;
	};
	
	
	try{
		ast=esprima.parse(fullCode,{range:true});
	}catch(err){
		try{
			ast=esprima.parseModule(fullCode,{range:true});
		}catch(err){
			return fullCode;
		}
	}
	nodes=ast.body;
	n=nodes.length;
	//Mark all un-inited global names
	for(i=0;i<n;i++){
		node=nodes[i];
		console.log("Node: "+node.type);
		console.log(node);
		if(node.type==="VariableDeclaration"){
			let list,subNode,leftNode,rightNode;
			list=node.declarations;
			for(subNode of list){
				if(!subNode.init && subNode.id.type==="Identifier"){
					globalNames.add(subNode.id.name);
				}
			}
		}
	}
	
	for(i=n-1;i>=0;i--){
		node=nodes[i];
		if(node.type==="VariableDeclaration"){
			let list,subNode,leftNode,rightNode;
			list=node.declarations;
			for(subNode of list){
				if(subNode.init && subNode.init.type==="FunctionExpression"){
					if(!lite || getLineNum(subNode)>=8){
						compressFunction(subNode.init);
					}
				}
			}
		}else if(node.type==="ExpressionStatement" && node.expression.type=== "AssignmentExpression" && 
				 node.expression.left.type==="Identifier" && node.expression.right.type==="FunctionExpression"){
			let name=node.expression.left.name;
			if(globalNames.has(name)){
				if(!lite || getLineNum(node)>=8){
					compressFunction(node.expression.right);
				}
			}
		}else if(node.type==="FunctionDeclaration"){
			if(!lite || getLineNum(node)>=8){
				compressFunction(node);
			}
		}else if(node.type==="ExportNamedDeclaration"){
			removeNode(node);//Remove
		}else{
			if(getLineNum(node)>2){
				removeNode(node);
			}
		}
	}
	console.log("Briefed Code:");
	console.log(fullCode);
	return fullCode;
}

export default briefCode;
export {briefCode};