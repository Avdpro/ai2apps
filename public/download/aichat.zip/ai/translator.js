//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import pathLib from "/@path";
import inherits from "/@inherits";
import Base64 from "/@tabos/utils/base64.js";
import {trimJSON} from "/@aichat/utils.js";
/*#{1HDP0G4P60MoreImports*/
/*}#1HDP0G4P60MoreImports*/
const agentURL=(new URL(import.meta.url)).pathname;
const basePath=pathLib.dirname(agentURL);
const $ln=VFACT.lanCode||"EN";
/*#{1HDP0G4P60StartDoc*/
/*}#1HDP0G4P60StartDoc*/
//----------------------------------------------------------------------------
let translator=async function(session){
	let execInput;
	const $ln=session.language||"EN";
	let context,globalContext=session.globalContext;
	let self;
	let Start,ChooseLan,ShowLan,WaitChat,CheckInput,CallAI,ShowResult;
	/*#{1HDP0G4P60LocalVals*/
	/*}#1HDP0G4P60LocalVals*/
	
	function parseAgentArgs(input){
		execInput=input;
		/*#{1HDP0G4P60ParseArgs*/
		/*}#1HDP0G4P60ParseArgs*/
	}
	
	/*#{1HDP0G4P60PreContext*/
	/*}#1HDP0G4P60PreContext*/
	context={
		"tgtLan":"Chinese",
		/*#{1HDP0G4P64ExCtxAttrs*/
		/*}#1HDP0G4P64ExCtxAttrs*/
	};
	context=VFACT.flexState(context);
	/*#{1HDP0G4P60PostContext*/
	/*}#1HDP0G4P60PostContext*/
	let agent,segs={};
	segs["Start"]=Start=async function(input){//:1HDP0T0UT0
		let result=input;
		let role="assistant";
		let content=(($ln==="CN")?("这是一个用来演示交互功能的翻译 Agent。在启动后，Agent 会先询问用户翻译的目标语言。然后每轮对话把用户输入的文本翻译成用户选择的语言。如果用户输入 “rest” 则重新询问用户目标语言。"):("This is a translation Agent for demonstrating interactive functionality. Upon launch, the Agent will first ask the user for the target language of translation. Then, in each conversation round, it will translate the user's input text into the selected language. If the user inputs 'rest', it will ask the user for the target language again."));
		session.addChatText(role,content);
		return {seg:ChooseLan,result:(result),preSeg:"1HDP0T0UT0",outlet:"1HDP0T0UT1"};
	};
	Start.jaxId="1HDP0T0UT0"
	Start.url="Start@"+agentURL
	
	segs["ChooseLan"]=ChooseLan=async function(input){//:1HDP0T0UU0
		let prompt=((($ln==="CN")?("请选择翻译的目标语言"):("Please select the target language")))||input;
		let countdown=undefined;
		let placeholder=(undefined)||null;
		let silent=false;
		let items=[
			{icon:"/~/-tabos/shared/assets/dot.svg",text:"中文",code:0},
			{icon:"/~/-tabos/shared/assets/dot.svg",text:"English",code:1},
			{icon:"/~/-tabos/shared/assets/dot.svg",text:"日本语",code:2},
		];
		let result="";
		let item=null;
		
		if(silent){
			result="";
			/*#{1HDUHR54S0Silent*/
			/*}#1HDUHR54S0Silent*/
			return {seg:ShowLan,result:(result),preSeg:"1HDP0T0UU0",outlet:"1HDUHR54S0"};
		}
		[result,item]=await session.askUserRaw({type:"menu",prompt:prompt,multiSelect:false,items:items,withChat:false,countdown:countdown,placeholder:placeholder});
		if(typeof(item)==='string'){
			result=item;
			return {result:result};
		}else if(item.code===0){
			/*#{1HDUHR54S0*/
			context.tgtLan="Chinese";
			/*}#1HDUHR54S0*/
			return {seg:ShowLan,result:(result),preSeg:"1HDP0T0UU0",outlet:"1HDUHR54S0"};
		}else if(item.code===1){
			/*#{1HDUHR54S1*/
			context.tgtLan="English";
			/*}#1HDUHR54S1*/
			return {seg:ShowLan,result:(result),preSeg:"1HDP0T0UU0",outlet:"1HDUHR54S1"};
		}else if(item.code===2){
			/*#{1HDUHR54S2*/
			context.tgtLan="Japanese";
			/*}#1HDUHR54S2*/
			return {seg:ShowLan,result:(result),preSeg:"1HDP0T0UU0",outlet:"1HDUHR54S2"};
		}
		return {result:result};
	};
	ChooseLan.jaxId="1HDP0T0UU0"
	ChooseLan.url="ChooseLan@"+agentURL
	
	segs["ShowLan"]=ShowLan=async function(input){//:1HDP0T0UU1
		let result=input;
		let role="event";
		let content=(($ln==="CN")?(`选择的目标语言：${input}。`):(`Selected target language: ${input}.`));
		session.addChatText(role,content);
		return {seg:WaitChat,result:(result),preSeg:"1HDP0T0UU1",outlet:"1HDP0T0UU2"};
	};
	ShowLan.jaxId="1HDP0T0UU1"
	ShowLan.url="ShowLan@"+agentURL
	
	segs["WaitChat"]=WaitChat=async function(input){//:1HDP0T0UU3
		let tip=("");
		let tipRole=("assistant");
		let placeholder=("");
		let text=("");
		let result="";
		if(tip){
			session.addChatText(tipRole,tip);
		}
		result=await session.askChatInput({type:"input",placeholder:placeholder,text:text});
		session.addChatText("user",result);
		return {seg:CheckInput,result:(result),preSeg:"1HDP0T0UU3",outlet:"1HDP0T0UU4"};
	};
	WaitChat.jaxId="1HDP0T0UU3"
	WaitChat.url="WaitChat@"+agentURL
	
	segs["CheckInput"]=CheckInput=async function(input){//:1HDP0T0UU5
		let result=input;
		if(input==="reset"){
			return {seg:ChooseLan,result:(input),preSeg:"1HDP0T0UU5",outlet:"1HDP0T0UU6"};
		}
		return {seg:CallAI,result:(result),preSeg:"1HDP0T0UU5",outlet:"1HDP0T0UU7"};
	};
	CheckInput.jaxId="1HDP0T0UU5"
	CheckInput.url="CheckInput@"+agentURL
	
	segs["CallAI"]=CallAI=async function(input){//:1HDP0T0UU8
		let prompt;
		let result=null;
		/*#{1HDP0T0UU8Input*/
		input=`Translate following text into ${context.tgtLan}: \n${input}`;
		/*}#1HDP0T0UU8Input*/
		
		let opts={
			platform:"OpenAI",
			mode:"gpt-3.5-turbo",
			maxToken:2000,
			temperature:0,
			topP:1,
			fqcP:0,
			prcP:0,
			secret:false,
			responseFormat:"text"
		};
		let chatMem=CallAI.messages
		let seed="";
		if(seed!==undefined){opts.seed=seed;}
		let messages=[
			{role:"system",content:`You are a translator. You translate text into ${context.tgtLan}. If text is already ${context.tgtLan}, keep the same.`},
		];
		/*#{1HDP0T0UU8PrePrompt*/
		/*}#1HDP0T0UU8PrePrompt*/
		prompt=input;
		if(prompt!==null){
			if(typeof(prompt)!=="string"){
				prompt=JSON.stringify(prompt,null,"	");
			}
			messages.push({role:"user",content:prompt});
		}
		/*#{1HDP0T0UU8PreCall*/
		/*}#1HDP0T0UU8PreCall*/
		result=(result===null)?(await session.callSegLLM("CallAI@"+agentURL,opts,messages,true)):result;
		/*#{1HDP0T0UU8PostCall*/
		/*}#1HDP0T0UU8PostCall*/
		return {seg:ShowResult,result:(result),preSeg:"1HDP0T0UU8",outlet:"1HDP0T0UU9"};
	};
	CallAI.jaxId="1HDP0T0UU8"
	CallAI.url="CallAI@"+agentURL
	
	segs["ShowResult"]=ShowResult=async function(input){//:1HDP0T0UU10
		let result=input;
		let role="assistant";
		let content=input;
		session.addChatText(role,content);
		return {seg:WaitChat,result:(result),preSeg:"1HDP0T0UU10",outlet:"1HDP0T0UU11"};
	};
	ShowResult.jaxId="1HDP0T0UU10"
	ShowResult.url="ShowResult@"+agentURL
	
	agent={
		isAIAgent:true,
		session:session,
		name:"translator",
		url:agentURL,
		autoStart:true,
		jaxId:"1HDP0G4P60",
		context:context,
		livingSeg:null,
		execChat:async function(input){
			let result;
			parseAgentArgs(input);
			/*#{1HDP0G4P60PreEntry*/
			/*}#1HDP0G4P60PreEntry*/
			result={seg:Start,"input":input};
			/*#{1HDP0G4P60PostEntry*/
			/*}#1HDP0G4P60PostEntry*/
			return result;
		},
		/*#{1HDP0G4P60MoreAgentAttrs*/
		/*}#1HDP0G4P60MoreAgentAttrs*/
	};
	/*#{1HDP0G4P60PostAgent*/
	/*}#1HDP0G4P60PostAgent*/
	return agent;
};
/*#{1HDP0G4P60ExCodes*/
/*}#1HDP0G4P60ExCodes*/

//#CodyExport>>>
//#CodyExport<<<
/*#{1HDP0G4P60PostDoc*/
/*}#1HDP0G4P60PostDoc*/


export default translator;
export{translator};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DocAIAgent",
//	"jaxId": "1HDP0G4P60",
//	"attrs": {
//		"editObjs": {
//			"jaxId": "1HDP0G4P61",
//			"attrs": {
//				"translator": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1HDP0G4P80",
//					"attrs": {
//						"constructArgs": {
//							"jaxId": "1HDP0G4P90",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1HDP0G4P91",
//							"attrs": {}
//						},
//						"functions": {
//							"jaxId": "1HDP0G4P92",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false",
//						"exportType": "UI Data Template",
//						"exportClass": "false"
//					},
//					"mockups": {}
//				}
//			}
//		},
//		"agent": {
//			"jaxId": "1HDP0G4P62",
//			"attrs": {}
//		},
//		"entry": "",
//		"autoStart": "true",
//		"inBrowser": "true",
//		"debug": "true",
//		"apiArgs": {
//			"jaxId": "1IIUR58OJ0",
//			"attrs": {}
//		},
//		"localVars": {
//			"jaxId": "1HDP0G4P63",
//			"attrs": {}
//		},
//		"context": {
//			"jaxId": "1HDP0G4P64",
//			"attrs": {
//				"tgtLan": {
//					"type": "string",
//					"valText": "Chinese"
//				}
//			}
//		},
//		"globalMockup": {
//			"jaxId": "1HDP0G4P65",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1HDP0T0UT0",
//					"attrs": {
//						"id": "Start",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "50",
//						"y": "340",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1HDP0T0UV0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1HDP0T0UV1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "Assistant",
//						"text": {
//							"type": "string",
//							"valText": "This is a translation Agent for demonstrating interactive functionality. Upon launch, the Agent will first ask the user for the target language of translation. Then, in each conversation round, it will translate the user's input text into the selected language. If the user inputs 'rest', it will ask the user for the target language again.",
//							"localize": {
//								"EN": "This is a translation Agent for demonstrating interactive functionality. Upon launch, the Agent will first ask the user for the target language of translation. Then, in each conversation round, it will translate the user's input text into the selected language. If the user inputs 'rest', it will ask the user for the target language again.",
//								"CN": "这是一个用来演示交互功能的翻译 Agent。在启动后，Agent 会先询问用户翻译的目标语言。然后每轮对话把用户输入的文本翻译成用户选择的语言。如果用户输入 “rest” 则重新询问用户目标语言。"
//							},
//							"localizable": true
//						},
//						"outlet": {
//							"jaxId": "1HDP0T0UT1",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。",
//								"showLine": {
//									"valText": "true"
//								}
//							},
//							"linkedSeg": "1HDP0T0UU0"
//						}
//					},
//					"icon": "hudtxt.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "askMenu",
//					"jaxId": "1HDP0T0UU0",
//					"attrs": {
//						"id": "ChooseLan",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "240",
//						"y": "340",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"prompt": {
//							"type": "string",
//							"valText": "Please select the target language",
//							"localize": {
//								"EN": "Please select the target language",
//								"CN": "请选择翻译的目标语言"
//							},
//							"localizable": true
//						},
//						"multi": "false",
//						"withChat": "false",
//						"outlet": {
//							"jaxId": "1IIUR58OG0",
//							"attrs": {
//								"id": "ChatInput",
//								"desc": "输出节点。",
//								"codes": "false"
//							}
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1HDUHR54S0",
//									"attrs": {
//										"id": "CN",
//										"desc": "输出节点。",
//										"text": "中文",
//										"result": "",
//										"codes": "true",
//										"context": {
//											"jaxId": "1IIUR58OJ1",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1IIUR58OJ2",
//											"attrs": {
//												"cast": ""
//											}
//										}
//									},
//									"linkedSeg": "1HDP0T0UU1"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1HDUHR54S1",
//									"attrs": {
//										"id": "EN",
//										"desc": "输出节点。",
//										"text": "English",
//										"result": "",
//										"codes": "true",
//										"context": {
//											"jaxId": "1IIUR58OJ3",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1IIUR58OJ4",
//											"attrs": {
//												"cast": ""
//											}
//										}
//									},
//									"linkedSeg": "1HDP0T0UU1"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1HDUHR54S2",
//									"attrs": {
//										"id": "JP",
//										"desc": "输出节点。",
//										"text": "日本语",
//										"result": "",
//										"codes": "true",
//										"context": {
//											"jaxId": "1IIUR58OJ5",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1IIUR58OJ6",
//											"attrs": {
//												"cast": ""
//											}
//										}
//									},
//									"linkedSeg": "1HDP0T0UU1"
//								}
//							]
//						},
//						"silent": "false",
//						"context": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HDP0T0UV2",
//							"attrs": {}
//						},
//						"global": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HDP0T0UV3",
//							"attrs": {}
//						}
//					},
//					"icon": "menu.svg",
//					"reverseOutlets": true
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1HDP0T0UU1",
//					"attrs": {
//						"id": "ShowLan",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "485",
//						"y": "325",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1HDP0T0UV4",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1HDP0T0UV5",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "Event",
//						"text": {
//							"type": "string",
//							"valText": "#`Selected target language: ${input}.`",
//							"localize": {
//								"EN": "#`Selected target language: ${input}.`",
//								"CN": "#`选择的目标语言：${input}。`"
//							},
//							"localizable": true
//						},
//						"outlet": {
//							"jaxId": "1HDP0T0UU2",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。",
//								"showLine": {
//									"valText": "true"
//								}
//							},
//							"linkedSeg": "1HDP0T0UU3"
//						}
//					},
//					"icon": "hudtxt.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "askChat",
//					"jaxId": "1HDP0T0UU3",
//					"attrs": {
//						"id": "WaitChat",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "700",
//						"y": "325",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1HDP0T0UV6",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1HDP0T0UV7",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"tip": "",
//						"tipRole": "Assistant",
//						"placeholder": "",
//						"text": "",
//						"file": "false",
//						"showText": "true",
//						"outlet": {
//							"jaxId": "1HDP0T0UU4",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。",
//								"showLine": {
//									"valText": "true"
//								}
//							},
//							"linkedSeg": "1HDP0T0UU5"
//						},
//						"prompt": "Please input"
//					},
//					"icon": "chat.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "brunch",
//					"jaxId": "1HDP0T0UU5",
//					"attrs": {
//						"id": "CheckInput",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "945",
//						"y": "325",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1HDP0T0UV8",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1HDP0T0UV9",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1HDP0T0UU7",
//							"attrs": {
//								"id": "Default",
//								"desc": "输出节点。",
//								"output": "",
//								"showLine": {
//									"valText": "true"
//								}
//							},
//							"linkedSeg": "1HDP0T0UU8"
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1HDP0T0UU6",
//									"attrs": {
//										"id": "reset",
//										"desc": "条件输出节点。",
//										"output": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1IIUR58OJ7",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1IIUR58OJ8",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "",
//										"ouput": {
//											"valText": ""
//										}
//									},
//									"linkedSeg": "1HDP0T0UV10"
//								}
//							]
//						}
//					},
//					"icon": "condition.svg",
//					"reverseOutlets": true
//				},
//				{
//					"type": "aiseg",
//					"def": "callLLM",
//					"jaxId": "1HDP0T0UU8",
//					"attrs": {
//						"id": "CallAI",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "1185",
//						"y": "340",
//						"desc": "执行一次LLM调用。",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1HDP0T0UV11",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1HDP0T0UV12",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"platform": "\"OpenAI\"",
//						"mode": "GPT-3.5",
//						"system": "#`You are a translator. You translate text into ${context.tgtLan}. If text is already ${context.tgtLan}, keep the same.`",
//						"temperature": "0",
//						"maxToken": "2000",
//						"topP": "1",
//						"fqcP": "0",
//						"prcP": "0",
//						"messages": {
//							"attrs": []
//						},
//						"prompt": "#input",
//						"seed": "",
//						"outlet": {
//							"jaxId": "1HDP0T0UU9",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。",
//								"showLine": {
//									"valText": "true"
//								}
//							},
//							"linkedSeg": "1HDP0T0UU10"
//						},
//						"secret": "false",
//						"allowCheat": "false",
//						"GPTCheats": {
//							"attrs": []
//						},
//						"shareChatName": "",
//						"keepChat": "No",
//						"clearChat": "2",
//						"apiFiles": {
//							"attrs": []
//						},
//						"parallelFunction": "false",
//						"responseFormat": "text",
//						"formatDef": "\"\""
//					},
//					"icon": "llm.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1HDP0T0UU10",
//					"attrs": {
//						"id": "ShowResult",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "1410",
//						"y": "340",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1HDP0T0UV13",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1HDP0T0UV14",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "Assistant",
//						"text": "#input",
//						"outlet": {
//							"jaxId": "1HDP0T0UU11",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。",
//								"showLine": {
//									"valText": "true"
//								}
//							},
//							"linkedSeg": "1HDP0T0UV15"
//						}
//					},
//					"icon": "hudtxt.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1HDP0T0UV10",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "1100",
//						"y": "225",
//						"outlet": {
//							"jaxId": "1HDP0T0UV16",
//							"attrs": {
//								"id": "Summary",
//								"desc": "输出节点。",
//								"showLine": {
//									"valText": "true"
//								}
//							},
//							"linkedSeg": "1HDP0T0UV17"
//						},
//						"dir": "R2L"
//					},
//					"icon": "arrowright.svg",
//					"isConnector": true
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1HDP0T0UV17",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "275",
//						"y": "225",
//						"outlet": {
//							"jaxId": "1HDP0T0UV18",
//							"attrs": {
//								"id": "Summary",
//								"desc": "输出节点。",
//								"showLine": {
//									"valText": "true"
//								}
//							},
//							"linkedSeg": "1HDP0T0UU0"
//						},
//						"dir": "R2L"
//					},
//					"icon": "arrowright.svg",
//					"isConnector": true
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1HDP0T0UV15",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "1565",
//						"y": "430",
//						"outlet": {
//							"jaxId": "1HDP0T0UV19",
//							"attrs": {
//								"id": "Summary",
//								"desc": "输出节点。",
//								"showLine": {
//									"valText": "true"
//								}
//							},
//							"linkedSeg": "1HDP0T0UV20"
//						},
//						"dir": "R2L"
//					},
//					"icon": "arrowright.svg",
//					"isConnector": true
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1HDP0T0UV20",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "725",
//						"y": "430",
//						"outlet": {
//							"jaxId": "1HDP0T0UV21",
//							"attrs": {
//								"id": "Summary",
//								"desc": "输出节点。",
//								"showLine": {
//									"valText": "true"
//								}
//							},
//							"linkedSeg": "1HDP0T0UU3"
//						},
//						"dir": "R2L"
//					},
//					"icon": "arrowright.svg",
//					"isConnector": true
//				}
//			]
//		},
//		"desc": "这是一个AI代理。",
//		"exportAPI": "false",
//		"exportAddOn": "false",
//		"addOnOpts": ""
//	}
//}