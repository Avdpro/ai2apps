//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import pathLib from "/@path";
import inherits from "/@inherits";
import Base64 from "/@tabos/utils/base64.js";
import {trimJSON} from "/@aichat/utils.js";
/*#{1JDRUCKEB0MoreImports*/
/*}#1JDRUCKEB0MoreImports*/
const agentURL=(new URL(import.meta.url)).pathname;
const baseURL=pathLib.dirname(agentURL);
const basePath=baseURL.startsWith("file://")?decodeURI(baseURL):baseURL;
const $ln=VFACT.lanCode||"EN";
/*#{1JDRUCKEB0StartDoc*/
/*}#1JDRUCKEB0StartDoc*/
//----------------------------------------------------------------------------
let CaChat_GPT_5=async function(session){
	let execInput;
	const $ln=session.language||"EN";
	let context,globalContext=session.globalContext;
	let self;
	let SEG1JDRUACAR0;
	/*#{1JDRUCKEB0LocalVals*/
	/*}#1JDRUCKEB0LocalVals*/
	
	function parseAgentArgs(input){
		execInput=input;
		/*#{1JDRUCKEB0ParseArgs*/
		/*}#1JDRUCKEB0ParseArgs*/
	}
	
	/*#{1JDRUCKEB0PreContext*/
	/*}#1JDRUCKEB0PreContext*/
	context={};
	context=VFACT.flexState(context);
	/*#{1JDRUCKEB0PostContext*/
	/*}#1JDRUCKEB0PostContext*/
	let $agent,agent,segs={};
	segs["SEG1JDRUACAR0"]=SEG1JDRUACAR0=async function(input){//:1JDRUACAR0
		let prompt;
		let $platform="OpenAI";
		let $model="gpt-5";
		let $agent;
		let result;
		
		let opts={
			platform:$platform,
			mode:$model,
			maxToken:2000,
			temperature:0,
			topP:1,
			fqcP:0,
			prcP:0,
			secret:false,
			responseFormat:"text"
		};
		let chatMem=SEG1JDRUACAR0.messages
		let seed="";
		if(seed!==undefined){opts.seed=seed;}
		let messages=[
			{role:"system",content:"You are a smart assistant."},
		];
		prompt=input;
		if(prompt!==null){
			if(typeof(prompt)!=="string"){
				prompt=JSON.stringify(prompt,null,"	");
			}
			let msg={role:"user",content:prompt};messages.push(msg);
		}
		if($agent){
			result=await session.callAgent($agent.agentNode,$agent.path,{messages:messages,maxToken:opts.maxToken,responseFormat:opts.responseFormat});
		}else{
			result=await session.callSegLLM("SEG1JDRUACAR0@"+agentURL,opts,messages,true);
		}
		return {result:result};
	};
	SEG1JDRUACAR0.jaxId="1JDRUACAR0"
	SEG1JDRUACAR0.url="SEG1JDRUACAR0@"+agentURL
	
	agent=$agent={
		isAIAgent:true,
		session:session,
		name:"CaChat_GPT_5",
		url:agentURL,
		autoStart:true,
		jaxId:"1JDRUCKEB0",
		context:context,
		livingSeg:null,
		execChat:async function(input){
			let result;
			parseAgentArgs(input);
			/*#{1JDRUCKEB0PreEntry*/
			/*}#1JDRUCKEB0PreEntry*/
			result={seg:SEG1JDRUACAR0,"input":input};
			/*#{1JDRUCKEB0PostEntry*/
			/*}#1JDRUCKEB0PostEntry*/
			return result;
		},
		/*#{1JDRUCKEB0MoreAgentAttrs*/
		/*}#1JDRUCKEB0MoreAgentAttrs*/
	};
	/*#{1JDRUCKEB0PostAgent*/
	/*}#1JDRUCKEB0PostAgent*/
	return agent;
};
/*#{1JDRUCKEB0ExCodes*/
/*}#1JDRUCKEB0ExCodes*/

//#CodyExport>>>
export const ChatAPI=[{
	def:{
		name: "CaChat_GPT_5",
		description: "这是一个AI智能体。",
		parameters:{
			type: "object",
			properties:{
			}
		}
	},
	isChatApi: true,
	kind: "chat",
	capabilities: ["streaming","tool.call","tool.parallel","output.json","output.jsonSchema","output.markdown","vision.input","longContext","code:7.5","planning:6.75"],
	filters: [{"key":"platform","value":"OpenAI"},{"key":"model","value":"gpt-5"}],
	metrics: {"quality":6.5,"costPerCall":0,"costPer1M":1.25,"speed":4,"size":0},
	meta: {"platform":"OpenAI","model":"gpt-5"},
	agent: CaChat_GPT_5
}];
//#CodyExport<<<
/*#{1JDRUCKEB0PostDoc*/
/*}#1JDRUCKEB0PostDoc*/


export default CaChat_GPT_5;
export{CaChat_GPT_5};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DocAIAgent",
//	"jaxId": "1JDRUCKEB0",
//	"attrs": {
//		"editObjs": {
//			"jaxId": "1JDRU0P5V1",
//			"attrs": {
//				"CaChat_GPT_5.js": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1JDRU0P604",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1JDRU0P605",
//							"attrs": {}
//						},
//						"properties": {
//							"jaxId": "1JDRU0P606",
//							"attrs": {}
//						},
//						"functions": {
//							"jaxId": "1JDRU0P607",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false",
//						"exportClass": "false",
//						"superClass": ""
//					},
//					"mockups": {}
//				}
//			}
//		},
//		"agent": {
//			"jaxId": "1JDRU0P5V2",
//			"attrs": {}
//		},
//		"showName": "",
//		"entry": "",
//		"autoStart": "true",
//		"inBrowser": "true",
//		"debug": "true",
//		"apiArgs": {
//			"jaxId": "1JDRU0P600",
//			"attrs": {}
//		},
//		"localVars": {
//			"jaxId": "1JDRU0P601",
//			"attrs": {}
//		},
//		"context": {
//			"jaxId": "1JDRU0P602",
//			"attrs": {}
//		},
//		"globalMockup": {
//			"jaxId": "1JDRU0P603",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "aiseg",
//					"def": "callLLM",
//					"jaxId": "1JDRUACAR0",
//					"attrs": {
//						"id": "",
//						"viewName": "",
//						"label": "",
//						"x": "195",
//						"y": "165",
//						"desc": "执行一次LLM调用。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1JDRUBCC70",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1JDRUBCC71",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"platform": "\"OpenAI\"",
//						"mode": "gpt-5",
//						"system": "You are a smart assistant.",
//						"temperature": "0",
//						"maxToken": "2000",
//						"topP": "1",
//						"fqcP": "0",
//						"prcP": "0",
//						"messages": {
//							"attrs": []
//						},
//						"prompt": "#input",
//						"seed": "",
//						"outlet": {
//							"jaxId": "1JDRUBCC40",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							}
//						},
//						"stream": "true",
//						"secret": "false",
//						"allowCheat": "false",
//						"GPTCheats": {
//							"attrs": []
//						},
//						"shareChatName": "",
//						"keepChat": "No",
//						"clearChat": "2",
//						"apiFiles": {
//							"attrs": []
//						},
//						"parallelFunction": "false",
//						"responseFormat": "text",
//						"formatDef": "\"\"",
//						"outlets": {
//							"attrs": []
//						}
//					},
//					"icon": "llm.svg",
//					"reverseOutlets": true
//				}
//			]
//		},
//		"desc": "这是一个AI智能体。",
//		"exportAPI": "true",
//		"exportAddOn": "false",
//		"addOnOpts": "{\"name\":\"\",\"label\":\"\",\"path\":\"\",\"pathInHub\":\"\",\"chatEntry\":false,\"isChatApi\":1,\"isRPA\":0,\"rpaHost\":\"\",\"segIcon\":\"\",\"catalog\":\"AI Call\",\"kind\":\"chat\",\"capabilities\":[\"streaming\",\"tool.call\",\"tool.parallel\",\"output.json\",\"output.jsonSchema\",\"output.markdown\",\"vision.input\",\"longContext\",\"code:7.5\",\"planning:6.75\"],\"filters\":[{\"key\":\"platform\",\"value\":\"OpenAI\"},{\"key\":\"model\",\"value\":\"gpt-5\"}],\"metrics\":{\"quality\":6.5,\"costPerCall\":0,\"costPer1M\":1.25,\"speed\":4,\"size\":0},\"meta\":{\"platform\":\"OpenAI\",\"model\":\"gpt-5\"}}"
//	}
//}