//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import pathLib from "/@path";
import inherits from "/@inherits";
import Base64 from "/@tabos/utils/base64.js";
import {trimJSON} from "/@aichat/utils.js";
/*#{1ITG3B57V0MoreImports*/
import {tabNT} from "/@tabos";
/*}#1ITG3B57V0MoreImports*/
const agentURL=(new URL(import.meta.url)).pathname;
const basePath=pathLib.dirname(agentURL);
const $ln=VFACT.lanCode||"EN";
const argsTemplate={
	properties:{
		"purchases":{
			"name":"purchases","type":"auto",
			"defaultValue":"",
			"desc":"",
		}
	},
	/*#{1ITG3B57V0ArgsView*/
	/*}#1ITG3B57V0ArgsView*/
};

/*#{1ITG3B57V0StartDoc*/
/*}#1ITG3B57V0StartDoc*/
//----------------------------------------------------------------------------
let CheckPurchase=async function(session){
	let purchases;
	const $ln=session.language||"EN";
	let context,globalContext=session.globalContext;
	let self;
	let CheckPurchase,IsChecked,Finish,Ask,Abort,Looper,AskItem,FreeTrialItem,PurchaseItem,AbortPurchase,AskDays,EnoughToken,AskCharge,JumpFreeTrial,JumpAbortPurchase,ChargeTokens,JumpEoughToken,PurchaseDone,JumpAskItem,JumpStart,CheckAbort,Abort2,CheckTrialResult,AskRetryTrial,Retry,AbortTrial,AskRetryPurchase,AbortPurchase2,TipTrialOK,TipPurchaseOK,JumpBack,JumpCharge;
	let checkResult=undefined;
	let loopAborted=false;
	let loopItem=null;
	let userTokens=0;
	
	/*#{1ITG3B57V0LocalVals*/
	let app=VFACT.app;
	/*}#1ITG3B57V0LocalVals*/
	
	function parseAgentArgs(input){
		if(typeof(input)=='object'){
			purchases=input.purchases;
		}else{
			purchases=undefined;
		}
		/*#{1ITG3B57V0ParseArgs*/
		if(!Array.isArray(purchases)){
			purchases=[purchases];
		}
		/*}#1ITG3B57V0ParseArgs*/
	}
	
	/*#{1ITG3B57V0PreContext*/
	/*}#1ITG3B57V0PreContext*/
	context={};
	context=VFACT.flexState(context);
	/*#{1ITG3B57V0PostContext*/
	/*}#1ITG3B57V0PostContext*/
	let $agent,agent,segs={};
	segs["CheckPurchase"]=CheckPurchase=async function(input){//:1ITG3C4LM0
		let result=input
		/*#{1ITG3C4LM0Code*/
		let res;
		await tabNT.checkLogin(true);
		res=await tabNT.makeCall("SubSrvCheck",{check:purchases});
		if(res.code!=200){
			if(res.info){
				throw Error(`Check purchase error ${res.code}: ${res.info}`);
			}else{
				throw Error(`Check purchase error: ${res.code}`);
			}
		}
		checkResult=res;
		result=res;
		/*}#1ITG3C4LM0Code*/
		return {seg:IsChecked,result:(result),preSeg:"1ITG3C4LM0",outlet:"1ITG44TCI0"};
	};
	CheckPurchase.jaxId="1ITG3C4LM0"
	CheckPurchase.url="CheckPurchase@"+agentURL
	
	segs["IsChecked"]=IsChecked=async function(input){//:1ITG3CIV30
		let result=input;
		if(!!input.check){
			return {seg:Finish,result:(input),preSeg:"1ITG3CIV30",outlet:"1ITG44TCI1"};
		}
		return {seg:Ask,result:(result),preSeg:"1ITG3CIV30",outlet:"1ITG44TCI2"};
	};
	IsChecked.jaxId="1ITG3CIV30"
	IsChecked.url="IsChecked@"+agentURL
	
	segs["Finish"]=Finish=async function(input){//:1ITG3FMQS0
		let result=input
		/*#{1ITG3FMQS0Code*/
		result={'result':"Checked",'info':"Purchase(s) are all checked"};
		/*}#1ITG3FMQS0Code*/
		return {result:result};
	};
	Finish.jaxId="1ITG3FMQS0"
	Finish.url="Finish@"+agentURL
	
	segs["Ask"]=Ask=async function(input){//:1ITG3MUPL0
		let prompt=("Please confirm")||input;
		let countdown=undefined;
		let placeholder=(undefined)||null;
		let withChat=false;
		let silent=false;
		let items=[
			{emoji:"🚀",text:(($ln==="CN")?("购买或试用缺失的服务"):("Purchase or free-trial missing service(s)")),code:0},
			{emoji:"❌",text:(($ln==="CN")?("放弃"):("Abort")),code:1},
		];
		let result="";
		let item=null;
		
		/*#{1ITG3MUPL0PreCodes*/
		let missingList,sub,canFreeTrial,freeTrial,minPrice,totalPrice;
		missingList=checkResult.missing;
		minPrice=0;
		totalPrice=0;
		freeTrial=0;
		canFreeTrial=true;
		for(sub of missingList){
			if(sub.freeTrial>0){
				freeTrial+=1;
			}else{
				canFreeTrial=false;
				minPrice+=sub.price;
			}
		}
		if($ln==="CN"){
			if(canFreeTrial){
				prompt=`缺少${missingList.length}个必须的订阅项目，你可以免费试用这些付费项目，是否继续？`;
			}else{
				if(freeTrial>0){
					prompt=`缺少${missingList.length}个必须的订阅项目，你可以免费其中的${freeTrial}个项目，另外的项目需要至少${minPrice}代币订阅，是否继续？`;
				}else{
					prompt=`缺少${missingList.length}个必须的订阅项目，一共需要至少${minPrice}代币订阅，是否继续？`;
				}
			}
		}else{
			if(canFreeTrial){
				prompt=`Missing ${missingList.length} ISP item(s)，you can take a free-trial.`;
			}else{
				if(freeTrial>0){
					prompt=`Missing ${missingList.length} ISP item(s), you can free-trial ${freeTrial} item(s)，others need at least ${minPrice} tokens to subscribe.`;
				}else{
					prompt=`Missing ${missingList.length} ISP item(s), you need ast least ${minPrice} token to subscribe.`;
				}
			}
		}
		/*}#1ITG3MUPL0PreCodes*/
		if(silent){
			result="";
			return {seg:Looper,result:(result),preSeg:"1ITG3MUPL0",outlet:"1ITG3MUP10"};
		}
		[result,item]=await session.askUserRaw({type:"menu",prompt:prompt,multiSelect:false,items:items,withChat:withChat,countdown:countdown,placeholder:placeholder});
		/*#{1ITG3MUPL0PostCodes*/
		/*}#1ITG3MUPL0PostCodes*/
		if(typeof(item)==='string'){
			result=item;
			return {result:result};
		}else if(item.code===0){
			return {seg:Looper,result:(result),preSeg:"1ITG3MUPL0",outlet:"1ITG3MUP10"};
		}else if(item.code===1){
			return {seg:Abort,result:(result),preSeg:"1ITG3MUPL0",outlet:"1ITG3MUP20"};
		}
		/*#{1ITG3MUPL0FinCodes*/
		/*}#1ITG3MUPL0FinCodes*/
		return {result:result};
	};
	Ask.jaxId="1ITG3MUPL0"
	Ask.url="Ask@"+agentURL
	
	segs["Abort"]=Abort=async function(input){//:1ITG3QIHE0
		let result=input
		/*#{1ITG3QIHE0Code*/
		result={'reuslt':"Abort",info:"User abort."};
		/*}#1ITG3QIHE0Code*/
		return {result:result};
	};
	Abort.jaxId="1ITG3QIHE0"
	Abort.url="Abort@"+agentURL
	
	segs["Looper"]=Looper=async function(input){//:1ITG3R5BG0
		let result=input;
		let list=checkResult.missing;
		let i,n,item,loopR;
		n=list.length;
		for(i=0;i<n;i++){
			item=list[i];
			loopR=await session.runAISeg(agent,AskItem,item,"1ITG3R5BG0","1ITG44TCJ0")
			if(loopR==="break"){
				break;
			}
		}
		return {seg:CheckAbort,result:(result),preSeg:"1ITG3R5BG0",outlet:"1ITG44TCJ1"};
	};
	Looper.jaxId="1ITG3R5BG0"
	Looper.url="Looper@"+agentURL
	
	segs["AskItem"]=AskItem=async function(input){//:1ITG3S05E0
		let prompt=("Please confirm")||input;
		let countdown=undefined;
		let placeholder=(undefined)||null;
		let withChat=false;
		let silent=false;
		let items=[
			{emoji:"⚡️",text:(($ln==="CN")?("免费试用这个服务"):("Free trial this service")),code:0},
			{emoji:"💰",text:(($ln==="CN")?("购买/订阅这个服务。"):("Purchase/subscribe to this service.")),code:1},
			{emoji:"❌",text:(($ln==="CN")?("放弃使用服务"):("Abort")),code:2},
		];
		let result="";
		let item=null;
		
		/*#{1ITG3S05E0PreCodes*/
		loopItem=input;
		if($ln==="CN"){
			prompt=`#### 需要订阅项目：${input.name["CN"]||input.name["EN"]||input.name}  \n${input.desc["CN"]||input.desc["EN"]||input.desc}  \n订阅费用：${input.price}代币 / 30天  \n${input.freeTrial>0?`你可以免费实用${input.freeTrial}天。`:""}`;
			session.addChatText("assistant",prompt,{});
			if(input.freeTrial>0){
				prompt=`是否试用或者使用代币订阅这个项目?`;
			}else{
				if(input.expired>0){
					prompt=`该项目的订阅${input.expired}天前已过期，现在无法免费试用，是否订阅这个付费项目?`;
					items.splice(0,1);
					//items[0].enable=false;
				}else{
					prompt=`该项目无法免费试用，是否订阅这个付费项目?`;
					items.splice(0,1);
					//items[0].enable=false;
				}
			}
		}else{
			prompt=`#### Subscription：${input.name["EN"]||input.name}  \n${input.desc["EN"]||input.desc}  \nSubscrib：${input.price} tokens / 30 days  \n订阅费用：${input.price}代币 / 30天  \n${input.freeTrial>0?`You can take a ${input.freeTrial} day(s) free trial.`:""}`;
			session.addChatText("assistant",prompt,{});
			if(input.freeTrial>0){
				prompt=`Do you like take a free-trial or subscribe it?`;
			}else{
				if(input.expired>0){
					prompt=`Your subscribe expired ${input.expired} days ago, no free-trial available, sub subscribe it?`;
					items.splice(0,1);
					//items[0].enable=false;
				}else{
					prompt=`No free-trial for this item, subscribe it?`;
					items.splice(0,1);
					//items[0].enable=false;
				}
			}
		}
		/*}#1ITG3S05E0PreCodes*/
		if(silent){
			result=input;
			return {seg:FreeTrialItem,result:(result),preSeg:"1ITG3S05E0",outlet:"1ITG3S04T0"};
		}
		[result,item]=await session.askUserRaw({type:"menu",prompt:prompt,multiSelect:false,items:items,withChat:withChat,countdown:countdown,placeholder:placeholder});
		/*#{1ITG3S05E0PostCodes*/
		/*}#1ITG3S05E0PostCodes*/
		if(typeof(item)==='string'){
			result=item;
			return {result:result};
		}else if(item.code===0){
			result=(input);
			return {seg:FreeTrialItem,result:(result),preSeg:"1ITG3S05E0",outlet:"1ITG3S04T0"};
		}else if(item.code===1){
			result=(input);
			return {seg:EnoughToken,result:(result),preSeg:"1ITG3S05E0",outlet:"1ITG3S04T1"};
		}else if(item.code===2){
			result=(input);
			/*#{1ITG3S04T2*/
			/*}#1ITG3S04T2*/
			return {seg:AbortPurchase,result:(result),preSeg:"1ITG3S05E0",outlet:"1ITG3S04T2"};
		}
		/*#{1ITG3S05E0FinCodes*/
		/*}#1ITG3S05E0FinCodes*/
		return {result:result};
	};
	AskItem.jaxId="1ITG3S05E0"
	AskItem.url="AskItem@"+agentURL
	
	segs["FreeTrialItem"]=FreeTrialItem=async function(input){//:1ITG400G10
		let result=input
		/*#{1ITG400G10Code*/
		result=await tabNT.makeCall("SubSrvPurchase",{subService:input.id,batch:input.freeTrial,cost:0});
		/*}#1ITG400G10Code*/
		return {seg:CheckTrialResult,result:(result),preSeg:"1ITG400G10",outlet:"1ITG44TCJ3"};
	};
	FreeTrialItem.jaxId="1ITG400G10"
	FreeTrialItem.url="FreeTrialItem@"+agentURL
	
	segs["PurchaseItem"]=PurchaseItem=async function(input){//:1ITG40E5Q0
		let result=input
		/*#{1ITG40E5Q0Code*/
		result=await tabNT.makeCall("SubSrvPurchase",{subService:input.item.id,cost:input.cost,batch:input.batch});
		/*}#1ITG40E5Q0Code*/
		return {seg:PurchaseDone,result:(result),preSeg:"1ITG40E5Q0",outlet:"1ITG44TCJ4"};
	};
	PurchaseItem.jaxId="1ITG40E5Q0"
	PurchaseItem.url="PurchaseItem@"+agentURL
	
	segs["AbortPurchase"]=AbortPurchase=async function(input){//:1ITG40N110
		let result=input
		/*#{1ITG40N110Code*/
		result="break";
		loopAborted=true;
		/*}#1ITG40N110Code*/
		return {result:result};
	};
	AbortPurchase.jaxId="1ITG40N110"
	AbortPurchase.url="AbortPurchase@"+agentURL
	
	segs["AskDays"]=AskDays=async function(input){//:1ITG41EP60
		let prompt=("Please confirm")||input;
		let countdown=undefined;
		let placeholder=(undefined)||null;
		let withChat=false;
		let silent=false;
		let items=[
			{emoji:"🛒",text:(($ln==="CN")?("订阅30天"):("Subscribe for 30 days")),code:0},
			{emoji:"🛒",text:(($ln==="CN")?("订阅90天"):("Subscribe for 90 days")),code:1},
			{emoji:"🛒",text:(($ln==="CN")?("订阅365天"):("Subscribe for 365 days")),code:2},
			{emoji:"💰",text:(($ln==="CN")?("获取更多代币。"):("Get more tokens.")),code:3},
			{emoji:"🔙",text:(($ln==="CN")?("返回。"):("Back.")),code:4},
		];
		let result="";
		let item=null;
		
		/*#{1ITG41EP60PreCodes*/
		let p30,p90,p365;
		p30=input.price;
		p90=Math.floor(input.price*3*0.9);
		p365=Math.floor(input.price*12*0.8);
		if($ln==="CN"){
			prompt=`当前代币数量: ${userTokens}，订阅的价格是: ${input.price} / 30天。请选择要订阅的天数:`;
			items[0].text+=`: ${p30}代币${userTokens>p30?"。":"，代币不足。"}`;
			items[1].text+=`: ${p90}代币${userTokens>p90?"。":"，代币不足。"}`;
			items[2].text+=`: ${p365}代币${userTokens>p365?"。":"，代币不足。"}`;
		}else{
			prompt=`You have ${userTokens} tokens, subscribe price: ${input.price} / 30 days. Please choose days to subscribe:`;
			items[0].text+=`: ${p30}tokens${userTokens>p30?".":", not enough tokens."}`;
			items[1].text+=`: ${p90}tokens${userTokens>p90?".":", not enough tokens."}`;
			items[2].text+=`: ${p365}tokens${userTokens>p365?".":", not enough tokens."}`;
		}
		if(userTokens<p30){
			items[0].enable=false;
			items[0].color=[150,0,0,1];
		}
		if(userTokens<p90){
			items[1].enable=false;
			items[1].color=[150,0,0,1];
		}
		if(userTokens<p365){
			items[2].enable=false;
			items[2].color=[150,0,0,1];
		}
		/*}#1ITG41EP60PreCodes*/
		if(silent){
			result={item:input,batch:30};
			/*#{1ITG41EOK0Silent*/
			/*}#1ITG41EOK0Silent*/
			return {seg:PurchaseItem,result:(result),preSeg:"1ITG41EP60",outlet:"1ITG41EOK0"};
		}
		[result,item]=await session.askUserRaw({type:"menu",prompt:prompt,multiSelect:false,items:items,withChat:withChat,countdown:countdown,placeholder:placeholder});
		/*#{1ITG41EP60PostCodes*/
		/*}#1ITG41EP60PostCodes*/
		if(typeof(item)==='string'){
			result=item;
			return {result:result};
		}else if(item.code===0){
			result=({item:input,batch:30});
			/*#{1ITG41EOK0*/
			result.cost=p30;
			/*}#1ITG41EOK0*/
			return {seg:PurchaseItem,result:(result),preSeg:"1ITG41EP60",outlet:"1ITG41EOK0"};
		}else if(item.code===1){
			result=({item:input,batch:90});
			/*#{1ITG41EOK1*/
			result.cost=p90;
			/*}#1ITG41EOK1*/
			return {seg:PurchaseItem,result:(result),preSeg:"1ITG41EP60",outlet:"1ITG41EOK1"};
		}else if(item.code===2){
			result=({item:input,batch:365});
			/*#{1ITG41EOK2*/
			result.cost=p365;
			/*}#1ITG41EOK2*/
			return {seg:PurchaseItem,result:(result),preSeg:"1ITG41EP60",outlet:"1ITG41EOK2"};
		}else if(item.code===3){
			result=(input);
			return {seg:JumpCharge,result:(result),preSeg:"1ITG41EP60",outlet:"1ITLC4AT60"};
		}else if(item.code===4){
			result=(input);
			return {seg:JumpBack,result:(result),preSeg:"1ITG41EP60",outlet:"1ITLBQ4830"};
		}
		/*#{1ITG41EP60FinCodes*/
		/*}#1ITG41EP60FinCodes*/
		return {result:result};
	};
	AskDays.jaxId="1ITG41EP60"
	AskDays.url="AskDays@"+agentURL
	
	segs["EnoughToken"]=EnoughToken=async function(input){//:1ITG47G2D0
		let result=input;
		/*#{1ITG47G2D0Start*/
		let res=await tabNT.makeCall("userCurrency",{});
		if(res.code===200){
			userTokens=res.coins||0;
		}else{
			userTokens=0;
		}
		/*}#1ITG47G2D0Start*/
		if(userTokens>input.price){
			let output=input;
			return {seg:AskDays,result:(output),preSeg:"1ITG47G2D0",outlet:"1ITG4F4NI0"};
		}
		result=input;
		/*#{1ITG47G2D0Post*/
		/*}#1ITG47G2D0Post*/
		return {seg:AskCharge,result:(result),preSeg:"1ITG47G2D0",outlet:"1ITG4F4NI1"};
	};
	EnoughToken.jaxId="1ITG47G2D0"
	EnoughToken.url="EnoughToken@"+agentURL
	
	segs["AskCharge"]=AskCharge=async function(input){//:1ITG495U00
		let prompt=("Please confirm")||input;
		let countdown=undefined;
		let placeholder=(undefined)||null;
		let withChat=false;
		let silent=false;
		let items=[
			{emoji:"💰",text:(($ln==="CN")?("获得更多代币"):("Get more tokens")),code:0},
			{emoji:"拒绝",text:(($ln==="CN")?("放弃订阅"):("Abort purchase")),code:1},
			{emoji:"⚡️",text:(($ln==="CN")?("免费试用此服务"):("Free trial this service")),code:2},
		];
		let result="";
		let item=null;
		
		/*#{1ITG495U00PreCodes*/
		if($ln==="CN"){
			prompt=`需要至少${input.price}代币订阅该服务，当前代币为${userTokens}。是否购买/取得更多代币？`;
		}else{
			prompt=`This ISP item need at least ${input.price} tokens to subscribe, you have ${userTokens}. Do you like to get more tokens?`;
		}
		if(!(input.freeTrial>0)){
			items.splice(2,1);
		}
		/*}#1ITG495U00PreCodes*/
		if(silent){
			result=input;
			return {seg:ChargeTokens,result:(result),preSeg:"1ITG495U00",outlet:"1ITG495TC0"};
		}
		[result,item]=await session.askUserRaw({type:"menu",prompt:prompt,multiSelect:false,items:items,withChat:withChat,countdown:countdown,placeholder:placeholder});
		/*#{1ITG495U00PostCodes*/
		/*}#1ITG495U00PostCodes*/
		if(typeof(item)==='string'){
			result=item;
			return {result:result};
		}else if(item.code===0){
			result=(input);
			return {seg:ChargeTokens,result:(result),preSeg:"1ITG495U00",outlet:"1ITG495TC0"};
		}else if(item.code===1){
			result=(input);
			return {seg:JumpAbortPurchase,result:(result),preSeg:"1ITG495U00",outlet:"1ITG495TC1"};
		}else if(item.code===2){
			result=(input);
			return {seg:JumpFreeTrial,result:(result),preSeg:"1ITG495U00",outlet:"1ITG495TC2"};
		}
		/*#{1ITG495U00FinCodes*/
		/*}#1ITG495U00FinCodes*/
		return {result:result};
	};
	AskCharge.jaxId="1ITG495U00"
	AskCharge.url="AskCharge@"+agentURL
	
	segs["JumpFreeTrial"]=JumpFreeTrial=async function(input){//:1ITG4FUO60
		let result=input;
		return {seg:FreeTrialItem,result:result,preSeg:"1ITG400G10",outlet:"1ITG4GPG80"};
	
	};
	JumpFreeTrial.jaxId="1ITG400G10"
	JumpFreeTrial.url="JumpFreeTrial@"+agentURL
	
	segs["JumpAbortPurchase"]=JumpAbortPurchase=async function(input){//:1ITG4HSMM0
		let result=input;
		return {seg:AbortPurchase,result:result,preSeg:"1ITG40N110",outlet:"1ITG4IGOM0"};
	
	};
	JumpAbortPurchase.jaxId="1ITG40N110"
	JumpAbortPurchase.url="JumpAbortPurchase@"+agentURL
	
	segs["ChargeTokens"]=ChargeTokens=async function(input){//:1ITG4ION80
		let result=input
		/*#{1ITG4ION80Code*/
		await app.modalDlg("/@homekit/ui/DlgTokenGas.js",{});
		/*}#1ITG4ION80Code*/
		return {seg:JumpEoughToken,result:(result),preSeg:"1ITG4ION80",outlet:"1ITG4K9I90"};
	};
	ChargeTokens.jaxId="1ITG4ION80"
	ChargeTokens.url="ChargeTokens@"+agentURL
	
	segs["JumpEoughToken"]=JumpEoughToken=async function(input){//:1ITG4JRE00
		let result=input;
		/*#{1ITG4JRE00PreCodes*/
		result=loopItem;
		/*}#1ITG4JRE00PreCodes*/
		return {seg:EnoughToken,result:result,preSeg:"1ITG47G2D0",outlet:"1ITG4K9I91"};
	
	};
	JumpEoughToken.jaxId="1ITG47G2D0"
	JumpEoughToken.url="JumpEoughToken@"+agentURL
	
	segs["PurchaseDone"]=PurchaseDone=async function(input){//:1ITG4KHTA0
		let result=input;
		if((!input)||(input.code!==200)){
			return {seg:AskRetryPurchase,result:(input),preSeg:"1ITG4KHTA0",outlet:"1ITG4MPUF0"};
		}
		return {seg:TipPurchaseOK,result:(result),preSeg:"1ITG4KHTA0",outlet:"1ITG4MPUF1"};
	};
	PurchaseDone.jaxId="1ITG4KHTA0"
	PurchaseDone.url="PurchaseDone@"+agentURL
	
	segs["JumpAskItem"]=JumpAskItem=async function(input){//:1ITG4LRH00
		let result=input;
		return {seg:AskItem,result:result,preSeg:"1ITG3S05E0",outlet:"1ITG4MPUF2"};
	
	};
	JumpAskItem.jaxId="1ITG3S05E0"
	JumpAskItem.url="JumpAskItem@"+agentURL
	
	segs["JumpStart"]=JumpStart=async function(input){//:1ITG4S6R00
		let result=input;
		return {seg:CheckPurchase,result:result,preSeg:"1ITG3C4LM0",outlet:"1ITG4SIR00"};
	
	};
	JumpStart.jaxId="1ITG3C4LM0"
	JumpStart.url="JumpStart@"+agentURL
	
	segs["CheckAbort"]=CheckAbort=async function(input){//:1ITG4TAO60
		let result=input;
		if(!!loopAborted){
			return {seg:Abort2,result:(input),preSeg:"1ITG4TAO60",outlet:"1ITG4UHGC0"};
		}
		return {seg:JumpStart,result:(result),preSeg:"1ITG4TAO60",outlet:"1ITG4UHGC1"};
	};
	CheckAbort.jaxId="1ITG4TAO60"
	CheckAbort.url="CheckAbort@"+agentURL
	
	segs["Abort2"]=Abort2=async function(input){//:1ITG4U7SH0
		let result=input
		/*#{1ITG4U7SH0Code*/
		result={'result':"Abort",'info':"User aborted subscribe."}
		/*}#1ITG4U7SH0Code*/
		return {result:result};
	};
	Abort2.jaxId="1ITG4U7SH0"
	Abort2.url="Abort2@"+agentURL
	
	segs["CheckTrialResult"]=CheckTrialResult=async function(input){//:1ITICVJB10
		let result=input;
		if((!input) || (input.code!==200)){
			return {seg:AskRetryTrial,result:(input),preSeg:"1ITICVJB10",outlet:"1ITID681E0"};
		}
		return {seg:TipTrialOK,result:(result),preSeg:"1ITICVJB10",outlet:"1ITID681E1"};
	};
	CheckTrialResult.jaxId="1ITICVJB10"
	CheckTrialResult.url="CheckTrialResult@"+agentURL
	
	segs["AskRetryTrial"]=AskRetryTrial=async function(input){//:1ITID1SKA0
		let prompt=((($ln==="CN")?("免费试用失败，是否再试一次？"):("Free trial failed, would you like to try again?")))||input;
		let countdown=undefined;
		let placeholder=(undefined)||null;
		let withChat=false;
		let silent=false;
		let items=[
			{emoji:"🔄",text:(($ln==="CN")?("重试"):("Retry")),code:0},
			{emoji:"❌",text:(($ln==="CN")?("放弃"):("Abort")),code:1},
		];
		let result="";
		let item=null;
		
		if(silent){
			result=loopItem;
			return {seg:Retry,result:(result),preSeg:"1ITID1SKA0",outlet:"1ITID1SJL0"};
		}
		[result,item]=await session.askUserRaw({type:"menu",prompt:prompt,multiSelect:false,items:items,withChat:withChat,countdown:countdown,placeholder:placeholder});
		if(typeof(item)==='string'){
			result=item;
			return {result:result};
		}else if(item.code===0){
			result=(loopItem);
			return {seg:Retry,result:(result),preSeg:"1ITID1SKA0",outlet:"1ITID1SJL0"};
		}else if(item.code===1){
			return {seg:AbortTrial,result:(result),preSeg:"1ITID1SKA0",outlet:"1ITID1SJL1"};
		}
		return {result:result};
	};
	AskRetryTrial.jaxId="1ITID1SKA0"
	AskRetryTrial.url="AskRetryTrial@"+agentURL
	
	segs["Retry"]=Retry=async function(input){//:1ITID855Q0
		let result=input;
		return {seg:AskItem,result:result,preSeg:"1ITG3S05E0",outlet:"1ITID9GN20"};
	
	};
	Retry.jaxId="1ITG3S05E0"
	Retry.url="Retry@"+agentURL
	
	segs["AbortTrial"]=AbortTrial=async function(input){//:1ITID924I0
		let result=input
		/*#{1ITID924I0Code*/
		result="break";
		loopAborted=true;
		/*}#1ITID924I0Code*/
		return {result:result};
	};
	AbortTrial.jaxId="1ITID924I0"
	AbortTrial.url="AbortTrial@"+agentURL
	
	segs["AskRetryPurchase"]=AskRetryPurchase=async function(input){//:1ITIF14EV0
		let prompt=("订阅项目失败，是否重试?")||input;
		let countdown=undefined;
		let placeholder=(undefined)||null;
		let withChat=false;
		let silent=false;
		let items=[
			{emoji:"🔄",text:(($ln==="CN")?("重试"):("Retry")),code:0},
			{emoji:"❌",text:(($ln==="CN")?("放弃"):("Abort")),code:1},
		];
		let result="";
		let item=null;
		
		if(silent){
			result="";
			return {seg:JumpAskItem,result:(result),preSeg:"1ITIF14EV0",outlet:"1ITIF14EC0"};
		}
		[result,item]=await session.askUserRaw({type:"menu",prompt:prompt,multiSelect:false,items:items,withChat:withChat,countdown:countdown,placeholder:placeholder});
		if(typeof(item)==='string'){
			result=item;
			return {result:result};
		}else if(item.code===0){
			return {seg:JumpAskItem,result:(result),preSeg:"1ITIF14EV0",outlet:"1ITIF14EC0"};
		}else if(item.code===1){
			return {seg:AbortPurchase2,result:(result),preSeg:"1ITIF14EV0",outlet:"1ITIF14ED0"};
		}
		return {result:result};
	};
	AskRetryPurchase.jaxId="1ITIF14EV0"
	AskRetryPurchase.url="AskRetryPurchase@"+agentURL
	
	segs["AbortPurchase2"]=AbortPurchase2=async function(input){//:1ITIF3I380
		let result=input
		/*#{1ITIF3I380Code*/
		loopAborted=true;
		result="break";
		/*}#1ITIF3I380Code*/
		return {result:result};
	};
	AbortPurchase2.jaxId="1ITIF3I380"
	AbortPurchase2.url="AbortPurchase2@"+agentURL
	
	segs["TipTrialOK"]=TipTrialOK=async function(input){//:1ITL9LHTE0
		let result=input;
		let opts={txtHeader:($agent.showName||$agent.name||null)};
		let role="assistant";
		let content=(($ln==="CN")?("订阅免费试用成功"):("Subscribe free trial successful"));
		session.addChatText(role,content,opts);
		return {result:result};
	};
	TipTrialOK.jaxId="1ITL9LHTE0"
	TipTrialOK.url="TipTrialOK@"+agentURL
	
	segs["TipPurchaseOK"]=TipPurchaseOK=async function(input){//:1ITL9O6US0
		let result=input;
		let opts={txtHeader:($agent.showName||$agent.name||null)};
		let role="assistant";
		let content=(($ln==="CN")?("购买订阅项目成功!"):("Subscription item purchased successfully!"));
		session.addChatText(role,content,opts);
		return {result:result};
	};
	TipPurchaseOK.jaxId="1ITL9O6US0"
	TipPurchaseOK.url="TipPurchaseOK@"+agentURL
	
	segs["JumpBack"]=JumpBack=async function(input){//:1ITLBO6H80
		let result=input;
		return {seg:AskItem,result:result,preSeg:"1ITG3S05E0",outlet:"1ITLBQ4840"};
	
	};
	JumpBack.jaxId="1ITG3S05E0"
	JumpBack.url="JumpBack@"+agentURL
	
	segs["JumpCharge"]=JumpCharge=async function(input){//:1ITLC6DHR0
		let result=input;
		return {seg:ChargeTokens,result:result,preSeg:"1ITG4ION80",outlet:"1ITLC7MOC0"};
	
	};
	JumpCharge.jaxId="1ITG4ION80"
	JumpCharge.url="JumpCharge@"+agentURL
	
	agent=$agent={
		isAIAgent:true,
		session:session,
		name:"CheckPurchase",
		url:agentURL,
		autoStart:true,
		jaxId:"1ITG3B57V0",
		context:context,
		livingSeg:null,
		execChat:async function(input/*{purchases}*/){
			let result;
			parseAgentArgs(input);
			/*#{1ITG3B57V0PreEntry*/
			/*}#1ITG3B57V0PreEntry*/
			result={seg:CheckPurchase,"input":input};
			/*#{1ITG3B57V0PostEntry*/
			/*}#1ITG3B57V0PostEntry*/
			return result;
		},
		/*#{1ITG3B57V0MoreAgentAttrs*/
		/*}#1ITG3B57V0MoreAgentAttrs*/
	};
	/*#{1ITG3B57V0PostAgent*/
	/*}#1ITG3B57V0PostAgent*/
	return agent;
};
/*#{1ITG3B57V0ExCodes*/
/*}#1ITG3B57V0ExCodes*/

//#CodyExport>>>
export const ChatAPI=[{
	def:{
		name: "CheckPurchase",
		description: "这是一个AI智能体。",
		parameters:{
			type: "object",
			properties:{
				purchases:{type:"auto",description:""}
			}
		}
	},
	agent: CheckPurchase
}];
//#CodyExport<<<
/*#{1ITG3B57V0PostDoc*/
/*}#1ITG3B57V0PostDoc*/


export default CheckPurchase;
export{CheckPurchase};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DocAIAgent",
//	"jaxId": "1ITG3B57V0",
//	"attrs": {
//		"editObjs": {
//			"jaxId": "1ITG3B57V1",
//			"attrs": {
//				"CheckPurchase": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1ITG3B5800",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1ITG3B5801",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1ITG3B5802",
//							"attrs": {}
//						},
//						"functions": {
//							"jaxId": "1ITG3B5803",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false",
//						"exportClass": "false"
//					},
//					"mockups": {}
//				}
//			}
//		},
//		"agent": {
//			"jaxId": "1ITG3B57V2",
//			"attrs": {}
//		},
//		"showName": "",
//		"entry": "",
//		"autoStart": "true",
//		"inBrowser": "true",
//		"debug": "true",
//		"apiArgs": {
//			"jaxId": "1ITG3B57V3",
//			"attrs": {
//				"purchases": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1ITG3BRFR0",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1ITG3B57V4",
//			"attrs": {
//				"checkResult": {
//					"type": "auto",
//					"valText": ""
//				},
//				"loopAborted": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"loopItem": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"userTokens": {
//					"type": "number",
//					"valText": "0"
//				}
//			}
//		},
//		"context": {
//			"jaxId": "1ITG3B57V5",
//			"attrs": {}
//		},
//		"globalMockup": {
//			"jaxId": "1ITG3B57V6",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1ITG3C4LM0",
//					"attrs": {
//						"id": "CheckPurchase",
//						"viewName": "",
//						"label": "",
//						"x": "130",
//						"y": "240",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1ITG44TCK0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1ITG44TCK1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1ITG44TCI0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1ITG3CIV30"
//						},
//						"outlets": {
//							"attrs": []
//						},
//						"result": "#input"
//					},
//					"icon": "tab_css.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "brunch",
//					"jaxId": "1ITG3CIV30",
//					"attrs": {
//						"id": "IsChecked",
//						"viewName": "",
//						"label": "",
//						"x": "395",
//						"y": "240",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1ITG44TCK2",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1ITG44TCK3",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1ITG44TCI2",
//							"attrs": {
//								"id": "No",
//								"desc": "输出节点。",
//								"output": ""
//							},
//							"linkedSeg": "1ITG3MUPL0"
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1ITG44TCI1",
//									"attrs": {
//										"id": "Yes",
//										"desc": "输出节点。",
//										"output": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1ITG44TCK4",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1ITG44TCK5",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#!!input.check"
//									},
//									"linkedSeg": "1ITG3FMQS0"
//								}
//							]
//						}
//					},
//					"icon": "condition.svg",
//					"reverseOutlets": true
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1ITG3FMQS0",
//					"attrs": {
//						"id": "Finish",
//						"viewName": "",
//						"label": "",
//						"x": "615",
//						"y": "160",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "flag.svg",
//						"context": {
//							"jaxId": "1ITG44TCK6",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1ITG44TCK7",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1ITG44TCI3",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							}
//						},
//						"outlets": {
//							"attrs": []
//						},
//						"result": "#input"
//					},
//					"icon": "tab_css.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "askMenu",
//					"jaxId": "1ITG3MUPL0",
//					"attrs": {
//						"id": "Ask",
//						"viewName": "",
//						"label": "",
//						"x": "615",
//						"y": "340",
//						"desc": "这是一个AISeg。",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"prompt": "Please confirm",
//						"multi": "false",
//						"withChat": "false",
//						"outlet": {
//							"jaxId": "1ITG44TCI4",
//							"attrs": {
//								"id": "ChatInput",
//								"desc": "输出节点。",
//								"codes": "false"
//							}
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1ITG3MUP10",
//									"attrs": {
//										"id": "Purchase",
//										"desc": "输出节点。",
//										"text": {
//											"type": "string",
//											"valText": "Purchase or free-trial missing service(s)",
//											"localize": {
//												"EN": "Purchase or free-trial missing service(s)",
//												"CN": "购买或试用缺失的服务"
//											},
//											"localizable": true
//										},
//										"result": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1ITG44TCK8",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1ITG44TCK9",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"emoji": "🚀"
//									},
//									"linkedSeg": "1ITG3R5BG0"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1ITG3MUP20",
//									"attrs": {
//										"id": "Abort",
//										"desc": "输出节点。",
//										"text": {
//											"type": "string",
//											"valText": "Abort",
//											"localize": {
//												"EN": "Abort",
//												"CN": "放弃"
//											},
//											"localizable": true
//										},
//										"result": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1ITG44TCK10",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1ITG44TCK11",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"emoji": "❌"
//									},
//									"linkedSeg": "1ITG3QIHE0"
//								}
//							]
//						},
//						"silent": "false"
//					},
//					"icon": "menu.svg",
//					"reverseOutlets": true
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1ITG3QIHE0",
//					"attrs": {
//						"id": "Abort",
//						"viewName": "",
//						"label": "",
//						"x": "830",
//						"y": "410",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "flag.svg",
//						"context": {
//							"jaxId": "1ITG44TCK12",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1ITG44TCK13",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1ITG44TCI5",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							}
//						},
//						"outlets": {
//							"attrs": []
//						},
//						"result": "#input"
//					},
//					"icon": "tab_css.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "loopArray",
//					"jaxId": "1ITG3R5BG0",
//					"attrs": {
//						"id": "Looper",
//						"viewName": "",
//						"label": "",
//						"x": "830",
//						"y": "175",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1ITG44TCK14",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1ITG44TCK15",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"loopArray": "#checkResult.missing",
//						"method": "forEach",
//						"outlet": {
//							"jaxId": "1ITG44TCJ0",
//							"attrs": {
//								"id": "Looper",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1ITG3S05E0"
//						},
//						"catchlet": {
//							"jaxId": "1ITG44TCJ1",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1ITG4TAO60"
//						}
//					},
//					"icon": "loop_array.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "askMenu",
//					"jaxId": "1ITG3S05E0",
//					"attrs": {
//						"id": "AskItem",
//						"viewName": "",
//						"label": "",
//						"x": "1055",
//						"y": "160",
//						"desc": "这是一个AISeg。",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"prompt": "Please confirm",
//						"multi": "false",
//						"withChat": "false",
//						"outlet": {
//							"jaxId": "1ITG44TCJ2",
//							"attrs": {
//								"id": "ChatInput",
//								"desc": "输出节点。",
//								"codes": "false"
//							}
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1ITG3S04T0",
//									"attrs": {
//										"id": "FreeTrial",
//										"desc": "输出节点。",
//										"text": {
//											"type": "string",
//											"valText": "Free trial this service",
//											"localize": {
//												"EN": "Free trial this service",
//												"CN": "免费试用这个服务"
//											},
//											"localizable": true
//										},
//										"result": "#input",
//										"codes": "false",
//										"context": {
//											"jaxId": "1ITG44TCK16",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1ITG44TCK17",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"emoji": "⚡️"
//									},
//									"linkedSeg": "1ITG400G10"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1ITG3S04T1",
//									"attrs": {
//										"id": "Purchase",
//										"desc": "输出节点。",
//										"text": {
//											"type": "string",
//											"valText": "Purchase/subscribe to this service.",
//											"localize": {
//												"EN": "Purchase/subscribe to this service.",
//												"CN": "购买/订阅这个服务。"
//											},
//											"localizable": true
//										},
//										"result": "#input",
//										"codes": "false",
//										"context": {
//											"jaxId": "1ITG44TCK18",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1ITG44TCK19",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"emoji": "💰"
//									},
//									"linkedSeg": "1ITG47G2D0"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1ITG3S04T2",
//									"attrs": {
//										"id": "Abort",
//										"desc": "输出节点。",
//										"text": {
//											"type": "string",
//											"valText": "Abort",
//											"localize": {
//												"EN": "Abort",
//												"CN": "放弃使用服务"
//											},
//											"localizable": true
//										},
//										"result": "#input",
//										"codes": "true",
//										"context": {
//											"jaxId": "1ITG44TCK20",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1ITG44TCK21",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"emoji": "❌"
//									},
//									"linkedSeg": "1ITG40N110"
//								}
//							]
//						},
//						"silent": "false"
//					},
//					"icon": "menu.svg",
//					"reverseOutlets": true
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1ITG400G10",
//					"attrs": {
//						"id": "FreeTrialItem",
//						"viewName": "",
//						"label": "",
//						"x": "1300",
//						"y": "-15",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1ITG44TCK22",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1ITG44TCK23",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1ITG44TCJ3",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1ITICVJB10"
//						},
//						"outlets": {
//							"attrs": []
//						},
//						"result": "#input"
//					},
//					"icon": "tab_css.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1ITG40E5Q0",
//					"attrs": {
//						"id": "PurchaseItem",
//						"viewName": "",
//						"label": "",
//						"x": "1810",
//						"y": "0",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1ITG44TCK24",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1ITG44TCK25",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1ITG44TCJ4",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1ITG4KHTA0"
//						},
//						"outlets": {
//							"attrs": []
//						},
//						"result": "#input"
//					},
//					"icon": "tab_css.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1ITG40N110",
//					"attrs": {
//						"id": "AbortPurchase",
//						"viewName": "",
//						"label": "",
//						"x": "1300",
//						"y": "285",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1ITG44TCK26",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1ITG44TCK27",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1ITG44TCJ5",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							}
//						},
//						"outlets": {
//							"attrs": []
//						},
//						"result": "#input"
//					},
//					"icon": "tab_css.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "askMenu",
//					"jaxId": "1ITG41EP60",
//					"attrs": {
//						"id": "AskDays",
//						"viewName": "",
//						"label": "",
//						"x": "1540",
//						"y": "45",
//						"desc": "这是一个AISeg。",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"prompt": "Please confirm",
//						"multi": "false",
//						"withChat": "false",
//						"outlet": {
//							"jaxId": "1ITG44TCJ6",
//							"attrs": {
//								"id": "ChatInput",
//								"desc": "输出节点。",
//								"codes": "false"
//							}
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1ITG41EOK0",
//									"attrs": {
//										"id": "30",
//										"desc": "输出节点。",
//										"text": {
//											"type": "string",
//											"valText": "Subscribe for 30 days",
//											"localize": {
//												"EN": "Subscribe for 30 days",
//												"CN": "订阅30天"
//											},
//											"localizable": true
//										},
//										"result": "#{item:input,batch:30}",
//										"codes": "true",
//										"context": {
//											"jaxId": "1ITG44TCK28",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1ITG44TCK29",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"emoji": "🛒"
//									},
//									"linkedSeg": "1ITG40E5Q0"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1ITG41EOK1",
//									"attrs": {
//										"id": "90",
//										"desc": "输出节点。",
//										"text": {
//											"type": "string",
//											"valText": "Subscribe for 90 days",
//											"localize": {
//												"EN": "Subscribe for 90 days",
//												"CN": "订阅90天"
//											},
//											"localizable": true
//										},
//										"result": "#{item:input,batch:90}",
//										"codes": "true",
//										"context": {
//											"jaxId": "1ITG44TCK30",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1ITG44TCK31",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"emoji": "🛒"
//									},
//									"linkedSeg": "1ITG40E5Q0"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1ITG41EOK2",
//									"attrs": {
//										"id": "365",
//										"desc": "输出节点。",
//										"text": {
//											"type": "string",
//											"valText": "Subscribe for 365 days",
//											"localize": {
//												"EN": "Subscribe for 365 days",
//												"CN": "订阅365天"
//											},
//											"localizable": true
//										},
//										"result": "#{item:input,batch:365}",
//										"codes": "true",
//										"context": {
//											"jaxId": "1ITG44TCK32",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1ITG44TCK33",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"emoji": "🛒"
//									},
//									"linkedSeg": "1ITG40E5Q0"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1ITLC4AT60",
//									"attrs": {
//										"id": "Charge",
//										"desc": "输出节点。",
//										"text": {
//											"type": "string",
//											"valText": "Get more tokens.",
//											"localize": {
//												"EN": "Get more tokens.",
//												"CN": "获取更多代币。"
//											},
//											"localizable": true
//										},
//										"result": "#input",
//										"codes": "false",
//										"context": {
//											"jaxId": "1ITLC7MOI0",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1ITLC7MOI1",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"icon": "/~/-tabos/shared/assets/inc.svg",
//										"emoji": "💰"
//									},
//									"linkedSeg": "1ITLC6DHR0"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1ITLBQ4830",
//									"attrs": {
//										"id": "Back",
//										"desc": "输出节点。",
//										"text": {
//											"type": "string",
//											"valText": "Back.",
//											"localize": {
//												"EN": "Back.",
//												"CN": "返回。"
//											},
//											"localizable": true
//										},
//										"result": "#input",
//										"codes": "false",
//										"context": {
//											"jaxId": "1ITLBQ48C0",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1ITLBQ48C1",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"emoji": "🔙"
//									},
//									"linkedSeg": "1ITLBO6H80"
//								}
//							]
//						},
//						"silent": "false"
//					},
//					"icon": "menu.svg",
//					"reverseOutlets": true
//				},
//				{
//					"type": "aiseg",
//					"def": "brunch",
//					"jaxId": "1ITG47G2D0",
//					"attrs": {
//						"id": "EnoughToken",
//						"viewName": "",
//						"label": "",
//						"x": "1300",
//						"y": "145",
//						"desc": "这是一个AISeg。",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1ITG4F4NK0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1ITG4F4NK1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1ITG4F4NI1",
//							"attrs": {
//								"id": "No",
//								"desc": "输出节点。",
//								"output": "#input"
//							},
//							"linkedSeg": "1ITG495U00"
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1ITG4F4NI0",
//									"attrs": {
//										"id": "Yes",
//										"desc": "输出节点。",
//										"output": "#input",
//										"codes": "false",
//										"context": {
//											"jaxId": "1ITG4F4NK2",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1ITG4F4NK3",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#userTokens>input.price"
//									},
//									"linkedSeg": "1ITG41EP60"
//								}
//							]
//						}
//					},
//					"icon": "condition.svg",
//					"reverseOutlets": true
//				},
//				{
//					"type": "aiseg",
//					"def": "askMenu",
//					"jaxId": "1ITG495U00",
//					"attrs": {
//						"id": "AskCharge",
//						"viewName": "",
//						"label": "",
//						"x": "1540",
//						"y": "295",
//						"desc": "这是一个AISeg。",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"prompt": "Please confirm",
//						"multi": "false",
//						"withChat": "false",
//						"outlet": {
//							"jaxId": "1ITG4F4NI2",
//							"attrs": {
//								"id": "ChatInput",
//								"desc": "输出节点。",
//								"codes": "false"
//							}
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1ITG495TC0",
//									"attrs": {
//										"id": "Charge",
//										"desc": "输出节点。",
//										"text": {
//											"type": "string",
//											"valText": "Get more tokens",
//											"localize": {
//												"EN": "Get more tokens",
//												"CN": "获得更多代币"
//											},
//											"localizable": true
//										},
//										"result": "#input",
//										"codes": "false",
//										"context": {
//											"jaxId": "1ITG4F4NK4",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1ITG4F4NK5",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"emoji": "💰"
//									},
//									"linkedSeg": "1ITG4ION80"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1ITG495TC1",
//									"attrs": {
//										"id": "Abort",
//										"desc": "输出节点。",
//										"text": {
//											"type": "string",
//											"valText": "Abort purchase",
//											"localize": {
//												"EN": "Abort purchase",
//												"CN": "放弃订阅"
//											},
//											"localizable": true
//										},
//										"result": "#input",
//										"codes": "false",
//										"context": {
//											"jaxId": "1ITG4F4NL0",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1ITG4F4NL1",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"emoji": "拒绝"
//									},
//									"linkedSeg": "1ITG4HSMM0"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1ITG495TC2",
//									"attrs": {
//										"id": "FreeTrial",
//										"desc": "输出节点。",
//										"text": {
//											"type": "string",
//											"valText": "Free trial this service",
//											"localize": {
//												"EN": "Free trial this service",
//												"CN": "免费试用此服务"
//											},
//											"localizable": true
//										},
//										"result": "#input",
//										"codes": "false",
//										"context": {
//											"jaxId": "1ITG4F4NL2",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1ITG4F4NL3",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"emoji": "⚡️"
//									},
//									"linkedSeg": "1ITG4FUO60"
//								}
//							]
//						},
//						"silent": "false"
//					},
//					"icon": "menu.svg",
//					"reverseOutlets": true
//				},
//				{
//					"type": "aiseg",
//					"def": "jumper",
//					"jaxId": "1ITG4FUO60",
//					"attrs": {
//						"id": "JumpFreeTrial",
//						"viewName": "",
//						"label": "",
//						"x": "1800",
//						"y": "365",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"seg": "1ITG400G10",
//						"outlet": {
//							"jaxId": "1ITG4GPG80",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						}
//					},
//					"icon": "arrowupright.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "jumper",
//					"jaxId": "1ITG4HSMM0",
//					"attrs": {
//						"id": "JumpAbortPurchase",
//						"viewName": "",
//						"label": "",
//						"x": "1800",
//						"y": "280",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"seg": "1ITG40N110",
//						"outlet": {
//							"jaxId": "1ITG4IGOM0",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						}
//					},
//					"icon": "arrowupright.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1ITG4ION80",
//					"attrs": {
//						"id": "ChargeTokens",
//						"viewName": "",
//						"label": "",
//						"x": "1800",
//						"y": "190",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1ITG4K9IC0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1ITG4K9IC1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1ITG4K9I90",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1ITG4JRE00"
//						},
//						"outlets": {
//							"attrs": []
//						},
//						"result": "#input"
//					},
//					"icon": "tab_css.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "jumper",
//					"jaxId": "1ITG4JRE00",
//					"attrs": {
//						"id": "JumpEoughToken",
//						"viewName": "",
//						"label": "",
//						"x": "2045",
//						"y": "190",
//						"desc": "这是一个AISeg。",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"seg": "1ITG47G2D0",
//						"outlet": {
//							"jaxId": "1ITG4K9I91",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						}
//					},
//					"icon": "arrowupright.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "brunch",
//					"jaxId": "1ITG4KHTA0",
//					"attrs": {
//						"id": "PurchaseDone",
//						"viewName": "",
//						"label": "",
//						"x": "2055",
//						"y": "0",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1ITG4MPUI0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1ITG4MPUI1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1ITG4MPUF1",
//							"attrs": {
//								"id": "Done",
//								"desc": "输出节点。",
//								"output": ""
//							},
//							"linkedSeg": "1ITL9O6US0"
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1ITG4MPUF0",
//									"attrs": {
//										"id": "Failed",
//										"desc": "输出节点。",
//										"output": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1ITG4MPUI2",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1ITG4MPUI3",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#(!input)||(input.code!==200)"
//									},
//									"linkedSeg": "1ITIF14EV0"
//								}
//							]
//						}
//					},
//					"icon": "condition.svg",
//					"reverseOutlets": true
//				},
//				{
//					"type": "aiseg",
//					"def": "jumper",
//					"jaxId": "1ITG4LRH00",
//					"attrs": {
//						"id": "JumpAskItem",
//						"viewName": "",
//						"label": "",
//						"x": "2570",
//						"y": "-130",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"seg": "1ITG3S05E0",
//						"outlet": {
//							"jaxId": "1ITG4MPUF2",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						}
//					},
//					"icon": "arrowupright.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "jumper",
//					"jaxId": "1ITG4S6R00",
//					"attrs": {
//						"id": "JumpStart",
//						"viewName": "",
//						"label": "",
//						"x": "1280",
//						"y": "475",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"seg": "1ITG3C4LM0",
//						"outlet": {
//							"jaxId": "1ITG4SIR00",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						}
//					},
//					"icon": "arrowupright.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "brunch",
//					"jaxId": "1ITG4TAO60",
//					"attrs": {
//						"id": "CheckAbort",
//						"viewName": "",
//						"label": "",
//						"x": "1055",
//						"y": "425",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1ITG4UHGG0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1ITG4UHGG1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1ITG4UHGC1",
//							"attrs": {
//								"id": "Finish",
//								"desc": "输出节点。",
//								"output": ""
//							},
//							"linkedSeg": "1ITG4S6R00"
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1ITG4UHGC0",
//									"attrs": {
//										"id": "Abort",
//										"desc": "输出节点。",
//										"output": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1ITG4UHGG2",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1ITG4UHGG3",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#!!loopAborted"
//									},
//									"linkedSeg": "1ITG4U7SH0"
//								}
//							]
//						}
//					},
//					"icon": "condition.svg",
//					"reverseOutlets": true
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1ITG4U7SH0",
//					"attrs": {
//						"id": "Abort2",
//						"viewName": "",
//						"label": "",
//						"x": "1280",
//						"y": "375",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "flag.svg",
//						"context": {
//							"jaxId": "1ITG4UHGG4",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1ITG4UHGG5",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1ITG4UHGC2",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							}
//						},
//						"outlets": {
//							"attrs": []
//						},
//						"result": "#input"
//					},
//					"icon": "tab_css.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "brunch",
//					"jaxId": "1ITICVJB10",
//					"attrs": {
//						"id": "CheckTrialResult",
//						"viewName": "",
//						"label": "",
//						"x": "1540",
//						"y": "-170",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1ITID7L2M0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1ITID7L2M1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1ITID681E1",
//							"attrs": {
//								"id": "Default",
//								"desc": "输出节点。",
//								"output": ""
//							},
//							"linkedSeg": "1ITL9LHTE0"
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1ITID681E0",
//									"attrs": {
//										"id": "Error",
//										"desc": "输出节点。",
//										"output": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1ITID7L2M2",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1ITID7L2M3",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#(!input) || (input.code!==200)"
//									},
//									"linkedSeg": "1ITID1SKA0"
//								}
//							]
//						}
//					},
//					"icon": "condition.svg",
//					"reverseOutlets": true
//				},
//				{
//					"type": "aiseg",
//					"def": "askMenu",
//					"jaxId": "1ITID1SKA0",
//					"attrs": {
//						"id": "AskRetryTrial",
//						"viewName": "",
//						"label": "",
//						"x": "1810",
//						"y": "-185",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"prompt": {
//							"type": "string",
//							"valText": "Free trial failed, would you like to try again?",
//							"localize": {
//								"EN": "Free trial failed, would you like to try again?",
//								"CN": "免费试用失败，是否再试一次？"
//							},
//							"localizable": true
//						},
//						"multi": "false",
//						"withChat": "false",
//						"outlet": {
//							"jaxId": "1ITID681E2",
//							"attrs": {
//								"id": "ChatInput",
//								"desc": "输出节点。",
//								"codes": "false"
//							}
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1ITID1SJL0",
//									"attrs": {
//										"id": "Retry",
//										"desc": "输出节点。",
//										"text": {
//											"type": "string",
//											"valText": "Retry",
//											"localize": {
//												"EN": "Retry",
//												"CN": "重试"
//											},
//											"localizable": true
//										},
//										"result": "#loopItem",
//										"codes": "false",
//										"context": {
//											"jaxId": "1ITID7L2M4",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1ITID7L2M5",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"emoji": "🔄"
//									},
//									"linkedSeg": "1ITID855Q0"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1ITID1SJL1",
//									"attrs": {
//										"id": "Abort",
//										"desc": "输出节点。",
//										"text": {
//											"type": "string",
//											"valText": "Abort",
//											"localize": {
//												"EN": "Abort",
//												"CN": "放弃"
//											},
//											"localizable": true
//										},
//										"result": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1ITID7L2M6",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1ITID7L2M7",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"emoji": "❌"
//									},
//									"linkedSeg": "1ITID924I0"
//								}
//							]
//						},
//						"silent": "false"
//					},
//					"icon": "menu.svg",
//					"reverseOutlets": true
//				},
//				{
//					"type": "aiseg",
//					"def": "jumper",
//					"jaxId": "1ITID855Q0",
//					"attrs": {
//						"id": "Retry",
//						"viewName": "",
//						"label": "",
//						"x": "2055",
//						"y": "-245",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"seg": "1ITG3S05E0",
//						"outlet": {
//							"jaxId": "1ITID9GN20",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						}
//					},
//					"icon": "arrowupright.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1ITID924I0",
//					"attrs": {
//						"id": "AbortTrial",
//						"viewName": "",
//						"label": "",
//						"x": "2055",
//						"y": "-160",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1ITID9GN90",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1ITID9GN91",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1ITID9GN21",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							}
//						},
//						"outlets": {
//							"attrs": []
//						},
//						"result": "#input"
//					},
//					"icon": "tab_css.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "askMenu",
//					"jaxId": "1ITIF14EV0",
//					"attrs": {
//						"id": "AskRetryPurchase",
//						"viewName": "",
//						"label": "",
//						"x": "2285",
//						"y": "-55",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"prompt": "订阅项目失败，是否重试?",
//						"multi": "false",
//						"withChat": "false",
//						"outlet": {
//							"jaxId": "1ITIF44TV0",
//							"attrs": {
//								"id": "ChatInput",
//								"desc": "输出节点。",
//								"codes": "false"
//							}
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1ITIF14EC0",
//									"attrs": {
//										"id": "Retry",
//										"desc": "输出节点。",
//										"text": {
//											"type": "string",
//											"valText": "Retry",
//											"localize": {
//												"EN": "Retry",
//												"CN": "重试"
//											},
//											"localizable": true
//										},
//										"result": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1ITIF44U70",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1ITIF44U71",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"emoji": "🔄"
//									},
//									"linkedSeg": "1ITG4LRH00"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1ITIF14ED0",
//									"attrs": {
//										"id": "Abort",
//										"desc": "输出节点。",
//										"text": {
//											"type": "string",
//											"valText": "Abort",
//											"localize": {
//												"EN": "Abort",
//												"CN": "放弃"
//											},
//											"localizable": true
//										},
//										"result": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1ITIF44U72",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1ITIF44U73",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"emoji": "❌"
//									},
//									"linkedSeg": "1ITIF3I380"
//								}
//							]
//						},
//						"silent": "false"
//					},
//					"icon": "menu.svg",
//					"reverseOutlets": true
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1ITIF3I380",
//					"attrs": {
//						"id": "AbortPurchase2",
//						"viewName": "",
//						"label": "",
//						"x": "2570",
//						"y": "-20",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1ITIF44U74",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1ITIF44U75",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1ITIF44TV1",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							}
//						},
//						"outlets": {
//							"attrs": []
//						},
//						"result": "#input"
//					},
//					"icon": "tab_css.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1ITL9LHTE0",
//					"attrs": {
//						"id": "TipTrialOK",
//						"viewName": "",
//						"label": "",
//						"x": "1810",
//						"y": "-80",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1ITL9NOSJ0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1ITL9NOSJ1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "Assistant",
//						"text": {
//							"type": "string",
//							"valText": "Subscribe free trial successful",
//							"localize": {
//								"EN": "Subscribe free trial successful",
//								"CN": "订阅免费试用成功"
//							},
//							"localizable": true
//						},
//						"outlet": {
//							"jaxId": "1ITL9NOSD0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							}
//						}
//					},
//					"icon": "hudtxt.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1ITL9O6US0",
//					"attrs": {
//						"id": "TipPurchaseOK",
//						"viewName": "",
//						"label": "",
//						"x": "2285",
//						"y": "55",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1ITL9QF290",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1ITL9QF291",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"role": "Assistant",
//						"text": {
//							"type": "string",
//							"valText": "Subscription item purchased successfully!",
//							"localize": {
//								"EN": "Subscription item purchased successfully!",
//								"CN": "购买订阅项目成功!"
//							},
//							"localizable": true
//						},
//						"outlet": {
//							"jaxId": "1ITL9QF220",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							}
//						}
//					},
//					"icon": "hudtxt.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "jumper",
//					"jaxId": "1ITLBO6H80",
//					"attrs": {
//						"id": "JumpBack",
//						"viewName": "",
//						"label": "",
//						"x": "1810",
//						"y": "125",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"seg": "1ITG3S05E0",
//						"outlet": {
//							"jaxId": "1ITLBQ4840",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						}
//					},
//					"icon": "arrowupright.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "jumper",
//					"jaxId": "1ITLC6DHR0",
//					"attrs": {
//						"id": "JumpCharge",
//						"viewName": "",
//						"label": "",
//						"x": "1810",
//						"y": "60",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"seg": "1ITG4ION80",
//						"outlet": {
//							"jaxId": "1ITLC7MOC0",
//							"attrs": {
//								"id": "Next",
//								"desc": "输出节点。"
//							}
//						}
//					},
//					"icon": "arrowupright.svg"
//				}
//			]
//		},
//		"desc": "这是一个AI智能体。",
//		"exportAPI": "true",
//		"exportAddOn": "false",
//		"addOnOpts": ""
//	}
//}