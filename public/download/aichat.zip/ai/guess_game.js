//Auto genterated by Cody
import {$P,VFACT,callAfter} from "/@vfact";
import pathLib from "/@path";
import inherits from "/@inherits";
/*#{1HCQBLMCQ0MoreImports*/
/*}#1HCQBLMCQ0MoreImports*/
const agentURL=(new URL(import.meta.url)).pathname;
const basePath=pathLib.dirname(agentURL);
const $ln=VFACT.lanCode||"EN";
/*#{1HCQBLMCQ0StartDoc*/
/*}#1HCQBLMCQ0StartDoc*/
//----------------------------------------------------------------------------
let guess_game=function(session){
	let state,context;
	let self;
	let Start,GenNames,PickName,Ready,UserGuess,AIReply,ShowReply,CheckOver,OverAsk,AIChatRely,WaitChat,StartChat,ShowChatReply,GameEnd;
	/*#{1HCQBLMCQ0LocalVals*/
	/*}#1HCQBLMCQ0LocalVals*/
	
	/*#{1HCQBLMCQ0PreContext*/
	/*}#1HCQBLMCQ0PreContext*/
	context={
		"objName":"Apple","round":0,
		/*#{1HCQBLMCR3ExCtxAttrs*/
		/*}#1HCQBLMCR3ExCtxAttrs*/
	};
	context=VFACT.flexState(context);
	/*#{1HCQBLMCQ0PostContext*/
	/*}#1HCQBLMCQ0PostContext*/
	let agent,segs={};
	segs["Start"]=Start=async function(input){//:1HCQDFO2Q2
		let result=input;
		let role="assistant";
		let conent="Let's play a mind game...";
		session.addChatText(role,conent);
		return {seg:GenNames,result:(result),preSeg:"1HCQDFO2Q2",outlet:"1HCQDFO2Q3"};
	};
	Start.jaxId="1HCQDFO2Q2"
	Start.url="Start@"+agentURL
	
	segs["GenNames"]=GenNames=async function(input){//:1HCQDFO2R0
		let result;
		let opts={
			mode:"gpt-3.5-turbo",
			maxToken:1000,
			temperature:0,
			topP:1,
			fqcP:0,
			prcP:0,
			secret:true
		};
		let messages=[
			{role:"system",content:"Each time you interact with the user, imagine a few things randomly and tell the user their names. Please only answer with the names of the items, without including any other text."},
		];
		messages.push({role:"user",content:`Imagine 10 random things, anything is fine, feel free to be imaginative
Please only provide the English names of the things, without including color, size, or other information. Separate the names of the things with semicolons.`});
		
		result=await session.callSegLLM("GenNames@"+agentURL,opts,messages);
		return {seg:PickName,result:(result),preSeg:"1HCQDFO2R0",outlet:"1HCQDFO2R1"};
	};
	GenNames.jaxId="1HCQDFO2R0"
	GenNames.url="GenNames@"+agentURL
	segs["PickName"]=PickName=async function(input){//:1HCQDFO2R2
		let result=""
		/*#{1HCQDFO2R2Code*/
		let objNames,num,objName;
		objNames=input.split(";");
		num=objNames.length-1;
		objName=objNames[Math.floor(Math.random()*num)];
		result=objName;
		/*}#1HCQDFO2R2Code*/
		Object.assign(context,{
			"objName":objName
		});
		return {seg:Ready,result:(result),preSeg:"1HCQDFO2R2",outlet:"1HCQDFO2R3"};
	};
	PickName.jaxId="1HCQDFO2R2"
	PickName.url="PickName@"+agentURL
	
	segs["Ready"]=Ready=async function(input){//:1HCQDFO2R4
		let result=input;
		let role="assistant";
		let conent="I have a item in mind, can you guess what it is?";
		session.addChatText(role,conent);
		return {seg:UserGuess,result:(result),preSeg:"1HCQDFO2R4",outlet:"1HCQDFO2R5"};
	};
	Ready.jaxId="1HCQDFO2R4"
	Ready.url="Ready@"+agentURL
	
	segs["UserGuess"]=UserGuess=async function(input){//:1HCQDFO2R6
		let prompt=("Please input")||input;
		let placeholder=("");
		let text=("");
		let result="";
		result=await session.askChatInput({type:"input",prompt:prompt,placeholder:placeholder,text:text});
		session.addChatText("user",result);
		return {seg:AIReply,result:(result),preSeg:"1HCQDFO2R6",outlet:"1HCQDFO2R7"};
	};
	UserGuess.jaxId="1HCQDFO2R6"
	UserGuess.url="UserGuess@"+agentURL
	
	segs["AIReply"]=AIReply=async function(input){//:1HCQDFO2R8
		let result;
		let opts={
			mode:"gpt-3.5-turbo",
			maxToken:2000,
			temperature:0,
			topP:1,
			fqcP:0,
			prcP:0,
			secret:false
		};
		let messages=[
			{role:"system",content:`You are an AI playing a guessing game with the user. You have an item that the user needs to guess.
The item is ${context.objName}
In each conversation, the user guesses what the item is or asks you questions about the item.
When the user asks a question about the item, you can only respond with 'Yes', 'No', or 'Uncertain' based on the item to be guessed.
When the user guesses what the item is, if user guesses correctly, respond with 'You win' and congrate user, otherwise, respond with "No.".
When user gives up, respond with 'You lose' and tell user the correct answer.
You always reply with English.`},
		];
		messages.push(...AIReply.messages);
		messages.push({role:"user",content:`User guess / question: "${input}"\n Please reply in English.`});
		
		result=await session.callSegLLM("AIReply@"+agentURL,opts,messages);
		AIReply.messages.push({role:"user",content:input});
		AIReply.messages.push({role:"assistant",content:result});
		if(AIReply.messages.length>10){AIReply.messages.splice(0,2);}
		Object.assign(context,{
			"round":context.round+1
		});
		return {seg:ShowReply,result:(result),preSeg:"1HCQDFO2R8",outlet:"1HCQDFO2R9"};
	};
	AIReply.jaxId="1HCQDFO2R8"
	AIReply.url="AIReply@"+agentURL
	AIReply.messages=[];
	segs["ShowReply"]=ShowReply=async function(input){//:1HCQDFO2R10
		let result=input;
		let role="assistant";
		let conent=input;
		session.addChatText(role,conent);
		return {seg:CheckOver,result:(result),preSeg:"1HCQDFO2R10",outlet:"1HCQDFO2R11"};
	};
	ShowReply.jaxId="1HCQDFO2R10"
	ShowReply.url="ShowReply@"+agentURL
	
	segs["CheckOver"]=CheckOver=async function(input){//:1HCQDFO2R12
		/*#{1HCQDFO2R12Start*/
		if(input.toLowerCase().indexOf(context.objName.toLowerCase())<0 && input.indexOf("You win")<0){
			input="GuessMore";
		}else{
			input="GameOver";
		}
		/*}#1HCQDFO2R12Start*/
		if(input==="GuessMore"){
			return {seg:UserGuess,result:(input),preSeg:"1HCQDFO2R12",outlet:"1HCQDFO2R13"};
		}
		/*#{1HCQDFO2R12Post*/
		/*}#1HCQDFO2R12Post*/
		return {seg:OverAsk,result:(input),preSeg:"1HCQDFO2R12",outlet:"1HCQDFO2R14"};
	};
	CheckOver.jaxId="1HCQDFO2R12"
	CheckOver.url="CheckOver@"+agentURL
	
	segs["OverAsk"]=OverAsk=async function(input){//:1HCQDFO2R15
		let prompt=(`Do you like a new game or maybe we chat more about ${context.objName}?`)||input;
		let items=[
			{text:"Exit",code:0},
			{text:"Chat more about it!",code:1},
			{text:"New Game",code:2},
		];
		let result="";
		let item=null;
		[result,item]=await session.askUserRaw({type:"menu",prompt:prompt,items:items});
		if(item.code===0){return {seg:GameEnd,result:(result),preSeg:"1HCQDFO2R15",outlet:"1HDHH7OH20"};}
		if(item.code===1){return {seg:StartChat,result:(result),preSeg:"1HCQDFO2R15",outlet:"1HDHH7OH21"};}
		if(item.code===2){return {seg:GenNames,result:(result),preSeg:"1HCQDFO2R15",outlet:"1HDHH7OH22"};}
		return {result:result};
	
	};
	OverAsk.jaxId="1HCQDFO2R15"
	OverAsk.url="OverAsk@"+agentURL
	
	segs["AIChatRely"]=AIChatRely=async function(input){//:1HCQDFO2R16
		let result;
		let opts={
			mode:"gpt-3.5-turbo",
			maxToken:0,
			temperature:0,
			topP:1,
			fqcP:0,
			prcP:0,
			secret:false
		};
		let messages=[
			{role:"system",content:`You are an AI expert about ${context.objName}. Chat to help user learn more about ${context.objName}.`},
		];
		messages.push({role:"user",content:input});
		
		result=await session.callSegLLM("AIChatRely@"+agentURL,opts,messages);
		return {seg:ShowChatReply,result:(result),preSeg:"1HCQDFO2R16",outlet:"1HCQDFO2R17"};
	};
	AIChatRely.jaxId="1HCQDFO2R16"
	AIChatRely.url="AIChatRely@"+agentURL
	segs["WaitChat"]=WaitChat=async function(input){//:1HCQDFO2R18
		let prompt=("Please input")||input;
		let placeholder=("");
		let text=("");
		let result="";
		result=await session.askChatInput({type:"input",prompt:prompt,placeholder:placeholder,text:text});
		session.addChatText("user",result);
		return {seg:AIChatRely,result:(result),preSeg:"1HCQDFO2R18",outlet:"1HCQDFO2R19"};
	};
	WaitChat.jaxId="1HCQDFO2R18"
	WaitChat.url="WaitChat@"+agentURL
	
	segs["StartChat"]=StartChat=async function(input){//:1HCQDFO2R20
		let result=input;
		let role="assistant";
		let conent=`Cool! Let's talk more about ${context.objName}!`;
		session.addChatText(role,conent);
		return {seg:WaitChat,result:(result),preSeg:"1HCQDFO2R20",outlet:"1HCQDFO2R21"};
	};
	StartChat.jaxId="1HCQDFO2R20"
	StartChat.url="StartChat@"+agentURL
	
	segs["ShowChatReply"]=ShowChatReply=async function(input){//:1HCQDFO2Q0
		let result=input;
		let role="assistant";
		let conent=input;
		/*#{1HCQDFO2Q0PreCodes*/
		/*}#1HCQDFO2Q0PreCodes*/
		session.addChatText(role,conent);
		/*#{1HCQDFO2Q0PostCodes*/
		result="";
		/*}#1HCQDFO2Q0PostCodes*/
		return {seg:WaitChat,result:(result),preSeg:"1HCQDFO2Q0",outlet:"1HCQDFO2R22"};
	};
	ShowChatReply.jaxId="1HCQDFO2Q0"
	ShowChatReply.url="ShowChatReply@"+agentURL
	
	segs["GameEnd"]=GameEnd=async function(input){//:1HCQDFO2Q1
		let result=input;
		let role="assistant";
		let conent="Bye! Hope to see you soon!";
		session.addChatText(role,conent);
		return {result:result};
	};
	GameEnd.jaxId="1HCQDFO2Q1"
	GameEnd.url="GameEnd@"+agentURL
	
	agent={
		isAIAgent:true,
		name:"guess_game",
		url:agentURL,
		autoStart:true,
		jaxId:"1HCQBLMCQ0",
		context:context,
		livingSeg:null,
		execChat:async function(input){
			let result;
			/*#{1HCQBLMCQ0PreEntry*/
			/*}#1HCQBLMCQ0PreEntry*/
			result={seg:Start,"input":input};
			/*#{1HCQBLMCQ0PostEntry*/
			/*}#1HCQBLMCQ0PostEntry*/
			return result;
		},
		/*#{1HCQBLMCQ0MoreAgentAttrs*/
		/*}#1HCQBLMCQ0MoreAgentAttrs*/
	};
	/*#{1HCQBLMCQ0PostAgent*/
	/*}#1HCQBLMCQ0PostAgent*/
	return agent;
};
/*#{1HCQBLMCQ0ExCodes*/
/*}#1HCQBLMCQ0ExCodes*/


export default guess_game;
export{guess_game};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DocAIAgent",
//	"jaxId": "1HCQBLMCQ0",
//	"editVersion": 28,
//	"attrs": {
//		"editObjs": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1HCQBLMCR0",
//			"editVersion": 2,
//			"attrs": {
//				"guess_game": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1HCQBLMCR4",
//					"editVersion": 34,
//					"attrs": {
//						"constructArgs": {
//							"type": "object",
//							"jaxId": "1HCQBLMCR5",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HCQBLMCS0",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"functions": {
//							"type": "object",
//							"def": "Functions",
//							"jaxId": "1HCQBLMCS1",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false"
//					},
//					"mockups": {}
//				}
//			}
//		},
//		"agent": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1HCQBLMCR1",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"segs": {
//			"type": "array",
//			"attrs": [
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1HCQDFO2Q2",
//					"editVersion": 115,
//					"attrs": {
//						"id": "Start",
//						"label": "",
//						"x": "130",
//						"y": "80",
//						"context": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HCQDFO2U0",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"role": "Assistant",
//						"text": "Let's play a mind game...",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HCQDFO2Q3",
//							"editVersion": 59,
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。",
//								"showLine": "true"
//							},
//							"linkedSeg": "1HCQDFO2R0"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "callLLM",
//					"jaxId": "1HCQDFO2R0",
//					"editVersion": 144,
//					"attrs": {
//						"id": "GenNames",
//						"label": "Generates Names",
//						"x": "250",
//						"y": "180",
//						"context": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HCQDFO2U1",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"desc": "执行一次LLM调用。",
//						"codes": "false",
//						"mkpInput": "10",
//						"mode": "GPT-3.5",
//						"system": "Each time you interact with the user, imagine a few things randomly and tell the user their names. Please only answer with the names of the items, without including any other text.",
//						"temperature": "0",
//						"maxToken": "1000",
//						"topP": "1",
//						"fqcP": "0",
//						"prcP": "0",
//						"messages": {
//							"type": "array",
//							"attrs": []
//						},
//						"prompt": "#`Imagine 10 random things, anything is fine, feel free to be imaginative\nPlease only provide the English names of the things, without including color, size, or other information. Separate the names of the things with semicolons.`",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HCQDFO2R1",
//							"editVersion": 66,
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。",
//								"showLine": "true"
//							},
//							"linkedSeg": "1HCQDFO2R2"
//						},
//						"secret": "true",
//						"keepChat": "No",
//						"apiFiles": {
//							"type": "array",
//							"def": "FileArray",
//							"attrs": []
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1HCQDFO2R2",
//					"editVersion": 112,
//					"attrs": {
//						"id": "PickName",
//						"label": "Random pick one from names",
//						"x": "440",
//						"y": "270",
//						"context": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HCQDFO2U2",
//							"editVersion": 8,
//							"attrs": {
//								"objName": {
//									"type": "string",
//									"valText": "#objName"
//								}
//							}
//						},
//						"desc": "这是一个AISeg。",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HCQDFO2R3",
//							"editVersion": 66,
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。",
//								"showLine": "true"
//							},
//							"linkedSeg": "1HCQDFO2R4"
//						},
//						"result": ""
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1HCQDFO2R4",
//					"editVersion": 128,
//					"attrs": {
//						"id": "Ready",
//						"label": "Ready to go!",
//						"x": "670",
//						"y": "180",
//						"context": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HCQDFO2U3",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"role": "Assistant",
//						"text": "I have a item in mind, can you guess what it is?",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HCQDFO2R5",
//							"editVersion": 66,
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。",
//								"showLine": "true"
//							},
//							"linkedSeg": "1HCQDFO2R6"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "askChat",
//					"jaxId": "1HCQDFO2R6",
//					"editVersion": 219,
//					"attrs": {
//						"id": "UserGuess",
//						"label": "Wait user guess",
//						"x": "830",
//						"y": "270",
//						"context": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HCQDFO2U4",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"prompt": "Please input",
//						"placeholder": "",
//						"text": "",
//						"file": "false",
//						"showText": "true",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HCQDFO2R7",
//							"editVersion": 155,
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。",
//								"showLine": "true"
//							},
//							"linkedSeg": "1HCQDFO2R8"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "callLLM",
//					"jaxId": "1HCQDFO2R8",
//					"editVersion": 305,
//					"attrs": {
//						"id": "AIReply",
//						"label": "Generate reply",
//						"x": "1010",
//						"y": "180",
//						"context": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HCQDFO2U5",
//							"editVersion": 8,
//							"attrs": {
//								"round": {
//									"type": "int",
//									"valText": "#context.round+1"
//								}
//							}
//						},
//						"desc": "执行一次LLM调用。",
//						"codes": "false",
//						"mkpInput": "is it alive?",
//						"mode": "GPT-3.5",
//						"system": "#`You are an AI playing a guessing game with the user. You have an item that the user needs to guess.\nThe item is ${context.objName}\nIn each conversation, the user guesses what the item is or asks you questions about the item.\nWhen the user asks a question about the item, you can only respond with 'Yes', 'No', or 'Uncertain' based on the item to be guessed.\nWhen the user guesses what the item is, if user guesses correctly, respond with 'You win' and congrate user, otherwise, respond with \"No.\".\nWhen user gives up, respond with 'You lose' and tell user the correct answer.\nYou always reply with English.`",
//						"temperature": "0",
//						"maxToken": "2000",
//						"topP": "1",
//						"fqcP": "0",
//						"prcP": "0",
//						"messages": {
//							"type": "array",
//							"attrs": []
//						},
//						"prompt": "#`User guess / question: \"${input}\"\\n Please reply in English.`",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HCQDFO2R9",
//							"editVersion": 150,
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。",
//								"showLine": "true"
//							},
//							"linkedSeg": "1HCQDFO2R10"
//						},
//						"secret": "false",
//						"keepChat": "10 messages",
//						"apiFiles": {
//							"type": "array",
//							"def": "FileArray",
//							"attrs": []
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1HCQDFO2R10",
//					"editVersion": 212,
//					"attrs": {
//						"id": "ShowReply",
//						"label": "New AI Seg",
//						"x": "1160",
//						"y": "270",
//						"context": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HCQDFO2U6",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"role": "Assistant",
//						"text": "#input",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HCQDFO2R11",
//							"editVersion": 150,
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。",
//								"showLine": "true"
//							},
//							"linkedSeg": "1HCQDFO2R12"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "brunch",
//					"jaxId": "1HCQDFO2R12",
//					"editVersion": 208,
//					"attrs": {
//						"id": "CheckOver",
//						"label": "Check if game is over",
//						"x": "1300",
//						"y": "360",
//						"context": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HCQDFO2U7",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"desc": "这是一个AISeg。",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HCQDFO2R14",
//							"editVersion": 61,
//							"attrs": {
//								"id": "GameOver",
//								"desc": "输出节点。",
//								"showLine": "true"
//							},
//							"linkedSeg": "1HCQDFO2R15"
//						},
//						"outlets": {
//							"type": "array",
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1HCQDFO2R13",
//									"editVersion": 151,
//									"attrs": {
//										"id": "GuessMore",
//										"condition": "",
//										"codes": "false",
//										"ouput": "",
//										"desc": "条件输出节点。"
//									},
//									"linkedSeg": "1HCQDFO2U8"
//								}
//							]
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "askMenu",
//					"jaxId": "1HCQDFO2R15",
//					"editVersion": 129,
//					"attrs": {
//						"id": "OverAsk",
//						"label": "Ask user what to do",
//						"x": "1550",
//						"y": "200",
//						"context": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HCQDFO2U9",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"prompt": "#`Do you like a new game or maybe we chat more about ${context.objName}?`",
//						"multi": "false",
//						"outlets": {
//							"type": "array",
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1HDHH7OH20",
//									"editVersion": 43,
//									"attrs": {
//										"id": "Exit",
//										"text": "Exit"
//									},
//									"linkedSeg": "1HCQDFO2Q1"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1HDHH7OH21",
//									"editVersion": 43,
//									"attrs": {
//										"id": "Chats",
//										"text": "Chat more about it!"
//									},
//									"linkedSeg": "1HCQDFO2R20"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIButtonOutlet",
//									"jaxId": "1HDHH7OH22",
//									"editVersion": 46,
//									"attrs": {
//										"id": "New game",
//										"text": "New Game"
//									},
//									"linkedSeg": "1HCQDFO2U10"
//								}
//							]
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1HCQDFO2U8",
//					"editVersion": 82,
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "1540",
//						"y": "440",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HCQDFO2U11",
//							"editVersion": 44,
//							"attrs": {
//								"id": "Summary",
//								"desc": "输出节点。",
//								"showLine": "true"
//							},
//							"linkedSeg": "1HCQDFO2U12"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1HCQDFO2U12",
//					"editVersion": 70,
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "860",
//						"y": "440",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HCQDFO2U13",
//							"editVersion": 44,
//							"attrs": {
//								"id": "Summary",
//								"desc": "输出节点。",
//								"showLine": "true"
//							},
//							"linkedSeg": "1HCQDFO2R6"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1HCQDFO2U10",
//					"editVersion": 86,
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "1770",
//						"y": "490",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HCQDFO2U14",
//							"editVersion": 34,
//							"attrs": {
//								"id": "Summary",
//								"desc": "输出节点。",
//								"showLine": "true"
//							},
//							"linkedSeg": "1HCQDFO2U15"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1HCQDFO2U15",
//					"editVersion": 74,
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "200",
//						"y": "440",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HCQDFO2U16",
//							"editVersion": 34,
//							"attrs": {
//								"id": "Summary",
//								"desc": "输出节点。",
//								"showLine": "true"
//							},
//							"linkedSeg": "1HCQDFO2R0"
//						},
//						"dir": "B2T"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "callLLM",
//					"jaxId": "1HCQDFO2R16",
//					"editVersion": 159,
//					"attrs": {
//						"id": "AIChatRely",
//						"label": "Get AI reply",
//						"x": "2140",
//						"y": "200",
//						"context": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HCQDFO2V0",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"desc": "执行一次LLM调用。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"mode": "GPT-3.5",
//						"system": "#`You are an AI expert about ${context.objName}. Chat to help user learn more about ${context.objName}.`",
//						"temperature": "0",
//						"maxToken": "0",
//						"topP": "1",
//						"fqcP": "0",
//						"prcP": "0",
//						"messages": {
//							"type": "array",
//							"attrs": []
//						},
//						"prompt": "#input",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HCQDFO2R17",
//							"editVersion": 40,
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。",
//								"showLine": "true"
//							},
//							"linkedSeg": "1HCQDFO2Q0"
//						},
//						"secret": "false",
//						"keepChat": "No",
//						"apiFiles": {
//							"type": "array",
//							"def": "FileArray",
//							"attrs": []
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "askChat",
//					"jaxId": "1HCQDFO2R18",
//					"editVersion": 109,
//					"attrs": {
//						"id": "WaitChat",
//						"label": "Wait user chat",
//						"x": "1990",
//						"y": "110",
//						"context": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HCQDFO2V1",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"prompt": "Please input",
//						"placeholder": "",
//						"text": "",
//						"file": "false",
//						"showText": "true",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HCQDFO2R19",
//							"editVersion": 41,
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。",
//								"showLine": "true"
//							},
//							"linkedSeg": "1HCQDFO2R16"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1HCQDFO2R20",
//					"editVersion": 101,
//					"attrs": {
//						"id": "StartChat",
//						"label": "Start chat",
//						"x": "1850",
//						"y": "200",
//						"context": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HCQDFO2V2",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"role": "Assistant",
//						"text": "#`Cool! Let's talk more about ${context.objName}!`",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HCQDFO2R21",
//							"editVersion": 37,
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。",
//								"showLine": "true"
//							},
//							"linkedSeg": "1HCQDFO2R18"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1HCQDFO2Q0",
//					"editVersion": 134,
//					"attrs": {
//						"id": "ShowChatReply",
//						"label": "Show reply",
//						"x": "2270",
//						"y": "110",
//						"context": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HCQDFO2V3",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"desc": "这是一个AISeg。",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"role": "Assistant",
//						"text": "#input",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HCQDFO2R22",
//							"editVersion": 40,
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。",
//								"showLine": "true"
//							},
//							"linkedSeg": "1HCQDFO2V4"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1HCQDFO2V4",
//					"editVersion": 106,
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "2440",
//						"y": "30",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HCQDFO2V5",
//							"editVersion": 37,
//							"attrs": {
//								"id": "Summary",
//								"desc": "输出节点。",
//								"showLine": "true"
//							},
//							"linkedSeg": "1HCQDFO2V6"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1HCQDFO2V6",
//					"editVersion": 86,
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "2060",
//						"y": "30",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HCQDFO2V7",
//							"editVersion": 37,
//							"attrs": {
//								"id": "Summary",
//								"desc": "输出节点。",
//								"showLine": "true"
//							},
//							"linkedSeg": "1HCQDFO2R18"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1HCQDFO2Q1",
//					"editVersion": 97,
//					"attrs": {
//						"id": "GameEnd",
//						"label": "Game over!",
//						"x": "1760",
//						"y": "80",
//						"context": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HCQDFO2V8",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"role": "Assistant",
//						"text": "Bye! Hope to see you soon!",
//						"outlet": {
//							"type": "aioutlet",
//							"def": "AISegOutlet",
//							"jaxId": "1HCQDFO2R23",
//							"editVersion": 34,
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。",
//								"showLine": "true"
//							}
//						}
//					}
//				}
//			]
//		},
//		"entry": "",
//		"autoStart": "true",
//		"debug": "true",
//		"localVars": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1HCQBLMCR2",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"context": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1HCQBLMCR3",
//			"editVersion": 12,
//			"attrs": {
//				"objName": {
//					"type": "string",
//					"valText": "Apple"
//				},
//				"round": {
//					"type": "int",
//					"valText": "0"
//				}
//			}
//		},
//		"desc": "这是一个AI代理。"
//	}
//}