import {VFACT} from "/@vfact";
import {briefCode} from "./briefcode.js";

const $ln=VFACT.lanCode;
async function filterAPIDescriptor(code){
	let session,val;
	session=this.session;
	//Test confirm:
	val=await session.askUser({type:"confirm",text:"Do you like to brief the code to reduce token usage?",button1:"Yes",button2:"No",button3:"A little"});
	if(val){
		//Brief code:
		code=briefCode(code,val===2);
	}
	return code;
};

export default filterAPIDescriptor;
export {filterAPIDescriptor};
