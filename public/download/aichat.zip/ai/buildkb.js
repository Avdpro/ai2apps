import pathLib from "/@path";
import {tabFS} from "/@tabos";

async function buildKB(inputPath){
	let entry,dirPath,list,newList,lastKBTime,json,kbInfo,extName,path,content,brief;
	dirPath=inputPath;
	entry=await tabFS.getEntry(dirPath);
	if(!entry){
		throw Error(`${path} is not a file or dir path.`);
	}
	if(!entry.dir){
		dirPath=pathLib.dirname(dirPath);
	}
	try{
		json=await tabFS.readFile(pathLib.join(dirPath,"knowledge.base.json"),"utf8");
		kbInfo=JSON.parse(json);
		lastKBTime=kbInfo.time;
	}catch(err){
		lastKBTime=0;
		kbInfo={
			time:0,docs:{}
		};
	}
	list=await tabFS.getEntries(dirPath);
	for(entry of list){
		extName=pathLib.extname(entry.name).toLowerCase();
		if(extName!==".md" && extName!==".pdf" && extName!==".txt" && extName!==".html"){
			//Not the type we can read...
			continue;
		}
		if(entry.modifyTime<lastKBTime &&kbInfo[entry.name]){
			//Current info is ok
			continue;
		}
		path=pathLib.join(dirPath,entry.name);
		content=await tabFS.readFile(path,"utf8");
		
		brief=await this.pipeChat("./docinfo.aichat",content);
		kbInfo.docs[entry.name]=brief;
	}
	kbInfo.time=Date.now();
	json=JSON.stringify(kbInfo,null,"\t");
	await tabFS.writeFile(pathLib.join(dirPath,"knowledge.base.json"),json,"utf8");
	return `Knowledge base for ${dirPath} is updated.`
}

export default buildKB;
export {buildKB};