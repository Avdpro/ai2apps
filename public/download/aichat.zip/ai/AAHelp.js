//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import pathLib from "/@path";
import inherits from "/@inherits";
import Base64 from "/@tabos/utils/base64.js";
import {trimJSON} from "/@aichat/utils.js";
/*#{1HS3OVF3D0MoreImports*/
/*}#1HS3OVF3D0MoreImports*/
const agentURL=(new URL(import.meta.url)).pathname;
const basePath=pathLib.dirname(agentURL);
const $ln=VFACT.lanCode||"EN";
/*#{1HS3OVF3D0StartDoc*/
/*}#1HS3OVF3D0StartDoc*/
//----------------------------------------------------------------------------
let AAHelp=async function(session){
	let context,globalContext;
	let self;
	let CheckContext,ReadContext,LLMHelp,Output;
	let docContext="";
	
	/*#{1HS3OVF3D0LocalVals*/
	/*}#1HS3OVF3D0LocalVals*/
	
	/*#{1HS3OVF3D0PreContext*/
	/*}#1HS3OVF3D0PreContext*/
	globalContext=session.globalContext;
	context={
		"question":"What is AI2Apps",
		/*#{1HS3OVF3D4ExCtxAttrs*/
		/*}#1HS3OVF3D4ExCtxAttrs*/
	};
	context=VFACT.flexState(context);
	/*#{1HS3OVF3D0PostContext*/
	/*}#1HS3OVF3D0PostContext*/
	let agent,segs={};
	segs["CheckContext"]=CheckContext=async function(input){//:1HS3PJ4F10
		/*#{1HS3PJ4F10Start*/
		/*}#1HS3PJ4F10Start*/
		if(!docContext){
			return {seg:ReadContext,result:(input),preSeg:"1HS3PJ4F10",outlet:"1HS3PJ4F11"};
		}
		/*#{1HS3PJ4F10Post*/
		/*}#1HS3PJ4F10Post*/
		return {seg:LLMHelp,result:(input),preSeg:"1HS3PJ4F10",outlet:"1HS3PJ4F12"};
	};
	CheckContext.jaxId="1HS3PJ4F10"
	CheckContext.url="CheckContext@"+agentURL
	
	segs["ReadContext"]=ReadContext=async function(input){//:1HS3PJ4F13
		let content=null;
		let result=null;
		/*#{1HS3PJ4F13PreCodes*/
		/*}#1HS3PJ4F13PreCodes*/
		{
			let tabFS=(await import("/@tabos")).tabFS;
			let fileName="aahelp.md";
			fileName=fileName[0]==="/"?fileName:basePath+"/"+fileName;
			fileName=fileName.startsWith("/~/")?fileName.substring(2):fileName;
			fileName=fileName.startsWith("//")?fileName.substring(1):fileName;
			try{
				content=await tabFS.readFile(fileName,"utf8");
				/*#{1HS3PJ4F13LoadData*/
				/*}#1HS3PJ4F13LoadData*/
			}catch(err){
				content=null;
			}
		}
		/*#{1HS3PJ4F13PreMerge*/
		/*}#1HS3PJ4F13PreMerge*/
		result=content;
		/*#{1HS3PJ4F13FinCodes*/
		docContext=content;
		/*}#1HS3PJ4F13FinCodes*/
		return {seg:LLMHelp,result:(result),preSeg:"1HS3PJ4F13",outlet:"1HS3PJ4F14"};
	};
	ReadContext.jaxId="1HS3PJ4F13"
	ReadContext.url="ReadContext@"+agentURL
	
	segs["LLMHelp"]=LLMHelp=async function(input){//:1HS3PJ4F20
		let prompt;
		let result;
		
		let opts={
			platform:"OpenAI",
			mode:"gpt-4-1106-preview",
			maxToken:2000,
			temperature:0,
			topP:1,
			fqcP:0,
			prcP:0,
			secret:false,
			responseFormat:"text"
		};
		let chatMem=LLMHelp.messages
		let seed="";
		if(seed!==undefined){opts.seed=seed;}
		let messages=[
			{role:"system",content:`
你是 AI2Apps 系统根据背景资料解答用户问题的 AI Agent。
背景资料：
${docContext}

`
},
		];
		messages.push(...chatMem);
		prompt=context.question;
		if(prompt!==null){
			messages.push({role:"user",content:prompt});
		}
		result=await session.callSegLLM("LLMHelp@"+agentURL,opts,messages,true);
		chatMem.push({role:"user",content:prompt});
		chatMem.push({role:"assistant",content:result});
		if(chatMem.length>10){
			let removedMsgs=chatMem.splice(0,2);
		}
		return {seg:Output,result:(result),preSeg:"1HS3PJ4F20",outlet:"1HS3PJ4F21"};
	};
	LLMHelp.jaxId="1HS3PJ4F20"
	LLMHelp.url="LLMHelp@"+agentURL
	LLMHelp.messages=[];
	
	segs["Output"]=Output=async function(input){//:1HS3PJ4F22
		let result=input;
		let role="assistant";
		let content=input;
		session.addChatText(role,content);
		return {result:result};
	};
	Output.jaxId="1HS3PJ4F22"
	Output.url="Output@"+agentURL
	
	agent={
		isAIAgent:true,
		session:session,
		name:"AAHelp",
		url:agentURL,
		autoStart:true,
		jaxId:"1HS3OVF3D0",
		context:context,
		livingSeg:null,
		execChat:async function(input){
			let result;
			/*#{1HS3OVF3D0PreEntry*/
			if(input.question){
				context.question=input.question;
			}
			/*}#1HS3OVF3D0PreEntry*/
			result={seg:CheckContext,"input":input};
			/*#{1HS3OVF3D0PostEntry*/
			/*}#1HS3OVF3D0PostEntry*/
			return result;
		},
		/*#{1HS3OVF3D0MoreAgentAttrs*/
		/*}#1HS3OVF3D0MoreAgentAttrs*/
	};
	/*#{1HS3OVF3D0PostAgent*/
	/*}#1HS3OVF3D0PostAgent*/
	return agent;
};
/*#{1HS3OVF3D0ExCodes*/
/*}#1HS3OVF3D0ExCodes*/


export default AAHelp;
export{AAHelp};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DocAIAgent",
//	"jaxId": "1HS3OVF3D0",
//	"attrs": {
//		"editObjs": {
//			"jaxId": "1HS3OVF3D1",
//			"attrs": {
//				"AAHelp": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1HS3OVF3D7",
//					"attrs": {
//						"constructArgs": {
//							"jaxId": "1HS3OVF3E0",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1HS3OVF3E1",
//							"attrs": {}
//						},
//						"functions": {
//							"jaxId": "1HS3OVF3E2",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false",
//						"exportType": "UI Data Template"
//					},
//					"mockups": {}
//				}
//			}
//		},
//		"agent": {
//			"jaxId": "1HS3OVF3D2",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "aiseg",
//					"def": "brunch",
//					"jaxId": "1HS3PJ4F10",
//					"attrs": {
//						"id": "CheckContext",
//						"label": "New AI Seg",
//						"x": "120",
//						"y": "260",
//						"context": {
//							"jaxId": "1HS3PJ4F50",
//							"attrs": {}
//						},
//						"global": {
//							"jaxId": "1HS3PJ4F51",
//							"attrs": {}
//						},
//						"desc": "This is an AISeg.",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"outlet": {
//							"jaxId": "1HS3PJ4F12",
//							"attrs": {
//								"id": "Default",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1HS3PJ4F52"
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1HS3PJ4F11",
//									"attrs": {
//										"id": "NoContext",
//										"condition": "!docContext",
//										"codes": "false",
//										"ouput": "",
//										"desc": "Condition outlet."
//									},
//									"linkedSeg": "1HS3PJ4F13"
//								}
//							]
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "load",
//					"jaxId": "1HS3PJ4F13",
//					"attrs": {
//						"id": "ReadContext",
//						"label": "New AI Seg",
//						"x": "400",
//						"y": "170",
//						"context": {
//							"jaxId": "1HS3PJ4F53",
//							"attrs": {}
//						},
//						"global": {
//							"jaxId": "1HS3PJ4F54",
//							"attrs": {}
//						},
//						"desc": "This is an AISeg.",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"fileName": "aahelp.md",
//						"read": "Text",
//						"outlet": {
//							"jaxId": "1HS3PJ4F14",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1HS3PJ4F20"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "callLLM",
//					"jaxId": "1HS3PJ4F20",
//					"attrs": {
//						"id": "LLMHelp",
//						"label": "New AI Seg",
//						"x": "650",
//						"y": "250",
//						"context": {
//							"jaxId": "1HS3PJ4F55",
//							"attrs": {}
//						},
//						"global": {
//							"jaxId": "1HS3PJ4F56",
//							"attrs": {}
//						},
//						"desc": "Excute a LLM call.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"platform": "OpenAI",
//						"mode": "GPT-4 Turbo",
//						"system": "#`\n你是 AI2Apps 系统根据背景资料解答用户问题的 AI Agent。\n背景资料：\n${docContext}\n\n`\n",
//						"temperature": "0",
//						"maxToken": "2000",
//						"topP": "1",
//						"fqcP": "0",
//						"prcP": "0",
//						"messages": {
//							"attrs": []
//						},
//						"prompt": "#context.question",
//						"seed": "",
//						"outlet": {
//							"jaxId": "1HS3PJ4F21",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1HS3PJ4F22"
//						},
//						"secret": "false",
//						"allowCheat": "false",
//						"GPTCheats": {
//							"attrs": []
//						},
//						"shareChatName": "",
//						"keepChat": "10 messages",
//						"clearChat": "2",
//						"apiFiles": {
//							"attrs": []
//						},
//						"parallelFunction": "false",
//						"responseFormat": "text"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connectorL",
//					"jaxId": "1HS3PJ4F52",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "400",
//						"y": "350",
//						"outlet": {
//							"jaxId": "1HS3PJ4F57",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1HS3PJ4F58"
//						},
//						"dir": "L2R"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connectorL",
//					"jaxId": "1HS3PJ4F58",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "530",
//						"y": "350",
//						"outlet": {
//							"jaxId": "1HS3PJ4F59",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1HS3PJ4F20"
//						},
//						"dir": "L2R"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1HS3PJ4F22",
//					"attrs": {
//						"id": "Output",
//						"label": "New AI Seg",
//						"x": "870",
//						"y": "250",
//						"context": {
//							"jaxId": "1HS3PJ4F510",
//							"attrs": {}
//						},
//						"global": {
//							"jaxId": "1HS3PJ4F511",
//							"attrs": {}
//						},
//						"desc": "This is an AISeg.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"role": "Assistant",
//						"text": "#input",
//						"outlet": {
//							"jaxId": "1HS3PJ4F23",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							}
//						}
//					}
//				}
//			]
//		},
//		"entry": "",
//		"autoStart": "true",
//		"debug": "true",
//		"localVars": {
//			"jaxId": "1HS3OVF3D3",
//			"attrs": {
//				"docContext": {
//					"type": "string",
//					"valText": ""
//				}
//			}
//		},
//		"context": {
//			"jaxId": "1HS3OVF3D4",
//			"attrs": {
//				"question": {
//					"type": "string",
//					"valText": "What is AI2Apps"
//				}
//			}
//		},
//		"globalMockup": {
//			"jaxId": "1HS3OVF3D5",
//			"attrs": {}
//		},
//		"desc": "This is an AI agent.",
//		"exportAPI": "false",
//		"apiArgs": {
//			"jaxId": "1HS3OVF3D6",
//			"attrs": {}
//		}
//	}
//}