//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import pathLib from "/@path";
import inherits from "/@inherits";
import Base64 from "/@tabos/utils/base64.js";
import {trimJSON} from "/@aichat/utils.js";
/*#{1HS3MPUJT0MoreImports*/
/*}#1HS3MPUJT0MoreImports*/
const agentURL=(new URL(import.meta.url)).pathname;
const basePath=pathLib.dirname(agentURL);
const $ln=VFACT.lanCode||"EN";
/*#{1HS3MPUJT0StartDoc*/
/*}#1HS3MPUJT0StartDoc*/
//----------------------------------------------------------------------------
let helper=async function(session){
	let context,globalContext;
	let self;
	let Greeting,AskChat,HandleChat,GetTask,CreatePrj,AAHelp,ShowReply;
	/*#{1HS3MPUJT0LocalVals*/
	/*}#1HS3MPUJT0LocalVals*/
	
	/*#{1HS3MPUJT0PreContext*/
	/*}#1HS3MPUJT0PreContext*/
	globalContext=session.globalContext;
	context={};
	context=VFACT.flexState(context);
	/*#{1HS3MPUJT0PostContext*/
	/*}#1HS3MPUJT0PostContext*/
	let agent,segs={};
	segs["Greeting"]=Greeting=async function(input){//:1HS3N4EMP0
		let result=input;
		let role="assistant";
		let content="这是AI2Apps的助理 AI Agent。你可以和我对话了解更多关于AI2Apps的话题，也可以告诉我你的需求，我会帮你创建AI Agent工程。";
		session.addChatText(role,content);
		return {seg:AskChat,result:(result),preSeg:"1HS3N4EMP0",outlet:"1HS3N4EMQ0"};
	};
	Greeting.jaxId="1HS3N4EMP0"
	Greeting.url="Greeting@"+agentURL
	
	segs["AskChat"]=AskChat=async function(input){//:1HS3NJNSO0
		let prompt=("Please input")||input;
		let placeholder=("");
		let text=("");
		let result="";
		result=await session.askChatInput({type:"input",prompt:prompt,placeholder:placeholder,text:text});
		session.addChatText("user",result);
		return {seg:HandleChat,result:(result),preSeg:"1HS3NJNSO0",outlet:"1HS3NJNSO1"};
	};
	AskChat.jaxId="1HS3NJNSO0"
	AskChat.url="AskChat@"+agentURL
	
	segs["HandleChat"]=HandleChat=async function(input){//:1HS3NJNSP0
		let prompt;
		let result;
		
		let opts={
			platform:"OpenAI",
			mode:"gpt-4-1106-preview",
			maxToken:2000,
			temperature:0,
			topP:1,
			fqcP:0,
			prcP:0,
			secret:false,
			responseFormat:"json_object"
		};
		let chatMem=HandleChat.messages
		let seed="";
		if(seed!==undefined){opts.seed=seed;}
		let messages=[
			{role:"system",content:"你是AI2Apps系统帮助 App 里，用于区分用户意图的 AI Agent。\n请分析用户的Prompt，并输出分析结果：\n\n#1 如果用户是询问有关AI2Apps系统的相关问题，请返回JSON对象，把用户的问题放在JSON对象的 \"question\" 变量里。\n例如：\n{\n\t\"question\":\"我怎么启动AI2Apps？\"\n}\n\n#2 如果用户是想创建一个 AI Agent，请返回JSON对象：\n2.1）把用户对 AI Agent 的需求放在JOSN对象的 \"agent\"变量里。\n2.2) 给 Agent 起一个简短的英文名字，要符合JS变量命名规则，首字母大写，放在JSON对象的 \"name\" 变量里。\n2.3）根据用户需求，生成 AI Agent 的系统设定 Prompt，放在JSON对象的 \"system\" 变量里。\n2.4）为这个AI Agent生成向用户打招呼的问候语，放在JSON对象的 \"greeting\" 变量里。\n例如：\n{\n\t\"agent\":\"文本翻译成中文的agent\",\n    \"name\":\"ChineseTranslator\",\n    \"system\":\"You are a Chinese-English translator. If user's message is in Chinese, you translate user's message English. If user's message is not Chinese, translate it into Chinese.\",\n\t\"greeting\":\"请告诉我需要翻译的内容\"\n}\n\n#3 如果用户的输入不满足#1和#2的情况，请作为通用的聊天机器人生成与用户对话的结果。返回JSON对象，把对话结果放到JSON对象的 \"reply\" 变量里。\n例如：\n{\n\t\"reply\":\"猫和狗都是很好的宠物呢。\"\n}\n\n"},
		];
		messages.push(...chatMem);
		prompt=input;
		if(prompt!==null){
			messages.push({role:"user",content:prompt});
		}
		result=await session.callSegLLM("HandleChat@"+agentURL,opts,messages,true);
		chatMem.push({role:"user",content:prompt});
		chatMem.push({role:"assistant",content:result});
		if(chatMem.length>10){
			let removedMsgs=chatMem.splice(0,2);
		}
		result=trimJSON(result);
		return {seg:GetTask,result:(result),preSeg:"1HS3NJNSP0",outlet:"1HS3NJNSP1"};
	};
	HandleChat.jaxId="1HS3NJNSP0"
	HandleChat.url="HandleChat@"+agentURL
	HandleChat.messages=[];
	
	segs["GetTask"]=GetTask=async function(input){//:1HS3NJNSP2
		if(!!input.agent){
			let output=input;
			return {seg:CreatePrj,result:(output),preSeg:"1HS3NJNSP2",outlet:"1HS3NJNSP3"};
		}
		if(!!input.question){
			let output=input;
			return {seg:AAHelp,result:(output),preSeg:"1HS3NJNSP2",outlet:"1HS3OTNRU0"};
		}
		return {seg:ShowReply,result:(input),preSeg:"1HS3NJNSP2",outlet:"1HS3NJNSP4"};
	};
	GetTask.jaxId="1HS3NJNSP2"
	GetTask.url="GetTask@"+agentURL
	
	segs["CreatePrj"]=CreatePrj=async function(input){//:1HS3NJNSP5
		let result;
		let sourcePath=pathLib.join(basePath,"./CreatePrj.js");
		let arg=input;
		result= await session.pipeChat(sourcePath,arg,false);
		return {seg:AskChat,result:(result),preSeg:"1HS3NJNSP5",outlet:"1HS3NJNSP6"};
	};
	CreatePrj.jaxId="1HS3NJNSP5"
	CreatePrj.url="CreatePrj@"+agentURL
	
	segs["AAHelp"]=AAHelp=async function(input){//:1HS3NJNSP7
		let result;
		let sourcePath=pathLib.join(basePath,"./AAHelp.js");
		let arg=input;
		result= await session.pipeChat(sourcePath,arg,false);
		return {seg:AskChat,result:(result),preSeg:"1HS3NJNSP7",outlet:"1HS3NJNSP8"};
	};
	AAHelp.jaxId="1HS3NJNSP7"
	AAHelp.url="AAHelp@"+agentURL
	
	segs["ShowReply"]=ShowReply=async function(input){//:1HS3OTNRU1
		let result=input;
		let role="assistant";
		let content=input.reply;
		session.addChatText(role,content);
		return {seg:AskChat,result:(result),preSeg:"1HS3OTNRU1",outlet:"1HS3OTNRU2"};
	};
	ShowReply.jaxId="1HS3OTNRU1"
	ShowReply.url="ShowReply@"+agentURL
	
	agent={
		isAIAgent:true,
		session:session,
		name:"helper",
		url:agentURL,
		autoStart:true,
		jaxId:"1HS3MPUJT0",
		context:context,
		livingSeg:null,
		execChat:async function(input){
			let result;
			/*#{1HS3MPUJT0PreEntry*/
			/*}#1HS3MPUJT0PreEntry*/
			result={seg:Greeting,"input":input};
			/*#{1HS3MPUJT0PostEntry*/
			/*}#1HS3MPUJT0PostEntry*/
			return result;
		},
		/*#{1HS3MPUJT0MoreAgentAttrs*/
		/*}#1HS3MPUJT0MoreAgentAttrs*/
	};
	/*#{1HS3MPUJT0PostAgent*/
	/*}#1HS3MPUJT0PostAgent*/
	return agent;
};
/*#{1HS3MPUJT0ExCodes*/
/*}#1HS3MPUJT0ExCodes*/


export default helper;
export{helper};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DocAIAgent",
//	"jaxId": "1HS3MPUJT0",
//	"attrs": {
//		"editObjs": {
//			"jaxId": "1HS3MPUJT1",
//			"attrs": {
//				"helper": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1HS3MPUJU0",
//					"attrs": {
//						"constructArgs": {
//							"jaxId": "1HS3MPUJU1",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1HS3MPUJU2",
//							"attrs": {}
//						},
//						"functions": {
//							"jaxId": "1HS3MPUJU3",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false",
//						"exportType": "UI Data Template"
//					},
//					"mockups": {}
//				}
//			}
//		},
//		"agent": {
//			"jaxId": "1HS3MPUJT2",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1HS3N4EMP0",
//					"attrs": {
//						"id": "Greeting",
//						"label": "New AI Seg",
//						"x": "60",
//						"y": "190",
//						"context": {
//							"jaxId": "1HS3N4EMQ1",
//							"attrs": {}
//						},
//						"global": {
//							"jaxId": "1HS3N4EMQ2",
//							"attrs": {}
//						},
//						"desc": "This is an AISeg.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"role": "Assistant",
//						"text": "这是AI2Apps的助理 AI Agent。你可以和我对话了解更多关于AI2Apps的话题，也可以告诉我你的需求，我会帮你创建AI Agent工程。",
//						"outlet": {
//							"jaxId": "1HS3N4EMQ0",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1HS3NJNSO0"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "askChat",
//					"jaxId": "1HS3NJNSO0",
//					"attrs": {
//						"id": "AskChat",
//						"label": "New AI Seg",
//						"x": "280",
//						"y": "190",
//						"context": {
//							"jaxId": "1HS3NJNST0",
//							"attrs": {}
//						},
//						"global": {
//							"jaxId": "1HS3NJNST1",
//							"attrs": {}
//						},
//						"desc": "This is an AISeg.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"prompt": "Please input",
//						"placeholder": "",
//						"text": "",
//						"file": "false",
//						"showText": "true",
//						"outlet": {
//							"jaxId": "1HS3NJNSO1",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1HS3NJNSP0"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "callLLM",
//					"jaxId": "1HS3NJNSP0",
//					"attrs": {
//						"id": "HandleChat",
//						"label": "New AI Seg",
//						"x": "500",
//						"y": "190",
//						"context": {
//							"jaxId": "1HS3NJNST2",
//							"attrs": {}
//						},
//						"global": {
//							"jaxId": "1HS3NJNST3",
//							"attrs": {}
//						},
//						"desc": "Excute a LLM call.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"platform": "OpenAI",
//						"mode": "GPT-4 Turbo",
//						"system": "你是AI2Apps系统帮助 App 里，用于区分用户意图的 AI Agent。\n请分析用户的Prompt，并输出分析结果：\n\n#1 如果用户是询问有关AI2Apps系统的相关问题，请返回JSON对象，把用户的问题放在JSON对象的 \"question\" 变量里。\n例如：\n{\n\t\"question\":\"我怎么启动AI2Apps？\"\n}\n\n#2 如果用户是想创建一个 AI Agent，请返回JSON对象：\n2.1）把用户对 AI Agent 的需求放在JOSN对象的 \"agent\"变量里。\n2.2) 给 Agent 起一个简短的英文名字，要符合JS变量命名规则，首字母大写，放在JSON对象的 \"name\" 变量里。\n2.3）根据用户需求，生成 AI Agent 的系统设定 Prompt，放在JSON对象的 \"system\" 变量里。\n2.4）为这个AI Agent生成向用户打招呼的问候语，放在JSON对象的 \"greeting\" 变量里。\n例如：\n{\n\t\"agent\":\"文本翻译成中文的agent\",\n    \"name\":\"ChineseTranslator\",\n    \"system\":\"You are a Chinese-English translator. If user's message is in Chinese, you translate user's message English. If user's message is not Chinese, translate it into Chinese.\",\n\t\"greeting\":\"请告诉我需要翻译的内容\"\n}\n\n#3 如果用户的输入不满足#1和#2的情况，请作为通用的聊天机器人生成与用户对话的结果。返回JSON对象，把对话结果放到JSON对象的 \"reply\" 变量里。\n例如：\n{\n\t\"reply\":\"猫和狗都是很好的宠物呢。\"\n}\n\n",
//						"temperature": "0",
//						"maxToken": "2000",
//						"topP": "1",
//						"fqcP": "0",
//						"prcP": "0",
//						"messages": {
//							"attrs": []
//						},
//						"prompt": "#input",
//						"seed": "",
//						"outlet": {
//							"jaxId": "1HS3NJNSP1",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1HS3NJNSP2"
//						},
//						"secret": "false",
//						"allowCheat": "false",
//						"GPTCheats": {
//							"attrs": []
//						},
//						"shareChatName": "",
//						"keepChat": "10 messages",
//						"clearChat": "2",
//						"apiFiles": {
//							"attrs": []
//						},
//						"parallelFunction": "false",
//						"responseFormat": "json_object"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "brunch",
//					"jaxId": "1HS3NJNSP2",
//					"attrs": {
//						"id": "GetTask",
//						"label": "New AI Seg",
//						"x": "740",
//						"y": "190",
//						"context": {
//							"jaxId": "1HS3NJNST4",
//							"attrs": {}
//						},
//						"global": {
//							"jaxId": "1HS3NJNST5",
//							"attrs": {}
//						},
//						"desc": "This is an AISeg.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"outlet": {
//							"jaxId": "1HS3NJNSP4",
//							"attrs": {
//								"id": "Default",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1HS3OTNRU1"
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1HS3NJNSP3",
//									"attrs": {
//										"id": "CreatePrj",
//										"condition": "!!input.agent",
//										"codes": "false",
//										"ouput": "#input",
//										"desc": "Condition outlet."
//									},
//									"linkedSeg": "1HS3NJNSP5"
//								},
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1HS3OTNRU0",
//									"attrs": {
//										"id": "AAHelp",
//										"condition": "!!input.question",
//										"codes": "false",
//										"ouput": "#input",
//										"desc": "Condition outlet."
//									},
//									"linkedSeg": "1HS3NJNSP7"
//								}
//							]
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "aiBot",
//					"jaxId": "1HS3NJNSP5",
//					"attrs": {
//						"id": "CreatePrj",
//						"label": "New AI Seg",
//						"x": "1030",
//						"y": "110",
//						"context": {
//							"jaxId": "1HS3NJNST6",
//							"attrs": {}
//						},
//						"global": {
//							"jaxId": "1HS3NJNST7",
//							"attrs": {}
//						},
//						"desc": "Call AI Agent, use it's output as result",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"source": "ai/CreatePrj.js",
//						"argument": "#input",
//						"secret": "false",
//						"outlet": {
//							"jaxId": "1HS3NJNSP6",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1HS3OTNS10"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "aiBot",
//					"jaxId": "1HS3NJNSP7",
//					"attrs": {
//						"id": "AAHelp",
//						"label": "New AI Seg",
//						"x": "990",
//						"y": "190",
//						"context": {
//							"jaxId": "1HS3NJNST8",
//							"attrs": {}
//						},
//						"global": {
//							"jaxId": "1HS3NJNST9",
//							"attrs": {}
//						},
//						"desc": "Call AI Agent, use it's output as result",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"source": "ai/AAHelp.js",
//						"argument": "#input",
//						"secret": "false",
//						"outlet": {
//							"jaxId": "1HS3NJNSP8",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1HS3OTNS10"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "output",
//					"jaxId": "1HS3OTNRU1",
//					"attrs": {
//						"id": "ShowReply",
//						"label": "New AI Seg",
//						"x": "970",
//						"y": "280",
//						"context": {
//							"jaxId": "1HS3OTNS11",
//							"attrs": {}
//						},
//						"global": {
//							"jaxId": "1HS3OTNS12",
//							"attrs": {}
//						},
//						"desc": "This is an AISeg.",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"role": "Assistant",
//						"text": "#input.reply",
//						"outlet": {
//							"jaxId": "1HS3OTNRU2",
//							"attrs": {
//								"id": "Result",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1HS3OTNS10"
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1HS3OTNS10",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "1160",
//						"y": "380",
//						"outlet": {
//							"jaxId": "1HS3OTNS13",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1HS3OTNS14"
//						},
//						"dir": "R2L"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1HS3OTNS14",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "310",
//						"y": "380",
//						"outlet": {
//							"jaxId": "1HS3OTNS20",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "Outlet."
//							},
//							"linkedSeg": "1HS3NJNSO0"
//						},
//						"dir": "R2L"
//					}
//				}
//			]
//		},
//		"entry": "Greeting",
//		"autoStart": "true",
//		"debug": "true",
//		"localVars": {
//			"jaxId": "1HS3MPUJT3",
//			"attrs": {}
//		},
//		"context": {
//			"jaxId": "1HS3MPUJT4",
//			"attrs": {}
//		},
//		"globalMockup": {
//			"jaxId": "1HS3MPUJT5",
//			"attrs": {}
//		},
//		"desc": "This is an AI agent.",
//		"exportAPI": "false",
//		"apiArgs": {
//			"jaxId": "1HS3MPUJT6",
//			"attrs": {}
//		}
//	}
//}