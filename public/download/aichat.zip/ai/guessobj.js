import {ChatAction} from "/@aichat/chataction.js"

//----------------------------------------------------------------------------
async function init(){
	let objNames,num,objName;
	console.log("filterInit called.");
	objNames=await this.pipeChat("./objname.aichat","随机想象20个东西，什么东西都行，可以天马行空一点\n请只提供东西的英文名称，不要包括颜色，大小等其它信息，东西名称直接用分号隔开。");
	objNames=objNames.split(";");
	num=objNames.length-1;
	objName=objNames[Math.floor(Math.random()*num)];
	this.userMsgPrefix=`The item to guess is: ${objName}.\nAnswer the user based on the following questions:\n\n`;
	this.name2Guess=objName;
	return objName;
};

//----------------------------------------------------------------------------
async function round(result){
	let item,session;
	if(!this.name2Guess){
		return result;
	}
	if(result.toLowerCase().indexOf(this.name2Guess.toLowerCase())<0 && result.indexOf("You win")<0){
		return result;
	}
	session=this.session;
	item=await session.askUser({
		type:"menu",text:"Do you want to have another game, or lets talkabout "+this.name2Guess+" a bit more?",
		items:[
			{text:"Let's have a new game!",code:"NewGame"},
			{text:"I'd like to talk more about "+this.name2Guess,code:"Talk"}
		]
	});
	if(item &&item.code==="NewGame"){
		await init.call(this);
		this.chatMsgs.splice(0);//Clear chat msg
		result=this.greeting;
		session.addChatText("assistant",result);
	}else{
		this.sysMsg=`You are an expert about ${this.name2Guess}.`;
		this.userMsgPrefix="";
		this.userMsgPostfix="";
		result=`Cool! Let's talk about ${this.name2Guess}!`;
		session.addChatText("assistant",result);
		this.chatMsgs.splice(0);//Clear chat msg
		this.name2Guess=null;
	}
	return result;
};

export {init,round};