//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import pathLib from "/@path";
import inherits from "/@inherits";
import Base64 from "/@tabos/utils/base64.js";
import {trimJSON} from "/@aichat/utils.js";
/*#{1I1NMG59H0MoreImports*/
/*}#1I1NMG59H0MoreImports*/
const agentURL=(new URL(import.meta.url)).pathname;
const basePath=pathLib.dirname(agentURL);
const $ln=VFACT.lanCode||"EN";
const argsTemplate={
	properties:{
		"argsTemplate":{
			"name":"argsTemplate","type":"auto",
			"defaultValue":"",
			"desc":"",
		},
		"command":{
			"name":"command","type":"auto",
			"defaultValue":"",
			"desc":"",
		},
		"smartAsk":{
			"name":"smartAsk","type":"auto",
			"defaultValue":"",
			"desc":"",
		}
	},
	/*#{1I1NMG59H0ArgsView*/
	/*}#1I1NMG59H0ArgsView*/
};

/*#{1I1NMG59H0StartDoc*/
/*}#1I1NMG59H0StartDoc*/
//----------------------------------------------------------------------------
let CompleteArgs=async function(session){
	let argsTemplate,command,smartAsk;
	const $ln=session.language||"EN";
	let context,globalContext=session.globalContext;
	let self;
	let CheckCommand,GenArgs,HasMissing,InputArgs,Done,CheckSmart,SmartCheck,SmartMissing,AskUpward;
	/*#{1I1NMG59H0LocalVals*/
	/*}#1I1NMG59H0LocalVals*/
	
	function parseAgentArgs(input){
		if(typeof(input)=='object'){
			argsTemplate=input.argsTemplate;
			command=input.command;
			smartAsk=input.smartAsk;
		}else{
			argsTemplate=undefined;
			command=undefined;
			smartAsk=undefined;
		}
		/*#{1I1NMG59H0ParseArgs*/
		/*}#1I1NMG59H0ParseArgs*/
	}
	
	/*#{1I1NMG59H0PreContext*/
	/*}#1I1NMG59H0PreContext*/
	context={
		args: "",
		/*#{1I1NMG59H5ExCtxAttrs*/
		/*}#1I1NMG59H5ExCtxAttrs*/
	};
	context=VFACT.flexState(context);
	/*#{1I1NMG59H0PostContext*/
	/*}#1I1NMG59H0PostContext*/
	let $agent,agent,segs={};
	segs["CheckCommand"]=CheckCommand=async function(input){//:1I1NMIL190
		let result=input;
		/*#{1I1NMIL190Start*/
		let ua=$agent.upperAgent;
		if(ua){
			$agent.showName=ua.showName||ua.name;
		}
		/*}#1I1NMIL190Start*/
		if(!!command){
			return {seg:CheckSmart,result:(input),preSeg:"1I1NMIL190",outlet:"1I1NMK8580"};
		}
		/*#{1I1NMIL190Post*/
		/*}#1I1NMIL190Post*/
		return {seg:InputArgs,result:(result),preSeg:"1I1NMIL190",outlet:"1I1NMK8590"};
	};
	CheckCommand.jaxId="1I1NMIL190"
	CheckCommand.url="CheckCommand@"+agentURL
	
	segs["GenArgs"]=GenArgs=async function(input){//:1I1NMJNU80
		let prompt;
		let result=null;
		/*#{1I1NMJNU80Input*/
		/*}#1I1NMJNU80Input*/
		
		let opts={
			platform:"OpenAI",
			mode:"gpt-4o",
			maxToken:2000,
			temperature:0,
			topP:1,
			fqcP:0,
			prcP:0,
			secret:false,
			responseFormat:"json_object"
		};
		let chatMem=GenArgs.messages
		let seed="";
		if(seed!==undefined){opts.seed=seed;}
		let messages=[
			{role:"system",content:`
你是一个解析自然语言命令，生成函数调用参数的AI
- 用户会输入要调用的函数的参数描述以及自然语言命令。

- 函数参数描述是以JSON形式提供，例如
{
	"name":{
		"name":"name","type":"string",
		"defaultValue":"",
		"desc":"User name used in this site."
	},
	"gender":{
		"name":"gender","type":"string",
		"defaultValue":"Male",
		"desc":"User gender."
	}
}

- 请根据函数参数JSON，分析用户的自然语言指令，生成调用函数的参数VO，用JSON回答。例如：
{
	"name":"Alex",
    "gender":"Male"
}

- 如果你无法确定某些参数的内容，请用字符串"$$MISSING"作为参数值.例如，如果你不能确定gender属性：：
{
	"name":"Alex",
    "gender":"$$MISSING"
}
`},
		];
		/*#{1I1NMJNU80PrePrompt*/
		/*}#1I1NMJNU80PrePrompt*/
		prompt=`
函数参数JSON：
${JSON.stringify(argsTemplate.properties,null,"\t")}
${typeof(command)==="string"?("自然语言指令："+command):"指令JSON表达："+JSON.stringify(command)}
`;
		if(prompt!==null){
			if(typeof(prompt)!=="string"){
				prompt=JSON.stringify(prompt,null,"	");
			}
			let msg={role:"user",content:prompt};
			/*#{1I1NMJNU80FilterMessage*/
			/*}#1I1NMJNU80FilterMessage*/
			messages.push(msg);
		}
		/*#{1I1NMJNU80PreCall*/
		/*}#1I1NMJNU80PreCall*/
		result=(result===null)?(await session.callSegLLM("GenArgs@"+agentURL,opts,messages,true)):result;
		result=trimJSON(result);
		/*#{1I1NMJNU80PostCall*/
		context.args=result;
		/*}#1I1NMJNU80PostCall*/
		return {seg:HasMissing,result:(result),preSeg:"1I1NMJNU80",outlet:"1I1NMK85A0"};
	};
	GenArgs.jaxId="1I1NMJNU80"
	GenArgs.url="GenArgs@"+agentURL
	
	segs["HasMissing"]=HasMissing=async function(input){//:1I1OQLA7I0
		let result=input;
		/*#{1I1OQLA7I0Start*/
		let hasMissing=false;
		let pptDefs=argsTemplate.properties;
		{
			let key,value;
			for(key in input){
				value=input[key];
				if(value==="$$MISSING"){
					delete input[key];
					if(pptDefs[key].required!==false){
						hasMissing=true;
					}
				}
			}
		}
		/*}#1I1OQLA7I0Start*/
		if(!hasMissing){
			return {seg:Done,result:(input),preSeg:"1I1OQLA7I0",outlet:"1I1OQMG0O0"};
		}
		/*#{1I1OQLA7I0Post*/
		/*}#1I1OQLA7I0Post*/
		return {seg:InputArgs,result:(result),preSeg:"1I1OQLA7I0",outlet:"1I1OQMG0P0"};
	};
	HasMissing.jaxId="1I1OQLA7I0"
	HasMissing.url="HasMissing@"+agentURL
	
	segs["InputArgs"]=InputArgs=async function(input){//:1ICAFE0910
		let result,resultText;
		let role="assistant";
		let text=(($ln==="CN")?("完善智能体调用参数:"):("Complete agent arguments:"));
		let template=argsTemplate;
		let data=context.args;
		let edit=true;
		if(typeof(template)==="string"){
			template=VFACT.getEditUITemplate(template)||VFACT.getUITemplate(template);
		}
		let inputVO={template:template,data:data,options:{edit:edit}};
		/*#{1ICAFE0910Pre*/
		/*}#1ICAFE0910Pre*/
		[resultText,result]=await session.askUserRaw({type:"object",text:text,data:data,template:template,role:role,edit:edit});
		/*#{1ICAFE0910Codes*/
		/*}#1ICAFE0910Codes*/
		return {result:result};
	};
	InputArgs.jaxId="1ICAFE0910"
	InputArgs.url="InputArgs@"+agentURL
	
	segs["Done"]=Done=async function(input){//:1I1OQM4690
		let result=input
		/*#{1I1OQM4690Code*/
		/*}#1I1OQM4690Code*/
		return {result:result};
	};
	Done.jaxId="1I1OQM4690"
	Done.url="Done@"+agentURL
	
	segs["CheckSmart"]=CheckSmart=async function(input){//:1IOCERCSG0
		let result=input;
		if(!!smartAsk){
			let output="请分析并用JSON给出函数调用参数或给出提问内容。";
			return {seg:SmartCheck,result:(output),preSeg:"1IOCERCSG0",outlet:"1IOCERCSG4"};
		}
		return {seg:GenArgs,result:(result),preSeg:"1IOCERCSG0",outlet:"1IOCERCSG3"};
	};
	CheckSmart.jaxId="1IOCERCSG0"
	CheckSmart.url="CheckSmart@"+agentURL
	
	segs["SmartCheck"]=SmartCheck=async function(input){//:1IOCESQTE0
		let prompt;
		let result;
		
		let opts={
			platform:"OpenAI",
			mode:"gpt-4o",
			maxToken:2000,
			temperature:0,
			topP:1,
			fqcP:0,
			prcP:0,
			secret:false,
			responseFormat:"json_object"
		};
		let chatMem=SmartCheck.messages
		let seed="";
		if(seed!==undefined){opts.seed=seed;}
		let messages=[
			{role:"system",content:`
### 角色
你是一个解析自然语言命令，生成函数调用参数的AI
- 用户会输入要调用的函数的参数描述以及自然语言命令。

### 函数参数
- 当前函数参数的JSON定义是：
\`\`\`
${JSON.stringify(argsTemplate.properties,null,"\t")}
\`\`\`

${typeof(command)==="string"?("### 用户初始输入的自然语言的调用指令\n"+command):"### 调用指令的JSON表达："+JSON.stringify(command)}

### 对话
- 在每一轮对话中，请分析根据输入的调用指令以及当前对话过程，是否可以给出符合要求的完整函数调用参数

- 你必须用JSON格式做出回复

- 如果当前信息可以给出完整的函数调用参数，请在返回JSON中的"arguments"属性中给出当前函数参数。例如：
\`\`\`
{
	"arguments":{
		"name":"Alex",
    	"gender":"Male"
    }
}
\`\`\`

- 如果当前信息无法给出完整的函数调用参数，请在返回JSON中的"ask"属性中给出向用户提问补全信息的问题。你的问题应该明确详细，包括缺失参数的简单说明，请用用户容易理解的自然语言提问。例如：
\`\`\`
{
	"ask":"请提供要查询的用户的电子邮箱地址，用户的性别，以及用户的年龄范围。"
}
\`\`\`

- 提问后收到用户回复后，根据当前对话信息，如果不足以返回完整的调用参数，请继续向用户提问，直到返回完整函数调用信息为止。

### 返回JSON属性
- "arguments" optional, {object}: 完整的函数调用参数列表，其中每一项属性的名称是对应的参数名称，内容是参数的值。
- "ask" optional, {string}: 向用户提问的内容。
`},
		];
		messages.push(...chatMem);
		prompt=input;
		if(prompt!==null){
			if(typeof(prompt)!=="string"){
				prompt=JSON.stringify(prompt,null,"	");
			}
			let msg={role:"user",content:prompt};messages.push(msg);
		}
		result=await session.callSegLLM("SmartCheck@"+agentURL,opts,messages,true);
		chatMem.push({role:"user",content:prompt});
		chatMem.push({role:"assistant",content:result});
		if(chatMem.length>20){
			let removedMsgs=chatMem.splice(0,2);
		}
		result=trimJSON(result);
		return {seg:SmartMissing,result:(result),preSeg:"1IOCESQTE0",outlet:"1IOCESQTE3"};
	};
	SmartCheck.jaxId="1IOCESQTE0"
	SmartCheck.url="SmartCheck@"+agentURL
	SmartCheck.messages=[];
	
	segs["SmartMissing"]=SmartMissing=async function(input){//:1IOCF9APS0
		let result=input;
		/*#{1IOCF9APS0Start*/
		/*}#1IOCF9APS0Start*/
		if(!!input.ask){
			let output=input.ask;
			return {seg:AskUpward,result:(output),preSeg:"1IOCF9APS0",outlet:"1IOCF9APS4"};
		}
		/*#{1IOCF9APS0Post*/
		result=input.arguments;
		/*}#1IOCF9APS0Post*/
		return {seg:Done,result:(result),preSeg:"1IOCF9APS0",outlet:"1IOCF9APS3"};
	};
	SmartMissing.jaxId="1IOCF9APS0"
	SmartMissing.url="SmartMissing@"+agentURL
	
	segs["AskUpward"]=AskUpward=async function(input){//:1IOCF9J3H0
		let tip=(input);
		let tipRole=("assistant");
		let placeholder=("");
		let allowFile=(false)||false;
		let askUpward=(true);
		let text=("");
		let result="";
		if(askUpward && tip){
			result=await session.askUpward($agent,tip);
		}else{
			if(tip){
				session.addChatText(tipRole,tip);
			}
			result=await session.askChatInput({type:"input",placeholder:placeholder,text:text,allowFile:allowFile});
		}
		return {seg:SmartCheck,result:(result),preSeg:"1IOCF9J3H0",outlet:"1IOCF9J3I2"};
	};
	AskUpward.jaxId="1IOCF9J3H0"
	AskUpward.url="AskUpward@"+agentURL
	
	agent=$agent={
		isAIAgent:true,
		session:session,
		name:"CompleteArgs",
		showName:"-",
		url:agentURL,
		autoStart:true,
		jaxId:"1I1NMG59H0",
		context:context,
		livingSeg:null,
		execChat:async function(input/*{argsTemplate,command,smartAsk}*/){
			let result;
			parseAgentArgs(input);
			/*#{1I1NMG59H0PreEntry*/
			/*}#1I1NMG59H0PreEntry*/
			result={seg:CheckCommand,"input":input};
			/*#{1I1NMG59H0PostEntry*/
			/*}#1I1NMG59H0PostEntry*/
			return result;
		},
		/*#{1I1NMG59H0MoreAgentAttrs*/
		/*}#1I1NMG59H0MoreAgentAttrs*/
	};
	/*#{1I1NMG59H0PostAgent*/
	/*}#1I1NMG59H0PostAgent*/
	return agent;
};
/*#{1I1NMG59H0ExCodes*/
/*}#1I1NMG59H0ExCodes*/

//#CodyExport>>>
export const ChatAPI=[{
	def:{
		name: "CompleteArgs",
		description: "这是一个AI智能体。",
		parameters:{
			type: "object",
			properties:{
				argsTemplate:{type:"auto",description:""},
				command:{type:"auto",description:""},
				smartAsk:{type:"auto",description:""}
			}
		}
	},
	agent: CompleteArgs
}];

//:Export Edit-AddOn:
const DocAIAgentExporter=VFACT?VFACT.classRegs.DocAIAgentExporter:null;
if(DocAIAgentExporter){
	const EditAttr=VFACT.classRegs.EditAttr;
	const EditAISeg=VFACT.classRegs.EditAISeg;
	const EditAISegOutlet=VFACT.classRegs.EditAISegOutlet;
	const SegObjShellAttr=EditAISeg.SegObjShellAttr;
	const SegOutletDef=EditAISegOutlet.SegOutletDef;
	const docAIAgentExporter=DocAIAgentExporter.prototype;
	const packExtraCodes=docAIAgentExporter.packExtraCodes;
	const packResult=docAIAgentExporter.packResult;
	const varNameRegex = /^[a-zA-Z_$][a-zA-Z0-9_$]*$/;
	
	EditAISeg.regDef({
		name:"CompleteArgs",showName:"CompleteArgs",icon:"agent.svg",catalog:["AI Call"],
		attrs:{
			...SegObjShellAttr,
			"argsTemplate":{name:"argsTemplate",showName:undefined,type:"auto",key:1,fixed:1,initVal:""},
			"command":{name:"command",showName:undefined,type:"auto",key:1,fixed:1,initVal:""},
			"smartAsk":{name:"smartAsk",showName:undefined,type:"auto",key:1,fixed:1,initVal:""},
			"outlet":{name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc"}
		},
		listHint:["id","argsTemplate","command","smartAsk","codes","desc"],
		desc:"这是一个AI智能体。"
	});
	
	DocAIAgentExporter.segTypeExporters["CompleteArgs"]=
	function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let exportDebug=this.isExportDebug();
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();coder.newLine();
		{
			coder.packText(`let result,args={};`);coder.newLine();
			coder.packText("args['argsTemplate']=");this.genAttrStatement(seg.getAttr("argsTemplate"));coder.packText(";");coder.newLine();
			coder.packText("args['command']=");this.genAttrStatement(seg.getAttr("command"));coder.packText(";");coder.newLine();
			coder.packText("args['smartAsk']=");this.genAttrStatement(seg.getAttr("smartAsk"));coder.packText(";");coder.newLine();
			this.packExtraCodes(coder,seg,"PreCodes");
			coder.packText(`result= await session.pipeChat("/~/aichat/ai/CompleteArgs.js",args,false);`);coder.newLine();
			this.packExtraCodes(coder,seg,"PostCodes");
			this.packUpdateContext(coder,seg);
			this.packUpdateGlobal(coder,seg);
			this.packResult(coder,seg,seg.outlet);
		}
		coder.indentLess();coder.maybeNewLine();
		coder.packText(`};`);coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		coder.newLine();
	};
}
//#CodyExport<<<
/*#{1I1NMG59H0PostDoc*/
/*}#1I1NMG59H0PostDoc*/


export default CompleteArgs;
export{CompleteArgs};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DocAIAgent",
//	"jaxId": "1I1NMG59H0",
//	"attrs": {
//		"editObjs": {
//			"jaxId": "1I1NMG59H1",
//			"attrs": {
//				"CompleteArgs": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1I1NMG59H7",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1I1NMG59H8",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1I1NMG59H9",
//							"attrs": {}
//						},
//						"functions": {
//							"jaxId": "1I1NMG59H10",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false",
//						"exportClass": "false"
//					},
//					"mockups": {}
//				}
//			}
//		},
//		"agent": {
//			"jaxId": "1I1NMG59H2",
//			"attrs": {}
//		},
//		"showName": "-",
//		"entry": "",
//		"autoStart": "true",
//		"inBrowser": "true",
//		"debug": "true",
//		"apiArgs": {
//			"jaxId": "1I1NMG59H3",
//			"attrs": {
//				"argsTemplate": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I1NMH5L20",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				},
//				"command": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I1NMH5L21",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				},
//				"smartAsk": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1IOCER5560",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1I1NMG59H4",
//			"attrs": {}
//		},
//		"context": {
//			"jaxId": "1I1NMG59H5",
//			"attrs": {
//				"args": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I1NMI6P80",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				}
//			}
//		},
//		"globalMockup": {
//			"jaxId": "1I1NMG59H6",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "aiseg",
//					"def": "brunch",
//					"jaxId": "1I1NMIL190",
//					"attrs": {
//						"id": "CheckCommand",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "50",
//						"y": "345",
//						"desc": "这是一个AISeg。",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I1NMK85B0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1NMK85B1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I1NMK8590",
//							"attrs": {
//								"id": "Default",
//								"desc": "输出节点。",
//								"output": ""
//							},
//							"linkedSeg": "1ICAFE0910"
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I1NMK8580",
//									"attrs": {
//										"id": "Result",
//										"desc": "输出节点。",
//										"output": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I1NMK85B2",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I1NMK85B3",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "!!command"
//									},
//									"linkedSeg": "1IOCERCSG0"
//								}
//							]
//						}
//					},
//					"icon": "condition.svg",
//					"reverseOutlets": true
//				},
//				{
//					"type": "aiseg",
//					"def": "callLLM",
//					"jaxId": "1I1NMJNU80",
//					"attrs": {
//						"id": "GenArgs",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "560",
//						"y": "285",
//						"desc": "执行一次LLM调用。",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "faces.svg",
//						"context": {
//							"jaxId": "1I1NMK85B4",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1NMK85B5",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"platform": "\"OpenAI\"",
//						"mode": "gpt-4o",
//						"system": "#`\n你是一个解析自然语言命令，生成函数调用参数的AI\n- 用户会输入要调用的函数的参数描述以及自然语言命令。\n\n- 函数参数描述是以JSON形式提供，例如\n{\n\t\"name\":{\n\t\t\"name\":\"name\",\"type\":\"string\",\n\t\t\"defaultValue\":\"\",\n\t\t\"desc\":\"User name used in this site.\"\n\t},\n\t\"gender\":{\n\t\t\"name\":\"gender\",\"type\":\"string\",\n\t\t\"defaultValue\":\"Male\",\n\t\t\"desc\":\"User gender.\"\n\t}\n}\n\n- 请根据函数参数JSON，分析用户的自然语言指令，生成调用函数的参数VO，用JSON回答。例如：\n{\n\t\"name\":\"Alex\",\n    \"gender\":\"Male\"\n}\n\n- 如果你无法确定某些参数的内容，请用字符串\"$$MISSING\"作为参数值.例如，如果你不能确定gender属性：：\n{\n\t\"name\":\"Alex\",\n    \"gender\":\"$$MISSING\"\n}\n`",
//						"temperature": "0",
//						"maxToken": "2000",
//						"topP": "1",
//						"fqcP": "0",
//						"prcP": "0",
//						"messages": {
//							"attrs": []
//						},
//						"prompt": "#`\n函数参数JSON：\n${JSON.stringify(argsTemplate.properties,null,\"\\t\")}\n${typeof(command)===\"string\"?(\"自然语言指令：\"+command):\"指令JSON表达：\"+JSON.stringify(command)}\n`",
//						"seed": "",
//						"outlet": {
//							"jaxId": "1I1NMK85A0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1OQLA7I0"
//						},
//						"secret": "false",
//						"allowCheat": "false",
//						"GPTCheats": {
//							"attrs": []
//						},
//						"shareChatName": "",
//						"keepChat": "No",
//						"clearChat": "2",
//						"apiFiles": {
//							"attrs": []
//						},
//						"parallelFunction": "false",
//						"responseFormat": "json_object",
//						"formatDef": "\"\""
//					},
//					"icon": "llm.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "brunch",
//					"jaxId": "1I1OQLA7I0",
//					"attrs": {
//						"id": "HasMissing",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "810",
//						"y": "285",
//						"desc": "这是一个AISeg。",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I1OQMG0T0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1OQMG0T1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I1OQMG0P0",
//							"attrs": {
//								"id": "Default",
//								"desc": "输出节点。",
//								"output": ""
//							},
//							"linkedSeg": "1ICAFE0910"
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I1OQMG0O0",
//									"attrs": {
//										"id": "NoMissing",
//										"desc": "输出节点。",
//										"output": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I1OQMG0T2",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I1OQMG0T3",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#!hasMissing"
//									},
//									"linkedSeg": "1I1OQM4690"
//								}
//							]
//						}
//					},
//					"icon": "condition.svg",
//					"reverseOutlets": true
//				},
//				{
//					"type": "aiseg",
//					"def": "askEditObj",
//					"jaxId": "1ICAFE0910",
//					"attrs": {
//						"id": "InputArgs",
//						"viewName": "",
//						"label": "",
//						"x": "1065",
//						"y": "360",
//						"desc": "这是一个AISeg。",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1ICAFGUF40",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1ICAFGUF41",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"text": {
//							"type": "string",
//							"valText": "Complete agent arguments:",
//							"localize": {
//								"EN": "Complete agent arguments:",
//								"CN": "完善智能体调用参数:"
//							},
//							"localizable": true
//						},
//						"role": "Assistant",
//						"data": "#context.args",
//						"template": "#argsTemplate",
//						"editData": "true",
//						"outlet": {
//							"jaxId": "1ICAFGUEQ0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							}
//						}
//					},
//					"icon": "rename.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I1OQM4690",
//					"attrs": {
//						"id": "Done",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "1065",
//						"y": "270",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "flag.svg",
//						"context": {
//							"jaxId": "1I1OQMG0T4",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1OQMG0T5",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I1OQMG0P1",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							}
//						},
//						"outlets": {
//							"attrs": []
//						},
//						"result": "#input"
//					},
//					"icon": "tab_css.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "brunch",
//					"jaxId": "1IOCERCSG0",
//					"attrs": {
//						"id": "CheckSmart",
//						"viewName": "",
//						"label": "",
//						"x": "315",
//						"y": "270",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1IOCERCSG1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1IOCERCSG2",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1IOCERCSG3",
//							"attrs": {
//								"id": "Default",
//								"desc": "输出节点。",
//								"output": ""
//							},
//							"linkedSeg": "1I1NMJNU80"
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1IOCERCSG4",
//									"attrs": {
//										"id": "Smart",
//										"desc": "输出节点。",
//										"output": "请分析并用JSON给出函数调用参数或给出提问内容。",
//										"codes": "false",
//										"context": {
//											"jaxId": "1IOCERCSG5",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1IOCERCSG6",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#!!smartAsk"
//									},
//									"linkedSeg": "1IOCESQTE0"
//								}
//							]
//						}
//					},
//					"icon": "condition.svg",
//					"reverseOutlets": true
//				},
//				{
//					"type": "aiseg",
//					"def": "callLLM",
//					"jaxId": "1IOCESQTE0",
//					"attrs": {
//						"id": "SmartCheck",
//						"viewName": "",
//						"label": "",
//						"x": "560",
//						"y": "175",
//						"desc": "执行一次LLM调用。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1IOCESQTE1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1IOCESQTE2",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"platform": "\"OpenAI\"",
//						"mode": "gpt-4o",
//						"system": "#`\n### 角色\n你是一个解析自然语言命令，生成函数调用参数的AI\n- 用户会输入要调用的函数的参数描述以及自然语言命令。\n\n### 函数参数\n- 当前函数参数的JSON定义是：\n\\`\\`\\`\n${JSON.stringify(argsTemplate.properties,null,\"\\t\")}\n\\`\\`\\`\n\n${typeof(command)===\"string\"?(\"### 用户初始输入的自然语言的调用指令\\n\"+command):\"### 调用指令的JSON表达：\"+JSON.stringify(command)}\n\n### 对话\n- 在每一轮对话中，请分析根据输入的调用指令以及当前对话过程，是否可以给出符合要求的完整函数调用参数\n\n- 你必须用JSON格式做出回复\n\n- 如果当前信息可以给出完整的函数调用参数，请在返回JSON中的\"arguments\"属性中给出当前函数参数。例如：\n\\`\\`\\`\n{\n\t\"arguments\":{\n\t\t\"name\":\"Alex\",\n    \t\"gender\":\"Male\"\n    }\n}\n\\`\\`\\`\n\n- 如果当前信息无法给出完整的函数调用参数，请在返回JSON中的\"ask\"属性中给出向用户提问补全信息的问题。你的问题应该明确详细，包括缺失参数的简单说明，请用用户容易理解的自然语言提问。例如：\n\\`\\`\\`\n{\n\t\"ask\":\"请提供要查询的用户的电子邮箱地址，用户的性别，以及用户的年龄范围。\"\n}\n\\`\\`\\`\n\n- 提问后收到用户回复后，根据当前对话信息，如果不足以返回完整的调用参数，请继续向用户提问，直到返回完整函数调用信息为止。\n\n### 返回JSON属性\n- \"arguments\" optional, {object}: 完整的函数调用参数列表，其中每一项属性的名称是对应的参数名称，内容是参数的值。\n- \"ask\" optional, {string}: 向用户提问的内容。\n`",
//						"temperature": "0",
//						"maxToken": "2000",
//						"topP": "1",
//						"fqcP": "0",
//						"prcP": "0",
//						"messages": {
//							"attrs": []
//						},
//						"prompt": "#input",
//						"seed": "",
//						"outlet": {
//							"jaxId": "1IOCESQTE3",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1IOCF9APS0"
//						},
//						"secret": "false",
//						"allowCheat": "false",
//						"GPTCheats": {
//							"attrs": []
//						},
//						"shareChatName": "",
//						"keepChat": "20 messages",
//						"clearChat": "2",
//						"apiFiles": {
//							"attrs": []
//						},
//						"parallelFunction": "false",
//						"responseFormat": "json_object",
//						"formatDef": "\"\""
//					},
//					"icon": "llm.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "brunch",
//					"jaxId": "1IOCF9APS0",
//					"attrs": {
//						"id": "SmartMissing",
//						"viewName": "",
//						"label": "",
//						"x": "810",
//						"y": "175",
//						"desc": "这是一个AISeg。",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1IOCF9APS1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1IOCF9APS2",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1IOCF9APS3",
//							"attrs": {
//								"id": "Default",
//								"desc": "输出节点。",
//								"output": ""
//							},
//							"linkedSeg": "1I1OQM4690"
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1IOCF9APS4",
//									"attrs": {
//										"id": "Ask",
//										"desc": "输出节点。",
//										"output": "#input.ask",
//										"codes": "false",
//										"context": {
//											"jaxId": "1IOCF9APS5",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1IOCF9APS6",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#!!input.ask"
//									},
//									"linkedSeg": "1IOCF9J3H0"
//								}
//							]
//						}
//					},
//					"icon": "condition.svg",
//					"reverseOutlets": true
//				},
//				{
//					"type": "aiseg",
//					"def": "askChat",
//					"jaxId": "1IOCF9J3H0",
//					"attrs": {
//						"id": "AskUpward",
//						"viewName": "",
//						"label": "",
//						"x": "1065",
//						"y": "160",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1IOCF9J3I0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1IOCF9J3I1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"tip": "#input",
//						"tipRole": "Assistant",
//						"placeholder": "",
//						"text": "",
//						"file": "false",
//						"showText": "false",
//						"askUpward": "true",
//						"outlet": {
//							"jaxId": "1IOCF9J3I2",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1IOCF9RR40"
//						}
//					},
//					"icon": "chat.svg"
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1IOCF9RR40",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "1210",
//						"y": "70",
//						"outlet": {
//							"jaxId": "1IOCFA7UO0",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1IOCFA01J0"
//						},
//						"dir": "R2L"
//					},
//					"icon": "arrowright.svg",
//					"isConnector": true
//				},
//				{
//					"type": "aiseg",
//					"def": "connector",
//					"jaxId": "1IOCFA01J0",
//					"attrs": {
//						"id": "",
//						"label": "New AI Seg",
//						"x": "585",
//						"y": "70",
//						"outlet": {
//							"jaxId": "1IOCFA7UO1",
//							"attrs": {
//								"id": "Outlet",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1IOCESQTE0"
//						},
//						"dir": "R2L"
//					},
//					"icon": "arrowright.svg",
//					"isConnector": true
//				}
//			]
//		},
//		"desc": "这是一个AI智能体。",
//		"exportAPI": "true",
//		"exportAddOn": "true",
//		"addOnOpts": ""
//	}
//}