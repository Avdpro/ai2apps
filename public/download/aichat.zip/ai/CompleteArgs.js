//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import pathLib from "/@path";
import inherits from "/@inherits";
import Base64 from "/@tabos/utils/base64.js";
import {trimJSON} from "/@aichat/utils.js";
/*#{1I1NMG59H0MoreImports*/
/*}#1I1NMG59H0MoreImports*/
const agentURL=(new URL(import.meta.url)).pathname;
const basePath=pathLib.dirname(agentURL);
const $ln=VFACT.lanCode||"EN";
const argsTemplate={
	properties:{
		"argsTemplate":{
			"name":"argsTemplate","type":"auto",
			"defaultValue":"",
			"desc":"",
		},
		"command":{
			"name":"command","type":"auto",
			"defaultValue":"",
			"desc":"",
		}
	},
	/*#{1I1NMG59H0ArgsView*/
	/*}#1I1NMG59H0ArgsView*/
};

/*#{1I1NMG59H0StartDoc*/
/*}#1I1NMG59H0StartDoc*/
//----------------------------------------------------------------------------
let CompleteArgs=async function(session){
	let argsTemplate,command;
	let context,globalContext;
	let self;
	let CheckCommand,HasMissing,GenArgs,EditArgs,InputArgs,Done;
	/*#{1I1NMG59H0LocalVals*/
	/*}#1I1NMG59H0LocalVals*/
	
	function parseAgentArgs(input){
		if(typeof(input)=='object'){
			argsTemplate=input.argsTemplate;
			command=input.command;
		}else{
			argsTemplate=undefined;
			command=undefined;
		}
		/*#{1I1NMG59H0ParseArgs*/
		/*}#1I1NMG59H0ParseArgs*/
	}
	
	/*#{1I1NMG59H0PreContext*/
	/*}#1I1NMG59H0PreContext*/
	globalContext=session.globalContext;
	context={
		args: "",
		/*#{1I1NMG59H5ExCtxAttrs*/
		/*}#1I1NMG59H5ExCtxAttrs*/
	};
	context=VFACT.flexState(context);
	/*#{1I1NMG59H0PostContext*/
	/*}#1I1NMG59H0PostContext*/
	let agent,segs={};
	segs["CheckCommand"]=CheckCommand=async function(input){//:1I1NMIL190
		let result=input;
		if(!!command){
			return {seg:GenArgs,result:(input),preSeg:"1I1NMIL190",outlet:"1I1NMK8580"};
		}
		return {seg:InputArgs,result:(result),preSeg:"1I1NMIL190",outlet:"1I1NMK8590"};
	};
	CheckCommand.jaxId="1I1NMIL190"
	CheckCommand.url="CheckCommand@"+agentURL
	
	segs["HasMissing"]=HasMissing=async function(input){//:1I1OQLA7I0
		let result=input;
		/*#{1I1OQLA7I0Start*/
		let hasMissing=false;
		let pptDefs=argsTemplate.properties;
		{
			let key,value;
			for(key in input){
				value=input[key];
				if(value==="$$MISSING"){
					delete input[key];
					if(pptDefs[key].required!==false){
						hasMissing=true;
					}
				}
			}
		}
		/*}#1I1OQLA7I0Start*/
		if(!hasMissing){
			return {seg:Done,result:(input),preSeg:"1I1OQLA7I0",outlet:"1I1OQMG0O0"};
		}
		/*#{1I1OQLA7I0Post*/
		/*}#1I1OQLA7I0Post*/
		return {seg:InputArgs,result:(result),preSeg:"1I1OQLA7I0",outlet:"1I1OQMG0P0"};
	};
	HasMissing.jaxId="1I1OQLA7I0"
	HasMissing.url="HasMissing@"+agentURL
	
	segs["GenArgs"]=GenArgs=async function(input){//:1I1NMJNU80
		let prompt;
		let result=null;
		/*#{1I1NMJNU80Input*/
		/*}#1I1NMJNU80Input*/
		
		let opts={
			platform:"OpenAI",
			mode:"gpt-4o",
			maxToken:2000,
			temperature:0,
			topP:1,
			fqcP:0,
			prcP:0,
			secret:false,
			responseFormat:"json_object"
		};
		let chatMem=GenArgs.messages
		let seed="";
		if(seed!==undefined){opts.seed=seed;}
		let messages=[
			{role:"system",content:`
你是一个解析自然语言命令，生成函数调用参数的AI
- 用户会输入要调用的函数的参数描述以及自然语言命令。

- 函数参数描述是以JSON形式提供，例如
{
	"name":{
		"name":"name","type":"string",
		"defaultValue":"",
		"desc":"User name used in this site."
	},
	"gender":{
		"name":"gender","type":"string",
		"defaultValue":"Male",
		"desc":"User gender."
	}
}

- 请根据函数参数JSON，分析用户的自然语言指令，生成调用函数的参数VO，用JSON回答。例如：
{
	"name":"Alex",
    "gender":"Male"
}

- 如果你无法确定某些参数的内容，请用字符串"$$MISSING"作为参数值.例如，如果你不能确定gender属性：：
{
	"name":"Alex",
    "gender":"$$MISSING"
}
`},
		];
		/*#{1I1NMJNU80PrePrompt*/
		/*}#1I1NMJNU80PrePrompt*/
		prompt=`
函数参数JSON：
${JSON.stringify(argsTemplate.properties,null,"\t")}
自然语言指令：${command}
`;
		if(prompt!==null){
			messages.push({role:"user",content:prompt});
		}
		/*#{1I1NMJNU80PreCall*/
		/*}#1I1NMJNU80PreCall*/
		result=(result===null)?(await session.callSegLLM("GenArgs@"+agentURL,opts,messages,true)):result;
		result=trimJSON(result);
		/*#{1I1NMJNU80PostCall*/
		console.log(result);
		context.args=result;
		/*}#1I1NMJNU80PostCall*/
		return {seg:HasMissing,result:(result),preSeg:"1I1NMJNU80",outlet:"1I1NMK85A0"};
	};
	GenArgs.jaxId="1I1NMJNU80"
	GenArgs.url="GenArgs@"+agentURL
	
	segs["EditArgs"]=EditArgs=async function(input){//:1I1NMLE500
		let result,resultText;
		let role="assistant";
		let md=await import("/@StdUI/ui/AIAskDataBlock.js");
		let func=md.default;
		let text=(($ln==="CN")?("完善智能体调用参数:"):("Complete agent arguments:"));
		let template=argsTemplate;
		let data=context.args;
		let edit=true;
		if(typeof(template)==="string"){
			template=VFACT.getEditUITemplate(template)||VFACT.getUITemplate(template);
		}
		let inputVO={template:template,data:data,options:{edit:edit}};
		/*#{1I1NMLE500Pre*/
		/*}#1I1NMLE500Pre*/
		[resultText,result]=await session.askUserRaw({type:"block",text:text,block:func(session,{}),input:inputVO,role:role});
		/*#{1I1NMLE500Codes*/
		/*}#1I1NMLE500Codes*/
		return {result:result};
	};
	EditArgs.jaxId="1I1NMLE500"
	EditArgs.url="EditArgs@"+agentURL
	
	segs["InputArgs"]=InputArgs=async function(input){//:1ICAFE0910
		let result,resultText;
		let role="assistant";
		let text=(($ln==="CN")?("完善智能体调用参数:"):("Complete agent arguments:"));
		let template=argsTemplate;
		let data=context.args;
		let edit=true;
		if(typeof(template)==="string"){
			template=VFACT.getEditUITemplate(template)||VFACT.getUITemplate(template);
		}
		let inputVO={template:template,data:data,options:{edit:edit}};
		/*#{1ICAFE0910Pre*/
		/*}#1ICAFE0910Pre*/
		[resultText,result]=await session.askUserRaw({type:"object",text:text,data:data,template:template,role:role,edit:edit});
		/*#{1ICAFE0910Codes*/
		/*}#1ICAFE0910Codes*/
		return {result:result};
	};
	InputArgs.jaxId="1ICAFE0910"
	InputArgs.url="InputArgs@"+agentURL
	
	segs["Done"]=Done=async function(input){//:1I1OQM4690
		let result=input
		/*#{1I1OQM4690Code*/
		/*}#1I1OQM4690Code*/
		return {result:result};
	};
	Done.jaxId="1I1OQM4690"
	Done.url="Done@"+agentURL
	
	agent={
		isAIAgent:true,
		session:session,
		name:"CompleteArgs",
		url:agentURL,
		autoStart:true,
		jaxId:"1I1NMG59H0",
		context:context,
		livingSeg:null,
		execChat:async function(input/*{argsTemplate,command}*/){
			let result;
			parseAgentArgs(input);
			/*#{1I1NMG59H0PreEntry*/
			/*}#1I1NMG59H0PreEntry*/
			result={seg:CheckCommand,"input":input};
			/*#{1I1NMG59H0PostEntry*/
			/*}#1I1NMG59H0PostEntry*/
			return result;
		},
		/*#{1I1NMG59H0MoreAgentAttrs*/
		/*}#1I1NMG59H0MoreAgentAttrs*/
	};
	/*#{1I1NMG59H0PostAgent*/
	/*}#1I1NMG59H0PostAgent*/
	return agent;
};
/*#{1I1NMG59H0ExCodes*/
/*}#1I1NMG59H0ExCodes*/

export const ChatAPI=[{
	def:{
		name: "CompleteArgs",
		description: "这是一个AI智能体。",
		parameters:{
			type: "object",
			properties:{
				argsTemplate:{type:"auto",description:""},
				command:{type:"auto",description:""}
			}
		}
	},
	agent: CompleteArgs
}];

//:Export Edit-AddOn:
const DocAIAgentExporter=VFACT.classRegs.DocAIAgentExporter;
if(DocAIAgentExporter){
	const EditAttr=VFACT.classRegs.EditAttr;
	const EditAISeg=VFACT.classRegs.EditAISeg;
	const EditAISegOutlet=VFACT.classRegs.EditAISegOutlet;
	const SegObjShellAttr=EditAISeg.SegObjShellAttr;
	const SegOutletDef=EditAISegOutlet.SegOutletDef;
	const docAIAgentExporter=DocAIAgentExporter.prototype;
	const packExtraCodes=docAIAgentExporter.packExtraCodes;
	const packResult=docAIAgentExporter.packResult;
	const varNameRegex = /^[a-zA-Z_$][a-zA-Z0-9_$]*$/;
	
	EditAISeg.regDef({
		name:"CompleteArgs",showName:"CompleteArgs",icon:"agent.svg",catalog:["AI Call"],
		attrs:{
			...SegObjShellAttr,
			"argsTemplate":{name:"argsTemplate",type:"auto",key:1,fixed:1,initVal:""},
			"command":{name:"command",type:"auto",key:1,fixed:1,initVal:""},
			"outlet":{name:"outlet",type:"aioutlet",def:SegOutletDef,key:1,fixed:1,edit:false,navi:"doc"}
		},
		listHint:["id","argsTemplate","command","codes","desc"],
		desc:"这是一个AI智能体。"
	});
	
	DocAIAgentExporter.segTypeExporters["CompleteArgs"]=
	function(seg){
		let coder=this.coder;
		let segName=seg.idVal.val;
		let exportDebug=this.isExportDebug();
		segName=(segName &&varNameRegex.test(segName))?segName:("SEG"+seg.jaxId);
		coder.packText(`segs["${segName}"]=${segName}=async function(input){//:${seg.jaxId}`);
		coder.indentMore();coder.newLine();
		{
			coder.packText(`let result,args={};`);coder.newLine();
			coder.packText("args['argsTemplate']=");this.genAttrStatement(seg.getAttr("argsTemplate"));coder.packText(";");coder.newLine();
			coder.packText("args['command']=");this.genAttrStatement(seg.getAttr("command"));coder.packText(";");coder.newLine();
			this.packExtraCodes(coder,seg,"PreCodes");
			coder.packText(`result= await session.pipeChat("/~/aichat/ai/CompleteArgs.js",args,false);`);coder.newLine();
			this.packExtraCodes(coder,seg,"PostCodes");
			this.packResult(coder,seg,seg.outlet);
		}
		coder.indentLess();coder.maybeNewLine();
		coder.packText(`};`);coder.newLine();
		if(exportDebug){
			coder.packText(`${segName}.jaxId="${seg.jaxId}"`);coder.newLine();
		}
		coder.packText(`${segName}.url="${segName}@"+agentURL`);coder.newLine();
		coder.newLine();
	};
}
/*#{1I1NMG59H0PostDoc*/
/*}#1I1NMG59H0PostDoc*/


export default CompleteArgs;
export{CompleteArgs};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "DocAIAgent",
//	"jaxId": "1I1NMG59H0",
//	"attrs": {
//		"editObjs": {
//			"jaxId": "1I1NMG59H1",
//			"attrs": {
//				"CompleteArgs": {
//					"type": "objclass",
//					"def": "ObjClass",
//					"jaxId": "1I1NMG59H7",
//					"attrs": {
//						"exportType": "UI Data Template",
//						"constructArgs": {
//							"jaxId": "1I1NMG59H8",
//							"attrs": {}
//						},
//						"superClass": "",
//						"properties": {
//							"jaxId": "1I1NMG59H9",
//							"attrs": {}
//						},
//						"functions": {
//							"jaxId": "1I1NMG59H10",
//							"attrs": {}
//						},
//						"mockupOnly": "false",
//						"nullMockup": "false"
//					},
//					"mockups": {}
//				}
//			}
//		},
//		"agent": {
//			"jaxId": "1I1NMG59H2",
//			"attrs": {}
//		},
//		"entry": "",
//		"autoStart": "true",
//		"debug": "true",
//		"apiArgs": {
//			"jaxId": "1I1NMG59H3",
//			"attrs": {
//				"argsTemplate": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I1NMH5L20",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				},
//				"command": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I1NMH5L21",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1I1NMG59H4",
//			"attrs": {}
//		},
//		"context": {
//			"jaxId": "1I1NMG59H5",
//			"attrs": {
//				"args": {
//					"type": "object",
//					"def": "AgentCallArgument",
//					"jaxId": "1I1NMI6P80",
//					"attrs": {
//						"type": "Auto",
//						"mockup": "\"\"",
//						"desc": ""
//					}
//				}
//			}
//		},
//		"globalMockup": {
//			"jaxId": "1I1NMG59H6",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": [
//				{
//					"type": "aiseg",
//					"def": "brunch",
//					"jaxId": "1I1NMIL190",
//					"attrs": {
//						"id": "CheckCommand",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "110",
//						"y": "165",
//						"desc": "这是一个AISeg。",
//						"codes": "false",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I1NMK85B0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1NMK85B1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I1NMK8590",
//							"attrs": {
//								"id": "Default",
//								"desc": "输出节点。",
//								"output": ""
//							},
//							"linkedSeg": "1ICAFE0910"
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I1NMK8580",
//									"attrs": {
//										"id": "Result",
//										"desc": "输出节点。",
//										"output": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I1NMK85B2",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I1NMK85B3",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "!!command"
//									},
//									"linkedSeg": "1I1NMJNU80"
//								}
//							]
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "brunch",
//					"jaxId": "1I1OQLA7I0",
//					"attrs": {
//						"id": "HasMissing",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "575",
//						"y": "105",
//						"desc": "这是一个AISeg。",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I1OQMG0T0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1OQMG0T1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I1OQMG0P0",
//							"attrs": {
//								"id": "Default",
//								"desc": "输出节点。",
//								"output": ""
//							},
//							"linkedSeg": "1ICAFE0910"
//						},
//						"outlets": {
//							"attrs": [
//								{
//									"type": "aioutlet",
//									"def": "AIConditionOutlet",
//									"jaxId": "1I1OQMG0O0",
//									"attrs": {
//										"id": "NoMissing",
//										"desc": "输出节点。",
//										"output": "",
//										"codes": "false",
//										"context": {
//											"jaxId": "1I1OQMG0T2",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"global": {
//											"jaxId": "1I1OQMG0T3",
//											"attrs": {
//												"cast": ""
//											}
//										},
//										"condition": "#!hasMissing"
//									},
//									"linkedSeg": "1I1OQM4690"
//								}
//							]
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "callLLM",
//					"jaxId": "1I1NMJNU80",
//					"attrs": {
//						"id": "GenArgs",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "370",
//						"y": "105",
//						"desc": "执行一次LLM调用。",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "faces.svg",
//						"context": {
//							"jaxId": "1I1NMK85B4",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1NMK85B5",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"platform": "\"OpenAI\"",
//						"mode": "gpt-4o",
//						"system": "#`\n你是一个解析自然语言命令，生成函数调用参数的AI\n- 用户会输入要调用的函数的参数描述以及自然语言命令。\n\n- 函数参数描述是以JSON形式提供，例如\n{\n\t\"name\":{\n\t\t\"name\":\"name\",\"type\":\"string\",\n\t\t\"defaultValue\":\"\",\n\t\t\"desc\":\"User name used in this site.\"\n\t},\n\t\"gender\":{\n\t\t\"name\":\"gender\",\"type\":\"string\",\n\t\t\"defaultValue\":\"Male\",\n\t\t\"desc\":\"User gender.\"\n\t}\n}\n\n- 请根据函数参数JSON，分析用户的自然语言指令，生成调用函数的参数VO，用JSON回答。例如：\n{\n\t\"name\":\"Alex\",\n    \"gender\":\"Male\"\n}\n\n- 如果你无法确定某些参数的内容，请用字符串\"$$MISSING\"作为参数值.例如，如果你不能确定gender属性：：\n{\n\t\"name\":\"Alex\",\n    \"gender\":\"$$MISSING\"\n}\n`",
//						"temperature": "0",
//						"maxToken": "2000",
//						"topP": "1",
//						"fqcP": "0",
//						"prcP": "0",
//						"messages": {
//							"attrs": []
//						},
//						"prompt": "#`\n函数参数JSON：\n${JSON.stringify(argsTemplate.properties,null,\"\\t\")}\n自然语言指令：${command}\n`",
//						"seed": "",
//						"outlet": {
//							"jaxId": "1I1NMK85A0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							},
//							"linkedSeg": "1I1OQLA7I0"
//						},
//						"secret": "false",
//						"allowCheat": "false",
//						"GPTCheats": {
//							"attrs": []
//						},
//						"shareChatName": "",
//						"keepChat": "No",
//						"clearChat": "2",
//						"apiFiles": {
//							"attrs": []
//						},
//						"parallelFunction": "false",
//						"responseFormat": "json_object"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "askDataView",
//					"jaxId": "1I1NMLE500",
//					"attrs": {
//						"id": "EditArgs",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "1050",
//						"y": "175",
//						"desc": "这是一个AISeg。",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1I1NMM2TV0",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1NMM2TV1",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I1NMM2TT0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							}
//						},
//						"text": {
//							"type": "string",
//							"valText": "Complete agent arguments:",
//							"localize": {
//								"EN": "Complete agent arguments:",
//								"CN": "完善智能体调用参数:"
//							},
//							"localizable": true
//						},
//						"role": "Assistant",
//						"data": "#context.args",
//						"template": "#argsTemplate",
//						"editData": "true"
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "askEditObj",
//					"jaxId": "1ICAFE0910",
//					"attrs": {
//						"id": "InputArgs",
//						"viewName": "",
//						"label": "",
//						"x": "830",
//						"y": "180",
//						"desc": "这是一个AISeg。",
//						"codes": "true",
//						"mkpInput": "$$input$$",
//						"segMark": "None",
//						"context": {
//							"jaxId": "1ICAFGUF40",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1ICAFGUF41",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"text": {
//							"type": "string",
//							"valText": "Complete agent arguments:",
//							"localize": {
//								"EN": "Complete agent arguments:",
//								"CN": "完善智能体调用参数:"
//							},
//							"localizable": true
//						},
//						"role": "Assistant",
//						"data": "#context.args",
//						"template": "#argsTemplate",
//						"editData": "true",
//						"outlet": {
//							"jaxId": "1ICAFGUEQ0",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							}
//						}
//					}
//				},
//				{
//					"type": "aiseg",
//					"def": "code",
//					"jaxId": "1I1OQM4690",
//					"attrs": {
//						"id": "Done",
//						"viewName": "",
//						"label": "New AI Seg",
//						"x": "830",
//						"y": "90",
//						"desc": "这是一个AISeg。",
//						"mkpInput": "$$input$$",
//						"segMark": "flag.svg",
//						"context": {
//							"jaxId": "1I1OQMG0T4",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"global": {
//							"jaxId": "1I1OQMG0T5",
//							"attrs": {
//								"cast": ""
//							}
//						},
//						"outlet": {
//							"jaxId": "1I1OQMG0P1",
//							"attrs": {
//								"id": "Result",
//								"desc": "输出节点。"
//							}
//						},
//						"result": "#input"
//					}
//				}
//			]
//		},
//		"desc": "这是一个AI智能体。",
//		"exportAPI": "true",
//		"exportAddOn": "true",
//		"addOnOpts": ""
//	}
//}