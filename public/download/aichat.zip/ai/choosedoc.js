import pathLib from "/@path";
import {tabFS} from "/@tabos";

async function init(){
	let botPath,session,kbPath,dirPath,path,json,docs,name,kbDocs;
	botPath=pathLib.dirname(this.url);
	if(botPath.startsWith("/~/")){
		botPath=botPath.substring(2);
	}else if(botPath.startsWith("//")){
		botPath=botPath.substring(1);
	}
	session=this.session;
	kbPath=session.kbPath||"../kb";
	if(!Array.isArray(kbPath)){
		kbPath=[kbPath];
	}
	kbDocs={};
	for(dirPath of kbPath){
		path=pathLib.join(botPath,dirPath,"knowledge.base.json");
		try{
			json=await tabFS.readFile(path,"utf8");
			json=JSON.parse(json);
			docs=json.docs;
			for(name in docs){
				kbDocs[pathLib.join(botPath,dirPath,name)]=docs[name];
			}
		}catch(err){
			console.warn(`Can't load knowledge base: ${path}`);
		}
	}
	this.chatContext="Known docs:"+JSON.stringify(kbDocs);
	this.kbDocs=kbDocs;
};

async function output(prompt){
	let pos1,pos2,list,doc,kbDocs;
	kbDocs=this.kbDocs;
	pos1=prompt.indexOf("[");
	pos2=prompt.indexOf("]");
	if(pos1>=0 && pos2>pos1){
		prompt=prompt.substring(pos1,pos2+1);
		list=JSON.parse(prompt);
		list=list.filter(item=>!!kbDocs[item]);
		prompt=JSON.stringify(list);
	}
	return prompt;
};

export {init,output};