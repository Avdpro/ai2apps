import pathLib from "/@path";
import {tabNT} from "/@tabos/tabos_nt.js";
import {makeObjEventEmitter,makeNotify} from "/@events";
import {ChatBot} from "./chatbot.js";
import {VFACT} from "/@vfact";
const $ln=VFACT.lanCode||"EN";
//****************************************************************************
//****************************************************************************
let ChatAction=function(session,type){
	let owner;
	this.type=type||"Chat";//"Chat,GPTCall,Filter,API"
	this.session=session;
	owner=session.curAction;
	session.curAction=this;
	this.ownerAction=owner;
	if(this.ownerAction){
		owner.subActions.push(this);
	}
	this.actor="";
	this.prompt=null;
	this.result=null;
	this.error=null;
	this.subActions=[];
	this.startTime=Date.now();
	this.endTime=0;
	this.uiBlock=null;
	makeObjEventEmitter(this);
};

//----------------------------------------------------------------------------
ChatAction.logChat=function(session,chatBot,prompt){
	let act;
	const app=VFACT.app;
	act=new ChatAction(session,"Chat");
	act.chatBot=chatBot;
	act.actor=chatBot.name;
	act.path=chatBot.url;
	act.desc=chatBot.info;
	act.prompt=prompt;
	if(act.ownerAction){
		act.ownerAction.emit("NewSub",act);
	}else{
		app.emit("NewAction",act);
	}
	return act;
};

//----------------------------------------------------------------------------
ChatAction.logAgentExec=function(session,agent,input){
	let act;
	const app=VFACT.app;
	act=new ChatAction(session,"Agent");
	act.agent=agent;
	act.actor=agent.name;
	act.path=agent.url;
	act.desc=agent.info;
	act.prompt=input;
	if(act.ownerAction){
		act.ownerAction.emit("NewSub",act);
	}else{
		app.emit("NewAction",act);
	}
	return act;
};

//----------------------------------------------------------------------------
ChatAction.logAISeg=function(session,seg,input){
	let act,owner;
	const app=VFACT.app;
	act=new ChatAction(session,"AISeg");
	act.actor=seg.name;
	act.path=seg.url;
	act.desc=seg.info;
	act.prompt=input;
	owner=act.ownerAction
	while(owner && owner.type==="AISeg"){
		owner=owner.ownerAction;
	}
	if(owner){
		owner.emit("NewSub",act);
	}else{
		app.emit("NewAction",act);
	}
	return act;
};

//----------------------------------------------------------------------------
ChatAction.logFilter=function(session,chatBot,filterType,filterPath,prompt){
	let act;
	const app=VFACT.app;
	act=new ChatAction(session,"Filter");
	act.actor=filterPath;
	act.prompt=prompt;
	act.filterType=filterType;
	act.filterPath=filterPath;
	if(act.ownerAction){
		act.ownerAction.emit("NewSub",act);
	}else{
		app.emit("NewAction",act);
	}
	return act;
};

//----------------------------------------------------------------------------
ChatAction.logGPTCall=function(session,chatBot,callVO){
	let act;
	const app=VFACT.app;
	act=new ChatAction(session,"GPTCall");
	act.actor=chatBot;
	act.prompt=JSON.stringify(callVO);
	if(act.ownerAction){
		act.ownerAction.emit("NewSub",act);
	}else{
		app.emit("NewAction",act);
	}
	return act;
};

//----------------------------------------------------------------------------
ChatAction.logAPICall=function(session,apiName,callVO,stub){
	let act,def;
	def=stub.def;
	const app=VFACT.app;
	act=new ChatAction(session,"APICall");
	act.actor=apiName;
	console.log("API DEF:");
	console.log(def);
	act.desc=def.description;
	if(typeof(callVO)==="string"){
		act.prompt=callVO;
	}else{
		act.prompt=JSON.stringify(callVO);
	}
	if(act.ownerAction){
		act.ownerAction.emit("NewSub",act);
	}else{
		app.emit("NewAction",act);
	}
	return act;
};

//----------------------------------------------------------------------------
ChatAction.logAskUser=function(session,askVO){
	let act,actor;
	const app=VFACT.app;
	actor=session.curAction.actor;
	act=new ChatAction(session,"AskUser");
	act.actor=actor+"#askUser";
	if(typeof(askVO)!=="string"){
		try{
			askVO=JSON.stringify(askVO);
		}catch(err){
			askVO=""+askVO;
		}
	}
	act.prompt=askVO;
	act.result=null;
	if(act.ownerAction){
		act.ownerAction.emit("NewSub",act);
	}else{
		app.emit("NewAction",act);
	}
	return act;
};

//----------------------------------------------------------------------------
ChatAction.logChatText=function(session,role,text){
	let act,actor;
	const app=VFACT.app;
	actor=session.curAction.actor;
	act=new ChatAction(session,"ChatText");
	act.actor="";
	act.prompt=role+":"+text;
	if(act.ownerAction){
		act.ownerAction.emit("NewSub",act);
	}else{
		app.emit("NewAction",act);
	}
	act.end("");
	act.endTime=act.startTime;
	act.result="";
	return act;
};

//----------------------------------------------------------------------------
ChatAction.logLogEvent=function(session,text){
	let act,actor;
	const app=VFACT.app;
	actor=session.curAction.actor;
	act=new ChatAction(session,"LogEvent");
	act.actor="";
	act.prompt=text;
	if(act.ownerAction){
		act.ownerAction.emit("NewSub",act);
	}else{
		app.emit("NewAction",act);
	}
	act.end("");
	act.endTime=act.startTime;
	act.result="";
	return act;
};

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
let chatAction=ChatAction.prototype={};

//----------------------------------------------------------------------------
//add a new sub action, actObj can be ChatRound, FilterCall or APICall
chatAction.end=function(result){
	if(typeof(result)!=="string"){
		try{
			result=JSON.stringify(result);
		}catch(err){
		}
	}
	this.result=result;
	this.session.curAction=this.ownerAction;
	this.endTime=Date.now();
	this.emit("ActionEnd");
};

//----------------------------------------------------------------------------
chatAction.failed=function(err){
	this.error=err;
	this.session.curAction=this.ownerAction;
	this.endTime=Date.now();
	this.emit("ActionError");
};

export default ChatAction;
export {ChatAction,chatAction};