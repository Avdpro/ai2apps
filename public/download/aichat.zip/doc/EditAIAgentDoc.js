import {VFACT} from "/@vfact.js";
import {EditAttr} from "/@editkit/EditAttr.js";
import {EditObj} from "/@editkit/EditObj.js";
import {EditDoc,EditDocDef} from "/@editkit/editdoc/EditDoc.js";
import inherits from "/@inherits";
import pathLib from "/@path";
let $ln=VFACT.lanCode||"EN";
let DocAIAgent,docAIAgent;
const AISegArrayDef={elementType:"aiseg",allowExtraAttr:1};
const DocAIAgentDef={
	name:"DocAIAgent",
	icon:"gears.svg",allowExtraAttr:0,navi:"prj",
	constructFunc:DocAIAgent,
	exporter:"AIAgent",
	attrs:{
		...EditDocDef.attrs,//basic attr: path
		"desc":{
			name:"desc",showName:(($ln==="CN")?("说明"):/*EN*/("Description")),type:"string",key:1,fixed:1,initVal:(($ln==="CN")?("这是一个AI代理。"):/*EN*/("This is an AI agent.")),
		},
		"segs":{
			name:"segs",type:"array",def:AISegArrayDef,fixed:1,key:1,edit:false,navi:"doc"
		},
		"entry":{
			name:"entry",showName:(($ln==="CN")?("启动入口"):/*EN*/("Entry point")),type:"string",key:1,fixed:1,initVal:"Start",
		},
		"context":{
			name:"context",showName:(($ln==="CN")?("全局上下文"):/*EN*/("Global context")),type:"object",def:"Object",key:1,fixed:1,edit:false,navi:0
		}
	},
	objAttrs:{
		getLocalizableObjs(){
			return [this.getAttr("localVars"),this.getAttr("state"),this.hudObj]
		}
	}
};
//****************************************************************************
//:EditAIAgentDoc:
//****************************************************************************
DocAIAgent=function(owner,def,init){
	let self,objDef;
	self=this;
	EditDoc.call(this,owner,def,true);
	this.isAIAgentDoc=true;
	objDef=this.objDef;
	this.segsVal=this.getAttr("segs");
	this.segsList=this.segsVal.attrList;
	this.entryVal=this.getAttr("entry");
};

inherits(DocAIAgent,EditDoc);
docAIAgent=DocAIAgent.prototype;
EditDoc.regDocDef("AIAgent",DocAIAgentDef);

//****************************************************************************
//:I/O
//****************************************************************************
{
}

//****************************************************************************
//:Seg access:
//****************************************************************************
{
	//------------------------------------------------------------------------
	docAIAgent.runOnAllSegs=function(func,...args){
		this.hudObj.runOnAllHuds(func,...args);
	};
}

//****************************************************************************
//:TabEditor interactive:
//****************************************************************************
{
	//------------------------------------------------------------------------
	docAIAgent.getNaviDocRoot=function(){
		let config,attrHash;
		let list=[];
		config=this.prj.config;
		attrHash=this.attrHash;
		list.push(this.segsVal);
		return list;
	};
}