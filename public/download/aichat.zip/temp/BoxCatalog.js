//Auto genterated by Cody
import {$P,VFACT,callAfter} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
/*#{1HB5OTI560StartDoc*/
/*}#1HB5OTI560StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BoxCatalog=function(name){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1HB5OTI561LocalVals*/
	/*}#1HB5OTI561LocalVals*/
	
	/*#{1HB5OTI561PreState*/
	/*}#1HB5OTI561PreState*/
	/*#{1HB5OTI561PostState*/
	/*}#1HB5OTI561PostState*/
	cssVO={
		"hash":"1HB5OTI561",nameHost:true,
		"type":"hud","x":0,"y":0,"w":"100%","h":"","minW":"","minH":50,"maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
		children:[
			{
				"hash":"1HB5OV6IG0",
				"type":"hud","id":"BoxHeader","position":"relative","x":0,"y":0,"w":"100%","h":30,"padding":[0,5,0,5],"styleClass":"","contentLayout":"flex-x",
				children:[
					{
						"hash":"1HB5P0O8I0",
						"type":BtnIcon("front",20,0,appCfg.sharedAssets+"/collapse.svg",null),"position":"relative","x":10,"y":"50%","anchorY":1,"anchorX":1,"padding":2,
					},
					{
						"hash":"1HB5P48IC0",
						"type":"text","position":"relative","x":0,"y":0,"w":100,"h":"100%","styleClass":"","color":cfgColor["fontBodySub"],"text":name,"fontSize":txtSize.midPlus,
						"fontWeight":"bold","fontStyle":"normal","textDecoration":"","alignV":1,
					}
				],
			},
			{
				"hash":"1HB5RAKIB0",
				"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":"","minH":50,"styleClass":"","contentLayout":"flex-x","subAlign":4,"itemsAlign":1,"itemsWrap":1,
				children:[
					{
						"hash":"1HB5RN25N0",
						"type":"text","position":"relative","x":0,"y":0,"w":"100%","h":"100%","styleClass":"","color":cfgColor["fontBodyLit"],"text":(($ln==="CN")?("没有找到属于这个分类的AI Chat"):("No AI chat found for this catalog.")),
						"fontSize":txtSize.mid,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignH":1,"alignV":1,
					}
				],
			}
		],
		/*#{1HB5OTI561ExtraCSS*/
		/*}#1HB5OTI561ExtraCSS*/
		faces:{
			"open":{
				"#1HB5P0O8I0":{
					"rotate":90,
					ani:[
						{
							"type":"auto","time":100
						}
					]
				}
			},"close":{
			},"empty":{
				"#1HB5RN25N0":{
					"display":1
				}
			},"!empty":{
				"#1HB5RN25N0":{
					"display":0
				}
			}
		},
		OnCreate:function(){
			self=this;
			
			/*#{1HB5OTI561Create*/
			/*}#1HB5OTI561Create*/
		},
		/*#{1HB5OTI561EndCSS*/
		/*}#1HB5OTI561EndCSS*/
	};
	/*#{1HB5OTI561PostCSSVO*/
	/*}#1HB5OTI561PostCSSVO*/
	return cssVO;
};
/*#{1HB5OTI561ExCodes*/
/*}#1HB5OTI561ExCodes*/

BoxCatalog.gearExport={
	framework: "jax",
	hudType: "hud",
	"showName":"",icon:"gears.svg",previewImg:false,
	fixPose:false,initW:100,initH:100,
	catalog:"",
	args: {
		"name": {
			"name": "name", "showName": "name", "type": "string", "key": true, "fixed": true, "initVal": "System"
		}
	},
	state:{
	},
	properties:["id","position","x","y","display"],
	faces:[
		{name:"open",entry:false,next:"",desc:"",time:0},
		{name:"close",entry:false,next:"",desc:"",time:0},
		{name:"empty",entry:false,next:"",desc:"",time:0},
		{name:"!empty",entry:false,next:"",desc:"",time:0}
	],
	subContainers:{
	},
	deviceW:375,
	deviceH:750,
	/*#{1HB5OTI560ExGearInfo*/
	/*}#1HB5OTI560ExGearInfo*/
};
export default BoxCatalog;
export{BoxCatalog};