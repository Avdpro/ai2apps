import {tabNT} from "/@tabos";
import {makeObjEventEmitter,makeNotify} from "/@events";


//***************************************************************************
//AaChatThread
//***************************************************************************
let AaChatThread,aaChatThread;
{
	const STATE_NONE="none";
	const STATE_HOST="host";
	const STATE_SHADOW="shadow";
	const STATE_DORMANT="dormant";

	//-----------------------------------------------------------------------
	AaChatThread=function(client){
		this.client=client;
		this.id=null;
		this.title="";
		this.prompt=null;
		this.messages=null;
		this.state=STATE_NONE;
		this.hostClientId=null;
		this.timeStamp=0;
		this.asking=false;
		this.askVo=null;
		this.lastMsgIdx=-1;
		this.lastMsgCode=-1;
		makeNotify(this);
		makeObjEventEmitter(this);
	};
	aaChatThread=AaChatThread.prototype={};
	AaChatThread.STATE_NONE=STATE_NONE;
	AaChatThread.STATE_HOST=STATE_HOST;
	AaChatThread.STATE_SHADOW=STATE_SHADOW;
	AaChatThread.STATE_DORMANT=STATE_DORMANT;
	
	
	//-----------------------------------------------------------------------
	aaChatThread.newHostThread=async function(prompt){
		let threadId;
		threadId=await this.client.callServer("NewThread",{prompt:prompt});
		this.id=threadId;
		this.hostClientId=this.client.id;
		this.state=STATE_HOST;
	};
	
	//-----------------------------------------------------------------------
	aaChatThread.loadFromVo=function(vo){
		this.id=vo.id;
		this.hostClientId=vo.client;
		this.title=vo.title;
		this.timeStamp=vo.timeStamp;
		this.messages=vo.messages||null;
		if(this.hostClientId===this.client.id){
			this.state=STATE_HOST;
		}else if(this.hostClientId){
			this.state=STATE_SHADOW;
			this.asking=vo.asking;
			this.askVo=vo.askVo||null;
		}else{
			this.state=STATE_DORMANT;
			this.asking=false;
			this.askVo=null;
		}
	};
	
	//-----------------------------------------------------------------------
	aaChatThread.syncMessages=async function(){
		let client=this.client;
		if(!this.messages){
			this.messages=await client.callServer("GetThreadMessages",{thread:this.id,from:0});
		}else{
			let newMessages;
			newMessages=await client.callServer("GetThreadMessages",{thread:this.id,from:this.messages.length});
			this.messages.push(...newMessages);
		}
	};
	
	//-----------------------------------------------------------------------
	aaChatThread.postNewMessage=async function(message){
		this.client.postServer("NewMessage",{thread:this.id,message:message});
		this.emit("PostNewMessage",message);
		this.emitNotify("PostNewMessage");
	};
	
	//-----------------------------------------------------------------------
	aaChatThread.addNewMessage=async function(vo){
		let messages,idx,lastMsg,msg;
		messages=this.messages
		if(!messages){
			this.emit("NewMessage",vo);
			this.emitNotify("NewMessage");
			return;
		}
		lastMsg=messages[messages.length-1];
		if(lastMsg && vo.idx<=lastMsg.idx){
			return;
		}else if(!lastMsg || vo.idx>this.lastMsgCode+1){
			let oldLength=messages.length;
			await this.syncMessages();
			messages=this.messages;
			let n=messages.length;
			let start=0;//this.lastMsgIdx+1;
			for(idx=start;idx<n;idx++){
				msg=messages[idx];
				if(this.lastMsgCode<0 || msg.idx===this.lastMsgCode+1){
					console.log("Looping emit: "+msg.idx);
					this.lastMsgIdx=idx;
					this.lastMsgCode=msg.idx;
					this.emit("NewMessage",msg);
				}
			}
			this.emitNotify("NewMessage");
			return;
		}
		if(vo.idx===this.lastMsgCode+1){
			this.lastMsgIdx=messages.length;
			this.lastMsgCode=vo.idx;
			this.messages.push(vo);
			this.emit("NewMessage",vo);
			this.emitNotify("NewMessage");
		}
	};
	
	//-----------------------------------------------------------------------
	aaChatThread.askUser=async function(type,askVo){
		this.asking=type;
		this.askVo=askVo;
		this.client.postServer("AskUser",{thread:this.id,type:type,askVo:askVo});
	};
	
	//-----------------------------------------------------------------------
	aaChatThread.userReply=async function(result){
		if(!this.asking){
			return;
		}
		this.asking=false;
		this.askVo=null;
		if(this.state===STATE_HOST){
			this.client.postServer("UserReply",{thread:this.id,result:result});
		}else{
			this.client.callHostClient(this.hostClientId,"ShadowReply",{thread:this.id,result:result});
		}
	};
	
	//-----------------------------------------------------------------------
	aaChatThread.offline=async function(){
		this.hostClientId=null;
		this.state=STATE_DORMANT;
		this.emit("Offline");
	};
}

//***************************************************************************
//AaChatClient
//***************************************************************************
let AaChatClient,aaChatClient;
{
	//-----------------------------------------------------------------------
	AaChatClient=function(){
		this.id=null;
		this.ws=null;
		this.threads=[];
		this.hostClientId=null;
		this.threadMap=new Map();
		
		this.heartTimer=null;
		
		this.callMap=new Map();
		this.nextCallId=0;
		makeNotify(this);
		makeObjEventEmitter(this);
	};
	aaChatClient=AaChatClient.prototype={};
	
	
	//***********************************************************************
	//Network
	//***********************************************************************
	{	
		//-------------------------------------------------------------------
		aaChatClient.connect=async function(opts){
			let ws,res,clientId,hostClientId;
			let pms,callback,callerror;
			
			opts=opts||{};
			const shadow=opts.shadow||false;
			hostClientId=opts.hostClientId||null;

			pms=new Promise((resolve,reject)=>{
				callback=resolve;
				callerror=reject;
			});

			//Get clientId first:
			if(!(await tabNT.checkLogin(false))){
				//Not login
				return 403;
			}
			clientId=sessionStorage.getItem('Chat-Client-Id');
			if(!clientId){
				res=await tabNT.makeCall("AcsNewClient",{type:shadow?"shadow":"host",host:hostClientId});
				if(!res || res.code!==200){
					//TODO: Can't start new client
					return res.code;
				}
				clientId=this.id=res.clientId;
				if(shadow){
					hostClientId=this.hostClientId=res.hostId;
				}
			}else{
				res=await tabNT.makeCall("AcsResumeClient",{type:shadow?"shadow":"host",clientId:clientId});
				if(!res || res.code!==200){
					sessionStorage.removeItem('Chat-Client-Id');
					return await this.connect(opts);
				}
				this.id=clientId;
				if(shadow){
					hostClientId=this.hostClientId=res.hostId;
				}
			}

			const wsProtocol = location.protocol === 'https:' ? 'wss:' : 'ws:';
			ws=this.ws=new WebSocket(`${wsProtocol}//${document.location.host}`);
			ws.addEventListener('open',()=>{
				ws.send(JSON.stringify({msg:"CONNECT",selector:"ChatClient:"+clientId}));
				console.log("AaChatserver connected.");
			});
			ws.addEventListener('message', async (msg) => {
				let method,msgVO,msgCode;
				console.log("Message from chat server:");
				console.log(msg)
				msgVO=JSON.parse(msg.data);
				console.log(msgVO)
				method=msgVO.method;
				msgCode=msgVO.msg;
				if(!this.isConnected){
					if(msgCode==="CONNECTED"){
						let call;
						this.isConnected=true;
						//Notify into chat session:
						call=callback;
						if(call){
							callback=null;
							callerror=null;
							call();
						}
						sessionStorage.setItem('Chat-Client-Id',this.id);
						console.log("Remote session ready.");
						this.startHeartbeat();
					}else{
						let handler;
						handler="onWs_"+msgCode;
						handler=this[handler]||ws[handler];
						if(handler){
							handler.call(this,msgVO);
						}
						console.log("Message from remote session:");
						console.log()
					}
				}else{
					let handler;
					if(msgCode){
						handler="onWs_"+msgCode;
						handler=this[handler]||ws[handler];
						if(!handler){
							console.log("Can't find chat-client message: "+msgCode);
							return;
						}
					}
					switch(method){
						case "Call":{
							let result,resVO;
							try{
								result=await handler.call(this,msgVO.vo);
								resVO={
									method:"CallResult",
									callId:msgVO.callId,
									result:result
								}
							}catch(err){
								resVO={
									method:"CallResult",
									callId:msgVO.callId,
									error:""+err
								}
							}
							ws.send(JSON.stringify(resVO));
							break;
						}
						case "Post":
							await handler.call(this,msgVO.vo);
							break;
						case "CallResult":{
							let stub, callMap, callId;
							callMap = this.callMap;
							callId = msgVO.callId;
							stub = callMap.get(callId);
							if (stub) {
								callMap.delete(callId);
								if (msgVO.error) {
									stub.reject(msgVO.error);
								} else {
									stub.resolve(msgVO.result);
								}
							}
							break;
						}
					}
				}
			});
			ws.addEventListener('close', (msg) => {
				if(this.isConnected){
					let call;
					this.isConnected=false;
					call=callerror;
					if(call){
						callerror=null;
						callback=null;
						call("Client offline.");
					}
					//Notify not connected...
				}else{
					let call;
					call=callerror;
					if(call){
						callback=null;
						callerror=null;
						call("Client connect failed.");
					}
				}
				if(ws===this.ws){
					this.ws=null;
					this.emit("Offline");
					this.emitNotify("Offline");
				}
			});
			ws.addEventListener('error', (msg) => {
				//wsError(msg);
				//TODO: Show error in session?
			});

			//Wait remote session ready:
			try{
				await pms;
				this.emitNotify("Connected");
				await this.syncThreads();
				return 200;
			}catch(err){
				console.log("RemoteSession start failed:");
				console.error(err);
				return 500;
			}
		};
		
		//-------------------------------------------------------------------
		aaChatClient.startHeartbeat=function(){
			if(this.heartTimer){
				clearInterval(this.heartTimer);
			}
			this.heartTimer=setInterval(()=>{
				if(!this.ws){
					clearInterval(this.heartTimer);
					this.heartTimer=null;
					return;
				}
				this.postServer("Ping",{});
			},10000);
		};
		
		//-------------------------------------------------------------------
		aaChatClient.disconnect=async function(){
			if(this.ws){
				this.ws.close();
			}
		};

		//-------------------------------------------------------------------
		aaChatClient.callServer=async function(msg,vo){
			if(!this.ws){
				throw Error(`Client not connected.`);
			}
			const callId = String(this.nextCallId++);
			const pms = new Promise((resolve, reject) => {
				this.callMap.set(callId,{ callId, resolve, reject });
			});
			const message = JSON.stringify({
				method: "Call",
				msg:msg,vo:vo,
				callId,
			});
			await this.ws.send(message);
			return pms;
		};

		//-------------------------------------------------------------------
		aaChatClient.postServer=async function(msg,vo){
			if(!this.ws){
				throw Error(`Client not connected.`);
			}
			const message = JSON.stringify({
				method: "Post",
				msg:msg,vo:vo,
			});
			await this.ws.send(message);
		};

		//-------------------------------------------------------------------
		aaChatClient.callHostClient=async function(hostClientId,msg,vo){
			if(!this.ws){
				throw Error(`Client not connected.`);
			}
			hostClientId=hostClientId||this.hostClientId;
			const callId = String(this.nextCallId++);
			const pms = new Promise((resolve, reject) => {
				this.callMap.set(callId,{ callId, resolve, reject });
			});
			const message = JSON.stringify({
				method: "CallHostClient",
				host:hostClientId,
				msg:msg,vo:vo,
				callId,
			});
			await this.ws.send(message);
			return pms;
		};

		//-------------------------------------------------------------------
		aaChatClient.postHostClient=async function(hostClientId,msg,vo){
			if(!this.ws){
				throw Error(`Client not connected.`);
			}
			hostClientId=hostClientId||this.hostClientId;
			const pms = new Promise((resolve, reject) => {
				this.callMap.set(callId,{ callId, resolve, reject });
			});
			const message = JSON.stringify({
				method: "PostHostClient",
				host:hostClientId,
				msg:msg,vo:vo,
			});
			await this.ws.send(message);
			return pms;
		};
	}
	
	//***********************************************************************
	//Handlers
	//***********************************************************************
	{
		//-------------------------------------------------------------------
		aaChatClient.onWs_NewThread=async function(vo){
			let thread,threadId,threadVo;
			threadId=vo.thread;
			thread=this.threadMap.get(threadId);
			if(thread){
				return;
			}
			threadVo=await this.callServer("GetThread",{id:threadId});
			if(threadVo){
				thread=new AaChatThread(this);
				thread.loadFromVo(threadVo);
				this.threadMap.set(threadId,thread);
				this.emit("NewThread",thread);
			}
		};

		//-------------------------------------------------------------------
		aaChatClient.onWs_NewThreadMessage=async function(vo){
			let thread,threadId;
			threadId=vo.thread;
			thread=this.threadMap.get(threadId);
			if(!thread){
				let threadVo;
				threadVo=await this.callServer("GetThread",{id:threadId,messages:true});
				thread=new AaChatThread(this);
				await thread.loadFromVo(threadVo);
				this.emitNotify("NewMessage");
				this.emit("NewMessage",vo.message);
				return;
			}
			thread.addNewMessage(vo.message);
			this.emit("NewMessage",thread,vo.message);
		};
		
		//-------------------------------------------------------------------
		aaChatClient.onWs_AskUser=async function(vo){
			let thread,threadId;
			threadId=vo.thread;
			thread=this.threadMap.get(threadId);
			if(!thread){
				//We don't care
				return;
			}
			thread.asking=vo.type;
			thread.askVo=vo.askVo;
			thread.emit("AskUser",vo);
		};

		//-------------------------------------------------------------------
		aaChatClient.onWs_ShadowReply=async function(vo){
			let thread,threadId,askType;
			threadId=vo.thread;
			thread=this.threadMap.get(threadId);
			if(!thread){
				//We don't care
				return;
			}
			askType=thread.asking;
			thread.emit("UserReply",askType,vo.result);
		};

		//-------------------------------------------------------------------
		aaChatClient.onWs_UserReply=async function(vo){
			let thread,threadId,askType;
			threadId=vo.thread;
			thread=this.threadMap.get(threadId);
			if(!thread){
				//We don't care
				return;
			}
			askType=thread.asking;
			thread.asking=false;
			thread.askVo=null;
			thread.emit("UserReply",askType,vo.result);
		};

		//-------------------------------------------------------------------
		aaChatClient.onWs_ThreadOffline=async function(vo){
			let thread,threadId;
			threadId=vo.thread;
			thread=this.threadMap.get(threadId);
			if(!thread){
				return;
			}
			thread.offline();
		};

		//-------------------------------------------------------------------
		aaChatClient.onWs_RenameThread=async function(vo){
			let thread,threadId;
			threadId=vo.thread;
			thread=this.threadMap.get(threadId);
			if(!thread){
				return;
			}
			thread.title=vo.title;
			thread.emit("Rename",vo.title);
		};
		
		//-------------------------------------------------------------------
		aaChatClient.onWs_NewShadowThread=async function(vo){
			let args,thread,tool;
			args=vo.args;
			tool=vo.tool;
			thread=await this.newThread(args);
			this.emit("NewShadowThread",thread,args,tool);
			return thread.id;
		};
		
		//-------------------------------------------------------------------
		aaChatClient.onWs_ArchiveThread=async function(vo){
			let threadId,thread;
			threadId=vo.thread;
			thread=this.threadMap.get(threadId);
			if(thread){
				let idx;
				idx=this.threads.indexOf(thread);
				if(idx>=0){
					this.threads.splice(idx,1);
				}
				this.threadMap.delete(threadId);
				this.emit("ArchiveThread",thread);
			}
		};

		//-------------------------------------------------------------------
		aaChatClient.onWs_DeleteThread=async function(vo){
			let threadId,thread;
			threadId=vo.thread;
			thread=this.threadMap.get(threadId);
			if(thread){
				let idx;
				idx=this.threads.indexOf(thread);
				if(idx>=0){
					this.threads.splice(idx,1);
				}
				this.threadMap.delete(threadId);
				this.emit("DeleteThread",thread);
			}
		};

		//-------------------------------------------------------------------
		aaChatClient.onWs_HostClientOffline=async function(vo){
			if(vo.client===this.hostClientId){
				this.emit("HostClientOffline");
				this.emitNotify("HostClientOffline");
			}
		};
	}
	
	//***********************************************************************
	//Threads:
	//***********************************************************************
	{
		//-------------------------------------------------------------------
		aaChatClient.newThread=async function(prompt){
			let vo,thread;
			thread=new AaChatThread(this);
			await thread.newHostThread(prompt);
			if(thread.id){
				this.threads.push(thread);
				this.threadMap.set(thread.id,thread);
				return thread;
			}
			return null;
		};
		
		//-------------------------------------------------------------------
		aaChatClient.newThreadOnHost=async function(vo){
			let threadId,thread,callback;
			let WaitThread=(thread)=>{
				if(threadId===threadId){
					this.off("NewThread",WaitThread);
					callback(thread);
				}
			};
			if(!this.hostClientId){
				throw Error("Client is not shadow.");
			}
			threadId=await this.callHostClient(null,"NewShadowThread",vo);
			if(threadId){
				thread=this.threadMap.get(threadId);
				if(thread){
					return thread;
				}
				return new Promise((resolve,reject)=>{
					callback=resolve;
					this.on("NewThread",WaitThread);
				});
			}
			return null;
		};
		
		//-------------------------------------------------------------------
		aaChatClient.syncThreads=async function(){
			let threads,threadMap,thread,threadVos,vo;
			threads=this.threads;
			threadMap=this.threadMap;
			threadVos=await this.callServer("GetThreads",{});
			threadVos=threadVos.sort((vo1,vo2)=>{
				return -(vo1.timeStamp-vo2.timeStamp);
			})
			threads.splice(0);
			for(vo of threadVos){
				thread=threadMap.get(vo.id);
				if(!thread){
					thread=new AaChatThread(this);
					await thread.loadFromVo(vo);
					threadMap.set(thread.id,thread);
				}
				threads.push(thread);
			}
			this.emitNotify("ThreadsSynced");
		};
	}
}

export default AaChatClient;
export {AaChatClient};