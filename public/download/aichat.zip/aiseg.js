import {ChatAction} from "./chataction.js";
const AISegTypes=new Set(["Call","SetMemory","Branch","Summary","AskConfirm","AskMenu","AskText","AskFile"]);
let AISeg,aiSeg,AISegTypes;
let AISegCall,AISegMem,AISegBranch,AISegSummary,AISegAsk;
//****************************************************************************
//:AISeg
//****************************************************************************
AISeg=function(session){
	this.session=session;
	this.type="";//AIType
	this.name="";
	this.inputPatten="`${$CONTENT}`";
	this.outpuPatten="`${$CONTENT}`";
};
aiSeg=AISeg.prototype={};
AISegTypes={};

//****************************************************************************
//:AISeg's I/O
//****************************************************************************
{
	//------------------------------------------------------------------------
	AISeg.newSeg=async function(session,type){
		let func,seg;
		func=AISegTypes[type];
		if(!func){
			throw Error(`Unknown AISeg type: ${type}.`);
		}
		seg=new func(session);
		return seg;
	};
	
	//------------------------------------------------------------------------
	AISeg.loadSeg=async function(session,vo){
		let type,func,seg;
		type=vo.type;
		func=AISegTypes[type];
		if(!func){
			throw Error(`Unknown AISeg type: ${type}.`);
		}
		seg=new func(session);
		await seg.loadFromVO(vo);
		return seg;
	};
	
	//------------------------------------------------------------------------
	aiSeg.genSaveVO=function(){
		let vo;
		vo={};
		vo.name=this.name;
		vo.inputPatten=this.inputPatten;
		return vo;
	};

	//------------------------------------------------------------------------
	aiSeg.loadFromVO=async function(vo){
		this.name=vo.name;
		this.inputPatten=vo.inputPatten;
	};
}

//****************************************************************************
//:AISeg's Follow control
//****************************************************************************
{
	//------------------------------------------------------------------------
	aiSeg.execSeg=async function(input){
		//TODO: Code this:
	};
	
	//------------------------------------------------------------------------
	//For editor:
	aiSeg.getNextSegs=function(){
		return null;
	};
}

//****************************************************************************
//:AISeg's visual edit support:
//****************************************************************************
{
	//------------------------------------------------------------------------
	aiSeg.getEditAttrs=function(){
		return{
			name:{
				attr:"name",tip:"Seg's Name:",type:"string",placeHolder:"Seg's name",
				check(val){
					//TODO: Check it.
					return true;
				}
			},
			inputPatten:{
				attr:"inputPatten",tip:"Input patten:",type:"string",placeHolder:"e.g. `is ${$CONTENT} correct?`",
				check:(val)=>{
					//TODO: Check it.
					return true;
				},
				set:(val)=>{
					this.inputPatten=val?val:null;
				}
			},
			ouputPatten:{
				attr:"ouputPatten",tip:"Ouput patten:",type:"string",placeHolder:"e.g. `is ${$CONTENT} correct?`",
				check:(val)=>{
					//TODO: Check it.
					return true;
				},
				set:(val)=>{
					this.ouputPatten=val?val:null;
				}
			},
		};
	};
	
	//------------------------------------------------------------------------
	//For editor:
	aiSeg.getNextSegs=function(){
		return null;
	};
}

//****************************************************************************
//:AISegCall
//****************************************************************************
{
	
}

