//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1HA0EN6720StartDoc*/
import pathLib from "/@path";
import {ChatSession} from "../chatsession.js";
/*}#1HA0EN6720StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BoxAIChat=function(){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1HA0EN6730LocalVals*/
	const app=VFACT.app;
	const rootApp=app.appFrame?app.appFrame.app:app;
	let session=null;
	let entryURL=null;
	let entryJSON=null;
	let chatBot=null;
	let chatBotURL=null;
	let sessionMap=new Map();
	let chatBlockDefs=null;
	let askBlockDefs=null;
	let liveBlockNum=0;
	let basePath;
	let askUserBlock=null;
	let askUserReject=null;
	let indent=0;
	let indentSize=10;
	basePath=pathLib.dirname(document.location.pathname);
	/*}#1HA0EN6730LocalVals*/
	
	/*#{1HA0EN6730PreState*/
	/*}#1HA0EN6730PreState*/
	/*#{1HA0EN6730PostState*/
	/*}#1HA0EN6730PostState*/
	cssVO={
		"hash":"1HA0EN6730",nameHost:true,
		"type":"hud","x":0,"y":0,"w":300,"h":100,"padding":[0,0,20,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
		/*#{1HA0EN6730ExtraCSS*/
		app:app,notifyApp:rootApp||app,
		/*}#1HA0EN6730ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			self=this;
			
			/*#{1HA0EN6730Create*/
			/*}#1HA0EN6730Create*/
		},
		/*#{1HA0EN6730EndCSS*/
		basePath:basePath,
		/*}#1HA0EN6730EndCSS*/
	};
	/*#{1HA0EN6730PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.initBlockDef=function(chatDefs,askDefs){
		chatBlockDefs=chatDefs;
		askBlockDefs=askDefs;
	};
	
	//------------------------------------------------------------------------
	cssVO.initSession=async function(url,greeting=true,resetBot=false,json=null){
		let bot,isNewBot;
		if(entryURL!==url){
			isNewBot=true;
			entryURL=url;
			entryJSON=json;
		}
		if(!chatBlockDefs){
			console.warning("BoxAIChat's block def is not inited.");
		}
		if(session){
			//There is an old session, stop or close it?
		}
		session=sessionMap.get(url);
		if(!session){
			session=new ChatSession(this);
			sessionMap.set(url,session);
		}
		this.session=session;
		if(isNewBot || liveBlockNum===0){
			bot=await session.initEntry(url,json);
			this.entryBot=bot;
			chatBotURL=url;
			if(bot.isAIChatBot){
				if(greeting && chatBlockDefs && bot.greeting && !liveBlockNum){
					self.appendChatBlock({type:"greeting",text:bot.greeting});
				}
			}
		}
		indent=0;
		return session;
	};
	
	//------------------------------------------------------------------------
	cssVO.execChat=async function(botURL,arg){
		let result;
		botURL=botURL||chatBotURL;
		indent=0;
		try{
			result=await session.execChat(botURL,arg);
		}catch(err){
			let errType=typeof(err);
			if(errType==="object"){
				if(err.code && err.info){
					err=`Error ${err.code}: ${err.info}`;
				}else if(err.info){
					err=err.info;
				}else{
					err=(($ln==="CN")?("Error: "+err+"\n执行AI任务的时候发生错误，更多的信息请查看浏览器的控制台。"):/*EN*/("Error: "+err+"\nError in AI task, check browser's console for more infomation."));
				}
			}else if(errType!=="string"){
				err=(($ln==="CN")?("Error: "+err+"\n执行AI任务的时候发生错误，更多的信息请查看浏览器的控制台。"):/*EN*/("Error: "+err+"\nError in AI task, check browser's console for more infomation."));
			}
			self.appendChatBlock({type:"error",text:""+err});
		}
		indent=0;
		return result;
	};
	
	//------------------------------------------------------------------------
	cssVO.resetChat=async function(restart=true){
		let url=entryURL;
		liveBlockNum=0;
		self.clearChildren();
		indent=0;
		entryURL=null;
		this.session=null;
		sessionMap.clear();
		if(restart){
			return await this.initSession(url,true,false,entryJSON);
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.clearChats=async function(greeting=true){
		let bot;
		liveBlockNum=0;
		self.clearChildren();
		indent=0;
		if(session){
			await session.resetBots();
			//Show greeting again?
			bot=await session.loadBot(chatBotURL);
			if(greeting && chatBlockDefs && bot.greeting){
				this.entryBot=bot;
				self.appendChatBlock({type:"greeting",text:bot.greeting});
			}
		}
	};
	
	//************************************************************************
	//Interface for chatSession:
	//************************************************************************
	{
		//--------------------------------------------------------------------
		cssVO.appendChatBlock=function(blockVO){
			let blkDef,block;
			blkDef=chatBlockDefs[blockVO.type];
			if(blkDef===null){
				return null;
			}
			if(!blkDef){
				throw Error("Unkonwn chat block type: "+blockVO.type);
			}
			if(!liveBlockNum){
				blockVO.top=true;
			}
			if(self.checkChatBlock){
				if(self.checkChatBlock(blockVO)===false){
					return null;
				}
			}
			blkDef=blkDef(session,blockVO);
			if(indent>0){
				blkDef.x=indent*indentSize;
				blkDef.w=`>calc(100% - ${indent*indentSize}px)`;
			}
			block=self.appendNewChild(blkDef);
			self.scrollDown();
			//VFACT.scrollToShow(block);
			liveBlockNum+=1;
			return block;
		};
	
		//--------------------------------------------------------------------
		cssVO.removeChatBlock=async function(block,maybe=true){
			if(self.keepBlocks && maybe){
				return;
			}
			self.removeChild(block);
			liveBlockNum-=1;
		};
	
		//--------------------------------------------------------------------
		cssVO.abortChat=async function(reason="User abort."){
			let err;
			if(typeof(reason==="string")){
				err=Error(reason);
			}else{
				err=reason;
			}
			session.abortChat(err);
			if(askUserBlock){
				askUserBlock.abort();
				askUserBlock=null;
			}
			if(askUserReject){
				askUserReject(err);
				askUserReject=null;
			}
		};
		
		//--------------------------------------------------------------------
		cssVO.askChatInput=async function(askVO){
			let chatCall;
			chatCall=askBlockDefs["chatInput"];
			if(chatCall){
				return await chatCall(askVO);
			}
			return await self.askUser({type:"input",...askVO});
		};
	
		//--------------------------------------------------------------------
		cssVO.cancelChatInput=async function(){
			let cancelChatInput;
			cancelChatInput=askBlockDefs["cancelChatInput"];
			if(cancelChatInput){
				cancelChatInput();
			}
		};
	
		//--------------------------------------------------------------------
		cssVO.askUserRaw=async function(askVO){
			let blkDef,block,pms,chatPms,result;
			blkDef=askBlockDefs[askVO.type];
			if(!blkDef){
				throw Error("Unkonwn askUser type: "+askVO.type);
			}
			blkDef=blkDef(session,askVO);
			if(indent>0){
				blkDef.x=indent*indentSize;
				blkDef.w=`>calc(100% - ${indent*indentSize}px)`;
			}
			pms=new Promise((resovle,reject)=>{
				askUserBlock=block=self.appendNewChild(blkDef);
				askUserReject=reject;
				if(block.setCallback){
					block.setCallback(resovle);
				}else{
					block.callback=resovle;
				}
				callAfter(()=>{				
					self.scrollDown();
				},100);
			});
			if(askVO.withChat){
				chatPms=self.askChatInput(askVO);
				result=await Promise.any([pms,chatPms]);
				if(Array.isArray(result)){
					self.cancelChatInput();
				}else{
					askUserBlock.cancelAsk(result);
					result=[result,result];
				}
				askUserBlock=null;
				askUserReject=null;
				return result;
			}
			//AskBlocks must call callback function with a array of result text and value, the text will show in UI and value will return as result.
			result=await pms;
			askUserBlock=null;
			askUserReject=null;
			return result;
		};
		
		//--------------------------------------------------------------------
		cssVO.askUser=async function(askVO){
			let blkDef,block,pms,resultTxt,resultVal;
			blkDef=askBlockDefs[askVO.type];
			if(!blkDef){
				throw Error("Unkonwn askUser type: "+askVO.type);
			}
			blkDef=blkDef(session,askVO);
			if(indent>0){
				blkDef.x=indent*indentSize;
				blkDef.w=`>calc(100% - ${indent*indentSize}px)`;
			}
			pms=new Promise((resovle,reject)=>{
				askUserBlock=block=self.appendNewChild(blkDef);
				askUserReject=reject;
				if(block.setCallback){
					block.setCallback(resovle);
				}else{
					block.callback=resovle;
				}
				self.scrollDown();
				//VFACT.scrollToShow(block);
			});
			//AskBlocks must call callback function with a array of result text and value, the text will show in UI and value will return as result.
			[resultTxt,resultVal]=await pms;
			askUserBlock=null;
			askUserReject=null;
			self.appendChatBlock({type:"user",text:resultTxt});
			return resultVal;
		};
		
		//--------------------------------------------------------------------
		cssVO.scrollDown=function(){
			let webObj;
			webObj=self.webObj;
			if(webObj.scrollHeight>webObj.offsetHeight){
				webObj.scrollTop=webObj.scrollHeight;
			}else{
				webObj=self.parent.webObj;
				webObj.scrollTop=webObj.scrollHeight;
			}
		};
		
		//--------------------------------------------------------------------
		cssVO.incIndent=function(){
			indent+=1;
		};
	
		//--------------------------------------------------------------------
		cssVO.decIndent=function(){
			if(indent>0){
				indent-=1;
			}
		};
	}
	/*}#1HA0EN6730PostCSSVO*/
	return cssVO;
};
/*#{1HA0EN6730ExCodes*/
/*}#1HA0EN6730ExCodes*/

BoxAIChat.gearExport={
	framework: "jax",
	hudType: "hud",
	"showName":"AIChat",icon:"gears.svg",previewImg:false,
	fixPose:false,initW:300,initH:100,
	catalog:"Views",
	args: {},
	state:{
	},
	properties:["id","position","x","y","w","h","anchorH","anchorV","autoLayout","display","clip","uiEvent","alpha","rotate","scale","cursor","zIndex","margin","traceSize","minW","minH","maxW","maxH","styleClass"],
	faces:[],
	subContainers:{
	},
	/*#{1HA0EN6720ExGearInfo*/
	/*}#1HA0EN6720ExGearInfo*/
};
/*#{1HA0EN6720EndDoc*/
/*}#1HA0EN6720EndDoc*/

export default BoxAIChat;
export{BoxAIChat};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1HA0EN6720",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1HA0EN6731",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1HA0EN6732",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1HA0EN6733",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1HA0EN6734",
//			"attrs": {}
//		},
//		"localVars": {
//			"jaxId": "1HA0EN6735",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1HA0EN6736",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "AIChat",
//		"gearIcon": "gears.svg",
//		"gearW": "300",
//		"gearH": "100",
//		"gearCatalog": "Views",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1HA0EN6737",
//			"attrs": {}
//		},
//		"mockupStates": {
//			"jaxId": "1HAA4CL680",
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1HA0EN6730",
//			"attrs": {
//				"properties": {
//					"jaxId": "1HA0EN6738",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "300",
//						"h": "100",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "[0,0,20,0]",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Flex Y"
//					}
//				},
//				"subHuds": {
//					"attrs": []
//				},
//				"faces": {
//					"jaxId": "1HA0EN6739",
//					"attrs": {}
//				},
//				"functions": {
//					"jaxId": "1HA0EN67310",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1HA0EN67311",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "true",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "true",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1HA0EN67312",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "true",
//				"h": "true",
//				"anchorH": "true",
//				"anchorV": "true",
//				"autoLayout": "true",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "true",
//				"uiEvent": "true",
//				"alpha": "true",
//				"rotate": "true",
//				"scale": "true",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "true",
//				"zIndex": "true",
//				"flex": "false",
//				"margin": "true",
//				"traceSize": "true",
//				"padding": "false",
//				"minW": "true",
//				"minH": "true",
//				"maxW": "true",
//				"maxH": "true",
//				"styleClass": "true"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}