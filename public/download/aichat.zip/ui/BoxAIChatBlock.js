//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
/*#{1HA0EVOKU0StartDoc*/
import pathLib from "/@path";
import Base64 from "/@tabos/utils/base64.js";
import {BoxCodeSeg} from "./BoxCodeSeg.js";
import markdownit from "/@markdownit";
/*}#1HA0EVOKU0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BoxAIChatBlock=function(vo,session){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let boxContents,txtContent,boxMD,image,boxAudioSlot,btnCopy,boxCopyMark;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let icon=vo.icon||(appCfg.sharedAssets+"/faces.svg");
	let showText=vo.text||"";
	
	/*#{1HA0EVOKU1LocalVals*/
	let isDesktop=true;
	let tracedObj=null;
	let tracePrefix="";
	let tracePostfix="";
	let owner=null;
	let hideOnTraceClose=true;
	let webAudio;
	if(showText.length>1024*20){
		showText=showText.substring(0,1024*20);
	}
	/*}#1HA0EVOKU1LocalVals*/
	
	/*#{1HA0EVOKU1PreState*/
	/*}#1HA0EVOKU1PreState*/
	/*#{1HA0EVOKU1PostState*/
	/*}#1HA0EVOKU1PostState*/
	cssVO={
		"hash":"1HA0EVOKU1",nameHost:true,
		"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":"","padding":[15,30,10,50],"minW":"","minH":30,"maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
		"traceSize":true,
		children:[
			{
				"hash":"1HA0F1G1C0",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":vo.blkColor||[0,0,0,0],
				"border":vo.top?0:[1,0,0,0],"borderColor":cfgColor["fontBodyLit"],"contentLayout":"flex-x","itemsWrap":1,
			},
			{
				"hash":"1HA0FE4LK0",
				"type":"box","id":"BoxIcon","x":11,"y":5,"w":28,"h":28,"padding":2,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":vo.iconBG||vo.bgColor,
				"corner":5,
				children:[
					{
						"hash":"1HA0GFET80",
						"type":"box","position":"relative","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":vo.iconColor,
						"maskImage":icon,"attached":!!vo.icon,
					},
					{
						"hash":"1HB2MJU6E0",
						"type":"image","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","image":vo.pic,"fitSize":"cover","attached":!!vo.pic,
					}
				],
			},
			{
				"hash":"1HA0G844M0",
				"type":"hud","id":"BoxContents","position":"relative","x":0,"y":0,"w":"100%","h":"","minW":"","minH":20,"maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
				children:[
					{
						"hash":"1HA0H00DG0",
						"type":"text","id":"TxtContent","position":"relative","x":0,"y":0,"w":"100%","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":vo.textColor,
						"text":showText,"fontSize":txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","wrap":true,"selectable":true,
					},
					{
						"hash":"1HGQTLVFR0",
						"type":"hud","id":"BoxMD","position":"relative","x":0,"y":0,"w":"100%","h":"","display":0,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
					},
					{
						"hash":"1HEK4VTO80",
						"type":"image","id":"Image","position":"relative","x":0,"y":0,"w":100,"h":100,"margin":[5,0,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						"image":vo.image,"fitSize":"contain","attached":!!vo.image,
						children:[
							{
								"hash":"1HEQ2E04B0",
								"type":BtnIcon("front",30,0,appCfg.sharedAssets+"/save.svg",null),"id":"BtnSaveImg","x":"100%","y":">calc(100% - 30px)","anchorY":1,
								"OnClick":function(event){
									/*#{1HEQ2GOVT0FunctionBody*/
									self.saveImage();
									/*}#1HEQ2GOVT0FunctionBody*/
								},
							}
						],
						"OnLoad":function(){
							/*#{1HEK542I00FunctionBody*/
							let imgW,imgH,pw,maxW,maxH,ph;
							imgW=this.imageW;imgH=this.imageH;
							pw=this.parent.w;
							maxW=pw*0.8;
							maxH=pw*2;
							if(imgW<maxW && imgH<maxH){
								this.w=imgW;this.h=imgH;
							}else if(imgW>=maxW && imgH>=maxH){
								ph=maxH/imgH;
								pw=maxW/imgW;
								if(pw>ph){
									this.h=maxH;
									this.w=maxH/imgH*imgW;
								}else{
									this.w=maxW;
									this.h=maxW/imgW*imgH;
								}
							}else if(imgW>=maxW){
								this.w=maxW;
								this.h=maxW/imgW*imgH;
							}else{
								this.h=maxH;
								this.w=maxH/imgH*imgW;
							}
							/*}#1HEK542I00FunctionBody*/
						},
					},
					{
						"hash":"1HEN2ROP70",
						"type":"hud","id":"BoxAudio","position":"relative","x":0,"y":0,"w":"100%","h":30,"margin":[5,0,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						"contentLayout":"flex-x","attached":!!vo.audio,"itemsAlign":1,
						children:[
							{
								"hash":"1HEN2TTCK0",
								"type":"box","id":"BoxPlayAudio","position":"relative","x":0,"y":0,"w":80,"h":30,"cursor":"pointer","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
								"background":cfgColor["success"],"border":1,"borderColor":cfgColor["secondary"],"corner":[0,8,8,8],
								children:[
									{
										"hash":"1HEN2VICR0",
										"type":"box","x":"50%","y":"50%","w":28,"h":28,"anchorX":1,"anchorY":1,"uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
										"background":cfgColor["fontSuccess"],"maskImage":appCfg.sharedAssets+"/sound.svg",
									}
								],
								"OnClick":function(event){
									/*#{1HEN3E9430FunctionBody*/
									if(webAudio){
										webAudio.play();
									}
									/*}#1HEN3E9430FunctionBody*/
								},
							},
							{
								"hash":"1HEN3GINJ0",
								"type":BtnIcon("front",28,0,appCfg.sharedAssets+"/save.svg",null),"position":"relative","x":0,"y":0,"margin":[0,0,0,5],
								"OnClick":function(event){
									/*#{1HENF70OE0FunctionBody*/
									self.downloadAudio();
									/*}#1HENF70OE0FunctionBody*/
								},
							},
							{
								"hash":"1HEN33S1J0",
								"type":"hud","id":"BoxAudioSlot","position":"relative","x":0,"y":0,"w":10,"h":10,"overflow":1,"alpha":0,"minW":"","minH":"","maxW":"","maxH":"",
								"styleClass":"",
							}
						],
					}
				],
			},
			{
				"hash":"1HA0H30PR0",
				"type":"hud","x":"100%","y":0,"w":30,"h":30,"anchorX":2,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				children:[
					{
						"hash":"1HA0H8MAA0",
						"type":BtnIcon(cfgColor.fontBodySub,25,0,appCfg.sharedAssets+"/copy.svg",null),"id":"BtnCopy","x":"50%","y":"50%","anchorX":1,"anchorY":1,"attached":vo.buttons,
						"OnClick":function(event){
							/*#{1HA77UIQA0FunctionBody*/
							self.doCopy();
							/*}#1HA77UIQA0FunctionBody*/
						},
					},
					{
						"hash":"1HA783RAB0",
						"type":"box","id":"BoxCopyMark","position":"relative","x":"50%","y":"50%","w":"50%","h":"50%","anchorX":1,"anchorY":1,"display":0,"minW":"","minH":"",
						"maxW":"","maxH":"","styleClass":"","background":cfgColor["fontBody"],"border":1,"maskImage":appCfg.sharedAssets+"/check.svg",
					}
				],
			}
		],
		/*#{1HA0EVOKU1ExtraCSS*/
		/*}#1HA0EVOKU1ExtraCSS*/
		faces:{
			"desktop":{
				"#self":{
					"padding":[10,30,15,50]
				},
				"#1HA0H30PR0":{
					"y":0
				}
			},"mobile":{
				"#self":{
					"padding":vo.buttons?[10,5,30,50]:[10,5,10,50]
				},
				"#1HA0H30PR0":{
					"y":">calc(100% - 30px)"
				}
			}
		},
		OnCreate:function(){
			self=this;
			boxContents=self.BoxContents;txtContent=self.TxtContent;boxMD=self.BoxMD;image=self.Image;boxAudioSlot=self.BoxAudioSlot;btnCopy=self.BtnCopy;boxCopyMark=self.BoxCopyMark;
			/*#{1HA0EVOKU1Create*/
			self.content=vo.text||vo.content;
			if(vo.render){
				self.renderContents();
			}
			if(vo.audio){
				boxAudioSlot.webObj.innerHTML=`<audio id="audioPlayer" controls> <source src="data:audio/mp3;base64,${vo.audio}" type="audio/mp3"></audio>`;
				webAudio=boxAudioSlot.webObj.firstChild;
				if(vo.autoPlay!==false){
					callAfter(()=>{webAudio.play()});
				}
			}
			/*}#1HA0EVOKU1Create*/
		},
		/*#{1HA0EVOKU1EndCSS*/
		/*}#1HA0EVOKU1EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.OnSize=function(){
		/*#{1HA0HQH3P0FunctionBody*/
		self.content=vo.text||vo.content;
		if(!isDesktop && self.w>=500){
			self.showFace("desktop");
			isDesktop=true;
		}else if(isDesktop && self.w<500){
			self.showFace("mobile");
			isDesktop=false;
		}
		/*}#1HA0HQH3P0FunctionBody*/
	};
	
	//------------------------------------------------------------------------
	cssVO.OnFree=function(){
		/*#{1HA0IDR1E0FunctionBody*/
		if(tracedObj){
			tracedObj.off("content",self.OnUpdate);
			tracedObj.off("close",self.OnClose);
			tracedObj=null;
		}
		/*}#1HA0IDR1E0FunctionBody*/
	};
	/*#{1HA0EVOKU1PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.renderContents=function(){
		let content,htmlCode,webObj,list,i,n,blks,blk,upperElement,tagType,blkBox,code,mode,pos;
		boxMD.display=true;
		txtContent.display=false;
		content=""+self.content;
		htmlCode=markdownit().render(content);
		webObj=boxMD.webObj;
		webObj.style.fontSize="14px";
		webObj.innerHTML=htmlCode;
		//First, fix tab-border
		list=webObj.querySelectorAll("table");
		n=list.length;
		for(i=0;i<n;i++){
			blk=list[i];
			blk.style.border="1px solid black";
			blk.style.borderSpacing="0px";
		}
		//First, fix tab-border
		list=webObj.querySelectorAll("table");
		n=list.length;
		for(i=0;i<n;i++){
			blk=list[i];
			blk.style.border="1px solid black";
		}
		list=webObj.querySelectorAll("th");
		n=list.length;
		for(i=0;i<n;i++){
			blk=list[i];
			blk.style.border="1px solid black";
		}
		list=webObj.querySelectorAll("td");
		n=list.length;
		for(i=0;i<n;i++){
			blk=list[i];
			blk.style.border="1px solid gray";
		}
		list=webObj.querySelectorAll("img");
		n=list.length;
		for(i=0;i<n;i++){
			blk=list[i];
			blk.style.maxWidth="100%";
		}
		list=webObj.children;
		blks=[];
		n=list.length;
		for(i=0;i<n;i++){
			blks.push(list[i]);
		}
		for(i=0;i<n;i++){
			blk=blks[i];
			blkBox=boxMD.appendNewChild({
				type:"hud",width:"100%",height:"",position:"relative",
			});
			tagType=blk.tagName.toLowerCase();
			if(tagType==="pre"){
				list=blk.childNodes;
				if(list.length===1 && list[0].tagName.toLowerCase()==="code"){
					mode=list[0].className||"";
					pos=mode.indexOf("-");
					if(pos>0){
						mode=mode.substring(pos+1);
					}else{
						mode="";
					}
					code=list[0].innerText;
					boxMD.webObj.removeChild(blk);
					blkBox.appendNewChild(BoxCodeSeg(code,mode));
				}else{
					blkBox.webObj.appendChild(blk);
				}
			}else{
				if(i===0){
					blk.style.marginBlockStart="0px";
				}
				blkBox.webObj.appendChild(blk);
			}
		}
	};
	
	//------------------------------------------------------------------------
	cssVO._renderContents=function(){
		let content,preCode,code,postCode;
		let parsePos,pos,fullLength;
		let textBlk=txtContent;
		parsePos=0;
		content=self.content;
		fullLength=content.length;
		do{
			pos=content.indexOf("```",parsePos);
			if(pos>=0){
				//Precode:
				preCode=content.substring(parsePos,pos);
				if(textBlk){
					textBlk.text=preCode;
					textBlk=null;
				}else{
					if(preCode.length){
						boxContents.appendNewChild({
							"type":"text","position":"relative","x":0,"y":0,"w":"100%","h":"","color":vo.textColor||cfgColor.fontBody,
							"text":preCode,"fontSize":txtSize.smallPlus,"wrap":true,"selectable":true,
						});
					}
				}
				//find Code:
				parsePos=pos+3;
				pos=content.indexOf("```",parsePos);
				if(pos<0){
					pos=fullLength;
				}
				code=content.substring(parsePos,pos);
				if(code.length){
					boxContents.appendNewChild(
						BoxCodeSeg(code,"")
					);
				}
				parsePos=pos+3;
			}else{
				postCode=content.substring(parsePos);
				if(textBlk){
					textBlk.text=postCode;
					textBlk=null;
				}else{
					if(postCode.length){
						boxContents.appendNewChild({
							"type":"text","position":"relative","x":0,"y":0,"w":"100%","h":"","color":vo.textColor||cfgColor.fontBody,
							"text":postCode,"fontSize":txtSize.smallPlus,"wrap":true,"selectable":true,
						});
					}
				}
				parsePos=fullLength;
			}
		}while(parsePos>=0 && parsePos<fullLength);
	};
	
	//------------------------------------------------------------------------
	cssVO.trace=function(obj,prefix="",postfix="",autoHide=true){
		owner=self.parent;
		tracedObj=obj;
		hideOnTraceClose=autoHide;
		tracePrefix=prefix;
		tracePostfix=postfix;
		obj.on("content",self.OnUpdate);
		obj.on("close",self.OnClose);
	};
	
	function replaceTextContent(text) {
		// 替换所有数字为 "#"
		let result = text.replace(/\d/g, "#");
		// 替换所有拉丁字母为 "*"
		result = result.replace(/[a-zA-Z]/g, "*");
		// 替换所有非ASCII字符（例如中文）为 "■"
		result = result.replace(/[^\x00-\x7F]+/g, "■");
	
		return result;
	}
	
	//------------------------------------------------------------------------
	cssVO.OnUpdate=function(){
		if(tracedObj){
			if(session.hideInternal){
				let tgtText,srcText;
				self.content=txtContent.text=tracePrefix+replaceTextContent(tracedObj.content)+tracePostfix;
			}else{
				self.content=txtContent.text=tracePrefix+tracedObj.content+tracePostfix;
			}
			owner.scrollDown();
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.OnClose=function(){
		if(tracedObj){
			tracedObj.off("content",self.OnUpdate);
			tracedObj.off("close",self.OnClose);
			tracedObj=null;
			if(hideOnTraceClose){
				self.display=0;
			}
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.doCopy=function(){
		navigator.clipboard.writeText(self.content);
		boxCopyMark.display=1;
		boxCopyMark.animate({type:"out",time:500,alpha:0,delay:500});
	};
	
	//------------------------------------------------------------------------
	cssVO.saveImage=async function(){
		let fileName;
		function downloadBuf(data){
			var img = new Image();
			img.crossOrigin = "Anonymous";
			img.src = data;
			img.onload = function () {
				var canvas = document.createElement("canvas");
				var context = canvas.getContext("2d");
				canvas.width = img.width;
				canvas.height = img.height;
				context.drawImage(img, 0, 0);
				var dataURL = canvas.toDataURL("image/png");
				var link = document.createElement("a");
				link.href = dataURL;
				link.download = "image.png";
				link.click();
			};
		}
		function downloadFile(data){
			let e,blob,url;
			blob = new Blob([data], {type: "application/octet-stream"});
			url = URL.createObjectURL(blob);
			VFACT.webFileDownload.download = fileName;
			VFACT.webFileDownload.href = url;
	
			//Generate a mouse click:
			e = document.createEvent('MouseEvents');
			e.initEvent('click', true, false, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null);
			VFACT.webFileDownload.dispatchEvent(e);
	
			//Release the URLData:
			window.setTimeout(() => {
				URL.revokeObjectURL(url);
			}, 10000);
		}
		fileName=vo.image;
		if(fileName.startsWith("data:image/jpeg;")){
			downloadBuf(fileName);
		}else if(fileName.startsWith("data:image/png;")){
			fileName="image.png";
			downloadBuf(vo.image);
		}else if(fileName.startsWith("data:image/gif;")){
			fileName="image.gif";
			downloadBuf(vo.image);
		}else{
			let data=await (await fetch(fileName)).arrayBuffer();
			fileName=pathLib.basename(fileName);
			downloadFile(data);
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.downloadAudio=function(){
		let buf;
		function downloadFile(data,fileName){
			let blob, url;
			let e;
			blob = new Blob([data], {type: "application/octet-stream"});
			url = URL.createObjectURL(blob);
			VFACT.webFileDownload.download = fileName;
			VFACT.webFileDownload.href = url;
	
			//Generate a mouse click:
			e = document.createEvent('MouseEvents');
			e.initEvent('click', true, false, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null);
			VFACT.webFileDownload.dispatchEvent(e);
	
			//Release the URLData:
			window.setTimeout(() => {
				URL.revokeObjectURL(url);
			}, 10000);
		}
		buf=Base64.decode(vo.audio);
		downloadFile(buf,"voice.mp3");
	};
	/*}#1HA0EVOKU1PostCSSVO*/
	return cssVO;
};
/*#{1HA0EVOKU1ExCodes*/
/*}#1HA0EVOKU1ExCodes*/


export default BoxAIChatBlock;
export{BoxAIChatBlock};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1HA0EVOKU0",
//	"editVersion": 106,
//	"attrs": {
//		"editEnv": {
//			"type": "object",
//			"jaxId": "1HA0EVOKV0",
//			"editVersion": 14,
//			"attrs": {
//				"device": "iPhone 375x750",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"type": "object",
//			"jaxId": "1HA0EVOKV1",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"model": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1HA0EVOKV2",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"createArgs": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1HA0EVOKV3",
//			"editVersion": 94,
//			"attrs": {
//				"vo": {
//					"type": "auto",
//					"valText": "#{icon:appCfg.sharedAssets+\"/user.svg\",iconBG:cfgColor.success,bgColor:cfgColor.success,iconColor:cfgColor.fontPrimary,\tblkColor:cfgColor.body,textColor:cfgColor.fontBody,text:\"Hello!\",buttons:false,top:true,image:\"/~/tabos/shared/assets/aalogo.svg\"}"
//				},
//				"session": {
//					"type": "auto",
//					"valText": "null"
//				}
//			}
//		},
//		"localVars": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1HA0EVOKV4",
//			"editVersion": 18,
//			"attrs": {
//				"icon": {
//					"type": "url",
//					"valText": "#vo.icon||(appCfg.sharedAssets+\"/faces.svg\")"
//				},
//				"showText": {
//					"type": "string",
//					"valText": "#vo.text||\"\""
//				}
//			}
//		},
//		"oneHud": "false",
//		"state": {
//			"type": "object",
//			"def": "StateObj",
//			"jaxId": "1HA0EVOKV5",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"segs": {
//			"type": "array",
//			"attrs": []
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"type": "object",
//			"def": "FaceTags",
//			"jaxId": "1HA0EVOKV6",
//			"editVersion": 4,
//			"attrs": {
//				"desktop": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HA0HG3080",
//					"editVersion": 16,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1HA0HL4C00",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"mobile": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HA0HGV240",
//					"editVersion": 16,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1HA0HL4C01",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"type": "object",
//			"def": "MockupObj",
//			"jaxId": "1HA9DQK2O0",
//			"editVersion": 8,
//			"attrs": {
//				"AI result": {
//					"type": "mockState",
//					"def": "MockState",
//					"jaxId": "1HA9DQK2O1",
//					"editVersion": 4,
//					"attrs": {
//						"createArgs": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HA0EVOKV3",
//							"editVersion": 38,
//							"attrs": {
//								"vo": {
//									"type": "auto",
//									"valText": "#{icon:appCfg.sharedAssets+\"/faces.svg\",iconBG:cfgColor.primary,iconColor:cfgColor.fontPrimary,\tbgColor:cfgColor.body,textColor:cfgColor.fontBody,text:\"AI is thinking...\",buttons:true,top:true}"
//								}
//							}
//						},
//						"stateObj": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HA0EVOKV5",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"User prompt": {
//					"type": "mockState",
//					"def": "MockState",
//					"jaxId": "1HA9DSAG20",
//					"editVersion": 4,
//					"attrs": {
//						"createArgs": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HA0EVOKV3",
//							"editVersion": 54,
//							"attrs": {
//								"vo": {
//									"type": "auto",
//									"valText": "#{icon:appCfg.sharedAssets+\"/user.svg\",iconBG:cfgColor.success,iconColor:cfgColor.fontPrimary,\tbgColor:cfgColor.body,textColor:cfgColor.fontBody,text:\"Hello!\",buttons:false,top:true}"
//								}
//							}
//						},
//						"stateObj": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HA0EVOKV5",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"Audio": {
//					"type": "mockState",
//					"def": "MockState",
//					"jaxId": "1HEN3HOB70",
//					"editVersion": 4,
//					"attrs": {
//						"createArgs": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HA0EVOKV3",
//							"editVersion": 88,
//							"attrs": {
//								"vo": {
//									"type": "auto",
//									"valText": "#{icon:appCfg.sharedAssets+\"/user.svg\",iconBG:cfgColor.success,bgColor:cfgColor.success,iconColor:cfgColor.fontPrimary,\tblkColor:cfgColor.body,textColor:cfgColor.fontBody,text:\"Hello!\",buttons:false,top:true,audio:\"xyz\"}"
//								},
//								"session": {
//									"type": "auto",
//									"valText": "null"
//								}
//							}
//						},
//						"stateObj": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HA0EVOKV5",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"image": {
//					"type": "mockState",
//					"def": "MockState",
//					"jaxId": "1HEQ2GG6B0",
//					"editVersion": 4,
//					"attrs": {
//						"createArgs": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HA0EVOKV3",
//							"editVersion": 94,
//							"attrs": {
//								"vo": {
//									"type": "auto",
//									"valText": "#{icon:appCfg.sharedAssets+\"/user.svg\",iconBG:cfgColor.success,bgColor:cfgColor.success,iconColor:cfgColor.fontPrimary,\tblkColor:cfgColor.body,textColor:cfgColor.fontBody,text:\"Hello!\",buttons:false,top:true,image:\"/~/tabos/shared/assets/aalogo.svg\"}"
//								},
//								"session": {
//									"type": "auto",
//									"valText": "null"
//								}
//							}
//						},
//						"stateObj": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HA0EVOKV5",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1HA0EVOKU1",
//			"editVersion": 45,
//			"attrs": {
//				"properties": {
//					"type": "object",
//					"jaxId": "1HA0EVOKV7",
//					"editVersion": 272,
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Relative",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "\"\"",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "[0,0,0,0]",
//						"padding": "[15,30,10,50]",
//						"minW": "",
//						"minH": "30",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Flex X",
//						"traceSize": "true"
//					}
//				},
//				"subHuds": {
//					"type": "array",
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1HA0F1G1C0",
//							"editVersion": 38,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1HA0FE24I0",
//									"editVersion": 162,
//									"attrs": {
//										"type": "box",
//										"id": "BoxBG",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#vo.blkColor||[0,0,0,0]",
//										"border": "#vo.top?0:[1,0,0,0]",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor[\"fontBodyLit\"]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"contentLayout": "Flex X",
//										"itemsWrap": "Wrap"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1HA0FE24I1",
//									"editVersion": 38,
//									"attrs": {
//										"1HA0HG3080": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HA6ROM340",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HA6ROM341",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HA0HG3080",
//											"faceTagName": "desktop"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1HA0FE24I2",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1HA0FE24I3",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1HA0FE4LK0",
//							"editVersion": 33,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1HA0G1M6B0",
//									"editVersion": 234,
//									"attrs": {
//										"type": "box",
//										"id": "BoxIcon",
//										"position": "Absolute",
//										"x": "11",
//										"y": "5",
//										"w": "28",
//										"h": "28",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "2",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#vo.iconBG||vo.bgColor",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "5",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1HA0GFET80",
//											"editVersion": 22,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HA0GHG9I0",
//													"editVersion": 128,
//													"attrs": {
//														"type": "box",
//														"id": "",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "#vo.iconColor",
//														"border": "0",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]",
//														"maskImage": "#icon",
//														"attach": "#!!vo.icon"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1HA0GHG9I1",
//													"editVersion": 38,
//													"attrs": {
//														"1HA0HG3080": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HA6ROM342",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HA6ROM343",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HA0HG3080",
//															"faceTagName": "desktop"
//														}
//													}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1HA0GHG9I2",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1HA0GHG9J0",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "image",
//											"jaxId": "1HB2MJU6E0",
//											"editVersion": 20,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HB2MKMU80",
//													"editVersion": 94,
//													"attrs": {
//														"type": "image",
//														"id": "",
//														"position": "Absolute",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"image": "#vo.pic",
//														"autoSize": "false",
//														"fitSize": "Cover",
//														"repeat": "true",
//														"alignX": "Left",
//														"alignY": "Top",
//														"attach": "#!!vo.pic"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1HB2MKMU81",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1HB2MKMU82",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1HB2MKMU83",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1HA0G1M6B1",
//									"editVersion": 38,
//									"attrs": {
//										"1HA0HG3080": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HA6ROM344",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HA6ROM345",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HA0HG3080",
//											"faceTagName": "desktop"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1HA0G1M6B2",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1HA0G1M6B3",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1HA0G844M0",
//							"editVersion": 50,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1HA0GE7BT0",
//									"editVersion": 94,
//									"attrs": {
//										"type": "hud",
//										"id": "BoxContents",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "20",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex Y"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1HA0H00DG0",
//											"editVersion": 54,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HA0H1R0H0",
//													"editVersion": 136,
//													"attrs": {
//														"type": "text",
//														"id": "TxtContent",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#vo.textColor",
//														"text": "#showText",
//														"font": "",
//														"fontSize": "#txtSize.smallPlus",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "true",
//														"ellipsis": "false",
//														"select": "true",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1HA0H1R0H1",
//													"editVersion": 38,
//													"attrs": {
//														"1HA0HG3080": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HA6ROM346",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HA6ROM350",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HA0HG3080",
//															"faceTagName": "desktop"
//														}
//													}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1HA0H1R0H2",
//													"editVersion": 4,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1HA0H1R0H3",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1HGQTLVFR0",
//											"editVersion": 28,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HGQTOIVG0",
//													"editVersion": 78,
//													"attrs": {
//														"type": "hud",
//														"id": "BoxMD",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "Off",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": ""
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1HGQTOIVG1",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1HGQTOIVG2",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1HGQTOIVG3",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "true",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "image",
//											"jaxId": "1HEK4VTO80",
//											"editVersion": 32,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HEK52D4J0",
//													"editVersion": 118,
//													"attrs": {
//														"type": "image",
//														"id": "Image",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100",
//														"h": "100",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[5,0,0,0]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"image": "#vo.image",
//														"autoSize": "false",
//														"fitSize": "Contain",
//														"repeat": "true",
//														"alignX": "Left",
//														"alignY": "Top",
//														"attach": "#!!vo.image"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1HEQ2E04B0",
//															"editVersion": 32,
//															"attrs": {
//																"createArgs": {
//																	"type": "object",
//																	"def": "gearCrateArgs",
//																	"jaxId": "1HEQ2GG6B1",
//																	"editVersion": 22,
//																	"attrs": {
//																		"style": "\"front\"",
//																		"w": "30",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/save.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HEQ2GG6B2",
//																	"editVersion": 57,
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"front\",30,0,appCfg.sharedAssets+\"/save.svg\",null)",
//																		"id": "BtnSaveImg",
//																		"position": "Absolute",
//																		"x": "100%",
//																		"y": "100%-30",
//																		"display": "On",
//																		"face": "",
//																		"anchorV": "Center"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HEQ2GG6B3",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HEQ2GG6B4",
//																	"editVersion": 2,
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HEQ2GOVT0",
//																			"editVersion": 4,
//																			"attrs": {
//																				"callArgs": {
//																					"type": "object",
//																					"jaxId": "1HEQ2H1N50",
//																					"editVersion": 2,
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HEQ2GG6B5",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"type": "object",
//																	"jaxId": "1HEQ2GG6B6",
//																	"editVersion": 0,
//																	"attrs": {}
//																}
//															}
//														}
//													]
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1HEK52D4J1",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1HEK52D4J2",
//													"editVersion": 2,
//													"attrs": {
//														"OnLoad": {
//															"type": "fixedFunc",
//															"jaxId": "1HEK542I00",
//															"editVersion": 4,
//															"attrs": {
//																"callArgs": {
//																	"type": "object",
//																	"jaxId": "1HEK566K30",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1HEK52D4J3",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "true"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1HEN2ROP70",
//											"editVersion": 25,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HEN35CH80",
//													"editVersion": 120,
//													"attrs": {
//														"type": "hud",
//														"id": "BoxAudio",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "30",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[5,0,0,0]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"subAlign": "Start",
//														"contentLayout": "Flex X",
//														"attach": "#!!vo.audio",
//														"itemsAlign": "Center"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "box",
//															"jaxId": "1HEN2TTCK0",
//															"editVersion": 23,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HEN35CH81",
//																	"editVersion": 166,
//																	"attrs": {
//																		"type": "box",
//																		"id": "BoxPlayAudio",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "80",
//																		"h": "30",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "pointer",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"background": "#cfgColor[\"success\"]",
//																		"border": "1",
//																		"borderStyle": "Solid",
//																		"borderColor": "#cfgColor[\"secondary\"]",
//																		"corner": "[0,8,8,8]",
//																		"shadow": "false",
//																		"shadowX": "2",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowSpread": "0",
//																		"shadowColor": "[0,0,0,0.50]"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "box",
//																			"jaxId": "1HEN2VICR0",
//																			"editVersion": 20,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HEN35CH82",
//																					"editVersion": 166,
//																					"attrs": {
//																						"type": "box",
//																						"id": "",
//																						"position": "Absolute",
//																						"x": "50%",
//																						"y": "50%",
//																						"w": "28",
//																						"h": "28",
//																						"anchorH": "Center",
//																						"anchorV": "Center",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "Tree Off",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"background": "#cfgColor[\"fontSuccess\"]",
//																						"border": "0",
//																						"borderStyle": "Solid",
//																						"borderColor": "[0,0,0,1.00]",
//																						"corner": "0",
//																						"shadow": "false",
//																						"shadowX": "2",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowSpread": "0",
//																						"shadowColor": "[0,0,0,0.50]",
//																						"maskImage": "#appCfg.sharedAssets+\"/sound.svg\""
//																					}
//																				},
//																				"subHuds": {
//																					"type": "array",
//																					"attrs": []
//																				},
//																				"faces": {
//																					"type": "object",
//																					"jaxId": "1HEN35CH83",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"functions": {
//																					"type": "object",
//																					"jaxId": "1HEN35CH84",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"type": "object",
//																					"def": "Object",
//																					"jaxId": "1HEN35CH85",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "false"
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HEN35CH86",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HEN35CH87",
//																	"editVersion": 2,
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HEN3E9430",
//																			"editVersion": 4,
//																			"attrs": {
//																				"callArgs": {
//																					"type": "object",
//																					"jaxId": "1HEN3EMDH0",
//																					"editVersion": 2,
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HEN35CH88",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1HEN3GINJ0",
//															"editVersion": 30,
//															"attrs": {
//																"createArgs": {
//																	"type": "object",
//																	"def": "gearCrateArgs",
//																	"jaxId": "1HEN3HOB71",
//																	"editVersion": 28,
//																	"attrs": {
//																		"style": "\"front\"",
//																		"w": "28",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/save.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HEN3HOB72",
//																	"editVersion": 44,
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"front\",28,0,appCfg.sharedAssets+\"/save.svg\",null)",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"margin": "[0,0,0,5]"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HEN3HOB73",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HEN3HOB74",
//																	"editVersion": 2,
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HENF70OE0",
//																			"editVersion": 4,
//																			"attrs": {
//																				"callArgs": {
//																					"type": "object",
//																					"jaxId": "1HENF7DKD0",
//																					"editVersion": 2,
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HEN3HOB75",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"type": "object",
//																	"jaxId": "1HEN3HOB76",
//																	"editVersion": 0,
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1HEN33S1J0",
//															"editVersion": 30,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HEN35CH89",
//																	"editVersion": 88,
//																	"attrs": {
//																		"type": "hud",
//																		"id": "BoxAudioSlot",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "10",
//																		"h": "10",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "On",
//																		"uiEvent": "On",
//																		"alpha": "0",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": ""
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HEN35CH810",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HEN35CH811",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HEN35CH812",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "true",
//																"exposeContainer": "false"
//															}
//														}
//													]
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1HEN35CH813",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1HEN35CH814",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1HEN35CH815",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1HA0GE7BT1",
//									"editVersion": 38,
//									"attrs": {
//										"1HA0HG3080": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HA6ROM351",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HA6ROM352",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HA0HG3080",
//											"faceTagName": "desktop"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1HA0GE7BT2",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1HA0GE7BT3",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1HA0H30PR0",
//							"editVersion": 26,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1HA0HL4C110",
//									"editVersion": 88,
//									"attrs": {
//										"type": "hud",
//										"id": "",
//										"position": "Absolute",
//										"x": "100%",
//										"y": "0",
//										"w": "30",
//										"h": "30",
//										"anchorH": "Right",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": ""
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1HA0H8MAA0",
//											"editVersion": 67,
//											"attrs": {
//												"createArgs": {
//													"type": "object",
//													"def": "gearCrateArgs",
//													"jaxId": "1HA0HL4C111",
//													"editVersion": 30,
//													"attrs": {
//														"style": "#cfgColor.fontBodySub",
//														"w": "25",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/copy.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"type": "object",
//													"jaxId": "1HA0HL4C112",
//													"editVersion": 83,
//													"attrs": {
//														"type": "#null#>BtnIcon(cfgColor.fontBodySub,25,0,appCfg.sharedAssets+\"/copy.svg\",null)",
//														"id": "BtnCopy",
//														"position": "Absolute",
//														"x": "50%",
//														"y": "50%",
//														"display": "On",
//														"face": "",
//														"anchorH": "Center",
//														"anchorV": "Center",
//														"attach": "#vo.buttons"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1HA0HL4C113",
//													"editVersion": 38,
//													"attrs": {
//														"1HA0HG3080": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HA6ROM353",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HA6ROM354",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HA0HG3080",
//															"faceTagName": "desktop"
//														}
//													}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1HA0HL4C116",
//													"editVersion": 2,
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1HA77UIQA0",
//															"editVersion": 4,
//															"attrs": {
//																"callArgs": {
//																	"type": "object",
//																	"jaxId": "1HA77UR2U0",
//																	"editVersion": 2,
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1HA0HL4C117",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"type": "object",
//													"jaxId": "1HA0HL4C118",
//													"editVersion": 0,
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1HA783RAB0",
//											"editVersion": 48,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HA783RAB1",
//													"editVersion": 166,
//													"attrs": {
//														"type": "box",
//														"id": "BoxCopyMark",
//														"position": "relative",
//														"x": "50%",
//														"y": "50%",
//														"w": "50%",
//														"h": "50%",
//														"anchorH": "Center",
//														"anchorV": "Center",
//														"autoLayout": "false",
//														"display": "Off",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "#cfgColor[\"fontBody\"]",
//														"border": "1",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]",
//														"maskImage": "#appCfg.sharedAssets+\"/check.svg\""
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1HA783RAB2",
//													"editVersion": 4,
//													"attrs": {}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1HA783RAB3",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1HA783RAB4",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										}
//									]
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1HA0HL4C119",
//									"editVersion": 4,
//									"attrs": {
//										"1HA0HG3080": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HA0HL4C120",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HA0HL4C121",
//													"editVersion": 4,
//													"attrs": {
//														"y": {
//															"type": "length",
//															"valText": "0"
//														}
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HA0HG3080",
//											"faceTagName": "desktop"
//										},
//										"1HA0HGV240": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HA0HL4C122",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HA0HL4C123",
//													"editVersion": 8,
//													"attrs": {
//														"y": {
//															"type": "length",
//															"valText": "100%-30"
//														}
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HA0HGV240",
//											"faceTagName": "mobile"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1HA0HL4C124",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1HA0HL4C125",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"type": "object",
//					"jaxId": "1HA0EVOKV8",
//					"editVersion": 4,
//					"attrs": {
//						"1HA0HG3080": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HA0HL4C126",
//							"editVersion": 4,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1HA0HL4C127",
//									"editVersion": 22,
//									"attrs": {
//										"padding": {
//											"type": "auto",
//											"valText": "[10,30,15,50]",
//											"editMode": "edges"
//										}
//									}
//								},
//								"anis": {
//									"type": "array",
//									"def": "Array",
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HA0HG3080",
//							"faceTagName": "desktop"
//						},
//						"1HA0HGV240": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HA0HL4C128",
//							"editVersion": 4,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1HA0HL4C129",
//									"editVersion": 28,
//									"attrs": {
//										"padding": {
//											"type": "auto",
//											"valText": "#vo.buttons?[10,5,30,50]:[10,5,10,50]",
//											"editMode": "edges"
//										}
//									}
//								},
//								"anis": {
//									"type": "array",
//									"def": "Array",
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HA0HGV240",
//							"faceTagName": "mobile"
//						}
//					}
//				},
//				"functions": {
//					"type": "object",
//					"jaxId": "1HA0EVOKV9",
//					"editVersion": 4,
//					"attrs": {
//						"OnSize": {
//							"type": "fixedFunc",
//							"jaxId": "1HA0HQH3P0",
//							"editVersion": 4,
//							"attrs": {
//								"callArgs": {
//									"type": "object",
//									"jaxId": "1HA0HQP8C0",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"seg": ""
//							}
//						},
//						"OnFree": {
//							"type": "fixedFunc",
//							"jaxId": "1HA0IDR1E0",
//							"editVersion": 4,
//							"attrs": {
//								"callArgs": {
//									"type": "object",
//									"jaxId": "1HA0IE1L70",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"seg": ""
//							}
//						}
//					}
//				},
//				"extraPpts": {
//					"type": "object",
//					"def": "Object",
//					"jaxId": "1HA0EVOKV10",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "true",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1HA0EVOKV11",
//			"editVersion": 64,
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}