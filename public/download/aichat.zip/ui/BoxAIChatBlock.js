//Auto genterated by Cody
import {$P,VFACT,callAfter} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
/*#{1HA0EVOKU0StartDoc*/
import {BoxCodeSeg} from "./BoxCodeSeg.js";
/*}#1HA0EVOKU0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BoxAIChatBlock=function(vo,session){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let boxContents,txtContent,btnCopy,boxCopyMark;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let icon=vo.icon||(appCfg.sharedAssets+"/faces.svg");
	
	/*#{1HA0EVOKU1LocalVals*/
	let isDesktop=true;
	let tracedObj=null;
	let tracePrefix="";
	let tracePostfix="";
	let owner=null;
	let hideOnTraceClose=true;
	/*}#1HA0EVOKU1LocalVals*/
	
	/*#{1HA0EVOKU1PreState*/
	/*}#1HA0EVOKU1PreState*/
	/*#{1HA0EVOKU1PostState*/
	/*}#1HA0EVOKU1PostState*/
	cssVO={
		"hash":"1HA0EVOKU1",nameHost:true,
		"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":"","padding":[15,30,10,50],"minW":"","minH":30,"maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
		"traceSize":true,
		children:[
			{
				"hash":"1HA0F1G1C0",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":vo.blkColor||[0,0,0,0],
				"border":vo.top?0:[1,0,0,0],"borderColor":cfgColor["fontBodyLit"],"contentLayout":"flex-x","itemsWrap":1,
			},
			{
				"hash":"1HA0FE4LK0",
				"type":"box","id":"BoxIcon","x":11,"y":5,"w":28,"h":28,"padding":2,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":vo.iconBG||vo.bgColor,
				"corner":5,
				children:[
					{
						"hash":"1HA0GFET80",
						"type":"box","position":"relative","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":vo.iconColor,
						"maskImage":icon,"attached":!!vo.icon,
					},
					{
						"hash":"1HB2MJU6E0",
						"type":"image","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","image":vo.pic,"fitSize":"cover","attached":!!vo.pic,
					}
				],
			},
			{
				"hash":"1HA0G844M0",
				"type":"hud","id":"BoxContents","position":"relative","x":0,"y":0,"w":"100%","h":"","minW":"","minH":20,"maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
				children:[
					{
						"hash":"1HA0H00DG0",
						"type":"text","id":"TxtContent","position":"relative","x":0,"y":0,"w":"100%","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":vo.textColor,
						"text":vo.text,"fontSize":txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","wrap":true,"selectable":true,
					}
				],
			},
			{
				"hash":"1HA0H30PR0",
				"type":"hud","x":"100%","y":0,"w":30,"h":30,"anchorX":2,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				children:[
					{
						"hash":"1HA0H8MAA0",
						"type":BtnIcon(cfgColor.fontBodySub,25,0,appCfg.sharedAssets+"/copy.svg",null),"id":"BtnCopy","x":"50%","y":"50%","anchorX":1,"anchorY":1,"attached":vo.buttons,
						"OnClick":function(event){
							/*#{1HA77UIQA0FunctionBody*/
							self.doCopy();
							/*}#1HA77UIQA0FunctionBody*/
						},
					},
					{
						"hash":"1HA783RAB0",
						"type":"box","id":"BoxCopyMark","position":"relative","x":"50%","y":"50%","w":"50%","h":"50%","anchorX":1,"anchorY":1,"display":0,"minW":"","minH":"",
						"maxW":"","maxH":"","styleClass":"","background":cfgColor["fontBody"],"border":1,"maskImage":appCfg.sharedAssets+"/check.svg",
					}
				],
			}
		],
		/*#{1HA0EVOKU1ExtraCSS*/
		/*}#1HA0EVOKU1ExtraCSS*/
		faces:{
			"desktop":{
				"#self":{
					"padding":[10,30,15,50]
				},
				"#1HA0H30PR0":{
					"y":0
				}
			},"mobile":{
				"#self":{
					"padding":vo.buttons?[10,5,30,50]:[10,5,10,50]
				},
				"#1HA0H30PR0":{
					"y":">calc(100% - 30px)"
				}
			}
		},
		OnCreate:function(){
			self=this;
			boxContents=self.BoxContents;txtContent=self.TxtContent;btnCopy=self.BtnCopy;boxCopyMark=self.BoxCopyMark;
			/*#{1HA0EVOKU1Create*/
			self.content=vo.text||vo.content;
			if(vo.render){
				self.renderContents();
			}
			/*}#1HA0EVOKU1Create*/
		},
		/*#{1HA0EVOKU1EndCSS*/
		/*}#1HA0EVOKU1EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.OnSize=function(){
		/*#{1HA0HQH3P0FunctionBody*/
		self.content=vo.text||vo.content;
		if(!isDesktop && self.w>=500){
			self.showFace("desktop");
			isDesktop=true;
		}else if(isDesktop && self.w<500){
			self.showFace("mobile");
			isDesktop=false;
		}
		/*}#1HA0HQH3P0FunctionBody*/
	};
	
	//------------------------------------------------------------------------
	cssVO.OnFree=function(){
		/*#{1HA0IDR1E0FunctionBody*/
		if(tracedObj){
			tracedObj.off("content",self.OnUpdate);
			tracedObj.off("close",self.OnClose);
			tracedObj=null;
		}
		/*}#1HA0IDR1E0FunctionBody*/
	};
	/*#{1HA0EVOKU1PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.renderContents=function(){
		let content,preCode,code,postCode;
		let parsePos,pos,fullLength;
		let textBlk=txtContent;
		parsePos=0;
		content=self.content;
		fullLength=content.length;
		do{
			pos=content.indexOf("```",parsePos);
			if(pos>=0){
				//Precode:
				preCode=content.substring(parsePos,pos);
				if(textBlk){
					textBlk.text=preCode;
					textBlk=null;
				}else{
					if(preCode.length){
						boxContents.appendNewChild({
							"type":"text","position":"relative","x":0,"y":0,"w":"100%","h":"","color":vo.textColor||cfgColor.fontBody,
							"text":preCode,"fontSize":txtSize.smallPlus,"wrap":true,"selectable":true,
						});
					}
				}
				//find Code:
				parsePos=pos+3;
				pos=content.indexOf("```",parsePos);
				if(pos<0){
					pos=fullLength;
				}
				code=content.substring(parsePos,pos);
				if(code.length){
					boxContents.appendNewChild(
						BoxCodeSeg(code,"")
					);
				}
				parsePos=pos+3;
			}else{
				postCode=content.substring(parsePos);
				if(textBlk){
					textBlk.text=postCode;
					textBlk=null;
				}else{
					if(postCode.length){
						boxContents.appendNewChild({
							"type":"text","position":"relative","x":0,"y":0,"w":"100%","h":"","color":vo.textColor||cfgColor.fontBody,
							"text":postCode,"fontSize":txtSize.smallPlus,"wrap":true,"selectable":true,
						});
					}
				}
				parsePos=fullLength;
			}
		}while(parsePos>=0 && parsePos<fullLength);
	};
	
	//------------------------------------------------------------------------
	cssVO.trace=function(obj,prefix="",postfix="",autoHide=true){
		owner=self.parent;
		tracedObj=obj;
		hideOnTraceClose=autoHide;
		tracePrefix=prefix;
		tracePostfix=postfix;
		obj.on("content",self.OnUpdate);
		obj.on("close",self.OnClose);
	};
	
	function replaceTextContent(text) {
		// 替换所有数字为 "#"
		let result = text.replace(/\d/g, "#");
		// 替换所有拉丁字母为 "*"
		result = result.replace(/[a-zA-Z]/g, "*");
		// 替换所有非ASCII字符（例如中文）为 "■"
		result = result.replace(/[^\x00-\x7F]+/g, "■");
	
		return result;
	}
	
	//------------------------------------------------------------------------
	cssVO.OnUpdate=function(){
		if(tracedObj){
			if(session.hideInternal){
				let tgtText,srcText;
				self.content=txtContent.text=tracePrefix+replaceTextContent(tracedObj.content)+tracePostfix;
			}else{
				self.content=txtContent.text=tracePrefix+tracedObj.content+tracePostfix;
			}
			owner.scrollDown();
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.OnClose=function(){
		if(tracedObj){
			tracedObj.off("content",self.OnUpdate);
			tracedObj.off("close",self.OnClose);
			tracedObj=null;
			if(hideOnTraceClose){
				self.display=0;
			}
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.doCopy=function(){
		navigator.clipboard.writeText(self.content);
		boxCopyMark.display=1;
		boxCopyMark.animate({type:"out",time:500,alpha:0,delay:500});
	};
	/*}#1HA0EVOKU1PostCSSVO*/
	return cssVO;
};
/*#{1HA0EVOKU1ExCodes*/
/*}#1HA0EVOKU1ExCodes*/


export default BoxAIChatBlock;
export{BoxAIChatBlock};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1HA0EVOKU0",
//	"editVersion": 96,
//	"attrs": {
//		"editEnv": {
//			"type": "object",
//			"jaxId": "1HA0EVOKV0",
//			"editVersion": 14,
//			"attrs": {
//				"device": "iPhone 375x750",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"type": "object",
//			"jaxId": "1HA0EVOKV1",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"model": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1HA0EVOKV2",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"createArgs": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1HA0EVOKV3",
//			"editVersion": 82,
//			"attrs": {
//				"vo": {
//					"type": "auto",
//					"valText": "#{icon:appCfg.sharedAssets+\"/user.svg\",iconBG:cfgColor.success,bgColor:cfgColor.success,iconColor:cfgColor.fontPrimary,\tblkColor:cfgColor.body,textColor:cfgColor.fontBody,text:\"Hello!\",buttons:false,top:true}"
//				},
//				"session": {
//					"type": "auto",
//					"valText": "null"
//				}
//			}
//		},
//		"localVars": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1HA0EVOKV4",
//			"editVersion": 10,
//			"attrs": {
//				"icon": {
//					"type": "url",
//					"valText": "#vo.icon||(appCfg.sharedAssets+\"/faces.svg\")"
//				}
//			}
//		},
//		"oneHud": "false",
//		"state": {
//			"type": "object",
//			"def": "StateObj",
//			"jaxId": "1HA0EVOKV5",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"type": "object",
//			"def": "FaceTags",
//			"jaxId": "1HA0EVOKV6",
//			"editVersion": 4,
//			"attrs": {
//				"desktop": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HA0HG3080",
//					"editVersion": 16,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1HA0HL4C00",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"mobile": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HA0HGV240",
//					"editVersion": 16,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1HA0HL4C01",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"type": "object",
//			"def": "MockupObj",
//			"jaxId": "1HA9DQK2O0",
//			"editVersion": 4,
//			"attrs": {
//				"AI result": {
//					"type": "mockState",
//					"def": "MockState",
//					"jaxId": "1HA9DQK2O1",
//					"editVersion": 4,
//					"attrs": {
//						"createArgs": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HA0EVOKV3",
//							"editVersion": 38,
//							"attrs": {
//								"vo": {
//									"type": "auto",
//									"valText": "#{icon:appCfg.sharedAssets+\"/faces.svg\",iconBG:cfgColor.primary,iconColor:cfgColor.fontPrimary,\tbgColor:cfgColor.body,textColor:cfgColor.fontBody,text:\"AI is thinking...\",buttons:true,top:true}"
//								}
//							}
//						},
//						"stateObj": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HA0EVOKV5",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"User prompt": {
//					"type": "mockState",
//					"def": "MockState",
//					"jaxId": "1HA9DSAG20",
//					"editVersion": 4,
//					"attrs": {
//						"createArgs": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HA0EVOKV3",
//							"editVersion": 54,
//							"attrs": {
//								"vo": {
//									"type": "auto",
//									"valText": "#{icon:appCfg.sharedAssets+\"/user.svg\",iconBG:cfgColor.success,iconColor:cfgColor.fontPrimary,\tbgColor:cfgColor.body,textColor:cfgColor.fontBody,text:\"Hello!\",buttons:false,top:true}"
//								}
//							}
//						},
//						"stateObj": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HA0EVOKV5",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1HA0EVOKU1",
//			"editVersion": 45,
//			"attrs": {
//				"properties": {
//					"type": "object",
//					"jaxId": "1HA0EVOKV7",
//					"editVersion": 272,
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Relative",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "\"\"",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "[0,0,0,0]",
//						"padding": "[15,30,10,50]",
//						"minW": "",
//						"minH": "30",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Flex X",
//						"traceSize": "true"
//					}
//				},
//				"subHuds": {
//					"type": "array",
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1HA0F1G1C0",
//							"editVersion": 35,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1HA0FE24I0",
//									"editVersion": 162,
//									"attrs": {
//										"type": "box",
//										"id": "BoxBG",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#vo.blkColor||[0,0,0,0]",
//										"border": "#vo.top?0:[1,0,0,0]",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor[\"fontBodyLit\"]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"contentLayout": "Flex X",
//										"itemsWrap": "Wrap"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1HA0FE24I1",
//									"editVersion": 38,
//									"attrs": {
//										"1HA0HG3080": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HA6ROM340",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HA6ROM341",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HA0HG3080",
//											"faceTagName": "desktop"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1HA0FE24I2",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1HA0FE24I3",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1HA0FE4LK0",
//							"editVersion": 30,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1HA0G1M6B0",
//									"editVersion": 234,
//									"attrs": {
//										"type": "box",
//										"id": "BoxIcon",
//										"position": "Absolute",
//										"x": "11",
//										"y": "5",
//										"w": "28",
//										"h": "28",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "2",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#vo.iconBG||vo.bgColor",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "5",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1HA0GFET80",
//											"editVersion": 22,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HA0GHG9I0",
//													"editVersion": 128,
//													"attrs": {
//														"type": "box",
//														"id": "",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "#vo.iconColor",
//														"border": "0",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]",
//														"maskImage": "#icon",
//														"attach": "#!!vo.icon"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1HA0GHG9I1",
//													"editVersion": 38,
//													"attrs": {
//														"1HA0HG3080": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HA6ROM342",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HA6ROM343",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HA0HG3080",
//															"faceTagName": "desktop"
//														}
//													}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1HA0GHG9I2",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1HA0GHG9J0",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "image",
//											"jaxId": "1HB2MJU6E0",
//											"editVersion": 20,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HB2MKMU80",
//													"editVersion": 94,
//													"attrs": {
//														"type": "image",
//														"id": "",
//														"position": "Absolute",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"image": "#vo.pic",
//														"autoSize": "false",
//														"fitSize": "Cover",
//														"repeat": "true",
//														"alignX": "Left",
//														"alignY": "Top",
//														"attach": "#!!vo.pic"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1HB2MKMU81",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1HB2MKMU82",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1HB2MKMU83",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1HA0G1M6B1",
//									"editVersion": 38,
//									"attrs": {
//										"1HA0HG3080": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HA6ROM344",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HA6ROM345",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HA0HG3080",
//											"faceTagName": "desktop"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1HA0G1M6B2",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1HA0G1M6B3",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1HA0G844M0",
//							"editVersion": 44,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1HA0GE7BT0",
//									"editVersion": 94,
//									"attrs": {
//										"type": "hud",
//										"id": "BoxContents",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "20",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex Y"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1HA0H00DG0",
//											"editVersion": 48,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HA0H1R0H0",
//													"editVersion": 130,
//													"attrs": {
//														"type": "text",
//														"id": "TxtContent",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#vo.textColor",
//														"text": "#vo.text",
//														"font": "",
//														"fontSize": "#txtSize.smallPlus",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "true",
//														"ellipsis": "false",
//														"select": "true",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1HA0H1R0H1",
//													"editVersion": 38,
//													"attrs": {
//														"1HA0HG3080": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HA6ROM346",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HA6ROM350",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HA0HG3080",
//															"faceTagName": "desktop"
//														}
//													}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1HA0H1R0H2",
//													"editVersion": 4,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1HA0H1R0H3",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										}
//									]
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1HA0GE7BT1",
//									"editVersion": 38,
//									"attrs": {
//										"1HA0HG3080": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HA6ROM351",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HA6ROM352",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HA0HG3080",
//											"faceTagName": "desktop"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1HA0GE7BT2",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1HA0GE7BT3",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1HA0H30PR0",
//							"editVersion": 26,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1HA0HL4C110",
//									"editVersion": 88,
//									"attrs": {
//										"type": "hud",
//										"id": "",
//										"position": "Absolute",
//										"x": "100%",
//										"y": "0",
//										"w": "30",
//										"h": "30",
//										"anchorH": "Right",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": ""
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1HA0H8MAA0",
//											"editVersion": 58,
//											"attrs": {
//												"createArgs": {
//													"type": "object",
//													"def": "gearCrateArgs",
//													"jaxId": "1HA0HL4C111",
//													"editVersion": 30,
//													"attrs": {
//														"style": "#cfgColor.fontBodySub",
//														"w": "25",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/copy.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"type": "object",
//													"jaxId": "1HA0HL4C112",
//													"editVersion": 80,
//													"attrs": {
//														"type": "#null#>BtnIcon(cfgColor.fontBodySub,25,0,appCfg.sharedAssets+\"/copy.svg\",null)",
//														"id": "BtnCopy",
//														"position": "Absolute",
//														"x": "50%",
//														"y": "50%",
//														"display": "On",
//														"face": "",
//														"anchorH": "Center",
//														"anchorV": "Center",
//														"attach": "#vo.buttons"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1HA0HL4C113",
//													"editVersion": 38,
//													"attrs": {
//														"1HA0HG3080": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HA6ROM353",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HA6ROM354",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HA0HG3080",
//															"faceTagName": "desktop"
//														}
//													}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1HA0HL4C116",
//													"editVersion": 2,
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1HA77UIQA0",
//															"editVersion": 2,
//															"attrs": {
//																"callArgs": {
//																	"type": "object",
//																	"jaxId": "1HA77UR2U0",
//																	"editVersion": 2,
//																	"attrs": {
//																		"event": ""
//																	}
//																}
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1HA0HL4C117",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"type": "object",
//													"jaxId": "1HA0HL4C118",
//													"editVersion": 0,
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1HA783RAB0",
//											"editVersion": 42,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HA783RAB1",
//													"editVersion": 162,
//													"attrs": {
//														"type": "box",
//														"id": "BoxCopyMark",
//														"position": "relative",
//														"x": "50%",
//														"y": "50%",
//														"w": "50%",
//														"h": "50%",
//														"anchorH": "Center",
//														"anchorV": "Center",
//														"autoLayout": "false",
//														"display": "Off",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "#cfgColor[\"fontBody\"]",
//														"border": "1",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]",
//														"maskImage": "#appCfg.sharedAssets+\"/check.svg\""
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1HA783RAB2",
//													"editVersion": 4,
//													"attrs": {}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1HA783RAB3",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1HA783RAB4",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										}
//									]
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1HA0HL4C119",
//									"editVersion": 4,
//									"attrs": {
//										"1HA0HG3080": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HA0HL4C120",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HA0HL4C121",
//													"editVersion": 4,
//													"attrs": {
//														"y": {
//															"type": "length",
//															"valText": "0"
//														}
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HA0HG3080",
//											"faceTagName": "desktop"
//										},
//										"1HA0HGV240": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HA0HL4C122",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HA0HL4C123",
//													"editVersion": 8,
//													"attrs": {
//														"y": {
//															"type": "length",
//															"valText": "100%-30"
//														}
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HA0HGV240",
//											"faceTagName": "mobile"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1HA0HL4C124",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1HA0HL4C125",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"type": "object",
//					"jaxId": "1HA0EVOKV8",
//					"editVersion": 4,
//					"attrs": {
//						"1HA0HG3080": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HA0HL4C126",
//							"editVersion": 4,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1HA0HL4C127",
//									"editVersion": 22,
//									"attrs": {
//										"padding": {
//											"type": "auto",
//											"valText": "[10,30,15,50]",
//											"editMode": "edges"
//										}
//									}
//								},
//								"anis": {
//									"type": "array",
//									"def": "Array",
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HA0HG3080",
//							"faceTagName": "desktop"
//						},
//						"1HA0HGV240": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HA0HL4C128",
//							"editVersion": 4,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1HA0HL4C129",
//									"editVersion": 28,
//									"attrs": {
//										"padding": {
//											"type": "auto",
//											"valText": "#vo.buttons?[10,5,30,50]:[10,5,10,50]",
//											"editMode": "edges"
//										}
//									}
//								},
//								"anis": {
//									"type": "array",
//									"def": "Array",
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HA0HGV240",
//							"faceTagName": "mobile"
//						}
//					}
//				},
//				"functions": {
//					"type": "object",
//					"jaxId": "1HA0EVOKV9",
//					"editVersion": 4,
//					"attrs": {
//						"OnSize": {
//							"type": "fixedFunc",
//							"jaxId": "1HA0HQH3P0",
//							"editVersion": 2,
//							"attrs": {
//								"callArgs": {
//									"type": "object",
//									"jaxId": "1HA0HQP8C0",
//									"editVersion": 0,
//									"attrs": {}
//								}
//							}
//						},
//						"OnFree": {
//							"type": "fixedFunc",
//							"jaxId": "1HA0IDR1E0",
//							"editVersion": 2,
//							"attrs": {
//								"callArgs": {
//									"type": "object",
//									"jaxId": "1HA0IE1L70",
//									"editVersion": 0,
//									"attrs": {}
//								}
//							}
//						}
//					}
//				},
//				"extraPpts": {
//					"type": "object",
//					"def": "Object",
//					"jaxId": "1HA0EVOKV10",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "true",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1HA0EVOKV11",
//			"editVersion": 64,
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}