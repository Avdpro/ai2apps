//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
/*#{1HA0EVOKU0StartDoc*/
import pathLib from "/@path";
import Base64 from "/@tabos/utils/base64.js";
import {BoxCodeSeg} from "./BoxCodeSeg.js";
import markdownit from "/@markdownit";
/*}#1HA0EVOKU0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BoxAIChatBlock=function(vo,session){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let boxContents,txtContent,boxMD,image,boxAudioSlot,btnCopy,boxCopyMark;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let icon=vo.icon||(appCfg.sharedAssets+"/faces.svg");
	let showText=vo.text||"";
	
	/*#{1HA0EVOKU1LocalVals*/
	let isDesktop=true;
	let tracedObj=null;
	let tracePrefix="";
	let tracePostfix="";
	let owner=null;
	let hideOnTraceClose=true;
	let webAudio;
	const roleDefs={
		"user":{
			side:"right",
			icon:appCfg.sharedAssets+"/user.svg",
			textColor:cfgColor.fontBody,
			bgColor:cfgColor.tool,
			bgBorderSize:0,
			bgBorderColor:cfgColor.fontBodySub,
			iconColor:cfgColor.fontBody,
			iconBG:cfgColor.body,
			iconBorderColor:cfgColor.fontBodyLit,
			iconBorderSize:1,
			iconCorner:100,
			render:false
		},
		"assistant":{
			side:"left",
			icon:appCfg.sharedAssets+"/agent.svg",
			textColor:cfgColor.fontBody,
			bgColor:0,
			bgBorderSize:0,
			bgBorderColor:cfgColor.fontBodySub,
			iconColor:cfgColor.fontBody,
			iconBG:cfgColor.body,
			iconBorderColor:cfgColor.fontBodyLit,
			iconBorderSize:1,
			iconCorner:100,
		},
		"wait":{
			side:"left",
			icon:appCfg.sharedAssets+"/wait.svg",
			textColor:cfgColor.fontBody,
			bgColor:cfgColor.tool,
			bgBorderSize:0,
			bgBorderColor:cfgColor.fontBodySub,
			iconColor:cfgColor.fontBody,
			iconBG:cfgColor.body,
			iconBorderColor:cfgColor.fontBodyLit,
			iconBorderSize:1,
			iconCorner:100,
			render:false,
		},
		"system":{
			side:"left",
			icon:appCfg.sharedAssets+"/event.svg",
			textColor:cfgColor.fontBodySub,
			bgColor:cfgColor.tool,
			bgBorderSize:0,
			bgBorderColor:cfgColor.fontBodySub,
			iconColor:cfgColor.fontBody,
			iconBG:cfgColor.body,
			iconBorderColor:cfgColor.fontBodyLit,
			iconBorderSize:1,
			iconCorner:100,
		},
		"warning":{
			side:"left",
			icon:appCfg.sharedAssets+"/event.svg",
			textColor:cfgColor.fontWarning,
			bgColor:cfgColor.warning,
			bgBorderSize:0,
			bgBorderColor:cfgColor.fontBodySub,
			iconColor:cfgColor.fontWarning,
			iconBG:cfgColor.warning,
			iconBorderColor:cfgColor.fontBodyLit,
			iconBorderSize:0,
			iconCorner:100,
			render:false,
		},
		"error":{
			side:"left",
			icon:appCfg.sharedAssets+"/event.svg",
			textColor:cfgColor.error,
			bgColor:0,
			bgBorderSize:0,
			bgBorderColor:cfgColor.fontBodySub,
			iconColor:cfgColor.fontError,
			iconBG:cfgColor.error,
			iconBorderColor:cfgColor.fontBodyLit,
			iconBorderSize:0,
			iconCorner:100,
			render:false,
		},
		"log":{
			side:"left",
			iconSize:24,
			icon:appCfg.sharedAssets+"/event.svg",
			fontSize:12,
			textColor:cfgColor.fontBodySub,
			bgColor:0,
			bgBorderSize:0,
			bgBorderColor:cfgColor.fontBodySub,
			iconColor:cfgColor.fontBody,
			iconBG:cfgColor.body,
			iconBorderColor:cfgColor.fontBodyLit,
			iconBorderSize:0,
			iconCorner:100,
			render:false,
		}
	};
	roleDefs.greeting=roleDefs.ai=roleDefs.agent=roleDefs.assistant;
	if(showText.length>1024*20){
		showText=showText.substring(0,1024*20);
	}
	vo.role=vo.role||vo.type||"assistant";
	if(vo.role){
		let def;
		def=roleDefs[vo.role]||roleDefs.assistant;
		if(session.getRoleDef){
			let sdef;
			sdef=session.getRoleDef(vo.role);
			if(sdef){
				def={...def,...sdef};
			}
		}
		vo={...def,...vo};
	}else{
		vo={...vo};
	}
	vo.side=vo.side||"left";
	vo.side=vo.side.toLowerCase()==="right"?"right":"left";
	icon=vo.icon||(appCfg.sharedAssets+"/faces.svg");
	/*}#1HA0EVOKU1LocalVals*/
	
	/*#{1HA0EVOKU1PreState*/
	/*}#1HA0EVOKU1PreState*/
	/*#{1HA0EVOKU1PostState*/
	/*}#1HA0EVOKU1PostState*/
	cssVO={
		"hash":"1HA0EVOKU1",nameHost:true,
		"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":"","padding":vo.side==="right"?[5,5,10,30]:[5,30,10,5],"minW":"","minH":30,"maxW":"","maxH":"",
		"styleClass":"","contentLayout":vo.side==="right"?"flex-xr":"flex-x","traceSize":true,
		children:[
			{
				"hash":"1HA0FE4LK0",
				"type":"box","id":"BoxIcon","position":"relative","x":0,"y":vo.iconSize?vo.iconSize*0.5:16,"w":vo.iconSize||32,"h":vo.iconSize||32,"anchorY":1,"display":vo.icon!==false,
				"overflow":1,"padding":3,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":vo.iconBG||vo.bgColor,"border":vo.iconBorderSize||0,
				"borderColor":vo.iconBorderColor||[0,0,0,1.00],"corner":vo.iconCorner||5,
				children:[
					{
						"hash":"1HA0GFET80",
						"type":"box","position":"relative","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":vo.iconColor,
						"maskImage":icon,"attached":!!vo.icon,
					},
					{
						"hash":"1HB2MJU6E0",
						"type":"image","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","image":vo.pic,"fitSize":"cover","attached":!!vo.pic,
					}
				],
			},
			{
				"hash":"1HA0G844M0",
				"type":"hud","id":"BoxContents","position":"relative","x":0,"y":5,"w":100,"h":"","padding":vo.role==="log"?[0,5,0,1]:[0,5,0,2],"minW":"","minH":20,
				"maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y","flex":true,"subAlign":"","itemsAlign":vo.side==="right"?2:0,
				children:[
					{
						"hash":"1IBKCSL060",
						"type":"text","id":"TxtHeader","position":"relative","x":0,"y":0,"w":100,"h":"","display":vo.txtHeader,"minW":"","minH":5,"maxW":"","maxH":"","styleClass":"",
						"color":cfgColor["fontBodySub"],"text":vo.txtHeader||" ","fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
					},
					{
						"hash":"1IBKD3C560",
						"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":"","padding":vo.bgColor?[3,0,3,0]:[0,0,3,0],"minW":"","minH":"","maxW":"","maxH":"",
						"styleClass":"","contentLayout":"flex-x","subAlign":vo.side==="right"?2:0,
						children:[
							{
								"hash":"1IBKD43MO0",
								"type":"box","id":"BoxText","position":"relative","x":0,"y":0,"w":"","h":"","padding":vo.role==="log"?[0,3,3,3]:(vo.bgColor?10:[0,10,10,5]),"minW":50,
								"minH":12,"maxW":"100%","maxH":"","styleClass":"","background":vo.bgColor||[0,0,0,0],"border":vo.bgBorderSize||0,"borderColor":vo.bgBorderColor,
								"corner":vo.side==="left"?[0,16,16,16]:[16,0,16,16],"contentLayout":"flex-y","itemsAlign":(!vo.image && !vo.audio)?1:(vo.side==="right"?2:0),
								children:[
									{
										"hash":"1IBKD7HO70",
										"type":"text","id":"TxtContent","position":"relative","x":0,"y":0,"w":"","h":"","cursor":"text","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
										"color":vo.textColor,"text":showText,"fontSize":vo.fontSize||txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
										"wrap":true,"selectable":true,
									},
									{
										"hash":"1IBKD9AO70",
										"type":"hud","id":"BoxMD","position":"relative","x":0,"y":0,"w":"100%","h":"","display":0,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
									},
									{
										"hash":"1IBKDJG8R0",
										"type":"image","id":"Image","position":"relative","x":0,"y":0,"w":100,"h":100,"margin":[5,30,0,30],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
										"image":vo.image,"fitSize":"contain","attached":!!vo.image,
										children:[
											{
												"hash":"1IBKDJG8S0",
												"type":BtnIcon("front",30,0,appCfg.sharedAssets+"/save.svg",null),"id":"BtnSaveImg","x":vo.side==="right"?-30:"100%","y":">calc(100% - 30px)",
												"display":vo.button!==false,"anchorY":1,
												"OnClick":function(event){
													/*#{1IBKDJG8S5FunctionBody*/
													self.saveImage();
													/*}#1IBKDJG8S5FunctionBody*/
												},
											}
										],
										"OnLoad":function(){
											/*#{1IBKDJG8S11FunctionBody*/
											let iw,ih,w,h,pw,maxW,maxH;
											iw=this.imageW;
											ih=this.imageH;
											pw=self.parent.w;
											maxW=pw*0.9-80;
											maxH=pw*1.5;
											w=iw;h=ih;
											if(w>maxW){
												h=h*maxW/w;
												w=maxW;
											}
											if(h>maxH){
												w=w*maxH/h;
												h=maxH;
											}
											this.w=w;
											this.h=h;
											/*}#1IBKDJG8S11FunctionBody*/
										},
									},
									{
										"hash":"1IBKDJB3M0",
										"type":"hud","id":"BoxAudio","position":"relative","x":0,"y":0,"w":"100%","h":30,"margin":[5,0,0,0],"minW":"","minH":"","maxW":"","maxH":"",
										"styleClass":"","contentLayout":"flex-x","attached":!!vo.audio,"itemsAlign":1,
										children:[
											{
												"hash":"1IBKDJB3N0",
												"type":"box","id":"BoxPlayAudio","position":"relative","x":0,"y":0,"w":80,"h":30,"cursor":"pointer","minW":"","minH":"","maxW":"","maxH":"",
												"styleClass":"","background":cfgColor["success"],"border":1,"borderColor":cfgColor["secondary"],"corner":[0,8,8,8],
												children:[
													{
														"hash":"1IBKDJB3O0",
														"type":"box","x":"50%","y":"50%","w":28,"h":28,"anchorX":1,"anchorY":1,"uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
														"background":cfgColor["fontSuccess"],"maskImage":appCfg.sharedAssets+"/sound.svg",
													}
												],
												"OnClick":function(event){
													/*#{1IBKDJB3O7FunctionBody*/
													webAudio && webAudio.play();
													/*}#1IBKDJB3O7FunctionBody*/
												},
											},
											{
												"hash":"1IBKDJB3O10",
												"type":BtnIcon("front",28,0,appCfg.sharedAssets+"/save.svg",null),"position":"relative","x":0,"y":0,"margin":[0,0,0,5],
												"OnClick":function(event){
													/*#{1IBKDJB3P2FunctionBody*/
													self.downloadAudio();
													/*}#1IBKDJB3P2FunctionBody*/
												},
											},
											{
												"hash":"1IBKDJB3P6",
												"type":"hud","id":"BoxAudioSlot","position":"relative","x":0,"y":0,"w":10,"h":10,"overflow":1,"alpha":0,"minW":"","minH":"","maxW":"","maxH":"",
												"styleClass":"",
											}
										],
									},
									{
										"hash":"1IBKFL32O0",
										"type":"hud","x":vo.side==="right"?0:"100%","y":0,"w":30,"h":30,"anchorX":vo.side==="right"?2:0,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
										"attached":vo.buttons,
										children:[
											{
												"hash":"1IBKFL32P0",
												"type":BtnIcon(cfgColor.fontBodySub,25,0,appCfg.sharedAssets+"/copy.svg",null),"id":"BtnCopy","x":"50%","y":"50%","anchorX":1,"anchorY":1,
												"attached":vo.buttons,
												"OnClick":function(event){
													/*#{1IBKFL32P7FunctionBody*/
													self.doCopy();
													/*}#1IBKFL32P7FunctionBody*/
												},
											},
											{
												"hash":"1IBKFL32Q0",
												"type":"box","id":"BoxCopyMark","position":"relative","x":"50%","y":"50%","w":"50%","h":"50%","anchorX":1,"anchorY":1,"display":0,"minW":"",
												"minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["fontBody"],"border":1,"maskImage":appCfg.sharedAssets+"/check.svg",
											}
										],
									}
								],
							}
						],
					},
					{
						"hash":"1IBKFA0G40",
						"type":"text","id":"TxtFooter","position":"relative","x":0,"y":0,"w":100,"h":"","minW":"","minH":5,"maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodySub"],
						"text":vo.txtFooter||"","fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","attached":!!vo.txtFooter,
					}
				],
			}
		],
		/*#{1HA0EVOKU1ExtraCSS*/
		/*}#1HA0EVOKU1ExtraCSS*/
		faces:{
			"desktop":{
				"#1IBKFL32O0":{
					"y":0
				}
			},"mobile":{
				"#1IBKFL32O0":{
					"y":">calc(100% - 30px)"
				}
			}
		},
		OnCreate:function(){
			self=this;
			boxContents=self.BoxContents;txtContent=self.TxtContent;boxMD=self.BoxMD;image=self.Image;boxAudioSlot=self.BoxAudioSlot;btnCopy=self.BtnCopy;boxCopyMark=self.BoxCopyMark;
			/*#{1HA0EVOKU1Create*/
			self.content=vo.text||vo.content;
			if(vo.render!==false){
				self.renderContents();
			}
			if(vo.audio){
				if(vo.audio.startsWith("data:")){
					boxAudioSlot.webObj.innerHTML=`<audio id="audioPlayer" controls> <source src="${vo.audio}" type="audio/mp3"></audio>`;
				}else{
					boxAudioSlot.webObj.innerHTML=`<audio id="audioPlayer" controls> <source src="data:audio/mp3;base64,${vo.audio}" type="audio/mp3"></audio>`;
				}
				webAudio=boxAudioSlot.webObj.firstChild;
				if(vo.autoPlay!==false){
					callAfter(()=>{webAudio.play()});
				}
			}
			/*}#1HA0EVOKU1Create*/
		},
		/*#{1HA0EVOKU1EndCSS*/
		/*}#1HA0EVOKU1EndCSS*/
	};
	//------------------------------------------------------------------------
	cssVO.OnSize=function(){
		/*#{1HA0HQH3P0FunctionBody*/
		self.content=vo.text||vo.content;
		if(!isDesktop && self.w>=500){
			self.showFace("desktop");
			isDesktop=true;
		}else if(isDesktop && self.w<500){
			self.showFace("mobile");
			isDesktop=false;
		}
		/*}#1HA0HQH3P0FunctionBody*/
	};
	
	//------------------------------------------------------------------------
	cssVO.OnFree=function(){
		/*#{1HA0IDR1E0FunctionBody*/
		if(tracedObj){
			tracedObj.off("content",self.OnUpdate);
			tracedObj.off("close",self.OnClose);
			tracedObj=null;
		}
		/*}#1HA0IDR1E0FunctionBody*/
	};
	/*#{1HA0EVOKU1PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.renderContents=function(){
		let content,htmlCode,webObj,list,i,n,blks,blk,upperElement,tagType,blkBox,code,mode,pos,href;
		boxMD.display=true;
		txtContent.display=false;
		content=""+self.content;
		htmlCode=markdownit().render(content);
		webObj=boxMD.webObj;
		webObj.style.fontSize="14px";
		webObj.innerHTML=htmlCode;
		//First, fix tab-border
		list=webObj.querySelectorAll("table");
		n=list.length;
		for(i=0;i<n;i++){
			blk=list[i];
			blk.style.border="1px solid black";
			blk.style.borderSpacing="0px";
		}
		//First, fix tab-border
		list=webObj.querySelectorAll("table");
		n=list.length;
		for(i=0;i<n;i++){
			blk=list[i];
			blk.style.border="1px solid black";
		}
		list=webObj.querySelectorAll("th");
		n=list.length;
		for(i=0;i<n;i++){
			blk=list[i];
			blk.style.border="1px solid black";
		}
		list=webObj.querySelectorAll("td");
		n=list.length;
		for(i=0;i<n;i++){
			blk=list[i];
			blk.style.border="1px solid gray";
		}
		list=webObj.querySelectorAll("img");
		n=list.length;
		for(i=0;i<n;i++){
			blk=list[i];
			blk.style.maxWidth="100%";
		}

		list=webObj.querySelectorAll("a");
		n=list.length;
		for(i=0;i<n;i++){
			blk=list[i];
			href=blk.href;
			if(href.startsWith("hub://")){
				//Filter <a> elements:
				blk.href="/-+hubfile/"+href.substring("hub://".length);
				blk.target="_blank";
			}
		}
		list=webObj.children;
		blks=[];
		n=list.length;
		for(i=0;i<n;i++){
			blks.push(list[i]);
		}
		for(i=0;i<n;i++){
			blk=blks[i];
			blkBox=boxMD.appendNewChild({
				type:"hud",width:"100%",height:"",position:"relative",
			});
			tagType=blk.tagName.toLowerCase();
			if(tagType==="pre"){
				list=blk.childNodes;
				if(list.length===1 && list[0].tagName.toLowerCase()==="code"){
					mode=list[0].className||"";
					pos=mode.indexOf("-");
					if(pos>0){
						mode=mode.substring(pos+1);
					}else{
						mode="";
					}
					code=list[0].innerText;
					boxMD.webObj.removeChild(blk);
					blkBox.appendNewChild(BoxCodeSeg(code,mode));
				}else{
					blkBox.webObj.appendChild(blk);
				}
			}else{
				if(i===0){
					blk.style.marginBlockStart="0px";
				}
				blkBox.webObj.appendChild(blk);
			}
		}
	};
	
	//------------------------------------------------------------------------
	cssVO._renderContents=function(){
		let content,preCode,code,postCode;
		let parsePos,pos,fullLength;
		let textBlk=txtContent;
		parsePos=0;
		content=self.content;
		fullLength=content.length;
		do{
			pos=content.indexOf("```",parsePos);
			if(pos>=0){
				//Precode:
				preCode=content.substring(parsePos,pos);
				if(textBlk){
					textBlk.text=preCode;
					textBlk=null;
				}else{
					if(preCode.length){
						boxContents.appendNewChild({
							"type":"text","position":"relative","x":0,"y":0,"w":"100%","h":"","color":vo.textColor||cfgColor.fontBody,
							"text":preCode,"fontSize":txtSize.smallPlus,"wrap":true,"selectable":true,
						});
					}
				}
				//find Code:
				parsePos=pos+3;
				pos=content.indexOf("```",parsePos);
				if(pos<0){
					pos=fullLength;
				}
				code=content.substring(parsePos,pos);
				if(code.length){
					boxContents.appendNewChild(
						BoxCodeSeg(code,"")
					);
				}
				parsePos=pos+3;
			}else{
				postCode=content.substring(parsePos);
				if(textBlk){
					textBlk.text=postCode;
					textBlk=null;
				}else{
					if(postCode.length){
						boxContents.appendNewChild({
							"type":"text","position":"relative","x":0,"y":0,"w":"100%","h":"","color":vo.textColor||cfgColor.fontBody,
							"text":postCode,"fontSize":txtSize.smallPlus,"wrap":true,"selectable":true,
						});
					}
				}
				parsePos=fullLength;
			}
		}while(parsePos>=0 && parsePos<fullLength);
	};
	
	//------------------------------------------------------------------------
	cssVO.trace=function(obj,prefix="",postfix="",autoHide=true){
		owner=self.parent;
		tracedObj=obj;
		hideOnTraceClose=autoHide;
		tracePrefix=prefix;
		tracePostfix=postfix;
		obj.on("content",self.OnUpdate);
		obj.on("close",self.OnClose);
	};
	
	function replaceTextContent(text) {
		// 替换所有数字为 "#"
		let result = text.replace(/\d/g, "#");
		// 替换所有拉丁字母为 "*"
		result = result.replace(/[a-zA-Z]/g, "*");
		// 替换所有非ASCII字符（例如中文）为 "■"
		result = result.replace(/[^\x00-\x7F]+/g, "■");
	
		return result;
	}
	
	//------------------------------------------------------------------------
	cssVO.OnUpdate=function(){
		if(tracedObj){
			if(session.hideInternal){
				let tgtText,srcText;
				self.content=txtContent.text=tracePrefix+replaceTextContent(tracedObj.content)+tracePostfix;
			}else{
				self.content=txtContent.text=tracePrefix+tracedObj.content+tracePostfix;
			}
			self.inputTokens=tracedObj.inputTokens;
			self.outputTokens=tracedObj.outputTokens;
			owner.scrollDown();
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.setWaitText=function(text){
		owner=self.parent
		if(tracedObj){
			if(session.hideInternal){
				let tgtText,srcText;
				self.content=txtContent.text=tracePrefix+replaceTextContent(tracedObj.content)+tracePostfix;
			}else{
				self.content=txtContent.text=tracePrefix+tracedObj.content+tracePostfix;
			}
			self.inputTokens=tracedObj.inputTokens;
			self.outputTokens=tracedObj.outputTokens;
			owner.scrollDown();
		}else{
			if(session.hideInternal||self.hideWaitText){
				txtContent.text=tracePrefix+replaceTextContent(text||"...")+tracePostfix;
			}else{
				txtContent.text=tracePrefix+(text||"...")+tracePostfix;
			}
			owner.scrollDown();
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.OnClose=function(){
		if(tracedObj){
			tracedObj.off("content",self.OnUpdate);
			tracedObj.off("close",self.OnClose);
			tracedObj=null;
			if(hideOnTraceClose){
				self.display=0;
			}
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.doCopy=function(){
		navigator.clipboard.writeText(self.content);
		boxCopyMark.display=1;
		boxCopyMark.animate({type:"out",time:500,alpha:0,delay:500});
	};
	
	//------------------------------------------------------------------------
	cssVO.saveImage=async function(){
		let fileName;
		function downloadBuf(data){
			var img = new Image();
			img.crossOrigin = "Anonymous";
			img.src = data;
			img.onload = function () {
				var canvas = document.createElement("canvas");
				var context = canvas.getContext("2d");
				canvas.width = img.width;
				canvas.height = img.height;
				context.drawImage(img, 0, 0);
				var dataURL = canvas.toDataURL("image/png");
				var link = document.createElement("a");
				link.href = dataURL;
				link.download = "image.png";
				link.click();
	
				//Release the URLData:
				window.setTimeout(() => {
					URL.revokeObjectURL(dataURL);
				}, 10000);
			};
		}
		function downloadFile(data){
			let e,blob,url;
			blob = new Blob([data], {type: "application/octet-stream"});
			url = URL.createObjectURL(blob);
			VFACT.webFileDownload.download = fileName;
			VFACT.webFileDownload.href = url;
	
			//Generate a mouse click:
			e = document.createEvent('MouseEvents');
			e.initEvent('click', true, false, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null);
			VFACT.webFileDownload.dispatchEvent(e);
	
			//Release the URLData:
			window.setTimeout(() => {
				URL.revokeObjectURL(url);
			}, 10000);
		}
		fileName=vo.image;
		if(fileName.startsWith("data:image/jpeg;")){
			downloadBuf(fileName);
		}else if(fileName.startsWith("data:image/png;")){
			fileName="image.png";
			downloadBuf(vo.image);
		}else if(fileName.startsWith("data:image/gif;")){
			fileName="image.gif";
			downloadBuf(vo.image);
		}else{
			let data=await (await fetch(fileName)).arrayBuffer();
			fileName=pathLib.basename(fileName);
			downloadFile(data);
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.downloadAudio=function(){
		let buf;
		function downloadFile(data,fileName){
			let blob, url;
			let e;
			blob = new Blob([data], {type: "application/octet-stream"});
			url = URL.createObjectURL(blob);
			VFACT.webFileDownload.download = fileName;
			VFACT.webFileDownload.href = url;
	
			//Generate a mouse click:
			e = document.createEvent('MouseEvents');
			e.initEvent('click', true, false, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null);
			VFACT.webFileDownload.dispatchEvent(e);
	
			//Release the URLData:
			window.setTimeout(() => {
				URL.revokeObjectURL(url);
			}, 10000);
		}
		buf=vo.audio;
		if(buf.startsWith("data:")){
			let pos=buf.indexOf(",");
			buf=buf.substring(pos+1);
		}
		buf=Base64.decode(buf);
		downloadFile(buf,"voice.mp3");
	};
	/*}#1HA0EVOKU1PostCSSVO*/
	cssVO.constructor=BoxAIChatBlock;
	return cssVO;
};
/*#{1HA0EVOKU1ExCodes*/
/*}#1HA0EVOKU1ExCodes*/

//----------------------------------------------------------------------------
BoxAIChatBlock.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1HA0EVOKU1PreAISpot*/
	/*}#1HA0EVOKU1PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1HA0EVOKU1PostAISpot*/
	/*}#1HA0EVOKU1PostAISpot*/
	return exposeVO;
};

/*#{1HA0EVOKU0EndDoc*/
/*}#1HA0EVOKU0EndDoc*/

export default BoxAIChatBlock;
export{BoxAIChatBlock};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1HA0EVOKU0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1HA0EVOKV0",
//			"attrs": {
//				"device": "iPhone 375x750",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1HA0EVOKV1",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1HA0EVOKV2",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1HA0EVOKV3",
//			"attrs": {
//				"vo": {
//					"type": "object",
//					"def": "FlatObj",
//					"jaxId": "1IBKH0AMQ0",
//					"attrs": {
//						"iconSize": {
//							"type": "int",
//							"valText": "24"
//						},
//						"icon": {
//							"type": "string",
//							"valText": "#appCfg.sharedAssets+\"/user.svg\""
//						},
//						"text": {
//							"type": "string",
//							"valText": "Hello AI2Apps!"
//						},
//						"fontSize": {
//							"type": "int",
//							"valText": "12"
//						},
//						"textColor": {
//							"type": "colorRGBA",
//							"valText": "#cfgColor[\"fontBodySub\"]"
//						},
//						"bgColor": {
//							"type": "colorRGBA",
//							"valText": "0"
//						},
//						"iconColor": {
//							"type": "colorRGBA",
//							"valText": "#cfgColor[\"fontBody\"]"
//						},
//						"iconBG": {
//							"type": "colorRGBA",
//							"valText": "#cfgColor[\"body\"]"
//						},
//						"iconBorderColor": {
//							"type": "colorRGBA",
//							"valText": "#cfgColor[\"fontBodyLit\"]"
//						},
//						"iconCorner": {
//							"type": "number",
//							"valText": "100"
//						},
//						"iconBorderSize": {
//							"type": "number",
//							"valText": "0"
//						},
//						"image": {
//							"type": "string",
//							"valText": ""
//						},
//						"audio": {
//							"type": "bool",
//							"valText": "false"
//						},
//						"buttons": {
//							"type": "bool",
//							"valText": "false"
//						},
//						"side": {
//							"type": "string",
//							"valText": "left"
//						},
//						"bgBorderSize": {
//							"type": "number",
//							"valText": "0"
//						},
//						"bgBorderColor": {
//							"type": "colorRGB",
//							"valText": "#cfgColor[\"fontBodyLit\"]"
//						},
//						"txtHeader": {
//							"type": "string",
//							"valText": ""
//						},
//						"txtFooter": {
//							"type": "string",
//							"valText": ""
//						},
//						"role": {
//							"type": "string",
//							"valText": "log"
//						}
//					}
//				},
//				"session": {
//					"type": "auto",
//					"valText": "null"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1HA0EVOKV4",
//			"attrs": {
//				"icon": {
//					"type": "url",
//					"valText": "#vo.icon||(appCfg.sharedAssets+\"/faces.svg\")"
//				},
//				"showText": {
//					"type": "string",
//					"valText": "#vo.text||\"\""
//				}
//			}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1HA0EVOKV5",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1HA0EVOKV6",
//			"attrs": {
//				"desktop": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HA0HG3080",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HA0HL4C00",
//							"attrs": {}
//						}
//					}
//				},
//				"mobile": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HA0HGV240",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HA0HL4C01",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1HA9DQK2O0",
//			"attrs": {
//				"AI result": {
//					"type": "mockState",
//					"def": "MockState",
//					"jaxId": "1HA9DQK2O1",
//					"attrs": {
//						"createArgs": {
//							"jaxId": "1HA0EVOKV3",
//							"attrs": {
//								"vo": {
//									"type": "auto"
//								},
//								"vox": {
//									"type": "auto",
//									"valText": "#{icon:appCfg.sharedAssets+\"/user.svg\",iconBG:cfgColor.success,bgColor:cfgColor.success,iconColor:cfgColor.fontPrimary,\tblkColor:cfgColor.body,textColor:cfgColor.fontBody,text:\"Hello!\",buttons:false,top:true,image:\"/~/tabos/shared/assets/aalogo.svg\"}"
//								},
//								"session": {
//									"type": "auto",
//									"valText": "null"
//								}
//							}
//						},
//						"stateObj": {
//							"jaxId": "1HA0EVOKV5",
//							"attrs": {}
//						}
//					}
//				},
//				"User prompt": {
//					"type": "mockState",
//					"def": "MockState",
//					"jaxId": "1HA9DSAG20",
//					"attrs": {
//						"createArgs": {
//							"jaxId": "1HA0EVOKV3",
//							"attrs": {
//								"vo": {
//									"type": "auto"
//								},
//								"session": {
//									"type": "auto",
//									"valText": "null"
//								}
//							}
//						},
//						"stateObj": {
//							"jaxId": "1HA0EVOKV5",
//							"attrs": {}
//						}
//					}
//				},
//				"Audio": {
//					"type": "mockState",
//					"def": "MockState",
//					"jaxId": "1HEN3HOB70",
//					"attrs": {
//						"createArgs": {
//							"jaxId": "1HA0EVOKV3",
//							"attrs": {
//								"vo": {
//									"type": "auto"
//								},
//								"session": {
//									"type": "auto",
//									"valText": "null"
//								}
//							}
//						},
//						"stateObj": {
//							"jaxId": "1HA0EVOKV5",
//							"attrs": {}
//						}
//					}
//				},
//				"image": {
//					"type": "mockState",
//					"def": "MockState",
//					"jaxId": "1HEQ2GG6B0",
//					"attrs": {
//						"createArgs": {
//							"jaxId": "1HA0EVOKV3",
//							"attrs": {
//								"vo": {
//									"type": "auto"
//								},
//								"session": {
//									"type": "auto",
//									"valText": "null"
//								}
//							}
//						},
//						"stateObj": {
//							"jaxId": "1HA0EVOKV5",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"exposeToAI": "true",
//		"descAI": "",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1HA0EVOKU1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1HA0EVOKV7",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Relative",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "\"\"",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "[0,0,0,0]",
//						"padding": "#vo.side===\"right\"?[5,5,10,30]:[5,30,10,5]",
//						"minW": "",
//						"minH": "30",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "#vo.side===\"right\"?\"flex-xr\":\"flex-x\"",
//						"traceSize": "true"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1HA0FE4LK0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HA0G1M6B0",
//									"attrs": {
//										"type": "box",
//										"id": "BoxIcon",
//										"position": "Relative",
//										"x": "0",
//										"y": "#vo.iconSize?vo.iconSize*0.5:16",
//										"w": "#vo.iconSize||32",
//										"h": "#vo.iconSize||32",
//										"anchorH": "Left",
//										"anchorV": "Center",
//										"autoLayout": "false",
//										"display": "#vo.icon!==false",
//										"clip": "On",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "3",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#vo.iconBG||vo.bgColor",
//										"border": "#vo.iconBorderSize||0",
//										"borderStyle": "Solid",
//										"borderColor": "#vo.iconBorderColor||[0,0,0,1.00]",
//										"corner": "#vo.iconCorner||5",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1HA0GFET80",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HA0GHG9I0",
//													"attrs": {
//														"type": "box",
//														"id": "",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "#vo.iconColor",
//														"border": "0",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]",
//														"maskImage": "#icon",
//														"attach": "#!!vo.icon"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HA0GHG9I1",
//													"attrs": {
//														"1HA0HG3080": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IBKGD3070",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IBKGD3071",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HA0HG3080",
//															"faceTagName": "desktop"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HA0GHG9I2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HA0GHG9J0",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "image",
//											"jaxId": "1HB2MJU6E0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HB2MKMU80",
//													"attrs": {
//														"type": "image",
//														"id": "",
//														"position": "Absolute",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"image": "#vo.pic",
//														"autoSize": "false",
//														"fitSize": "Cover",
//														"repeat": "true",
//														"alignX": "Left",
//														"alignY": "Top",
//														"attach": "#!!vo.pic"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HB2MKMU81",
//													"attrs": {
//														"1HA0HG3080": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IBKGD3072",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IBKGD3073",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HA0HG3080",
//															"faceTagName": "desktop"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HB2MKMU82",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HB2MKMU83",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1HA0G1M6B1",
//									"attrs": {
//										"1HA0HG3080": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IBKGD3074",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IBKGD3075",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HA0HG3080",
//											"faceTagName": "desktop"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HA0G1M6B2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HA0G1M6B3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1HA0G844M0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HA0GE7BT0",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxContents",
//										"position": "relative",
//										"x": "0",
//										"y": "5",
//										"w": "100",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "#vo.role===\"log\"?[0,5,0,1]:[0,5,0,2]",
//										"minW": "",
//										"minH": "20",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex Y",
//										"flex": "true",
//										"subAlign": "",
//										"itemsAlign": "#vo.side===\"right\"?2:0"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1IBKCSL060",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IBKD5A0E0",
//													"attrs": {
//														"type": "text",
//														"id": "TxtHeader",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "#vo.txtHeader",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "5",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBodySub\"]",
//														"text": "#vo.txtHeader||\" \"",
//														"font": "",
//														"fontSize": "#txtSize.small",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IBKD5A0E1",
//													"attrs": {
//														"1HA0HG3080": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IBKGD3078",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IBKGD3079",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HA0HG3080",
//															"faceTagName": "desktop"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IBKD5A0E2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IBKD5A0E3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1IBKD3C560",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IBKD5A0E4",
//													"attrs": {
//														"type": "hud",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "#vo.bgColor?[3,0,3,0]:[0,0,3,0]",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex X",
//														"subAlign": "#vo.side===\"right\"?2:0"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "box",
//															"jaxId": "1IBKD43MO0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IBKD5A0E5",
//																	"attrs": {
//																		"type": "box",
//																		"id": "BoxText",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "#vo.role===\"log\"?[0,3,3,3]:(vo.bgColor?10:[0,10,10,5])",
//																		"minW": "50",
//																		"minH": "12",
//																		"maxW": "100%",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"background": "#vo.bgColor||[0,0,0,0]",
//																		"border": "#vo.bgBorderSize||0",
//																		"borderStyle": "Solid",
//																		"borderColor": "#vo.bgBorderColor",
//																		"corner": "#vo.side===\"left\"?[0,16,16,16]:[16,0,16,16]",
//																		"shadow": "false",
//																		"shadowX": "2",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowSpread": "0",
//																		"shadowColor": "[0,0,0,0.50]",
//																		"contentLayout": "Flex Y",
//																		"itemsAlign": "#(!vo.image && !vo.audio)?1:(vo.side===\"right\"?2:0)"
//																	}
//																},
//																"subHuds": {
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "text",
//																			"jaxId": "1IBKD7HO70",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IBKD7HO71",
//																					"attrs": {
//																						"type": "text",
//																						"id": "TxtContent",
//																						"position": "Relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "",
//																						"h": "",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "text",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"color": "#vo.textColor",
//																						"text": "#showText",
//																						"font": "",
//																						"fontSize": "#vo.fontSize||txtSize.smallPlus",
//																						"bold": "false",
//																						"italic": "false",
//																						"underline": "false",
//																						"alignH": "Left",
//																						"alignV": "Top",
//																						"wrap": "true",
//																						"ellipsis": "false",
//																						"lineClamp": "0",
//																						"select": "true",
//																						"shadow": "false",
//																						"shadowX": "0",
//																						"shadowY": "2",
//																						"shadowBlur": "3",
//																						"shadowColor": "[0,0,0,1.00]",
//																						"shadowEx": "",
//																						"maxTextW": "0"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1IBKD7HO80",
//																					"attrs": {
//																						"1HA0HG3080": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IBKGD30710",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IBKGD30711",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HA0HG3080",
//																							"faceTagName": "desktop"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1IBKD7HO83",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1IBKD7HO84",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "false",
//																				"nameVal": "true"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "hud",
//																			"jaxId": "1IBKD9AO70",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IBKD9AO71",
//																					"attrs": {
//																						"type": "hud",
//																						"id": "BoxMD",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "100%",
//																						"h": "",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "Off",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": ""
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"faces": {
//																					"jaxId": "1IBKD9AO72",
//																					"attrs": {
//																						"1HA0HG3080": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IBKGD30712",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IBKGD30713",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HA0HG3080",
//																							"faceTagName": "desktop"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1IBKD9AO73",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1IBKD9AO74",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "true",
//																				"exposeContainer": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "image",
//																			"jaxId": "1IBKDJG8R0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IBKDJG8R1",
//																					"attrs": {
//																						"type": "image",
//																						"id": "Image",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "100",
//																						"h": "100",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "[5,30,0,30]",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"image": "#vo.image",
//																						"autoSize": "false",
//																						"fitSize": "Contain",
//																						"repeat": "true",
//																						"alignX": "Left",
//																						"alignY": "Top",
//																						"attach": "#!!vo.image"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": [
//																						{
//																							"type": "hudobj",
//																							"def": "Gear/@StdUI/ui/BtnIcon.js",
//																							"jaxId": "1IBKDJG8S0",
//																							"attrs": {
//																								"createArgs": {
//																									"jaxId": "1IBKDJG8S1",
//																									"attrs": {
//																										"style": "\"front\"",
//																										"w": "30",
//																										"h": "0",
//																										"icon": "#appCfg.sharedAssets+\"/save.svg\"",
//																										"colorBG": "null"
//																									}
//																								},
//																								"properties": {
//																									"jaxId": "1IBKDJG8S2",
//																									"attrs": {
//																										"type": "#null#>BtnIcon(\"front\",30,0,appCfg.sharedAssets+\"/save.svg\",null)",
//																										"id": "BtnSaveImg",
//																										"position": "Absolute",
//																										"x": "#vo.side===\"right\"?-30:\"100%\"",
//																										"y": "100%-30",
//																										"display": "#vo.button!==false",
//																										"face": "",
//																										"anchorV": "Center"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1IBKDJG8S3",
//																									"attrs": {
//																										"1HA0HG3080": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IBKGD3080",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IBKGD3081",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HA0HG3080",
//																											"faceTagName": "desktop"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1IBKDJG8S4",
//																									"attrs": {
//																										"OnClick": {
//																											"type": "fixedFunc",
//																											"jaxId": "1IBKDJG8S5",
//																											"attrs": {
//																												"callArgs": {
//																													"jaxId": "1IBKDJG8S6",
//																													"attrs": {
//																														"event": ""
//																													}
//																												},
//																												"seg": ""
//																											}
//																										}
//																									}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1IBKDJG8S7",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "false",
//																								"containerSlots": {
//																									"jaxId": "1IBKDJG8S8",
//																									"attrs": {}
//																								}
//																							}
//																						}
//																					]
//																				},
//																				"faces": {
//																					"jaxId": "1IBKDJG8S9",
//																					"attrs": {
//																						"1HA0HG3080": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IBKGD3082",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IBKGD3083",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HA0HG3080",
//																							"faceTagName": "desktop"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1IBKDJG8S10",
//																					"attrs": {
//																						"OnLoad": {
//																							"type": "fixedFunc",
//																							"jaxId": "1IBKDJG8S11",
//																							"attrs": {
//																								"callArgs": {
//																									"jaxId": "1IBKDJG8S12",
//																									"attrs": {}
//																								},
//																								"seg": ""
//																							}
//																						}
//																					}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1IBKDJG8S13",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "true"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "hud",
//																			"jaxId": "1IBKDJB3M0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IBKDJB3M1",
//																					"attrs": {
//																						"type": "hud",
//																						"id": "BoxAudio",
//																						"position": "relative",
//																						"x": "0",
//																						"y": "0",
//																						"w": "100%",
//																						"h": "30",
//																						"anchorH": "Left",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "[5,0,0,0]",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"subAlign": "Start",
//																						"contentLayout": "Flex X",
//																						"attach": "#!!vo.audio",
//																						"itemsAlign": "Center"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": [
//																						{
//																							"type": "hudobj",
//																							"def": "box",
//																							"jaxId": "1IBKDJB3N0",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IBKDJB3N1",
//																									"attrs": {
//																										"type": "box",
//																										"id": "BoxPlayAudio",
//																										"position": "relative",
//																										"x": "0",
//																										"y": "0",
//																										"w": "80",
//																										"h": "30",
//																										"anchorH": "Left",
//																										"anchorV": "Top",
//																										"autoLayout": "false",
//																										"display": "On",
//																										"clip": "Off",
//																										"uiEvent": "On",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "pointer",
//																										"zIndex": "0",
//																										"margin": "",
//																										"padding": "",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": "",
//																										"background": "#cfgColor[\"success\"]",
//																										"border": "1",
//																										"borderStyle": "Solid",
//																										"borderColor": "#cfgColor[\"secondary\"]",
//																										"corner": "[0,8,8,8]",
//																										"shadow": "false",
//																										"shadowX": "2",
//																										"shadowY": "2",
//																										"shadowBlur": "3",
//																										"shadowSpread": "0",
//																										"shadowColor": "[0,0,0,0.50]"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": [
//																										{
//																											"type": "hudobj",
//																											"def": "box",
//																											"jaxId": "1IBKDJB3O0",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IBKDJB3O1",
//																													"attrs": {
//																														"type": "box",
//																														"id": "",
//																														"position": "Absolute",
//																														"x": "50%",
//																														"y": "50%",
//																														"w": "28",
//																														"h": "28",
//																														"anchorH": "Center",
//																														"anchorV": "Center",
//																														"autoLayout": "false",
//																														"display": "On",
//																														"clip": "Off",
//																														"uiEvent": "Tree Off",
//																														"alpha": "1",
//																														"rotate": "0",
//																														"scale": "",
//																														"filter": "",
//																														"cursor": "",
//																														"zIndex": "0",
//																														"margin": "",
//																														"padding": "",
//																														"minW": "",
//																														"minH": "",
//																														"maxW": "",
//																														"maxH": "",
//																														"face": "",
//																														"styleClass": "",
//																														"background": "#cfgColor[\"fontSuccess\"]",
//																														"border": "0",
//																														"borderStyle": "Solid",
//																														"borderColor": "[0,0,0,1.00]",
//																														"corner": "0",
//																														"shadow": "false",
//																														"shadowX": "2",
//																														"shadowY": "2",
//																														"shadowBlur": "3",
//																														"shadowSpread": "0",
//																														"shadowColor": "[0,0,0,0.50]",
//																														"maskImage": "#appCfg.sharedAssets+\"/sound.svg\""
//																													}
//																												},
//																												"subHuds": {
//																													"attrs": []
//																												},
//																												"faces": {
//																													"jaxId": "1IBKDJB3O2",
//																													"attrs": {
//																														"1HA0HG3080": {
//																															"type": "hudface",
//																															"def": "HudFace",
//																															"jaxId": "1IBKGD3084",
//																															"attrs": {
//																																"properties": {
//																																	"jaxId": "1IBKGD3085",
//																																	"attrs": {}
//																																},
//																																"anis": {
//																																	"attrs": []
//																																}
//																															},
//																															"faceTagId": "1HA0HG3080",
//																															"faceTagName": "desktop"
//																														}
//																													}
//																												},
//																												"functions": {
//																													"jaxId": "1IBKDJB3O3",
//																													"attrs": {}
//																												},
//																												"extraPpts": {
//																													"jaxId": "1IBKDJB3O4",
//																													"attrs": {}
//																												},
//																												"mockup": "false",
//																												"codes": "false",
//																												"locked": "false",
//																												"container": "true",
//																												"nameVal": "false"
//																											}
//																										}
//																									]
//																								},
//																								"faces": {
//																									"jaxId": "1IBKDJB3O5",
//																									"attrs": {
//																										"1HA0HG3080": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IBKGD3086",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IBKGD3087",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HA0HG3080",
//																											"faceTagName": "desktop"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1IBKDJB3O6",
//																									"attrs": {
//																										"OnClick": {
//																											"type": "fixedFunc",
//																											"jaxId": "1IBKDJB3O7",
//																											"attrs": {
//																												"callArgs": {
//																													"jaxId": "1IBKDJB3O8",
//																													"attrs": {
//																														"event": ""
//																													}
//																												},
//																												"seg": ""
//																											}
//																										}
//																									}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1IBKDJB3O9",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "true",
//																								"nameVal": "false"
//																							}
//																						},
//																						{
//																							"type": "hudobj",
//																							"def": "Gear/@StdUI/ui/BtnIcon.js",
//																							"jaxId": "1IBKDJB3O10",
//																							"attrs": {
//																								"createArgs": {
//																									"jaxId": "1IBKDJB3O11",
//																									"attrs": {
//																										"style": "\"front\"",
//																										"w": "28",
//																										"h": "0",
//																										"icon": "#appCfg.sharedAssets+\"/save.svg\"",
//																										"colorBG": "null"
//																									}
//																								},
//																								"properties": {
//																									"jaxId": "1IBKDJB3O12",
//																									"attrs": {
//																										"type": "#null#>BtnIcon(\"front\",28,0,appCfg.sharedAssets+\"/save.svg\",null)",
//																										"id": "",
//																										"position": "relative",
//																										"x": "0",
//																										"y": "0",
//																										"display": "On",
//																										"face": "",
//																										"margin": "[0,0,0,5]"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1IBKDJB3P0",
//																									"attrs": {
//																										"1HA0HG3080": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IBKGD3088",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IBKGD3089",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HA0HG3080",
//																											"faceTagName": "desktop"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1IBKDJB3P1",
//																									"attrs": {
//																										"OnClick": {
//																											"type": "fixedFunc",
//																											"jaxId": "1IBKDJB3P2",
//																											"attrs": {
//																												"callArgs": {
//																													"jaxId": "1IBKDJB3P3",
//																													"attrs": {
//																														"event": ""
//																													}
//																												},
//																												"seg": ""
//																											}
//																										}
//																									}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1IBKDJB3P4",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "false",
//																								"containerSlots": {
//																									"jaxId": "1IBKDJB3P5",
//																									"attrs": {}
//																								}
//																							}
//																						},
//																						{
//																							"type": "hudobj",
//																							"def": "hud",
//																							"jaxId": "1IBKDJB3P6",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IBKDJB3P7",
//																									"attrs": {
//																										"type": "hud",
//																										"id": "BoxAudioSlot",
//																										"position": "relative",
//																										"x": "0",
//																										"y": "0",
//																										"w": "10",
//																										"h": "10",
//																										"anchorH": "Left",
//																										"anchorV": "Top",
//																										"autoLayout": "false",
//																										"display": "On",
//																										"clip": "On",
//																										"uiEvent": "On",
//																										"alpha": "0",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "",
//																										"zIndex": "0",
//																										"margin": "",
//																										"padding": "",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": ""
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1IBKDJB3P8",
//																									"attrs": {
//																										"1HA0HG3080": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IBKGD30810",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IBKGD30811",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HA0HG3080",
//																											"faceTagName": "desktop"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1IBKDJB3P9",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1IBKDJB3P10",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "true",
//																								"nameVal": "true",
//																								"exposeContainer": "false"
//																							}
//																						}
//																					]
//																				},
//																				"faces": {
//																					"jaxId": "1IBKDJB3P11",
//																					"attrs": {
//																						"1HA0HG3080": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IBKGD30812",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IBKGD30813",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HA0HG3080",
//																							"faceTagName": "desktop"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1IBKDJB3P12",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1IBKDJB3P13",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "false",
//																				"exposeContainer": "false"
//																			}
//																		},
//																		{
//																			"type": "hudobj",
//																			"def": "hud",
//																			"jaxId": "1IBKFL32O0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IBKFL32O1",
//																					"attrs": {
//																						"type": "hud",
//																						"id": "",
//																						"position": "Absolute",
//																						"x": "#vo.side===\"right\"?0:\"100%\"",
//																						"y": "0",
//																						"w": "30",
//																						"h": "30",
//																						"anchorH": "#vo.side===\"right\"?2:0",
//																						"anchorV": "Top",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": "",
//																						"attach": "#vo.buttons"
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": [
//																						{
//																							"type": "hudobj",
//																							"def": "Gear/@StdUI/ui/BtnIcon.js",
//																							"jaxId": "1IBKFL32P0",
//																							"attrs": {
//																								"createArgs": {
//																									"jaxId": "1IBKFL32P1",
//																									"attrs": {
//																										"style": "#cfgColor.fontBodySub",
//																										"w": "25",
//																										"h": "0",
//																										"icon": "#appCfg.sharedAssets+\"/copy.svg\"",
//																										"colorBG": "null"
//																									}
//																								},
//																								"properties": {
//																									"jaxId": "1IBKFL32P2",
//																									"attrs": {
//																										"type": "#null#>BtnIcon(cfgColor.fontBodySub,25,0,appCfg.sharedAssets+\"/copy.svg\",null)",
//																										"id": "BtnCopy",
//																										"position": "Absolute",
//																										"x": "50%",
//																										"y": "50%",
//																										"display": "On",
//																										"face": "",
//																										"anchorH": "Center",
//																										"anchorV": "Center",
//																										"attach": "#vo.buttons"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1IBKFL32P3",
//																									"attrs": {
//																										"1HA0HG3080": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IBKGD30814",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IBKGD30815",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HA0HG3080",
//																											"faceTagName": "desktop"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1IBKFL32P6",
//																									"attrs": {
//																										"OnClick": {
//																											"type": "fixedFunc",
//																											"jaxId": "1IBKFL32P7",
//																											"attrs": {
//																												"callArgs": {
//																													"jaxId": "1IBKFL32P8",
//																													"attrs": {
//																														"event": ""
//																													}
//																												},
//																												"seg": ""
//																											}
//																										}
//																									}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1IBKFL32P9",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "true",
//																								"containerSlots": {
//																									"jaxId": "1IBKFL32P10",
//																									"attrs": {}
//																								}
//																							}
//																						},
//																						{
//																							"type": "hudobj",
//																							"def": "box",
//																							"jaxId": "1IBKFL32Q0",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IBKFL32Q1",
//																									"attrs": {
//																										"type": "box",
//																										"id": "BoxCopyMark",
//																										"position": "relative",
//																										"x": "50%",
//																										"y": "50%",
//																										"w": "50%",
//																										"h": "50%",
//																										"anchorH": "Center",
//																										"anchorV": "Center",
//																										"autoLayout": "false",
//																										"display": "Off",
//																										"clip": "Off",
//																										"uiEvent": "On",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "",
//																										"zIndex": "0",
//																										"margin": "",
//																										"padding": "",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": "",
//																										"background": "#cfgColor[\"fontBody\"]",
//																										"border": "1",
//																										"borderStyle": "Solid",
//																										"borderColor": "[0,0,0,1.00]",
//																										"corner": "0",
//																										"shadow": "false",
//																										"shadowX": "2",
//																										"shadowY": "2",
//																										"shadowBlur": "3",
//																										"shadowSpread": "0",
//																										"shadowColor": "[0,0,0,0.50]",
//																										"maskImage": "#appCfg.sharedAssets+\"/check.svg\""
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1IBKFL32Q2",
//																									"attrs": {
//																										"1HA0HG3080": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IBKGD30816",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IBKGD30817",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HA0HG3080",
//																											"faceTagName": "desktop"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1IBKFL32Q3",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1IBKFL32Q4",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "true"
//																							}
//																						}
//																					]
//																				},
//																				"faces": {
//																					"jaxId": "1IBKFL32Q5",
//																					"attrs": {
//																						"1HA0HG3080": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IBKFL32Q6",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IBKFL32Q7",
//																									"attrs": {
//																										"y": {
//																											"type": "length",
//																											"valText": "0"
//																										}
//																									}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HA0HG3080",
//																							"faceTagName": "desktop"
//																						},
//																						"1HA0HGV240": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IBKFL32Q8",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IBKFL32Q9",
//																									"attrs": {
//																										"y": {
//																											"type": "length",
//																											"valText": "100%-30"
//																										}
//																									}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HA0HGV240",
//																							"faceTagName": "mobile"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1IBKFL32Q10",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1IBKFL32Q11",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "false",
//																				"exposeContainer": "false"
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"jaxId": "1IBKD5A0E6",
//																	"attrs": {
//																		"1HA0HG3080": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IBKGD30818",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IBKGD30819",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HA0HG3080",
//																			"faceTagName": "desktop"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1IBKD5A0E7",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1IBKD5A0E8",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false"
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1IBKD5A0E9",
//													"attrs": {
//														"1HA0HG3080": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IBKGD30820",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IBKGD30821",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HA0HG3080",
//															"faceTagName": "desktop"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IBKD5A0E10",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IBKD5A0E11",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1IBKFA0G40",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IBKFA0G41",
//													"attrs": {
//														"type": "text",
//														"id": "TxtFooter",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "5",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBodySub\"]",
//														"text": "#vo.txtFooter||\"\"",
//														"font": "",
//														"fontSize": "#txtSize.small",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0",
//														"attach": "#!!vo.txtFooter"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IBKFA0G42",
//													"attrs": {
//														"1HA0HG3080": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IBKGD30822",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IBKGD30823",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HA0HG3080",
//															"faceTagName": "desktop"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IBKFA0G43",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IBKFA0G44",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1HA0GE7BT1",
//									"attrs": {
//										"1HA0HG3080": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IBKGD30824",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IBKGD30825",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HA0HG3080",
//											"faceTagName": "desktop"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HA0GE7BT2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HA0GE7BT3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1HA0EVOKV8",
//					"attrs": {
//						"1HA0HG3080": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1IBKGD30826",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IBKGD30827",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HA0HG3080",
//							"faceTagName": "desktop"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1HA0EVOKV9",
//					"attrs": {
//						"OnSize": {
//							"type": "fixedFunc",
//							"jaxId": "1HA0HQH3P0",
//							"attrs": {
//								"callArgs": {
//									"jaxId": "1HA0HQP8C0",
//									"attrs": {}
//								},
//								"seg": ""
//							}
//						},
//						"OnFree": {
//							"type": "fixedFunc",
//							"jaxId": "1HA0IDR1E0",
//							"attrs": {
//								"callArgs": {
//									"jaxId": "1HA0IE1L70",
//									"attrs": {}
//								},
//								"seg": ""
//							}
//						}
//					}
//				},
//				"extraPpts": {
//					"jaxId": "1HA0EVOKV10",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "true",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1HA0EVOKV11",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}