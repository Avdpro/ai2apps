//Auto genterated by Cody
import {$P,VFACT,callAfter} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
/*#{1HANQVJRS0StartDoc*/
/*}#1HANQVJRS0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BoxGoNext=function(){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1HANQVJRS1LocalVals*/
	/*}#1HANQVJRS1LocalVals*/
	
	/*#{1HANQVJRS1PreState*/
	/*}#1HANQVJRS1PreState*/
	/*#{1HANQVJRS1PostState*/
	/*}#1HANQVJRS1PostState*/
	cssVO={
		"hash":"1HANQVJRS1",nameHost:true,
		"type":"hud","x":0,"y":0,"w":"100%","h":"","uiEvent":-1,"padding":5,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
		"itemsAlign":1,"subAlign":1,
		children:[
			{
				"hash":"1HANR0NV30",
				"type":"box","position":"relative","x":0,"y":0,"w":16,"h":16,"uiEvent":-1,"styleClass":"","background":cfgColor["fontBodySub"],"maskImage":appCfg.sharedAssets+"/fat_down.svg",
			},
			{
				"hash":"1HANRHQN60",
				"type":"box","position":"relative","x":0,"y":0,"w":16,"h":16,"uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["fontBodySub"],
				"maskImage":appCfg.sharedAssets+"/fat_down.svg",
			},
			{
				"hash":"1HANRHSH20",
				"type":"box","position":"relative","x":0,"y":0,"w":16,"h":16,"uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["fontBodySub"],
				"maskImage":appCfg.sharedAssets+"/fat_down.svg",
			}
		],
		/*#{1HANQVJRS1ExtraCSS*/
		/*}#1HANQVJRS1ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			self=this;
			
			/*#{1HANQVJRS1Create*/
			/*}#1HANQVJRS1Create*/
		},
		/*#{1HANQVJRS1EndCSS*/
		/*}#1HANQVJRS1EndCSS*/
	};
	/*#{1HANQVJRS1PostCSSVO*/
	/*}#1HANQVJRS1PostCSSVO*/
	return cssVO;
};
/*#{1HANQVJRS1ExCodes*/
/*}#1HANQVJRS1ExCodes*/

BoxGoNext.gearExport={
	framework: "jax",
	hudType: "hud",
	"showName":"",icon:"gears.svg",previewImg:false,
	fixPose:true,initW:300,initH:30,
	catalog:"",
	args: {},
	state:{
	},
	properties:["id","position","x","y","display"],
	faces:[],
	subContainers:{
	},
	/*#{1HANQVJRS0ExGearInfo*/
	/*}#1HANQVJRS0ExGearInfo*/
};
export default BoxGoNext;
export{BoxGoNext};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1HANQVJRS0",
//	"editVersion": 66,
//	"attrs": {
//		"editEnv": {
//			"type": "object",
//			"jaxId": "1HANQVJRS2",
//			"editVersion": 10,
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"type": "object",
//			"jaxId": "1HANQVJRS3",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"model": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1HANQVJRS4",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"createArgs": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1HANQVJRS5",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"localVars": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1HANQVJRS6",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"type": "object",
//			"def": "StateObj",
//			"jaxId": "1HANQVJRS7",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "300",
//		"gearH": "30",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "true",
//		"previewImg": "",
//		"faceTags": {
//			"type": "object",
//			"def": "FaceTags",
//			"jaxId": "1HANQVJRS8",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"mockupStates": {
//			"type": "object",
//			"def": "MockupObj",
//			"jaxId": "1HANQVJRS9",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1HANQVJRS1",
//			"editVersion": 22,
//			"attrs": {
//				"properties": {
//					"type": "object",
//					"jaxId": "1HANQVJRS10",
//					"editVersion": 90,
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "Tree Off",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "5",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Flex X",
//						"itemsAlign": "Center",
//						"subAlign": "Center"
//					}
//				},
//				"subHuds": {
//					"type": "array",
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1HANR0NV30",
//							"editVersion": 20,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1HANR5FDH0",
//									"editVersion": 148,
//									"attrs": {
//										"type": "box",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "16",
//										"h": "16",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"fontBodySub\"]",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"maskImage": "#appCfg.sharedAssets+\"/fat_down.svg\""
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1HANR5FDH1",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1HANR5FDH2",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1HANR5FDH3",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1HANRHQN60",
//							"editVersion": 20,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1HANRHQN61",
//									"editVersion": 150,
//									"attrs": {
//										"type": "box",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "16",
//										"h": "16",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"fontBodySub\"]",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"maskImage": "#appCfg.sharedAssets+\"/fat_down.svg\""
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1HANRHQN62",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1HANRHQN63",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1HANRHQN64",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1HANRHSH20",
//							"editVersion": 20,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1HANRHSH21",
//									"editVersion": 148,
//									"attrs": {
//										"type": "box",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "16",
//										"h": "16",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"fontBodySub\"]",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"maskImage": "#appCfg.sharedAssets+\"/fat_down.svg\""
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1HANRHSH30",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1HANRHSH31",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1HANRHSH32",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"type": "object",
//					"jaxId": "1HANQVJRS11",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"functions": {
//					"type": "object",
//					"jaxId": "1HANQVJRS12",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"extraPpts": {
//					"type": "object",
//					"def": "Object",
//					"jaxId": "1HANQVJRS13",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1HANQVJRS14",
//			"editVersion": 64,
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}