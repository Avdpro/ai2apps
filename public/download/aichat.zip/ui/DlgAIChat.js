//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
import {BoxAIChat} from "./BoxAIChat.js";
import {BtnText} from "/@StdUI/ui/BtnText.js";
/*#{1HA4CQ2RT0StartDoc*/
import {tabFS} from "/@tabos";
import {tabNT} from "/@tabos/tabos_nt.js";
import {DlgLogin} from "/@homekit/ui/DlgLogin.js";
import {DlgFile} from "/@homekit/ui/DlgFile.js";
import {BoxAIChatBlock} from "./BoxAIChatBlock.js";
import {BoxAskUser} from "./BoxAskUser.js";
/*}#1HA4CQ2RT0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let DlgAIChat=function(){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let boxBG,txtTitle,btnClear,boxChats,boxUser,btnLocalFile,btnNativeFile,edUserInput,txtInputHint;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1HA4CQ2RT1LocalVals*/
	const app=VFACT.app;
	let dlgVO=null;
	let allowEmptyChat=true;
	let chatCallback=null;
	/*}#1HA4CQ2RT1LocalVals*/
	
	/*#{1HA4CQ2RT1PreState*/
	/*}#1HA4CQ2RT1PreState*/
	/*#{1HA4CQ2RT1PostState*/
	/*}#1HA4CQ2RT1PostState*/
	cssVO={
		"hash":"1HA4CQ2RT1",nameHost:true,
		"type":"hud","id":"DlgAIChat","x":"50%","y":"50%","w":"90%","h":"","anchorX":1,"anchorY":1,"padding":[10,10,10,10],"minW":320,"minH":"","maxW":800,"maxH":"",
		"styleClass":"","contentLayout":"flex-y",
		children:[
			{
				"hash":"1HA4D73LO0",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["body"],
				"border":1,"borderColor":cfgColor["lineBodySub"],"corner":6,"shadow":true,"shadowY":6,"shadowBlur":8,"shadowColor":[0,0,0,0.3],
			},
			{
				"hash":"1HA4DB93M0",
				"type":"text","id":"TxtTitle","position":"relative","x":0,"y":0,"w":"100%","h":30,"uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"color":cfgColor["fontBodySub"],"text":"Chat with AI Assistant","fontSize":txtSize.big,"fontWeight":"bold","fontStyle":"normal","textDecoration":"",
				"alignV":1,
			},
			{
				"hash":"1HA4DOVNU0",
				"type":"hud","id":"BoxToolBtns","x":">calc(100% - 10px)","y":10,"w":"","h":30,"anchorX":2,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"contentLayout":"flex-x","subAlign":2,"itemsAlign":1,
				children:[
					{
						"hash":"1HA4E37S70",
						"type":BtnIcon(cfgColor.fontBody,28,0,appCfg.sharedAssets+"/trash.svg",null),"id":"BtnClear","position":"relative","x":0,"y":0,"padding":2,
						"OnClick":function(event){
							/*#{1HA6N7GI00FunctionBody*/
							self.resetChat();
							/*}#1HA6N7GI00FunctionBody*/
						},
					},
					{
						"hash":"1HA4DVAJM0",
						"type":BtnIcon(cfgColor.fontBody,28,0,appCfg.sharedAssets+"/close.svg",null),"id":"BtnClose","position":"relative","x":0,"y":0,"padding":2,
						"OnClick":function(event){
							/*#{1HA5KCQGD0FunctionBody*/
							self.close();
							/*}#1HA5KCQGD0FunctionBody*/
						},
					}
				],
			},
			{
				"hash":"1HA51LIVU0",
				"type":BoxAIChat(),"id":"BoxChats","position":"relative","x":0,"y":0,"w":"100%","h":"","minH":20,"maxH":500,"overflow":"auto-y",
			},
			{
				"hash":"1HA539OJ20",
				"type":"box","id":"BoxUser","position":"relative","x":"50%","y":0,"w":">calc(100% - 50px)","h":"","anchorX":1,"minW":"","minH":30,"maxW":"","maxH":"",
				"styleClass":"","background":[255,255,255,1],"corner":3,"shadow":true,"shadowX":0,"shadowY":1,"shadowBlur":4,"shadowColor":[0,0,0,0.3],"contentLayout":"flex-y",
				children:[
					{
						"hash":"1HA5C6UEO0",
						"type":"hud","id":"BoxInput","position":"relative","x":0,"y":0,"w":"100%","h":"","padding":[5,10,5,10],"minW":"","minH":20,"maxW":"","maxH":"","styleClass":"",
						"contentLayout":"flex-x","traceSize":true,"itemsAlign":1,
						children:[
							{
								"hash":"1HD6JB8LG0",
								"type":"hud","id":"BoxFileBtnsFrame","position":"relative","x":0,"y":0,"w":20,"h":20,"overflow":1,"margin":[0,5,0,0],"minW":"","minH":"","maxW":"",
								"maxH":"","styleClass":"",
								children:[
									{
										"hash":"1HD6JB8LG2",
										"type":"hud","id":"BoxButtons","x":0,"y":20,"w":20,"h":40,"anchorY":2,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
										children:[
											{
												"hash":"1HD6JB8LG4",
												"type":"box","x":-3,"y":-3,"w":">calc(100% + 6px)","h":">calc(100% + 6px)","display":0,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
												"background":cfgColor["body"],"border":1,"borderColor":cfgColor["fontBodyLit"],"corner":3,"shadow":true,"shadowX":0,"shadowBlur":5,"shadowColor":[0,0,0,0.3],
											},
											{
												"hash":"1HD6JB8LH12",
												"type":BtnIcon("front",20,0,appCfg.sharedAssets+"/folder.svg",null),"id":"BtnLocalFile","x":0,"y":20,"margin":[0,5,0,0],"padding":0,"autoLayout":true,
												"OnClick":function(event){
													/*#{1HD6JB8LI0FunctionBody*/
													self.useLocalFile();
													/*}#1HD6JB8LI0FunctionBody*/
												},
											},
											{
												"hash":"1HD6JB8LI4",
												"type":BtnIcon("front",20,0,appCfg.sharedAssets+"/upload.svg",null),"id":"BtnNativeFile","x":0,"y":0,"display":0,"margin":[0,5,0,0],"padding":0,
												"autoLayout":true,
												/*#{1HD6JB8LI4Codes*/
												"labelHtml": '<input type="file" multiple="false" style="width:0px">',
												OnLableAction:function(){
													let files=[],i,n;
													n=this.files.length;
													for(i=0;i<n;i++){
														files.push(this.files[i]);
													}
													self.useNativeFile(files[0]);
													this.value="";
												}
												/*}#1HD6JB8LI4Codes*/
											}
										],
									}
								],
								"OnMouseInOut":function(isIn,event){
									/*#{1HD6JB8LJ3FunctionBody*/
									if(isIn){
										self.showFace("filemenu");
									}else{
										self.showFace("!filemenu");
									}
									/*}#1HD6JB8LJ3FunctionBody*/
								},
							},
							{
								"hash":"1HA5CBU550",
								"type":"memo","id":"EdUserInput","position":"relative","x":0,"y":0,"w":">calc(100% - 100px)","h":"","minW":"","minH":20,"maxW":"","maxH":200,"styleClass":"",
								"color":cfgColor["fontBody"],"background":cfgColor["body"],"fontSize":txtSize.mid,"outline":0,"border":[0,0,1,0],"borderColor":[0,0,0,0.5],"flex":true,
								"OnInput":function(){
									/*#{1HA5G1NT60FunctionBody*/
									txtInputHint.display=!this.text;
									/*}#1HA5G1NT60FunctionBody*/
								},
								"OnKeyDown":function(event){
									/*#{1HA5G46350FunctionBody*/
									if(event.code==="Enter"){
										if((!event.isComposing) &&(!event.shiftKey)){
											event.stopPropagation();
											event.preventDefault();
											self.sendChat();
										}
									}
									/*}#1HA5G46350FunctionBody*/
								},
							},
							{
								"hash":"1HA5CFVOF0",
								"type":BtnIcon("front",30,0,appCfg.sharedAssets+"/send.svg",null),"id":"BtnSend","position":"relative","x":0,"y":0,"margin":[0,0,0,10],"padding":2,
								"autoLayout":true,
								"OnClick":function(event){
									/*#{1HA5G7T3V0FunctionBody*/
									self.sendChat();
									/*}#1HA5G7T3V0FunctionBody*/
								},
							},
							{
								"hash":"1HA5CMCID0",
								"type":"text","id":"TxtInputHint","x":40,"y":0,"w":100,"h":"100%","uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodyLit"],
								"text":"Input chat message...","fontSize":txtSize.mid,"fontWeight":"normal","fontStyle":"italic","textDecoration":"","alignV":1,
							}
						],
					},
					{
						"hash":"1HA5CRLRB0",
						"type":"hud","id":"BoxWait","position":"relative","x":0,"y":0,"w":"100%","h":50,"display":0,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						children:[
							{
								"hash":"1HA5CSM2L0",
								"type":"text","x":0,"y":0,"w":"100%","h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodyLit"],"text":"AI is thinking...",
								"fontSize":txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignH":1,"alignV":1,
							},
							{
								"hash":"1HA5CV4FU0",
								"type":BtnText("primary",100,25,"Abort",false,""),"id":"BtnAbort","x":"50%","y":20,"anchorX":1,
								"OnClick":function(event){
									/*#{1HA7BN1640FunctionBody*/
									self.abortChat();
									/*}#1HA7BN1640FunctionBody*/
								},
							}
						],
					}
				],
			}
		],
		/*#{1HA4CQ2RT1ExtraCSS*/
		/*}#1HA4CQ2RT1ExtraCSS*/
		faces:{
			"start":{
				/*BoxInput*/"#1HA5C6UEO0":{
					"display":0
				}
			},"input":{
				/*BtnClear*/"#1HA4E37S70":{
					"enable":true
				},
				/*BtnClose*/"#1HA4DVAJM0":{
					"enable":true
				},
				/*BoxInput*/"#1HA5C6UEO0":{
					"display":1
				},
				/*BoxWait*/"#1HA5CRLRB0":{
					"display":0
				}
			},"wait":{
				/*BtnClear*/"#1HA4E37S70":{
					"enable":false
				},
				/*BtnClose*/"#1HA4DVAJM0":{
					"enable":false
				},
				/*BoxInput*/"#1HA5C6UEO0":{
					"display":0
				},
				/*BoxWait*/"#1HA5CRLRB0":{
					"display":1
				}
			},"mobile":{
			},"desktop":{
			},"allowflie":{
				/*BoxFileBtnsFrame*/"#1HD6JB8LG0":{
					"display":1
				},
				/*TxtInputHint*/"#1HA5CMCID0":{
					"x":40
				}
			},"!allowfile":{
				/*BoxFileBtnsFrame*/"#1HD6JB8LG0":{
					"display":0
				},
				/*TxtInputHint*/"#1HA5CMCID0":{
					"x":18
				}
			},"filemenu":{
				/*BoxFileBtnsFrame*/"#1HD6JB8LG0":{
					"overflow":0
				},
				"#1HD6JB8LG4":{
					"display":1
				},
				/*BtnLocalFile*/"#1HD6JB8LH12":{
					"display":1
				},
				/*BtnNativeFile*/"#1HD6JB8LI4":{
					"display":1
				}
			},"!filemenu":{
				/*BoxFileBtnsFrame*/"#1HD6JB8LG0":{
					"overflow":1
				},
				"#1HD6JB8LG4":{
					"display":0
				},
				/*BtnNativeFile*/"#1HD6JB8LI4":{
					"display":0
				}
			}
		},
		OnCreate:function(){
			self=this;
			boxBG=self.BoxBG;txtTitle=self.TxtTitle;btnClear=self.BtnClear;boxChats=self.BoxChats;boxUser=self.BoxUser;btnLocalFile=self.BtnLocalFile;btnNativeFile=self.BtnNativeFile;edUserInput=self.EdUserInput;txtInputHint=self.TxtInputHint;
			/*#{1HA4CQ2RT1Create*/
			edUserInput.text="";
			txtInputHint.display=true;
			//ApplyMove:
			VFACT.applyMoveDrag(boxBG,self);
			//Init blocks:
			boxChats.initBlockDef({
				"user":(session,blockVO)=>{
					return BoxAIChatBlock({
						icon:appCfg.sharedAssets+"/user.svg",iconBG:cfgColor.success,iconColor:cfgColor.fontPrimary,
						bgColor:cfgColor.body,textColor:cfgColor.fontBody,text:blockVO.text||blockVO.content,buttons:false,top:blockVO.top
					},session);
				},
				"greeting":(session,blockVO)=>{
					return BoxAIChatBlock({
						icon:appCfg.sharedAssets+"/faces.svg",iconBG:cfgColor.warning,iconColor:cfgColor.fontPrimary,
						bgColor:cfgColor.body,textColor:cfgColor.fontBody,text:blockVO.text||blockVO.content,buttons:false,top:blockVO.top
					},session);
				},
				"assistant":(session,blockVO)=>{
					return BoxAIChatBlock({
						icon:appCfg.sharedAssets+"/faces.svg",iconBG:cfgColor.warning,iconColor:cfgColor.fontPrimary,
						bgColor:cfgColor.body,textColor:cfgColor.fontBody,text:blockVO.text||blockVO.content,buttons:true,top:blockVO.top,
						render:true
					},session);
				},
				"wait":(session,blockVO)=>{
					return BoxAIChatBlock({
						icon:appCfg.sharedAssets+"/wait.svg",iconBG:cfgColor.secondary,iconColor:cfgColor.fontPrimary,
						bgColor:cfgColor.body,textColor:cfgColor.fontBody,text:blockVO.text||blockVO.content,buttons:false,top:blockVO.top
					},session);
				},
				"event":(session,blockVO)=>{
					return BoxAIChatBlock({
						icon:appCfg.sharedAssets+"/event.svg",iconBG:cfgColor.warning,iconColor:cfgColor.fontPrimary,
						bgColor:cfgColor.body,textColor:cfgColor.fontBody,text:blockVO.text||blockVO.content,buttons:false,top:blockVO.top
					},session);
				},
				"error":(session,blockVO)=>{
					return BoxAIChatBlock({
						icon:appCfg.sharedAssets+"/fat_right.svg",iconBG:cfgColor.error,iconColor:cfgColor.fontPrimary,
						bgColor:cfgColor.body,textColor:cfgColor.fontBody,text:blockVO.text||blockVO.content,buttons:false,top:blockVO.top
					},session);
				},
			},{
				"input":(session,blockVO)=>{
					return BoxAskUser(blockVO,session);
				},
				"confirm":(session,blockVO)=>{
					return BoxAskUser(blockVO,session);
				},
				"menu":(session,blockVO)=>{
					return BoxAskUser(blockVO,session);
				},
				"range":(session,blockVO)=>{
					return null;
				},
				"chatInput":self.chatInput,
				"cancelChatInput":self.cancelChatInput,
			});
			/*}#1HA4CQ2RT1Create*/
		},
		/*#{1HA4CQ2RT1EndCSS*/
		/*}#1HA4CQ2RT1EndCSS*/
	};
	/*#{1HA4CQ2RT1PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.showDlg=function(vo){
		dlgVO=vo;
		if(self.w<500){
			self.showFace("mobile");
		}else{
			self.showFace("desktop");
		}
		self.showFace("start");
		if(vo.allowReset===false){
			btnClear.display=false;
		}else{
			btnClear.display=true;
		}
		if(vo.clearChat){
			boxChats.resetChat(false);
		}
		allowEmptyChat=vo.allowEmptyChat!==false;
		boxChats.initSession(vo.bot||vo.url).then(async (session)=>{
			let bot;
			if(!(await tabNT.checkLogin(false))){
				let rootApp,logined;
				let res=await tabNT.makeCall("checkAICallStatus",{},5000);
				if(res.code!==200){
					rootApp=app.appFrame?app.appFrame.app:app;
					logined=await rootApp.modalDlg(DlgLogin,{x:rootApp.width/2,y:100,alignH:1});
					if(!logined){
						self.close();
						return;
					}
					await tabNT.checkLogin(false);
				}
			}
			bot=session.entryBot;
			if(bot.isAIChatBot){
				if(bot.allowFile){
					self.showFace("allowfile");
				}else{
					self.showFace("!allowfile");
				}
				self.showFace("input");
				edUserInput.focus();
				app.emit("SessionReady",session);
			}else{
				app.emit("SessionReady",session);
				if(bot.autoStart && vo.autoStart!==false){
					let result;
					app.emit("StartAgent",session);
					result=await boxChats.execChat(bot.url,vo.prompt||"");
					app.emit("EndAgent",session,bot);
					if(dlgVO.autoClose){
						app.closeDlg(self,result);
					}
				}
			}
		}).catch((err)=>{
			console.error(err);
			app.closeDlg(self);
		});
	};
	
	//------------------------------------------------------------------------
	cssVO.useLocalFile=async function(){
		let path,item;
		path=pathLib.dirname(this.session.entryBot.url);
		if(path.startsWith("/~/")){
			path=path.substring(2);
		}else if(path.startsWith("//")){
			path=path.substring(1);
		}
		item=await app.modalDlg(DlgMenu,{
			hud:self.BtnLocalFile,
			items:[
				{text:(($ln==="CN")?("使用文件路径"):/*EN*/("Use file path")),code:"path"},
				{text:(($ln==="CN")?("使用文件内容"):/*EN*/("Use file content")),code:"content"},
			]
		});
		if(!item){
			return;
		}
	
		path=await app.modalDlg(DlgFile,{
			mode:"open",
			path:path,
			options:{preview:1},
		});
		if(!path){
			return;
		}
		if(item.code==="path"){
			edUserInput.text+=`\$\{\{file:${path}\}\}`;
		}else{
			let text;
			try{
				text=await tabFS.readFile(path,"utf8");
				edUserInput.text+="\n```\n"+text+"\n```\n";
			}catch(err){
			}
		}
		edUserInput.OnInput();
	};
	
	async function arrayBuffer(file){
		if(file.arrayBuffer){
			return file.arrayBuffer();
		}
		return new Promise((onDone,onError)=>{
			let reader=new FileReader();
			reader.onload=function(event) {
				let arrayBuffer = event.target.result;
				onDone(arrayBuffer);
			};
			reader.readAsArrayBuffer(file);
		})
	}
	
	//------------------------------------------------------------------------
	cssVO.useNativeFile=async function(file){
		let buf,byteAry,text;
		if(!file){
			return;
		}
		try{
			buf=await arrayBuffer(file);
			byteAry = new Uint8Array(buf);
			let enc = new TextDecoder("utf-8");
			text=enc.decode(byteAry);
			edUserInput.text+="\n```\n"+text+"\n```\n";
			edUserInput.OnInput();
		}catch(err){
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.chatInput=function(vo){
		let pms;
		self.showFace("input");
		edUserInput.text=vo.text||"";
		if(vo.text){
			txtInputHint.display=false;
		}
		allowEmptyChat=vo.allowEmpty||false;
		edUserInput.focus();
		pms=new Promise((resolve,reject)=>{
			chatCallback=resolve;
		});
		return pms;
	};
	
	//------------------------------------------------------------------------
	cssVO.cancelChatInput=function(){
		let callback;
		callback=chatCallback;
		if(callback){
			chatCallback=null;
			callback(null);
			self.showFace("start");
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.sendChat=async function(){
		let text,callback;
		text=edUserInput.text;
		if(!text && !allowEmptyChat)
			return;
		callback=chatCallback;
		if(callback){
			chatCallback=null;
			callback(text);
			self.showFace("start");
			return;
		}
		self.showFace("wait");
		try{
			await boxChats.execChat(null,text);
		}catch(err){
		}
		edUserInput.text="";
		txtInputHint.display=true;
		self.showFace("input");
		edUserInput.focus();
	};
	
	//------------------------------------------------------------------------
	cssVO.resetChat=async function(){
		await boxChats.resetChat();
		edUserInput.text="";
		txtInputHint.display=true;
		self.showFace("input");
		edUserInput.focus();
	};
	
	//------------------------------------------------------------------------
	cssVO.abortChat=async function(){
		await boxChats.abortChat();
	};
	
	//------------------------------------------------------------------------
	cssVO.close=function(){
		app.closeDlg(self);
	};
	/*}#1HA4CQ2RT1PostCSSVO*/
	return cssVO;
};
/*#{1HA4CQ2RT1ExCodes*/
/*}#1HA4CQ2RT1ExCodes*/


export default DlgAIChat;
export{DlgAIChat};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1HA4CQ2RT0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1HA4CQ2RU0",
//			"attrs": {
//				"device": "Desktop 800x600",
//				"screenW": "800",
//				"screenH": "600",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1HA4CQ2RU1",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1HA4CQ2RU2",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1HA4CQ2RU3",
//			"attrs": {}
//		},
//		"localVars": {
//			"jaxId": "1HA4CQ2RU4",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1HA4CQ2RU5",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1HA4CQ2RU6",
//			"attrs": {
//				"start": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HAJJLQL80",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HAJJNKNF0",
//							"attrs": {}
//						}
//					}
//				},
//				"input": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HA5D430C0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HA5DK4IS0",
//							"attrs": {}
//						}
//					}
//				},
//				"wait": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HA5D4BEQ0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HA5DK4IS1",
//							"attrs": {}
//						}
//					}
//				},
//				"mobile": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HA5I24TH0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HA5I33500",
//							"attrs": {}
//						}
//					}
//				},
//				"desktop": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HA5I2GNK0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HA5I33501",
//							"attrs": {}
//						}
//					}
//				},
//				"allowflie": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HD6J6MJ30",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HD6J6MJ31",
//							"attrs": {}
//						}
//					}
//				},
//				"!allowfile": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HD6J6MJ32",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HD6J6MJ33",
//							"attrs": {}
//						}
//					}
//				},
//				"filemenu": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HD6J774A0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HD6J774A1",
//							"attrs": {}
//						}
//					}
//				},
//				"!filemenu": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HD6J774A2",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HD6J774A3",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1HAAN550J0",
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1HA4CQ2RT1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1HA4CQ2RU7",
//					"attrs": {
//						"type": "hud",
//						"id": "DlgAIChat",
//						"position": "Absolute",
//						"x": "50%",
//						"y": "50%",
//						"w": "90%",
//						"h": "",
//						"anchorH": "Center",
//						"anchorV": "Center",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "[10,10,10,10]",
//						"minW": "320",
//						"minH": "",
//						"maxW": "800",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Flex Y"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1HA4D73LO0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HA4DON240",
//									"attrs": {
//										"type": "box",
//										"id": "BoxBG",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"body\"]",
//										"border": "1",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor[\"lineBodySub\"]",
//										"corner": "6",
//										"shadow": "true",
//										"shadowX": "2",
//										"shadowY": "6",
//										"shadowBlur": "8",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.30]"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HA4DON241",
//									"attrs": {
//										"1HA5I24TH0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HD6HPG9Q0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HD6HPG9Q1",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HA5I24TH0",
//											"faceTagName": "mobile"
//										},
//										"1HA5D4BEQ0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HD6HPG9Q4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HD6HPG9Q5",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HA5D4BEQ0",
//											"faceTagName": "wait"
//										},
//										"1HD6J6MJ30": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HD6J8LO72",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HD6J8LO73",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HD6J6MJ30",
//											"faceTagName": "allowflie"
//										},
//										"1HD6J774A0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HD6J8LO74",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HD6J8LO75",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HD6J774A0",
//											"faceTagName": "filemenu"
//										},
//										"1HD6J6MJ32": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HD6JFSE30",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HD6JFSE31",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HD6J6MJ32",
//											"faceTagName": "!allowfile"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HA4DON242",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HA4DON243",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "true",
//								"container": "false",
//								"nameVal": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1HA4DB93M0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HA4DON244",
//									"attrs": {
//										"type": "text",
//										"id": "TxtTitle",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#cfgColor[\"fontBodySub\"]",
//										"text": "Chat with AI Assistant",
//										"font": "",
//										"fontSize": "#txtSize.big",
//										"bold": "true",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Center",
//										"wrap": "false",
//										"ellipsis": "false",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HA4DON245",
//									"attrs": {
//										"1HA5I24TH0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HD6HPG9Q6",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HD6HPG9Q7",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HA5I24TH0",
//											"faceTagName": "mobile"
//										},
//										"1HA5D4BEQ0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HD6HPG9Q10",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HD6HPG9Q11",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HA5D4BEQ0",
//											"faceTagName": "wait"
//										},
//										"1HD6J6MJ30": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HD6J8LO710",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HD6J8LO711",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HD6J6MJ30",
//											"faceTagName": "allowflie"
//										},
//										"1HD6J774A0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HD6J8LO712",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HD6J8LO713",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HD6J774A0",
//											"faceTagName": "filemenu"
//										},
//										"1HD6J6MJ32": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HD6JFSE32",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HD6JFSE33",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HD6J6MJ32",
//											"faceTagName": "!allowfile"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HA4DON246",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HA4DON247",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1HA4DOVNU0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HA4DQHR20",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxToolBtns",
//										"position": "Absolute",
//										"x": "100%-10",
//										"y": "10",
//										"w": "",
//										"h": "30",
//										"anchorH": "Right",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex X",
//										"subAlign": "End",
//										"itemsAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1HA4E37S70",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1HA4E37S71",
//													"attrs": {
//														"style": "#cfgColor.fontBody",
//														"w": "28",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/trash.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1HA4E37S72",
//													"attrs": {
//														"type": "#null#>BtnIcon(cfgColor.fontBody,28,0,appCfg.sharedAssets+\"/trash.svg\",null)",
//														"id": "BtnClear",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"padding": "2"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HA4E37S73",
//													"attrs": {
//														"1HA5D430C0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HA5DK4IS10",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HA5DK4IS11",
//																	"attrs": {
//																		"enable": {
//																			"type": "bool",
//																			"valText": "true"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HA5D430C0",
//															"faceTagName": "input"
//														},
//														"1HA5D4BEQ0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HA7C1NRD8",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HA7C1NRD9",
//																	"attrs": {
//																		"enable": {
//																			"type": "bool",
//																			"valText": "false"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HA5D4BEQ0",
//															"faceTagName": "wait"
//														},
//														"1HA5I24TH0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HD6HPG9Q12",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HD6HPG9Q13",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HA5I24TH0",
//															"faceTagName": "mobile"
//														},
//														"1HD6J6MJ30": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HD6J8LO718",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HD6J8LO719",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HD6J6MJ30",
//															"faceTagName": "allowflie"
//														},
//														"1HD6J774A0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HD6J8LO720",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HD6J8LO721",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HD6J774A0",
//															"faceTagName": "filemenu"
//														},
//														"1HD6J6MJ32": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HD6JFSE34",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HD6JFSE35",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HD6J6MJ32",
//															"faceTagName": "!allowfile"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HA4E37S74",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1HA6N7GI00",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1HA6N7NDE0",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1HA4E37S75",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1HA4E37S76",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1HA4DVAJM0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1HA4DVAJM1",
//													"attrs": {
//														"style": "#cfgColor.fontBody",
//														"w": "28",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/close.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1HA4DVAJM2",
//													"attrs": {
//														"type": "#null#>BtnIcon(cfgColor.fontBody,28,0,appCfg.sharedAssets+\"/close.svg\",null)",
//														"id": "BtnClose",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"padding": "2"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HA4DVAJM3",
//													"attrs": {
//														"1HA5D430C0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HA5DK4IS12",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HA5DK4IS13",
//																	"attrs": {
//																		"enable": {
//																			"type": "bool",
//																			"valText": "true"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HA5D430C0",
//															"faceTagName": "input"
//														},
//														"1HA5D4BEQ0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HA7C1NRD10",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HA7C1NRD11",
//																	"attrs": {
//																		"enable": {
//																			"type": "bool",
//																			"valText": "false"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HA5D4BEQ0",
//															"faceTagName": "wait"
//														},
//														"1HA5I24TH0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HD6HPG9Q14",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HD6HPG9Q15",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HA5I24TH0",
//															"faceTagName": "mobile"
//														},
//														"1HD6J6MJ30": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HD6J8LO726",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HD6J8LO727",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HD6J6MJ30",
//															"faceTagName": "allowflie"
//														},
//														"1HD6J774A0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HD6J8LO728",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HD6J8LO729",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HD6J774A0",
//															"faceTagName": "filemenu"
//														},
//														"1HD6J6MJ32": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HD6JFSE36",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HD6JFSE37",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HD6J6MJ32",
//															"faceTagName": "!allowfile"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HA4DVAJM4",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1HA5KCQGD0",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1HA5KDF120",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1HA4DVAJM5",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1HA4DVAJM6",
//													"attrs": {}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1HA4DQHR21",
//									"attrs": {
//										"1HA5I24TH0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HD6HPG9Q16",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HD6HPG9Q17",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HA5I24TH0",
//											"faceTagName": "mobile"
//										},
//										"1HA5D4BEQ0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HD6HPG9Q20",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HD6HPG9Q21",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HA5D4BEQ0",
//											"faceTagName": "wait"
//										},
//										"1HD6J6MJ30": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HD6J8LO734",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HD6J8LO735",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HD6J6MJ30",
//											"faceTagName": "allowflie"
//										},
//										"1HD6J774A0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HD6J8LO736",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HD6J8LO737",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HD6J774A0",
//											"faceTagName": "filemenu"
//										},
//										"1HD6J6MJ32": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HD6JFSE38",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HD6JFSE39",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HD6J6MJ32",
//											"faceTagName": "!allowfile"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HA4DQHR22",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HA4DQHR23",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear1HA0EN6720",
//							"jaxId": "1HA51LIVU0",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1HA53D8VE0",
//									"attrs": {}
//								},
//								"properties": {
//									"jaxId": "1HA53D8VE1",
//									"attrs": {
//										"type": "#null#>BoxAIChat()",
//										"id": "BoxChats",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"display": "On",
//										"face": "",
//										"w": "100%",
//										"h": "",
//										"minH": "20",
//										"maxH": "500",
//										"clip": "Auto Scroll Y"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HA53D8VE2",
//									"attrs": {
//										"1HA5I24TH0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HD6HPG9Q22",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HD6HPG9Q23",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HA5I24TH0",
//											"faceTagName": "mobile"
//										},
//										"1HA5D4BEQ0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HD6HPG9Q26",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HD6HPG9Q27",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HA5D4BEQ0",
//											"faceTagName": "wait"
//										},
//										"1HD6J6MJ30": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HD6J8LO742",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HD6J8LO743",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HD6J6MJ30",
//											"faceTagName": "allowflie"
//										},
//										"1HD6J774A0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HD6J8LO744",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HD6J8LO745",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HD6J774A0",
//											"faceTagName": "filemenu"
//										},
//										"1HD6J6MJ32": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HD6JFSE310",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HD6JFSE311",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HD6J6MJ32",
//											"faceTagName": "!allowfile"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HA53D8VE3",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HA53D8VE4",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true",
//								"containerSlots": {
//									"jaxId": "1HA53D8VE5",
//									"attrs": {}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1HA539OJ20",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HA53D8VE6",
//									"attrs": {
//										"type": "box",
//										"id": "BoxUser",
//										"position": "relative",
//										"x": "50%",
//										"y": "0",
//										"w": "100%-50",
//										"h": "",
//										"anchorH": "Center",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "30",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "[255,255,255,1.00]",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "3",
//										"shadow": "true",
//										"shadowX": "0",
//										"shadowY": "1",
//										"shadowBlur": "4",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.30]",
//										"contentLayout": "Flex Y"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1HA5C6UEO0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HA5CQ5QV0",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxInput",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "[5,10,5,10]",
//														"minW": "",
//														"minH": "20",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex X",
//														"traceSize": "true",
//														"itemsAlign": "Center"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1HD6JB8LG0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HD6JB8LG1",
//																	"attrs": {
//																		"type": "hud",
//																		"id": "BoxFileBtnsFrame",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "20",
//																		"h": "20",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "On",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[0,5,0,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "hud",
//																			"jaxId": "1HD6JB8LG2",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HD6JB8LG3",
//																					"attrs": {
//																						"type": "hud",
//																						"id": "BoxButtons",
//																						"position": "Absolute",
//																						"x": "0",
//																						"y": "20",
//																						"w": "20",
//																						"h": "40",
//																						"anchorH": "Left",
//																						"anchorV": "Bottom",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": ""
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": [
//																						{
//																							"type": "hudobj",
//																							"def": "box",
//																							"jaxId": "1HD6JB8LG4",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HD6JB8LG5",
//																									"attrs": {
//																										"type": "box",
//																										"id": "",
//																										"position": "Absolute",
//																										"x": "-3",
//																										"y": "-3",
//																										"w": "100%+6",
//																										"h": "100%+6",
//																										"anchorH": "Left",
//																										"anchorV": "Top",
//																										"autoLayout": "false",
//																										"display": "Off",
//																										"clip": "Off",
//																										"uiEvent": "On",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "",
//																										"zIndex": "0",
//																										"margin": "",
//																										"padding": "",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": "",
//																										"background": "#cfgColor[\"body\"]",
//																										"border": "1",
//																										"borderStyle": "Solid",
//																										"borderColor": "#cfgColor[\"fontBodyLit\"]",
//																										"corner": "3",
//																										"shadow": "true",
//																										"shadowX": "0",
//																										"shadowY": "2",
//																										"shadowBlur": "5",
//																										"shadowSpread": "0",
//																										"shadowColor": "[0,0,0,0.30]"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1HD6JB8LG6",
//																									"attrs": {
//																										"1HD6J774A0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HD6JB8LH0",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HD6JB8LH1",
//																													"attrs": {
//																														"display": {
//																															"type": "choice",
//																															"valText": "On"
//																														}
//																													}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HD6J774A0",
//																											"faceTagName": "filemenu"
//																										},
//																										"1HD6J774A2": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HD6JB8LH2",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HD6JB8LH3",
//																													"attrs": {
//																														"display": {
//																															"type": "choice",
//																															"valText": "Off"
//																														}
//																													}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HD6J774A2",
//																											"faceTagName": "!filemenu"
//																										},
//																										"1HA5D430C0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HD6JB8LH6",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HD6JB8LH7",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HA5D430C0",
//																											"faceTagName": "input"
//																										},
//																										"1HA5D4BEQ0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HD6JB8LH8",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HD6JB8LH9",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HA5D4BEQ0",
//																											"faceTagName": "wait"
//																										},
//																										"1HD6J6MJ30": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HD6JC7O30",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HD6JC7O31",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HD6J6MJ30",
//																											"faceTagName": "allowflie"
//																										},
//																										"1HD6J6MJ32": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HD6JFSE312",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HD6JFSE313",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HD6J6MJ32",
//																											"faceTagName": "!allowfile"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1HD6JB8LH10",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1HD6JB8LH11",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "true",
//																								"nameVal": "false"
//																							}
//																						},
//																						{
//																							"type": "hudobj",
//																							"def": "Gear/@StdUI/ui/BtnIcon.js",
//																							"jaxId": "1HD6JB8LH12",
//																							"attrs": {
//																								"createArgs": {
//																									"jaxId": "1HD6JB8LH13",
//																									"attrs": {
//																										"style": "\"front\"",
//																										"w": "20",
//																										"h": "0",
//																										"icon": "#appCfg.sharedAssets+\"/folder.svg\"",
//																										"colorBG": "null"
//																									}
//																								},
//																								"properties": {
//																									"jaxId": "1HD6JB8LH14",
//																									"attrs": {
//																										"type": "#null#>BtnIcon(\"front\",20,0,appCfg.sharedAssets+\"/folder.svg\",null)",
//																										"id": "BtnLocalFile",
//																										"position": "Absolute",
//																										"x": "0",
//																										"y": "20",
//																										"display": "On",
//																										"face": "",
//																										"margin": "[0,5,0,0]",
//																										"padding": "0",
//																										"anchorV": "Top",
//																										"autoLayout": "true"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1HD6JB8LH15",
//																									"attrs": {
//																										"1HA5D430C0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HD6JB8LH16",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HD6JB8LH17",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HA5D430C0",
//																											"faceTagName": "input"
//																										},
//																										"1HD6J774A0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HD6JB8LH18",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HD6JB8LH19",
//																													"attrs": {
//																														"display": {
//																															"type": "choice",
//																															"valText": "On"
//																														}
//																													}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HD6J774A0",
//																											"faceTagName": "filemenu"
//																										},
//																										"1HA5D4BEQ0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HD6JB8LH22",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HD6JB8LH23",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HA5D4BEQ0",
//																											"faceTagName": "wait"
//																										},
//																										"1HD6J6MJ30": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HD6JC7O32",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HD6JC7O33",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HD6J6MJ30",
//																											"faceTagName": "allowflie"
//																										},
//																										"1HD6J6MJ32": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HD6JFSE314",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HD6JFSE315",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HD6J6MJ32",
//																											"faceTagName": "!allowfile"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1HD6JB8LH26",
//																									"attrs": {
//																										"OnClick": {
//																											"type": "fixedFunc",
//																											"jaxId": "1HD6JB8LI0",
//																											"attrs": {
//																												"callArgs": {
//																													"jaxId": "1HD6JB8LI1",
//																													"attrs": {
//																														"event": ""
//																													}
//																												},
//																												"seg": ""
//																											}
//																										}
//																									}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1HD6JB8LI2",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "true",
//																								"containerSlots": {
//																									"jaxId": "1HD6JB8LI3",
//																									"attrs": {}
//																								}
//																							}
//																						},
//																						{
//																							"type": "hudobj",
//																							"def": "Gear/@StdUI/ui/BtnIcon.js",
//																							"jaxId": "1HD6JB8LI4",
//																							"attrs": {
//																								"createArgs": {
//																									"jaxId": "1HD6JB8LI5",
//																									"attrs": {
//																										"style": "\"front\"",
//																										"w": "20",
//																										"h": "0",
//																										"icon": "#appCfg.sharedAssets+\"/upload.svg\"",
//																										"colorBG": "null"
//																									}
//																								},
//																								"properties": {
//																									"jaxId": "1HD6JB8LI6",
//																									"attrs": {
//																										"type": "#null#>BtnIcon(\"front\",20,0,appCfg.sharedAssets+\"/upload.svg\",null)",
//																										"id": "BtnNativeFile",
//																										"position": "Absolute",
//																										"x": "0",
//																										"y": "0",
//																										"display": "Off",
//																										"face": "",
//																										"margin": "[0,5,0,0]",
//																										"padding": "0",
//																										"anchorV": "Top",
//																										"autoLayout": "true"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1HD6JB8LI7",
//																									"attrs": {
//																										"1HA5D430C0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HD6JB8LI8",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HD6JB8LI9",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HA5D430C0",
//																											"faceTagName": "input"
//																										},
//																										"1HD6J774A0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HD6JB8LI10",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HD6JB8LI11",
//																													"attrs": {
//																														"display": {
//																															"type": "choice",
//																															"valText": "On"
//																														}
//																													}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HD6J774A0",
//																											"faceTagName": "filemenu"
//																										},
//																										"1HD6J774A2": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HD6JB8LI12",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HD6JB8LI13",
//																													"attrs": {
//																														"display": {
//																															"type": "choice",
//																															"valText": "Off"
//																														}
//																													}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HD6J774A2",
//																											"faceTagName": "!filemenu"
//																										},
//																										"1HA5D4BEQ0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HD6JB8LI16",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HD6JB8LI17",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HA5D4BEQ0",
//																											"faceTagName": "wait"
//																										},
//																										"1HD6J6MJ30": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HD6JC7O34",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HD6JC7O35",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HD6J6MJ30",
//																											"faceTagName": "allowflie"
//																										},
//																										"1HD6J6MJ32": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HD6JFSE316",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HD6JFSE317",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HD6J6MJ32",
//																											"faceTagName": "!allowfile"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1HD6JB8LI18",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1HD6JB8LI19",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "true",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "true",
//																								"containerSlots": {
//																									"jaxId": "1HD6JB8LI20",
//																									"attrs": {}
//																								}
//																							}
//																						}
//																					]
//																				},
//																				"faces": {
//																					"jaxId": "1HD6JB8LI21",
//																					"attrs": {
//																						"1HD6J774A0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HD6JB8LI22",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HD6JB8LI23",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HD6J774A0",
//																							"faceTagName": "filemenu"
//																						},
//																						"1HA5D430C0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HD6JB8LI26",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HD6JB8LI27",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HA5D430C0",
//																							"faceTagName": "input"
//																						},
//																						"1HA5D4BEQ0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HD6JB8LI28",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HD6JB8LI29",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HA5D4BEQ0",
//																							"faceTagName": "wait"
//																						},
//																						"1HD6J6MJ30": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HD6JC7O36",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HD6JC7O37",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HD6J6MJ30",
//																							"faceTagName": "allowflie"
//																						},
//																						"1HD6J6MJ32": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HD6JFSE318",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HD6JFSE319",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HD6J6MJ32",
//																							"faceTagName": "!allowfile"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1HD6JB8LI32",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1HD6JB8LI33",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "false",
//																				"exposeContainer": "false"
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"jaxId": "1HD6JB8LI34",
//																	"attrs": {
//																		"1HD6J774A2": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HD6JB8LI35",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HD6JB8LI36",
//																					"attrs": {
//																						"clip": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HD6J774A2",
//																			"faceTagName": "!filemenu"
//																		},
//																		"1HD6J774A0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HD6JB8LI37",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HD6JB8LI38",
//																					"attrs": {
//																						"clip": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HD6J774A0",
//																			"faceTagName": "filemenu"
//																		},
//																		"1HD6J6MJ32": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HD6JB8LI41",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HD6JB8LI42",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HD6J6MJ32",
//																			"faceTagName": "!allowfile"
//																		},
//																		"1HA5D430C0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HD6JB8LI43",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HD6JB8LI44",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HA5D430C0",
//																			"faceTagName": "input"
//																		},
//																		"1HA5D4BEQ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HD6JB8LJ0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HD6JB8LJ1",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HA5D4BEQ0",
//																			"faceTagName": "wait"
//																		},
//																		"1HD6J6MJ30": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HD6JC7O40",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HD6JC7O41",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HD6J6MJ30",
//																			"faceTagName": "allowflie"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HD6JB8LJ2",
//																	"attrs": {
//																		"OnMouseInOut": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HD6JB8LJ3",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1HD6JB8LJ4",
//																					"attrs": {
//																						"isIn": "",
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1HD6JB8LJ5",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false",
//																"exposeContainer": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "memo",
//															"jaxId": "1HA5CBU550",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HA5CQ5QV1",
//																	"attrs": {
//																		"type": "memo",
//																		"id": "EdUserInput",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%-100",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "20",
//																		"maxW": "",
//																		"maxH": "200",
//																		"face": "",
//																		"styleClass": "",
//																		"text": "",
//																		"color": "#cfgColor[\"fontBody\"]",
//																		"bgColor": "#cfgColor[\"body\"]",
//																		"font": "",
//																		"fontSize": "#txtSize.mid",
//																		"outline": "0",
//																		"border": "[0,0,1,0]",
//																		"borderStyle": "Solid",
//																		"borderColor": "[0,0,0,0.5]",
//																		"corner": "0",
//																		"readOnly": "false",
//																		"selectOnFocus": "true",
//																		"spellCheck": "true",
//																		"flex": "true"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HA5CQ5QV2",
//																	"attrs": {
//																		"1HA5I24TH0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HD6HPG9Q34",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HD6HPG9Q35",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HA5I24TH0",
//																			"faceTagName": "mobile"
//																		},
//																		"1HA5D4BEQ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HD6HPG9Q38",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HD6HPG9Q39",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HA5D4BEQ0",
//																			"faceTagName": "wait"
//																		},
//																		"1HD6J6MJ30": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HD6J8LO758",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HD6J8LO759",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HD6J6MJ30",
//																			"faceTagName": "allowflie"
//																		},
//																		"1HD6J774A0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HD6J8LO760",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HD6J8LO761",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HD6J774A0",
//																			"faceTagName": "filemenu"
//																		},
//																		"1HD6J6MJ32": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HD6JFSE320",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HD6JFSE321",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HD6J6MJ32",
//																			"faceTagName": "!allowfile"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HA5CQ5QV3",
//																	"attrs": {
//																		"OnInput": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HA5G1NT60",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1HA5G2MPD0",
//																					"attrs": {}
//																				},
//																				"seg": ""
//																			}
//																		},
//																		"OnKeyDown": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HA5G46350",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1HA5G54UK0",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1HA5CQ5QV4",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1HA5CFVOF0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1HA5CQ5QV5",
//																	"attrs": {
//																		"style": "\"front\"",
//																		"w": "30",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/send.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1HA5CQ5QV6",
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"front\",30,0,appCfg.sharedAssets+\"/send.svg\",null)",
//																		"id": "BtnSend",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"margin": "[0,0,0,10]",
//																		"padding": "2",
//																		"anchorV": "Top",
//																		"autoLayout": "true"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HA5CQ5QV7",
//																	"attrs": {
//																		"1HA5I24TH0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HD6HPG9Q40",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HD6HPG9Q41",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HA5I24TH0",
//																			"faceTagName": "mobile"
//																		},
//																		"1HA5D4BEQ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HD6HPG9Q44",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HD6HPG9Q45",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HA5D4BEQ0",
//																			"faceTagName": "wait"
//																		},
//																		"1HD6J6MJ30": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HD6J8LO766",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HD6J8LO767",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HD6J6MJ30",
//																			"faceTagName": "allowflie"
//																		},
//																		"1HD6J774A0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HD6J8LO768",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HD6J8LO769",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HD6J774A0",
//																			"faceTagName": "filemenu"
//																		},
//																		"1HD6J6MJ32": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HD6JFSE322",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HD6JFSE323",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HD6J6MJ32",
//																			"faceTagName": "!allowfile"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HA5CQ5QV8",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HA5G7T3V0",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1HA5G82OM0",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1HA5CQ5QV9",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1HA5CQ5QV10",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1HA5CMCID0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HA5CQ5QV11",
//																	"attrs": {
//																		"type": "text",
//																		"id": "TxtInputHint",
//																		"position": "Absolute",
//																		"x": "40",
//																		"y": "0",
//																		"w": "100",
//																		"h": "100%",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "Tree Off",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontBodyLit\"]",
//																		"text": "Input chat message...",
//																		"font": "",
//																		"fontSize": "#txtSize.mid",
//																		"bold": "false",
//																		"italic": "true",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Center",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HA5CQ5QV12",
//																	"attrs": {
//																		"1HA5I24TH0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HD6HPG9Q46",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HD6HPG9Q47",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HA5I24TH0",
//																			"faceTagName": "mobile"
//																		},
//																		"1HA5D4BEQ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HD6HPG9Q50",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HD6HPG9Q51",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HA5D4BEQ0",
//																			"faceTagName": "wait"
//																		},
//																		"1HD6J6MJ30": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HD6J8LO774",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HD6J8LO775",
//																					"attrs": {
//																						"x": {
//																							"type": "length",
//																							"valText": "40"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HD6J6MJ30",
//																			"faceTagName": "allowflie"
//																		},
//																		"1HD6J774A0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HD6J8LO776",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HD6J8LO777",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HD6J774A0",
//																			"faceTagName": "filemenu"
//																		},
//																		"1HD6J6MJ32": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HD6JE56T12",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HD6JE56T13",
//																					"attrs": {
//																						"x": {
//																							"type": "length",
//																							"valText": "18"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HD6J6MJ32",
//																			"faceTagName": "!allowfile"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HA5CQ5QV13",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HA5CQ5QV14",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true"
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1HA5CQ5QV15",
//													"attrs": {
//														"1HA5D430C0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HA5DK4IS24",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HA5DK4IS25",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HA5D430C0",
//															"faceTagName": "input"
//														},
//														"1HA5D4BEQ0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HA5DK4IS26",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HA5DK4IS27",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HA5D4BEQ0",
//															"faceTagName": "wait"
//														},
//														"1HAJJLQL80": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAJJNKNG16",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAJJNKNG17",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAJJLQL80",
//															"faceTagName": "start"
//														},
//														"1HA5I24TH0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HD6HPG9Q52",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HD6HPG9Q53",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HA5I24TH0",
//															"faceTagName": "mobile"
//														},
//														"1HD6J6MJ30": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HD6J8LO782",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HD6J8LO783",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HD6J6MJ30",
//															"faceTagName": "allowflie"
//														},
//														"1HD6J774A0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HD6J8LO784",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HD6J8LO785",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HD6J774A0",
//															"faceTagName": "filemenu"
//														},
//														"1HD6J6MJ32": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HD6JFSE40",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HD6JFSE41",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HD6J6MJ32",
//															"faceTagName": "!allowfile"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HA5CQ5QV16",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HA5CQ5QV17",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1HA5CRLRB0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HA5D3IKV0",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxWait",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "50",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "Off",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": ""
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1HA5CSM2L0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HA5D3IKV1",
//																	"attrs": {
//																		"type": "text",
//																		"id": "",
//																		"position": "Absolute",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "20",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontBodyLit\"]",
//																		"text": "AI is thinking...",
//																		"font": "",
//																		"fontSize": "#txtSize.smallPlus",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Center",
//																		"alignV": "Center",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HA5D3IKV2",
//																	"attrs": {
//																		"1HA5I24TH0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HD6HPG9Q54",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HD6HPG9Q55",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HA5I24TH0",
//																			"faceTagName": "mobile"
//																		},
//																		"1HA5D4BEQ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HD6HPG9Q58",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HD6HPG9Q59",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HA5D4BEQ0",
//																			"faceTagName": "wait"
//																		},
//																		"1HD6J6MJ30": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HD6J8LO790",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HD6J8LO791",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HD6J6MJ30",
//																			"faceTagName": "allowflie"
//																		},
//																		"1HD6J774A0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HD6J8LO792",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HD6J8LO793",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HD6J774A0",
//																			"faceTagName": "filemenu"
//																		},
//																		"1HD6J6MJ32": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HD6JFSE42",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HD6JFSE43",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HD6J6MJ32",
//																			"faceTagName": "!allowfile"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HA5D3IKV3",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HA5D3IKV4",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnText.js",
//															"jaxId": "1HA5CV4FU0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1HA5D3IKV5",
//																	"attrs": {
//																		"style": "primary",
//																		"w": "100",
//																		"h": "25",
//																		"text": "Abort",
//																		"outlined": "false",
//																		"icon": ""
//																	}
//																},
//																"properties": {
//																	"jaxId": "1HA5D3IKV6",
//																	"attrs": {
//																		"type": "#null#>BtnText(\"primary\",100,25,\"Abort\",false,\"\")",
//																		"id": "BtnAbort",
//																		"position": "Absolute",
//																		"x": "50%",
//																		"y": "20",
//																		"display": "On",
//																		"face": "",
//																		"anchorH": "Center"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HA5D3IKV7",
//																	"attrs": {
//																		"1HA5I24TH0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HD6HPG9Q60",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HD6HPG9Q61",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HA5I24TH0",
//																			"faceTagName": "mobile"
//																		},
//																		"1HA5D4BEQ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HD6HPG9Q64",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HD6HPG9Q65",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HA5D4BEQ0",
//																			"faceTagName": "wait"
//																		},
//																		"1HD6J6MJ30": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HD6J8LO798",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HD6J8LO799",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HD6J6MJ30",
//																			"faceTagName": "allowflie"
//																		},
//																		"1HD6J774A0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HD6J8LO7100",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HD6J8LO7101",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HD6J774A0",
//																			"faceTagName": "filemenu"
//																		},
//																		"1HD6J6MJ32": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HD6JFSE44",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HD6JFSE45",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HD6J6MJ32",
//																			"faceTagName": "!allowfile"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HA5D3IKV8",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HA7BN1640",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1HA7BOS360",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1HA5D3IKV9",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1HA5D3IKV10",
//																	"attrs": {
//																		"Slot1H2F6U36O0": {
//																			"jaxId": "1HA5D3IKV11",
//																			"attrs": {
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"container": "true"
//																			}
//																		}
//																	}
//																}
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1HA5D3IKV12",
//													"attrs": {
//														"1HA5D430C0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HA5DK4IS32",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HA5DK4IS33",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HA5D430C0",
//															"faceTagName": "input"
//														},
//														"1HA5D4BEQ0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HA5DK4IS34",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HA5DK4IS35",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HA5D4BEQ0",
//															"faceTagName": "wait"
//														},
//														"1HA5I24TH0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HD6HPG9Q66",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HD6HPG9Q67",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HA5I24TH0",
//															"faceTagName": "mobile"
//														},
//														"1HD6J6MJ30": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HD6J8LO7106",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HD6J8LO7107",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HD6J6MJ30",
//															"faceTagName": "allowflie"
//														},
//														"1HD6J774A0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HD6J8LO7108",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HD6J8LO7109",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HD6J774A0",
//															"faceTagName": "filemenu"
//														},
//														"1HD6J6MJ32": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HD6JFSE46",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HD6JFSE47",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HD6J6MJ32",
//															"faceTagName": "!allowfile"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HA5D3IKV13",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HA5D3IKV14",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1HA53D8VE7",
//									"attrs": {
//										"1HA5I24TH0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HD6HPG9Q68",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HD6HPG9Q69",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HA5I24TH0",
//											"faceTagName": "mobile"
//										},
//										"1HA5D4BEQ0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HD6HPG9Q72",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HD6HPG9Q73",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HA5D4BEQ0",
//											"faceTagName": "wait"
//										},
//										"1HD6J6MJ30": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HD6J8LO7114",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HD6J8LO7115",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HD6J6MJ30",
//											"faceTagName": "allowflie"
//										},
//										"1HD6J774A0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HD6J8LO7116",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HD6J8LO7117",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HD6J774A0",
//											"faceTagName": "filemenu"
//										},
//										"1HD6J6MJ32": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HD6JFSE48",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HD6JFSE49",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HD6J6MJ32",
//											"faceTagName": "!allowfile"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HA53D8VE8",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HA53D8VE9",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1HA4CQ2RU8",
//					"attrs": {
//						"1HA5I24TH0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HD6HPG9Q74",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HD6HPG9Q75",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HA5I24TH0",
//							"faceTagName": "mobile"
//						},
//						"1HA5D4BEQ0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HD6HPG9Q78",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HD6HPG9Q79",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HA5D4BEQ0",
//							"faceTagName": "wait"
//						},
//						"1HD6J6MJ30": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HD6J8LO7122",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HD6J8LO7123",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HD6J6MJ30",
//							"faceTagName": "allowflie"
//						},
//						"1HD6J774A0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HD6J8LO7124",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HD6J8LO7125",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HD6J774A0",
//							"faceTagName": "filemenu"
//						},
//						"1HD6J6MJ32": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HD6JFSE410",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HD6JFSE411",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HD6J6MJ32",
//							"faceTagName": "!allowfile"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1HA4CQ2RU9",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1HA4CQ2RU10",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "true",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1HA4CQ2RU11",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}