//Auto genterated by Cody
import {$P,VFACT,callAfter} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
import {UIChat} from "./UIChat.js";
/*#{1GGJKM84D0StartDoc*/
import {tabNT} from "/@tabos/tabos_nt.js";
import {tabOS,tabFS} from "/@tabos";
import pathLib from "/@path";
import {DlgFile} from "/@homekit/ui/DlgFile.js";
import {DlgMenu} from "/@StdUI/ui/DlgMenu.js";
import {DlgAddShortCut} from "./DlgAddShortCut.js";
import {DlgAIChatHome} from "./DlgAIChatHome.js";
/*}#1GGJKM84D0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let MainUI=function(app,appFrame){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let boxHeader,btnMenu,chatUI;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let isMobile=true;
	
	/*#{1GGJKM84D1LocalVals*/
	app.openDocPath=localStorage.getItem("LastAIChatPath")||"/";
	let session=null;
	isMobile=app.w<500?true:false;
	/*}#1GGJKM84D1LocalVals*/
	
	/*#{1GGJKM84D1PreState*/
	/*}#1GGJKM84D1PreState*/
	state={
		"counter":0,"botName":"Open AI chat to start session","chatBot":null,"userTokens":-1,"userGas":-1,
		/*#{1GGJKM84D6ExState*/
		/*}#1GGJKM84D6ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1GGJKM84D1PostState*/
	/*}#1GGJKM84D1PostState*/
	cssVO={
		"hash":"1GGJKM84D1",nameHost:true,
		"type":"view","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
		children:[
			{
				"hash":"1HB40BN780",
				"type":"box","id":"BoxHeader","x":0,"y":0,"w":"100%","h":36,"padding":[0,10,0,10],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["body"],
				"border":[0,0,1,0],"borderColor":cfgColor["fontBodyLit"],"shadow":true,"shadowX":0,"shadowY":1,"shadowBlur":5,"shadowColor":[0,0,0,0.3],"contentLayout":"flex-x",
				"itemsAlign":1,
				children:[
					{
						"hash":"1HB40IQQK0",
						"type":BtnIcon("front",26,0,appCfg.sharedAssets+"/folder.svg",null),"id":"BtnOpen","position":"relative","x":0,"y":0,"display":$P(()=>(!state.chatBot),state),
						"margin":[0,3,0,0],
						"tip":"Open AI Chat",
						"OnClick":function(event){
							/*#{1HB4258150FunctionBody*/
							self.openChat();
							/*}#1HB4258150FunctionBody*/
						},
					},
					{
						"hash":"1HB40LUV60",
						"type":"text","id":"TxtBotName","position":"relative","x":0,"y":0,"w":"","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
						"text":$P(()=>(state.botName),state),"fontSize":txtSize.mid,"fontWeight":"bold","fontStyle":"normal","textDecoration":"","ellipsis":true,"flex":true,
					},
					{
						"hash":"1HB40SU890",
						"type":BtnIcon("front",26,0,appCfg.sharedAssets+"/menu.svg",null),"id":"BtnMenu","position":"relative","x":0,"y":0,"enable":$P(()=>(!!state.chatBot),state),
						"OnClick":function(event){
							/*#{1HB4BUUKC0FunctionBody*/
							self.showMenu();
							/*}#1HB4BUUKC0FunctionBody*/
						},
					}
				],
			},
			{
				"hash":"1HB41056P0",
				"type":UIChat({"bubble":!!isMobile,"ai":{"blkColor":[0,0,0,0],"bgColor":cfgColor["primary"],"icon":appCfg.sharedAssets+"/faces.svg","pic":"","textColor":isMobile?cfgColor["fontSecondary"]:cfgColor["fontBody"],"iconColor":cfgColor["fontSuccess"],"side":"left"},"user":{"blkColor":[0,0,0,0],"bgColor":cfgColor["secondary"],"icon":appCfg.sharedAssets+"/user.svg","pic":"","textColor":isMobile?cfgColor["fontPrimary"]:cfgColor["fontBody"],"iconColor":cfgColor["fontPrimary"],"side":"right"},"wait":{"blkColor":[0,0,0,0],"bgColor":cfgColor["secondary"],"icon":appCfg.sharedAssets+"/faces.svg","pic":"","textColor":isMobile?cfgColor["fontSecondarySub"]:cfgColor["fontBody"],"iconColor":cfgColor["fontSecondary"],"side":"left"},"event":{"blkColor":[0,0,0,0],"bgColor":cfgColor["warning"],"icon":appCfg.sharedAssets+"/event.svg","pic":"","textColor":isMobile?cfgColor["fontWarning"]:cfgColor["fontBody"],"iconColor":cfgColor["fontWarning"],"side":"left"},"error":{"blkColor":[0,0,0,0],"bgColor":cfgColor["error"],"icon":appCfg.sharedAssets+"/fat_right.svg","pic":"","textColor":isMobile?cfgColor["fontError"]:[155,0,0,1.00],"iconColor":cfgColor["fontError"],"side":"left"},"ask":{"blkColor":[0,0,0,0],"bgColor":cfgColor["success"],"icon":appCfg.sharedAssets+"/help.svg","pic":"","textColor":cfgColor["fontBody"],"iconColor":cfgColor["fontSuccess"],"side":"left"}}),
				"id":"ChatUI","x":0,"y":36,"h":">calc(100% - 56px)",
			},
			{
				"hash":"1HB441PR20",
				"type":"box","id":"BoxFooter","x":0,"y":">calc(100% - 20px)","w":"100%","h":20,"padding":[0,5,0,5],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"background":cfgColor["secondary"],"contentLayout":"flex-xr","itemsAlign":1,
				children:[
					{
						"hash":"1HB445K7D0",
						"type":"hud","position":"relative","x":0,"y":0,"w":"","h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-xr","itemsAlign":1,
						children:[
							{
								"hash":"1HB445K7E0",
								"type":BtnIcon(cfgColor.fontSecondary,16,0,appCfg.sharedAssets+"/gas.svg",null),"position":"relative","x":0,"y":0,
								"tip":"Account gas left",
							},
							{
								"hash":"1HB445K7F0",
								"type":"text","id":"TxtGas","position":"relative","x":0,"y":0,"w":"","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontSecondary"],
								"text":$P(()=>(state.userGas>=0?state.userGas:"- - -"),state),"fontSize":txtSize.smallPlus,"fontWeight":"bold","fontStyle":"normal","textDecoration":"",
							},
							{
								"hash":"1HB445K7F9",
								"type":BtnIcon(cfgColor.fontSecondary,16,0,appCfg.sharedAssets+"/token.svg",null),"position":"relative","x":0,"y":0,"scale":[-1,1],"anchorX":2,
								"margin":[0,10,0,0],
								"tip":"Account tokens left",
							},
							{
								"hash":"1HB445K7G0",
								"type":"text","id":"TxtTokens","position":"relative","x":0,"y":0,"w":"","h":"","margin":[0,3,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
								"color":cfgColor["fontSecondary"],"text":$P(()=>(state.userTokens>=0?state.userTokens:"- - -"),state),"fontSize":txtSize.smallPlus,"fontWeight":"bold",
								"fontStyle":"normal","textDecoration":"",
							}
						],
					}
				],
			}
		],
		/*#{1GGJKM84D1ExtraCSS*/
		/*}#1GGJKM84D1ExtraCSS*/
		faces:{
			"start":{
				"/":function(){
					state["botName"]="Open AI chat to start session";
				}
			},"init":{
				"/":function(){
					state["botName"]="Loading AI Chat...";
				}
			},"ready":{
			},"wait":{
			}
		},
		OnCreate:function(){
			self=this;
			boxHeader=self.BoxHeader;btnMenu=self.BtnMenu;chatUI=self.ChatUI;
			/*#{1GGJKM84D1Create*/
			let params,chatJSON;
			self.showFace("start");
			self.checkCy();
			app.on("SessionReady",(_session)=>{
				session=_session;
				state.chatBot=session.entryBot;
				state.botName=state.chatBot.name;
				self.showFace("ready");
			});
			app.on("SessionLoadError",(reason)=>{
				self.showFace("start");
			});
			app.on("CheckCY",(_session)=>{
				self.checkCy("ready");
			});
			params=VFACT.appParams;
			if(params){
				chatJSON=params.json;
				if(chatJSON){
					try{
						chatJSON=JSON.parse(chatJSON);
					}catch(err){
						chatJSON=null;
					}
				}
				self.openChatFile(params.chat||params.file,chatJSON);
			}
			/*}#1GGJKM84D1Create*/
		},
		/*#{1GGJKM84D1EndCSS*/
		/*}#1GGJKM84D1EndCSS*/
	};
	/*#{1GGJKM84D1PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.openChat=async function(){
		let filePath;
		filePath=await app.modalDlg(DlgFile,{
			mode:"open",
			path:app.openDocPath,
			options:{
				preview:1,
				filter:"*.aichat;*.js",
			}
		});
		if(filePath){
			self.openChatFile(filePath);
			app.openDocPath=pathLib.dirname(filePath);
			localStorage.setItem("LastAIChatPath",app.openDocPath);
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.openChatFile=async function(path,json){
		let ext;
		//Convert file system path to URL:
		self.showFace("init");
		ext=pathLib.extname(path);
		if(ext===".js"){
			if(path[0]==="/" && path[1]!=="/" && path[1]!=="~"){
				path="/~"+path;
			}
			if(path[0]!=="/" && (!path.startsWith("http://")) &&(!path.startsWith("https://"))){
				path=pathLib.join(app.appDir,path);
			}
			await chatUI.resetChat({url:path});
		}else if(ext===".aichat"){
			if(path[0]==="/" && path[1]!=="/" && path[1]!=="@" && path[1]!=="~"){
				path="/~"+path;
			}
			if(path[0]!=="/" && (!path.startsWith("http://")) &&(!path.startsWith("https://"))){
				path=pathLib.join(app.appDir,path);
			}
			await chatUI.resetChat({bot:path,json:json});
		}else if(ext===".aidebug"){
			let vo;
			try{
				vo=await tabFS.readFile(path,"utf8");
				vo=JSON.parse(vo);
			}catch(err){
				return;
			}
			await chatUI.loadDebug(vo,path);
		}else{
			return;
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.showMenu=async function(){
		let chatBot,item,path,ext;
		path=session.entryBot.url;
		ext=pathLib.extname(path);
		if(path.startsWith("//")){
			path=path.substring(1);
		}else if(path.startsWith("/~/")){
			path=path.substring(2);
		}else if(path.startsWith("/@")){
			let pkgName,pos,subPath,pkgJSON;
			pos=path.indexOf("/",2);
			if(pos>0){
				pkgName=path.substring(2,pos);
				subPath=path.substring(pos);
			}else if(pos===0){
				path="";
			}else{
				pkgName=path.substring(2);
				subPath=null;
			}
			try{
				pkgJSON=await tabFS.readFile(`/coke/lib/${pkgName}.json`,"utf8");
				pkgJSON=JSON.parse(pkgJSON);
				if(subPath){
					path=pathLib.join(pkgJSON.path,subPath);
				}else{
					path=pkgJSON.main;
				}
			}catch(err){
				path="";
			}
		}
		if(path[0]!=="/"){
			path=null;
		}
		item=await app.modalDlg(DlgMenu,{
			hud:btnMenu,
			items:[
				{text:(($ln==="CN")?("清除会话"):/*EN*/("Clear Session")),code:"Reset"},
				{text:(($ln==="CN")?("添加到系统AI快捷方式"):/*EN*/("Add to System AI Shortcut")),code:"Shortcut"},
				{text:(($ln==="CN")?("编辑这个AIChat"):/*EN*/("Edit This AIChat")),code:"Edit",enable:(ext===".aichat")&&(!!path)},
				{text:(($ln==="CN")?("分享这个AIChat"):/*EN*/("Share This AIChat")),code:"Share",enable:false},
			]
		});
		if(item){
			switch(item.code){
				case "Reset":
					self.clearChat();
					break;
				case "Shortcut":
					app.showDlg(DlgAddShortCut,{bot:session.entryBot});
					break;
				case "Edit":{
					app.openPath(path,"edit");
					break;
				}
				case "Share":
					break;
			}
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.clearChat=async function(){
		self.showFace("init");
		await chatUI.clearChats();
	};
	
	//------------------------------------------------------------------------
	cssVO.checkCy=async function(){
		let res;
		if(!tabNT.checkLogin(false)){
			state.userTokens=-1;
			state.userGas=-1;
			return;
		}
		try{
			res=await tabNT.makeCall("userCurrency",{});
			if(res.code===200){
				state.userTokens=res.coins||0;
				state.userGas=res.points||0;
			}else{
				state.userTokens=-1;
				state.userGas=-1;
			}
		}catch(err){
			state.userTokens=-1;
			state.userGas=-1;
		}
	};
	
	/*}#1GGJKM84D1PostCSSVO*/
	return cssVO;
};
/*#{1GGJKM84D1ExCodes*/
/*}#1GGJKM84D1ExCodes*/


export default MainUI;
export{MainUI};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "UIView",
//	"jaxId": "1GGJKM84D0",
//	"editVersion": 79,
//	"attrs": {
//		"editEnv": {
//			"type": "object",
//			"jaxId": "1GGJKM84D2",
//			"editVersion": 52,
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "#cfgColor.body",
//				"bgChecker": "true"
//			}
//		},
//		"editObjs": {
//			"type": "object",
//			"jaxId": "1GGJKM84D3",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"model": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1H90TKKV70",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"createArgs": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1GGJKM84D4",
//			"editVersion": 16,
//			"attrs": {
//				"app": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"appFrame": {
//					"type": "auto",
//					"valText": "null"
//				}
//			}
//		},
//		"localVars": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1GGJKM84D5",
//			"editVersion": 22,
//			"attrs": {
//				"isMobile": {
//					"type": "bool",
//					"valText": "true"
//				}
//			}
//		},
//		"oneHud": "false",
//		"state": {
//			"type": "object",
//			"def": "StateObj",
//			"jaxId": "1GGJKM84D6",
//			"editVersion": 60,
//			"attrs": {
//				"counter": {
//					"type": "int",
//					"valText": "0"
//				},
//				"botName": {
//					"type": "string",
//					"valText": "Open AI chat to start session"
//				},
//				"chatBot": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"userTokens": {
//					"type": "int",
//					"valText": "-1"
//				},
//				"userGas": {
//					"type": "int",
//					"valText": "-1"
//				}
//			}
//		},
//		"exportTarget": "VFACT document",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"type": "object",
//			"def": "FaceTags",
//			"jaxId": "1GGJKM84D7",
//			"editVersion": 8,
//			"attrs": {
//				"start": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HB42O6710",
//					"editVersion": 18,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1HB42O6711",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"state": {
//							"type": "object",
//							"jaxId": "1HB44HBK60",
//							"editVersion": 4,
//							"attrs": {
//								"botName": {
//									"type": "string",
//									"valText": "Open AI chat to start session"
//								}
//							}
//						}
//					}
//				},
//				"init": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HB42O6712",
//					"editVersion": 18,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1HB42O6713",
//							"editVersion": 0,
//							"attrs": {}
//						},
//						"state": {
//							"type": "object",
//							"jaxId": "1HB44HBK61",
//							"editVersion": 8,
//							"attrs": {
//								"botName": {
//									"type": "string",
//									"valText": "Loading AI Chat..."
//								}
//							}
//						}
//					}
//				},
//				"ready": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HB42O6714",
//					"editVersion": 16,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1HB42O6715",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"wait": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HB42O6716",
//					"editVersion": 16,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1HB42O6717",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"type": "object",
//			"def": "MockupObj",
//			"jaxId": "1HAJQ2QB70",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "view",
//			"jaxId": "1GGJKM84D1",
//			"editVersion": 16,
//			"attrs": {
//				"properties": {
//					"type": "object",
//					"jaxId": "1GGJKM84D8",
//					"editVersion": 84,
//					"attrs": {
//						"type": "view",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "100%",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": ""
//					}
//				},
//				"subHuds": {
//					"type": "array",
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1HB40BN780",
//							"editVersion": 44,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1HB40GQA50",
//									"editVersion": 194,
//									"attrs": {
//										"type": "box",
//										"id": "BoxHeader",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "36",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "[0,10,0,10]",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"body\"]",
//										"border": "[0,0,1,0]",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor[\"fontBodyLit\"]",
//										"corner": "0",
//										"shadow": "true",
//										"shadowX": "0",
//										"shadowY": "1",
//										"shadowBlur": "5",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.30]",
//										"contentLayout": "Flex X",
//										"itemsAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1HB40IQQK0",
//											"editVersion": 47,
//											"attrs": {
//												"createArgs": {
//													"type": "object",
//													"def": "gearCrateArgs",
//													"jaxId": "1HB40N89V0",
//													"editVersion": 28,
//													"attrs": {
//														"style": "\"front\"",
//														"w": "26",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/folder.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"type": "object",
//													"jaxId": "1HB40N89V1",
//													"editVersion": 65,
//													"attrs": {
//														"type": "#null#>BtnIcon(\"front\",26,0,appCfg.sharedAssets+\"/folder.svg\",null)",
//														"id": "BtnOpen",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "${!state.chatBot},state",
//														"face": "",
//														"margin": "[0,3,0,0]"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1HB40N89V2",
//													"editVersion": 6,
//													"attrs": {
//														"1HB42O6712": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HB44HBK62",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HB44HBK63",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HB42O6712",
//															"faceTagName": "init"
//														}
//													}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1HB40N89V3",
//													"editVersion": 2,
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1HB4258150",
//															"editVersion": 2,
//															"attrs": {
//																"callArgs": {
//																	"type": "object",
//																	"jaxId": "1HB425G2S0",
//																	"editVersion": 2,
//																	"attrs": {
//																		"event": ""
//																	}
//																}
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1HB40N89V4",
//													"editVersion": 8,
//													"attrs": {
//														"tip": {
//															"type": "string",
//															"valText": "Open AI Chat",
//															"localizable": true
//														}
//													}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"type": "object",
//													"jaxId": "1HB40N89V5",
//													"editVersion": 0,
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1HB40LUV60",
//											"editVersion": 30,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HB40N89V6",
//													"editVersion": 146,
//													"attrs": {
//														"type": "text",
//														"id": "TxtBotName",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBody\"]",
//														"text": "${state.botName},state",
//														"font": "",
//														"fontSize": "#txtSize.mid",
//														"bold": "true",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "true",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0",
//														"flex": "true"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1HB40N89V7",
//													"editVersion": 6,
//													"attrs": {
//														"1HB42O6712": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HB44HBK64",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HB44HBK65",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HB42O6712",
//															"faceTagName": "init"
//														}
//													}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1HB40N89V8",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1HB40N89V9",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1HB40SU890",
//											"editVersion": 55,
//											"attrs": {
//												"createArgs": {
//													"type": "object",
//													"def": "gearCrateArgs",
//													"jaxId": "1HB4101TG0",
//													"editVersion": 22,
//													"attrs": {
//														"style": "\"front\"",
//														"w": "26",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/menu.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"type": "object",
//													"jaxId": "1HB4101TG1",
//													"editVersion": 46,
//													"attrs": {
//														"type": "#null#>BtnIcon(\"front\",26,0,appCfg.sharedAssets+\"/menu.svg\",null)",
//														"id": "BtnMenu",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"enable": "${!!state.chatBot},state"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1HB4101TG2",
//													"editVersion": 6,
//													"attrs": {
//														"1HB42O6712": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HB44HBK66",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HB44HBK67",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HB42O6712",
//															"faceTagName": "init"
//														}
//													}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1HB4101TG3",
//													"editVersion": 2,
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1HB4BUUKC0",
//															"editVersion": 2,
//															"attrs": {
//																"callArgs": {
//																	"type": "object",
//																	"jaxId": "1HB4BV57D0",
//																	"editVersion": 2,
//																	"attrs": {
//																		"event": ""
//																	}
//																}
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1HB4101TG4",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"type": "object",
//													"jaxId": "1HB4101TG5",
//													"editVersion": 0,
//													"attrs": {}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1HB40GQA51",
//									"editVersion": 6,
//									"attrs": {
//										"1HB42O6712": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HB44HBK68",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HB44HBK69",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HB42O6712",
//											"faceTagName": "init"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1HB40GQA52",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1HB40GQA53",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "true",
//								"container": "true",
//								"nameVal": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear1HAMRK4MB0",
//							"jaxId": "1HB41056P0",
//							"editVersion": 172,
//							"attrs": {
//								"createArgs": {
//									"type": "object",
//									"def": "gearCrateArgs",
//									"jaxId": "1HB411ADT0",
//									"editVersion": 92,
//									"attrs": {
//										"opts": {
//											"type": "object",
//											"jaxId": "1HB411ADT1",
//											"editVersion": 104,
//											"attrs": {
//												"bubble": "#!!isMobile",
//												"ai": {
//													"type": "object",
//													"jaxId": "1HB411ADT2",
//													"editVersion": 38,
//													"attrs": {
//														"blkColor": "[0,0,0,0.00]",
//														"bgColor": "#cfgColor[\"primary\"]",
//														"icon": "#appCfg.sharedAssets+\"/faces.svg\"",
//														"pic": "",
//														"textColor": "#isMobile?cfgColor[\"fontSecondary\"]:cfgColor[\"fontBody\"]",
//														"iconColor": "#cfgColor[\"fontSuccess\"]",
//														"side": "left"
//													}
//												},
//												"user": {
//													"type": "object",
//													"jaxId": "1HB411ADT3",
//													"editVersion": 40,
//													"attrs": {
//														"blkColor": "[0,0,0,0.00]",
//														"bgColor": "#cfgColor[\"secondary\"]",
//														"icon": "#appCfg.sharedAssets+\"/user.svg\"",
//														"pic": "",
//														"textColor": "#isMobile?cfgColor[\"fontPrimary\"]:cfgColor[\"fontBody\"]",
//														"iconColor": "#cfgColor[\"fontPrimary\"]",
//														"side": "right"
//													}
//												},
//												"wait": {
//													"type": "object",
//													"jaxId": "1HB411ADT4",
//													"editVersion": 20,
//													"attrs": {
//														"blkColor": "[0,0,0,0.00]",
//														"bgColor": "#cfgColor[\"secondary\"]",
//														"icon": "#appCfg.sharedAssets+\"/faces.svg\"",
//														"pic": "",
//														"textColor": "#isMobile?cfgColor[\"fontSecondarySub\"]:cfgColor[\"fontBody\"]",
//														"iconColor": "#cfgColor[\"fontSecondary\"]",
//														"side": "left"
//													}
//												},
//												"event": {
//													"type": "object",
//													"jaxId": "1HB411ADT5",
//													"editVersion": 20,
//													"attrs": {
//														"blkColor": "[0,0,0,0.00]",
//														"bgColor": "#cfgColor[\"warning\"]",
//														"icon": "#appCfg.sharedAssets+\"/event.svg\"",
//														"pic": "",
//														"textColor": "#isMobile?cfgColor[\"fontWarning\"]:cfgColor[\"fontBody\"]",
//														"iconColor": "#cfgColor[\"fontWarning\"]",
//														"side": "left"
//													}
//												},
//												"error": {
//													"type": "object",
//													"jaxId": "1HB411ADT6",
//													"editVersion": 20,
//													"attrs": {
//														"blkColor": "[0,0,0,0.00]",
//														"bgColor": "#cfgColor[\"error\"]",
//														"icon": "#appCfg.sharedAssets+\"/fat_right.svg\"",
//														"pic": "",
//														"textColor": "#isMobile?cfgColor[\"fontError\"]:[155,0,0,1.00]",
//														"iconColor": "#cfgColor[\"fontError\"]",
//														"side": "left"
//													}
//												},
//												"ask": {
//													"type": "object",
//													"jaxId": "1HB411ADT7",
//													"editVersion": 14,
//													"attrs": {
//														"blkColor": "[0,0,0,0.00]",
//														"bgColor": "#cfgColor[\"success\"]",
//														"icon": "#appCfg.sharedAssets+\"/help.svg\"",
//														"pic": "",
//														"textColor": "#cfgColor[\"fontBody\"]",
//														"iconColor": "#cfgColor[\"fontSuccess\"]",
//														"side": "left"
//													}
//												}
//											}
//										}
//									}
//								},
//								"properties": {
//									"type": "object",
//									"jaxId": "1HB411ADT8",
//									"editVersion": 92,
//									"attrs": {
//										"type": "#null#>UIChat({\"bubble\":!!isMobile,\"ai\":{\"blkColor\":[0,0,0,0],\"bgColor\":cfgColor[\"primary\"],\"icon\":appCfg.sharedAssets+\"/faces.svg\",\"pic\":\"\",\"textColor\":isMobile?cfgColor[\"fontSecondary\"]:cfgColor[\"fontBody\"],\"iconColor\":cfgColor[\"fontSuccess\"],\"side\":\"left\"},\"user\":{\"blkColor\":[0,0,0,0],\"bgColor\":cfgColor[\"secondary\"],\"icon\":appCfg.sharedAssets+\"/user.svg\",\"pic\":\"\",\"textColor\":isMobile?cfgColor[\"fontPrimary\"]:cfgColor[\"fontBody\"],\"iconColor\":cfgColor[\"fontPrimary\"],\"side\":\"right\"},\"wait\":{\"blkColor\":[0,0,0,0],\"bgColor\":cfgColor[\"secondary\"],\"icon\":appCfg.sharedAssets+\"/faces.svg\",\"pic\":\"\",\"textColor\":isMobile?cfgColor[\"fontSecondarySub\"]:cfgColor[\"fontBody\"],\"iconColor\":cfgColor[\"fontSecondary\"],\"side\":\"left\"},\"event\":{\"blkColor\":[0,0,0,0],\"bgColor\":cfgColor[\"warning\"],\"icon\":appCfg.sharedAssets+\"/event.svg\",\"pic\":\"\",\"textColor\":isMobile?cfgColor[\"fontWarning\"]:cfgColor[\"fontBody\"],\"iconColor\":cfgColor[\"fontWarning\"],\"side\":\"left\"},\"error\":{\"blkColor\":[0,0,0,0],\"bgColor\":cfgColor[\"error\"],\"icon\":appCfg.sharedAssets+\"/fat_right.svg\",\"pic\":\"\",\"textColor\":isMobile?cfgColor[\"fontError\"]:[155,0,0,1.00],\"iconColor\":cfgColor[\"fontError\"],\"side\":\"left\"},\"ask\":{\"blkColor\":[0,0,0,0],\"bgColor\":cfgColor[\"success\"],\"icon\":appCfg.sharedAssets+\"/help.svg\",\"pic\":\"\",\"textColor\":cfgColor[\"fontBody\"],\"iconColor\":cfgColor[\"fontSuccess\"],\"side\":\"left\"}})",
//										"id": "ChatUI",
//										"position": "Absolute",
//										"x": "0",
//										"y": "36",
//										"display": "On",
//										"face": "",
//										"h": "100%-56"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1HB411ADT9",
//									"editVersion": 6,
//									"attrs": {
//										"1HB42O6712": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HB44HBK610",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HB44HBK611",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HB42O6712",
//											"faceTagName": "init"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1HB411ADT10",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1HB411ADT11",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true",
//								"containerSlots": {
//									"type": "object",
//									"jaxId": "1HB411ADT12",
//									"editVersion": 0,
//									"attrs": {}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1HB441PR20",
//							"editVersion": 30,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1HB444N5G0",
//									"editVersion": 142,
//									"attrs": {
//										"type": "box",
//										"id": "BoxFooter",
//										"position": "Absolute",
//										"x": "0",
//										"y": "100%-20",
//										"w": "100%",
//										"h": "20",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "[0,5,0,5]",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"secondary\"]",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"contentLayout": "Flex XR",
//										"itemsAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1HB445K7D0",
//											"editVersion": 22,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HB445K7D1",
//													"editVersion": 112,
//													"attrs": {
//														"type": "hud",
//														"id": "",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"w": "",
//														"h": "20",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex XR",
//														"subAlign": "Start",
//														"itemsAlign": "Center"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1HB445K7E0",
//															"editVersion": 46,
//															"attrs": {
//																"createArgs": {
//																	"type": "object",
//																	"def": "gearCrateArgs",
//																	"jaxId": "1HB445K7E1",
//																	"editVersion": 40,
//																	"attrs": {
//																		"style": "#cfgColor.fontSecondary",
//																		"w": "16",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/gas.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HB445K7E2",
//																	"editVersion": 42,
//																	"attrs": {
//																		"type": "#null#>BtnIcon(cfgColor.fontSecondary,16,0,appCfg.sharedAssets+\"/gas.svg\",null)",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": ""
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HB445K7E3",
//																	"editVersion": 34,
//																	"attrs": {
//																		"1HB42O6712": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HB44HBK612",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HB44HBK613",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HB42O6712",
//																			"faceTagName": "init"
//																		}
//																	}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HB445K7E8",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HB445K7E9",
//																	"editVersion": 8,
//																	"attrs": {
//																		"tip": {
//																			"type": "string",
//																			"valText": "Account gas left",
//																			"localizable": true
//																		}
//																	}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"type": "object",
//																	"jaxId": "1HB445K7E10",
//																	"editVersion": 0,
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1HB445K7F0",
//															"editVersion": 37,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HB445K7F1",
//																	"editVersion": 166,
//																	"attrs": {
//																		"type": "text",
//																		"id": "TxtGas",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontSecondary\"]",
//																		"text": "${state.userGas>=0?state.userGas:\"- - -\"},state",
//																		"font": "",
//																		"fontSize": "#txtSize.smallPlus",
//																		"bold": "true",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Top",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HB445K7F2",
//																	"editVersion": 34,
//																	"attrs": {
//																		"1HB42O6712": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HB44HBK614",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HB44HBK615",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HB42O6712",
//																			"faceTagName": "init"
//																		}
//																	}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HB445K7F7",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HB445K7F8",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1HB445K7F9",
//															"editVersion": 49,
//															"attrs": {
//																"createArgs": {
//																	"type": "object",
//																	"def": "gearCrateArgs",
//																	"jaxId": "1HB445K7F10",
//																	"editVersion": 52,
//																	"attrs": {
//																		"style": "#cfgColor.fontSecondary",
//																		"w": "16",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/token.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HB445K7F11",
//																	"editVersion": 79,
//																	"attrs": {
//																		"type": "#null#>BtnIcon(cfgColor.fontSecondary,16,0,appCfg.sharedAssets+\"/token.svg\",null)",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"scale": "[-1,1]",
//																		"anchorH": "Right",
//																		"margin": "[0,10,0,0]"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HB445K7F12",
//																	"editVersion": 34,
//																	"attrs": {
//																		"1HB42O6712": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HB44HBK616",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HB44HBK617",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HB42O6712",
//																			"faceTagName": "init"
//																		}
//																	}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HB445K7F17",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HB445K7F18",
//																	"editVersion": 14,
//																	"attrs": {
//																		"tip": {
//																			"type": "string",
//																			"valText": "Account tokens left",
//																			"localizable": true
//																		}
//																	}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"type": "object",
//																	"jaxId": "1HB445K7F19",
//																	"editVersion": 0,
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1HB445K7G0",
//															"editVersion": 39,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HB445K7G1",
//																	"editVersion": 186,
//																	"attrs": {
//																		"type": "text",
//																		"id": "TxtTokens",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[0,3,0,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontSecondary\"]",
//																		"text": "${state.userTokens>=0?state.userTokens:\"- - -\"},state",
//																		"font": "",
//																		"fontSize": "#txtSize.smallPlus",
//																		"bold": "true",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Top",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HB445K7G2",
//																	"editVersion": 34,
//																	"attrs": {
//																		"1HB42O6712": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HB44HBK618",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HB44HBK619",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HB42O6712",
//																			"faceTagName": "init"
//																		}
//																	}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HB445K7G7",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HB445K7G8",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false"
//															}
//														}
//													]
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1HB445K7G9",
//													"editVersion": 34,
//													"attrs": {
//														"1HB42O6712": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HB44HBK620",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HB44HBK621",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HB42O6712",
//															"faceTagName": "init"
//														}
//													}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1HB445K7G14",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1HB445K7G15",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1HB444N5G1",
//									"editVersion": 6,
//									"attrs": {
//										"1HB42O6712": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HB44HBK622",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HB44HBK623",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HB42O6712",
//											"faceTagName": "init"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1HB444N5G2",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1HB444N5G3",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"type": "object",
//					"jaxId": "1GGJKM84D9",
//					"editVersion": 6,
//					"attrs": {
//						"1HB42O6712": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HB44HBK624",
//							"editVersion": 4,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1HB44HBK625",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"anis": {
//									"type": "array",
//									"def": "Array",
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HB42O6712",
//							"faceTagName": "init"
//						}
//					}
//				},
//				"functions": {
//					"type": "object",
//					"jaxId": "1GGJKM84D10",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"extraPpts": {
//					"type": "object",
//					"def": "Object",
//					"jaxId": "1GGJKM84D11",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1GGJKM84D12",
//			"editVersion": 70,
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"innerLayout": {
//					"valText": "false"
//				},
//				"marginL": {
//					"valText": "false"
//				},
//				"marginR": {
//					"valText": "false"
//				},
//				"marginT": {
//					"valText": "false"
//				},
//				"marginB": {
//					"valText": "false"
//				},
//				"paddingL": {
//					"valText": "false"
//				},
//				"paddingR": {
//					"valText": "false"
//				},
//				"paddingT": {
//					"valText": "false"
//				},
//				"paddingB": {
//					"valText": "false"
//				},
//				"attach": {
//					"valText": "false"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}