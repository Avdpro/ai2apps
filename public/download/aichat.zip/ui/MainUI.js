//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
import {UIChat} from "./UIChat.js";
import {BoxTokenGas} from "./BoxTokenGas.js";
/*#{1GGJKM84D0StartDoc*/
import {tabNT} from "/@tabos/tabos_nt.js";
import {tabOS,tabFS} from "/@tabos";
import pathLib from "/@path";
import {DlgFile} from "/@homekit/ui/DlgFile.js";
import {DlgMenu} from "/@StdUI/ui/DlgMenu.js";
import {DlgAddShortCut} from "./DlgAddShortCut.js";
import {DlgAIChatHome} from "./DlgAIChatHome.js";
/*}#1GGJKM84D0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let MainUI=function(app,appFrame){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let boxHeader,btnMenu,chatUI,boxFooter;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let isMobile=true;
	
	/*#{1GGJKM84D1LocalVals*/
	app.openDocPath=localStorage.getItem("LastAIChatPath")||"/";
	let session=null;
	isMobile=app.w<500?true:false;
	/*}#1GGJKM84D1LocalVals*/
	
	/*#{1GGJKM84D1PreState*/
	/*}#1GGJKM84D1PreState*/
	state={
		"counter":0,"botName":"Open AI chat to start session","chatBot":null,"userTokens":-1,"userGas":-1,
		/*#{1GGJKM84D6ExState*/
		/*}#1GGJKM84D6ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1GGJKM84D1PostState*/
	/*}#1GGJKM84D1PostState*/
	cssVO={
		"hash":"1GGJKM84D1",nameHost:true,
		"type":"view","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
		children:[
			{
				"hash":"1HB40BN780",
				"type":"box","id":"BoxHeader","x":0,"y":0,"w":"100%","h":36,"padding":[0,10,0,10],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["body"],
				"border":[0,0,1,0],"borderColor":cfgColor["fontBodyLit"],"shadow":true,"shadowX":0,"shadowY":1,"shadowBlur":5,"shadowColor":[0,0,0,0.3],"contentLayout":"flex-x",
				"itemsAlign":1,
				children:[
					{
						"hash":"1HB40IQQK0",
						"type":BtnIcon("front",26,0,appCfg.sharedAssets+"/folder.svg",null),"id":"BtnOpen","position":"relative","x":0,"y":0,"display":$P(()=>(!state.chatBot),state),
						"margin":[0,3,0,0],
						"tip":"Open AI Chat",
						"OnClick":function(event){
							/*#{1HB4258150FunctionBody*/
							self.openChat();
							/*}#1HB4258150FunctionBody*/
						},
					},
					{
						"hash":"1HB40LUV60",
						"type":"text","id":"TxtBotName","position":"relative","x":0,"y":0,"w":"","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
						"text":$P(()=>(state.botName),state),"fontSize":txtSize.mid,"fontWeight":"bold","fontStyle":"normal","textDecoration":"","ellipsis":true,"flex":true,
					},
					{
						"hash":"1HB40SU890",
						"type":BtnIcon("front",26,0,appCfg.sharedAssets+"/menu.svg",null),"id":"BtnMenu","position":"relative","x":0,"y":0,"enable":$P(()=>(!!state.chatBot),state),
						"OnClick":function(event){
							/*#{1HB4BUUKC0FunctionBody*/
							self.showMenu();
							/*}#1HB4BUUKC0FunctionBody*/
						},
					}
				],
			},
			{
				"hash":"1HB41056P0",
				"type":UIChat({"bubble":!!isMobile,"ai":{"blkColor":[0,0,0,0],"bgColor":cfgColor["primary"],"icon":appCfg.sharedAssets+"/faces.svg","pic":"","textColor":isMobile?cfgColor["fontSecondary"]:cfgColor["fontBody"],"iconColor":cfgColor["fontSuccess"],"side":"left"},"user":{"blkColor":[0,0,0,0],"bgColor":cfgColor["secondary"],"icon":appCfg.sharedAssets+"/user.svg","pic":"","textColor":isMobile?cfgColor["fontPrimary"]:cfgColor["fontBody"],"iconColor":cfgColor["fontPrimary"],"side":"right"},"wait":{"blkColor":[0,0,0,0],"bgColor":cfgColor["secondary"],"icon":appCfg.sharedAssets+"/faces.svg","pic":"","textColor":isMobile?cfgColor["fontSecondarySub"]:cfgColor["fontBody"],"iconColor":cfgColor["fontSecondary"],"side":"left"},"event":{"blkColor":[0,0,0,0],"bgColor":cfgColor["warning"],"icon":appCfg.sharedAssets+"/event.svg","pic":"","textColor":isMobile?cfgColor["fontWarning"]:cfgColor["fontBody"],"iconColor":cfgColor["fontWarning"],"side":"left"},"error":{"blkColor":[0,0,0,0],"bgColor":cfgColor["error"],"icon":appCfg.sharedAssets+"/fat_right.svg","pic":"","textColor":isMobile?cfgColor["fontError"]:[155,0,0,1.00],"iconColor":cfgColor["fontError"],"side":"left"},"ask":{"blkColor":[0,0,0,0],"bgColor":cfgColor["success"],"icon":appCfg.sharedAssets+"/help.svg","pic":"","textColor":cfgColor["fontBody"],"iconColor":cfgColor["fontSuccess"],"side":"left"}}),
				"id":"ChatUI","x":0,"y":36,"h":">calc(100% - 56px)",
			},
			{
				"hash":"1HHAJFJ8R0",
				"type":BoxTokenGas(20,cfgColor["secondary"],cfgColor["fontSecondary"],16,14,true,false),"id":"BoxFooter","x":0,"y":">calc(100% - 20px)","caption":"",
			}
		],
		/*#{1GGJKM84D1ExtraCSS*/
		/*}#1GGJKM84D1ExtraCSS*/
		faces:{
			"start":{
				"/":function(){
					state["botName"]="Open AI chat to start session";
				}
			},"init":{
				"/":function(){
					state["botName"]="Loading AI Chat...";
				}
			},"ready":{
			},"wait":{
			}
		},
		OnCreate:function(){
			self=this;
			boxHeader=self.BoxHeader;btnMenu=self.BtnMenu;chatUI=self.ChatUI;boxFooter=self.BoxFooter;
			/*#{1GGJKM84D1Create*/
			let params,chatJSON;
			self.showFace("start");
			app.on("SessionReady",(_session)=>{
				session=_session;
				state.chatBot=session.entryBot;
				state.botName=state.chatBot.name;
				self.showFace("ready");
			});
			app.on("SessionLoadError",(reason)=>{
				self.showFace("start");
			});
			app.on("CheckCY",(_session)=>{
				boxFooter.refresh();
			});
			params=VFACT.appParams;
			if(params){
				chatJSON=params.json;
				if(chatJSON){
					try{
						chatJSON=JSON.parse(chatJSON);
					}catch(err){
						chatJSON=null;
					}
				}
				self.openChatFile(params.chat||params.file,chatJSON);
			}
			/*}#1GGJKM84D1Create*/
		},
		/*#{1GGJKM84D1EndCSS*/
		/*}#1GGJKM84D1EndCSS*/
	};
	/*#{1GGJKM84D1PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.openChat=async function(){
		let filePath;
		filePath=await app.modalDlg(DlgFile,{
			mode:"open",
			path:app.openDocPath,
			options:{
				preview:1,
				filter:"*.aichat;*.js",
			}
		});
		if(filePath){
			self.openChatFile(filePath);
			app.openDocPath=pathLib.dirname(filePath);
			localStorage.setItem("LastAIChatPath",app.openDocPath);
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.openChatFile=async function(path,json){
		let ext;
		//Convert file system path to URL:
		self.showFace("init");
		ext=pathLib.extname(path);
		if(ext===".js"){
			let argument=VFACT.appParams.prompt||VFACT.appParams.argument||null;
			if(path[0]==="/" && path[1]!=="/" && path[1]!=="~" && path[1]!=="@"){
				path="/~"+path;
			}
			if(path[0]!=="/" && (!path.startsWith("http://")) &&(!path.startsWith("https://"))){
				path=pathLib.join(app.appDir,path);
			}
			await chatUI.initChat({url:path,argument:argument});
		}else if(ext===".aichat"){
			if(path[0]==="/" && path[1]!=="/" && path[1]!=="@" && path[1]!=="~"){
				path="/~"+path;
			}
			if(path[0]!=="/" && (!path.startsWith("http://")) &&(!path.startsWith("https://"))){
				path=pathLib.join(app.appDir,path);
			}
			await chatUI.initChat({bot:path,json:json});
		}else if(ext===".aidebug"){
			let vo;
			try{
				vo=await tabFS.readFile(path,"utf8");
				vo=JSON.parse(vo);
			}catch(err){
				return;
			}
			await chatUI.loadDebug(vo,path);
		}else{
			return;
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.showMenu=async function(){
		let chatBot,item,path,ext;
		path=session.entryBot.url;
		ext=pathLib.extname(path);
		if(path.startsWith("//")){
			path=path.substring(1);
		}else if(path.startsWith("/~/")){
			path=path.substring(2);
		}else if(path.startsWith("/@")){
			let pkgName,pos,subPath,pkgJSON;
			pos=path.indexOf("/",2);
			if(pos>0){
				pkgName=path.substring(2,pos);
				subPath=path.substring(pos);
			}else if(pos===0){
				path="";
			}else{
				pkgName=path.substring(2);
				subPath=null;
			}
			try{
				pkgJSON=await tabFS.readFile(`/coke/lib/${pkgName}.json`,"utf8");
				pkgJSON=JSON.parse(pkgJSON);
				if(subPath){
					path=pathLib.join(pkgJSON.path,subPath);
				}else{
					path=pkgJSON.main;
				}
			}catch(err){
				path="";
			}
		}
		if(path[0]!=="/"){
			path=null;
		}
		item=await app.modalDlg(DlgMenu,{
			hud:btnMenu,
			items:[
				{text:(($ln==="CN")?("清除会话"):/*EN*/("Clear Session")),code:"Reset"},
				{text:(($ln==="CN")?("添加到系统AI快捷方式"):/*EN*/("Add to System AI Shortcut")),code:"Shortcut"},
				{text:(($ln==="CN")?("编辑这个AIChat"):/*EN*/("Edit This AIChat")),code:"Edit",enable:(ext===".aichat")&&(!!path)},
				{text:(($ln==="CN")?("分享这个AIChat"):/*EN*/("Share This AIChat")),code:"Share",enable:false},
			]
		});
		if(item){
			switch(item.code){
				case "Reset":
					self.resetChat();
					break;
				case "Shortcut":
					app.showDlg(DlgAddShortCut,{bot:session.entryBot});
					break;
				case "Edit":{
					app.openPath(path,"edit");
					break;
				}
				case "Share":
					break;
			}
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.resetChat=async function(){
		self.showFace("init");
		await chatUI.resetChat();
	};
	/*}#1GGJKM84D1PostCSSVO*/
	cssVO.constructor=MainUI;
	return cssVO;
};
/*#{1GGJKM84D1ExCodes*/
/*}#1GGJKM84D1ExCodes*/

//----------------------------------------------------------------------------
MainUI.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1GGJKM84D1PreAISpot*/
	/*}#1GGJKM84D1PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1GGJKM84D1PostAISpot*/
	/*}#1GGJKM84D1PostAISpot*/
	return exposeVO;
};

/*#{1GGJKM84D0EndDoc*/
/*}#1GGJKM84D0EndDoc*/

export default MainUI;
export{MainUI};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "UIView",
//	"jaxId": "1GGJKM84D0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1GGJKM84D2",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "#cfgColor.body",
//				"bgChecker": "true"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1GGJKM84D3",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1H90TKKV70",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1GGJKM84D4",
//			"attrs": {
//				"app": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"appFrame": {
//					"type": "auto",
//					"valText": "null"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1GGJKM84D5",
//			"attrs": {
//				"isMobile": {
//					"type": "bool",
//					"valText": "true"
//				}
//			}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1GGJKM84D6",
//			"attrs": {
//				"counter": {
//					"type": "int",
//					"valText": "0"
//				},
//				"botName": {
//					"type": "string",
//					"valText": "Open AI chat to start session"
//				},
//				"chatBot": {
//					"type": "auto",
//					"valText": "null"
//				},
//				"userTokens": {
//					"type": "int",
//					"valText": "-1"
//				},
//				"userGas": {
//					"type": "int",
//					"valText": "-1"
//				}
//			}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "VFACT document",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1GGJKM84D7",
//			"attrs": {
//				"start": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HB42O6710",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HB42O6711",
//							"attrs": {}
//						},
//						"state": {
//							"type": "object",
//							"jaxId": "1HB44HBK60",
//							"attrs": {
//								"botName": {
//									"type": "string",
//									"valText": "Open AI chat to start session"
//								}
//							}
//						}
//					}
//				},
//				"init": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HB42O6712",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HB42O6713",
//							"attrs": {}
//						},
//						"state": {
//							"type": "object",
//							"jaxId": "1HB44HBK61",
//							"attrs": {
//								"botName": {
//									"type": "string",
//									"valText": "Loading AI Chat..."
//								}
//							}
//						}
//					}
//				},
//				"ready": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HB42O6714",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HB42O6715",
//							"attrs": {}
//						}
//					}
//				},
//				"wait": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HB42O6716",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HB42O6717",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1HAJQ2QB70",
//			"attrs": {}
//		},
//		"exposeToAI": "true",
//		"descAI": "",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "view",
//			"jaxId": "1GGJKM84D1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1GGJKM84D8",
//					"attrs": {
//						"type": "view",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "100%",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": ""
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1HB40BN780",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HB40GQA50",
//									"attrs": {
//										"type": "box",
//										"id": "BoxHeader",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "36",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "[0,10,0,10]",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"body\"]",
//										"border": "[0,0,1,0]",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor[\"fontBodyLit\"]",
//										"corner": "0",
//										"shadow": "true",
//										"shadowX": "0",
//										"shadowY": "1",
//										"shadowBlur": "5",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.30]",
//										"contentLayout": "Flex X",
//										"itemsAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1HB40IQQK0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1HB40N89V0",
//													"attrs": {
//														"style": "\"front\"",
//														"w": "26",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/folder.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1HB40N89V1",
//													"attrs": {
//														"type": "#null#>BtnIcon(\"front\",26,0,appCfg.sharedAssets+\"/folder.svg\",null)",
//														"id": "BtnOpen",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "${!state.chatBot},state",
//														"face": "",
//														"margin": "[0,3,0,0]"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HB40N89V2",
//													"attrs": {
//														"1HB42O6712": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HB44HBK62",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HB44HBK63",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HB42O6712",
//															"faceTagName": "init"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HB40N89V3",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1HB4258150",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1HB425G2S0",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1HB40N89V4",
//													"attrs": {
//														"tip": {
//															"type": "string",
//															"valText": "Open AI Chat",
//															"localizable": true
//														}
//													}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1HB40N89V5",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1HB40LUV60",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HB40N89V6",
//													"attrs": {
//														"type": "text",
//														"id": "TxtBotName",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBody\"]",
//														"text": "${state.botName},state",
//														"font": "",
//														"fontSize": "#txtSize.mid",
//														"bold": "true",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "true",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0",
//														"flex": "true"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HB40N89V7",
//													"attrs": {
//														"1HB42O6712": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HB44HBK64",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HB44HBK65",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HB42O6712",
//															"faceTagName": "init"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HB40N89V8",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HB40N89V9",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1HB40SU890",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1HB4101TG0",
//													"attrs": {
//														"style": "\"front\"",
//														"w": "26",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/menu.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1HB4101TG1",
//													"attrs": {
//														"type": "#null#>BtnIcon(\"front\",26,0,appCfg.sharedAssets+\"/menu.svg\",null)",
//														"id": "BtnMenu",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"enable": "${!!state.chatBot},state"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HB4101TG2",
//													"attrs": {
//														"1HB42O6712": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HB44HBK66",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HB44HBK67",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HB42O6712",
//															"faceTagName": "init"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HB4101TG3",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1HB4BUUKC0",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1HB4BV57D0",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1HB4101TG4",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1HB4101TG5",
//													"attrs": {}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1HB40GQA51",
//									"attrs": {
//										"1HB42O6712": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HB44HBK68",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HB44HBK69",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HB42O6712",
//											"faceTagName": "init"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HB40GQA52",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HB40GQA53",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "true",
//								"container": "true",
//								"nameVal": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear1HAMRK4MB0",
//							"jaxId": "1HB41056P0",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1HB411ADT0",
//									"attrs": {
//										"opts": {
//											"jaxId": "1HB411ADT1",
//											"attrs": {
//												"bubble": "#!!isMobile",
//												"ai": {
//													"jaxId": "1HB411ADT2",
//													"attrs": {
//														"blkColor": "[0,0,0,0.00]",
//														"bgColor": "#cfgColor[\"primary\"]",
//														"icon": "#appCfg.sharedAssets+\"/faces.svg\"",
//														"pic": "",
//														"textColor": "#isMobile?cfgColor[\"fontSecondary\"]:cfgColor[\"fontBody\"]",
//														"iconColor": "#cfgColor[\"fontSuccess\"]",
//														"side": "left"
//													}
//												},
//												"user": {
//													"jaxId": "1HB411ADT3",
//													"attrs": {
//														"blkColor": "[0,0,0,0.00]",
//														"bgColor": "#cfgColor[\"secondary\"]",
//														"icon": "#appCfg.sharedAssets+\"/user.svg\"",
//														"pic": "",
//														"textColor": "#isMobile?cfgColor[\"fontPrimary\"]:cfgColor[\"fontBody\"]",
//														"iconColor": "#cfgColor[\"fontPrimary\"]",
//														"side": "right"
//													}
//												},
//												"wait": {
//													"jaxId": "1HB411ADT4",
//													"attrs": {
//														"blkColor": "[0,0,0,0.00]",
//														"bgColor": "#cfgColor[\"secondary\"]",
//														"icon": "#appCfg.sharedAssets+\"/faces.svg\"",
//														"pic": "",
//														"textColor": "#isMobile?cfgColor[\"fontSecondarySub\"]:cfgColor[\"fontBody\"]",
//														"iconColor": "#cfgColor[\"fontSecondary\"]",
//														"side": "left"
//													}
//												},
//												"event": {
//													"jaxId": "1HB411ADT5",
//													"attrs": {
//														"blkColor": "[0,0,0,0.00]",
//														"bgColor": "#cfgColor[\"warning\"]",
//														"icon": "#appCfg.sharedAssets+\"/event.svg\"",
//														"pic": "",
//														"textColor": "#isMobile?cfgColor[\"fontWarning\"]:cfgColor[\"fontBody\"]",
//														"iconColor": "#cfgColor[\"fontWarning\"]",
//														"side": "left"
//													}
//												},
//												"error": {
//													"jaxId": "1HB411ADT6",
//													"attrs": {
//														"blkColor": "[0,0,0,0.00]",
//														"bgColor": "#cfgColor[\"error\"]",
//														"icon": "#appCfg.sharedAssets+\"/fat_right.svg\"",
//														"pic": "",
//														"textColor": "#isMobile?cfgColor[\"fontError\"]:[155,0,0,1.00]",
//														"iconColor": "#cfgColor[\"fontError\"]",
//														"side": "left"
//													}
//												},
//												"ask": {
//													"jaxId": "1HB411ADT7",
//													"attrs": {
//														"blkColor": "[0,0,0,0.00]",
//														"bgColor": "#cfgColor[\"success\"]",
//														"icon": "#appCfg.sharedAssets+\"/help.svg\"",
//														"pic": "",
//														"textColor": "#cfgColor[\"fontBody\"]",
//														"iconColor": "#cfgColor[\"fontSuccess\"]",
//														"side": "left"
//													}
//												}
//											}
//										}
//									}
//								},
//								"properties": {
//									"jaxId": "1HB411ADT8",
//									"attrs": {
//										"type": "#null#>UIChat({\"bubble\":!!isMobile,\"ai\":{\"blkColor\":[0,0,0,0],\"bgColor\":cfgColor[\"primary\"],\"icon\":appCfg.sharedAssets+\"/faces.svg\",\"pic\":\"\",\"textColor\":isMobile?cfgColor[\"fontSecondary\"]:cfgColor[\"fontBody\"],\"iconColor\":cfgColor[\"fontSuccess\"],\"side\":\"left\"},\"user\":{\"blkColor\":[0,0,0,0],\"bgColor\":cfgColor[\"secondary\"],\"icon\":appCfg.sharedAssets+\"/user.svg\",\"pic\":\"\",\"textColor\":isMobile?cfgColor[\"fontPrimary\"]:cfgColor[\"fontBody\"],\"iconColor\":cfgColor[\"fontPrimary\"],\"side\":\"right\"},\"wait\":{\"blkColor\":[0,0,0,0],\"bgColor\":cfgColor[\"secondary\"],\"icon\":appCfg.sharedAssets+\"/faces.svg\",\"pic\":\"\",\"textColor\":isMobile?cfgColor[\"fontSecondarySub\"]:cfgColor[\"fontBody\"],\"iconColor\":cfgColor[\"fontSecondary\"],\"side\":\"left\"},\"event\":{\"blkColor\":[0,0,0,0],\"bgColor\":cfgColor[\"warning\"],\"icon\":appCfg.sharedAssets+\"/event.svg\",\"pic\":\"\",\"textColor\":isMobile?cfgColor[\"fontWarning\"]:cfgColor[\"fontBody\"],\"iconColor\":cfgColor[\"fontWarning\"],\"side\":\"left\"},\"error\":{\"blkColor\":[0,0,0,0],\"bgColor\":cfgColor[\"error\"],\"icon\":appCfg.sharedAssets+\"/fat_right.svg\",\"pic\":\"\",\"textColor\":isMobile?cfgColor[\"fontError\"]:[155,0,0,1.00],\"iconColor\":cfgColor[\"fontError\"],\"side\":\"left\"},\"ask\":{\"blkColor\":[0,0,0,0],\"bgColor\":cfgColor[\"success\"],\"icon\":appCfg.sharedAssets+\"/help.svg\",\"pic\":\"\",\"textColor\":cfgColor[\"fontBody\"],\"iconColor\":cfgColor[\"fontSuccess\"],\"side\":\"left\"}})",
//										"id": "ChatUI",
//										"position": "Absolute",
//										"x": "0",
//										"y": "36",
//										"display": "On",
//										"face": "",
//										"h": "100%-56"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HB411ADT9",
//									"attrs": {
//										"1HB42O6712": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HB44HBK610",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HB44HBK611",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HB42O6712",
//											"faceTagName": "init"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HB411ADT10",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HB411ADT11",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true",
//								"containerSlots": {
//									"jaxId": "1HB411ADT12",
//									"attrs": {}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear1HHA5TKVC0",
//							"jaxId": "1HHAJFJ8R0",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1HHAJGLQ60",
//									"attrs": {
//										"h": "20",
//										"bgColor": "#cfgColor[\"secondary\"]",
//										"textColor": "#cfgColor[\"fontSecondary\"]",
//										"iconSize": "16",
//										"fontSize": "14",
//										"menu": "true",
//										"thin": "false"
//									}
//								},
//								"properties": {
//									"jaxId": "1HHAJGLQ61",
//									"attrs": {
//										"type": "#null#>BoxTokenGas(20,cfgColor[\"secondary\"],cfgColor[\"fontSecondary\"],16,14,true,false)",
//										"id": "BoxFooter",
//										"position": "Absolute",
//										"x": "0",
//										"y": "100%-20",
//										"display": "On",
//										"face": "",
//										"caption": {
//											"type": "string",
//											"valText": "",
//											"localizable": true
//										}
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HHAJGLQ62",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1HHAJGLQ63",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HHAJGLQ64",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true",
//								"containerSlots": {
//									"jaxId": "1HHAJGLQ65",
//									"attrs": {}
//								}
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1GGJKM84D9",
//					"attrs": {
//						"1HB42O6712": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HB44HBK624",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HB44HBK625",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HB42O6712",
//							"faceTagName": "init"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1GGJKM84D10",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1GGJKM84D11",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1GGJKM84D12",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false",
//				"innerLayout": {
//					"valText": "false"
//				},
//				"marginL": {
//					"valText": "false"
//				},
//				"marginR": {
//					"valText": "false"
//				},
//				"marginT": {
//					"valText": "false"
//				},
//				"marginB": {
//					"valText": "false"
//				},
//				"paddingL": {
//					"valText": "false"
//				},
//				"paddingR": {
//					"valText": "false"
//				},
//				"paddingT": {
//					"valText": "false"
//				},
//				"paddingB": {
//					"valText": "false"
//				},
//				"attach": {
//					"valText": "false"
//				}
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}