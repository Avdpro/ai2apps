//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BoxAIChat} from "./BoxAIChat.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
import {BtnText} from "/@StdUI/ui/BtnText.js";
/*#{1HAMRK4MB0StartDoc*/
import pathLib from "/@path";
import Base64 from "/@tabos/utils/base64.js";
import {tabFS} from "/@tabos";
import {tabNT} from "/@tabos/tabos_nt.js";
import {DlgLogin} from "/@homekit/ui/DlgLogin.js";
import {DlgMenu} from "/@StdUI/ui/DlgMenu.js";
import {DlgFile} from "/@homekit/ui/DlgFile.js";
import {BoxAIChatBlock} from "./BoxAIChatBlock.js";
import {BoxAskUser} from "./BoxAskUser.js";
import {BoxChatBubble} from "./BoxChatBubble.js";
import {BtnChatAsset} from "/@aichat/ui/BtnChatAsset.js";

async function arrayBuffer(file){
	if(file.arrayBuffer){
		return file.arrayBuffer();
	}
	return new Promise((onDone,onError)=>{
		let reader=new FileReader();
		reader.onload=function(event) {
			let arrayBuffer = event.target.result;
			onDone(arrayBuffer);
		};
		reader.readAsArrayBuffer(file);
	})
}
/*}#1HAMRK4MB0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let UIChat=function(opts){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let boxUIView,boxChatView,boxChatFrame,boxChats,boxUser,btnLocalFile,btnNativeFile,edUserInput,txtInputHint,boxAssets,btnShowChats,boxChatMark;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1HAMRK4MB1LocalVals*/
	const app=VFACT.app;
	opts=opts||{};
	let chatCallback=null;
	let uiView=null;
	let uiViewMode='';
	let uiViewCallback=null;
	let uiViewCallerror=null;
	let initVO=null;
	let allowEmptyChat=false;
	let chatThread=null;
	let chatClient=null;
	let viewMap=new Map();
	/*}#1HAMRK4MB1LocalVals*/
	
	/*#{1HAMRK4MB1PreState*/
	/*}#1HAMRK4MB1PreState*/
	state={
		"defAssistant":{
			"colorBG":cfgColor["success"]
		},
		/*#{1HAMRK4MB7ExState*/
		/*}#1HAMRK4MB7ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1HAMRK4MB1PostState*/
	/*}#1HAMRK4MB1PostState*/
	cssVO={
		"hash":"1HAMRK4MB1",nameHost:true,
		"type":"hud","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
		children:[
			{
				"hash":"1J0KGVV2Q0",
				"type":"hud","id":"BoxUIView","position":"relative","x":0,"y":0,"w":"100%","h":">calc(100% - 30px)","display":0,"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"",
			},
			{
				"hash":"1J0PGLOO30",
				"type":"hud","id":"BoxChatView","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				children:[
					{
						"hash":"1J0PGOFVV0",
						"type":"box","id":"BoxChatBG","x":0,"y":0,"w":"100%","h":"100%","display":0,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":[255,255,255,1],
						"border":2,"borderColor":cfgColor["fontBodyLit"],"corner":10,"shadow":true,"shadowX":0,"shadowY":6,"shadowBlur":6,"shadowSpread":3,"shadowColor":[0,0,0,0.15],
					},
					{
						"hash":"1HAMRQ87E0",
						"type":"hud","id":"BoxChatFrame","x":0,"y":0,"w":"100%","h":"100%","overflow":"auto-y","padding":[5,0,60,0],"minW":"","minH":"","maxW":"","maxH":">calc(100% - 30px)",
						"styleClass":"","contentLayout":"flex-y",
						children:[
							{
								"hash":"1HAMRU2MG0",
								"type":BoxAIChat(),"id":"BoxChats","position":"relative","x":0,"y":0,"w":"100%","h":"",
							}
						],
					}
				],
				"OnClick":function(event){
					/*#{1J0SD3HMN0FunctionBody*/
					if(uiView){
						self.hideChats();
					}
					/*}#1J0SD3HMN0FunctionBody*/
				},
			},
			{
				"hash":"1HAMROHSE0",
				"type":"box","id":"BoxUser","x":"50%","y":">calc(100% - 20px)","w":">calc(100% - 80px)","h":"","anchorX":1,"anchorY":2,"minW":"","minH":40,"maxW":600,
				"maxH":"","styleClass":"","background":[255,255,255,1],"corner":3,"shadow":true,"shadowX":0,"shadowY":1,"shadowBlur":4,"shadowColor":[0,0,0,0.3],"contentLayout":"flex-y",
				children:[
					{
						"hash":"1HAMROHSE2",
						"type":"hud","id":"BoxInput","position":"relative","x":0,"y":0,"w":"100%","h":"","padding":[5,10,5,10],"minW":"","minH":20,"maxW":"","maxH":"","styleClass":"",
						"contentLayout":"flex-x","traceSize":true,"itemsAlign":1,
						children:[
							{
								"hash":"1HBHSL4O70",
								"type":"hud","id":"BoxFileBtnsFrame","position":"relative","x":0,"y":0,"w":20,"h":20,"display":0,"overflow":1,"margin":[0,5,0,0],"minW":"","minH":"",
								"maxW":"","maxH":"","styleClass":"",
								children:[
									{
										"hash":"1HBHSOUU60",
										"type":"hud","id":"BoxButtons","x":0,"y":20,"w":20,"h":40,"anchorY":2,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
										children:[
											{
												"hash":"1HBHSRIG70",
												"type":"box","x":-3,"y":-3,"w":">calc(100% + 6px)","h":">calc(100% + 6px)","display":0,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
												"background":cfgColor["body"],"border":1,"borderColor":cfgColor["fontBodyLit"],"corner":3,"shadow":true,"shadowX":0,"shadowBlur":5,"shadowColor":[0,0,0,0.3],
											},
											{
												"hash":"1HBHSPMP80",
												"type":BtnIcon("front",20,0,appCfg.sharedAssets+"/folder.svg",null),"id":"BtnLocalFile","x":0,"y":20,"margin":[0,5,0,0],"padding":0,"autoLayout":true,
												"OnClick":function(event){
													/*#{1HBHSPMP94FunctionBody*/
													self.showFileMenu(this);
													//self.useLocalFile();
													/*}#1HBHSPMP94FunctionBody*/
												},
											},
											{
												"hash":"1HBHSQC010",
												"type":BtnIcon("front",20,0,appCfg.sharedAssets+"/upload.svg",null),"id":"BtnNativeFile","x":0,"y":0,"display":0,"margin":[0,5,0,0],"padding":0,
												"autoLayout":true,
												/*#{1HBHSQC010Codes*/
												"labelHtml": '<input type="file" multiple="false" style="width:0px">',
												OnLableAction:function(){
													let files=[],i,n;
													n=this.files.length;
													for(i=0;i<n;i++){
														files.push(this.files[i]);
													}
													self.useNativeFile(files[0]);
													this.value="";
												}
												/*}#1HBHSQC010Codes*/
											}
										],
									}
								],
								"OnMouseInOut":function(isIn,event){
									/*#{1HBHU0P700FunctionBody*/
									/*if(isIn){
										self.showFace("filemenu");
									}else{
										self.showFace("!filemenu");
									}*/
									/*}#1HBHU0P700FunctionBody*/
								},
							},
							{
								"hash":"1HAMROHSG7",
								"type":"memo","id":"EdUserInput","position":"relative","x":0,"y":0,"w":">calc(100% - 100px)","h":"","minW":"","minH":20,"maxW":"","maxH":200,"styleClass":"",
								"color":cfgColor["fontBody"],"background":cfgColor["body"],"fontSize":txtSize.mid,"outline":0,"border":[0,0,1,0],"borderColor":[0,0,0,0.5],"flex":true,
								"OnInput":function(){
									/*#{1HAMROHSG15FunctionBody*/
									txtInputHint.display=!this.text.trimRight();
									/*}#1HAMROHSG15FunctionBody*/
								},
								"OnKeyDown":function(event){
									/*#{1HAMROHSG17FunctionBody*/
									if(event.code==="Enter"){
										if((!event.isComposing) &&(!event.shiftKey)){
											event.stopPropagation();
											event.preventDefault();
											self.sendChat();
										}
									}
									/*}#1HAMROHSG17FunctionBody*/
								},
							},
							{
								"hash":"1HAMROHSH0",
								"type":BtnIcon("front",30,0,appCfg.sharedAssets+"/send.svg",null),"id":"BtnSend","position":"relative","x":0,"y":0,"margin":[0,0,0,10],"padding":2,
								"autoLayout":true,
								"OnClick":function(event){
									/*#{1HAMROHSH9FunctionBody*/
									self.sendChat();
									/*}#1HAMROHSH9FunctionBody*/
								},
							},
							{
								"hash":"1HAMROHSH13",
								"type":"text","id":"TxtInputHint","x":18,"y":0,"w":100,"h":"100%","uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodyLit"],
								"text":"Input chat message...","fontSize":txtSize.mid,"fontWeight":"normal","fontStyle":"italic","textDecoration":"","alignV":1,
							}
						],
					},
					{
						"hash":"1HAMROHSI11",
						"type":"hud","id":"BoxWait","position":"relative","x":0,"y":0,"w":"100%","h":"","display":0,"minW":"","minH":30,"maxW":"","maxH":"","styleClass":"",
						"contentLayout":"flex-y","itemsAlign":1,"subAlign":1,
						children:[
							{
								"hash":"1HAMROHSI13",
								"type":"text","position":"relative","x":0,"y":0,"w":"100%","h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodyLit"],
								"text":"AI is thinking...","fontSize":txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignH":1,"alignV":1,
							},
							{
								"hash":"1HAMROHSJ6",
								"type":BtnText("primary",100,25,"Abort",false,""),"id":"BtnAbort","position":"relative","x":0,"y":0,
								"OnClick":function(event){
									/*#{1HAMROHSJ15FunctionBody*/
									self.abortChat();
									/*}#1HAMROHSJ15FunctionBody*/
								},
							}
						],
					},
					{
						"hash":"1IMNBNUAP0",
						"type":"hud","id":"BoxAssets","position":"relative","x":0,"y":0,"w":"100%","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
					},
					{
						"hash":"1J0PJCUQQ0",
						"type":"box","x":-50,"y":"50%","w":40,"h":40,"anchorY":1,"display":0,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":[255,255,255,1],
						"corner":6,"shadow":true,"shadowX":0,"shadowY":1,"shadowBlur":4,"shadowColor":[0,0,0,0.3],
						children:[
							{
								"hash":"1J0PJGNP80",
								"type":BtnIcon("front",36,0,appCfg.sharedAssets+"/update.svg",null),"id":"BtnShowChats","x":"50%","y":"50%","anchorX":1,"anchorY":1,"rotate":180,
								"padding":2,
								"OnClick":function(event){
									/*#{1J0R0IEES0FunctionBody*/
									if(uiViewMode==="ChatView"){
										self.hideChats();
									}else{
										self.showChats();
									}
									/*}#1J0R0IEES0FunctionBody*/
								},
							},
							{
								"hash":"1J0TOFQNJ0",
								"type":"box","id":"BoxChatMark","x":">calc(100% - 10px)","y":8,"w":10,"h":10,"anchorX":1,"anchorY":1,"display":0,"uiEvent":-1,"minW":"","minH":"",
								"maxW":"","maxH":"","styleClass":"","background":cfgColor["error"],"corner":10,
							}
						],
					}
				],
			}
		],
		get $$defAssistant(){return state["defAssistant"]},
		set $$defAssistant(v){
			state["defAssistant"]=v;
			/*#{1HAMRK4MB1SetdefAssistant*/
			/*}#1HAMRK4MB1SetdefAssistant*/
		},
		/*#{1HAMRK4MB1ExtraCSS*/
		/*}#1HAMRK4MB1ExtraCSS*/
		faces:{
			"start":{
				/*BoxUser*/"#1HAMROHSE0":{
					"display":1
				},
				/*BoxInput*/"#1HAMROHSE2":{
					"display":0
				},
				/*BoxWait*/"#1HAMROHSI11":{
					"display":0
				}
			},"input":{
				/*BoxUser*/"#1HAMROHSE0":{
					"display":1
				},
				/*BoxInput*/"#1HAMROHSE2":{
					"display":1
				},
				/*BoxWait*/"#1HAMROHSI11":{
					"display":0
				}
			},"wait":{
				/*BoxInput*/"#1HAMROHSE2":{
					"display":0
				},
				/*BoxWait*/"#1HAMROHSI11":{
					"display":1
				}
			},"filemenu":{
				/*BoxFileBtnsFrame*/"#1HBHSL4O70":{
					"overflow":0
				},
				"#1HBHSRIG70":{
					"display":1
				},
				/*BtnLocalFile*/"#1HBHSPMP80":{
					"display":1
				},
				/*BtnNativeFile*/"#1HBHSQC010":{
					"display":1
				}
			},"!filemenu":{
				/*BoxFileBtnsFrame*/"#1HBHSL4O70":{
					"overflow":1
				},
				"#1HBHSRIG70":{
					"display":0
				},
				/*BtnNativeFile*/"#1HBHSQC010":{
					"display":0
				}
			},"allowfile":{
				/*BoxFileBtnsFrame*/"#1HBHSL4O70":{
					"display":1
				},
				/*TxtInputHint*/"#1HAMROHSH13":{
					"x":40
				}
			},"!allowfile":{
				/*BoxFileBtnsFrame*/"#1HBHSL4O70":{
					"display":0
				},
				/*TxtInputHint*/"#1HAMROHSH13":{
					"x":18
				}
			},"dormant":{
				/*BoxInput*/"#1HAMROHSE2":{
					"display":0
				},
				/*BoxWait*/"#1HAMROHSI11":{
					"display":1
				},
				"#1HAMROHSI13":{
					"text":(($ln==="CN")?("对话已结束"):("Conversation has ended"))
				},
				/*BtnAbort*/"#1HAMROHSJ6":{
					"display":0
				}
			},"chatWithUI":{
				/*BoxUIView*/"#1J0KGVV2Q0":{
					"display":1
				},
				/*BoxChatView*/"#1J0PGLOO30":{
					"w":"100%","display":1,"h":"100%","x":0,"y":0
				},
				/*BoxChatBG*/"#1J0PGOFVV0":{
					"display":1,"x":25,"y":80,"w":">calc(100% - 50px)","h":">calc(100% - 90px)"
				},
				/*BoxChatFrame*/"#1HAMRQ87E0":{
					"h":">calc(100% - 110px)","y":90,"maxH":"100%","w":">calc(100% - 70px)","x":35
				},
				/*BoxUser*/"#1HAMROHSE0":{
					"x":">calc(50% + 25px)","w":">calc(100% - 130px)"
				},
				"#1J0PJCUQQ0":{
					"display":1
				}
			},"chatView":{
				/*BoxChatView*/"#1J0PGLOO30":{
					"display":1
				},
				/*BoxChatBG*/"#1J0PGOFVV0":{
					"display":1
				},
				/*BoxChatFrame*/"#1HAMRQ87E0":{
					"display":1
				},
				/*BtnShowChats*/"#1J0PJGNP80":{
					"rotate":180
				},
				/*BoxChatMark*/"#1J0TOFQNJ0":{
					"display":0
				},
				/*#{1J0KH3TAF0Code*/
				$(){
					uiViewMode="ChatView";
				}
				/*}#1J0KH3TAF0Code*/
			},"uiView":{
				/*BoxUIView*/"#1J0KGVV2Q0":{
					"display":1
				},
				/*BoxChatView*/"#1J0PGLOO30":{
					"display":0
				},
				/*BtnShowChats*/"#1J0PJGNP80":{
					"rotate":0
				},
				/*#{1J0KH46IF0Code*/
				$(){
					uiViewMode="UIView";
				}
				/*}#1J0KH46IF0Code*/
			},"showChat":{
				/*BoxUser*/"#1HAMROHSE0":{
					"display":1
				},
				/*BoxInput*/"#1HAMROHSE2":{
					"display":1
				},
				/*BoxWait*/"#1HAMROHSI11":{
					"display":0
				}
			},"hideChat":{
				/*BoxUser*/"#1HAMROHSE0":{
					"display":0
				}
			},"chatWithoutUI":{
				/*BoxUIView*/"#1J0KGVV2Q0":{
					"display":0
				},
				/*BoxChatView*/"#1J0PGLOO30":{
					"display":1,"w":"100%","h":"100%","x":0,"y":0
				},
				/*BoxChatBG*/"#1J0PGOFVV0":{
					"display":0
				},
				/*BoxChatFrame*/"#1HAMRQ87E0":{
					"display":1,"x":0,"y":0,"w":"100%","h":"100%","maxH":">calc(100% - 30px)"
				},
				"#1J0PJCUQQ0":{
					"display":0
				}
			}
		},
		OnCreate:function(){
			self=this;
			boxUIView=self.BoxUIView;boxChatView=self.BoxChatView;boxChatFrame=self.BoxChatFrame;boxChats=self.BoxChats;boxUser=self.BoxUser;btnLocalFile=self.BtnLocalFile;btnNativeFile=self.BtnNativeFile;edUserInput=self.EdUserInput;txtInputHint=self.TxtInputHint;boxAssets=self.BoxAssets;btnShowChats=self.BtnShowChats;boxChatMark=self.BoxChatMark;
			/*#{1HAMRK4MB1Create*/
			let blockDef;
			app.boxChats=boxChats;
			edUserInput.text="";
			txtInputHint.display=true;
			self.showFace("start");
			
			if(opts.bubble){
				blockDef=BoxChatBubble;
			}else{
				blockDef=BoxAIChatBlock;
			}
			if(opts.appendProcessBlock){
				boxChats.appendProcessBlock=opts.appendProcessBlock;
			}
			//Init blocks:
			boxChats.initBlockDef({
			},{
				"chatInput":self.chatInput,
				"addChatAsset":self.addChatAsset,
				"endChatInput":self.endChatInput,
				"cancelChatInput":self.cancelChatInput,
				"showUIView":self.showUIView,
			});
			/*}#1HAMRK4MB1Create*/
		},
		/*#{1HAMRK4MB1EndCSS*/
		/*}#1HAMRK4MB1EndCSS*/
	};
	/*#{1HAMRK4MB1PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.initChat=async function(vo,run=true){
		let session,url,bot,arg;
		initVO=vo;
		url=vo.url||vo.bot;
		arg=vo.argument||vo.arguments||vo.args||vo.arg||"";
		self.showFace("start");
		chatClient=vo.chatClient;
		chatThread=vo.chatThread;
		if(!chatClient && chatThread){
			chatClient=chatThread.client;
		}
		if(!(await tabNT.checkLogin(true,true))){
			if(!(await tabNT.maybePreview())){
				let res=await tabNT.makeCall("checkAICallStatus",{},5000);
				if(res.code!==200){
					let rootApp;
					rootApp=app.appFrame?app.appFrame.app:app;
					if(!(await rootApp.modalDlg(DlgLogin,{x:rootApp.width/2,y:100,alignH:1}))){
						boxChats.appendChatBlock({type:"error",text:(($ln==="CN")?("请先登录Tab-OS以使用与AI相关的API。"):/*EN*/("Please login Tab-OS first to use AI related APIs."))});
						app.emit("SessionLoadError",(($ln==="CN")?("请先登录Tab-OS以使用与AI相关的API。"):/*EN*/("Please login Tab-OS first to use AI related APIs.")));
						return;
					}
					await tabNT.checkLogin(false);
				}
				app.emit("UpdateTokenGas");
			}
			boxChats.appendChatBlock({type:"system",text:(($ln==="CN")?("正在使用预览账户模式，对话将消耗分享预览者的能量。"):/*EN*/("Using preview account mode, the conversation will consume the gas of the preview sharer."))});
			app.emit("PreviewLogin");
			app.emit("UpdateTokenGas");
		}
		if(chatThread){
			chatThread.on("UserReply",(result)=>{
				//TODO: Code this:
			});
			self.session=session=await boxChats.initSessionWithThread(url,chatThread);
		}else{
			self.session=session=await boxChats.initSession(url,true,false,vo.json);
		}
		if(vo && vo.setup){
			await vo.setup(session,chatThread);
		}
		app.emit("SessionReady",session);
		session.on("NewChatBlock",(vo)=>{
			if(uiViewMode==="UIView" && vo.role!=="wait" && vo.role!=="user"){
				boxChatMark.display=1;
				boxChatMark.scale=1.5;
				boxChatMark.animate({type:"pose",scale:1,time:80});
			}
		});
		if(run){
			return await self.startSession(session,arg);
		}
		return session;
	};
	
	//------------------------------------------------------------------------
	cssVO.initChatThread=async function(thread,vo){
		if(!(await tabNT.checkLogin(true,true))){
			if(!(await tabNT.maybePreview())){
				let res=await tabNT.makeCall("checkAICallStatus",{},5000);
				if(res.code!==200){
					let rootApp;
					rootApp=app.appFrame?app.appFrame.app:app;
					if(!(await rootApp.modalDlg(DlgLogin,{x:rootApp.width/2,y:100,alignH:1}))){
						boxChats.appendChatBlock({type:"error",text:(($ln==="CN")?("请先登录Tab-OS以使用与AI相关的API。"):/*EN*/("Please login Tab-OS first to use AI related APIs."))});
						app.emit("SessionLoadError",(($ln==="CN")?("请先登录Tab-OS以使用与AI相关的API。"):/*EN*/("Please login Tab-OS first to use AI related APIs.")));
						return;
					}
					await tabNT.checkLogin(false);
				}
				app.emit("UpdateTokenGas");
			}
			boxChats.appendChatBlock({type:"system",text:(($ln==="CN")?("正在使用预览账户模式，对话将消耗分享预览者的能量。"):/*EN*/("Using preview account mode, the conversation will consume the gas of the preview sharer."))});
			app.emit("PreviewLogin");
			app.emit("UpdateTokenGas");
		}
		self.session=null;
		self.chatThread=chatThread=thread;
		if(thread.state==="dormant"){
			self.showFace("dormant");
		}
		await boxChats.initThread(thread);
		if(vo && vo.setup){
			await vo.setup(null,thread);
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.startChat=async function(url,arg=""){
		let result,session;
		session=self.session;
		if(!session){
			throw Error("AI session is not ready.");
		}
		app.emit("StartAgent",session);
		result=await boxChats.execChat(url,arg);
		app.emit("EndAgent",session,url,result);
	};
	
	//------------------------------------------------------------------------
	cssVO.startSession=async function(session,arg=""){
		let bot,result;
		bot=session.entryBot;
		if(!bot){
			return;
		}
		console.log("!!!");
		console.log(bot.allowFile);
		if(bot.isAIChatBot){
			if(bot.allowFile){
				self.showFace("allowfile");
			}else{
				self.showFace("!allowfile");
			}
			self.showFace("input");
			edUserInput.focus();
		}else if(bot.isAIAgent){
			if(opts.allowFile){
				self.showFace("allowfile");
			}
			if(bot.autoStart && initVO.autoStart!==false){
				app.emit("StartAgent",session);
				result=await boxChats.execChat(bot.url,arg);
				app.emit("EndAgent",session,bot,result);
				return result;
			}
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.loadDebug=async function(vo,path){
		let session;
		self.showFace("start");
		if(!(await tabNT.checkLogin(false))){
			let res=await tabNT.makeCall("checkAICallStatus",{},5000);
			if(res.code!==200){
				let rootApp;
				rootApp=app.appFrame?app.appFrame.app:app;
				if(!(await rootApp.modalDlg(DlgLogin,{x:rootApp.width/2,y:100,alignH:1}))){
					boxChats.appendChatBlock({type:"error",text:(($ln==="CN")?("请先登录Tab-OS以使用与AI相关的API。"):/*EN*/("Please login Tab-OS first to use AI related APIs."))});
					app.emit("SessionLoadError",(($ln==="CN")?("请先登录Tab-OS以使用与AI相关的API。"):/*EN*/("Please login Tab-OS first to use AI related APIs.")));
					return;
				}
				await tabNT.checkLogin(false);
			}
		}
		this.session=session=await boxChats.initSession(vo.entryURL);
		await this.session.loadFromSaveVO(vo,path);
		if(session.entryBot && session.entryBot.allowFile){
			self.showFace("allowfile");
		}else{
			self.showFace("!allowfile");
		}
		app.emit("SessionReady",session);
		self.showFace("input");
		edUserInput.focus();
	};
	
	//------------------------------------------------------------------------
	cssVO.showFileMenu=async function(sender){
		let items,item;
		items=[
			{
				text:(($ln==="CN")?("从设备原生OS种选择"):/*EN*/("Choose from Native OS")),code:"NativeOS",
				labelHtml:'<input type="file" multiple="true" style="width:0px">',
				OnLabelAction(html){
					let item=this;
					item.file=html.files;
				}
			},
			{text:(($ln==="CN")?("从Tab-OS文件系统中选择"):/*EN*/("Choose from Tab-OS")),code:"TabOS"},
		];
		item=await app.modalDlg("/@StdUI/ui/DlgMenu.js",{items:items,hud:sender});
		if(item){
			if(item.code==="TabOS"){
				let path;
				path="/";
				path=await app.modalDlg("/@StdUI/ui/DlgFile.js",{
					path:path,
					title:(($ln==="CN")?("添加附件文件"):/*EN*/("Add asset")),
					buttonText:/*EN*/("Add")
				});
				if(path){
					let buf;
					buf=await tabFS.readFile(path);
					buf=Base64.encode(buf);
					await self.addChatAssetFile(pathLib.basename(path),buf);
				}
			}else if(item.code==="NativeOS" && item.file){
				for(let file of item.file){
					await self.addChatAssetFileChunked(file.name, file);
				}
			}
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.addChatAssetFile=async function(fileName,fileData){
		let res,line,hubURL;
		res=await tabNT.makeCall("AhFileSave",{fileName:fileName,data:fileData});
		if(!res || res.code!==200){
			if(res && res.info){
				window.alert("Upload file to agent hub error: "+res.info);
			}else{
				window.alert("Upload file to agent hub error.");
			}
			return;
		}
		hubURL="hub://"+res.fileName;
		self.addChatAsset(fileName,hubURL,null,fileData);
		return;
		line=boxAssets.appendNewChild({
			type:BtnChatAsset({text:fileName}),margin:[3,5,3,5],
			assetName:fileName,assetUrl:hubURL,assetData:fileData,
			OnClick(){
				let text=edUserInput.text;
				text+=" "+hubURL+" ";
				edUserInput.text=text;
				txtInputHint.display=false;
			},
			OnDelete(){
				boxAssets.removeChild(line);
			}
		});
	};

	//------------------------------------------------------------------------
	// 分块上传大文件，避免内存溢出
	cssVO.addChatAssetFileChunked=async function(fileName, file, maxChunkSize = 1048576){
		try {
			let fileSize = file.size;
			let hubURL;

			// 小文件直接使用原方法
			if (fileSize <= maxChunkSize) {
				let buf = await arrayBuffer(file);
				buf = Base64.encode(buf);
				return await self.addChatAssetFile(fileName, buf);
			}

			// 大文件使用分块上传
			let chunkSize = maxChunkSize;
			let totalChunks = Math.ceil(fileSize / chunkSize);

			// 开始分块上传
			let startRes = await tabNT.makeCall("AhFileStartChunked", {
				fileName: fileName,
				totalSize: fileSize,
				chunkSize: chunkSize
			});

			if (!startRes || startRes.code !== 200) {
				if (startRes && startRes.info) {
					window.alert("Start chunked upload error: " + startRes.info);
				} else {
					window.alert("Start chunked upload error.");
				}
				return;
			}

			let uploadId = startRes.uploadId;
			let finalFileName = startRes.fileName;

			// 分块上传每个chunk
			for (let i = 0; i < totalChunks; i++) {
				let start = i * chunkSize;
				let end = Math.min(start + chunkSize, fileSize);
				let chunk = file.slice(start, end);

				let chunkBuffer = await arrayBuffer(chunk);
				let chunkBase64 = Base64.encode(chunkBuffer);

				let chunkRes = await tabNT.makeCall("AhFileUploadChunk", {
					uploadId: uploadId,
					chunkIndex: i,
					data: chunkBase64
				});

				if (!chunkRes || chunkRes.code !== 200) {
					if (chunkRes && chunkRes.info) {
						window.alert(`Upload chunk ${i + 1}/${totalChunks} error: ` + chunkRes.info);
					} else {
						window.alert(`Upload chunk ${i + 1}/${totalChunks} error.`);
					}
					return;
				}
				console.log(`Uploaded chunk ${i + 1}/${totalChunks} (${chunkRes.receivedSize}/${chunkRes.totalSize})`);
			}

			// 完成分块上传
			let finishRes = await tabNT.makeCall("AhFileFinishChunked", {
				uploadId: uploadId
			});

			if (!finishRes || finishRes.code !== 200) {
				if (finishRes && finishRes.info) {
					window.alert("Finish chunked upload error: " + finishRes.info);
				} else {
					window.alert("Finish chunked upload error.");
				}
				return;
			}

			hubURL = "hub://" + finishRes.fileName;
			self.addChatAsset(fileName, hubURL, null, null); // 大文件不保存fileData到内存

		} catch (error) {
			console.error("Chunked upload error:", error);
			window.alert("文件上传失败: " + error.message);
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.useLocalFile=async function(){
		let path,item;
		path=pathLib.dirname(this.session.entryBot.url);
		if(path.startsWith("/~/")){
			path=path.substring(2);
		}else if(path.startsWith("//")){
			path=path.substring(1);
		}
		item=await app.modalDlg(DlgMenu,{
			hud:self.BtnLocalFile,
			items:[
				{text:(($ln==="CN")?("使用文件路径"):/*EN*/("Use file path")),code:"path"},
				{text:(($ln==="CN")?("使用文件内容"):/*EN*/("Use file content")),code:"content"},
			]
		});
		if(!item){
			return;
		}
	
		path=await app.modalDlg(DlgFile,{
			mode:"open",
			path:path,
			options:{preview:1},
		});
		if(!path){
			return;
		}
		if(item.code==="path"){
			edUserInput.text+=`\$\{\{file:${path}\}\}`;
		}else{
			let text;
			try{
				text=await tabFS.readFile(path,"utf8");
				edUserInput.text+="\n```\n"+text+"\n```\n";
			}catch(err){
			}
		}
		edUserInput.OnInput();
	};
	
	//------------------------------------------------------------------------
	cssVO.useNativeFile=async function(file){
		let buf,byteAry,text;
		if(!file){
			return;
		}
		try{
			buf=await arrayBuffer(file);
			byteAry = new Uint8Array(buf);
			let enc = new TextDecoder("utf-8");
			text=enc.decode(byteAry);
			edUserInput.text+="\n```\n"+text+"\n```\n";
			edUserInput.OnInput();
		}catch(err){
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.chatInput=function(vo){
		let pms,text,orgText;
		self.showFace("input");
		orgText=edUserInput.text;
		if(vo.maybeText){
			text=orgText||vo.maybeText;				
		}else{
			text=vo.text;
		}
		if(vo.allowFile){
			self.showFace("allowfile");
		}else{
			self.showFace("!allowfile");
		}
		edUserInput.text=text||"";
		txtInputHint.text=vo.placeholder||(($ln==="CN")?("输入信息..."):/*EN*/("Input chat message..."));
		if(text && text.trimRight()){
			txtInputHint.display=false;
		}else{
			txtInputHint.display=true;
		}
		allowEmptyChat=vo.allowEmpty||false;
		if(vo.waitInput===false){
			if(text!==orgText){
				edUserInput.focus();
			}
			return;
		}
		edUserInput.focus();
		pms=new Promise((resolve,reject)=>{
			chatCallback=resolve;
		});
		return pms;
	};
	
	//------------------------------------------------------------------------
	cssVO.addChatAsset=async function(fileName,hubUrl,promptFix,assetData){
		let line;
		assetData=assetData||null
		line=boxAssets.appendNewChild({
			type:BtnChatAsset({text:fileName}),margin:[3,5,3,5],
			assetName:fileName,assetUrl:hubUrl,assetData:assetData,
			OnClick(){
				let text=edUserInput.text;
				text+=" "+hubUrl+" ";
				edUserInput.text=text;
				txtInputHint.display=false;
			},
			OnDelete(){
				boxAssets.removeChild(line);
			}
		});
		if(promptFix){
			let text=edUserInput.text;
			text+=" "+promptFix+" ";
			edUserInput.text=text;
			txtInputHint.display=false;
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.cancelChatInput=cssVO.endChatInput=function(result){
		let callback;
		callback=chatCallback;
		boxAssets.clearChildren();
		if(callback){
			chatCallback=null;
			callback(result||null);
			self.showFace("start");
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.sendChat=async function(){
		let text,callback,assets;
		text=edUserInput.text;
		if(!text && !allowEmptyChat){
			return;
		}
		assets=[];
		{
			let list,i,n,line,url;
			list=boxAssets.children;
			n=list.length;
			for(i=0;i<n;i++){
				line=list[i];
				url=line.assetUrl;
				if(url){
					assets.push(url);
				}
			}
			assets=assets.length?assets:null;
		}
		callback=chatCallback;
		if(callback){
			let result;
			chatCallback=null;
			if(assets){
				boxAssets.clearChildren();
				result={prompt:text,assets:assets};
			}else{
				result=text;
			}
			callback(result);
			self.showFace("start");
			return;
		}
		self.showFace("wait");
		app.emit("StartChat");
		try{
			await boxChats.execChat(null,text);
		}catch(err){
		}
		edUserInput.text="";
		txtInputHint.display=true;
		self.showFace("input");
		app.emit("EndChat");
		app.emit("CheckCY");
		edUserInput.focus();
	};
	
	//------------------------------------------------------------------------
	cssVO.resetChat=async function(){
		let session,bot;
		edUserInput.text="";
		txtInputHint.display=true;
		self.session=session=await boxChats.resetChat();
		await self.startSession(session);
	};
	
	//------------------------------------------------------------------------
	cssVO.clearChats=async function(){
		boxChats.clearChats();
		edUserInput.text="";
		txtInputHint.display=true;
		self.showFace("input");
		edUserInput.focus();
		app.emit("SessionReady",boxChats.session);
	};
	
	//------------------------------------------------------------------------
	cssVO.abortChat=async function(){
		await boxChats.abortChat((($ln==="CN")?("用户终止"):/*EN*/("User abort")));
	};
	
	//------------------------------------------------------------------------
	cssVO.showUIView=async function(uiDef,startArgs,opts){
		let view,pms,viewPms,result,callback;
		if(typeof uiDef==="string"){
			uiDef=(await import(uiDef)).default;
		}else if(!uiDef){
			uiDef=uiView;
		}
		//TODO: If host client, send thread message:
		if(opts.package){
			//TODO: ensure package
		}
		pms=new Promise((resolve,reject)=>{
			uiViewCallback=callback=resolve;
			uiViewCallerror=reject;
		});
		if(uiDef instanceof Function){
			view=viewMap.get(uiDef);
			if(uiView===view){
				//Do nothing...
			}else{
				let def;
				def=uiDef(self.session);
				boxUIView.clearChildren();
				if(view){
					boxUIView.appendChild(view);
				}else{
					view=boxUIView.appendNewChild(def);
					view.hold();
					viewMap.set(uiDef,view);
				}
			}
		}else if(uiDef.webObj){//View obj
			view=uiDef;
			if(uiView!==view){
				boxUIView.clearChildren();
				boxUIView.appendChild(view);
			}else{
				//Do nothin...?
			}
		}
		uiView=view;
		self.session.uiView=view;
		self.showFace("chatWithUI");
		if(opts.showChats){
			self.showFace("uiChat");
		}else{
			self.showFace("uiView");
		}
		viewPms=view.showChatView(startArgs);
		if(opts.withChat){
			let chatPms;
			btnShowChats.enable=true;
			boxChatView.OnClick=self.hideChats;
			chatPms=self.chatInput(opts.chatOpts||{});
			result=await Promise.any([viewPms,chatPms]);
			chatCallback=null;
			if(typeof(result)==="string" || (!result.command && result.prompt)){
				await self.session.addChatText("user",result.prompt||result,{});
			}
			self.cancelChatInput();
			if(view.cancelViewCallback){
				view.cancelViewCallback();
			}
			if(uiViewCallback===callback){
				uiViewCallback=null;
				uiViewCallerror=null;
				callback(result);
			}
		}else{
			self.showFace("hideChat");
			result=await viewPms;
			self.showFace("hideChat");
			if(uiViewCallback===callback){
				uiViewCallback=null;
				uiViewCallerror=null;
				callback(result);
			}
		}
		self.showFace("chatView");
		if(opts.modalWork!==false){
			btnShowChats.enable=false;
			boxChatView.OnClick=null;
		}else{
			btnShowChats.enable=true;
			boxChatView.OnClick=self.hideChats;
		}
		return await pms;
	};
	
	//------------------------------------------------------------------------
	cssVO.showChats=function(){
		self.showFace("chatView");
		boxChatView.animate({type:"in",dy:100,alpha:0,time:100});
	};
	
	//------------------------------------------------------------------------
	cssVO.hideChats=function(){
		boxChatView.animate({
			type:"out",dy:100,alpha:0,time:100,
			OnFinish(){
				self.showFace("uiView");
			}
		});
	};
	/*}#1HAMRK4MB1PostCSSVO*/
	cssVO.constructor=UIChat;
	return cssVO;
};
/*#{1HAMRK4MB1ExCodes*/
/*}#1HAMRK4MB1ExCodes*/

//----------------------------------------------------------------------------
UIChat.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1HAMRK4MB1PreAISpot*/
	/*}#1HAMRK4MB1PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="UIChat";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1HAMRK4MB1PostAISpot*/
	/*}#1HAMRK4MB1PostAISpot*/
	return exposeVO;
};

//----------------------------------------------------------------------------
UIChat.gearExport={
	framework: "jax",
	hudType: "hud",
	"showName":"UIChat",icon:"gears.svg",previewImg:false,
	fixPose:false,initW:500,initH:300,
	catalog:"Views",
	args: {
		"opts": {
			"type": "object", "name": "opts", "showName": "opts", "icon": undefined, 
			"def": {
				"attrs": {
					"bubble": {
						"name": "bubble", "showName": "bubble", "type": "bool", "key": true, "fixed": true, "initVal": false
					}, 
					"ai": {
						"type": "object", "name": "ai", "showName": "ai", "icon": undefined, 
						"def": {
							"attrs": {
								"blkColor": {
									"name": "blkColor", "showName": "blkColor", "type": "colorRGBA", "key": true, "fixed": true, 
									"initVal": [0,0,0,0]
								}, 
								"bgColor": {
									"name": "bgColor", "showName": "bgColor", "type": "colorRGBA", "key": true, "fixed": true, 
									"initVal": [0,128,0,1], "initValText": "#cfgColor[\"success\"]"
								}, 
								"icon": {
									"name": "icon", "showName": "icon", "type": "url", "key": true, "fixed": true, "initVal": "/~/-tabos/shared/assets/faces.svg", "initValText": "#appCfg.sharedAssets+\"/faces.svg\""
								}, 
								"pic": {
									"name": "pic", "showName": "pic", "type": "url", "key": true, "fixed": true, "initVal": ""
								}, 
								"textColor": {
									"name": "textColor", "showName": "textColor", "type": "colorRGBA", "key": true, "fixed": true, 
									"initVal": [0,0,0,1], "initValText": "#cfgColor[\"fontBody\"]"
								}, 
								"iconColor": {
									"name": "iconColor", "showName": "iconColor", "type": "colorRGBA", "key": true, "fixed": true, 
									"initVal": [255,255,255,1], "initValText": "#cfgColor[\"fontSuccess\"]"
								}, 
								"side": {
									"name": "side", "showName": "side", "type": "string", "key": true, "fixed": true, "initVal": "left"
								}
							}
						}, 
						"key": true, "fixed": true
					}, 
					"user": {
						"type": "object", "name": "user", "showName": "user", "icon": undefined, 
						"def": {
							"attrs": {
								"blkColor": {
									"name": "blkColor", "showName": "blkColor", "type": "colorRGBA", "key": true, "fixed": true, 
									"initVal": [0,0,0,0]
								}, 
								"bgColor": {
									"name": "bgColor", "showName": "bgColor", "type": "colorRGBA", "key": true, "fixed": true, 
									"initVal": [13,110,253,1], "initValText": "#cfgColor.primary"
								}, 
								"icon": {
									"name": "icon", "showName": "icon", "type": "url", "key": true, "fixed": true, "initVal": "/~/-tabos/shared/assets/user.svg", "initValText": "#appCfg.sharedAssets+\"/user.svg\""
								}, 
								"pic": {
									"name": "pic", "showName": "pic", "type": "url", "key": true, "fixed": true, "initVal": ""
								}, 
								"textColor": {
									"name": "textColor", "showName": "textColor", "type": "colorRGBA", "key": true, "fixed": true, 
									"initVal": [0,0,0,1], "initValText": "#cfgColor[\"fontBody\"]"
								}, 
								"iconColor": {
									"name": "iconColor", "showName": "iconColor", "type": "colorRGBA", "key": true, "fixed": true, 
									"initVal": [255,255,255,1], "initValText": "#cfgColor[\"fontPrimary\"]"
								}, 
								"side": {
									"name": "side", "showName": "side", "type": "string", "key": true, "fixed": true, "initVal": "right"
								}
							}
						}, 
						"key": true, "fixed": true
					}, 
					"wait": {
						"type": "object", "name": "wait", "showName": "wait", "icon": undefined, 
						"def": {
							"attrs": {
								"blkColor": {
									"name": "blkColor", "showName": "blkColor", "type": "colorRGBA", "key": true, "fixed": true, 
									"initVal": [0,0,0,0]
								}, 
								"bgColor": {
									"name": "bgColor", "showName": "bgColor", "type": "colorRGBA", "key": true, "fixed": true, 
									"initVal": [108,117,125,1], "initValText": "#cfgColor[\"secondary\"]"
								}, 
								"icon": {
									"name": "icon", "showName": "icon", "type": "url", "key": true, "fixed": true, "initVal": "/~/-tabos/shared/assets/faces.svg", "initValText": "#appCfg.sharedAssets+\"/faces.svg\""
								}, 
								"pic": {
									"name": "pic", "showName": "pic", "type": "url", "key": true, "fixed": true, "initVal": ""
								}, 
								"textColor": {
									"name": "textColor", "showName": "textColor", "type": "colorRGBA", "key": true, "fixed": true, 
									"initVal": [0,0,0,1], "initValText": "#cfgColor[\"fontBody\"]"
								}, 
								"iconColor": {
									"name": "iconColor", "showName": "iconColor", "type": "colorRGBA", "key": true, "fixed": true, 
									"initVal": [255,255,255,1], "initValText": "#cfgColor[\"fontSecondary\"]"
								}, 
								"side": {
									"name": "side", "showName": "side", "type": "string", "key": true, "fixed": true, "initVal": "left"
								}
							}
						}, 
						"key": true, "fixed": true
					}, 
					"event": {
						"type": "object", "name": "event", "showName": "event", "icon": undefined, 
						"def": {
							"attrs": {
								"blkColor": {
									"name": "blkColor", "showName": "blkColor", "type": "colorRGBA", "key": true, "fixed": true, 
									"initVal": [0,0,0,0]
								}, 
								"bgColor": {
									"name": "bgColor", "showName": "bgColor", "type": "colorRGBA", "key": true, "fixed": true, 
									"initVal": [255,128,12,1], "initValText": "#cfgColor[\"warning\"]"
								}, 
								"icon": {
									"name": "icon", "showName": "icon", "type": "url", "key": true, "fixed": true, "initVal": "/~/-tabos/shared/assets/event.svg", "initValText": "#appCfg.sharedAssets+\"/event.svg\""
								}, 
								"pic": {
									"name": "pic", "showName": "pic", "type": "url", "key": true, "fixed": true, "initVal": ""
								}, 
								"textColor": {
									"name": "textColor", "showName": "textColor", "type": "colorRGBA", "key": true, "fixed": true, 
									"initVal": [0,0,0,1], "initValText": "#cfgColor[\"fontBody\"]"
								}, 
								"iconColor": {
									"name": "iconColor", "showName": "iconColor", "type": "colorRGBA", "key": true, "fixed": true, 
									"initVal": [255,255,255,1], "initValText": "#cfgColor[\"fontWarning\"]"
								}, 
								"side": {
									"name": "side", "showName": "side", "type": "string", "key": true, "fixed": true, "initVal": "left"
								}
							}
						}, 
						"key": true, "fixed": true
					}, 
					"error": {
						"type": "object", "name": "error", "showName": "error", "icon": undefined, 
						"def": {
							"attrs": {
								"blkColor": {
									"name": "blkColor", "showName": "blkColor", "type": "colorRGBA", "key": true, "fixed": true, 
									"initVal": [0,0,0,0]
								}, 
								"bgColor": {
									"name": "bgColor", "showName": "bgColor", "type": "colorRGBA", "key": true, "fixed": true, 
									"initVal": [240,0,0,1], "initValText": "#cfgColor[\"error\"]"
								}, 
								"icon": {
									"name": "icon", "showName": "icon", "type": "url", "key": true, "fixed": true, "initVal": "/~/-tabos/shared/assets/fat_right.svg", "initValText": "#appCfg.sharedAssets+\"/fat_right.svg\""
								}, 
								"pic": {
									"name": "pic", "showName": "pic", "type": "url", "key": true, "fixed": true, "initVal": ""
								}, 
								"textColor": {
									"name": "textColor", "showName": "textColor", "type": "colorRGBA", "key": true, "fixed": true, 
									"initVal": [155,0,0,1]
								}, 
								"iconColor": {
									"name": "iconColor", "showName": "iconColor", "type": "colorRGB", "key": true, "fixed": true, 
									"initVal": [255,255,255,1], "initValText": "#cfgColor[\"fontError\"]"
								}, 
								"side": {
									"name": "side", "showName": "side", "type": "string", "key": true, "fixed": true, "initVal": "left"
								}
							}
						}, 
						"key": true, "fixed": true
					}, 
					"ask": {
						"type": "object", "name": "ask", "showName": "ask", "icon": undefined, 
						"def": {
							"attrs": {
								"blkColor": {
									"name": "blkColor", "showName": "blkColor", "type": "colorRGBA", "key": true, "fixed": true, 
									"initVal": [0,0,0,0]
								}, 
								"bgColor": {
									"name": "bgColor", "showName": "bgColor", "type": "colorRGBA", "key": true, "fixed": true, 
									"initVal": [0,128,0,1], "initValText": "#cfgColor[\"success\"]"
								}, 
								"icon": {
									"name": "icon", "showName": "icon", "type": "url", "key": true, "fixed": true, "initVal": "/~/-tabos/shared/assets/help.svg", "initValText": "#appCfg.sharedAssets+\"/help.svg\""
								}, 
								"pic": {
									"name": "pic", "showName": "pic", "type": "url", "key": true, "fixed": true, "initVal": ""
								}, 
								"textColor": {
									"name": "textColor", "showName": "textColor", "type": "colorRGBA", "key": true, "fixed": true, 
									"initVal": [0,0,0,1], "initValText": "#cfgColor[\"fontBody\"]"
								}, 
								"iconColor": {
									"name": "iconColor", "showName": "iconColor", "type": "colorRGBA", "key": true, "fixed": true, 
									"initVal": [255,255,255,1], "initValText": "#cfgColor[\"fontSuccess\"]"
								}, 
								"side": {
									"name": "side", "showName": "side", "type": "string", "key": true, "fixed": true, "initVal": "left"
								}
							}
						}, 
						"key": true, "fixed": true
					}, 
					"allowFile": {
						"name": "allowFile", "showName": "allowFile", "type": "bool", "key": true, "fixed": true, "initVal": false
					}, 
					"appendProcessBlock": {
						"name": "appendProcessBlock", "showName": "appendProcessBlock", "type": "auto", "key": true, "fixed": true, 
						"initVal": null
					}
				}
			}, 
			"key": true, "fixed": true
		}
	},
	state:{
		defAssistant:{name:"defAssistant",type:"object",initVal:undefined}
	},
	properties:["id","position","x","y","w","h","anchorH","anchorV","autoLayout","display","clip","uiEvent","alpha","rotate","scale","cursor","zIndex","flex","margin","traceSize","padding","minW","minH","maxW","maxH"],
	faces:["start","input","wait","filemenu","!filemenu","allowfile","!allowfile","dormant","chatWithUI","chatView","uiView","showChat","hideChat","chatWithoutUI"],
	subContainers:{
	},
	/*#{1HAMRK4MB0ExGearInfo*/
	/*}#1HAMRK4MB0ExGearInfo*/
};
/*#{1HAMRK4MB0EndDoc*/
/*}#1HAMRK4MB0EndDoc*/

export default UIChat;
export{UIChat};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1HAMRK4MB0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1HAMRK4MB2",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "500",
//				"screenH": "600",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1HAMRK4MB3",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1HAMRK4MB4",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1HAMRK4MB5",
//			"attrs": {
//				"opts": {
//					"type": "object",
//					"def": "FlatObj",
//					"jaxId": "1HB2CA95A0",
//					"attrs": {
//						"bubble": {
//							"type": "bool",
//							"valText": "false"
//						},
//						"ai": {
//							"type": "object",
//							"def": "FlatObj",
//							"jaxId": "1HB2CA95A1",
//							"attrs": {
//								"blkColor": {
//									"type": "colorRGBA",
//									"valText": "[0,0,0,0.00]"
//								},
//								"bgColor": {
//									"type": "colorRGBA",
//									"valText": "#cfgColor[\"success\"]"
//								},
//								"icon": {
//									"type": "url",
//									"valText": "#appCfg.sharedAssets+\"/faces.svg\""
//								},
//								"pic": {
//									"type": "url",
//									"valText": ""
//								},
//								"textColor": {
//									"type": "colorRGBA",
//									"valText": "#cfgColor[\"fontBody\"]"
//								},
//								"iconColor": {
//									"type": "colorRGBA",
//									"valText": "#cfgColor[\"fontSuccess\"]"
//								},
//								"side": {
//									"type": "string",
//									"valText": "left"
//								}
//							}
//						},
//						"user": {
//							"type": "object",
//							"def": "FlatObj",
//							"jaxId": "1HB2CA95A2",
//							"attrs": {
//								"blkColor": {
//									"type": "colorRGBA",
//									"valText": "[0,0,0,0.00]"
//								},
//								"bgColor": {
//									"type": "colorRGBA",
//									"valText": "#cfgColor.primary"
//								},
//								"icon": {
//									"type": "url",
//									"valText": "#appCfg.sharedAssets+\"/user.svg\""
//								},
//								"pic": {
//									"type": "url",
//									"valText": ""
//								},
//								"textColor": {
//									"type": "colorRGBA",
//									"valText": "#cfgColor[\"fontBody\"]"
//								},
//								"iconColor": {
//									"type": "colorRGBA",
//									"valText": "#cfgColor[\"fontPrimary\"]"
//								},
//								"side": {
//									"type": "string",
//									"valText": "right"
//								}
//							}
//						},
//						"wait": {
//							"type": "object",
//							"def": "FlatObj",
//							"jaxId": "1HB2J3M5P0",
//							"attrs": {
//								"blkColor": {
//									"type": "colorRGBA",
//									"valText": "[0,0,0,0.00]"
//								},
//								"bgColor": {
//									"type": "colorRGBA",
//									"valText": "#cfgColor[\"secondary\"]"
//								},
//								"icon": {
//									"type": "url",
//									"valText": "#appCfg.sharedAssets+\"/faces.svg\""
//								},
//								"pic": {
//									"type": "url",
//									"valText": ""
//								},
//								"textColor": {
//									"type": "colorRGBA",
//									"valText": "#cfgColor[\"fontBody\"]"
//								},
//								"iconColor": {
//									"type": "colorRGBA",
//									"valText": "#cfgColor[\"fontSecondary\"]"
//								},
//								"side": {
//									"type": "string",
//									"valText": "left"
//								}
//							}
//						},
//						"event": {
//							"type": "object",
//							"def": "FlatObj",
//							"jaxId": "1HB2KQCVB0",
//							"attrs": {
//								"blkColor": {
//									"type": "colorRGBA",
//									"valText": "[0,0,0,0.00]"
//								},
//								"bgColor": {
//									"type": "colorRGBA",
//									"valText": "#cfgColor[\"warning\"]"
//								},
//								"icon": {
//									"type": "url",
//									"valText": "#appCfg.sharedAssets+\"/event.svg\""
//								},
//								"pic": {
//									"type": "url",
//									"valText": ""
//								},
//								"textColor": {
//									"type": "colorRGBA",
//									"valText": "#cfgColor[\"fontBody\"]"
//								},
//								"iconColor": {
//									"type": "colorRGBA",
//									"valText": "#cfgColor[\"fontWarning\"]"
//								},
//								"side": {
//									"type": "string",
//									"valText": "left"
//								}
//							}
//						},
//						"error": {
//							"type": "object",
//							"def": "FlatObj",
//							"jaxId": "1HB2KQCVB1",
//							"attrs": {
//								"blkColor": {
//									"type": "colorRGBA",
//									"valText": "[0,0,0,0.00]"
//								},
//								"bgColor": {
//									"type": "colorRGBA",
//									"valText": "#cfgColor[\"error\"]"
//								},
//								"icon": {
//									"type": "url",
//									"valText": "#appCfg.sharedAssets+\"/fat_right.svg\""
//								},
//								"pic": {
//									"type": "url",
//									"valText": ""
//								},
//								"textColor": {
//									"type": "colorRGBA",
//									"valText": "[155,0,0,1.00]"
//								},
//								"iconColor": {
//									"type": "colorRGB",
//									"valText": "#cfgColor[\"fontError\"]"
//								},
//								"side": {
//									"type": "string",
//									"valText": "left"
//								}
//							}
//						},
//						"ask": {
//							"type": "object",
//							"def": "FlatObj",
//							"jaxId": "1HB2KQCVB2",
//							"attrs": {
//								"blkColor": {
//									"type": "colorRGBA",
//									"valText": "[0,0,0,0.00]"
//								},
//								"bgColor": {
//									"type": "colorRGBA",
//									"valText": "#cfgColor[\"success\"]"
//								},
//								"icon": {
//									"type": "url",
//									"valText": "#appCfg.sharedAssets+\"/help.svg\""
//								},
//								"pic": {
//									"type": "url",
//									"valText": ""
//								},
//								"textColor": {
//									"type": "colorRGBA",
//									"valText": "#cfgColor[\"fontBody\"]"
//								},
//								"iconColor": {
//									"type": "colorRGBA",
//									"valText": "#cfgColor[\"fontSuccess\"]"
//								},
//								"side": {
//									"type": "string",
//									"valText": "left"
//								}
//							}
//						},
//						"allowFile": {
//							"type": "bool",
//							"valText": "false"
//						},
//						"appendProcessBlock": {
//							"type": "auto",
//							"valText": "null"
//						}
//					}
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1HAMRK4MB6",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1HAMRK4MB7",
//			"attrs": {
//				"defAssistant": {
//					"type": "object",
//					"def": "Object",
//					"jaxId": "1HAVQG08H0",
//					"attrs": {
//						"colorBG": {
//							"type": "colorRGBA",
//							"valText": "#cfgColor[\"success\"]"
//						}
//					}
//				}
//			}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "UIChat",
//		"gearIcon": "gears.svg",
//		"gearW": "500",
//		"gearH": "300",
//		"gearCatalog": "Views",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1HAMRK4MB8",
//			"attrs": {
//				"start": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HAMS3KJL0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HAMS4K160",
//							"attrs": {}
//						}
//					}
//				},
//				"input": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HAMS4K161",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HAMS4K162",
//							"attrs": {}
//						}
//					}
//				},
//				"wait": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HAMS4K163",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HAMS4K164",
//							"attrs": {}
//						}
//					}
//				},
//				"filemenu": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HBHT74HN0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HBHTAIUS0",
//							"attrs": {}
//						}
//					}
//				},
//				"!filemenu": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HBHT8HLB0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HBHTAIUS1",
//							"attrs": {}
//						}
//					}
//				},
//				"allowfile": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HBHUAT3S0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HBHUC9450",
//							"attrs": {}
//						}
//					}
//				},
//				"!allowfile": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HBHUBGFH0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HBHUC9451",
//							"attrs": {}
//						}
//					}
//				},
//				"dormant": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1J0C6EPL40",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1J0C6IE7V0",
//							"attrs": {}
//						}
//					}
//				},
//				"chatWithUI": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1J0PGPU570",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1J0PH9PA90",
//							"attrs": {}
//						}
//					}
//				},
//				"chatView": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1J0KH3TAF0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1J0KH5B6O0",
//							"attrs": {}
//						}
//					}
//				},
//				"uiView": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1J0KH46IF0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "true",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1J0KH5B6O1",
//							"attrs": {}
//						}
//					}
//				},
//				"showChat": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1J0LFGC5U0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1J0LFI5GO0",
//							"attrs": {}
//						}
//					}
//				},
//				"hideChat": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1J0LFGHOU0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1J0LFI5GO1",
//							"attrs": {}
//						}
//					}
//				},
//				"chatWithoutUI": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1J0PHT3FS0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1J0PHVAVA0",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1HAMRK4MB9",
//			"attrs": {}
//		},
//		"exposeToAI": "true",
//		"descAI": "",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1HAMRK4MB1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1HAMRK4MB10",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "100%",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": ""
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1J0KGVV2Q0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1J0KH3H030",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxUIView",
//										"position": "Relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%-30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "Off",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": ""
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1J0KH3H031",
//									"attrs": {
//										"1J0KH46IF0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1J0KH5B6O2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J0KH5B6O3",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1J0KH46IF0",
//											"faceTagName": "uiView"
//										},
//										"1HAMS4K161": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1J0LFI5GO2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J0LFI5GO3",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HAMS4K161",
//											"faceTagName": "input"
//										},
//										"1HAMS3KJL0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1J0LFI5GO4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J0LFI5GO5",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HAMS3KJL0",
//											"faceTagName": "start"
//										},
//										"1J0LFGHOU0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1J0PHVAVA1",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J0PHVAVA2",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1J0LFGHOU0",
//											"faceTagName": "hideChat"
//										},
//										"1J0PGPU570": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1J0PHVAVA5",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J0PHVAVA6",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1J0PGPU570",
//											"faceTagName": "chatWithUI"
//										},
//										"1J0PHT3FS0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1J0PHVAVA7",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J0PHVAVA8",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1J0PHT3FS0",
//											"faceTagName": "chatWithoutUI"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1J0KH3H032",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1J0KH3H033",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1J0PGLOO30",
//							"attrs": {
//								"properties": {
//									"jaxId": "1J0PGORM80",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxChatView",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": ""
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1J0PGOFVV0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J0PGORM81",
//													"attrs": {
//														"type": "box",
//														"id": "BoxChatBG",
//														"position": "Absolute",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "Off",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "[255,255,255,1.00]",
//														"border": "2",
//														"borderStyle": "Solid",
//														"borderColor": "#cfgColor[\"fontBodyLit\"]",
//														"corner": "10",
//														"shadow": "true",
//														"shadowX": "0",
//														"shadowY": "6",
//														"shadowBlur": "6",
//														"shadowSpread": "3",
//														"shadowColor": "[0,0,0,0.150]"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1J0PGORM82",
//													"attrs": {
//														"1J0PGPU570": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J0PH9PAA0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J0PH9PAA1",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		},
//																		"x": {
//																			"type": "length",
//																			"valText": "25"
//																		},
//																		"y": {
//																			"type": "length",
//																			"valText": "80"
//																		},
//																		"w": {
//																			"type": "length",
//																			"valText": "100%-50"
//																		},
//																		"h": {
//																			"type": "length",
//																			"valText": "100%-90"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J0PGPU570",
//															"faceTagName": "chatWithUI"
//														},
//														"1J0LFGHOU0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J0PHVAVA9",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J0PHVAVA10",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J0LFGHOU0",
//															"faceTagName": "hideChat"
//														},
//														"1J0KH3TAF0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J0PHVAVA15",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J0PHVAVA16",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J0KH3TAF0",
//															"faceTagName": "chatView"
//														},
//														"1J0PHT3FS0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J0PHVAVA17",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J0PHVAVA18",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J0PHT3FS0",
//															"faceTagName": "chatWithoutUI"
//														},
//														"1HAMS3KJL0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J0R0J7L50",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J0R0J7L51",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAMS3KJL0",
//															"faceTagName": "start"
//														},
//														"1HAMS4K161": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J0R0J7L52",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J0R0J7L53",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAMS4K161",
//															"faceTagName": "input"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1J0PGORM83",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1J0PGORM84",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1HAMRQ87E0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HAMRSPCM0",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxChatFrame",
//														"position": "Absolute",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Auto Scroll Y",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "[5,0,60,0]",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "100%-30",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex Y"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "Gear1HA0EN6720",
//															"jaxId": "1HAMRU2MG0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1HAMRVD260",
//																	"attrs": {}
//																},
//																"properties": {
//																	"jaxId": "1HAMRVD261",
//																	"attrs": {
//																		"type": "#null#>BoxAIChat()",
//																		"id": "BoxChats",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"w": "100%",
//																		"h": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HAMRVD262",
//																	"attrs": {
//																		"1HBHT74HN0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HBHU5CAO0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HBHU5CAO1",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HBHT74HN0",
//																			"faceTagName": "filemenu"
//																		},
//																		"1HBHT8HLB0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HD6JA7JV0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HD6JA7JV1",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HBHT8HLB0",
//																			"faceTagName": "!filemenu"
//																		},
//																		"1HBHUBGFH0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IMND4CK90",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IMND4CK91",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HBHUBGFH0",
//																			"faceTagName": "!allowfile"
//																		},
//																		"1J0C6EPL40": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J0C6UATU0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J0C6UATU1",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J0C6EPL40",
//																			"faceTagName": "dormant"
//																		},
//																		"1HAMS4K161": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J0LFI5GO8",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J0LFI5GO9",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAMS4K161",
//																			"faceTagName": "input"
//																		},
//																		"1HAMS3KJL0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J0LFI5GO10",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J0LFI5GO11",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAMS3KJL0",
//																			"faceTagName": "start"
//																		},
//																		"1J0LFGHOU0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J0PHVAVA19",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J0PHVAVA20",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J0LFGHOU0",
//																			"faceTagName": "hideChat"
//																		},
//																		"1J0PHT3FS0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J0PJUG6I0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J0PJUG6I1",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J0PHT3FS0",
//																			"faceTagName": "chatWithoutUI"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HAMRVD263",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HAMRVD264",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1HAMRVD265",
//																	"attrs": {}
//																}
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1HAMRSPCM1",
//													"attrs": {
//														"1HBHT74HN0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HBHU5CAO2",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HBHU5CAO3",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HBHT74HN0",
//															"faceTagName": "filemenu"
//														},
//														"1HBHT8HLB0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HD6JA7JV2",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HD6JA7JV3",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HBHT8HLB0",
//															"faceTagName": "!filemenu"
//														},
//														"1HBHUBGFH0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IMND4CK92",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IMND4CK93",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HBHUBGFH0",
//															"faceTagName": "!allowfile"
//														},
//														"1J0C6EPL40": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J0C6UATU2",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J0C6UATU3",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J0C6EPL40",
//															"faceTagName": "dormant"
//														},
//														"1J0KH3TAF0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J0KH5B6O12",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J0KH5B6O13",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J0KH3TAF0",
//															"faceTagName": "chatView"
//														},
//														"1HAMS4K161": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J0LFI5GO14",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J0LFI5GO15",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAMS4K161",
//															"faceTagName": "input"
//														},
//														"1HAMS3KJL0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J0LFI5GO16",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J0LFI5GO17",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAMS3KJL0",
//															"faceTagName": "start"
//														},
//														"1J0PGPU570": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J0PH9PAA2",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J0PH9PAA3",
//																	"attrs": {
//																		"h": {
//																			"type": "length",
//																			"valText": "100%-110"
//																		},
//																		"y": {
//																			"type": "length",
//																			"valText": "90"
//																		},
//																		"maxH": {
//																			"type": "length",
//																			"valText": "100%"
//																		},
//																		"w": {
//																			"type": "length",
//																			"valText": "100%-70"
//																		},
//																		"x": {
//																			"type": "length",
//																			"valText": "35"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J0PGPU570",
//															"faceTagName": "chatWithUI"
//														},
//														"1J0LFGHOU0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J0PHVAVA27",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J0PHVAVA28",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J0LFGHOU0",
//															"faceTagName": "hideChat"
//														},
//														"1J0PHT3FS0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J0PHVAVA31",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J0PHVAVA32",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		},
//																		"x": {
//																			"type": "length",
//																			"valText": "0"
//																		},
//																		"y": {
//																			"type": "length",
//																			"valText": "0"
//																		},
//																		"w": {
//																			"type": "length",
//																			"valText": "100%"
//																		},
//																		"h": {
//																			"type": "length",
//																			"valText": "100%"
//																		},
//																		"maxH": {
//																			"type": "length",
//																			"valText": "100%-30"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J0PHT3FS0",
//															"faceTagName": "chatWithoutUI"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HAMRSPCM2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HAMRSPCM3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"exposeContainer": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1J0PGORM85",
//									"attrs": {
//										"1J0PGPU570": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1J0PH9PAA4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J0PH9PAA5",
//													"attrs": {
//														"w": {
//															"type": "length",
//															"valText": "100%"
//														},
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														},
//														"h": {
//															"type": "length",
//															"valText": "100%"
//														},
//														"x": {
//															"type": "length",
//															"valText": "0"
//														},
//														"y": {
//															"type": "length",
//															"valText": "0"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1J0PGPU570",
//											"faceTagName": "chatWithUI"
//										},
//										"1J0LFGHOU0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1J0PHVAVA33",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J0PHVAVA34",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1J0LFGHOU0",
//											"faceTagName": "hideChat"
//										},
//										"1J0KH46IF0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1J0PHVAVA35",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J0PHVAVA36",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1J0KH46IF0",
//											"faceTagName": "uiView"
//										},
//										"1J0KH3TAF0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1J0PHVAVA39",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J0PHVAVA40",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1J0KH3TAF0",
//											"faceTagName": "chatView"
//										},
//										"1J0PHT3FS0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1J0PHVAVA41",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J0PHVAVA42",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														},
//														"w": {
//															"type": "length",
//															"valText": "100%"
//														},
//														"h": {
//															"type": "length",
//															"valText": "100%"
//														},
//														"x": {
//															"type": "length",
//															"valText": "0"
//														},
//														"y": {
//															"type": "length",
//															"valText": "0"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1J0PHT3FS0",
//											"faceTagName": "chatWithoutUI"
//										},
//										"1HAMS3KJL0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1J0R0J7L60",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J0R0J7L61",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HAMS3KJL0",
//											"faceTagName": "start"
//										},
//										"1HAMS4K161": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1J0R0J7L62",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J0R0J7L63",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HAMS4K161",
//											"faceTagName": "input"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1J0PGORM86",
//									"attrs": {
//										"OnClick": {
//											"type": "fixedFunc",
//											"jaxId": "1J0SD3HMN0",
//											"attrs": {
//												"callArgs": {
//													"jaxId": "1J0SD3Q1I0",
//													"attrs": {
//														"event": ""
//													}
//												},
//												"seg": ""
//											}
//										}
//									}
//								},
//								"extraPpts": {
//									"jaxId": "1J0PGORM87",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1HAMROHSE0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HAMROHSE1",
//									"attrs": {
//										"type": "box",
//										"id": "BoxUser",
//										"position": "Absolute",
//										"x": "50%",
//										"y": "100%-20",
//										"w": "100%-80",
//										"h": "",
//										"anchorH": "Center",
//										"anchorV": "Bottom",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "40",
//										"maxW": "600",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "[255,255,255,1.00]",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "3",
//										"shadow": "true",
//										"shadowX": "0",
//										"shadowY": "1",
//										"shadowBlur": "4",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.30]",
//										"contentLayout": "Flex Y"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1HAMROHSE2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HAMROHSE3",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxInput",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "[5,10,5,10]",
//														"minW": "",
//														"minH": "20",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex X",
//														"traceSize": "true",
//														"itemsAlign": "Center"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1HBHSL4O70",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HBHT2USB0",
//																	"attrs": {
//																		"type": "hud",
//																		"id": "BoxFileBtnsFrame",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "20",
//																		"h": "20",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "Off",
//																		"clip": "On",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[0,5,0,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "hud",
//																			"jaxId": "1HBHSOUU60",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HBHT2USB1",
//																					"attrs": {
//																						"type": "hud",
//																						"id": "BoxButtons",
//																						"position": "Absolute",
//																						"x": "0",
//																						"y": "20",
//																						"w": "20",
//																						"h": "40",
//																						"anchorH": "Left",
//																						"anchorV": "Bottom",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": ""
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": [
//																						{
//																							"type": "hudobj",
//																							"def": "box",
//																							"jaxId": "1HBHSRIG70",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HBHT2USB2",
//																									"attrs": {
//																										"type": "box",
//																										"id": "",
//																										"position": "Absolute",
//																										"x": "-3",
//																										"y": "-3",
//																										"w": "100%+6",
//																										"h": "100%+6",
//																										"anchorH": "Left",
//																										"anchorV": "Top",
//																										"autoLayout": "false",
//																										"display": "Off",
//																										"clip": "Off",
//																										"uiEvent": "On",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "",
//																										"zIndex": "0",
//																										"margin": "",
//																										"padding": "",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": "",
//																										"background": "#cfgColor[\"body\"]",
//																										"border": "1",
//																										"borderStyle": "Solid",
//																										"borderColor": "#cfgColor[\"fontBodyLit\"]",
//																										"corner": "3",
//																										"shadow": "true",
//																										"shadowX": "0",
//																										"shadowY": "2",
//																										"shadowBlur": "5",
//																										"shadowSpread": "0",
//																										"shadowColor": "[0,0,0,0.30]"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1HBHT2USB3",
//																									"attrs": {
//																										"1HBHT74HN0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HBHTAIUT4",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HBHTAIUT5",
//																													"attrs": {
//																														"display": {
//																															"type": "choice",
//																															"valText": "On"
//																														}
//																													}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HBHT74HN0",
//																											"faceTagName": "filemenu"
//																										},
//																										"1HBHT8HLB0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HBHTAIUT6",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HBHTAIUT7",
//																													"attrs": {
//																														"display": {
//																															"type": "choice",
//																															"valText": "Off"
//																														}
//																													}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HBHT8HLB0",
//																											"faceTagName": "!filemenu"
//																										},
//																										"1HBHUBGFH0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IMND4CK94",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IMND4CK95",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HBHUBGFH0",
//																											"faceTagName": "!allowfile"
//																										},
//																										"1J0C6EPL40": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1J0C6UATU4",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1J0C6UATU5",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1J0C6EPL40",
//																											"faceTagName": "dormant"
//																										},
//																										"1HAMS4K161": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1J0LFI5GO20",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1J0LFI5GO21",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HAMS4K161",
//																											"faceTagName": "input"
//																										},
//																										"1HAMS3KJL0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1J0LFI5GO22",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1J0LFI5GO23",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HAMS3KJL0",
//																											"faceTagName": "start"
//																										},
//																										"1J0LFGHOU0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1J0PHVAVA43",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1J0PHVAVA44",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1J0LFGHOU0",
//																											"faceTagName": "hideChat"
//																										},
//																										"1J0PHT3FS0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1J0PJUG6I2",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1J0PJUG6I3",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1J0PHT3FS0",
//																											"faceTagName": "chatWithoutUI"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1HBHT2USB4",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1HBHT2USB5",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "true",
//																								"nameVal": "false"
//																							}
//																						},
//																						{
//																							"type": "hudobj",
//																							"def": "Gear/@StdUI/ui/BtnIcon.js",
//																							"jaxId": "1HBHSPMP80",
//																							"attrs": {
//																								"createArgs": {
//																									"jaxId": "1HBHSPMP81",
//																									"attrs": {
//																										"style": "\"front\"",
//																										"w": "20",
//																										"h": "0",
//																										"icon": "#appCfg.sharedAssets+\"/folder.svg\"",
//																										"colorBG": "null"
//																									}
//																								},
//																								"properties": {
//																									"jaxId": "1HBHSPMP82",
//																									"attrs": {
//																										"type": "#null#>BtnIcon(\"front\",20,0,appCfg.sharedAssets+\"/folder.svg\",null)",
//																										"id": "BtnLocalFile",
//																										"position": "Absolute",
//																										"x": "0",
//																										"y": "20",
//																										"display": "On",
//																										"face": "",
//																										"margin": "[0,5,0,0]",
//																										"padding": "0",
//																										"anchorV": "Top",
//																										"autoLayout": "true"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1HBHSPMP90",
//																									"attrs": {
//																										"1HBHT74HN0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HBHTAIUT8",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HBHTAIUT9",
//																													"attrs": {
//																														"display": {
//																															"type": "choice",
//																															"valText": "On"
//																														}
//																													}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HBHT74HN0",
//																											"faceTagName": "filemenu"
//																										},
//																										"1HBHT8HLB0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HD6JA1UU0",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HD6JA1UU1",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HBHT8HLB0",
//																											"faceTagName": "!filemenu"
//																										},
//																										"1HBHUBGFH0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IMND4CK96",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IMND4CKA0",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HBHUBGFH0",
//																											"faceTagName": "!allowfile"
//																										},
//																										"1J0C6EPL40": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1J0C6UATU6",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1J0C6UATU7",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1J0C6EPL40",
//																											"faceTagName": "dormant"
//																										},
//																										"1HAMS4K161": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1J0LFI5GO26",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1J0LFI5GO27",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HAMS4K161",
//																											"faceTagName": "input"
//																										},
//																										"1HAMS3KJL0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1J0LFI5GO28",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1J0LFI5GO29",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HAMS3KJL0",
//																											"faceTagName": "start"
//																										},
//																										"1J0LFGHOU0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1J0PHVAVA51",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1J0PHVAVA52",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1J0LFGHOU0",
//																											"faceTagName": "hideChat"
//																										},
//																										"1J0PHT3FS0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1J0PJUG6I4",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1J0PJUG6I5",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1J0PHT3FS0",
//																											"faceTagName": "chatWithoutUI"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1HBHSPMP93",
//																									"attrs": {
//																										"OnClick": {
//																											"type": "fixedFunc",
//																											"jaxId": "1HBHSPMP94",
//																											"attrs": {
//																												"callArgs": {
//																													"jaxId": "1HBHSPMP95",
//																													"attrs": {
//																														"event": ""
//																													}
//																												},
//																												"seg": ""
//																											}
//																										}
//																									}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1HBHSPMP96",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "true",
//																								"containerSlots": {
//																									"jaxId": "1HBHSPMP97",
//																									"attrs": {}
//																								}
//																							}
//																						},
//																						{
//																							"type": "hudobj",
//																							"def": "Gear/@StdUI/ui/BtnIcon.js",
//																							"jaxId": "1HBHSQC010",
//																							"attrs": {
//																								"createArgs": {
//																									"jaxId": "1HBHSQC011",
//																									"attrs": {
//																										"style": "\"front\"",
//																										"w": "20",
//																										"h": "0",
//																										"icon": "#appCfg.sharedAssets+\"/upload.svg\"",
//																										"colorBG": "null"
//																									}
//																								},
//																								"properties": {
//																									"jaxId": "1HBHSQC012",
//																									"attrs": {
//																										"type": "#null#>BtnIcon(\"front\",20,0,appCfg.sharedAssets+\"/upload.svg\",null)",
//																										"id": "BtnNativeFile",
//																										"position": "Absolute",
//																										"x": "0",
//																										"y": "0",
//																										"display": "Off",
//																										"face": "",
//																										"margin": "[0,5,0,0]",
//																										"padding": "0",
//																										"anchorV": "Top",
//																										"autoLayout": "true"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1HBHSQC013",
//																									"attrs": {
//																										"1HBHT74HN0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HBHTAIUT12",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HBHTAIUT13",
//																													"attrs": {
//																														"display": {
//																															"type": "choice",
//																															"valText": "On"
//																														}
//																													}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HBHT74HN0",
//																											"faceTagName": "filemenu"
//																										},
//																										"1HBHT8HLB0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HBHTAIUT14",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HBHTAIUT15",
//																													"attrs": {
//																														"display": {
//																															"type": "choice",
//																															"valText": "Off"
//																														}
//																													}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HBHT8HLB0",
//																											"faceTagName": "!filemenu"
//																										},
//																										"1HBHUBGFH0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1IMND4CKA1",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1IMND4CKA2",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HBHUBGFH0",
//																											"faceTagName": "!allowfile"
//																										},
//																										"1J0C6EPL40": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1J0C6UATU8",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1J0C6UATU9",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1J0C6EPL40",
//																											"faceTagName": "dormant"
//																										},
//																										"1HAMS4K161": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1J0LFI5GO32",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1J0LFI5GO33",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HAMS4K161",
//																											"faceTagName": "input"
//																										},
//																										"1HAMS3KJL0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1J0LFI5GO34",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1J0LFI5GO35",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HAMS3KJL0",
//																											"faceTagName": "start"
//																										},
//																										"1J0LFGHOU0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1J0PHVAVA59",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1J0PHVAVA60",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1J0LFGHOU0",
//																											"faceTagName": "hideChat"
//																										},
//																										"1J0PHT3FS0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1J0PJUG6I6",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1J0PJUG6I7",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1J0PHT3FS0",
//																											"faceTagName": "chatWithoutUI"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1HBHSQC016",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1HBHSQC019",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "true",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "true",
//																								"containerSlots": {
//																									"jaxId": "1HBHSQC0110",
//																									"attrs": {}
//																								}
//																							}
//																						}
//																					]
//																				},
//																				"faces": {
//																					"jaxId": "1HBHT2USB6",
//																					"attrs": {
//																						"1HBHT74HN0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HBHU5CAP0",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HBHU5CAP1",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HBHT74HN0",
//																							"faceTagName": "filemenu"
//																						},
//																						"1HBHT8HLB0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HD6JA1UU2",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HD6JA1UU3",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HBHT8HLB0",
//																							"faceTagName": "!filemenu"
//																						},
//																						"1HBHUBGFH0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1IMND4CKA3",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1IMND4CKA4",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HBHUBGFH0",
//																							"faceTagName": "!allowfile"
//																						},
//																						"1J0C6EPL40": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1J0C6UATU10",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1J0C6UATU11",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J0C6EPL40",
//																							"faceTagName": "dormant"
//																						},
//																						"1HAMS4K161": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1J0LFI5GO38",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1J0LFI5GO39",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAMS4K161",
//																							"faceTagName": "input"
//																						},
//																						"1HAMS3KJL0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1J0LFI5GO40",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1J0LFI5GO41",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAMS3KJL0",
//																							"faceTagName": "start"
//																						},
//																						"1J0LFGHOU0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1J0PHVAVA67",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1J0PHVAVA68",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J0LFGHOU0",
//																							"faceTagName": "hideChat"
//																						},
//																						"1J0PHT3FS0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1J0PJUG6I8",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1J0PJUG6I9",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1J0PHT3FS0",
//																							"faceTagName": "chatWithoutUI"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1HBHT2USB7",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1HBHT2USB8",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "false",
//																				"exposeContainer": "false"
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"jaxId": "1HBHT2USB9",
//																	"attrs": {
//																		"1HBHT8HLB0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HBHTJ6NT2",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HBHTJ6NT3",
//																					"attrs": {
//																						"clip": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HBHT8HLB0",
//																			"faceTagName": "!filemenu"
//																		},
//																		"1HBHT74HN0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HBHU5CAP2",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HBHU5CAP3",
//																					"attrs": {
//																						"clip": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HBHT74HN0",
//																			"faceTagName": "filemenu"
//																		},
//																		"1HBHUAT3S0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HBHUC94616",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HBHUC94617",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HBHUAT3S0",
//																			"faceTagName": "allowfile"
//																		},
//																		"1HBHUBGFH0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HBHUC94618",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HBHUC94619",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HBHUBGFH0",
//																			"faceTagName": "!allowfile"
//																		},
//																		"1J0C6EPL40": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J0C6UATU12",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J0C6UATU13",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J0C6EPL40",
//																			"faceTagName": "dormant"
//																		},
//																		"1HAMS4K161": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J0LFI5GO44",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J0LFI5GO45",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAMS4K161",
//																			"faceTagName": "input"
//																		},
//																		"1HAMS3KJL0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J0LFI5GO46",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J0LFI5GO47",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAMS3KJL0",
//																			"faceTagName": "start"
//																		},
//																		"1J0LFGHOU0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J0PHVAVA75",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J0PHVAVA76",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J0LFGHOU0",
//																			"faceTagName": "hideChat"
//																		},
//																		"1J0PHT3FS0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J0PJUG6I10",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J0PJUG6I11",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J0PHT3FS0",
//																			"faceTagName": "chatWithoutUI"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HBHT2USB10",
//																	"attrs": {
//																		"OnMouseInOut": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HBHU0P700",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1HBHU19670",
//																					"attrs": {
//																						"isIn": "",
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1HBHT2USB11",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false",
//																"exposeContainer": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "memo",
//															"jaxId": "1HAMROHSG7",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAMROHSG8",
//																	"attrs": {
//																		"type": "memo",
//																		"id": "EdUserInput",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%-100",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "20",
//																		"maxW": "",
//																		"maxH": "200",
//																		"face": "",
//																		"styleClass": "",
//																		"text": "",
//																		"color": "#cfgColor[\"fontBody\"]",
//																		"bgColor": "#cfgColor[\"body\"]",
//																		"font": "",
//																		"fontSize": "#txtSize.mid",
//																		"outline": "0",
//																		"border": "[0,0,1,0]",
//																		"borderStyle": "Solid",
//																		"borderColor": "[0,0,0,0.5]",
//																		"corner": "0",
//																		"readOnly": "false",
//																		"selectOnFocus": "true",
//																		"spellCheck": "true",
//																		"flex": "true"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HAMROHSG9",
//																	"attrs": {
//																		"1HBHT74HN0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HBHU5CAP6",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HBHU5CAP7",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HBHT74HN0",
//																			"faceTagName": "filemenu"
//																		},
//																		"1HBHT8HLB0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HD6JA7JV4",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HD6JA7JV5",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HBHT8HLB0",
//																			"faceTagName": "!filemenu"
//																		},
//																		"1HBHUBGFH0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IMND4CKA5",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IMND4CKA6",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HBHUBGFH0",
//																			"faceTagName": "!allowfile"
//																		},
//																		"1J0C6EPL40": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J0C6UATV0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J0C6UATV1",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J0C6EPL40",
//																			"faceTagName": "dormant"
//																		},
//																		"1HAMS4K161": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J0LFI5GO50",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J0LFI5GO51",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAMS4K161",
//																			"faceTagName": "input"
//																		},
//																		"1HAMS3KJL0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J0LFI5GO52",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J0LFI5GO53",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAMS3KJL0",
//																			"faceTagName": "start"
//																		},
//																		"1J0LFGHOU0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J0PHVAVA83",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J0PHVAVA84",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J0LFGHOU0",
//																			"faceTagName": "hideChat"
//																		},
//																		"1J0PHT3FS0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J0PJUG6I12",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J0PJUG6I13",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J0PHT3FS0",
//																			"faceTagName": "chatWithoutUI"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HAMROHSG14",
//																	"attrs": {
//																		"OnInput": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HAMROHSG15",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1HAMROHSG16",
//																					"attrs": {}
//																				},
//																				"seg": ""
//																			}
//																		},
//																		"OnKeyDown": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HAMROHSG17",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1HAMROHSG18",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1HAMROHSG19",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1HAMROHSH0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1HAMROHSH1",
//																	"attrs": {
//																		"style": "\"front\"",
//																		"w": "30",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/send.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1HAMROHSH2",
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"front\",30,0,appCfg.sharedAssets+\"/send.svg\",null)",
//																		"id": "BtnSend",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"margin": "[0,0,0,10]",
//																		"padding": "2",
//																		"anchorV": "Top",
//																		"autoLayout": "true"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HAMROHSH3",
//																	"attrs": {
//																		"1HBHT74HN0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HBHU5CAP8",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HBHU5CAP9",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HBHT74HN0",
//																			"faceTagName": "filemenu"
//																		},
//																		"1HBHT8HLB0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HD6JA7JV6",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HD6JA7JV7",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HBHT8HLB0",
//																			"faceTagName": "!filemenu"
//																		},
//																		"1HBHUBGFH0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IMND4CKA7",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IMND4CKA8",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HBHUBGFH0",
//																			"faceTagName": "!allowfile"
//																		},
//																		"1J0C6EPL40": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J0C6UATV2",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J0C6UATV3",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J0C6EPL40",
//																			"faceTagName": "dormant"
//																		},
//																		"1HAMS4K161": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J0LFI5GO56",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J0LFI5GO57",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAMS4K161",
//																			"faceTagName": "input"
//																		},
//																		"1HAMS3KJL0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J0LFI5GO58",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J0LFI5GO59",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAMS3KJL0",
//																			"faceTagName": "start"
//																		},
//																		"1J0LFGHOU0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J0PHVAVA91",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J0PHVAVA92",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J0LFGHOU0",
//																			"faceTagName": "hideChat"
//																		},
//																		"1J0PHT3FS0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J0PJUG6I14",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J0PJUG6I15",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J0PHT3FS0",
//																			"faceTagName": "chatWithoutUI"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HAMROHSH8",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HAMROHSH9",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1HAMROHSH10",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1HAMROHSH11",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1HAMROHSH12",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1HAMROHSH13",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAMROHSH14",
//																	"attrs": {
//																		"type": "text",
//																		"id": "TxtInputHint",
//																		"position": "Absolute",
//																		"x": "18",
//																		"y": "0",
//																		"w": "100",
//																		"h": "100%",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "Tree Off",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontBodyLit\"]",
//																		"text": "Input chat message...",
//																		"font": "",
//																		"fontSize": "#txtSize.mid",
//																		"bold": "false",
//																		"italic": "true",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Center",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"lineClamp": "0",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HAMROHSH15",
//																	"attrs": {
//																		"1HBHT74HN0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HBHU5CAP10",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HBHU5CAP11",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HBHT74HN0",
//																			"faceTagName": "filemenu"
//																		},
//																		"1HBHUAT3S0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HBHUC94632",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HBHUC94633",
//																					"attrs": {
//																						"x": {
//																							"type": "length",
//																							"valText": "40"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HBHUAT3S0",
//																			"faceTagName": "allowfile"
//																		},
//																		"1HBHUBGFH0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HBHUC94634",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HBHUC94635",
//																					"attrs": {
//																						"x": {
//																							"type": "length",
//																							"valText": "18"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HBHUBGFH0",
//																			"faceTagName": "!allowfile"
//																		},
//																		"1HBHT8HLB0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HD6JA7JV8",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HD6JA7JV9",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HBHT8HLB0",
//																			"faceTagName": "!filemenu"
//																		},
//																		"1J0C6EPL40": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J0C6UATV4",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J0C6UATV5",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J0C6EPL40",
//																			"faceTagName": "dormant"
//																		},
//																		"1HAMS4K161": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J0LFI5GO62",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J0LFI5GO63",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAMS4K161",
//																			"faceTagName": "input"
//																		},
//																		"1HAMS3KJL0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J0LFI5GO64",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J0LFI5GO65",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAMS3KJL0",
//																			"faceTagName": "start"
//																		},
//																		"1J0LFGHOU0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J0PHVAVB0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J0PHVAVB1",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J0LFGHOU0",
//																			"faceTagName": "hideChat"
//																		},
//																		"1J0PHT3FS0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J0PJUG6I16",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J0PJUG6I17",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J0PHT3FS0",
//																			"faceTagName": "chatWithoutUI"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HAMROHSH20",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HAMROHSH21",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true"
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1HAMROHSI0",
//													"attrs": {
//														"1HAMS3KJL0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAMSKQ1D12",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAMSKQ1D13",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAMS3KJL0",
//															"faceTagName": "start"
//														},
//														"1HAMS4K161": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAMSMGCQ1",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAMSMGCQ2",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAMS4K161",
//															"faceTagName": "input"
//														},
//														"1HAMS4K163": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAMSMS7V12",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAMSMS7V13",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAMS4K163",
//															"faceTagName": "wait"
//														},
//														"1HBHT74HN0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HBHU5CAP12",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HBHU5CAP13",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HBHT74HN0",
//															"faceTagName": "filemenu"
//														},
//														"1HBHT8HLB0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HD6JA7JV10",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HD6JA7JV11",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HBHT8HLB0",
//															"faceTagName": "!filemenu"
//														},
//														"1HBHUBGFH0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IMND4CKA9",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IMND4CKA10",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HBHUBGFH0",
//															"faceTagName": "!allowfile"
//														},
//														"1J0C6EPL40": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J0C6IE7V1",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J0C6IE7V2",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J0C6EPL40",
//															"faceTagName": "dormant"
//														},
//														"1J0LFGC5U0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J0LFI5GO68",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J0LFI5GO69",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J0LFGC5U0",
//															"faceTagName": "showChat"
//														},
//														"1J0LFGHOU0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J0PHVAVB8",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J0PHVAVB9",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J0LFGHOU0",
//															"faceTagName": "hideChat"
//														},
//														"1J0PHT3FS0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J0PJUG6I18",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J0PJUG6I19",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J0PHT3FS0",
//															"faceTagName": "chatWithoutUI"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HAMROHSI9",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HAMROHSI10",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1HAMROHSI11",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HAMROHSI12",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxWait",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "Off",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "30",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex Y",
//														"itemsAlign": "Center",
//														"subAlign": "Center"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1HAMROHSI13",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAMROHSI14",
//																	"attrs": {
//																		"type": "text",
//																		"id": "",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "20",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontBodyLit\"]",
//																		"text": "AI is thinking...",
//																		"font": "",
//																		"fontSize": "#txtSize.smallPlus",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Center",
//																		"alignV": "Center",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"lineClamp": "0",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HAMROHSI15",
//																	"attrs": {
//																		"1HBHT74HN0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HBHU5CAP14",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HBHU5CAP15",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HBHT74HN0",
//																			"faceTagName": "filemenu"
//																		},
//																		"1HBHT8HLB0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HD6JA7JV12",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HD6JA7JV13",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HBHT8HLB0",
//																			"faceTagName": "!filemenu"
//																		},
//																		"1HBHUBGFH0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IMND4CKA11",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IMND4CKA12",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HBHUBGFH0",
//																			"faceTagName": "!allowfile"
//																		},
//																		"1J0C6EPL40": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J0C6IE800",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J0C6IE801",
//																					"attrs": {
//																						"text": {
//																							"type": "string",
//																							"valText": "Conversation has ended",
//																							"localize": {
//																								"EN": "Conversation has ended",
//																								"CN": "对话已结束"
//																							},
//																							"localizable": true
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J0C6EPL40",
//																			"faceTagName": "dormant"
//																		},
//																		"1HAMS4K161": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J0LFI5GO70",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J0LFI5GO71",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAMS4K161",
//																			"faceTagName": "input"
//																		},
//																		"1HAMS3KJL0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J0LFI5GO72",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J0LFI5GO73",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAMS3KJL0",
//																			"faceTagName": "start"
//																		},
//																		"1J0LFGHOU0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J0PHVAVB14",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J0PHVAVB15",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J0LFGHOU0",
//																			"faceTagName": "hideChat"
//																		},
//																		"1J0PHT3FS0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J0PJUG6I20",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J0PJUG6I21",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J0PHT3FS0",
//																			"faceTagName": "chatWithoutUI"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HAMROHSJ4",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HAMROHSJ5",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnText.js",
//															"jaxId": "1HAMROHSJ6",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1HAMROHSJ7",
//																	"attrs": {
//																		"style": "primary",
//																		"w": "100",
//																		"h": "25",
//																		"text": "Abort",
//																		"outlined": "false",
//																		"icon": ""
//																	}
//																},
//																"properties": {
//																	"jaxId": "1HAMROHSJ8",
//																	"attrs": {
//																		"type": "#null#>BtnText(\"primary\",100,25,\"Abort\",false,\"\")",
//																		"id": "BtnAbort",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"anchorH": "Left"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HAMROHSJ9",
//																	"attrs": {
//																		"1HBHT74HN0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HBHU5CAP16",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HBHU5CAP17",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HBHT74HN0",
//																			"faceTagName": "filemenu"
//																		},
//																		"1HBHT8HLB0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HD6JA7JV14",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HD6JA7JV15",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HBHT8HLB0",
//																			"faceTagName": "!filemenu"
//																		},
//																		"1HBHUBGFH0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IMND4CKA13",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IMND4CKA14",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HBHUBGFH0",
//																			"faceTagName": "!allowfile"
//																		},
//																		"1J0C6EPL40": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J0C6IE802",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J0C6IE803",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J0C6EPL40",
//																			"faceTagName": "dormant"
//																		},
//																		"1HAMS4K161": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J0LFI5GO76",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J0LFI5GO77",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAMS4K161",
//																			"faceTagName": "input"
//																		},
//																		"1HAMS3KJL0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J0LFI5GO78",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J0LFI5GO79",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAMS3KJL0",
//																			"faceTagName": "start"
//																		},
//																		"1J0LFGHOU0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J0PHVAVB22",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J0PHVAVB23",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J0LFGHOU0",
//																			"faceTagName": "hideChat"
//																		},
//																		"1J0PHT3FS0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J0PJUG6I22",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J0PJUG6I23",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J0PHT3FS0",
//																			"faceTagName": "chatWithoutUI"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HAMROHSJ14",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HAMROHSJ15",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1HAMROHSJ16",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1HAMROHSJ17",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1HAMROHSJ18",
//																	"attrs": {
//																		"Slot1H2F6U36O0": {
//																			"jaxId": "1HAMROHSJ19",
//																			"attrs": {
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"container": "true"
//																			}
//																		}
//																	}
//																}
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1HAMROHSJ20",
//													"attrs": {
//														"1HAMS3KJL0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAMSKQ1D18",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAMSKQ1D19",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAMS3KJL0",
//															"faceTagName": "start"
//														},
//														"1HAMS4K161": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAMSMGCQ7",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAMSMGCQ8",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAMS4K161",
//															"faceTagName": "input"
//														},
//														"1HAMS4K163": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAMSMS7V18",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAMSMS7V19",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAMS4K163",
//															"faceTagName": "wait"
//														},
//														"1HBHT74HN0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HBHU5CAP18",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HBHU5CAP19",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HBHT74HN0",
//															"faceTagName": "filemenu"
//														},
//														"1HBHT8HLB0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HD6JA7JV16",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HD6JA7JV17",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HBHT8HLB0",
//															"faceTagName": "!filemenu"
//														},
//														"1HBHUBGFH0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IMND4CKA15",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IMND4CKA16",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HBHUBGFH0",
//															"faceTagName": "!allowfile"
//														},
//														"1J0C6EPL40": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J0C6IE804",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J0C6IE805",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J0C6EPL40",
//															"faceTagName": "dormant"
//														},
//														"1J0LFGC5U0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J0LFI5GO82",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J0LFI5GO83",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J0LFGC5U0",
//															"faceTagName": "showChat"
//														},
//														"1J0LFGHOU0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J0PHVAVB30",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J0PHVAVB31",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J0LFGHOU0",
//															"faceTagName": "hideChat"
//														},
//														"1J0PHT3FS0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J0PJUG6I24",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J0PJUG6I25",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J0PHT3FS0",
//															"faceTagName": "chatWithoutUI"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HAMROHSJ29",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HAMROHSJ30",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1IMNBNUAP0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IMNC0ODV24",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxAssets",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex Y"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IMNC0ODV25",
//													"attrs": {
//														"1HBHUBGFH0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IMND4CKA17",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IMND4CKA18",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HBHUBGFH0",
//															"faceTagName": "!allowfile"
//														},
//														"1J0C6EPL40": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J0C6UATV6",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J0C6UATV7",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J0C6EPL40",
//															"faceTagName": "dormant"
//														},
//														"1HAMS4K161": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J0LFI5GO84",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J0LFI5GO85",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAMS4K161",
//															"faceTagName": "input"
//														},
//														"1HAMS3KJL0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J0LFI5GO86",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J0LFI5GO87",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAMS3KJL0",
//															"faceTagName": "start"
//														},
//														"1J0LFGHOU0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J0PHVAVB36",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J0PHVAVB37",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J0LFGHOU0",
//															"faceTagName": "hideChat"
//														},
//														"1J0PHT3FS0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J0PJUG6J0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J0PJUG6J1",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J0PHT3FS0",
//															"faceTagName": "chatWithoutUI"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IMNC0ODV26",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IMNC0ODV27",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1J0PJCUQQ0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J0PJUG6J2",
//													"attrs": {
//														"type": "box",
//														"id": "",
//														"position": "Absolute",
//														"x": "-50",
//														"y": "50%",
//														"w": "40",
//														"h": "40",
//														"anchorH": "Left",
//														"anchorV": "Center",
//														"autoLayout": "false",
//														"display": "Off",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "[255,255,255,1.00]",
//														"border": "0",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "6",
//														"shadow": "true",
//														"shadowX": "0",
//														"shadowY": "1",
//														"shadowBlur": "4",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.30]"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1J0PJGNP80",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1J0PJUG6J3",
//																	"attrs": {
//																		"style": "\"front\"",
//																		"w": "36",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/update.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1J0PJUG6J4",
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"front\",36,0,appCfg.sharedAssets+\"/update.svg\",null)",
//																		"id": "BtnShowChats",
//																		"position": "Absolute",
//																		"x": "50%",
//																		"y": "50%",
//																		"display": "On",
//																		"face": "",
//																		"anchorH": "Center",
//																		"autoLayout": "false",
//																		"anchorV": "Center",
//																		"rotate": "180",
//																		"padding": "2"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1J0PJUG6J5",
//																	"attrs": {
//																		"1J0PHT3FS0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J0PJUG6J6",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J0PJUG6J7",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J0PHT3FS0",
//																			"faceTagName": "chatWithoutUI"
//																		},
//																		"1J0LFGHOU0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J0PJUG6J10",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J0PJUG6J11",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J0LFGHOU0",
//																			"faceTagName": "hideChat"
//																		},
//																		"1J0KH46IF0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J0PJUG6J12",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J0PJUG6J13",
//																					"attrs": {
//																						"rotate": {
//																							"type": "number",
//																							"valText": "0"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J0KH46IF0",
//																			"faceTagName": "uiView"
//																		},
//																		"1J0KH3TAF0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J0PJUG6J14",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J0PJUG6J15",
//																					"attrs": {
//																						"rotate": {
//																							"type": "number",
//																							"valText": "180"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J0KH3TAF0",
//																			"faceTagName": "chatView"
//																		},
//																		"1HAMS3KJL0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J0R0J7L64",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J0R0J7L65",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAMS3KJL0",
//																			"faceTagName": "start"
//																		},
//																		"1HAMS4K161": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J0R0J7L66",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J0R0J7L67",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAMS4K161",
//																			"faceTagName": "input"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1J0PJUG6J16",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1J0R0IEES0",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1J0R0J7L68",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1J0PJUG6J17",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1J0PJUG6J18",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "box",
//															"jaxId": "1J0TOFQNJ0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J0TOKT870",
//																	"attrs": {
//																		"type": "box",
//																		"id": "BoxChatMark",
//																		"position": "Absolute",
//																		"x": "100%-10",
//																		"y": "8",
//																		"w": "10",
//																		"h": "10",
//																		"anchorH": "Center",
//																		"anchorV": "Center",
//																		"autoLayout": "false",
//																		"display": "Off",
//																		"clip": "Off",
//																		"uiEvent": "Tree Off",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"background": "#cfgColor[\"error\"]",
//																		"border": "0",
//																		"borderStyle": "Solid",
//																		"borderColor": "[0,0,0,1.00]",
//																		"corner": "10",
//																		"shadow": "false",
//																		"shadowX": "2",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowSpread": "0",
//																		"shadowColor": "[0,0,0,0.50]"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1J0TOKT871",
//																	"attrs": {
//																		"1J0KH3TAF0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1J0TT8AA80",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1J0TT8AA81",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1J0KH3TAF0",
//																			"faceTagName": "chatView"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1J0TOKT872",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1J0TOKT873",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "true"
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1J0PJUG6J19",
//													"attrs": {
//														"1J0PGPU570": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J0PJUG6J20",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J0PJUG6J21",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J0PGPU570",
//															"faceTagName": "chatWithUI"
//														},
//														"1J0PHT3FS0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J0PJUG6J22",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J0PJUG6J23",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J0PHT3FS0",
//															"faceTagName": "chatWithoutUI"
//														},
//														"1J0LFGHOU0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J0PJUG6J26",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J0PJUG6J27",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1J0LFGHOU0",
//															"faceTagName": "hideChat"
//														},
//														"1HAMS3KJL0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J0R0J7L69",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J0R0J7L610",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAMS3KJL0",
//															"faceTagName": "start"
//														},
//														"1HAMS4K161": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1J0R0J7L611",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1J0R0J7L612",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAMS4K161",
//															"faceTagName": "input"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1J0PJUG6J32",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1J0PJUG6J33",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1HAMROHSJ31",
//									"attrs": {
//										"1HBHT74HN0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HBHU5CAP20",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HBHU5CAP21",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HBHT74HN0",
//											"faceTagName": "filemenu"
//										},
//										"1HBHT8HLB0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HD6JA7JV18",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HD6JA7JV19",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HBHT8HLB0",
//											"faceTagName": "!filemenu"
//										},
//										"1HBHUBGFH0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IMND4CKA19",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IMND4CKA20",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HBHUBGFH0",
//											"faceTagName": "!allowfile"
//										},
//										"1J0C6EPL40": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1J0C6UATV8",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J0C6UATV9",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1J0C6EPL40",
//											"faceTagName": "dormant"
//										},
//										"1HAMS4K161": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1J0LFI5GO90",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J0LFI5GO91",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HAMS4K161",
//											"faceTagName": "input"
//										},
//										"1HAMS3KJL0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1J0LFI5GO92",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J0LFI5GO93",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HAMS3KJL0",
//											"faceTagName": "start"
//										},
//										"1J0LFGHOU0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1J0LFI5GO94",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J0LFI5GO95",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1J0LFGHOU0",
//											"faceTagName": "hideChat"
//										},
//										"1J0LFGC5U0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1J0LFI5GO96",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J0LFI5GO97",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1J0LFGC5U0",
//											"faceTagName": "showChat"
//										},
//										"1J0PHT3FS0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1J0PJUG6J34",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J0PJUG6J35",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1J0PHT3FS0",
//											"faceTagName": "chatWithoutUI"
//										},
//										"1J0PGPU570": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1J0QM08DB8",
//											"attrs": {
//												"properties": {
//													"jaxId": "1J0QM08DB9",
//													"attrs": {
//														"x": {
//															"type": "length",
//															"valText": "50%+25"
//														},
//														"w": {
//															"type": "length",
//															"valText": "100%-130"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1J0PGPU570",
//											"faceTagName": "chatWithUI"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HAMROHSJ36",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HAMROHSJ37",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1HAMRK4MB11",
//					"attrs": {
//						"1HBHT74HN0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HBHU5CAP22",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HBHU5CAP23",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HBHT74HN0",
//							"faceTagName": "filemenu"
//						},
//						"1HBHT8HLB0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HD6JA7JV20",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HD6JA7JV21",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HBHT8HLB0",
//							"faceTagName": "!filemenu"
//						},
//						"1HBHUBGFH0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1IMND4CKA21",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IMND4CKA22",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HBHUBGFH0",
//							"faceTagName": "!allowfile"
//						},
//						"1J0C6EPL40": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1J0C6UATV10",
//							"attrs": {
//								"properties": {
//									"jaxId": "1J0C6UATV11",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1J0C6EPL40",
//							"faceTagName": "dormant"
//						},
//						"1HAMS4K161": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1J0LFI5GO98",
//							"attrs": {
//								"properties": {
//									"jaxId": "1J0LFI5GO99",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HAMS4K161",
//							"faceTagName": "input"
//						},
//						"1HAMS3KJL0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1J0LFI5GO100",
//							"attrs": {
//								"properties": {
//									"jaxId": "1J0LFI5GO101",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HAMS3KJL0",
//							"faceTagName": "start"
//						},
//						"1J0LFGHOU0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1J0PHVAVB48",
//							"attrs": {
//								"properties": {
//									"jaxId": "1J0PHVAVB49",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1J0LFGHOU0",
//							"faceTagName": "hideChat"
//						},
//						"1J0PHT3FS0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1J0PJUG6J36",
//							"attrs": {
//								"properties": {
//									"jaxId": "1J0PJUG6J37",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1J0PHT3FS0",
//							"faceTagName": "chatWithoutUI"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1HAMRK4MB12",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1HAMRK4MB13",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "true",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1HAMRK4MB14",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "true",
//				"h": "true",
//				"anchorH": "true",
//				"anchorV": "true",
//				"autoLayout": "true",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "true",
//				"uiEvent": "true",
//				"alpha": "true",
//				"rotate": "true",
//				"scale": "true",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "true",
//				"zIndex": "true",
//				"flex": "true",
//				"margin": "true",
//				"traceSize": "true",
//				"padding": "true",
//				"minW": "true",
//				"minH": "true",
//				"maxW": "true",
//				"maxH": "true",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": [
//				{
//					"type": "string",
//					"valText": "defAssistant"
//				}
//			]
//		}
//	}
//}