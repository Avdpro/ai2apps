//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BoxAIChat} from "./BoxAIChat.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
import {BtnText} from "/@StdUI/ui/BtnText.js";
/*#{1HAMRK4MB0StartDoc*/
import pathLib from "/@path";
import {tabFS} from "/@tabos";
import {tabNT} from "/@tabos/tabos_nt.js";
import {DlgLogin} from "/@homekit/ui/DlgLogin.js";
import {DlgMenu} from "/@StdUI/ui/DlgMenu.js";
import {DlgFile} from "/@homekit/ui/DlgFile.js";
import {BoxAIChatBlock} from "./BoxAIChatBlock.js";
import {BoxAskUser} from "./BoxAskUser.js";
import {BoxChatBubble} from "./BoxChatBubble.js";
/*}#1HAMRK4MB0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let UIChat=function(opts){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let boxChatFrame,boxChats,boxUser,btnLocalFile,btnNativeFile,edUserInput,txtInputHint;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1HAMRK4MB1LocalVals*/
	const app=VFACT.app;
	opts=opts||{};
	let chatCallback=null;
	let initVO=null;
	let allowEmptyChat=false;
	/*}#1HAMRK4MB1LocalVals*/
	
	/*#{1HAMRK4MB1PreState*/
	/*}#1HAMRK4MB1PreState*/
	state={
		"defAssistant":{
			"colorBG":cfgColor["success"]
		},
		/*#{1HAMRK4MB7ExState*/
		/*}#1HAMRK4MB7ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1HAMRK4MB1PostState*/
	/*}#1HAMRK4MB1PostState*/
	cssVO={
		"hash":"1HAMRK4MB1",nameHost:true,
		"type":"hud","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
		children:[
			{
				"hash":"1HAMRQ87E0",
				"type":"hud","id":"BoxChatFrame","x":0,"y":0,"w":"100%","h":"100%","overflow":"auto-y","padding":[5,0,60,0],"minW":"","minH":"","maxW":"","maxH":">calc(100% - 30px)",
				"styleClass":"","contentLayout":"flex-y",
				children:[
					{
						"hash":"1HAMRU2MG0",
						"type":BoxAIChat(),"id":"BoxChats","position":"relative","x":0,"y":0,"w":"100%","h":"",
					}
				],
			},
			{
				"hash":"1HAMROHSE0",
				"type":"box","id":"BoxUser","x":"50%","y":">calc(100% - 10px)","w":">calc(100% - 80px)","h":"","anchorX":1,"anchorY":2,"minW":"","minH":30,"maxW":600,
				"maxH":"","styleClass":"","background":[255,255,255,1],"corner":3,"shadow":true,"shadowX":0,"shadowY":1,"shadowBlur":4,"shadowColor":[0,0,0,0.3],"contentLayout":"flex-y",
				children:[
					{
						"hash":"1HAMROHSE2",
						"type":"hud","id":"BoxInput","position":"relative","x":0,"y":0,"w":"100%","h":"","padding":[5,10,5,10],"minW":"","minH":20,"maxW":"","maxH":"","styleClass":"",
						"contentLayout":"flex-x","traceSize":true,"itemsAlign":1,
						children:[
							{
								"hash":"1HBHSL4O70",
								"type":"hud","id":"BoxFileBtnsFrame","position":"relative","x":0,"y":0,"w":20,"h":20,"display":0,"overflow":1,"margin":[0,5,0,0],"minW":"","minH":"",
								"maxW":"","maxH":"","styleClass":"",
								children:[
									{
										"hash":"1HBHSOUU60",
										"type":"hud","id":"BoxButtons","x":0,"y":20,"w":20,"h":40,"anchorY":2,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
										children:[
											{
												"hash":"1HBHSRIG70",
												"type":"box","x":-3,"y":-3,"w":">calc(100% + 6px)","h":">calc(100% + 6px)","display":0,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
												"background":cfgColor["body"],"border":1,"borderColor":cfgColor["fontBodyLit"],"corner":3,"shadow":true,"shadowX":0,"shadowBlur":5,"shadowColor":[0,0,0,0.3],
											},
											{
												"hash":"1HBHSPMP80",
												"type":BtnIcon("front",20,0,appCfg.sharedAssets+"/folder.svg",null),"id":"BtnLocalFile","x":0,"y":20,"margin":[0,5,0,0],"padding":0,"autoLayout":true,
												"OnClick":function(event){
													/*#{1HBHSPMP94FunctionBody*/
													self.useLocalFile();
													/*}#1HBHSPMP94FunctionBody*/
												},
											},
											{
												"hash":"1HBHSQC010",
												"type":BtnIcon("front",20,0,appCfg.sharedAssets+"/upload.svg",null),"id":"BtnNativeFile","x":0,"y":0,"display":0,"margin":[0,5,0,0],"padding":0,
												"autoLayout":true,
												/*#{1HBHSQC010Codes*/
												"labelHtml": '<input type="file" multiple="false" style="width:0px">',
												OnLableAction:function(){
													let files=[],i,n;
													n=this.files.length;
													for(i=0;i<n;i++){
														files.push(this.files[i]);
													}
													self.useNativeFile(files[0]);
													this.value="";
												}
												/*}#1HBHSQC010Codes*/
											}
										],
									}
								],
								"OnMouseInOut":function(isIn,event){
									/*#{1HBHU0P700FunctionBody*/
									if(isIn){
										self.showFace("filemenu");
									}else{
										self.showFace("!filemenu");
									}
									/*}#1HBHU0P700FunctionBody*/
								},
							},
							{
								"hash":"1HAMROHSG7",
								"type":"memo","id":"EdUserInput","position":"relative","x":0,"y":0,"w":">calc(100% - 100px)","h":"","minW":"","minH":20,"maxW":"","maxH":200,"styleClass":"",
								"color":cfgColor["fontBody"],"background":cfgColor["body"],"fontSize":txtSize.mid,"outline":0,"border":[0,0,1,0],"borderColor":[0,0,0,0.5],"flex":true,
								"OnInput":function(){
									/*#{1HAMROHSG15FunctionBody*/
									txtInputHint.display=!this.text;
									/*}#1HAMROHSG15FunctionBody*/
								},
								"OnKeyDown":function(event){
									/*#{1HAMROHSG17FunctionBody*/
									if(event.code==="Enter"){
										if((!event.isComposing) &&(!event.shiftKey)){
											event.stopPropagation();
											event.preventDefault();
											self.sendChat();
										}
									}
									/*}#1HAMROHSG17FunctionBody*/
								},
							},
							{
								"hash":"1HAMROHSH0",
								"type":BtnIcon("front",30,0,appCfg.sharedAssets+"/send.svg",null),"id":"BtnSend","position":"relative","x":0,"y":0,"margin":[0,0,0,10],"padding":2,
								"autoLayout":true,
								"OnClick":function(event){
									/*#{1HAMROHSH9FunctionBody*/
									self.sendChat();
									/*}#1HAMROHSH9FunctionBody*/
								},
							},
							{
								"hash":"1HAMROHSH13",
								"type":"text","id":"TxtInputHint","x":18,"y":0,"w":100,"h":"100%","uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodyLit"],
								"text":"Input chat message...","fontSize":txtSize.mid,"fontWeight":"normal","fontStyle":"italic","textDecoration":"","alignV":1,
							}
						],
					},
					{
						"hash":"1HAMROHSI11",
						"type":"hud","id":"BoxWait","position":"relative","x":0,"y":0,"w":"100%","h":50,"display":0,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						children:[
							{
								"hash":"1HAMROHSI13",
								"type":"text","x":0,"y":0,"w":"100%","h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodyLit"],"text":"AI is thinking...",
								"fontSize":txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignH":1,"alignV":1,
							},
							{
								"hash":"1HAMROHSJ6",
								"type":BtnText("primary",100,25,"Abort",false,""),"id":"BtnAbort","x":"50%","y":20,"anchorX":1,
								"OnClick":function(event){
									/*#{1HAMROHSJ15FunctionBody*/
									self.abortChat();
									/*}#1HAMROHSJ15FunctionBody*/
								},
							}
						],
					}
				],
			}
		],
		get $$defAssistant(){return state["defAssistant"]},
		set $$defAssistant(v){
			state["defAssistant"]=v;
			/*#{1HAMRK4MB1SetdefAssistant*/
			/*}#1HAMRK4MB1SetdefAssistant*/
		},
		/*#{1HAMRK4MB1ExtraCSS*/
		/*}#1HAMRK4MB1ExtraCSS*/
		faces:{
			"start":{
				/*BoxInput*/"#1HAMROHSE2":{
					"display":0
				},
				/*BoxWait*/"#1HAMROHSI11":{
					"display":0
				}
			},"input":{
				/*BoxInput*/"#1HAMROHSE2":{
					"display":1
				},
				/*BoxWait*/"#1HAMROHSI11":{
					"display":0
				}
			},"wait":{
				/*BoxInput*/"#1HAMROHSE2":{
					"display":0
				},
				/*BoxWait*/"#1HAMROHSI11":{
					"display":1
				}
			},"filemenu":{
				/*BoxFileBtnsFrame*/"#1HBHSL4O70":{
					"overflow":0
				},
				"#1HBHSRIG70":{
					"display":1
				},
				/*BtnLocalFile*/"#1HBHSPMP80":{
					"display":1
				},
				/*BtnNativeFile*/"#1HBHSQC010":{
					"display":1
				}
			},"!filemenu":{
				/*BoxFileBtnsFrame*/"#1HBHSL4O70":{
					"overflow":1
				},
				"#1HBHSRIG70":{
					"display":0
				},
				/*BtnNativeFile*/"#1HBHSQC010":{
					"display":0
				}
			},"allowfile":{
				/*BoxFileBtnsFrame*/"#1HBHSL4O70":{
					"display":1
				},
				/*TxtInputHint*/"#1HAMROHSH13":{
					"x":40
				}
			},"!allowfile":{
				/*BoxFileBtnsFrame*/"#1HBHSL4O70":{
					"display":0
				},
				/*TxtInputHint*/"#1HAMROHSH13":{
					"x":18
				}
			}
		},
		OnCreate:function(){
			self=this;
			boxChatFrame=self.BoxChatFrame;boxChats=self.BoxChats;boxUser=self.BoxUser;btnLocalFile=self.BtnLocalFile;btnNativeFile=self.BtnNativeFile;edUserInput=self.EdUserInput;txtInputHint=self.TxtInputHint;
			/*#{1HAMRK4MB1Create*/
			let blockDef;
			app.boxChats=boxChats;
			edUserInput.text="";
			txtInputHint.display=true;
			self.showFace("start");
			
			if(opts.bubble){
				blockDef=BoxChatBubble;
			}else{
				blockDef=BoxAIChatBlock;
			}
			//Init blocks:
			boxChats.initBlockDef({
				"user":(session,blockVO)=>{
					return blockDef({
						...opts.user,
						//side:"right",icon:appCfg.sharedAssets+"/user.svg",iconBG:cfgColor.success,iconColor:cfgColor.fontPrimary,bgColor:cfgColor.body,textColor:cfgColor.fontBody,
						text:blockVO.text||blockVO.content,buttons:false,top:blockVO.top,image:blockVO.image,audio:blockVO.audio
					},session);
				},
				"greeting":(session,blockVO)=>{
					return blockDef({
						...opts.ai,
						//side:"left",icon:appCfg.sharedAssets+"/faces.svg",iconBG:cfgColor.warning,iconColor:cfgColor.fontPrimary,bgColor:cfgColor.body,textColor:cfgColor.fontBody,
						text:blockVO.text||blockVO.content,buttons:false,top:blockVO.top,image:blockVO.image,audio:blockVO.audio
					},session);
				},
				"assistant":(session,blockVO)=>{
					return blockDef({
						...opts.ai,
						text:blockVO.text||blockVO.content,buttons:true,top:blockVO.top,render:true,image:blockVO.image,audio:blockVO.audio
					},session);
				},
				"wait":(session,blockVO)=>{
					return blockDef({
						...opts.wait,
						text:blockVO.text||blockVO.content,buttons:false,top:blockVO.top,image:blockVO.image,audio:blockVO.audio
					},session);
				},
				"event":(session,blockVO)=>{
					return blockDef({
						...opts.event,
						text:blockVO.text||blockVO.content,buttons:false,top:blockVO.top,image:blockVO.image,audio:blockVO.audio
					},session);
				},
				"system":(session,blockVO)=>{
					return blockDef({
						...opts.event,
						text:blockVO.text||blockVO.content,buttons:false,top:blockVO.top,image:blockVO.image,audio:blockVO.audio
					},session);
				},
				"error":(session,blockVO)=>{
					return blockDef({
						...opts.error,
						text:blockVO.text||blockVO.content,buttons:false,top:blockVO.top,image:blockVO.image,audio:blockVO.audio
					},session);
				},
			},{
				"input":(session,blockVO)=>{
					return BoxAskUser({
						...opts.ask,
						...blockVO
					},session);
				},
				"confirm":(session,blockVO)=>{
					return BoxAskUser({
						...opts.ask,
						...blockVO
					},session);
				},
				"menu":(session,blockVO)=>{
					return BoxAskUser({
						...opts.ask,
						...blockVO
					},session);
				},
				"block":(session,blockVO)=>{
					//TODO: Support role:
					return BoxAskUser({
						...opts.ask,
						...blockVO
					},session);
				},
				"range":(session,blockVO)=>{
					return null;
				},
				"file":(session,blockVO)=>{
					return null;
				},
				"photo":(session,blockVO)=>{
					return null;
				},
				"chatInput":self.chatInput,
				"cancelChatInput":self.cancelChatInput,
			});
			/*}#1HAMRK4MB1Create*/
		},
		/*#{1HAMRK4MB1EndCSS*/
		/*}#1HAMRK4MB1EndCSS*/
	};
	/*#{1HAMRK4MB1PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.initChat=async function(vo){
		let session,url,bot;
		initVO=vo;
		url=vo.url||vo.bot;
		self.showFace("start");
		if(!(await tabNT.checkLogin(true,true))){
			let res=await tabNT.makeCall("checkAICallStatus",{},5000);
			if(res.code!==200){
				let rootApp;
				rootApp=app.appFrame?app.appFrame.app:app;
				if(!(await rootApp.modalDlg(DlgLogin,{x:rootApp.width/2,y:100,alignH:1}))){
					boxChats.appendChatBlock({type:"error",text:(($ln==="CN")?("请先登录Tab-OS以使用与AI相关的API。"):/*EN*/("Please login Tab-OS first to use AI related APIs."))});
					app.emit("SessionLoadError",(($ln==="CN")?("请先登录Tab-OS以使用与AI相关的API。"):/*EN*/("Please login Tab-OS first to use AI related APIs.")));
					return;
				}
				await tabNT.checkLogin(false);
			}
			app.emit("UpdateTokenGas");
		}
		self.session=session=await boxChats.initSession(url,true,false,vo.json);
		await self.startSession(session);
	};
	
	//------------------------------------------------------------------------
	cssVO.startSession=async function(session){
		let bot;
		bot=session.entryBot;
		if(!bot){
			return;
		}
		if(bot.isAIChatBot){
			if(bot.allowFile){
				self.showFace("allowfile");
			}else{
				self.showFace("!allowfile");
			}
			self.showFace("input");
			edUserInput.focus();
			app.emit("SessionReady",session);
		}else if(bot.isAIAgent){
			app.emit("SessionReady",session);
			if(bot.autoStart && initVO.autoStart!==false){
				app.emit("StartAgent",session);
				await boxChats.execChat(bot.url,"");
				app.emit("EndAgent",session,bot);
			}
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.loadDebug=async function(vo,path){
		let session;
		self.showFace("start");
		if(!(await tabNT.checkLogin(false))){
			let res=await tabNT.makeCall("checkAICallStatus",{},5000);
			if(res.code!==200){
				let rootApp;
				rootApp=app.appFrame?app.appFrame.app:app;
				if(!(await rootApp.modalDlg(DlgLogin,{x:rootApp.width/2,y:100,alignH:1}))){
					boxChats.appendChatBlock({type:"error",text:(($ln==="CN")?("请先登录Tab-OS以使用与AI相关的API。"):/*EN*/("Please login Tab-OS first to use AI related APIs."))});
					app.emit("SessionLoadError",(($ln==="CN")?("请先登录Tab-OS以使用与AI相关的API。"):/*EN*/("Please login Tab-OS first to use AI related APIs.")));
					return;
				}
				await tabNT.checkLogin(false);
			}
		}
		this.session=session=await boxChats.initSession(vo.entryURL);
		await this.session.loadFromSaveVO(vo,path);
		if(session.entryBot && session.entryBot.allowFile){
			self.showFace("allowfile");
		}else{
			self.showFace("!allowfile");
		}
		app.emit("SessionReady",session);
		self.showFace("input");
		edUserInput.focus();
	};
	
	//------------------------------------------------------------------------
	cssVO.useLocalFile=async function(){
		let path,item;
		path=pathLib.dirname(this.session.entryBot.url);
		if(path.startsWith("/~/")){
			path=path.substring(2);
		}else if(path.startsWith("//")){
			path=path.substring(1);
		}
		item=await app.modalDlg(DlgMenu,{
			hud:self.BtnLocalFile,
			items:[
				{text:(($ln==="CN")?("使用文件路径"):/*EN*/("Use file path")),code:"path"},
				{text:(($ln==="CN")?("使用文件内容"):/*EN*/("Use file content")),code:"content"},
			]
		});
		if(!item){
			return;
		}
	
		path=await app.modalDlg(DlgFile,{
			mode:"open",
			path:path,
			options:{preview:1},
		});
		if(!path){
			return;
		}
		if(item.code==="path"){
			edUserInput.text+=`\$\{\{file:${path}\}\}`;
		}else{
			let text;
			try{
				text=await tabFS.readFile(path,"utf8");
				edUserInput.text+="\n```\n"+text+"\n```\n";
			}catch(err){
			}
		}
		edUserInput.OnInput();
	};
	
	async function arrayBuffer(file){
		if(file.arrayBuffer){
			return file.arrayBuffer();
		}
		return new Promise((onDone,onError)=>{
			let reader=new FileReader();
			reader.onload=function(event) {
				let arrayBuffer = event.target.result;
				onDone(arrayBuffer);
			};
			reader.readAsArrayBuffer(file);
		})
	}
	
	//------------------------------------------------------------------------
	cssVO.useNativeFile=async function(file){
		let buf,byteAry,text;
		if(!file){
			return;
		}
		try{
			buf=await arrayBuffer(file);
			byteAry = new Uint8Array(buf);
			let enc = new TextDecoder("utf-8");
			text=enc.decode(byteAry);
			edUserInput.text+="\n```\n"+text+"\n```\n";
			edUserInput.OnInput();
		}catch(err){
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.chatInput=function(vo){
		let pms;
		self.showFace("input");
		edUserInput.text=vo.text||"";
		if(vo.text){
			txtInputHint.display=false;
		}
		allowEmptyChat=vo.allowEmpty||false;
		edUserInput.focus();
		pms=new Promise((resolve,reject)=>{
			chatCallback=resolve;
		});
		return pms;
	};
	
	//------------------------------------------------------------------------
	cssVO.cancelChatInput=function(){
		let callback;
		callback=chatCallback;
		if(callback){
			chatCallback=null;
			callback(null);
			self.showFace("start");
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.sendChat=async function(){
		let text,callback;
		text=edUserInput.text;
		if(!text && !allowEmptyChat)
			return;
		callback=chatCallback;
		if(callback){
			chatCallback=null;
			callback(text);
			self.showFace("start");
			return;
		}
		self.showFace("wait");
		app.emit("StartChat");
		try{
			await boxChats.execChat(null,text);
		}catch(err){
		}
		edUserInput.text="";
		txtInputHint.display=true;
		self.showFace("input");
		app.emit("EndChat");
		app.emit("CheckCY");
		edUserInput.focus();
	};
	
	//------------------------------------------------------------------------
	cssVO.resetChat=async function(){
		let session,bot;
		edUserInput.text="";
		txtInputHint.display=true;
		self.session=session=await boxChats.resetChat();
		await self.startSession(session);
	};
	
	//------------------------------------------------------------------------
	cssVO.clearChats=async function(){
		boxChats.clearChats();
		edUserInput.text="";
		txtInputHint.display=true;
		self.showFace("input");
		edUserInput.focus();
		app.emit("SessionReady",boxChats.session);
	};
	
	//------------------------------------------------------------------------
	cssVO.abortChat=async function(){
		await boxChats.abortChat((($ln==="CN")?("用户终止"):/*EN*/("User abort")));
	};
	/*}#1HAMRK4MB1PostCSSVO*/
	return cssVO;
};
/*#{1HAMRK4MB1ExCodes*/
/*}#1HAMRK4MB1ExCodes*/

UIChat.gearExport={
	framework: "jax",
	hudType: "hud",
	"showName":"UIChat",icon:"gears.svg",previewImg:false,
	fixPose:false,initW:500,initH:300,
	catalog:"Views",
	args: {
		"opts": {
			"type": "object", "name": "opts", "showName": "opts", "icon": undefined, 
			"def": {
				"attrs": {
					"bubble": {
						"name": "bubble", "showName": "bubble", "type": "bool", "key": true, "fixed": true, "initVal": false
					}, 
					"ai": {
						"type": "object", "name": "ai", "showName": "ai", "icon": undefined, 
						"def": {
							"attrs": {
								"blkColor": {
									"name": "blkColor", "showName": "blkColor", "type": "colorRGBA", "key": true, "fixed": true, 
									"initVal": [0,0,0,0]
								}, 
								"bgColor": {
									"name": "bgColor", "showName": "bgColor", "type": "colorRGBA", "key": true, "fixed": true, 
									"initVal": [0,128,0,1], "initValText": "#cfgColor[\"success\"]"
								}, 
								"icon": {
									"name": "icon", "showName": "icon", "type": "url", "key": true, "fixed": true, "initVal": "/~/-tabos/shared/assets/faces.svg", "initValText": "#appCfg.sharedAssets+\"/faces.svg\""
								}, 
								"pic": {
									"name": "pic", "showName": "pic", "type": "url", "key": true, "fixed": true, "initVal": ""
								}, 
								"textColor": {
									"name": "textColor", "showName": "textColor", "type": "colorRGBA", "key": true, "fixed": true, 
									"initVal": [0,0,0,1], "initValText": "#cfgColor[\"fontBody\"]"
								}, 
								"iconColor": {
									"name": "iconColor", "showName": "iconColor", "type": "colorRGBA", "key": true, "fixed": true, 
									"initVal": [255,255,255,1], "initValText": "#cfgColor[\"fontSuccess\"]"
								}, 
								"side": {
									"name": "side", "showName": "side", "type": "string", "key": true, "fixed": true, "initVal": "left"
								}
							}
						}, 
						"key": true, "fixed": true
					}, 
					"user": {
						"type": "object", "name": "user", "showName": "user", "icon": undefined, 
						"def": {
							"attrs": {
								"blkColor": {
									"name": "blkColor", "showName": "blkColor", "type": "colorRGBA", "key": true, "fixed": true, 
									"initVal": [0,0,0,0]
								}, 
								"bgColor": {
									"name": "bgColor", "showName": "bgColor", "type": "colorRGBA", "key": true, "fixed": true, 
									"initVal": [13,110,253,1], "initValText": "#cfgColor.primary"
								}, 
								"icon": {
									"name": "icon", "showName": "icon", "type": "url", "key": true, "fixed": true, "initVal": "/~/-tabos/shared/assets/user.svg", "initValText": "#appCfg.sharedAssets+\"/user.svg\""
								}, 
								"pic": {
									"name": "pic", "showName": "pic", "type": "url", "key": true, "fixed": true, "initVal": ""
								}, 
								"textColor": {
									"name": "textColor", "showName": "textColor", "type": "colorRGBA", "key": true, "fixed": true, 
									"initVal": [0,0,0,1], "initValText": "#cfgColor[\"fontBody\"]"
								}, 
								"iconColor": {
									"name": "iconColor", "showName": "iconColor", "type": "colorRGBA", "key": true, "fixed": true, 
									"initVal": [255,255,255,1], "initValText": "#cfgColor[\"fontPrimary\"]"
								}, 
								"side": {
									"name": "side", "showName": "side", "type": "string", "key": true, "fixed": true, "initVal": "right"
								}
							}
						}, 
						"key": true, "fixed": true
					}, 
					"wait": {
						"type": "object", "name": "wait", "showName": "wait", "icon": undefined, 
						"def": {
							"attrs": {
								"blkColor": {
									"name": "blkColor", "showName": "blkColor", "type": "colorRGBA", "key": true, "fixed": true, 
									"initVal": [0,0,0,0]
								}, 
								"bgColor": {
									"name": "bgColor", "showName": "bgColor", "type": "colorRGBA", "key": true, "fixed": true, 
									"initVal": [108,117,125,1], "initValText": "#cfgColor[\"secondary\"]"
								}, 
								"icon": {
									"name": "icon", "showName": "icon", "type": "url", "key": true, "fixed": true, "initVal": "/~/-tabos/shared/assets/faces.svg", "initValText": "#appCfg.sharedAssets+\"/faces.svg\""
								}, 
								"pic": {
									"name": "pic", "showName": "pic", "type": "url", "key": true, "fixed": true, "initVal": ""
								}, 
								"textColor": {
									"name": "textColor", "showName": "textColor", "type": "colorRGBA", "key": true, "fixed": true, 
									"initVal": [0,0,0,1], "initValText": "#cfgColor[\"fontBody\"]"
								}, 
								"iconColor": {
									"name": "iconColor", "showName": "iconColor", "type": "colorRGBA", "key": true, "fixed": true, 
									"initVal": [255,255,255,1], "initValText": "#cfgColor[\"fontSecondary\"]"
								}, 
								"side": {
									"name": "side", "showName": "side", "type": "string", "key": true, "fixed": true, "initVal": "left"
								}
							}
						}, 
						"key": true, "fixed": true
					}, 
					"event": {
						"type": "object", "name": "event", "showName": "event", "icon": undefined, 
						"def": {
							"attrs": {
								"blkColor": {
									"name": "blkColor", "showName": "blkColor", "type": "colorRGBA", "key": true, "fixed": true, 
									"initVal": [0,0,0,0]
								}, 
								"bgColor": {
									"name": "bgColor", "showName": "bgColor", "type": "colorRGBA", "key": true, "fixed": true, 
									"initVal": [255,128,12,1], "initValText": "#cfgColor[\"warning\"]"
								}, 
								"icon": {
									"name": "icon", "showName": "icon", "type": "url", "key": true, "fixed": true, "initVal": "/~/-tabos/shared/assets/event.svg", "initValText": "#appCfg.sharedAssets+\"/event.svg\""
								}, 
								"pic": {
									"name": "pic", "showName": "pic", "type": "url", "key": true, "fixed": true, "initVal": ""
								}, 
								"textColor": {
									"name": "textColor", "showName": "textColor", "type": "colorRGBA", "key": true, "fixed": true, 
									"initVal": [0,0,0,1], "initValText": "#cfgColor[\"fontBody\"]"
								}, 
								"iconColor": {
									"name": "iconColor", "showName": "iconColor", "type": "colorRGBA", "key": true, "fixed": true, 
									"initVal": [255,255,255,1], "initValText": "#cfgColor[\"fontWarning\"]"
								}, 
								"side": {
									"name": "side", "showName": "side", "type": "string", "key": true, "fixed": true, "initVal": "left"
								}
							}
						}, 
						"key": true, "fixed": true
					}, 
					"error": {
						"type": "object", "name": "error", "showName": "error", "icon": undefined, 
						"def": {
							"attrs": {
								"blkColor": {
									"name": "blkColor", "showName": "blkColor", "type": "colorRGBA", "key": true, "fixed": true, 
									"initVal": [0,0,0,0]
								}, 
								"bgColor": {
									"name": "bgColor", "showName": "bgColor", "type": "colorRGBA", "key": true, "fixed": true, 
									"initVal": [240,0,0,1], "initValText": "#cfgColor[\"error\"]"
								}, 
								"icon": {
									"name": "icon", "showName": "icon", "type": "url", "key": true, "fixed": true, "initVal": "/~/-tabos/shared/assets/fat_right.svg", "initValText": "#appCfg.sharedAssets+\"/fat_right.svg\""
								}, 
								"pic": {
									"name": "pic", "showName": "pic", "type": "url", "key": true, "fixed": true, "initVal": ""
								}, 
								"textColor": {
									"name": "textColor", "showName": "textColor", "type": "colorRGBA", "key": true, "fixed": true, 
									"initVal": [155,0,0,1]
								}, 
								"iconColor": {
									"name": "iconColor", "showName": "iconColor", "type": "colorRGB", "key": true, "fixed": true, 
									"initVal": [255,255,255,1], "initValText": "#cfgColor[\"fontError\"]"
								}, 
								"side": {
									"name": "side", "showName": "side", "type": "string", "key": true, "fixed": true, "initVal": "left"
								}
							}
						}, 
						"key": true, "fixed": true
					}, 
					"ask": {
						"type": "object", "name": "ask", "showName": "ask", "icon": undefined, 
						"def": {
							"attrs": {
								"blkColor": {
									"name": "blkColor", "showName": "blkColor", "type": "colorRGBA", "key": true, "fixed": true, 
									"initVal": [0,0,0,0]
								}, 
								"bgColor": {
									"name": "bgColor", "showName": "bgColor", "type": "colorRGBA", "key": true, "fixed": true, 
									"initVal": [0,128,0,1], "initValText": "#cfgColor[\"success\"]"
								}, 
								"icon": {
									"name": "icon", "showName": "icon", "type": "url", "key": true, "fixed": true, "initVal": "/~/-tabos/shared/assets/help.svg", "initValText": "#appCfg.sharedAssets+\"/help.svg\""
								}, 
								"pic": {
									"name": "pic", "showName": "pic", "type": "url", "key": true, "fixed": true, "initVal": ""
								}, 
								"textColor": {
									"name": "textColor", "showName": "textColor", "type": "colorRGBA", "key": true, "fixed": true, 
									"initVal": [0,0,0,1], "initValText": "#cfgColor[\"fontBody\"]"
								}, 
								"iconColor": {
									"name": "iconColor", "showName": "iconColor", "type": "colorRGBA", "key": true, "fixed": true, 
									"initVal": [255,255,255,1], "initValText": "#cfgColor[\"fontSuccess\"]"
								}, 
								"side": {
									"name": "side", "showName": "side", "type": "string", "key": true, "fixed": true, "initVal": "left"
								}
							}
						}, 
						"key": true, "fixed": true
					}
				}
			}, 
			"key": true, "fixed": true
		}
	},
	state:{
		defAssistant:{name:"defAssistant",type:"object",initVal:undefined}
	},
	properties:["id","position","x","y","w","h","anchorH","anchorV","autoLayout","display","clip","uiEvent","alpha","rotate","scale","cursor","zIndex","flex","margin","traceSize","padding","minW","minH","maxW","maxH"],
	faces:["start","input","wait","filemenu","!filemenu","allowfile","!allowfile"],
	subContainers:{
	},
	/*#{1HAMRK4MB0ExGearInfo*/
	/*}#1HAMRK4MB0ExGearInfo*/
};
export default UIChat;
export{UIChat};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1HAMRK4MB0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1HAMRK4MB2",
//			"attrs": {
//				"device": "Desktop 800x600",
//				"screenW": "800",
//				"screenH": "600",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1HAMRK4MB3",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1HAMRK4MB4",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1HAMRK4MB5",
//			"attrs": {
//				"opts": {
//					"type": "object",
//					"def": "FlatObj",
//					"jaxId": "1HB2CA95A0",
//					"attrs": {
//						"bubble": {
//							"type": "bool",
//							"valText": "false"
//						},
//						"ai": {
//							"type": "object",
//							"def": "FlatObj",
//							"jaxId": "1HB2CA95A1",
//							"attrs": {
//								"blkColor": {
//									"type": "colorRGBA",
//									"valText": "[0,0,0,0.00]"
//								},
//								"bgColor": {
//									"type": "colorRGBA",
//									"valText": "#cfgColor[\"success\"]"
//								},
//								"icon": {
//									"type": "url",
//									"valText": "#appCfg.sharedAssets+\"/faces.svg\""
//								},
//								"pic": {
//									"type": "url",
//									"valText": ""
//								},
//								"textColor": {
//									"type": "colorRGBA",
//									"valText": "#cfgColor[\"fontBody\"]"
//								},
//								"iconColor": {
//									"type": "colorRGBA",
//									"valText": "#cfgColor[\"fontSuccess\"]"
//								},
//								"side": {
//									"type": "string",
//									"valText": "left"
//								}
//							}
//						},
//						"user": {
//							"type": "object",
//							"def": "FlatObj",
//							"jaxId": "1HB2CA95A2",
//							"attrs": {
//								"blkColor": {
//									"type": "colorRGBA",
//									"valText": "[0,0,0,0.00]"
//								},
//								"bgColor": {
//									"type": "colorRGBA",
//									"valText": "#cfgColor.primary"
//								},
//								"icon": {
//									"type": "url",
//									"valText": "#appCfg.sharedAssets+\"/user.svg\""
//								},
//								"pic": {
//									"type": "url",
//									"valText": ""
//								},
//								"textColor": {
//									"type": "colorRGBA",
//									"valText": "#cfgColor[\"fontBody\"]"
//								},
//								"iconColor": {
//									"type": "colorRGBA",
//									"valText": "#cfgColor[\"fontPrimary\"]"
//								},
//								"side": {
//									"type": "string",
//									"valText": "right"
//								}
//							}
//						},
//						"wait": {
//							"type": "object",
//							"def": "FlatObj",
//							"jaxId": "1HB2J3M5P0",
//							"attrs": {
//								"blkColor": {
//									"type": "colorRGBA",
//									"valText": "[0,0,0,0.00]"
//								},
//								"bgColor": {
//									"type": "colorRGBA",
//									"valText": "#cfgColor[\"secondary\"]"
//								},
//								"icon": {
//									"type": "url",
//									"valText": "#appCfg.sharedAssets+\"/faces.svg\""
//								},
//								"pic": {
//									"type": "url",
//									"valText": ""
//								},
//								"textColor": {
//									"type": "colorRGBA",
//									"valText": "#cfgColor[\"fontBody\"]"
//								},
//								"iconColor": {
//									"type": "colorRGBA",
//									"valText": "#cfgColor[\"fontSecondary\"]"
//								},
//								"side": {
//									"type": "string",
//									"valText": "left"
//								}
//							}
//						},
//						"event": {
//							"type": "object",
//							"def": "FlatObj",
//							"jaxId": "1HB2KQCVB0",
//							"attrs": {
//								"blkColor": {
//									"type": "colorRGBA",
//									"valText": "[0,0,0,0.00]"
//								},
//								"bgColor": {
//									"type": "colorRGBA",
//									"valText": "#cfgColor[\"warning\"]"
//								},
//								"icon": {
//									"type": "url",
//									"valText": "#appCfg.sharedAssets+\"/event.svg\""
//								},
//								"pic": {
//									"type": "url",
//									"valText": ""
//								},
//								"textColor": {
//									"type": "colorRGBA",
//									"valText": "#cfgColor[\"fontBody\"]"
//								},
//								"iconColor": {
//									"type": "colorRGBA",
//									"valText": "#cfgColor[\"fontWarning\"]"
//								},
//								"side": {
//									"type": "string",
//									"valText": "left"
//								}
//							}
//						},
//						"error": {
//							"type": "object",
//							"def": "FlatObj",
//							"jaxId": "1HB2KQCVB1",
//							"attrs": {
//								"blkColor": {
//									"type": "colorRGBA",
//									"valText": "[0,0,0,0.00]"
//								},
//								"bgColor": {
//									"type": "colorRGBA",
//									"valText": "#cfgColor[\"error\"]"
//								},
//								"icon": {
//									"type": "url",
//									"valText": "#appCfg.sharedAssets+\"/fat_right.svg\""
//								},
//								"pic": {
//									"type": "url",
//									"valText": ""
//								},
//								"textColor": {
//									"type": "colorRGBA",
//									"valText": "[155,0,0,1.00]"
//								},
//								"iconColor": {
//									"type": "colorRGB",
//									"valText": "#cfgColor[\"fontError\"]"
//								},
//								"side": {
//									"type": "string",
//									"valText": "left"
//								}
//							}
//						},
//						"ask": {
//							"type": "object",
//							"def": "FlatObj",
//							"jaxId": "1HB2KQCVB2",
//							"attrs": {
//								"blkColor": {
//									"type": "colorRGBA",
//									"valText": "[0,0,0,0.00]"
//								},
//								"bgColor": {
//									"type": "colorRGBA",
//									"valText": "#cfgColor[\"success\"]"
//								},
//								"icon": {
//									"type": "url",
//									"valText": "#appCfg.sharedAssets+\"/help.svg\""
//								},
//								"pic": {
//									"type": "url",
//									"valText": ""
//								},
//								"textColor": {
//									"type": "colorRGBA",
//									"valText": "#cfgColor[\"fontBody\"]"
//								},
//								"iconColor": {
//									"type": "colorRGBA",
//									"valText": "#cfgColor[\"fontSuccess\"]"
//								},
//								"side": {
//									"type": "string",
//									"valText": "left"
//								}
//							}
//						}
//					}
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1HAMRK4MB6",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1HAMRK4MB7",
//			"attrs": {
//				"defAssistant": {
//					"type": "object",
//					"def": "Object",
//					"jaxId": "1HAVQG08H0",
//					"attrs": {
//						"colorBG": {
//							"type": "colorRGBA",
//							"valText": "#cfgColor[\"success\"]"
//						}
//					}
//				}
//			}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "UIChat",
//		"gearIcon": "gears.svg",
//		"gearW": "500",
//		"gearH": "300",
//		"gearCatalog": "Views",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1HAMRK4MB8",
//			"attrs": {
//				"start": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HAMS3KJL0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HAMS4K160",
//							"attrs": {}
//						}
//					}
//				},
//				"input": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HAMS4K161",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HAMS4K162",
//							"attrs": {}
//						}
//					}
//				},
//				"wait": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HAMS4K163",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HAMS4K164",
//							"attrs": {}
//						}
//					}
//				},
//				"filemenu": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HBHT74HN0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HBHTAIUS0",
//							"attrs": {}
//						}
//					}
//				},
//				"!filemenu": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HBHT8HLB0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HBHTAIUS1",
//							"attrs": {}
//						}
//					}
//				},
//				"allowfile": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HBHUAT3S0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HBHUC9450",
//							"attrs": {}
//						}
//					}
//				},
//				"!allowfile": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HBHUBGFH0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HBHUC9451",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1HAMRK4MB9",
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1HAMRK4MB1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1HAMRK4MB10",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "100%",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": ""
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1HAMRQ87E0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HAMRSPCM0",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxChatFrame",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Auto Scroll Y",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "[5,0,60,0]",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "100%-30",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex Y"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "Gear1HA0EN6720",
//											"jaxId": "1HAMRU2MG0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1HAMRVD260",
//													"attrs": {}
//												},
//												"properties": {
//													"jaxId": "1HAMRVD261",
//													"attrs": {
//														"type": "#null#>BoxAIChat()",
//														"id": "BoxChats",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"w": "100%",
//														"h": ""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HAMRVD262",
//													"attrs": {
//														"1HAMS4K161": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAMSMGCP0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAMSMGCP1",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAMS4K161",
//															"faceTagName": "input"
//														},
//														"1HBHT74HN0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HBHU5CAO0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HBHU5CAO1",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HBHT74HN0",
//															"faceTagName": "filemenu"
//														},
//														"1HBHUAT3S0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HBHUC9452",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HBHUC9453",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HBHUAT3S0",
//															"faceTagName": "allowfile"
//														},
//														"1HAMS4K163": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HCKNT1KN0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HCKNT1KN1",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAMS4K163",
//															"faceTagName": "wait"
//														},
//														"1HBHT8HLB0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HD6JA7JV0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HD6JA7JV1",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HBHT8HLB0",
//															"faceTagName": "!filemenu"
//														},
//														"1HAMS3KJL0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HJQHBT0M0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HJQHBT0M1",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAMS3KJL0",
//															"faceTagName": "start"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HAMRVD263",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HAMRVD264",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1HAMRVD265",
//													"attrs": {}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1HAMRSPCM1",
//									"attrs": {
//										"1HAMS4K161": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HAMSMGCP2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HAMSMGCP3",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HAMS4K161",
//											"faceTagName": "input"
//										},
//										"1HBHT74HN0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HBHU5CAO2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HBHU5CAO3",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HBHT74HN0",
//											"faceTagName": "filemenu"
//										},
//										"1HBHUAT3S0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HBHUC9456",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HBHUC9457",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HBHUAT3S0",
//											"faceTagName": "allowfile"
//										},
//										"1HAMS4K163": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HCKNT1KN2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HCKNT1KN3",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HAMS4K163",
//											"faceTagName": "wait"
//										},
//										"1HBHT8HLB0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HD6JA7JV2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HD6JA7JV3",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HBHT8HLB0",
//											"faceTagName": "!filemenu"
//										},
//										"1HAMS3KJL0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HJQHBT0M2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HJQHBT0M3",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HAMS3KJL0",
//											"faceTagName": "start"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HAMRSPCM2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HAMRSPCM3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1HAMROHSE0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HAMROHSE1",
//									"attrs": {
//										"type": "box",
//										"id": "BoxUser",
//										"position": "Absolute",
//										"x": "50%",
//										"y": "100%-10",
//										"w": "100%-80",
//										"h": "",
//										"anchorH": "Center",
//										"anchorV": "Bottom",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "30",
//										"maxW": "600",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "[255,255,255,1.00]",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "3",
//										"shadow": "true",
//										"shadowX": "0",
//										"shadowY": "1",
//										"shadowBlur": "4",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.30]",
//										"contentLayout": "Flex Y"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1HAMROHSE2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HAMROHSE3",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxInput",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "[5,10,5,10]",
//														"minW": "",
//														"minH": "20",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex X",
//														"traceSize": "true",
//														"itemsAlign": "Center"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1HBHSL4O70",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HBHT2USB0",
//																	"attrs": {
//																		"type": "hud",
//																		"id": "BoxFileBtnsFrame",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "20",
//																		"h": "20",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "Off",
//																		"clip": "On",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[0,5,0,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": [
//																		{
//																			"type": "hudobj",
//																			"def": "hud",
//																			"jaxId": "1HBHSOUU60",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HBHT2USB1",
//																					"attrs": {
//																						"type": "hud",
//																						"id": "BoxButtons",
//																						"position": "Absolute",
//																						"x": "0",
//																						"y": "20",
//																						"w": "20",
//																						"h": "40",
//																						"anchorH": "Left",
//																						"anchorV": "Bottom",
//																						"autoLayout": "false",
//																						"display": "On",
//																						"clip": "Off",
//																						"uiEvent": "On",
//																						"alpha": "1",
//																						"rotate": "0",
//																						"scale": "",
//																						"filter": "",
//																						"cursor": "",
//																						"zIndex": "0",
//																						"margin": "",
//																						"padding": "",
//																						"minW": "",
//																						"minH": "",
//																						"maxW": "",
//																						"maxH": "",
//																						"face": "",
//																						"styleClass": ""
//																					}
//																				},
//																				"subHuds": {
//																					"attrs": [
//																						{
//																							"type": "hudobj",
//																							"def": "box",
//																							"jaxId": "1HBHSRIG70",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HBHT2USB2",
//																									"attrs": {
//																										"type": "box",
//																										"id": "",
//																										"position": "Absolute",
//																										"x": "-3",
//																										"y": "-3",
//																										"w": "100%+6",
//																										"h": "100%+6",
//																										"anchorH": "Left",
//																										"anchorV": "Top",
//																										"autoLayout": "false",
//																										"display": "Off",
//																										"clip": "Off",
//																										"uiEvent": "On",
//																										"alpha": "1",
//																										"rotate": "0",
//																										"scale": "",
//																										"filter": "",
//																										"cursor": "",
//																										"zIndex": "0",
//																										"margin": "",
//																										"padding": "",
//																										"minW": "",
//																										"minH": "",
//																										"maxW": "",
//																										"maxH": "",
//																										"face": "",
//																										"styleClass": "",
//																										"background": "#cfgColor[\"body\"]",
//																										"border": "1",
//																										"borderStyle": "Solid",
//																										"borderColor": "#cfgColor[\"fontBodyLit\"]",
//																										"corner": "3",
//																										"shadow": "true",
//																										"shadowX": "0",
//																										"shadowY": "2",
//																										"shadowBlur": "5",
//																										"shadowSpread": "0",
//																										"shadowColor": "[0,0,0,0.30]"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1HBHT2USB3",
//																									"attrs": {
//																										"1HBHT74HN0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HBHTAIUT4",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HBHTAIUT5",
//																													"attrs": {
//																														"display": {
//																															"type": "choice",
//																															"valText": "On"
//																														}
//																													}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HBHT74HN0",
//																											"faceTagName": "filemenu"
//																										},
//																										"1HBHT8HLB0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HBHTAIUT6",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HBHTAIUT7",
//																													"attrs": {
//																														"display": {
//																															"type": "choice",
//																															"valText": "Off"
//																														}
//																													}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HBHT8HLB0",
//																											"faceTagName": "!filemenu"
//																										},
//																										"1HBHUAT3S0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HBHUC9460",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HBHUC9461",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HBHUAT3S0",
//																											"faceTagName": "allowfile"
//																										},
//																										"1HAMS4K161": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HCKNT1KN4",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HCKNT1KN5",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HAMS4K161",
//																											"faceTagName": "input"
//																										},
//																										"1HAMS4K163": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HCKNT1KN6",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HCKNT1KN7",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HAMS4K163",
//																											"faceTagName": "wait"
//																										},
//																										"1HAMS3KJL0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HJQHBT0M4",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HJQHBT0M5",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HAMS3KJL0",
//																											"faceTagName": "start"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1HBHT2USB4",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1HBHT2USB5",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "true",
//																								"nameVal": "false"
//																							}
//																						},
//																						{
//																							"type": "hudobj",
//																							"def": "Gear/@StdUI/ui/BtnIcon.js",
//																							"jaxId": "1HBHSPMP80",
//																							"attrs": {
//																								"createArgs": {
//																									"jaxId": "1HBHSPMP81",
//																									"attrs": {
//																										"style": "\"front\"",
//																										"w": "20",
//																										"h": "0",
//																										"icon": "#appCfg.sharedAssets+\"/folder.svg\"",
//																										"colorBG": "null"
//																									}
//																								},
//																								"properties": {
//																									"jaxId": "1HBHSPMP82",
//																									"attrs": {
//																										"type": "#null#>BtnIcon(\"front\",20,0,appCfg.sharedAssets+\"/folder.svg\",null)",
//																										"id": "BtnLocalFile",
//																										"position": "Absolute",
//																										"x": "0",
//																										"y": "20",
//																										"display": "On",
//																										"face": "",
//																										"margin": "[0,5,0,0]",
//																										"padding": "0",
//																										"anchorV": "Top",
//																										"autoLayout": "true"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1HBHSPMP90",
//																									"attrs": {
//																										"1HAMS4K161": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HBHSPMP91",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HBHSPMP92",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HAMS4K161",
//																											"faceTagName": "input"
//																										},
//																										"1HBHT74HN0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HBHTAIUT8",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HBHTAIUT9",
//																													"attrs": {
//																														"display": {
//																															"type": "choice",
//																															"valText": "On"
//																														}
//																													}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HBHT74HN0",
//																											"faceTagName": "filemenu"
//																										},
//																										"1HBHUAT3S0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HBHUC9464",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HBHUC9465",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HBHUAT3S0",
//																											"faceTagName": "allowfile"
//																										},
//																										"1HAMS4K163": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HCKNT1KN8",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HCKNT1KN9",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HAMS4K163",
//																											"faceTagName": "wait"
//																										},
//																										"1HBHT8HLB0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HD6JA1UU0",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HD6JA1UU1",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HBHT8HLB0",
//																											"faceTagName": "!filemenu"
//																										},
//																										"1HAMS3KJL0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HJQHBT0M6",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HJQHBT0M7",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HAMS3KJL0",
//																											"faceTagName": "start"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1HBHSPMP93",
//																									"attrs": {
//																										"OnClick": {
//																											"type": "fixedFunc",
//																											"jaxId": "1HBHSPMP94",
//																											"attrs": {
//																												"callArgs": {
//																													"jaxId": "1HBHSPMP95",
//																													"attrs": {
//																														"event": ""
//																													}
//																												},
//																												"seg": ""
//																											}
//																										}
//																									}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1HBHSPMP96",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "false",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "true",
//																								"containerSlots": {
//																									"jaxId": "1HBHSPMP97",
//																									"attrs": {}
//																								}
//																							}
//																						},
//																						{
//																							"type": "hudobj",
//																							"def": "Gear/@StdUI/ui/BtnIcon.js",
//																							"jaxId": "1HBHSQC010",
//																							"attrs": {
//																								"createArgs": {
//																									"jaxId": "1HBHSQC011",
//																									"attrs": {
//																										"style": "\"front\"",
//																										"w": "20",
//																										"h": "0",
//																										"icon": "#appCfg.sharedAssets+\"/upload.svg\"",
//																										"colorBG": "null"
//																									}
//																								},
//																								"properties": {
//																									"jaxId": "1HBHSQC012",
//																									"attrs": {
//																										"type": "#null#>BtnIcon(\"front\",20,0,appCfg.sharedAssets+\"/upload.svg\",null)",
//																										"id": "BtnNativeFile",
//																										"position": "Absolute",
//																										"x": "0",
//																										"y": "0",
//																										"display": "Off",
//																										"face": "",
//																										"margin": "[0,5,0,0]",
//																										"padding": "0",
//																										"anchorV": "Top",
//																										"autoLayout": "true"
//																									}
//																								},
//																								"subHuds": {
//																									"attrs": []
//																								},
//																								"faces": {
//																									"jaxId": "1HBHSQC013",
//																									"attrs": {
//																										"1HAMS4K161": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HBHSQC014",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HBHSQC015",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HAMS4K161",
//																											"faceTagName": "input"
//																										},
//																										"1HBHT74HN0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HBHTAIUT12",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HBHTAIUT13",
//																													"attrs": {
//																														"display": {
//																															"type": "choice",
//																															"valText": "On"
//																														}
//																													}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HBHT74HN0",
//																											"faceTagName": "filemenu"
//																										},
//																										"1HBHT8HLB0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HBHTAIUT14",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HBHTAIUT15",
//																													"attrs": {
//																														"display": {
//																															"type": "choice",
//																															"valText": "Off"
//																														}
//																													}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HBHT8HLB0",
//																											"faceTagName": "!filemenu"
//																										},
//																										"1HBHUAT3S0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HBHUC9468",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HBHUC9469",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HBHUAT3S0",
//																											"faceTagName": "allowfile"
//																										},
//																										"1HAMS4K163": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HCKNT1KN10",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HCKNT1KN11",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HAMS4K163",
//																											"faceTagName": "wait"
//																										},
//																										"1HAMS3KJL0": {
//																											"type": "hudface",
//																											"def": "HudFace",
//																											"jaxId": "1HJQHBT0M8",
//																											"attrs": {
//																												"properties": {
//																													"jaxId": "1HJQHBT0M9",
//																													"attrs": {}
//																												},
//																												"anis": {
//																													"attrs": []
//																												}
//																											},
//																											"faceTagId": "1HAMS3KJL0",
//																											"faceTagName": "start"
//																										}
//																									}
//																								},
//																								"functions": {
//																									"jaxId": "1HBHSQC016",
//																									"attrs": {}
//																								},
//																								"extraPpts": {
//																									"jaxId": "1HBHSQC019",
//																									"attrs": {}
//																								},
//																								"mockup": "false",
//																								"codes": "true",
//																								"locked": "false",
//																								"container": "false",
//																								"nameVal": "true",
//																								"containerSlots": {
//																									"jaxId": "1HBHSQC0110",
//																									"attrs": {}
//																								}
//																							}
//																						}
//																					]
//																				},
//																				"faces": {
//																					"jaxId": "1HBHT2USB6",
//																					"attrs": {
//																						"1HBHT74HN0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HBHU5CAP0",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HBHU5CAP1",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HBHT74HN0",
//																							"faceTagName": "filemenu"
//																						},
//																						"1HBHUAT3S0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HBHUC94612",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HBHUC94613",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HBHUAT3S0",
//																							"faceTagName": "allowfile"
//																						},
//																						"1HAMS4K161": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HCKNT1KN12",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HCKNT1KN13",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAMS4K161",
//																							"faceTagName": "input"
//																						},
//																						"1HAMS4K163": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HCKNT1KN14",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HCKNT1KN15",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAMS4K163",
//																							"faceTagName": "wait"
//																						},
//																						"1HBHT8HLB0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HD6JA1UU2",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HD6JA1UU3",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HBHT8HLB0",
//																							"faceTagName": "!filemenu"
//																						},
//																						"1HAMS3KJL0": {
//																							"type": "hudface",
//																							"def": "HudFace",
//																							"jaxId": "1HJQHBT0M10",
//																							"attrs": {
//																								"properties": {
//																									"jaxId": "1HJQHBT0M11",
//																									"attrs": {}
//																								},
//																								"anis": {
//																									"attrs": []
//																								}
//																							},
//																							"faceTagId": "1HAMS3KJL0",
//																							"faceTagName": "start"
//																						}
//																					}
//																				},
//																				"functions": {
//																					"jaxId": "1HBHT2USB7",
//																					"attrs": {}
//																				},
//																				"extraPpts": {
//																					"jaxId": "1HBHT2USB8",
//																					"attrs": {}
//																				},
//																				"mockup": "false",
//																				"codes": "false",
//																				"locked": "false",
//																				"container": "true",
//																				"nameVal": "false",
//																				"exposeContainer": "false"
//																			}
//																		}
//																	]
//																},
//																"faces": {
//																	"jaxId": "1HBHT2USB9",
//																	"attrs": {
//																		"1HBHT8HLB0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HBHTJ6NT2",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HBHTJ6NT3",
//																					"attrs": {
//																						"clip": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HBHT8HLB0",
//																			"faceTagName": "!filemenu"
//																		},
//																		"1HBHT74HN0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HBHU5CAP2",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HBHU5CAP3",
//																					"attrs": {
//																						"clip": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HBHT74HN0",
//																			"faceTagName": "filemenu"
//																		},
//																		"1HBHUAT3S0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HBHUC94616",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HBHUC94617",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HBHUAT3S0",
//																			"faceTagName": "allowfile"
//																		},
//																		"1HBHUBGFH0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HBHUC94618",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HBHUC94619",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HBHUBGFH0",
//																			"faceTagName": "!allowfile"
//																		},
//																		"1HAMS4K161": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HCKNT1KN16",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HCKNT1KN17",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAMS4K161",
//																			"faceTagName": "input"
//																		},
//																		"1HAMS4K163": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HCKNT1KN18",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HCKNT1KN19",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAMS4K163",
//																			"faceTagName": "wait"
//																		},
//																		"1HAMS3KJL0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HJQHBT0M12",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HJQHBT0M13",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAMS3KJL0",
//																			"faceTagName": "start"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HBHT2USB10",
//																	"attrs": {
//																		"OnMouseInOut": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HBHU0P700",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1HBHU19670",
//																					"attrs": {
//																						"isIn": "",
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1HBHT2USB11",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false",
//																"exposeContainer": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "memo",
//															"jaxId": "1HAMROHSG7",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAMROHSG8",
//																	"attrs": {
//																		"type": "memo",
//																		"id": "EdUserInput",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%-100",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "20",
//																		"maxW": "",
//																		"maxH": "200",
//																		"face": "",
//																		"styleClass": "",
//																		"text": "",
//																		"color": "#cfgColor[\"fontBody\"]",
//																		"bgColor": "#cfgColor[\"body\"]",
//																		"font": "",
//																		"fontSize": "#txtSize.mid",
//																		"outline": "0",
//																		"border": "[0,0,1,0]",
//																		"borderStyle": "Solid",
//																		"borderColor": "[0,0,0,0.5]",
//																		"corner": "0",
//																		"readOnly": "false",
//																		"selectOnFocus": "true",
//																		"spellCheck": "true",
//																		"flex": "true"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HAMROHSG9",
//																	"attrs": {
//																		"1HAMS4K161": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAMSMGCP6",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAMSMGCP7",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAMS4K161",
//																			"faceTagName": "input"
//																		},
//																		"1HBHT74HN0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HBHU5CAP6",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HBHU5CAP7",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HBHT74HN0",
//																			"faceTagName": "filemenu"
//																		},
//																		"1HBHUAT3S0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HBHUC94624",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HBHUC94625",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HBHUAT3S0",
//																			"faceTagName": "allowfile"
//																		},
//																		"1HAMS4K163": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HCKNT1KN20",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HCKNT1KN21",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAMS4K163",
//																			"faceTagName": "wait"
//																		},
//																		"1HBHT8HLB0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HD6JA7JV4",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HD6JA7JV5",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HBHT8HLB0",
//																			"faceTagName": "!filemenu"
//																		},
//																		"1HAMS3KJL0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HJQHBT0M14",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HJQHBT0M15",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAMS3KJL0",
//																			"faceTagName": "start"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HAMROHSG14",
//																	"attrs": {
//																		"OnInput": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HAMROHSG15",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1HAMROHSG16",
//																					"attrs": {}
//																				},
//																				"seg": ""
//																			}
//																		},
//																		"OnKeyDown": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HAMROHSG17",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1HAMROHSG18",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1HAMROHSG19",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1HAMROHSH0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1HAMROHSH1",
//																	"attrs": {
//																		"style": "\"front\"",
//																		"w": "30",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/send.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1HAMROHSH2",
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"front\",30,0,appCfg.sharedAssets+\"/send.svg\",null)",
//																		"id": "BtnSend",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"margin": "[0,0,0,10]",
//																		"padding": "2",
//																		"anchorV": "Top",
//																		"autoLayout": "true"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HAMROHSH3",
//																	"attrs": {
//																		"1HAMS4K161": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAMSMGCP8",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAMSMGCP9",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAMS4K161",
//																			"faceTagName": "input"
//																		},
//																		"1HBHT74HN0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HBHU5CAP8",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HBHU5CAP9",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HBHT74HN0",
//																			"faceTagName": "filemenu"
//																		},
//																		"1HBHUAT3S0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HBHUC94628",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HBHUC94629",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HBHUAT3S0",
//																			"faceTagName": "allowfile"
//																		},
//																		"1HAMS4K163": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HCKNT1KN22",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HCKNT1KN23",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAMS4K163",
//																			"faceTagName": "wait"
//																		},
//																		"1HBHT8HLB0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HD6JA7JV6",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HD6JA7JV7",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HBHT8HLB0",
//																			"faceTagName": "!filemenu"
//																		},
//																		"1HAMS3KJL0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HJQHBT0M16",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HJQHBT0M17",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAMS3KJL0",
//																			"faceTagName": "start"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HAMROHSH8",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HAMROHSH9",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1HAMROHSH10",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1HAMROHSH11",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1HAMROHSH12",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1HAMROHSH13",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAMROHSH14",
//																	"attrs": {
//																		"type": "text",
//																		"id": "TxtInputHint",
//																		"position": "Absolute",
//																		"x": "18",
//																		"y": "0",
//																		"w": "100",
//																		"h": "100%",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "Tree Off",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontBodyLit\"]",
//																		"text": "Input chat message...",
//																		"font": "",
//																		"fontSize": "#txtSize.mid",
//																		"bold": "false",
//																		"italic": "true",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Center",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HAMROHSH15",
//																	"attrs": {
//																		"1HAMS4K161": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAMSMGCP10",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAMSMGCQ0",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAMS4K161",
//																			"faceTagName": "input"
//																		},
//																		"1HBHT74HN0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HBHU5CAP10",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HBHU5CAP11",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HBHT74HN0",
//																			"faceTagName": "filemenu"
//																		},
//																		"1HBHUAT3S0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HBHUC94632",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HBHUC94633",
//																					"attrs": {
//																						"x": {
//																							"type": "length",
//																							"valText": "40"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HBHUAT3S0",
//																			"faceTagName": "allowfile"
//																		},
//																		"1HBHUBGFH0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HBHUC94634",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HBHUC94635",
//																					"attrs": {
//																						"x": {
//																							"type": "length",
//																							"valText": "18"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HBHUBGFH0",
//																			"faceTagName": "!allowfile"
//																		},
//																		"1HAMS4K163": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HCKNT1KN24",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HCKNT1KN25",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAMS4K163",
//																			"faceTagName": "wait"
//																		},
//																		"1HBHT8HLB0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HD6JA7JV8",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HD6JA7JV9",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HBHT8HLB0",
//																			"faceTagName": "!filemenu"
//																		},
//																		"1HAMS3KJL0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HJQHBT0M18",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HJQHBT0M19",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAMS3KJL0",
//																			"faceTagName": "start"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HAMROHSH20",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HAMROHSH21",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true"
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1HAMROHSI0",
//													"attrs": {
//														"1HAMS3KJL0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAMSKQ1D12",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAMSKQ1D13",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAMS3KJL0",
//															"faceTagName": "start"
//														},
//														"1HAMS4K161": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAMSMGCQ1",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAMSMGCQ2",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAMS4K161",
//															"faceTagName": "input"
//														},
//														"1HAMS4K163": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAMSMS7V12",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAMSMS7V13",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAMS4K163",
//															"faceTagName": "wait"
//														},
//														"1HBHT74HN0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HBHU5CAP12",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HBHU5CAP13",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HBHT74HN0",
//															"faceTagName": "filemenu"
//														},
//														"1HBHUAT3S0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HBHUC94636",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HBHUC94637",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HBHUAT3S0",
//															"faceTagName": "allowfile"
//														},
//														"1HBHT8HLB0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HD6JA7JV10",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HD6JA7JV11",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HBHT8HLB0",
//															"faceTagName": "!filemenu"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HAMROHSI9",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HAMROHSI10",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1HAMROHSI11",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HAMROHSI12",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxWait",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "50",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "Off",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": ""
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1HAMROHSI13",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAMROHSI14",
//																	"attrs": {
//																		"type": "text",
//																		"id": "",
//																		"position": "Absolute",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "20",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontBodyLit\"]",
//																		"text": "AI is thinking...",
//																		"font": "",
//																		"fontSize": "#txtSize.smallPlus",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Center",
//																		"alignV": "Center",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HAMROHSI15",
//																	"attrs": {
//																		"1HAMS4K161": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAMSMGCQ3",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAMSMGCQ4",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAMS4K161",
//																			"faceTagName": "input"
//																		},
//																		"1HBHT74HN0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HBHU5CAP14",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HBHU5CAP15",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HBHT74HN0",
//																			"faceTagName": "filemenu"
//																		},
//																		"1HBHUAT3S0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HBHUC94640",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HBHUC94641",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HBHUAT3S0",
//																			"faceTagName": "allowfile"
//																		},
//																		"1HAMS4K163": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HCKNT1KN26",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HCKNT1KN27",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAMS4K163",
//																			"faceTagName": "wait"
//																		},
//																		"1HBHT8HLB0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HD6JA7JV12",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HD6JA7JV13",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HBHT8HLB0",
//																			"faceTagName": "!filemenu"
//																		},
//																		"1HAMS3KJL0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HJQHBT0M20",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HJQHBT0M21",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAMS3KJL0",
//																			"faceTagName": "start"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HAMROHSJ4",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HAMROHSJ5",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnText.js",
//															"jaxId": "1HAMROHSJ6",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1HAMROHSJ7",
//																	"attrs": {
//																		"style": "primary",
//																		"w": "100",
//																		"h": "25",
//																		"text": "Abort",
//																		"outlined": "false",
//																		"icon": ""
//																	}
//																},
//																"properties": {
//																	"jaxId": "1HAMROHSJ8",
//																	"attrs": {
//																		"type": "#null#>BtnText(\"primary\",100,25,\"Abort\",false,\"\")",
//																		"id": "BtnAbort",
//																		"position": "Absolute",
//																		"x": "50%",
//																		"y": "20",
//																		"display": "On",
//																		"face": "",
//																		"anchorH": "Center"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HAMROHSJ9",
//																	"attrs": {
//																		"1HAMS4K161": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAMSMGCQ5",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAMSMGCQ6",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAMS4K161",
//																			"faceTagName": "input"
//																		},
//																		"1HBHT74HN0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HBHU5CAP16",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HBHU5CAP17",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HBHT74HN0",
//																			"faceTagName": "filemenu"
//																		},
//																		"1HBHUAT3S0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HBHUC94644",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HBHUC94645",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HBHUAT3S0",
//																			"faceTagName": "allowfile"
//																		},
//																		"1HAMS4K163": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HCKNT1KN28",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HCKNT1KN29",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAMS4K163",
//																			"faceTagName": "wait"
//																		},
//																		"1HBHT8HLB0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HD6JA7JV14",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HD6JA7JV15",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HBHT8HLB0",
//																			"faceTagName": "!filemenu"
//																		},
//																		"1HAMS3KJL0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HJQHBT0M22",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HJQHBT0M23",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAMS3KJL0",
//																			"faceTagName": "start"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HAMROHSJ14",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HAMROHSJ15",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1HAMROHSJ16",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1HAMROHSJ17",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1HAMROHSJ18",
//																	"attrs": {
//																		"Slot1H2F6U36O0": {
//																			"jaxId": "1HAMROHSJ19",
//																			"attrs": {
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"container": "true"
//																			}
//																		}
//																	}
//																}
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1HAMROHSJ20",
//													"attrs": {
//														"1HAMS3KJL0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAMSKQ1D18",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAMSKQ1D19",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAMS3KJL0",
//															"faceTagName": "start"
//														},
//														"1HAMS4K161": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAMSMGCQ7",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAMSMGCQ8",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAMS4K161",
//															"faceTagName": "input"
//														},
//														"1HAMS4K163": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAMSMS7V18",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAMSMS7V19",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAMS4K163",
//															"faceTagName": "wait"
//														},
//														"1HBHT74HN0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HBHU5CAP18",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HBHU5CAP19",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HBHT74HN0",
//															"faceTagName": "filemenu"
//														},
//														"1HBHUAT3S0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HBHUC94648",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HBHUC94649",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HBHUAT3S0",
//															"faceTagName": "allowfile"
//														},
//														"1HBHT8HLB0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HD6JA7JV16",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HD6JA7JV17",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HBHT8HLB0",
//															"faceTagName": "!filemenu"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HAMROHSJ29",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HAMROHSJ30",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1HAMROHSJ31",
//									"attrs": {
//										"1HAMS4K161": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HAMSMGCQ9",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HAMSMGCQ10",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HAMS4K161",
//											"faceTagName": "input"
//										},
//										"1HBHT74HN0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HBHU5CAP20",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HBHU5CAP21",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HBHT74HN0",
//											"faceTagName": "filemenu"
//										},
//										"1HBHUAT3S0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HBHUC94652",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HBHUC94653",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HBHUAT3S0",
//											"faceTagName": "allowfile"
//										},
//										"1HAMS4K163": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HCKNT1KO0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HCKNT1KO1",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HAMS4K163",
//											"faceTagName": "wait"
//										},
//										"1HBHT8HLB0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HD6JA7JV18",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HD6JA7JV19",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HBHT8HLB0",
//											"faceTagName": "!filemenu"
//										},
//										"1HAMS3KJL0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HJQHBT0M24",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HJQHBT0M25",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HAMS3KJL0",
//											"faceTagName": "start"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HAMROHSJ36",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HAMROHSJ37",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1HAMRK4MB11",
//					"attrs": {
//						"1HAMS4K161": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HAMSMGCQ11",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HAMSMGCQ12",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HAMS4K161",
//							"faceTagName": "input"
//						},
//						"1HBHT74HN0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HBHU5CAP22",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HBHU5CAP23",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HBHT74HN0",
//							"faceTagName": "filemenu"
//						},
//						"1HBHUAT3S0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HBHUC94656",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HBHUC94657",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HBHUAT3S0",
//							"faceTagName": "allowfile"
//						},
//						"1HAMS4K163": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HCKNT1KO2",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HCKNT1KO3",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HAMS4K163",
//							"faceTagName": "wait"
//						},
//						"1HBHT8HLB0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HD6JA7JV20",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HD6JA7JV21",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HBHT8HLB0",
//							"faceTagName": "!filemenu"
//						},
//						"1HAMS3KJL0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HJQHBT0M26",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HJQHBT0M27",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HAMS3KJL0",
//							"faceTagName": "start"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1HAMRK4MB12",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1HAMRK4MB13",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1HAMRK4MB14",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "true",
//				"h": "true",
//				"anchorH": "true",
//				"anchorV": "true",
//				"autoLayout": "true",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "true",
//				"uiEvent": "true",
//				"alpha": "true",
//				"rotate": "true",
//				"scale": "true",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "true",
//				"zIndex": "true",
//				"flex": "true",
//				"margin": "true",
//				"traceSize": "true",
//				"padding": "true",
//				"minW": "true",
//				"minH": "true",
//				"maxW": "true",
//				"maxH": "true",
//				"styleClass": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": [
//				{
//					"type": "string",
//					"valText": "defAssistant"
//				}
//			]
//		}
//	}
//}