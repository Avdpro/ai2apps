//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
import {BtnNaviItem} from "/@StdUI/ui/BtnNaviItem.js";
import {BtnSwitch} from "/@StdUI/ui/BtnSwitch.js";
import {UIChat} from "./UIChat.js";
import {UIPath} from "./UIPath.js";
/*#{1HAN890200StartDoc*/
import {tabNT} from "/@tabos/tabos_nt.js";
import {tabOS,tabFS} from "/@tabos";
import pathLib from "/@path";
import {DlgFile} from "/@homekit/ui/DlgFile.js";
import {DlgMenu} from "/@StdUI/ui/DlgMenu.js";
/*}#1HAN890200StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let UIDebug=function(){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let txtTitle,btnReopen,btnClearReset,btnNaviChat,btnNaviPath,btnNaviBreak,btnNaviCheat,btnStepRun,chatUI,pathUI;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1HAN890201LocalVals*/
	const app=VFACT.app;
	const rootApp=app.appFrame?app.appFrame.app:app;
	app.openDocPath=localStorage.getItem("DebugAIChatPath")||tabOS.homePath||"/";
	let session=null;
	let isCheckingTokenGas=false;
	/*}#1HAN890201LocalVals*/
	
	/*#{1HAN890201PreState*/
	/*}#1HAN890201PreState*/
	state={
		"userGas":-1,"userTokens":-1,
		/*#{1HAN890207ExState*/
		/*}#1HAN890207ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1HAN890201PostState*/
	/*}#1HAN890201PostState*/
	cssVO={
		"hash":"1HAN890201",nameHost:true,
		"type":"hud","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
		children:[
			{
				"hash":"1HAN8B0B40",
				"type":"box","x":0,"y":0,"w":"100%","h":60,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["secondary"],
				children:[
					{
						"hash":"1HAN8C4FV0",
						"type":"text","id":"TxtTitle","x":9,"y":8,"w":"","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontSecondary"],
						"text":"BuildKB.aichat","fontSize":txtSize.midPlus,"fontWeight":"bold","fontStyle":"normal","textDecoration":"",
					},
					{
						"hash":"1HAN8IO0M0",
						"type":"hud","x":0,"y":30,"w":"100%","h":30,"padding":[0,10,0,10],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
						"itemsAlign":1,
						children:[
							{
								"hash":"1HAN8MNSE0",
								"type":BtnIcon(cfgColor.fontSecondary,24,0,appCfg.sharedAssets+"/folder.svg",null),"id":"BtnOpen","position":"relative","x":0,"y":0,"margin":[0,5,0,0],
								"tip":"Open",
								"OnClick":function(event){
									/*#{1HANFAU6C0FunctionBody*/
									self.openChat();
									/*}#1HANFAU6C0FunctionBody*/
								},
							},
							{
								"hash":"1HATNIBRK0",
								"type":BtnIcon(cfgColor.fontSecondary,24,0,appCfg.sharedAssets+"/recent.svg",null),"id":"BtnReopen","position":"relative","x":0,"y":0,"margin":[0,5,0,0],
								"tip":"Recent docs",
								"OnClick":function(event){
									/*#{1HATNIBRL7FunctionBody*/
									self.openRecent();
									/*}#1HATNIBRL7FunctionBody*/
								},
							},
							{
								"hash":"1HATNEAKG0",
								"type":BtnIcon(cfgColor.fontSecondary,24,0,appCfg.sharedAssets+"/save.svg",null),"id":"BtnSave","position":"relative","x":0,"y":0,"margin":[0,5,0,0],
								"tip":"Save",
								"OnClick":function(event){
									/*#{1HATNEAKH12FunctionBody*/
									self.saveChat();
									/*}#1HATNEAKH12FunctionBody*/
								},
							},
							{
								"hash":"1HAN8OC040",
								"type":BtnIcon(cfgColor.fontSecondary,24,0,appCfg.sharedAssets+"/trash.svg",null),"id":"BtnClearReset","position":"relative","x":0,"y":0,"margin":[0,5,0,0],
								"tip":"Clear / Reset",
								"OnClick":function(event){
									/*#{1HANG94GB0FunctionBody*/
									self.clearChat();
									/*}#1HANG94GB0FunctionBody*/
								},
							},
							{
								"hash":"1HAN8QGFV0",
								"type":"hud","position":"relative","x":0,"y":0,"w":100,"h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
							},
							{
								"hash":"1HAN8QUQ60",
								"type":BtnNaviItem("Chat","Chat",cfgColor.fontSecondary,appCfg.sharedAssets+"/aichat.svg",undefined,txtSize.mid,false,0,false),"id":"BtnNaviChat",
								"position":"relative","x":0,"y":0,"face":"focus",
								"OnClick":function(event){
									/*#{1HANHD4ED0FunctionBody*/
									self.showFace("chat");
									/*}#1HANHD4ED0FunctionBody*/
								},
							},
							{
								"hash":"1HAN8V0EG0",
								"type":BtnNaviItem("Debug","Debug",cfgColor.fontSecondary,appCfg.sharedAssets+"/lab.svg",undefined,txtSize.mid,false,0,false),"id":"BtnNaviPath",
								"position":"relative","x":0,"y":0,"face":"blur","margin":[0,0,0,10],
								"OnClick":function(event){
									/*#{1HANHE9Q10FunctionBody*/
									self.showFace("debug");
									/*}#1HANHE9Q10FunctionBody*/
								},
							},
							{
								"hash":"1HAQN80L40",
								"type":BtnNaviItem("Debug","Breakpoints",cfgColor.fontSecondary,appCfg.sharedAssets+"/spot.svg",undefined,txtSize.mid,false,0,false),"id":"BtnNaviBreak",
								"position":"relative","x":0,"y":0,"display":0,"face":"blur","margin":[0,0,0,10],"enable":false,
								"OnClick":function(event){
									/*#{1HAQN80L50FunctionBody*/
									pathUI.showFace("breaks");
									/*}#1HAQN80L50FunctionBody*/
								},
							},
							{
								"hash":"1HAQNCREA0",
								"type":BtnNaviItem("Debug","GPT Mimic",cfgColor.fontSecondary,appCfg.sharedAssets+"/gas.svg",undefined,txtSize.mid,false,0,false),"id":"BtnNaviCheat",
								"position":"relative","x":0,"y":0,"display":0,"face":"blur","margin":[0,0,0,10],"enable":false,
								"OnClick":function(event){
									/*#{1HAQNCREB0FunctionBody*/
									pathUI.showFace("cheats");
									/*}#1HAQNCREB0FunctionBody*/
								},
							}
						],
					},
					{
						"hash":"1HATNMTSH0",
						"type":"hud","x":">calc(100% - 10px)","y":8,"w":"","h":30,"anchorX":2,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-xr",
						"itemsAlign":1,
						children:[
							{
								"hash":"1HATNOJMV0",
								"type":BtnIcon(cfgColor.fontSecondary,24,0,appCfg.sharedAssets+"/gas.svg",null),"position":"relative","x":0,"y":0,
								"tip":"Account gas left",
								"OnClick":function(event){
									/*#{1HDTHO5VC0FunctionBody*/
									self.showTokenGasDlg();
									/*}#1HDTHO5VC0FunctionBody*/
								},
							},
							{
								"hash":"1HATOB4RC0",
								"type":"text","id":"TxtGas","position":"relative","x":0,"y":0,"w":"","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontSecondary"],
								"text":$P(()=>(state.userGas>=0?state.userGas:"- - -"),state),"fontSize":txtSize.midPlus,"fontWeight":"bold","fontStyle":"normal","textDecoration":"",
							},
							{
								"hash":"1HATP0I0V0",
								"type":BtnIcon(cfgColor.fontSecondary,24,0,appCfg.sharedAssets+"/token.svg",null),"position":"relative","x":0,"y":0,"scale":[-1,1],"anchorX":2,
								"margin":[0,10,0,0],
								"tip":"Account tokens left",
								"OnClick":function(event){
									/*#{1HDTHNJSU0FunctionBody*/
									self.showTokenGasDlg();
									/*}#1HDTHNJSU0FunctionBody*/
								},
							},
							{
								"hash":"1HATP29TO0",
								"type":"text","id":"TxtTokens","position":"relative","x":0,"y":0,"w":"","h":"","margin":[0,3,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
								"color":cfgColor["fontSecondary"],"text":$P(()=>(state.userTokens>=0?state.userTokens:"- - -"),state),"fontSize":txtSize.midPlus,"fontWeight":"bold",
								"fontStyle":"normal","textDecoration":"",
							}
						],
					}
				],
			},
			{
				"hash":"1HAN95S8B0",
				"type":"box","x":0,"y":">calc(100% - 30px)","w":"100%","h":30,"padding":[0,10,0,10],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["secondary"],
				"contentLayout":"flex-x","itemsAlign":1,
				children:[
					{
						"hash":"1HAN9JGIM0",
						"type":"text","x":">calc(100% - 10px)","y":0,"w":"","h":"100%","anchorX":2,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontSecondaryLit"],
						"text":"www.ai2apps.com","fontSize":txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignV":1,
					},
					{
						"hash":"1HAQAP0DE0",
						"type":"text","position":"relative","x":0,"y":0,"w":"","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontSecondary"],
						"text":"Step run:","fontSize":txtSize.smallPlus,"fontWeight":"bold","fontStyle":"normal","textDecoration":"",
					},
					{
						"hash":"1HAQASJCS0",
						"type":BtnSwitch(20,false),"id":"BtnStepRun","position":"relative","x":0,"y":0,"margin":[0,0,0,5],"color":cfgColor["warning"],"lineColor":cfgColor["fontSecondarySub"],
						/*#{1HAQASJCS0Codes*/
						OnCheck(){
							if(session){
								session.setStepRun(btnStepRun.checked);
							}
						}
						/*}#1HAQASJCS0Codes*/
					},
					{
						"hash":"1HAT08RSN0",
						"type":BtnIcon(cfgColor.fontSecondary,24,0,appCfg.sharedAssets+"/find.svg",null),"position":"relative","x":0,"y":0,"margin":[0,0,0,10],
						"tip":"Inspect chat bots","tipDir":0,
						"OnClick":function(event){
							/*#{1HAT0SRNE0FunctionBody*/
							if(session){
								session.inspectChatBot();
								app.showTip(this,"ChatBots loged into browser console.",this.w/2,-5,1,2);
							}
							/*}#1HAT0SRNE0FunctionBody*/
						},
					}
				],
			},
			{
				"hash":"1HAN9N2NL0",
				"type":UIChat({"bubble":false,"ai":{"blkColor":[0,0,0,0],"bgColor":cfgColor.primary,"icon":appCfg.sharedAssets+"/faces.svg","pic":"","textColor":cfgColor["fontBody"],"iconColor":cfgColor["fontSuccess"],"side":"left"},"user":{"blkColor":[0,0,0,0],"bgColor":cfgColor.primary,"icon":appCfg.sharedAssets+"/user.svg","pic":"","textColor":cfgColor["fontBody"],"iconColor":cfgColor["fontPrimary"],"side":"right"},"wait":{"blkColor":[0,0,0,0],"bgColor":cfgColor["secondary"],"icon":appCfg.sharedAssets+"/faces.svg","pic":"","textColor":cfgColor["fontBody"],"iconColor":cfgColor["fontSecondary"],"side":"left"},"event":{"blkColor":[0,0,0,0],"bgColor":cfgColor["warning"],"icon":appCfg.sharedAssets+"/event.svg","pic":"","textColor":cfgColor["fontBody"],"iconColor":cfgColor["fontWarning"],"side":"left"},"error":{"blkColor":[0,0,0,0],"bgColor":cfgColor["error"],"icon":appCfg.sharedAssets+"/fat_right.svg","pic":"","textColor":[155,0,0,1],"iconColor":cfgColor["fontError"],"side":"left"},"ask":{"blkColor":[0,0,0,0],"bgColor":cfgColor["success"],"icon":appCfg.sharedAssets+"/help.svg","pic":"","textColor":cfgColor["fontBody"],"iconColor":cfgColor["fontSuccess"],"side":"left"},"allowFile":false}),
				"id":"ChatUI","x":0,"y":60,"w":"100%","h":">calc(100% - 90px)",
				"defAssistant":{
				},
			},
			{
				"hash":"1HAN9VP510",
				"type":UIPath(),"id":"PathUI","x":0,"y":60,"display":0,"w":"100%","h":">calc(100% - 90px)",
			}
		],
		/*#{1HAN890201ExtraCSS*/
		/*}#1HAN890201ExtraCSS*/
		faces:{
			"chat":{
				/*BtnOpen*/"#1HAN8MNSE0":{
					"enable":true
				},
				/*BtnReopen*/"#1HATNIBRK0":{
					"enable":true
				},
				/*BtnSave*/"#1HATNEAKG0":{
					"enable":true
				},
				/*BtnClearReset*/"#1HAN8OC040":{
					"enable":true
				},
				/*BtnNaviChat*/"#1HAN8QUQ60":{
					"display":1,"face":"focus"
				},
				/*BtnNaviPath*/"#1HAN8V0EG0":{
					"display":1,"face":"blur"
				},
				/*BtnNaviBreak*/"#1HAQN80L40":{
					"display":0,"enable":false
				},
				/*BtnNaviCheat*/"#1HAQNCREA0":{
					"display":0,"enable":false
				},
				/*ChatUI*/"#1HAN9N2NL0":{
					"display":1
				},
				/*PathUI*/"#1HAN9VP510":{
					"display":0
				}
			},"debug":{
				/*BtnNaviChat*/"#1HAN8QUQ60":{
					"face":"blur"
				},
				/*BtnNaviPath*/"#1HAN8V0EG0":{
					"face":"focus"
				},
				/*BtnNaviBreak*/"#1HAQN80L40":{
					"enable":true,"display":1
				},
				/*BtnNaviCheat*/"#1HAQNCREA0":{
					"enable":true,"display":1
				},
				/*ChatUI*/"#1HAN9N2NL0":{
					"display":0
				},
				/*PathUI*/"#1HAN9VP510":{
					"display":1
				}
			},"start":{
				/*TxtTitle*/"#1HAN8C4FV0":{
					"text":"Please select chat entry file:"
				},
				/*BtnOpen*/"#1HAN8MNSE0":{
					"enable":true
				},
				/*BtnReopen*/"#1HATNIBRK0":{
					"enable":true
				},
				/*BtnSave*/"#1HATNEAKG0":{
					"enable":false
				},
				/*BtnClearReset*/"#1HAN8OC040":{
					"enable":false
				},
				/*BtnNaviChat*/"#1HAN8QUQ60":{
					"display":0
				},
				/*BtnNaviPath*/"#1HAN8V0EG0":{
					"display":0
				},
				/*BtnNaviBreak*/"#1HAQN80L40":{
					"display":0
				},
				/*BtnNaviCheat*/"#1HAQNCREA0":{
					"display":0
				}
			},"init":{
				/*TxtTitle*/"#1HAN8C4FV0":{
					"text":"Initing chat bot..."
				},
				/*BtnOpen*/"#1HAN8MNSE0":{
					"enable":false
				},
				/*BtnReopen*/"#1HATNIBRK0":{
					"enable":false
				},
				/*BtnSave*/"#1HATNEAKG0":{
					"enable":false
				},
				/*BtnClearReset*/"#1HAN8OC040":{
					"enable":false
				},
				/*BtnNaviChat*/"#1HAN8QUQ60":{
					"display":0
				},
				/*BtnNaviPath*/"#1HAN8V0EG0":{
					"display":0
				},
				/*BtnNaviBreak*/"#1HAQN80L40":{
					"display":0
				},
				/*BtnNaviCheat*/"#1HAQNCREA0":{
					"display":0
				}
			},"wait":{
				/*BtnOpen*/"#1HAN8MNSE0":{
					"enable":false
				},
				/*BtnReopen*/"#1HATNIBRK0":{
					"enable":false
				},
				/*BtnSave*/"#1HATNEAKG0":{
					"enable":false
				},
				/*BtnClearReset*/"#1HAN8OC040":{
					"enable":false
				}
			},"done":{
				/*BtnOpen*/"#1HAN8MNSE0":{
					"enable":true
				},
				/*BtnReopen*/"#1HATNIBRK0":{
					"enable":true
				},
				/*BtnSave*/"#1HATNEAKG0":{
					"enable":true
				},
				/*BtnClearReset*/"#1HAN8OC040":{
					"enable":true
				}
			},"runAgent":{
				/*BtnOpen*/"#1HAN8MNSE0":{
					"enable":true
				},
				/*BtnReopen*/"#1HATNIBRK0":{
					"enable":true
				},
				/*BtnSave*/"#1HATNEAKG0":{
					"enable":true
				},
				/*BtnClearReset*/"#1HAN8OC040":{
					"enable":true
				},
				/*BtnNaviChat*/"#1HAN8QUQ60":{
					"display":1
				},
				/*BtnNaviPath*/"#1HAN8V0EG0":{
					"display":1
				},
				/*BtnNaviBreak*/"#1HAQN80L40":{
					"display":0
				},
				/*BtnNaviCheat*/"#1HAQNCREA0":{
					"display":0
				}
			}
		},
		OnCreate:function(){
			self=this;
			txtTitle=self.TxtTitle;btnReopen=self.BtnReopen;btnClearReset=self.BtnClearReset;btnNaviChat=self.BtnNaviChat;btnNaviPath=self.BtnNaviPath;btnNaviBreak=self.BtnNaviBreak;btnNaviCheat=self.BtnNaviCheat;btnStepRun=self.BtnStepRun;chatUI=self.ChatUI;pathUI=self.PathUI;
			/*#{1HAN890201Create*/
			let startEntry,callArg;
			app.mainUI=self;
			app.debugUI=self;
			self.showFace("start");
			app.on("SessionReady",(session)=>{
				let bot=session.entryBot;
				if(session.ui===app.boxChats){
					txtTitle.text="ChatBot: "+bot.name;
				}
			});
			app.on("SessionLoadError",(reason)=>{
				self.showFace("start");
			});
			app.on("StartChat",()=>{
				self.showFace("wait");
			});
			app.on("EndChat",()=>{
				self.showFace("done");
			});
			app.on("SessionReady",(_session)=>{
				if(_session.ui===app.boxChats){
					session=_session;
					session.setStepRun(btnStepRun.checked);
					session.opts.showBreak=async (...args)=>{
						return await pathUI.showBreak(...args);
					}
					session.on("NewBreakPoint",(stub)=>{
						app.showTip(btnNaviBreak,"Breakpoint + 1",btnNaviBreak.w/2,-5,1,2);
					});
					session.on("NewGPTCheat",(stub)=>{
						app.showTip(btnNaviCheat,"GTP Mimic + 1",btnNaviCheat.w/2,-5,1,2);
					});
				}
			});
			app.on("StartAgent",(_session,agent)=>{
				self.showFace("runAgent");
			});
			if(tabOS.onNotify){
				app.on("CheckCY",()=>{
					tabOS.emitGlobalNotify("UpdateTokenGas");
				});
				app.on("UpdateTokenGas",()=>{
					tabOS.emitGlobalNotify("UpdateTokenGas");
				});
				tabOS.onNotify("UpdateTokenGas",self.checkCy);
			}else{
				app.on("CheckCY",self.checkCy);
				app.on("UpdateTokenGas",self.checkCy);
			}
			self.checkCy();
			startEntry=VFACT.appParams.file;
			callArg=VFACT.appParams.argument;
			if(startEntry){
				if(startEntry[0]!=="/"){
					if(rootApp.prj){
						startEntry=pathLib.join(rootApp.prj.path,startEntry);
					}
				}
				self.openChatFile(startEntry,callArg);
			}
			/*}#1HAN890201Create*/
		},
		/*#{1HAN890201EndCSS*/
		/*}#1HAN890201EndCSS*/
	};
	/*#{1HAN890201PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.openChat=function(){
		app.showDlg(DlgFile,{
			mode:"open",
			path:app.openDocPath,
			options:{
				preview:1,
				filter:"*.aichat;*.aidebug;*.js"
			},
			callback:async function(filePath){
				if(filePath){
					self.openChatFile(filePath);
					app.openDocPath=pathLib.dirname(filePath);
					localStorage.setItem("DebugAIChatPath",app.openDocPath);
				}
			}
		});
	};
	
	//------------------------------------------------------------------------
	cssVO.openRecent=async function(){
		let list,items,url,item;
		items=[];
		list=localStorage.getItem("DebugAIChats");
		if(!list)
			list="[]";
		list=JSON.parse(list);
		if(!list || (!list.length>0)){
			items.push({text:"No recent docs found",enable:false});
		}else{
			for(url of list){
				items.unshift({text:url,url:url});
			}
		}
		item=await app.modalDlg(DlgMenu,{
			hud:btnReopen,
			items:items,
		});
		if(!item)
			return;
		if(!item.url)
			return;
		self.openChatFile(item.url);
	};
	
	//------------------------------------------------------------------------
	cssVO.openChatFile=async function(path,arg){
		let ext;
		//Convert file system path to URL:
		await tabNT.checkLogin(true,true);
		self.showFace("init");
		ext=pathLib.extname(path);
		if(ext===".py" || VFACT.appParams.isServer){
			let nodeName=VFACT.appParams.node;
			let localPath;
			if(!nodeName){
				//nodeName=window.prompt("Input debug agent node name:",VFACT.appParams.prjName||"");
				nodeName=await app.modalDlg("/@StdUI/ui/DlgPrompt.js",{title:(($ln==="CN")?("输入调试智能体节点名称:"):/*EN*/("Input debug agent node name:")),text:VFACT.appParams.prjName||""});
			}
			localPath="/@aichat/ai/RemoteChat.js";
			await chatUI.initChat({url:localPath,argument:{nodeName:nodeName,callAgent:pathLib.basename(path),callArg:arg,checkUpdate:true}});
		}else if(ext===".js"){
			//Fix URL if needed:
			if(path[0]==="/" && path[1]!=="/" && path[1]!=="~"){
				path="/~"+path;
			}
			if(path[0]!=="/" && (!path.startsWith("http://")) &&(!path.startsWith("https://"))){
				path=rootApp.path2AppURL(path);
				//path=pathLib.join(rootApp.appDir,path);
			}
			await chatUI.initChat({url:path,argument:arg||""});
		}else if(ext===".aichat"){
			if(path[0]==="/" && path[1]!=="/" && path[1]!=="~"){
				path="/~"+path;
			}
			if(path[0]!=="/" && (!path.startsWith("http://")) &&(!path.startsWith("https://"))){
				path=pathLib.join(app.appDir,path);
			}
			await chatUI.initChat({bot:path});
		}else if(ext===".aidebug"){
			let vo;
			try{
				vo=await tabFS.readFile(path,"utf8");
				vo=JSON.parse(vo);
			}catch(err){
				return;
			}
			await chatUI.loadDebug(vo,path);
		}else{
			return;
		}
		self.showFace("chat");
		self.updateRecentDocs(path);
	};
	
	//------------------------------------------------------------------------
	cssVO.updateRecentDocs=function(path){
		let list,idx;
		//Record filepath:
		list=localStorage.getItem("DebugAIChats");
		if(!list)
			list="[]";
		list=JSON.parse(list);
		if(!list || (!list.length>0)){
			list=[];
		}
		idx=list.indexOf(path);
		if(idx>=0){
			list.splice(idx,1);
		}
		list.push(path);
		localStorage.setItem("DebugAIChats",JSON.stringify(list));
	};
	
	//------------------------------------------------------------------------
	cssVO.clearChat=async function(){
		let chatBot,item;
		item=await app.modalDlg(DlgMenu,{
			hud:btnClearReset,
			items:[
				{text:"Reset Session",code:"Reset"},
				{text:"Clear Debug Logs",code:"Debug"},
			]
		});
		if(item){
			if(item.code==="Reset"){
				self.showFace("init");
				pathUI.reset();
				await chatUI.resetChat();
				self.showFace("chat");
			}else{
				pathUI.clear();
			}
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.checkCy=async function(){
		let res;
		if(isCheckingTokenGas){
			return;
		}
		isCheckingTokenGas=true;
		if(!(await tabNT.checkLogin(false))){
			state.userTokens=-1;
			state.userGas=-1;
			self.showFace("showCy");
			isCheckingTokenGas=false;
			return;
		}
		self.showFace("checkCy");
		try{
			res=await tabNT.makeCall("userCurrency",{});
			if(res.code===200){
				state.userTokens=res.coins||0;
				state.userGas=res.points||0;
			}else{
				state.userTokens=-1;
				state.userGas=-1;
			}
		}catch(err){
			state.userTokens=-1;
			state.userGas=-1;
		}
		isCheckingTokenGas=false;
	};
	
	//------------------------------------------------------------------------
	cssVO.saveChat=async function(){
		let path,saveVO;
		path=await app.modalDlg(DlgFile,{
			mode:"save",
			path:app.openDocPath,
			options:{
				preview:1,
				filter:"*.aidebug"
			},
			callback:async function(filePath){
			}
		});
		if(path){
			let ext;
			ext=pathLib.extname(path);
			if(ext!==".aidebug"){
				path+=".aidebug";
			}
			saveVO=session.genSaveVO(path);
			tabFS.writeFile(path,JSON.stringify(saveVO,null,"\t"));
			app.openDocPath=pathLib.dirname(path);
			localStorage.setItem("DebugAIChatPath",app.openDocPath);
			self.updateRecentDocs(path);
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.showTokenGasDlg=function(){
		app.showDlg("/@homekit/ui/DlgTokenGas.js",{});
	};
	/*}#1HAN890201PostCSSVO*/
	cssVO.constructor=UIDebug;
	return cssVO;
};
/*#{1HAN890201ExCodes*/
/*}#1HAN890201ExCodes*/

//----------------------------------------------------------------------------
UIDebug.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1HAN890201PreAISpot*/
	/*}#1HAN890201PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1HAN890201PostAISpot*/
	/*}#1HAN890201PostAISpot*/
	return exposeVO;
};

/*#{1HAN890200EndDoc*/
/*}#1HAN890200EndDoc*/

export default UIDebug;
export{UIDebug};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1HAN890200",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1HAN890202",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "1000",
//				"screenH": "800",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1HAN890203",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1HAN890204",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1HAN890205",
//			"attrs": {}
//		},
//		"localVars": {
//			"jaxId": "1HAN890206",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1HAN890207",
//			"attrs": {
//				"userGas": {
//					"type": "int",
//					"valText": "-1"
//				},
//				"userTokens": {
//					"type": "int",
//					"valText": "-1"
//				}
//			}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1HAN890208",
//			"attrs": {
//				"chat": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HAN9TCNB0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HAN9TCNB1",
//							"attrs": {}
//						}
//					}
//				},
//				"debug": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HAN9TCNB2",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HAN9TCNB3",
//							"attrs": {}
//						}
//					}
//				},
//				"start": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HANF4N430",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HANF57940",
//							"attrs": {}
//						}
//					}
//				},
//				"init": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HANGAIE20",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HANGD1070",
//							"attrs": {}
//						}
//					}
//				},
//				"wait": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HANIE6IF0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HANIEURI0",
//							"attrs": {}
//						}
//					}
//				},
//				"done": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HANIEMO60",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HANIEURI1",
//							"attrs": {}
//						}
//					}
//				},
//				"runAgent": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HCKMRRSD0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HCKMV9TO0",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1HAN890209",
//			"attrs": {}
//		},
//		"exposeToAI": "true",
//		"descAI": "",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1HAN890201",
//			"attrs": {
//				"properties": {
//					"jaxId": "1HAN8902010",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "100%",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": ""
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1HAN8B0B40",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HAN8JDNL0",
//									"attrs": {
//										"type": "box",
//										"id": "",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "60",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"secondary\"]",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1HAN8C4FV0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HAN8JDNL1",
//													"attrs": {
//														"type": "text",
//														"id": "TxtTitle",
//														"position": "Absolute",
//														"x": "9",
//														"y": "8",
//														"w": "",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontSecondary\"]",
//														"text": "BuildKB.aichat",
//														"font": "",
//														"fontSize": "#txtSize.midPlus",
//														"bold": "true",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HAN8JDNL2",
//													"attrs": {
//														"1HANF4N430": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HANF57941",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HANF57942",
//																	"attrs": {
//																		"text": {
//																			"type": "string",
//																			"valText": "Please select chat entry file:",
//																			"localizable": true
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HANF4N430",
//															"faceTagName": "start"
//														},
//														"1HANGAIE20": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HANGD1071",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HANGD1072",
//																	"attrs": {
//																		"text": {
//																			"type": "string",
//																			"valText": "Initing chat bot...",
//																			"localizable": true
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HANGAIE20",
//															"faceTagName": "init"
//														},
//														"1HANIE6IF0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HANIEURI2",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HANIEURI3",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HANIE6IF0",
//															"faceTagName": "wait"
//														},
//														"1HANIEMO60": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAQNNP8R0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAQNNP8R1",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HANIEMO60",
//															"faceTagName": "done"
//														},
//														"1HAN9TCNB0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HCKN8H6E0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HCKN8H6E1",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAN9TCNB0",
//															"faceTagName": "chat"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HAN8JDNL3",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HAN8JDNL4",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1HAN8IO0M0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HAN8IO0M1",
//													"attrs": {
//														"type": "hud",
//														"id": "",
//														"position": "Absolute",
//														"x": "0",
//														"y": "30",
//														"w": "100%",
//														"h": "30",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "[0,10,0,10]",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex X",
//														"subAlign": "Start",
//														"itemsAlign": "Center"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1HAN8MNSE0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1HAN8MNSE1",
//																	"attrs": {
//																		"style": "#cfgColor.fontSecondary",
//																		"w": "24",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/folder.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1HAN8MNSE2",
//																	"attrs": {
//																		"type": "#null#>BtnIcon(cfgColor.fontSecondary,24,0,appCfg.sharedAssets+\"/folder.svg\",null)",
//																		"id": "BtnOpen",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"margin": "[0,5,0,0]"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HAN8MNSE3",
//																	"attrs": {
//																		"1HANIE6IF0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HANIEURJ0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HANIEURJ1",
//																					"attrs": {
//																						"enable": {
//																							"type": "bool",
//																							"valText": "false"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HANIE6IF0",
//																			"faceTagName": "wait"
//																		},
//																		"1HANIEMO60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HANIEURJ2",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HANIEURJ3",
//																					"attrs": {
//																						"enable": {
//																							"type": "bool",
//																							"valText": "true"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HANIEMO60",
//																			"faceTagName": "done"
//																		},
//																		"1HANGAIE20": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAQNNP8R4",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAQNNP8R5",
//																					"attrs": {
//																						"enable": {
//																							"type": "bool",
//																							"valText": "false"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HANGAIE20",
//																			"faceTagName": "init"
//																		},
//																		"1HAN9TCNB0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAQNRA3I2",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAQNRA3I3",
//																					"attrs": {
//																						"enable": {
//																							"type": "bool",
//																							"valText": "true"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAN9TCNB0",
//																			"faceTagName": "chat"
//																		},
//																		"1HANF4N430": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HBHUUHIK0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HBHUUHIK1",
//																					"attrs": {
//																						"enable": {
//																							"type": "bool",
//																							"valText": "true"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HANF4N430",
//																			"faceTagName": "start"
//																		},
//																		"1HCKMRRSD0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HCKMV9TO1",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HCKMV9TO2",
//																					"attrs": {
//																						"enable": {
//																							"type": "bool",
//																							"valText": "true"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HCKMRRSD0",
//																			"faceTagName": "runAgent"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HAN8MNSE4",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HANFAU6C0",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1HANFB49B0",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1HAN8MNSE5",
//																	"attrs": {
//																		"tip": {
//																			"type": "string",
//																			"valText": "Open",
//																			"localizable": true
//																		}
//																	}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1HAN8MNSE6",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1HATNIBRK0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1HATNIBRK1",
//																	"attrs": {
//																		"style": "#cfgColor.fontSecondary",
//																		"w": "24",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/recent.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1HATNIBRK2",
//																	"attrs": {
//																		"type": "#null#>BtnIcon(cfgColor.fontSecondary,24,0,appCfg.sharedAssets+\"/recent.svg\",null)",
//																		"id": "BtnReopen",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"margin": "[0,5,0,0]"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HATNIBRK3",
//																	"attrs": {
//																		"1HAN9TCNB0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HATNIBRK4",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HATNIBRK5",
//																					"attrs": {
//																						"enable": {
//																							"type": "bool",
//																							"valText": "true"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAN9TCNB0",
//																			"faceTagName": "chat"
//																		},
//																		"1HANF4N430": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HATNIBRK6",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HATNIBRK7",
//																					"attrs": {
//																						"enable": {
//																							"type": "bool",
//																							"valText": "true"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HANF4N430",
//																			"faceTagName": "start"
//																		},
//																		"1HANGAIE20": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HATNIBRL0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HATNIBRL1",
//																					"attrs": {
//																						"enable": {
//																							"type": "bool",
//																							"valText": "false"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HANGAIE20",
//																			"faceTagName": "init"
//																		},
//																		"1HANIE6IF0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HATNIBRL2",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HATNIBRL3",
//																					"attrs": {
//																						"enable": {
//																							"type": "bool",
//																							"valText": "false"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HANIE6IF0",
//																			"faceTagName": "wait"
//																		},
//																		"1HANIEMO60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HATNIBRL4",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HATNIBRL5",
//																					"attrs": {
//																						"enable": {
//																							"type": "bool",
//																							"valText": "true"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HANIEMO60",
//																			"faceTagName": "done"
//																		},
//																		"1HCKMRRSD0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HCKMV9TO3",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HCKMV9TO4",
//																					"attrs": {
//																						"enable": {
//																							"type": "bool",
//																							"valText": "true"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HCKMRRSD0",
//																			"faceTagName": "runAgent"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HATNIBRL6",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HATNIBRL7",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1HATNIBRL8",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1HATNIBRL9",
//																	"attrs": {
//																		"tip": {
//																			"type": "string",
//																			"valText": "Recent docs",
//																			"localizable": true
//																		}
//																	}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1HATNIBRL10",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1HATNEAKG0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1HATNEAKG1",
//																	"attrs": {
//																		"style": "#cfgColor.fontSecondary",
//																		"w": "24",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/save.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1HATNEAKG2",
//																	"attrs": {
//																		"type": "#null#>BtnIcon(cfgColor.fontSecondary,24,0,appCfg.sharedAssets+\"/save.svg\",null)",
//																		"id": "BtnSave",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"margin": "[0,5,0,0]"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HATNEAKH0",
//																	"attrs": {
//																		"1HAN9TCNB0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HATNEAKH1",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HATNEAKH2",
//																					"attrs": {
//																						"enable": {
//																							"type": "bool",
//																							"valText": "true"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAN9TCNB0",
//																			"faceTagName": "chat"
//																		},
//																		"1HANF4N430": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HATNEAKH3",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HATNEAKH4",
//																					"attrs": {
//																						"enable": {
//																							"type": "bool",
//																							"valText": "false"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HANF4N430",
//																			"faceTagName": "start"
//																		},
//																		"1HANGAIE20": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HATNEAKH5",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HATNEAKH6",
//																					"attrs": {
//																						"enable": {
//																							"type": "bool",
//																							"valText": "false"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HANGAIE20",
//																			"faceTagName": "init"
//																		},
//																		"1HANIE6IF0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HATNEAKH7",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HATNEAKH8",
//																					"attrs": {
//																						"enable": {
//																							"type": "bool",
//																							"valText": "false"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HANIE6IF0",
//																			"faceTagName": "wait"
//																		},
//																		"1HANIEMO60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HATNEAKH9",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HATNEAKH10",
//																					"attrs": {
//																						"enable": {
//																							"type": "bool",
//																							"valText": "true"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HANIEMO60",
//																			"faceTagName": "done"
//																		},
//																		"1HCKMRRSD0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HCKMV9TO5",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HCKMV9TO6",
//																					"attrs": {
//																						"enable": {
//																							"type": "bool",
//																							"valText": "true"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HCKMRRSD0",
//																			"faceTagName": "runAgent"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HATNEAKH11",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HATNEAKH12",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1HATNEAKH13",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1HATNEAKH14",
//																	"attrs": {
//																		"tip": {
//																			"type": "string",
//																			"valText": "Save",
//																			"localizable": true
//																		}
//																	}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1HATNEAKH15",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1HAN8OC040",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1HAN8OC041",
//																	"attrs": {
//																		"style": "#cfgColor.fontSecondary",
//																		"w": "24",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/trash.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1HAN8OC042",
//																	"attrs": {
//																		"type": "#null#>BtnIcon(cfgColor.fontSecondary,24,0,appCfg.sharedAssets+\"/trash.svg\",null)",
//																		"id": "BtnClearReset",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"margin": "[0,5,0,0]"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HAN8OC043",
//																	"attrs": {
//																		"1HAN9TCNB0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HANA3BLO4",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HANA3BLO5",
//																					"attrs": {
//																						"enable": {
//																							"type": "bool",
//																							"valText": "true"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAN9TCNB0",
//																			"faceTagName": "chat"
//																		},
//																		"1HANF4N430": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HANF57945",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HANF57946",
//																					"attrs": {
//																						"enable": {
//																							"type": "bool",
//																							"valText": "false"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HANF4N430",
//																			"faceTagName": "start"
//																		},
//																		"1HANGAIE20": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HANGD1075",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HANGD1076",
//																					"attrs": {
//																						"enable": {
//																							"type": "bool",
//																							"valText": "false"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HANGAIE20",
//																			"faceTagName": "init"
//																		},
//																		"1HANIE6IF0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HANIEURJ4",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HANIEURJ5",
//																					"attrs": {
//																						"enable": {
//																							"type": "bool",
//																							"valText": "false"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HANIE6IF0",
//																			"faceTagName": "wait"
//																		},
//																		"1HANIEMO60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HANIEURJ6",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HANIEURJ7",
//																					"attrs": {
//																						"enable": {
//																							"type": "bool",
//																							"valText": "true"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HANIEMO60",
//																			"faceTagName": "done"
//																		},
//																		"1HCKMRRSD0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HCKMV9TO7",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HCKMV9TO8",
//																					"attrs": {
//																						"enable": {
//																							"type": "bool",
//																							"valText": "true"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HCKMRRSD0",
//																			"faceTagName": "runAgent"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HAN8OC044",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HANG94GB0",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1HANG9E5P0",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1HAN8OC045",
//																	"attrs": {
//																		"tip": {
//																			"type": "string",
//																			"valText": "Clear / Reset",
//																			"localizable": true
//																		}
//																	}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1HAN8OC046",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1HAN8QGFV0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAN94JDK0",
//																	"attrs": {
//																		"type": "hud",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100",
//																		"h": "100%",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HAN94JDK1",
//																	"attrs": {
//																		"1HANIE6IF0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HANIEURJ8",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HANIEURJ9",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HANIE6IF0",
//																			"faceTagName": "wait"
//																		},
//																		"1HANGAIE20": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAQNNP8R8",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAQNNP8R9",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HANGAIE20",
//																			"faceTagName": "init"
//																		},
//																		"1HANIEMO60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAQNNP8R10",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAQNNP8R11",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HANIEMO60",
//																			"faceTagName": "done"
//																		},
//																		"1HANF4N430": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HBHUVOCG0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HBHUVOCG1",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HANF4N430",
//																			"faceTagName": "start"
//																		},
//																		"1HAN9TCNB0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HCKN8H6F0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HCKN8H6F1",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAN9TCNB0",
//																			"faceTagName": "chat"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HAN94JDK2",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HAN94JDK3",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false",
//																"exposeContainer": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnNaviItem.js",
//															"jaxId": "1HAN8QUQ60",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1HAN8UV1J0",
//																	"attrs": {
//																		"code": "Chat",
//																		"text": "Chat",
//																		"color": "#cfgColor.fontSecondary",
//																		"icon": "#appCfg.sharedAssets+\"/aichat.svg\"",
//																		"items": "",
//																		"fontSize": "#txtSize.mid",
//																		"hasClose": "false",
//																		"iconSize": "0",
//																		"mark": "false"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1HAN8UV1J1",
//																	"attrs": {
//																		"type": "#null#>BtnNaviItem(\"Chat\",\"Chat\",cfgColor.fontSecondary,appCfg.sharedAssets+\"/aichat.svg\",undefined,txtSize.mid,false,0,false)",
//																		"id": "BtnNaviChat",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "\"focus\""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HAN8UV1J2",
//																	"attrs": {
//																		"1HAN9TCNB0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HANA3BLO8",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HANA3BLO9",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						},
//																						"face": {
//																							"type": "auto",
//																							"valText": "\"focus\"",
//																							"editType": "face"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAN9TCNB0",
//																			"faceTagName": "chat"
//																		},
//																		"1HANF4N430": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HANF57949",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HANF579410",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HANF4N430",
//																			"faceTagName": "start"
//																		},
//																		"1HANGAIE20": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HANGD1079",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HANGD10710",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HANGAIE20",
//																			"faceTagName": "init"
//																		},
//																		"1HAN9TCNB2": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HANHCBA26",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HANHCBA27",
//																					"attrs": {
//																						"face": {
//																							"type": "auto",
//																							"valText": "\"blur\"",
//																							"editType": "face"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAN9TCNB2",
//																			"faceTagName": "debug"
//																		},
//																		"1HANIE6IF0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HANIEURJ12",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HANIEURJ13",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HANIE6IF0",
//																			"faceTagName": "wait"
//																		},
//																		"1HANIEMO60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAQNNP8R12",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAQNNP8R13",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HANIEMO60",
//																			"faceTagName": "done"
//																		},
//																		"1HCKMRRSD0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HCKMV9TO9",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HCKMV9TO10",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HCKMRRSD0",
//																			"faceTagName": "runAgent"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HAN8UV1J3",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HANHD4ED0",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1HANHDEOB0",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1HAN8UV1J4",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1HAN8UV1J5",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnNaviItem.js",
//															"jaxId": "1HAN8V0EG0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1HAN8V0EG1",
//																	"attrs": {
//																		"code": "Debug",
//																		"text": "Debug",
//																		"color": "#cfgColor.fontSecondary",
//																		"icon": "#appCfg.sharedAssets+\"/lab.svg\"",
//																		"items": "",
//																		"fontSize": "#txtSize.mid",
//																		"hasClose": "false",
//																		"iconSize": "0",
//																		"mark": "false"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1HAN8V0EG2",
//																	"attrs": {
//																		"type": "#null#>BtnNaviItem(\"Debug\",\"Debug\",cfgColor.fontSecondary,appCfg.sharedAssets+\"/lab.svg\",undefined,txtSize.mid,false,0,false)",
//																		"id": "BtnNaviPath",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "\"blur\"",
//																		"margin": "[0,0,0,10]"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HAN8V0EG3",
//																	"attrs": {
//																		"1HAN9TCNB0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HANA3BLO10",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HANA3BLO11",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						},
//																						"face": {
//																							"type": "auto",
//																							"valText": "\"blur\"",
//																							"editType": "face"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAN9TCNB0",
//																			"faceTagName": "chat"
//																		},
//																		"1HANF4N430": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HANF579411",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HANF579412",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HANF4N430",
//																			"faceTagName": "start"
//																		},
//																		"1HANGAIE20": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HANGD10711",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HANGD10712",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HANGAIE20",
//																			"faceTagName": "init"
//																		},
//																		"1HAN9TCNB2": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HANHCBA28",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HANHCBA29",
//																					"attrs": {
//																						"face": {
//																							"type": "auto",
//																							"valText": "\"focus\"",
//																							"editType": "face"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAN9TCNB2",
//																			"faceTagName": "debug"
//																		},
//																		"1HANIE6IF0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HANIEURJ16",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HANIEURJ17",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HANIE6IF0",
//																			"faceTagName": "wait"
//																		},
//																		"1HANIEMO60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAQNNP8R14",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAQNNP8R15",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HANIEMO60",
//																			"faceTagName": "done"
//																		},
//																		"1HCKMRRSD0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HCKMV9TO11",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HCKMV9TO12",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HCKMRRSD0",
//																			"faceTagName": "runAgent"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HAN8V0EG4",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HANHE9Q10",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1HANHEGD70",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1HAN8V0EG5",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1HAN8V0EG6",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnNaviItem.js",
//															"jaxId": "1HAQN80L40",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1HAQN80L41",
//																	"attrs": {
//																		"code": "Debug",
//																		"text": "Breakpoints",
//																		"color": "#cfgColor.fontSecondary",
//																		"icon": "#appCfg.sharedAssets+\"/spot.svg\"",
//																		"items": "",
//																		"fontSize": "#txtSize.mid",
//																		"hasClose": "false",
//																		"iconSize": "0",
//																		"mark": "false"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1HAQN80L42",
//																	"attrs": {
//																		"type": "#null#>BtnNaviItem(\"Debug\",\"Breakpoints\",cfgColor.fontSecondary,appCfg.sharedAssets+\"/spot.svg\",undefined,txtSize.mid,false,0,false)",
//																		"id": "BtnNaviBreak",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "Off",
//																		"face": "\"blur\"",
//																		"margin": "[0,0,0,10]",
//																		"enable": "false"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HAQN80L43",
//																	"attrs": {
//																		"1HAN9TCNB0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAQN80L44",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAQN80L45",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						},
//																						"enable": {
//																							"type": "bool",
//																							"valText": "false"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAN9TCNB0",
//																			"faceTagName": "chat"
//																		},
//																		"1HANF4N430": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAQN80L46",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAQN80L47",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HANF4N430",
//																			"faceTagName": "start"
//																		},
//																		"1HANGAIE20": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAQN80L48",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAQN80L49",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HANGAIE20",
//																			"faceTagName": "init"
//																		},
//																		"1HAN9TCNB2": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAQN80L410",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAQN80L411",
//																					"attrs": {
//																						"enable": {
//																							"type": "bool",
//																							"valText": "true"
//																						},
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAN9TCNB2",
//																			"faceTagName": "debug"
//																		},
//																		"1HANIE6IF0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAQN80L412",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAQN80L413",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HANIE6IF0",
//																			"faceTagName": "wait"
//																		},
//																		"1HANIEMO60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAQNNP8R16",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAQNNP8R17",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HANIEMO60",
//																			"faceTagName": "done"
//																		},
//																		"1HCKMRRSD0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HCKMV9TO13",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HCKMV9TO14",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HCKMRRSD0",
//																			"faceTagName": "runAgent"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HAQN80L414",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HAQN80L50",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1HAQN80L51",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1HAQN80L52",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1HAQN80L53",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnNaviItem.js",
//															"jaxId": "1HAQNCREA0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1HAQNCREA1",
//																	"attrs": {
//																		"code": "Debug",
//																		"text": "GPT Mimic",
//																		"color": "#cfgColor.fontSecondary",
//																		"icon": "#appCfg.sharedAssets+\"/gas.svg\"",
//																		"items": "",
//																		"fontSize": "#txtSize.mid",
//																		"hasClose": "false",
//																		"iconSize": "0",
//																		"mark": "false"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1HAQNCREA2",
//																	"attrs": {
//																		"type": "#null#>BtnNaviItem(\"Debug\",\"GPT Mimic\",cfgColor.fontSecondary,appCfg.sharedAssets+\"/gas.svg\",undefined,txtSize.mid,false,0,false)",
//																		"id": "BtnNaviCheat",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "Off",
//																		"face": "\"blur\"",
//																		"margin": "[0,0,0,10]",
//																		"enable": "false"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HAQNCREA3",
//																	"attrs": {
//																		"1HAN9TCNB0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAQNCREA4",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAQNCREA5",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						},
//																						"enable": {
//																							"type": "bool",
//																							"valText": "false"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAN9TCNB0",
//																			"faceTagName": "chat"
//																		},
//																		"1HANF4N430": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAQNCREA6",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAQNCREA7",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HANF4N430",
//																			"faceTagName": "start"
//																		},
//																		"1HANGAIE20": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAQNCREA8",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAQNCREA9",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HANGAIE20",
//																			"faceTagName": "init"
//																		},
//																		"1HAN9TCNB2": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAQNCREA10",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAQNCREA11",
//																					"attrs": {
//																						"enable": {
//																							"type": "bool",
//																							"valText": "true"
//																						},
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAN9TCNB2",
//																			"faceTagName": "debug"
//																		},
//																		"1HANIE6IF0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAQNCREA12",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAQNCREA13",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HANIE6IF0",
//																			"faceTagName": "wait"
//																		},
//																		"1HANIEMO60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAQNNP8R18",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAQNNP8R19",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HANIEMO60",
//																			"faceTagName": "done"
//																		},
//																		"1HCKMRRSD0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HCKMV9TO15",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HCKMV9TO16",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HCKMRRSD0",
//																			"faceTagName": "runAgent"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HAQNCREA14",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HAQNCREB0",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1HAQNCREB1",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1HAQNCREB2",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1HAQNCREB3",
//																	"attrs": {}
//																}
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1HAN8IO0M2",
//													"attrs": {
//														"1HANIE6IF0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HANIEURJ20",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HANIEURJ21",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HANIE6IF0",
//															"faceTagName": "wait"
//														},
//														"1HANGAIE20": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAQNNP8R22",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAQNNP8R23",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HANGAIE20",
//															"faceTagName": "init"
//														},
//														"1HANIEMO60": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAQNNP8R24",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAQNNP8R25",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HANIEMO60",
//															"faceTagName": "done"
//														},
//														"1HANF4N430": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HBHUVOCG2",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HBHUVOCG3",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HANF4N430",
//															"faceTagName": "start"
//														},
//														"1HAN9TCNB0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HCKN8H6F4",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HCKN8H6F5",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAN9TCNB0",
//															"faceTagName": "chat"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HAN8IO0M3",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HAN8IO0M4",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "true",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1HATNMTSH0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HATOD8U50",
//													"attrs": {
//														"type": "hud",
//														"id": "",
//														"position": "Absolute",
//														"x": "100%-10",
//														"y": "8",
//														"w": "",
//														"h": "30",
//														"anchorH": "Right",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex XR",
//														"subAlign": "Start",
//														"itemsAlign": "Center"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1HATNOJMV0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1HATOD8U51",
//																	"attrs": {
//																		"style": "#cfgColor.fontSecondary",
//																		"w": "24",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/gas.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1HATOD8U52",
//																	"attrs": {
//																		"type": "#null#>BtnIcon(cfgColor.fontSecondary,24,0,appCfg.sharedAssets+\"/gas.svg\",null)",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HATOD8U53",
//																	"attrs": {
//																		"1HANGAIE20": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HBHUUHIL0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HBHUUHIL1",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HANGAIE20",
//																			"faceTagName": "init"
//																		},
//																		"1HANF4N430": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HBHUVOCG4",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HBHUVOCG5",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HANF4N430",
//																			"faceTagName": "start"
//																		},
//																		"1HANIEMO60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HBHUVOCG6",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HBHUVOCG7",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HANIEMO60",
//																			"faceTagName": "done"
//																		},
//																		"1HAN9TCNB0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HCKN8H6F8",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HCKN8H6F9",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAN9TCNB0",
//																			"faceTagName": "chat"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HATOD8U54",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HDTHO5VC0",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1HDTHOA020",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1HATOD8U55",
//																	"attrs": {
//																		"tip": {
//																			"type": "string",
//																			"valText": "Account gas left",
//																			"localizable": true
//																		}
//																	}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1HATOD8U56",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1HATOB4RC0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HATOD8U57",
//																	"attrs": {
//																		"type": "text",
//																		"id": "TxtGas",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontSecondary\"]",
//																		"text": "${state.userGas>=0?state.userGas:\"- - -\"},state",
//																		"font": "",
//																		"fontSize": "#txtSize.midPlus",
//																		"bold": "true",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Top",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"lineClamp": "0",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HATOD8U58",
//																	"attrs": {
//																		"1HANGAIE20": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HBHUUHIL2",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HBHUUHIL3",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HANGAIE20",
//																			"faceTagName": "init"
//																		},
//																		"1HANF4N430": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HBHUVOCG10",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HBHUVOCG11",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HANF4N430",
//																			"faceTagName": "start"
//																		},
//																		"1HANIEMO60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HBHUVOCG12",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HBHUVOCG13",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HANIEMO60",
//																			"faceTagName": "done"
//																		},
//																		"1HAN9TCNB0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HCKN8H6F12",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HCKN8H6F13",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAN9TCNB0",
//																			"faceTagName": "chat"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HATOD8U59",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HATOD8U510",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1HATP0I0V0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1HATP0I0V1",
//																	"attrs": {
//																		"style": "#cfgColor.fontSecondary",
//																		"w": "24",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/token.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1HATP0I0V2",
//																	"attrs": {
//																		"type": "#null#>BtnIcon(cfgColor.fontSecondary,24,0,appCfg.sharedAssets+\"/token.svg\",null)",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"scale": "[-1,1]",
//																		"anchorH": "Right",
//																		"margin": "[0,10,0,0]"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HATP0I0V3",
//																	"attrs": {
//																		"1HANGAIE20": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HBHUUHIL4",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HBHUUHIL5",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HANGAIE20",
//																			"faceTagName": "init"
//																		},
//																		"1HANF4N430": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HBHUVOCG16",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HBHUVOCG17",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HANF4N430",
//																			"faceTagName": "start"
//																		},
//																		"1HANIEMO60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HBHUVOCG18",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HBHUVOCG19",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HANIEMO60",
//																			"faceTagName": "done"
//																		},
//																		"1HAN9TCNB0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HCKN8H6F16",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HCKN8H6F17",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAN9TCNB0",
//																			"faceTagName": "chat"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HATP0I0V4",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HDTHNJSU0",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1HDTHNVI50",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1HATP0I0V5",
//																	"attrs": {
//																		"tip": {
//																			"type": "string",
//																			"valText": "Account tokens left",
//																			"localizable": true
//																		}
//																	}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1HATP0I0V6",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1HATP29TO0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HATP29TO1",
//																	"attrs": {
//																		"type": "text",
//																		"id": "TxtTokens",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[0,3,0,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontSecondary\"]",
//																		"text": "${state.userTokens>=0?state.userTokens:\"- - -\"},state",
//																		"font": "",
//																		"fontSize": "#txtSize.midPlus",
//																		"bold": "true",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Top",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"lineClamp": "0",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HATP29TO2",
//																	"attrs": {
//																		"1HANGAIE20": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HBHUUHIL6",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HBHUUHIL7",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HANGAIE20",
//																			"faceTagName": "init"
//																		},
//																		"1HANF4N430": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HBHUVOCG22",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HBHUVOCG23",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HANF4N430",
//																			"faceTagName": "start"
//																		},
//																		"1HANIEMO60": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HBHUVOCG24",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HBHUVOCG25",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HANIEMO60",
//																			"faceTagName": "done"
//																		},
//																		"1HAN9TCNB0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HCKN8H6F20",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HCKN8H6F21",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAN9TCNB0",
//																			"faceTagName": "chat"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HATP29TO3",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HATP29TO4",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false"
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1HATOD8U60",
//													"attrs": {
//														"1HANGAIE20": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HBHUUHIL8",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HBHUUHIL9",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HANGAIE20",
//															"faceTagName": "init"
//														},
//														"1HANF4N430": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HBHUVOCG28",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HBHUVOCG29",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HANF4N430",
//															"faceTagName": "start"
//														},
//														"1HANIEMO60": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HBHUVOCG30",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HBHUVOCG31",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HANIEMO60",
//															"faceTagName": "done"
//														},
//														"1HAN9TCNB0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HCKN8H6F24",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HCKN8H6F25",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAN9TCNB0",
//															"faceTagName": "chat"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HATOD8U61",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HATOD8U62",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1HAN8JDNL5",
//									"attrs": {
//										"1HANIE6IF0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HANIEURJ24",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HANIEURJ25",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HANIE6IF0",
//											"faceTagName": "wait"
//										},
//										"1HANGAIE20": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HAQNNP8R28",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HAQNNP8R29",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HANGAIE20",
//											"faceTagName": "init"
//										},
//										"1HANIEMO60": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HAQNNP8R30",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HAQNNP8R31",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HANIEMO60",
//											"faceTagName": "done"
//										},
//										"1HANF4N430": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HBHUVOCG34",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HBHUVOCG35",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HANF4N430",
//											"faceTagName": "start"
//										},
//										"1HAN9TCNB0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HCKN8H6F28",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HCKN8H6F29",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HAN9TCNB0",
//											"faceTagName": "chat"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HAN8JDNL6",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HAN8JDNL7",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1HAN95S8B0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HAN972790",
//									"attrs": {
//										"type": "box",
//										"id": "",
//										"position": "Absolute",
//										"x": "0",
//										"y": "100%-30",
//										"w": "100%",
//										"h": "30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "[0,10,0,10]",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"secondary\"]",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"contentLayout": "Flex X",
//										"subAlign": "Start",
//										"itemsAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1HAN9JGIM0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HAN9LGGM0",
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "Absolute",
//														"x": "100%-10",
//														"y": "0",
//														"w": "",
//														"h": "100%",
//														"anchorH": "Right",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontSecondaryLit\"]",
//														"text": "www.ai2apps.com",
//														"font": "",
//														"fontSize": "#txtSize.smallPlus",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Center",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HAN9LGGM1",
//													"attrs": {
//														"1HANIE6IF0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HANIEURJ28",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HANIEURJ29",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HANIE6IF0",
//															"faceTagName": "wait"
//														},
//														"1HANGAIE20": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAQNNP8R34",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAQNNP8R35",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HANGAIE20",
//															"faceTagName": "init"
//														},
//														"1HANIEMO60": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAQNNP8R36",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAQNNP8R37",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HANIEMO60",
//															"faceTagName": "done"
//														},
//														"1HANF4N430": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HBHUVOCH0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HBHUVOCH1",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HANF4N430",
//															"faceTagName": "start"
//														},
//														"1HAN9TCNB0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HCKN8H6F32",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HCKN8H6F33",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAN9TCNB0",
//															"faceTagName": "chat"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HAN9LGGM2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HAN9LGGM3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1HAQAP0DE0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HAQAUB5C0",
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontSecondary\"]",
//														"text": "Step run:",
//														"font": "",
//														"fontSize": "#txtSize.smallPlus",
//														"bold": "true",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HAQAUB5C1",
//													"attrs": {
//														"1HANGAIE20": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAQNNP8R40",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAQNNP8R41",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HANGAIE20",
//															"faceTagName": "init"
//														},
//														"1HANIE6IF0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAQNNP8R42",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAQNNP8R43",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HANIE6IF0",
//															"faceTagName": "wait"
//														},
//														"1HANIEMO60": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAQNNP8R44",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAQNNP8R45",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HANIEMO60",
//															"faceTagName": "done"
//														},
//														"1HANF4N430": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HBHUVOCH2",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HBHUVOCH3",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HANF4N430",
//															"faceTagName": "start"
//														},
//														"1HAN9TCNB0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HCKN8H6F36",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HCKN8H6F37",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAN9TCNB0",
//															"faceTagName": "chat"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HAQAUB5C2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HAQAUB5C3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnSwitch.js",
//											"jaxId": "1HAQASJCS0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1HAQAUB5C4",
//													"attrs": {
//														"size": "20",
//														"check": "false"
//													}
//												},
//												"properties": {
//													"jaxId": "1HAQAUB5C5",
//													"attrs": {
//														"type": "#null#>BtnSwitch(20,false)",
//														"id": "BtnStepRun",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"margin": "[0,0,0,5]",
//														"color": "#cfgColor[\"warning\"]",
//														"lineColor": "#cfgColor[\"fontSecondarySub\"]"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HAQAUB5C6",
//													"attrs": {
//														"1HANGAIE20": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAQNNP8R48",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAQNNP8R49",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HANGAIE20",
//															"faceTagName": "init"
//														},
//														"1HANIE6IF0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAQNNP8R50",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAQNNP8R51",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HANIE6IF0",
//															"faceTagName": "wait"
//														},
//														"1HANIEMO60": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAQNNP8R52",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAQNNP8R53",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HANIEMO60",
//															"faceTagName": "done"
//														},
//														"1HANF4N430": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HBHUVOCH4",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HBHUVOCH5",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HANF4N430",
//															"faceTagName": "start"
//														},
//														"1HAN9TCNB0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HCKN8H6F40",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HCKN8H6F41",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAN9TCNB0",
//															"faceTagName": "chat"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HAQAUB5C7",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HAQAUB5C8",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "true",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1HAQAUB5C9",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1HAT08RSN0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1HAT0FO6I0",
//													"attrs": {
//														"style": "#cfgColor.fontSecondary",
//														"w": "24",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/find.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1HAT0FO6I1",
//													"attrs": {
//														"type": "#null#>BtnIcon(cfgColor.fontSecondary,24,0,appCfg.sharedAssets+\"/find.svg\",null)",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"margin": "[0,0,0,10]"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HAT0FO6I2",
//													"attrs": {
//														"1HANGAIE20": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HBHUUHIL10",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HBHUUHIL11",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HANGAIE20",
//															"faceTagName": "init"
//														},
//														"1HANF4N430": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HBHUVOCH6",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HBHUVOCH7",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HANF4N430",
//															"faceTagName": "start"
//														},
//														"1HANIEMO60": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HBHUVOCH8",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HBHUVOCH9",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HANIEMO60",
//															"faceTagName": "done"
//														},
//														"1HAN9TCNB0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HCKN8H6F44",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HCKN8H6F45",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAN9TCNB0",
//															"faceTagName": "chat"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HAT0FO6I3",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1HAT0SRNE0",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1HAT0TIVU0",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1HAT0FO6I4",
//													"attrs": {
//														"tip": {
//															"type": "string",
//															"valText": "Inspect chat bots",
//															"localizable": true
//														},
//														"tipDir": {
//															"type": "int",
//															"valText": "0"
//														}
//													}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1HAT0FO6I5",
//													"attrs": {}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1HAN972791",
//									"attrs": {
//										"1HANIE6IF0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HANIEURJ32",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HANIEURJ33",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HANIE6IF0",
//											"faceTagName": "wait"
//										},
//										"1HANGAIE20": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HAQNNP8R56",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HAQNNP8R57",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HANGAIE20",
//											"faceTagName": "init"
//										},
//										"1HANIEMO60": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HAQNNP8R58",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HAQNNP8R59",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HANIEMO60",
//											"faceTagName": "done"
//										},
//										"1HANF4N430": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HBHUVOCH12",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HBHUVOCH13",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HANF4N430",
//											"faceTagName": "start"
//										},
//										"1HAN9TCNB0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HCKN8H6F48",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HCKN8H6F49",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HAN9TCNB0",
//											"faceTagName": "chat"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HAN972792",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HAN972793",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear1HAMRK4MB0",
//							"jaxId": "1HAN9N2NL0",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1HAN9NSRM0",
//									"attrs": {
//										"opts": {
//											"jaxId": "1HB2D8HKK0",
//											"attrs": {
//												"bubble": "false",
//												"ai": {
//													"jaxId": "1HB2DJSU10",
//													"attrs": {
//														"blkColor": "[0,0,0,0.00]",
//														"bgColor": "#cfgColor.primary",
//														"icon": "#appCfg.sharedAssets+\"/faces.svg\"",
//														"pic": "",
//														"textColor": "#cfgColor[\"fontBody\"]",
//														"iconColor": "#cfgColor[\"fontSuccess\"]",
//														"side": "left"
//													}
//												},
//												"user": {
//													"jaxId": "1HB2DJSU11",
//													"attrs": {
//														"blkColor": "[0,0,0,0.00]",
//														"bgColor": "#cfgColor.primary",
//														"icon": "#appCfg.sharedAssets+\"/user.svg\"",
//														"pic": "",
//														"textColor": "#cfgColor[\"fontBody\"]",
//														"iconColor": "#cfgColor[\"fontPrimary\"]",
//														"side": "right"
//													}
//												},
//												"wait": {
//													"jaxId": "1HB2Q0DN60",
//													"attrs": {
//														"blkColor": "[0,0,0,0.00]",
//														"bgColor": "#cfgColor[\"secondary\"]",
//														"icon": "#appCfg.sharedAssets+\"/faces.svg\"",
//														"pic": "",
//														"textColor": "#cfgColor[\"fontBody\"]",
//														"iconColor": "#cfgColor[\"fontSecondary\"]",
//														"side": "left"
//													}
//												},
//												"event": {
//													"jaxId": "1HB2Q0DN61",
//													"attrs": {
//														"blkColor": "[0,0,0,0.00]",
//														"bgColor": "#cfgColor[\"warning\"]",
//														"icon": "#appCfg.sharedAssets+\"/event.svg\"",
//														"pic": "",
//														"textColor": "#cfgColor[\"fontBody\"]",
//														"iconColor": "#cfgColor[\"fontWarning\"]",
//														"side": "left"
//													}
//												},
//												"error": {
//													"jaxId": "1HB2Q0DN62",
//													"attrs": {
//														"blkColor": "[0,0,0,0.00]",
//														"bgColor": "#cfgColor[\"error\"]",
//														"icon": "#appCfg.sharedAssets+\"/fat_right.svg\"",
//														"pic": "",
//														"textColor": "[155,0,0,1.00]",
//														"iconColor": "#cfgColor[\"fontError\"]",
//														"side": "left"
//													}
//												},
//												"ask": {
//													"jaxId": "1HB2Q0DN63",
//													"attrs": {
//														"blkColor": "[0,0,0,0.00]",
//														"bgColor": "#cfgColor[\"success\"]",
//														"icon": "#appCfg.sharedAssets+\"/help.svg\"",
//														"pic": "",
//														"textColor": "#cfgColor[\"fontBody\"]",
//														"iconColor": "#cfgColor[\"fontSuccess\"]",
//														"side": "left"
//													}
//												},
//												"allowFile": "false"
//											}
//										}
//									}
//								},
//								"properties": {
//									"jaxId": "1HAN9NSRM1",
//									"attrs": {
//										"type": "#null#>UIChat({\"bubble\":false,\"ai\":{\"blkColor\":[0,0,0,0],\"bgColor\":cfgColor.primary,\"icon\":appCfg.sharedAssets+\"/faces.svg\",\"pic\":\"\",\"textColor\":cfgColor[\"fontBody\"],\"iconColor\":cfgColor[\"fontSuccess\"],\"side\":\"left\"},\"user\":{\"blkColor\":[0,0,0,0],\"bgColor\":cfgColor.primary,\"icon\":appCfg.sharedAssets+\"/user.svg\",\"pic\":\"\",\"textColor\":cfgColor[\"fontBody\"],\"iconColor\":cfgColor[\"fontPrimary\"],\"side\":\"right\"},\"wait\":{\"blkColor\":[0,0,0,0],\"bgColor\":cfgColor[\"secondary\"],\"icon\":appCfg.sharedAssets+\"/faces.svg\",\"pic\":\"\",\"textColor\":cfgColor[\"fontBody\"],\"iconColor\":cfgColor[\"fontSecondary\"],\"side\":\"left\"},\"event\":{\"blkColor\":[0,0,0,0],\"bgColor\":cfgColor[\"warning\"],\"icon\":appCfg.sharedAssets+\"/event.svg\",\"pic\":\"\",\"textColor\":cfgColor[\"fontBody\"],\"iconColor\":cfgColor[\"fontWarning\"],\"side\":\"left\"},\"error\":{\"blkColor\":[0,0,0,0],\"bgColor\":cfgColor[\"error\"],\"icon\":appCfg.sharedAssets+\"/fat_right.svg\",\"pic\":\"\",\"textColor\":[155,0,0,1],\"iconColor\":cfgColor[\"fontError\"],\"side\":\"left\"},\"ask\":{\"blkColor\":[0,0,0,0],\"bgColor\":cfgColor[\"success\"],\"icon\":appCfg.sharedAssets+\"/help.svg\",\"pic\":\"\",\"textColor\":cfgColor[\"fontBody\"],\"iconColor\":cfgColor[\"fontSuccess\"],\"side\":\"left\"},\"allowFile\":false})",
//										"id": "ChatUI",
//										"position": "Absolute",
//										"x": "0",
//										"y": "60",
//										"display": "On",
//										"face": "",
//										"w": "100%",
//										"h": "100%-90",
//										"defAssistant": {
//											"type": "object",
//											"def": "Object",
//											"jaxId": "1HAVR0L7E0",
//											"attrs": {}
//										}
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HAN9NSRM2",
//									"attrs": {
//										"1HAN9TCNB0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HANA3BLO20",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HANA3BLO21",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HAN9TCNB0",
//											"faceTagName": "chat"
//										},
//										"1HAN9TCNB2": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HANA3BLO22",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HANA3BLO23",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HAN9TCNB2",
//											"faceTagName": "debug"
//										},
//										"1HANIE6IF0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HANIEURJ36",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HANIEURJ37",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HANIE6IF0",
//											"faceTagName": "wait"
//										},
//										"1HANGAIE20": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HAQNNP8R62",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HAQNNP8R63",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HANGAIE20",
//											"faceTagName": "init"
//										},
//										"1HANIEMO60": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HAQNNP8R64",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HAQNNP8R65",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HANIEMO60",
//											"faceTagName": "done"
//										},
//										"1HANF4N430": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HBHUVOCH14",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HBHUVOCH15",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HANF4N430",
//											"faceTagName": "start"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HAN9NSRM3",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HAN9NSRM4",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true",
//								"containerSlots": {
//									"jaxId": "1HAN9NSRM5",
//									"attrs": {}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear1HAMSORTA0",
//							"jaxId": "1HAN9VP510",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1HANA09CI0",
//									"attrs": {}
//								},
//								"properties": {
//									"jaxId": "1HANA09CI1",
//									"attrs": {
//										"type": "#null#>UIPath()",
//										"id": "PathUI",
//										"position": "Absolute",
//										"x": "0",
//										"y": "60",
//										"display": "Off",
//										"face": "",
//										"w": "100%",
//										"h": "100%-90"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HANA09CI2",
//									"attrs": {
//										"1HAN9TCNB0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HANA3BLO24",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HANA3BLO25",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "Off"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HAN9TCNB0",
//											"faceTagName": "chat"
//										},
//										"1HAN9TCNB2": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HANA3BLO26",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HANA3BLO27",
//													"attrs": {
//														"display": {
//															"type": "choice",
//															"valText": "On"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HAN9TCNB2",
//											"faceTagName": "debug"
//										},
//										"1HANIE6IF0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HANIEURJ40",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HANIEURJ41",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HANIE6IF0",
//											"faceTagName": "wait"
//										},
//										"1HANGAIE20": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HAQNNP8R68",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HAQNNP8R69",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HANGAIE20",
//											"faceTagName": "init"
//										},
//										"1HANIEMO60": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HAQNNP8R70",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HAQNNP8R71",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HANIEMO60",
//											"faceTagName": "done"
//										},
//										"1HANF4N430": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HBHUVOCH16",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HBHUVOCH17",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HANF4N430",
//											"faceTagName": "start"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HANA09CI3",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HANA09CI4",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true",
//								"containerSlots": {
//									"jaxId": "1HANA09CI5",
//									"attrs": {}
//								}
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1HAN8902011",
//					"attrs": {
//						"1HANIE6IF0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HANIEURJ44",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HANIEURJ45",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HANIE6IF0",
//							"faceTagName": "wait"
//						},
//						"1HANGAIE20": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HAQNNP8R74",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HAQNNP8R75",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HANGAIE20",
//							"faceTagName": "init"
//						},
//						"1HANIEMO60": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HAQNNP8R76",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HAQNNP8R77",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HANIEMO60",
//							"faceTagName": "done"
//						},
//						"1HANF4N430": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HBHUVOCH18",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HBHUVOCH19",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HANF4N430",
//							"faceTagName": "start"
//						},
//						"1HAN9TCNB0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HCKN8H6F56",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HCKN8H6F57",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HAN9TCNB0",
//							"faceTagName": "chat"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1HAN8902012",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1HAN8902013",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1HAN8902014",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}