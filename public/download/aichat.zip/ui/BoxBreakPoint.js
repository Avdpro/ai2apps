//Auto genterated by Cody
import {$P,VFACT,callAfter} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
import {BtnSwitch} from "/@StdUI/ui/BtnSwitch.js";
/*#{1HAR1PMOV0StartDoc*/
import {DlgMenu} from "/@StdUI/ui/DlgMenu.js";
/*}#1HAR1PMOV0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BoxBreakPoint=function(stub,session){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let btnPhase;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1HAR1PMOV1LocalVals*/
	const app=VFACT.app;
	/*}#1HAR1PMOV1LocalVals*/
	
	/*#{1HAR1PMOV1PreState*/
	/*}#1HAR1PMOV1PreState*/
	/*#{1HAR1PMOV1PostState*/
	/*}#1HAR1PMOV1PostState*/
	cssVO={
		"hash":"1HAR1PMOV1",nameHost:true,
		"type":"box","x":0,"y":14,"w":"100%","h":"","margin":[5,0,10,0],"padding":10,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":[255,255,255,1],
		"border":2,"corner":6,"contentLayout":"flex-y",
		children:[
			{
				"hash":"1HAR399J40",
				"type":"box","x":">calc(100%                                                                                               -  95px)","y":-4,"w":100,
				"h":100,"alpha":0.5,"styleClass":"","background":cfgColor["fontBodyLit"],"maskImage":appCfg.sharedAssets+"/spot.svg",
			},
			{
				"hash":"1HAR1U3OM0",
				"type":"text","id":"TxtActor","position":"relative","x":0,"y":0,"w":"100%","h":"","margin":[0,0,5,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"color":cfgColor["fontBody"],"text":"Target: "+stub.actor,"fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
			},
			{
				"hash":"1HAR2CI5J0",
				"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":20,"margin":[0,0,5,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
				"itemsAlign":1,
				children:[
					{
						"hash":"1HAR2CVAB0",
						"type":BtnIcon("front",20,0,appCfg.sharedAssets+"/btncombo.svg",null),"id":"BtnPhase","position":"relative","x":0,"y":0,
						"OnClick":function(event){
							/*#{1HAR3DPUC0FunctionBody*/
							self.choosePhase();
							/*}#1HAR3DPUC0FunctionBody*/
						},
					},
					{
						"hash":"1HAR2G6DC0",
						"type":"text","id":"TxtPhase","position":"relative","x":0,"y":0,"w":"","h":"","margin":[0,0,0,5],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						"color":cfgColor["fontBody"],"text":"Break at: "+stub.phase+" phase","fontSize":txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
					}
				],
			},
			{
				"hash":"1HAR2JVS80",
				"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
				"itemsAlign":1,
				children:[
					{
						"hash":"1HAR2JVS97",
						"type":"text","id":"TxtEnable","position":"relative","x":0,"y":0,"w":"","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBody"],
						"text":"Enable:","fontSize":txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
					},
					{
						"hash":"1HAR2M2TR0",
						"type":BtnSwitch(16,stub.enable),"position":"relative","x":0,"y":0,"margin":[0,0,0,5],
						/*#{1HAR2M2TR0Codes*/
						OnCheck(){
							stub.enable=this.checked;
						}
						/*}#1HAR2M2TR0Codes*/
					}
				],
			},
			{
				"hash":"1HAR2UJVE0",
				"type":"text","position":"relative","x":0,"y":0,"w":"100%","h":"","margin":[5,0,0,0],"styleClass":"","color":cfgColor["fontBodySub"],"text":"Check value (empty means no check):",
				"fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"",
			},
			{
				"hash":"1HAR33IUT0",
				"type":"memo","id":"EdText","position":"relative","x":0,"y":0,"w":"100%","h":"","margin":[5,0,0,0],"minH":30,"maxH":100,"styleClass":"","text":stub.text,
				"color":[0,0,0],"fontSize":14,"border":1,"borderColor":[0,0,0,1],
				"OnChange":function(){
					/*#{1HAR3JM8U0FunctionBody*/
					/*}#1HAR3JM8U0FunctionBody*/
				},
				"OnKeyDown":function(event){
					/*#{1HAR74D0M0FunctionBody*/
					if(event.code==="Enter"){
						if((!event.isComposing) &&(!event.shiftKey)){
							event.stopPropagation();
							event.preventDefault();
							stub.text=this.text;
							this.blur();
						}
					}
					/*}#1HAR74D0M0FunctionBody*/
				},
			},
			{
				"hash":"1HAR3N8MH0",
				"type":BtnIcon("front",30,0,appCfg.sharedAssets+"/trash.svg",null),"id":"BtnRemove","x":">calc(100% - 35px)","y":5,
				"OnClick":function(event){
					/*#{1HAR3Q05P0FunctionBody*/
					//Remove breakpoint
					session.removeBreakPoint(stub);
					self.parent.removeChild(self);
					/*}#1HAR3Q05P0FunctionBody*/
				},
			}
		],
		/*#{1HAR1PMOV1ExtraCSS*/
		/*}#1HAR1PMOV1ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			self=this;
			btnPhase=self.BtnPhase;
			/*#{1HAR1PMOV1Create*/
			/*}#1HAR1PMOV1Create*/
		},
		/*#{1HAR1PMOV1EndCSS*/
		/*}#1HAR1PMOV1EndCSS*/
	};
	/*#{1HAR1PMOV1PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.choosePhase=async function(){
		let item;
		item=await app.modalDlg(DlgMenu,{
			hud:btnPhase,
			items:[
				{text:"Break on input phase",code:"input"},
				{text:"Break on output phase",code:"output"},
			]
		});
		if(!item){
			return;
		}
		stub.phase=item.code;
	};
	/*}#1HAR1PMOV1PostCSSVO*/
	return cssVO;
};
/*#{1HAR1PMOV1ExCodes*/
/*}#1HAR1PMOV1ExCodes*/


export default BoxBreakPoint;
export{BoxBreakPoint};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearBox",
//	"jaxId": "1HAR1PMOV0",
//	"editVersion": 62,
//	"attrs": {
//		"editEnv": {
//			"type": "object",
//			"jaxId": "1HAR1PMOV2",
//			"editVersion": 10,
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"type": "object",
//			"jaxId": "1HAR1PMOV3",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"model": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1HAR1PMOV4",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"createArgs": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1HAR1PMOV5",
//			"editVersion": 20,
//			"attrs": {
//				"stub": {
//					"type": "auto",
//					"valText": "#{actor:\"./default.aichat\",phase:\"all\",text:\"hi\",enable:true}"
//				},
//				"session": {
//					"type": "auto",
//					"valText": "null"
//				}
//			}
//		},
//		"localVars": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1HAR1PMOV6",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"type": "object",
//			"def": "StateObj",
//			"jaxId": "1HAR1PMOV7",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"type": "object",
//			"def": "FaceTags",
//			"jaxId": "1HAR1PMOV8",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"mockupStates": {
//			"type": "object",
//			"def": "MockupObj",
//			"jaxId": "1HAR1PMOV9",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "box",
//			"jaxId": "1HAR1PMOV1",
//			"editVersion": 20,
//			"attrs": {
//				"properties": {
//					"type": "object",
//					"jaxId": "1HAR1PMOV10",
//					"editVersion": 142,
//					"attrs": {
//						"type": "box",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "14",
//						"w": "100%",
//						"h": "",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "[5,0,10,0]",
//						"padding": "10",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"background": "[255,255,255,1.00]",
//						"border": "2",
//						"borderStyle": "Solid",
//						"borderColor": "[0,0,0,1.00]",
//						"corner": "6",
//						"shadow": "false",
//						"shadowX": "2",
//						"shadowY": "2",
//						"shadowBlur": "3",
//						"shadowSpread": "0",
//						"shadowColor": "[0,0,0,0.50]",
//						"contentLayout": "Flex Y"
//					}
//				},
//				"subHuds": {
//					"type": "array",
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1HAR399J40",
//							"editVersion": 20,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1HAR3CK2R0",
//									"editVersion": 796,
//									"attrs": {
//										"type": "box",
//										"id": "",
//										"position": "Absolute",
//										"x": "100%                                                                                              - 95",
//										"y": "-4",
//										"w": "100",
//										"h": "100",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "0.5",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"fontBodyLit\"]",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"maskImage": "#appCfg.sharedAssets+\"/spot.svg\""
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1HAR3CK2R1",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1HAR3CK2R2",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1HAR3CK2R3",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1HAR1U3OM0",
//							"editVersion": 22,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1HAR28V8B0",
//									"editVersion": 154,
//									"attrs": {
//										"type": "text",
//										"id": "TxtActor",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,5,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#cfgColor[\"fontBody\"]",
//										"text": "#\"Target: \"+stub.actor",
//										"font": "",
//										"fontSize": "#txtSize.small",
//										"bold": "false",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Top",
//										"wrap": "false",
//										"ellipsis": "false",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1HAR28V8B1",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1HAR28V8B2",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1HAR28V8B3",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1HAR2CI5J0",
//							"editVersion": 22,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1HAR2JU8J0",
//									"editVersion": 100,
//									"attrs": {
//										"type": "hud",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "20",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,5,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex X",
//										"itemsAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1HAR2CVAB0",
//											"editVersion": 32,
//											"attrs": {
//												"createArgs": {
//													"type": "object",
//													"def": "gearCrateArgs",
//													"jaxId": "1HAR2JU8J1",
//													"editVersion": 22,
//													"attrs": {
//														"style": "\"front\"",
//														"w": "20",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/btncombo.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"type": "object",
//													"jaxId": "1HAR2JU8J2",
//													"editVersion": 34,
//													"attrs": {
//														"type": "#null#>BtnIcon(\"front\",20,0,appCfg.sharedAssets+\"/btncombo.svg\",null)",
//														"id": "BtnPhase",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": ""
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1HAR2JU8J3",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1HAR2JU8J4",
//													"editVersion": 2,
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1HAR3DPUC0",
//															"editVersion": 2,
//															"attrs": {
//																"callArgs": {
//																	"type": "object",
//																	"jaxId": "1HAR3EGIU0",
//																	"editVersion": 2,
//																	"attrs": {
//																		"event": ""
//																	}
//																}
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1HAR2JU8J5",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"type": "object",
//													"jaxId": "1HAR2JU8J6",
//													"editVersion": 0,
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1HAR2G6DC0",
//											"editVersion": 24,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HAR2G6DC1",
//													"editVersion": 168,
//													"attrs": {
//														"type": "text",
//														"id": "TxtPhase",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "[0,0,0,5]",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBody\"]",
//														"text": "#\"Break at: \"+stub.phase+\" phase\"",
//														"font": "",
//														"fontSize": "#txtSize.smallPlus",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "false",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1HAR2G6DC2",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1HAR2G6DC3",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1HAR2G6DC4",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1HAR2JU8J7",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1HAR2JU8J8",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1HAR2JU8J9",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1HAR2JVS80",
//							"editVersion": 22,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1HAR2JVS81",
//									"editVersion": 78,
//									"attrs": {
//										"type": "hud",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "20",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex X",
//										"itemsAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1HAR2JVS97",
//											"editVersion": 26,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HAR2JVS98",
//													"editVersion": 186,
//													"attrs": {
//														"type": "text",
//														"id": "TxtEnable",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "0",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBody\"]",
//														"text": "Enable:",
//														"font": "",
//														"fontSize": "#txtSize.smallPlus",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "false",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1HAR2JVS99",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1HAR2JVS910",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1HAR2JVS911",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnSwitch.js",
//											"jaxId": "1HAR2M2TR0",
//											"editVersion": 31,
//											"attrs": {
//												"createArgs": {
//													"type": "object",
//													"def": "gearCrateArgs",
//													"jaxId": "1HAR2O0HO0",
//													"editVersion": 18,
//													"attrs": {
//														"size": "16",
//														"check": "#stub.enable"
//													}
//												},
//												"properties": {
//													"type": "object",
//													"jaxId": "1HAR2O0HO1",
//													"editVersion": 33,
//													"attrs": {
//														"type": "#null#>BtnSwitch(16,stub.enable)",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"margin": "[0,0,0,5]"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1HAR2O0HO2",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1HAR2O0HO3",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1HAR2O0HO4",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "true",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"type": "object",
//													"jaxId": "1HAR2O0HO5",
//													"editVersion": 0,
//													"attrs": {}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1HAR2JVS912",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1HAR2JVS913",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1HAR2JVS914",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1HAR2UJVE0",
//							"editVersion": 20,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1HAR34P280",
//									"editVersion": 132,
//									"attrs": {
//										"type": "text",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[5,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#cfgColor[\"fontBodySub\"]",
//										"text": "Check value (empty means no check):",
//										"font": "",
//										"fontSize": "#txtSize.small",
//										"bold": "false",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Top",
//										"wrap": "false",
//										"ellipsis": "false",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1HAR34P281",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1HAR34P282",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1HAR34P283",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "memo",
//							"jaxId": "1HAR33IUT0",
//							"editVersion": 21,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1HAR34P284",
//									"editVersion": 132,
//									"attrs": {
//										"type": "memo",
//										"id": "EdText",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[5,0,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "30",
//										"maxW": "",
//										"maxH": "100",
//										"face": "",
//										"styleClass": "",
//										"text": "#stub.text",
//										"color": "[0,0,0]",
//										"bgColor": "[255,255,255,1.00]",
//										"font": "",
//										"fontSize": "14",
//										"outline": "1",
//										"border": "1",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"readOnly": "false",
//										"selectOnFocus": "true",
//										"spellCheck": "true"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1HAR34P285",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1HAR34P286",
//									"editVersion": 4,
//									"attrs": {
//										"OnChange": {
//											"type": "fixedFunc",
//											"jaxId": "1HAR3JM8U0",
//											"editVersion": 2,
//											"attrs": {
//												"callArgs": {
//													"type": "object",
//													"jaxId": "1HAR3KN840",
//													"editVersion": 0,
//													"attrs": {}
//												}
//											}
//										},
//										"OnKeyDown": {
//											"type": "fixedFunc",
//											"jaxId": "1HAR74D0M0",
//											"editVersion": 2,
//											"attrs": {
//												"callArgs": {
//													"type": "object",
//													"jaxId": "1HAR75EU50",
//													"editVersion": 2,
//													"attrs": {
//														"event": ""
//													}
//												}
//											}
//										}
//									}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1HAR34P287",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear/@StdUI/ui/BtnIcon.js",
//							"jaxId": "1HAR3N8MH0",
//							"editVersion": 27,
//							"attrs": {
//								"createArgs": {
//									"type": "object",
//									"def": "gearCrateArgs",
//									"jaxId": "1HAR3QR9T0",
//									"editVersion": 16,
//									"attrs": {
//										"style": "\"front\"",
//										"w": "30",
//										"h": "0",
//										"icon": "#appCfg.sharedAssets+\"/trash.svg\"",
//										"colorBG": "null"
//									}
//								},
//								"properties": {
//									"type": "object",
//									"jaxId": "1HAR3QR9T1",
//									"editVersion": 48,
//									"attrs": {
//										"type": "#null#>BtnIcon(\"front\",30,0,appCfg.sharedAssets+\"/trash.svg\",null)",
//										"id": "BtnRemove",
//										"position": "Absolute",
//										"x": "100%-35",
//										"y": "5",
//										"display": "On",
//										"face": ""
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1HAR3QR9T2",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1HAR3QR9T3",
//									"editVersion": 2,
//									"attrs": {
//										"OnClick": {
//											"type": "fixedFunc",
//											"jaxId": "1HAR3Q05P0",
//											"editVersion": 2,
//											"attrs": {
//												"callArgs": {
//													"type": "object",
//													"jaxId": "1HAR3QR9T4",
//													"editVersion": 2,
//													"attrs": {
//														"event": ""
//													}
//												}
//											}
//										}
//									}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1HAR3QR9T5",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false",
//								"containerSlots": {
//									"type": "object",
//									"jaxId": "1HAR3QR9T6",
//									"editVersion": 0,
//									"attrs": {}
//								}
//							}
//						}
//					]
//				},
//				"faces": {
//					"type": "object",
//					"jaxId": "1HAR1PMOV11",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"functions": {
//					"type": "object",
//					"jaxId": "1HAR1PMOV12",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"extraPpts": {
//					"type": "object",
//					"def": "Object",
//					"jaxId": "1HAR1PMOV13",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "true",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1HAR1PMOV14",
//			"editVersion": 100,
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"background": "false",
//				"color": "false",
//				"gradient": "false",
//				"border": "false",
//				"borders": "false",
//				"borderStyle": "false",
//				"borderColor": "false",
//				"borderColors": "false",
//				"corner": "false",
//				"coner": "false",
//				"coners": "false",
//				"shadow": "false",
//				"shadowX": "false",
//				"shadowY": "false",
//				"shadowBlur": "false",
//				"shadowSpread": "false",
//				"shadowColor": "false",
//				"maskImage": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}