//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
/*#{1HHA5TKVC0StartDoc*/
import {tabNT,tabOS} from "/@tabos";
/*}#1HHA5TKVC0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BoxTokenGas=function(h,bgColor,textColor,iconSize,fontSize,menu,thin,chatIcon,chatIconSize){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let btnToken,btnGas;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1HHA5TKVD0LocalVals*/
	let app=VFACT.app;
	/*}#1HHA5TKVD0LocalVals*/
	
	/*#{1HHA5TKVD0PreState*/
	/*}#1HHA5TKVD0PreState*/
	state={
		"caption":"AIChat","txtToken":"- - -","txtGas":"- - -",
		/*#{1HHA5TKVD6ExState*/
		/*}#1HHA5TKVD6ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1HHA5TKVD0PostState*/
	/*}#1HHA5TKVD0PostState*/
	cssVO={
		"hash":"1HHA5TKVD0",nameHost:true,
		"type":"box","x":0,"y":0,"w":"100%","h":h,"padding":[0,10,0,5],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":bgColor,"contentLayout":"flex-x",
		"itemsAlign":1,
		children:[
			{
				"hash":"1IHT9RT840",
				"type":"box","id":"BoxIcon","position":"relative","x":0,"y":0,"w":chatIconSize||iconSize,"h":chatIconSize||iconSize,"margin":[0,5,0,0],"minW":"","minH":"",
				"maxW":"","maxH":"","styleClass":"","background":textColor,"attached":!!chatIcon,"maskImage":chatIcon,
			},
			{
				"hash":"1HHA62B5A0",
				"type":"text","id":"TxtCaption","position":"relative","x":0,"y":0,"w":100,"h":"","uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"color":textColor,"text":$P(()=>(state.caption),state),"fontSize":fontSize,"fontWeight":(!thin)?"bold":"normal","fontStyle":"normal","textDecoration":"",
				"alignV":1,"ellipsis":true,"flex":true,
			},
			{
				"hash":"1HHAIFR0C0",
				"type":BtnIcon(textColor,iconSize,0,appCfg.sharedAssets+(thin?"/token_e.svg":"/token.svg"),null),"id":"BtnToken","position":"relative","x":0,"y":0,
				"padding":2,
				"tip":(($ln==="CN")?("获取更多代币和能量"):("Get more token and gas")),
				"OnClick":function(event){
					/*#{1HHAJ1H150FunctionBody*/
					self.showTokenGasDlg();
					/*}#1HHAJ1H150FunctionBody*/
				},
			},
			{
				"hash":"1HHA66LJ10",
				"type":"text","id":"TxtToken","position":"relative","x":0,"y":0,"w":"","h":"100%","margin":[0,5,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"color":textColor,"text":$P(()=>(state.txtToken),state),"fontSize":fontSize,"fontWeight":(!thin)?"bold":"normal","fontStyle":"normal","textDecoration":"",
				"alignV":1,
			},
			{
				"hash":"1HHAIFR0C0",
				"type":BtnIcon(textColor,iconSize,0,appCfg.sharedAssets+(thin?"/gas_e.svg":"/gas.svg"),null),"id":"BtnGas","position":"relative","x":0,"y":0,"padding":2,
				"tip":(($ln==="CN")?("获取更多能量"):("Get more gas")),
				"OnClick":function(event){
					/*#{1HHAJ1NDM0FunctionBody*/
					self.showTokenGasDlg();
					/*}#1HHAJ1NDM0FunctionBody*/
				},
			},
			{
				"hash":"1HHA66LJ10",
				"type":"text","id":"TxtGas","position":"relative","x":0,"y":0,"w":"","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":textColor,
				"text":$P(()=>(state.txtGas),state),"fontSize":fontSize,"fontWeight":(!thin)?"bold":"normal","fontStyle":"normal","textDecoration":"","alignV":1,
			},
			{
				"hash":"1HIFSBPM20",
				"type":BtnIcon(textColor,iconSize,0,appCfg.sharedAssets+"/menu.svg",null),"id":"BtnMenu","position":"relative","x":0,"y":0,"margin":[0,0,0,10],"padding":0,
				"attached":!!menu,
				"tip":(($ln==="CN")?("首选菜单"):("Options menu")),
				"OnClick":function(event){
					/*#{1HIFSBPM30FunctionBody*/
					if(self.OnMenu){
						self.OnMenu(this);
					}
					/*}#1HIFSBPM30FunctionBody*/
				},
			}
		],
		get $$caption(){return state["caption"]},
		set $$caption(v){
			state["caption"]=v;
			/*#{1HHA5TKVD0Setcaption*/
			/*}#1HHA5TKVD0Setcaption*/
		},
		/*#{1HHA5TKVD0ExtraCSS*/
		/*}#1HHA5TKVD0ExtraCSS*/
		faces:{
			"preview":{
				/*BtnToken*/"#1HHAIFR0C0":{
					"enable":false
				},
				/*BtnGas*/"#1HHAIFR0C0":{
					"enable":false
				},
				/*BtnMenu*/"#1HIFSBPM20":{
					"enable":false
				}
			}
		},
		OnCreate:function(){
			self=this;
			btnToken=self.BtnToken;btnGas=self.BtnGas;
			/*#{1HHA5TKVD0Create*/
			self.refresh();
			app.on("PreviewLogin",self.preview);
			if(tabOS.onNotify){
				tabOS.onNotify("UpdateTokenGas",()=>{
					app.emit("UpdateTokenGas");
					app.emitNotify("UpdateTokenGas");
				});
			}
			app.on("UpdateTokenGas",self.refresh);
			/*}#1HHA5TKVD0Create*/
		},
		/*#{1HHA5TKVD0EndCSS*/
		/*}#1HHA5TKVD0EndCSS*/
	};
	/*#{1HHA5TKVD0PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.preview=function(){
		self.showFace("preview");
		btnToken.enable=false;
		btnGas.enable=false;
	};
	
	//------------------------------------------------------------------------
	let isRefreshing=false;
	cssVO.refresh=async function(){
		let res,userTokens,userGas;
		function numText(num){
			if(num<0){
				return "- - -";
			}
			num=Math.floor(num);
			if(num>=100){
				return ""+num;
			}
			if(num>=10){
				return "0"+num;
			}
			return "00"+num;
		}
		if(isRefreshing){
			return;
		}
		isRefreshing=true;
		if(!(await tabNT.checkLogin(false))){
			if(!(await tabNT.maybePreview())){
				userTokens=-1;
				userGas=-1;
				state.txtToken=numText(userTokens);
				state.txtGas=numText(userGas);
				isRefreshing=false;
				return;
			}
		}
		try{
			res=await tabNT.makeCall("userCurrency",{});
			if(res.code===200){
				userTokens=res.coins||0;
				userGas=res.points||0;
			}else{
				userTokens=-1;
				userGas=-1;
			}
		}catch(err){
			userTokens=-1;
			userGas=-1;
		}
		state.txtToken=numText(userTokens);
		state.txtGas=numText(userGas);
		isRefreshing=false;
	};
	
	//------------------------------------------------------------------------
	cssVO.showTokenGasDlg=async function(){
		await app.modalDlg("/@homekit/ui/DlgTokenGas.js",{});
		self.refresh();
	};
	/*}#1HHA5TKVD0PostCSSVO*/
	cssVO.constructor=BoxTokenGas;
	return cssVO;
};
/*#{1HHA5TKVD0ExCodes*/
/*}#1HHA5TKVD0ExCodes*/

//----------------------------------------------------------------------------
BoxTokenGas.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1HHA5TKVD0PreAISpot*/
	/*}#1HHA5TKVD0PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="Chat Header";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1HHA5TKVD0PostAISpot*/
	/*}#1HHA5TKVD0PostAISpot*/
	return exposeVO;
};

//----------------------------------------------------------------------------
BoxTokenGas.gearExport={
	framework: "jax",
	hudType: "box",
	"showName":"Chat Header",icon:"gears.svg",previewImg:false,
	fixPose:true,initW:300,initH:30,
	catalog:"Views",
	args: {
		"h": {
			"name": "h", "showName": "h", "type": "int", "key": true, "fixed": true, "initVal": 30
		}, 
		"bgColor": {
			"name": "bgColor", "showName": "bgColor", "type": "colorRGBA", "key": true, "fixed": true, 
			"initVal": [108,117,125,1], "initValText": "#cfgColor[\"secondary\"]"
		}, 
		"textColor": {
			"name": "textColor", "showName": "textColor", "type": "colorRGBA", "key": true, "fixed": true, 
			"initVal": [255,255,255,1], "initValText": "#cfgColor[\"fontSecondary\"]"
		}, 
		"iconSize": {
			"name": "iconSize", "showName": "iconSize", "type": "int", "key": true, "fixed": true, "initVal": 24
		}, 
		"fontSize": {
			"name": "fontSize", "showName": "fontSize", "type": "int", "key": true, "fixed": true, "initVal": 16
		}, 
		"menu": {
			"name": "menu", "showName": "menu", "type": "bool", "key": true, "fixed": true, "initVal": false
		}, 
		"thin": {
			"name": "thin", "showName": "thin", "type": "bool", "key": true, "fixed": true, "initVal": false
		}, 
		"chatIcon": {
			"name": "chatIcon", "showName": "chatIcon", "type": "string", "key": true, "fixed": true, "initVal": "/~/-tabos/shared/assets/aalogo.svg", "initValText": "#appCfg.sharedAssets+\"/aalogo.svg\""
		}, 
		"chatIconSize": {
			"name": "chatIconSize", "showName": "chatIconSize", "type": "int", "key": true, "fixed": true, "initVal": 30
		}
	},
	state:{
		caption:{name:"caption",type:"string",initVal:"AIChat",localizable:true}
	},
	properties:["id","position","x","y","w","h","anchorH","anchorV","display","clip","uiEvent","alpha","rotate","scale","cursor","zIndex","margin","traceSize","padding","styleClass","corner","shadow","shadowX","shadowY","shadowBlur","shadowSpread","shadowColor"],
	faces:["preview"],
	subContainers:{
	},
	/*#{1HHA5TKVC0ExGearInfo*/
	/*}#1HHA5TKVC0ExGearInfo*/
};
/*#{1HHA5TKVC0EndDoc*/
/*}#1HHA5TKVC0EndDoc*/

export default BoxTokenGas;
export{BoxTokenGas};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearBox",
//	"jaxId": "1HHA5TKVC0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1HHA5TKVD1",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1HHA5TKVD2",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1HHA5TKVD3",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1HHA5TKVD4",
//			"attrs": {
//				"h": {
//					"type": "int",
//					"valText": "30"
//				},
//				"bgColor": {
//					"type": "colorRGBA",
//					"valText": "#cfgColor[\"secondary\"]"
//				},
//				"textColor": {
//					"type": "colorRGBA",
//					"valText": "#cfgColor[\"fontSecondary\"]"
//				},
//				"iconSize": {
//					"type": "int",
//					"valText": "24"
//				},
//				"fontSize": {
//					"type": "int",
//					"valText": "16"
//				},
//				"menu": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"thin": {
//					"type": "bool",
//					"valText": "false"
//				},
//				"chatIcon": {
//					"type": "string",
//					"valText": "#appCfg.sharedAssets+\"/aalogo.svg\""
//				},
//				"chatIconSize": {
//					"type": "int",
//					"valText": "30"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1HHA5TKVD5",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1HHA5TKVD6",
//			"attrs": {
//				"caption": {
//					"type": "string",
//					"valText": "AIChat",
//					"localizable": true
//				},
//				"txtToken": {
//					"type": "string",
//					"valText": "- - -"
//				},
//				"txtGas": {
//					"type": "string",
//					"valText": "- - -"
//				}
//			}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "Chat Header",
//		"gearIcon": "gears.svg",
//		"gearW": "300",
//		"gearH": "30",
//		"gearCatalog": "Views",
//		"description": "",
//		"fixPose": "true",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1HHA5TKVD7",
//			"attrs": {
//				"preview": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HUKN1LNR0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HUKN22BE0",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1HHA5TKVD8",
//			"attrs": {}
//		},
//		"exposeToAI": "true",
//		"descAI": "",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "box",
//			"jaxId": "1HHA5TKVD0",
//			"attrs": {
//				"properties": {
//					"jaxId": "1HHA5TKVD9",
//					"attrs": {
//						"type": "box",
//						"id": "",
//						"position": "Absolute",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "#h",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "[0,10,0,5]",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"background": "#bgColor",
//						"border": "0",
//						"borderStyle": "Solid",
//						"borderColor": "[0,0,0,1.00]",
//						"corner": "0",
//						"shadow": "false",
//						"shadowX": "2",
//						"shadowY": "2",
//						"shadowBlur": "3",
//						"shadowSpread": "0",
//						"shadowColor": "[0,0,0,0.50]",
//						"contentLayout": "Flex X",
//						"subAlign": "Start",
//						"itemsAlign": "Center"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1IHT9RT840",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IHTA1BAP0",
//									"attrs": {
//										"type": "box",
//										"id": "BoxIcon",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "#chatIconSize||iconSize",
//										"h": "#chatIconSize||iconSize",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,5,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#textColor",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"attach": "#!!chatIcon",
//										"maskImage": "#chatIcon"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1IHTA1BAP1",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1IHTA1BAP2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IHTA1BAP3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1HHA62B5A0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HHA6A6NE0",
//									"attrs": {
//										"type": "text",
//										"id": "TxtCaption",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#textColor",
//										"text": "${state.caption},state",
//										"font": "",
//										"fontSize": "#fontSize",
//										"bold": "#!thin",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Center",
//										"wrap": "false",
//										"ellipsis": "true",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0",
//										"flex": "true"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HHA6A6NE1",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1HHA6A6NE2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HHA6A6NE3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear/@StdUI/ui/BtnIcon.js",
//							"jaxId": "1HHAIFR0C0",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1HHAIH1SQ0",
//									"attrs": {
//										"style": "#textColor",
//										"w": "#iconSize",
//										"h": "0",
//										"icon": "#appCfg.sharedAssets+(thin?\"/token_e.svg\":\"/token.svg\")",
//										"colorBG": "null"
//									}
//								},
//								"properties": {
//									"jaxId": "1HHAIH1SQ1",
//									"attrs": {
//										"type": "#null#>BtnIcon(textColor,iconSize,0,appCfg.sharedAssets+(thin?\"/token_e.svg\":\"/token.svg\"),null)",
//										"id": "BtnToken",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"display": "On",
//										"face": "",
//										"padding": "2"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HHAIH1SQ2",
//									"attrs": {
//										"1HUKN1LNR0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HUKN22BE3",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HUKN22BE4",
//													"attrs": {
//														"enable": {
//															"type": "bool",
//															"valText": "false"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HUKN1LNR0",
//											"faceTagName": "preview"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HHAIH1SQ3",
//									"attrs": {
//										"OnClick": {
//											"type": "fixedFunc",
//											"jaxId": "1HHAJ1H150",
//											"attrs": {
//												"callArgs": {
//													"jaxId": "1HHAJ5H0R0",
//													"attrs": {
//														"event": ""
//													}
//												},
//												"seg": ""
//											}
//										}
//									}
//								},
//								"extraPpts": {
//									"jaxId": "1HHAIH1SQ4",
//									"attrs": {
//										"tip": {
//											"type": "string",
//											"valText": "Get more token and gas",
//											"localize": {
//												"EN": "Get more token and gas",
//												"CN": "获取更多代币和能量"
//											},
//											"localizable": true
//										}
//									}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true",
//								"containerSlots": {
//									"jaxId": "1HHAIH1SQ5",
//									"attrs": {}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1HHA66LJ10",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HHA689BT0",
//									"attrs": {
//										"type": "text",
//										"id": "TxtToken",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,5,0,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#textColor",
//										"text": "${state.txtToken},state",
//										"font": "",
//										"fontSize": "#fontSize",
//										"bold": "#!thin",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Center",
//										"wrap": "false",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HHA689BU0",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1HHA689BU1",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HHA689BU2",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear/@StdUI/ui/BtnIcon.js",
//							"jaxId": "1HHAIFR0C0",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1HHAIH1SQ0",
//									"attrs": {
//										"style": "#textColor",
//										"w": "#iconSize",
//										"h": "0",
//										"icon": "#appCfg.sharedAssets+(thin?\"/gas_e.svg\":\"/gas.svg\")",
//										"colorBG": "null"
//									}
//								},
//								"properties": {
//									"jaxId": "1HHAIH1SQ1",
//									"attrs": {
//										"type": "#null#>BtnIcon(textColor,iconSize,0,appCfg.sharedAssets+(thin?\"/gas_e.svg\":\"/gas.svg\"),null)",
//										"id": "BtnGas",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"display": "On",
//										"face": "",
//										"padding": "2"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HHAIH1SQ2",
//									"attrs": {
//										"1HUKN1LNR0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HUKN22BE7",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HUKN22BF0",
//													"attrs": {
//														"enable": {
//															"type": "bool",
//															"valText": "false"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HUKN1LNR0",
//											"faceTagName": "preview"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HHAIH1SQ3",
//									"attrs": {
//										"OnClick": {
//											"type": "fixedFunc",
//											"jaxId": "1HHAJ1NDM0",
//											"attrs": {
//												"callArgs": {
//													"jaxId": "1HHAJ5H0R1",
//													"attrs": {
//														"event": ""
//													}
//												},
//												"seg": ""
//											}
//										}
//									}
//								},
//								"extraPpts": {
//									"jaxId": "1HHAIH1SQ4",
//									"attrs": {
//										"tip": {
//											"type": "string",
//											"valText": "Get more gas",
//											"localize": {
//												"EN": "Get more gas",
//												"CN": "获取更多能量"
//											},
//											"localizable": true
//										}
//									}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true",
//								"containerSlots": {
//									"jaxId": "1HHAIH1SQ5",
//									"attrs": {}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1HHA66LJ10",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HHA689BT0",
//									"attrs": {
//										"type": "text",
//										"id": "TxtGas",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#textColor",
//										"text": "${state.txtGas},state",
//										"font": "",
//										"fontSize": "#fontSize",
//										"bold": "#!thin",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Center",
//										"wrap": "false",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HHA689BU0",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1HHA689BU1",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HHA689BU2",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear/@StdUI/ui/BtnIcon.js",
//							"jaxId": "1HIFSBPM20",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1HIFSBPM21",
//									"attrs": {
//										"style": "#textColor",
//										"w": "#iconSize",
//										"h": "0",
//										"icon": "#appCfg.sharedAssets+\"/menu.svg\"",
//										"colorBG": "null"
//									}
//								},
//								"properties": {
//									"jaxId": "1HIFSBPM22",
//									"attrs": {
//										"type": "#null#>BtnIcon(textColor,iconSize,0,appCfg.sharedAssets+\"/menu.svg\",null)",
//										"id": "BtnMenu",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"display": "On",
//										"face": "",
//										"margin": "[0,0,0,10]",
//										"padding": "0",
//										"attach": "#!!menu"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HIFSBPM23",
//									"attrs": {
//										"1HUKN1LNR0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HUKN42MM6",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HUKN42MM7",
//													"attrs": {
//														"enable": {
//															"type": "bool",
//															"valText": "false"
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HUKN1LNR0",
//											"faceTagName": "preview"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HIFSBPM24",
//									"attrs": {
//										"OnClick": {
//											"type": "fixedFunc",
//											"jaxId": "1HIFSBPM30",
//											"attrs": {
//												"callArgs": {
//													"jaxId": "1HIFSBPM31",
//													"attrs": {
//														"event": ""
//													}
//												},
//												"seg": ""
//											}
//										}
//									}
//								},
//								"extraPpts": {
//									"jaxId": "1HIFSBPM32",
//									"attrs": {
//										"tip": {
//											"type": "string",
//											"valText": "Options menu",
//											"localize": {
//												"EN": "Options menu",
//												"CN": "首选菜单"
//											},
//											"localizable": true
//										}
//									}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false",
//								"containerSlots": {
//									"jaxId": "1HIFSBPM33",
//									"attrs": {}
//								}
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1HHA5TKVD10",
//					"attrs": {}
//				},
//				"functions": {
//					"jaxId": "1HHA5TKVD11",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1HHA5TKVD12",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false"
//			}
//		},
//		"exposeGear": "true",
//		"exposeTemplate": "true",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1HHA5TKVD13",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "true",
//				"h": "true",
//				"anchorH": "true",
//				"anchorV": "true",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "true",
//				"uiEvent": "true",
//				"alpha": "true",
//				"rotate": "true",
//				"scale": "true",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "true",
//				"zIndex": "true",
//				"flex": "false",
//				"margin": "true",
//				"traceSize": "true",
//				"padding": "true",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "true",
//				"exposeToAI": "false",
//				"descAI": "false",
//				"background": "false",
//				"color": "false",
//				"gradient": "false",
//				"border": "false",
//				"borders": "false",
//				"borderStyle": "false",
//				"borderColor": "false",
//				"borderColors": "false",
//				"corner": "true",
//				"coner": "false",
//				"coners": "false",
//				"shadow": "true",
//				"shadowX": "true",
//				"shadowY": "true",
//				"shadowBlur": "true",
//				"shadowSpread": "true",
//				"shadowColor": "true",
//				"maskImage": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": [
//				{
//					"type": "string",
//					"valText": "caption"
//				}
//			]
//		}
//	}
//}