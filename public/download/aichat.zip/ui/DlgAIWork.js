//Auto genterated by Cody
import {$P,VFACT,callAfter} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BoxAIChat} from "./BoxAIChat.js";
import {BtnText} from "/@StdUI/ui/BtnText.js";
/*#{1HAT6MSEI0StartDoc*/
import {tabNT} from "/@tabos/tabos_nt.js";
import {DlgLogin} from "/@homekit/ui/DlgLogin.js";
import {BoxAIChatBlock} from "./BoxAIChatBlock.js";
import {BoxAskUser} from "./BoxAskUser.js";
/*}#1HAT6MSEI0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let DlgAIWork=function(){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let boxBG,txtTitle,boxChats,boxUser;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let botName="AI";
	let title="";
	
	/*#{1HA4CQ2RT1LocalVals*/
	const app=VFACT.app;
	let dlgVO=null;
	let chatResult=null;
	let chatCnt=0;
	/*}#1HA4CQ2RT1LocalVals*/
	
	/*#{1HA4CQ2RT1PreState*/
	/*}#1HA4CQ2RT1PreState*/
	/*#{1HA4CQ2RT1PostState*/
	/*}#1HA4CQ2RT1PostState*/
	cssVO={
		"hash":"1HA4CQ2RT1",nameHost:true,
		"type":"hud","id":"DlgAIChat","x":"50%","y":"50%","w":"90%","h":"","anchorX":1,"anchorY":1,"padding":[10,10,10,10],"minW":320,"minH":"","maxW":800,"maxH":"",
		"styleClass":"","contentLayout":"flex-y",
		children:[
			{
				"hash":"1HA4D73LO0",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["body"],
				"border":1,"borderColor":cfgColor["lineBodySub"],"corner":6,"shadow":true,"shadowY":6,"shadowBlur":8,"shadowColor":[0,0,0,0.3],
			},
			{
				"hash":"1HA4DB93M0",
				"type":"text","id":"TxtTitle","position":"relative","x":0,"y":0,"w":"100%","h":30,"uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"color":cfgColor["fontBodySub"],"text":(title||botName)+" (working...)","fontSize":txtSize.big,"fontWeight":"bold","fontStyle":"normal","textDecoration":"",
				"alignV":1,
			},
			{
				"hash":"1HA51LIVU0",
				"type":BoxAIChat(),"id":"BoxChats","position":"relative","x":0,"y":0,"w":"100%","h":"","minH":20,"maxH":380,"overflow":"auto-y",
			},
			{
				"hash":"1HA539OJ20",
				"type":"box","id":"BoxUser","position":"relative","x":"50%","y":0,"w":">calc(100% - 50px)","h":"","anchorX":1,"minW":"","minH":30,"maxW":"","maxH":"",
				"styleClass":"","background":[255,255,255,1],"corner":3,"shadow":true,"shadowX":0,"shadowY":1,"shadowBlur":4,"shadowColor":[0,0,0,0.3],"contentLayout":"flex-y",
				children:[
					{
						"hash":"1HA5C6UEO0",
						"type":"hud","id":"BoxInput","position":"relative","x":0,"y":0,"w":"100%","h":"","padding":[5,10,5,10],"minW":"","minH":20,"maxW":"","maxH":"","styleClass":"",
						"contentLayout":"flex-x","traceSize":true,"itemsAlign":1,"subAlign":1,"itemsWrap":1,
						children:[
							{
								"hash":"1HAT6T5R40",
								"type":BtnText("primary",100,25,"Close",false,""),"position":"relative","x":0,"y":0,"margin":[0,20,0,0],
								"OnClick":function(event){
									/*#{1HAT9SIKO0FunctionBody*/
									app.closeDlg(self,chatResult);
									/*}#1HAT9SIKO0FunctionBody*/
								},
							},
							{
								"hash":"1HAT6UNGU0",
								"type":BtnText("warning",100,25,"Regenerate",false,""),"position":"relative","x":0,"y":0,
								"OnClick":function(event){
									/*#{1HAT9QFSD0FunctionBody*/
									chatCnt=0;
									self.sendChat(dlgVO.prompt);
									/*}#1HAT9QFSD0FunctionBody*/
								},
							}
						],
					},
					{
						"hash":"1HA5CRLRB0",
						"type":"hud","id":"BoxWait","position":"relative","x":0,"y":0,"w":"100%","h":50,"display":0,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						children:[
							{
								"hash":"1HA5CSM2L0",
								"type":"text","x":0,"y":0,"w":"100%","h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodyLit"],"text":"AI is thinking...",
								"fontSize":txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignH":1,"alignV":1,
							},
							{
								"hash":"1HA5CV4FU0",
								"type":BtnText("primary",100,25,"Abort",false,""),"id":"BtnAbort","x":"50%","y":20,"anchorX":1,
								"OnClick":function(event){
									/*#{1HA7BN1640FunctionBody*/
									self.abortChat();
									/*}#1HA7BN1640FunctionBody*/
								},
							}
						],
					}
				],
			}
		],
		/*#{1HA4CQ2RT1ExtraCSS*/
		/*}#1HA4CQ2RT1ExtraCSS*/
		faces:{
			"start":{
				/*TxtTitle*/"#1HA4DB93M0":{
					"text":$P(()=>((title||botName)+" (working...)"))
				},
				/*BoxInput*/"#1HA5C6UEO0":{
					"display":0
				}
			},"done":{
				/*TxtTitle*/"#1HA4DB93M0":{
					"text":$P(()=>(title||botName))
				},
				/*BoxInput*/"#1HA5C6UEO0":{
					"display":1
				},
				/*BoxWait*/"#1HA5CRLRB0":{
					"display":0
				}
			},"wait":{
				/*TxtTitle*/"#1HA4DB93M0":{
					"text":$P(()=>((title||botName)+" (working...)"))
				},
				/*BoxInput*/"#1HA5C6UEO0":{
					"display":0
				},
				/*BoxWait*/"#1HA5CRLRB0":{
					"display":1
				}
			},"mobile":{
			},"desktop":{
			},"abort":{
				/*TxtTitle*/"#1HA4DB93M0":{
					"text":$P(()=>((title||botName)+" (aborted)"))
				},
				/*BoxInput*/"#1HA5C6UEO0":{
					"display":1
				},
				/*BoxWait*/"#1HA5CRLRB0":{
					"display":0
				}
			}
		},
		OnCreate:function(){
			self=this;
			boxBG=self.BoxBG;txtTitle=self.TxtTitle;boxChats=self.BoxChats;boxUser=self.BoxUser;
			/*#{1HA4CQ2RT1Create*/
			//ApplyMove:
			VFACT.applyMoveDrag(boxBG,self);
			//Init blocks:
			boxChats.initBlockDef({
				"user":(session,blockVO)=>{
					return BoxAIChatBlock({
						icon:appCfg.sharedAssets+"/user.svg",iconBG:cfgColor.success,iconColor:cfgColor.fontPrimary,
						bgColor:cfgColor.body,textColor:cfgColor.fontBody,text:blockVO.text||blockVO.content,buttons:false,top:blockVO.top
					},session);
				},
				"greeting":(session,blockVO)=>{
					return BoxAIChatBlock({
						icon:appCfg.sharedAssets+"/faces.svg",iconBG:cfgColor.warning,iconColor:cfgColor.fontPrimary,
						bgColor:cfgColor.body,textColor:cfgColor.fontBody,text:blockVO.text||blockVO.content,buttons:false,top:blockVO.top
					},session);
				},
				"assistant":(session,blockVO)=>{
					return BoxAIChatBlock({
						icon:appCfg.sharedAssets+"/faces.svg",iconBG:cfgColor.warning,iconColor:cfgColor.fontPrimary,
						bgColor:cfgColor.body,textColor:cfgColor.fontBody,text:blockVO.text||blockVO.content,buttons:true,top:blockVO.top,
						render:true
					},session);
				},
				"wait":(session,blockVO)=>{
					return BoxAIChatBlock({
						icon:appCfg.sharedAssets+"/wait.svg",iconBG:cfgColor.secondary,iconColor:cfgColor.fontPrimary,
						bgColor:cfgColor.body,textColor:cfgColor.fontBody,text:blockVO.text||blockVO.content,buttons:false,top:blockVO.top
					},session);
				},
				"event":(session,blockVO)=>{
					return BoxAIChatBlock({
						icon:appCfg.sharedAssets+"/event.svg",iconBG:cfgColor.warning,iconColor:cfgColor.fontPrimary,
						bgColor:cfgColor.body,textColor:cfgColor.fontBody,text:blockVO.text||blockVO.content,buttons:false,top:blockVO.top
					},session);
				},
				"error":(session,blockVO)=>{
					return BoxAIChatBlock({
						icon:appCfg.sharedAssets+"/fat_right.svg",iconBG:cfgColor.error,iconColor:cfgColor.fontPrimary,
						bgColor:cfgColor.body,textColor:cfgColor.fontBody,text:blockVO.text||blockVO.content,buttons:false,top:blockVO.top
					},session);
				},
			},{
				"input":(session,blockVO)=>{
					return BoxAskUser(blockVO,session);
				},
				"confirm":(session,blockVO)=>{
					return BoxAskUser(blockVO,session);
				},
				"menu":(session,blockVO)=>{
					return BoxAskUser(blockVO,session);
				},
				"range":(session,blockVO)=>{
					return null;
				},
			});
			//
			boxChats.checkChatBlock=(blockVO)=>{
				chatCnt++;
				if(chatCnt===1){
					return false;//Ignore first user prompt.
				}
				return true;
			};
			/*}#1HA4CQ2RT1Create*/
		},
		/*#{1HA4CQ2RT1EndCSS*/
		/*}#1HA4CQ2RT1EndCSS*/
	};
	/*#{1HA4CQ2RT1PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.showDlg=function(vo){
		dlgVO=vo;
		chatCnt=0;
		title=dlgVO.title||null;
		boxChats.clearChats();
		if(self.w<500){
			self.showFace("mobile");
		}else{
			self.showFace("desktop");
		}
		self.showFace("start");
		tabNT.checkLogin(false).then(async (logined)=>{
			let bot;
			if(!logined){
				let res=await tabNT.makeCall("checkAICallStatus",{},5000);
				if(res.code!==200){
					let rootApp;
					rootApp=app.appFrame?app.appFrame.app:app;
					if(!(await rootApp.modalDlg(DlgLogin,{x:rootApp.width/2,y:100,alignH:1}))){
						app.closeDlg(self);
						return;
					}
					await tabNT.checkLogin(false);
				}
			}
			await boxChats.initSession(vo.bot||vo.url);
			bot=boxChats.entryBot;
			if(bot){
				botName=bot.name||"AI";
				self.sendChat(vo.prompt);
			}
		});
	};
	
	//------------------------------------------------------------------------
	cssVO.sendChat=async function(text){
		if(!text)
			return;
		chatResult=null;
		self.showFace("wait");
		try{
			chatResult=await boxChats.execChat(null,text);
		}catch(err){
		}
		if(dlgVO.waitClose){
			self.showFace("done");
		}else{
			app.closeDlg(self,chatResult);
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.abortChat=async function(){
		await boxChats.abortChat();
		chatResult=null;
		self.showFace("abort");
	};
	/*}#1HA4CQ2RT1PostCSSVO*/
	return cssVO;
};
/*#{1HA4CQ2RT1ExCodes*/
/*}#1HA4CQ2RT1ExCodes*/


export default DlgAIWork;
export{DlgAIWork};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1HAT6MSEI0",
//	"editVersion": 56,
//	"attrs": {
//		"editEnv": {
//			"type": "object",
//			"jaxId": "1HA4CQ2RU0",
//			"editVersion": 22,
//			"attrs": {
//				"device": "Desktop 800x600",
//				"screenW": "800",
//				"screenH": "600",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"type": "object",
//			"jaxId": "1HA4CQ2RU1",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"model": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1HA4CQ2RU2",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"createArgs": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1HA4CQ2RU3",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"localVars": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1HA4CQ2RU4",
//			"editVersion": 12,
//			"attrs": {
//				"botName": {
//					"type": "string",
//					"valText": "AI"
//				},
//				"title": {
//					"type": "string",
//					"valText": ""
//				}
//			}
//		},
//		"oneHud": "false",
//		"state": {
//			"type": "object",
//			"def": "StateObj",
//			"jaxId": "1HA4CQ2RU5",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"type": "object",
//			"def": "FaceTags",
//			"jaxId": "1HA4CQ2RU6",
//			"editVersion": 22,
//			"attrs": {
//				"start": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HAJJLQL80",
//					"editVersion": 16,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1HAJJNKNF0",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"done": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HA5D430C0",
//					"editVersion": 18,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1HA5DK4IS0",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"wait": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HA5D4BEQ0",
//					"editVersion": 16,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1HA5DK4IS1",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"mobile": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HA5I24TH0",
//					"editVersion": 16,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1HA5I33500",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"desktop": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HA5I2GNK0",
//					"editVersion": 16,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1HA5I33501",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"abort": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HAT9N7KE0",
//					"editVersion": 16,
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"type": "object",
//							"jaxId": "1HAT9O5HI0",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"type": "object",
//			"def": "MockupObj",
//			"jaxId": "1HAAN550J0",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1HA4CQ2RT1",
//			"editVersion": 38,
//			"attrs": {
//				"properties": {
//					"type": "object",
//					"jaxId": "1HA4CQ2RU7",
//					"editVersion": 148,
//					"attrs": {
//						"type": "hud",
//						"id": "DlgAIChat",
//						"position": "Absolute",
//						"x": "50%",
//						"y": "50%",
//						"w": "90%",
//						"h": "",
//						"anchorH": "Center",
//						"anchorV": "Center",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "[10,10,10,10]",
//						"minW": "320",
//						"minH": "",
//						"maxW": "800",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Flex Y"
//					}
//				},
//				"subHuds": {
//					"type": "array",
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1HA4D73LO0",
//							"editVersion": 57,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1HA4DON240",
//									"editVersion": 138,
//									"attrs": {
//										"type": "box",
//										"id": "BoxBG",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"body\"]",
//										"border": "1",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor[\"lineBodySub\"]",
//										"corner": "6",
//										"shadow": "true",
//										"shadowX": "2",
//										"shadowY": "6",
//										"shadowBlur": "8",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.30]"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1HA4DON241",
//									"editVersion": 56,
//									"attrs": {
//										"1HA5I2GNK0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HA5I33504",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HA5I33505",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HA5I2GNK0",
//											"faceTagName": "desktop"
//										},
//										"1HA5D4BEQ0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HAT9O5HI1",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HAT9O5HI2",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HA5D4BEQ0",
//											"faceTagName": "wait"
//										},
//										"1HA5D430C0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HATHCP5Q2",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HATHCP5Q3",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HA5D430C0",
//											"faceTagName": "done"
//										},
//										"1HAJJLQL80": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HATHKTUO0",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HATHKTUO1",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HAJJLQL80",
//											"faceTagName": "start"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1HA4DON242",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1HA4DON243",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "true",
//								"container": "false",
//								"nameVal": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1HA4DB93M0",
//							"editVersion": 87,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1HA4DON244",
//									"editVersion": 170,
//									"attrs": {
//										"type": "text",
//										"id": "TxtTitle",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#cfgColor[\"fontBodySub\"]",
//										"text": "#(title||botName)+\" (working...)\"",
//										"font": "",
//										"fontSize": "#txtSize.big",
//										"bold": "true",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Center",
//										"wrap": "false",
//										"ellipsis": "false",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1HA4DON245",
//									"editVersion": 38,
//									"attrs": {
//										"1HA5I2GNK0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HA5I33508",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HA5I33509",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HA5I2GNK0",
//											"faceTagName": "desktop"
//										},
//										"1HAJJLQL80": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HAJJNKNF3",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HAJJNKNF4",
//													"editVersion": 16,
//													"attrs": {
//														"text": {
//															"type": "string",
//															"valText": "${(title||botName)+\" (working...)\"}",
//															"localizable": true
//														}
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HAJJLQL80",
//											"faceTagName": "start"
//										},
//										"1HA5D4BEQ0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HAT9O5HI5",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HAT9O5HI6",
//													"editVersion": 16,
//													"attrs": {
//														"text": {
//															"type": "string",
//															"valText": "${(title||botName)+\" (working...)\"}",
//															"localizable": true
//														}
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HA5D4BEQ0",
//											"faceTagName": "wait"
//										},
//										"1HA5D430C0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HAT9O5HI7",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HAT9O5HI8",
//													"editVersion": 20,
//													"attrs": {
//														"text": {
//															"type": "string",
//															"valText": "${title||botName}",
//															"localizable": true
//														}
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HA5D430C0",
//											"faceTagName": "done"
//										},
//										"1HAT9N7KE0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HAT9O5HI9",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HAT9O5HI10",
//													"editVersion": 22,
//													"attrs": {
//														"text": {
//															"type": "string",
//															"valText": "${(title||botName)+\" (aborted)\"}",
//															"localizable": true
//														}
//													}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HAT9N7KE0",
//											"faceTagName": "abort"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1HA4DON246",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1HA4DON247",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear1HA0EN6720",
//							"jaxId": "1HA51LIVU0",
//							"editVersion": 57,
//							"attrs": {
//								"createArgs": {
//									"type": "object",
//									"def": "gearCrateArgs",
//									"jaxId": "1HA53D8VE0",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"properties": {
//									"type": "object",
//									"jaxId": "1HA53D8VE1",
//									"editVersion": 98,
//									"attrs": {
//										"type": "#null#>BoxAIChat()",
//										"id": "BoxChats",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"display": "On",
//										"face": "",
//										"w": "100%",
//										"h": "",
//										"minH": "20",
//										"maxH": "380",
//										"clip": "Auto Scroll Y"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1HA53D8VE2",
//									"editVersion": 56,
//									"attrs": {
//										"1HA5I2GNK0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HA5I335032",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HA5I335033",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HA5I2GNK0",
//											"faceTagName": "desktop"
//										},
//										"1HA5D4BEQ0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HAT9O5HI17",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HAT9O5HI18",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HA5D4BEQ0",
//											"faceTagName": "wait"
//										},
//										"1HA5D430C0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HATHCP5Q6",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HATHCP5Q7",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HA5D430C0",
//											"faceTagName": "done"
//										},
//										"1HAJJLQL80": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HATHKTUO2",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HATHKTUO3",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HAJJLQL80",
//											"faceTagName": "start"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1HA53D8VE3",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1HA53D8VE4",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true",
//								"containerSlots": {
//									"type": "object",
//									"jaxId": "1HA53D8VE5",
//									"editVersion": 0,
//									"attrs": {}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1HA539OJ20",
//							"editVersion": 55,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1HA53D8VE6",
//									"editVersion": 206,
//									"attrs": {
//										"type": "box",
//										"id": "BoxUser",
//										"position": "relative",
//										"x": "50%",
//										"y": "0",
//										"w": "100%-50",
//										"h": "",
//										"anchorH": "Center",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "30",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "[255,255,255,1.00]",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "3",
//										"shadow": "true",
//										"shadowX": "0",
//										"shadowY": "1",
//										"shadowBlur": "4",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.30]",
//										"contentLayout": "Flex Y"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1HA5C6UEO0",
//											"editVersion": 46,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HA5CQ5QV0",
//													"editVersion": 142,
//													"attrs": {
//														"type": "hud",
//														"id": "BoxInput",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "[5,10,5,10]",
//														"minW": "",
//														"minH": "20",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex X",
//														"traceSize": "true",
//														"itemsAlign": "Center",
//														"subAlign": "Center",
//														"itemsWrap": "Wrap"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnText.js",
//															"jaxId": "1HAT6T5R40",
//															"editVersion": 34,
//															"attrs": {
//																"createArgs": {
//																	"type": "object",
//																	"def": "gearCrateArgs",
//																	"jaxId": "1HAT6UKLH0",
//																	"editVersion": 24,
//																	"attrs": {
//																		"style": "primary",
//																		"w": "100",
//																		"h": "25",
//																		"text": "Close",
//																		"outlined": "false",
//																		"icon": ""
//																	}
//																},
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HAT6UKLH1",
//																	"editVersion": 38,
//																	"attrs": {
//																		"type": "#null#>BtnText(\"primary\",100,25,\"Close\",false,\"\")",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"margin": "[0,20,0,0]"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HAT6UKLI0",
//																	"editVersion": 26,
//																	"attrs": {
//																		"1HA5D4BEQ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAT9O5HI23",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAT9O5HI24",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HA5D4BEQ0",
//																			"faceTagName": "wait"
//																		},
//																		"1HA5D430C0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HATHCP5Q10",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HATHCP5Q11",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HA5D430C0",
//																			"faceTagName": "done"
//																		},
//																		"1HAJJLQL80": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HATHKTUO4",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HATHKTUO5",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAJJLQL80",
//																			"faceTagName": "start"
//																		}
//																	}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HAT6UKLI1",
//																	"editVersion": 2,
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HAT9SIKO0",
//																			"editVersion": 2,
//																			"attrs": {
//																				"callArgs": {
//																					"type": "object",
//																					"jaxId": "1HAT9SOVE0",
//																					"editVersion": 2,
//																					"attrs": {
//																						"event": ""
//																					}
//																				}
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HAT6UKLI2",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"type": "object",
//																	"jaxId": "1HAT6UKLI3",
//																	"editVersion": 2,
//																	"attrs": {
//																		"Slot1H2F6U36O0": {
//																			"type": "gearcontainer",
//																			"jaxId": "1HAT6UKLI4",
//																			"editVersion": 4,
//																			"attrs": {
//																				"subHuds": {
//																					"type": "array",
//																					"attrs": []
//																				},
//																				"container": "true"
//																			}
//																		}
//																	}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnText.js",
//															"jaxId": "1HAT6UNGU0",
//															"editVersion": 37,
//															"attrs": {
//																"createArgs": {
//																	"type": "object",
//																	"def": "gearCrateArgs",
//																	"jaxId": "1HAT6UNGU1",
//																	"editVersion": 36,
//																	"attrs": {
//																		"style": "warning",
//																		"w": "100",
//																		"h": "25",
//																		"text": "Regenerate",
//																		"outlined": "false",
//																		"icon": ""
//																	}
//																},
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HAT6UNGU2",
//																	"editVersion": 33,
//																	"attrs": {
//																		"type": "#null#>BtnText(\"warning\",100,25,\"Regenerate\",false,\"\")",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": ""
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HAT6UNGU3",
//																	"editVersion": 26,
//																	"attrs": {
//																		"1HA5D4BEQ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAT9O5HJ2",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAT9O5HJ3",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HA5D4BEQ0",
//																			"faceTagName": "wait"
//																		},
//																		"1HA5D430C0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HATHCP5Q14",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HATHCP5Q15",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HA5D430C0",
//																			"faceTagName": "done"
//																		},
//																		"1HAJJLQL80": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HATHKTUO6",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HATHKTUO7",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAJJLQL80",
//																			"faceTagName": "start"
//																		}
//																	}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HAT6UNGU4",
//																	"editVersion": 2,
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HAT9QFSD0",
//																			"editVersion": 2,
//																			"attrs": {
//																				"callArgs": {
//																					"type": "object",
//																					"jaxId": "1HAT9R4AM0",
//																					"editVersion": 2,
//																					"attrs": {
//																						"event": ""
//																					}
//																				}
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HAT6UNGU5",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"type": "object",
//																	"jaxId": "1HAT6UNGU6",
//																	"editVersion": 2,
//																	"attrs": {
//																		"Slot1H2F6U36O0": {
//																			"type": "gearcontainer",
//																			"jaxId": "1HAT6UNGU7",
//																			"editVersion": 4,
//																			"attrs": {
//																				"subHuds": {
//																					"type": "array",
//																					"attrs": []
//																				},
//																				"container": "true"
//																			}
//																		}
//																	}
//																}
//															}
//														}
//													]
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1HA5CQ5QV15",
//													"editVersion": 18,
//													"attrs": {
//														"1HA5D430C0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HA5DK4IS24",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HA5DK4IS25",
//																	"editVersion": 4,
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HA5D430C0",
//															"faceTagName": "done"
//														},
//														"1HA5D4BEQ0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HA5DK4IS26",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HA5DK4IS27",
//																	"editVersion": 4,
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HA5D4BEQ0",
//															"faceTagName": "wait"
//														},
//														"1HA5I2GNK0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HA5I335048",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HA5I335049",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HA5I2GNK0",
//															"faceTagName": "desktop"
//														},
//														"1HAJJLQL80": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAJJNKNG16",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HAJJNKNG17",
//																	"editVersion": 4,
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAJJLQL80",
//															"faceTagName": "start"
//														},
//														"1HAT9N7KE0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAT9O5HJ6",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HAT9O5HJ7",
//																	"editVersion": 4,
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAT9N7KE0",
//															"faceTagName": "abort"
//														}
//													}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1HA5CQ5QV16",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1HA5CQ5QV17",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1HA5CRLRB0",
//											"editVersion": 41,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HA5D3IKV0",
//													"editVersion": 84,
//													"attrs": {
//														"type": "hud",
//														"id": "BoxWait",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "50",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "Off",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": ""
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1HA5CSM2L0",
//															"editVersion": 20,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HA5D3IKV1",
//																	"editVersion": 134,
//																	"attrs": {
//																		"type": "text",
//																		"id": "",
//																		"position": "Absolute",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "20",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontBodyLit\"]",
//																		"text": "AI is thinking...",
//																		"font": "",
//																		"fontSize": "#txtSize.smallPlus",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Center",
//																		"alignV": "Center",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HA5D3IKV2",
//																	"editVersion": 56,
//																	"attrs": {
//																		"1HA5I2GNK0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HA5I335052",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HA5I335053",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HA5I2GNK0",
//																			"faceTagName": "desktop"
//																		},
//																		"1HA5D4BEQ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAT9O5HJ8",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAT9O5HJ9",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HA5D4BEQ0",
//																			"faceTagName": "wait"
//																		},
//																		"1HA5D430C0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HATHCP5Q18",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HATHCP5Q19",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HA5D430C0",
//																			"faceTagName": "done"
//																		},
//																		"1HAJJLQL80": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HATHKTUO8",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HATHKTUO9",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAJJLQL80",
//																			"faceTagName": "start"
//																		}
//																	}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HA5D3IKV3",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HA5D3IKV4",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnText.js",
//															"jaxId": "1HA5CV4FU0",
//															"editVersion": 62,
//															"attrs": {
//																"createArgs": {
//																	"type": "object",
//																	"def": "gearCrateArgs",
//																	"jaxId": "1HA5D3IKV5",
//																	"editVersion": 66,
//																	"attrs": {
//																		"style": "primary",
//																		"w": "100",
//																		"h": "25",
//																		"text": "Abort",
//																		"outlined": "false",
//																		"icon": ""
//																	}
//																},
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HA5D3IKV6",
//																	"editVersion": 58,
//																	"attrs": {
//																		"type": "#null#>BtnText(\"primary\",100,25,\"Abort\",false,\"\")",
//																		"id": "BtnAbort",
//																		"position": "Absolute",
//																		"x": "50%",
//																		"y": "20",
//																		"display": "On",
//																		"face": "",
//																		"anchorH": "Center"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HA5D3IKV7",
//																	"editVersion": 56,
//																	"attrs": {
//																		"1HA5I2GNK0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HA5I335056",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HA5I335057",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HA5I2GNK0",
//																			"faceTagName": "desktop"
//																		},
//																		"1HA5D4BEQ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAT9O5HJ12",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HAT9O5HJ13",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HA5D4BEQ0",
//																			"faceTagName": "wait"
//																		},
//																		"1HA5D430C0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HATHCP5Q22",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HATHCP5Q23",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HA5D430C0",
//																			"faceTagName": "done"
//																		},
//																		"1HAJJLQL80": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HATHKTUO10",
//																			"editVersion": 4,
//																			"attrs": {
//																				"properties": {
//																					"type": "object",
//																					"jaxId": "1HATHKTUO11",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"type": "array",
//																					"def": "Array",
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAJJLQL80",
//																			"faceTagName": "start"
//																		}
//																	}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HA5D3IKV8",
//																	"editVersion": 2,
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HA7BN1640",
//																			"editVersion": 2,
//																			"attrs": {
//																				"callArgs": {
//																					"type": "object",
//																					"jaxId": "1HA7BOS360",
//																					"editVersion": 2,
//																					"attrs": {
//																						"event": ""
//																					}
//																				}
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HA5D3IKV9",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"type": "object",
//																	"jaxId": "1HA5D3IKV10",
//																	"editVersion": 2,
//																	"attrs": {
//																		"Slot1H2F6U36O0": {
//																			"type": "gearcontainer",
//																			"jaxId": "1HA5D3IKV11",
//																			"editVersion": 4,
//																			"attrs": {
//																				"subHuds": {
//																					"type": "array",
//																					"attrs": []
//																				},
//																				"container": "true"
//																			}
//																		}
//																	}
//																}
//															}
//														}
//													]
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1HA5D3IKV12",
//													"editVersion": 22,
//													"attrs": {
//														"1HA5D430C0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HA5DK4IS32",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HA5DK4IS33",
//																	"editVersion": 4,
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HA5D430C0",
//															"faceTagName": "done"
//														},
//														"1HA5D4BEQ0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HA5DK4IS34",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HA5DK4IS35",
//																	"editVersion": 4,
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HA5D4BEQ0",
//															"faceTagName": "wait"
//														},
//														"1HA5I2GNK0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HA5I335060",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HA5I335061",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HA5I2GNK0",
//															"faceTagName": "desktop"
//														},
//														"1HAT9N7KE0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAT9O5HJ16",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HAT9O5HJ17",
//																	"editVersion": 4,
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAT9N7KE0",
//															"faceTagName": "abort"
//														},
//														"1HAJJLQL80": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HATHKTUO12",
//															"editVersion": 4,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HATHKTUO13",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"anis": {
//																	"type": "array",
//																	"def": "Array",
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAJJLQL80",
//															"faceTagName": "start"
//														}
//													}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1HA5D3IKV13",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1HA5D3IKV14",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1HA53D8VE7",
//									"editVersion": 56,
//									"attrs": {
//										"1HA5I2GNK0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HA5I335064",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HA5I335065",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HA5I2GNK0",
//											"faceTagName": "desktop"
//										},
//										"1HA5D4BEQ0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HAT9O5HJ18",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HAT9O5HJ19",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HA5D4BEQ0",
//											"faceTagName": "wait"
//										},
//										"1HA5D430C0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HATHCP5Q26",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HATHCP5Q27",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HA5D430C0",
//											"faceTagName": "done"
//										},
//										"1HAJJLQL80": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HATHKTUO14",
//											"editVersion": 4,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HATHKTUO15",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"anis": {
//													"type": "array",
//													"def": "Array",
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HAJJLQL80",
//											"faceTagName": "start"
//										}
//									}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1HA53D8VE8",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1HA53D8VE9",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true"
//							}
//						}
//					]
//				},
//				"faces": {
//					"type": "object",
//					"jaxId": "1HA4CQ2RU8",
//					"editVersion": 56,
//					"attrs": {
//						"1HA5I2GNK0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HA5I335068",
//							"editVersion": 4,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1HA5I335069",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"anis": {
//									"type": "array",
//									"def": "Array",
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HA5I2GNK0",
//							"faceTagName": "desktop"
//						},
//						"1HA5D4BEQ0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HAT9O5HJ22",
//							"editVersion": 4,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1HAT9O5HJ23",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"anis": {
//									"type": "array",
//									"def": "Array",
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HA5D4BEQ0",
//							"faceTagName": "wait"
//						},
//						"1HA5D430C0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HATHCP5Q30",
//							"editVersion": 4,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1HATHCP5Q31",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"anis": {
//									"type": "array",
//									"def": "Array",
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HA5D430C0",
//							"faceTagName": "done"
//						},
//						"1HAJJLQL80": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HATHKTUO16",
//							"editVersion": 4,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1HATHKTUO17",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"anis": {
//									"type": "array",
//									"def": "Array",
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HAJJLQL80",
//							"faceTagName": "start"
//						}
//					}
//				},
//				"functions": {
//					"type": "object",
//					"jaxId": "1HA4CQ2RU9",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"extraPpts": {
//					"type": "object",
//					"def": "Object",
//					"jaxId": "1HA4CQ2RU10",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "true",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1HA4CQ2RU11",
//			"editVersion": 64,
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}