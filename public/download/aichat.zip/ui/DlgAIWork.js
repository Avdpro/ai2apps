//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BoxAIChat} from "./BoxAIChat.js";
import {BtnText} from "/@StdUI/ui/BtnText.js";
/*#{1HAT6MSEI0StartDoc*/
import {tabNT} from "/@tabos/tabos_nt.js";
import {DlgLogin} from "/@homekit/ui/DlgLogin.js";
import {BoxAIChatBlock} from "./BoxAIChatBlock.js";
import {BoxAskUser} from "./BoxAskUser.js";
/*}#1HAT6MSEI0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let DlgAIWork=function(){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let boxBG,txtTitle,boxChats,boxUser;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let botName="AI";
	let title="";
	
	/*#{1HA4CQ2RT1LocalVals*/
	const app=VFACT.app;
	let dlgVO=null;
	let chatResult=null;
	let chatCnt=0;
	/*}#1HA4CQ2RT1LocalVals*/
	
	/*#{1HA4CQ2RT1PreState*/
	/*}#1HA4CQ2RT1PreState*/
	/*#{1HA4CQ2RT1PostState*/
	/*}#1HA4CQ2RT1PostState*/
	cssVO={
		"hash":"1HA4CQ2RT1",nameHost:true,
		"type":"hud","id":"DlgAIChat","x":"50%","y":"50%","w":"90%","h":"","anchorX":1,"anchorY":1,"padding":[10,10,10,10],"minW":320,"minH":"","maxW":800,"maxH":"",
		"styleClass":"","contentLayout":"flex-y",
		children:[
			{
				"hash":"1HA4D73LO0",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["body"],
				"border":1,"borderColor":cfgColor["lineBodySub"],"corner":6,"shadow":true,"shadowY":6,"shadowBlur":8,"shadowColor":[0,0,0,0.3],
			},
			{
				"hash":"1HA4DB93M0",
				"type":"text","id":"TxtTitle","position":"relative","x":0,"y":0,"w":"100%","h":30,"uiEvent":-1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"color":cfgColor["fontBodySub"],"text":(title||botName)+" (working...)","fontSize":txtSize.big,"fontWeight":"bold","fontStyle":"normal","textDecoration":"",
				"alignV":1,
			},
			{
				"hash":"1HA51LIVU0",
				"type":BoxAIChat(),"id":"BoxChats","position":"relative","x":0,"y":0,"w":"100%","h":"","minH":20,"maxH":380,"overflow":"auto-y",
			},
			{
				"hash":"1HA539OJ20",
				"type":"box","id":"BoxUser","position":"relative","x":"50%","y":0,"w":">calc(100% - 50px)","h":"","anchorX":1,"minW":"","minH":30,"maxW":"","maxH":"",
				"styleClass":"","background":[255,255,255,1],"corner":3,"shadow":true,"shadowX":0,"shadowY":1,"shadowBlur":4,"shadowColor":[0,0,0,0.3],"contentLayout":"flex-y",
				children:[
					{
						"hash":"1HA5C6UEO0",
						"type":"hud","id":"BoxInput","position":"relative","x":0,"y":0,"w":"100%","h":"","padding":[5,10,5,10],"minW":"","minH":20,"maxW":"","maxH":"","styleClass":"",
						"contentLayout":"flex-x","traceSize":true,"itemsAlign":1,"subAlign":1,"itemsWrap":1,
						children:[
							{
								"hash":"1HAT6T5R40",
								"type":BtnText("primary",100,25,"Close",false,""),"position":"relative","x":0,"y":0,"margin":[0,20,0,0],
								"OnClick":function(event){
									/*#{1HAT9SIKO0FunctionBody*/
									app.closeDlg(self,chatResult);
									/*}#1HAT9SIKO0FunctionBody*/
								},
							},
							{
								"hash":"1HAT6UNGU0",
								"type":BtnText("warning",100,25,"Regenerate",false,""),"position":"relative","x":0,"y":0,
								"OnClick":function(event){
									/*#{1HAT9QFSD0FunctionBody*/
									chatCnt=0;
									self.sendChat(dlgVO.prompt);
									/*}#1HAT9QFSD0FunctionBody*/
								},
							}
						],
					},
					{
						"hash":"1HA5CRLRB0",
						"type":"hud","id":"BoxWait","position":"relative","x":0,"y":0,"w":"100%","h":50,"display":0,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
						children:[
							{
								"hash":"1HA5CSM2L0",
								"type":"text","x":0,"y":0,"w":"100%","h":20,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodyLit"],"text":"AI is thinking...",
								"fontSize":txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","alignH":1,"alignV":1,
							},
							{
								"hash":"1HA5CV4FU0",
								"type":BtnText("primary",100,25,"Abort",false,""),"id":"BtnAbort","x":"50%","y":20,"anchorX":1,
								"OnClick":function(event){
									/*#{1HA7BN1640FunctionBody*/
									self.abortChat();
									/*}#1HA7BN1640FunctionBody*/
								},
							}
						],
					}
				],
			}
		],
		/*#{1HA4CQ2RT1ExtraCSS*/
		/*}#1HA4CQ2RT1ExtraCSS*/
		faces:{
			"start":{
				/*TxtTitle*/"#1HA4DB93M0":{
					"text":$P(()=>((title||botName)+" (working...)"))
				},
				/*BoxInput*/"#1HA5C6UEO0":{
					"display":0
				}
			},"done":{
				/*TxtTitle*/"#1HA4DB93M0":{
					"text":$P(()=>(title||botName))
				},
				/*BoxInput*/"#1HA5C6UEO0":{
					"display":1
				},
				/*BoxWait*/"#1HA5CRLRB0":{
					"display":0
				}
			},"wait":{
				/*TxtTitle*/"#1HA4DB93M0":{
					"text":$P(()=>((title||botName)+" (working...)"))
				},
				/*BoxInput*/"#1HA5C6UEO0":{
					"display":0
				},
				/*BoxWait*/"#1HA5CRLRB0":{
					"display":1
				}
			},"mobile":{
			},"desktop":{
			},"abort":{
				/*TxtTitle*/"#1HA4DB93M0":{
					"text":$P(()=>((title||botName)+" (aborted)"))
				},
				/*BoxInput*/"#1HA5C6UEO0":{
					"display":1
				},
				/*BoxWait*/"#1HA5CRLRB0":{
					"display":0
				}
			}
		},
		OnCreate:function(){
			self=this;
			boxBG=self.BoxBG;txtTitle=self.TxtTitle;boxChats=self.BoxChats;boxUser=self.BoxUser;
			/*#{1HA4CQ2RT1Create*/
			//ApplyMove:
			VFACT.applyMoveDrag(boxBG,self);
			//Init blocks:
			boxChats.initBlockDef({
			},{
			});
			//
			boxChats.checkChatBlock=(blockVO)=>{
				chatCnt++;
				if(chatCnt===1){
					return false;//Ignore first user prompt.
				}
				return true;
			};
			/*}#1HA4CQ2RT1Create*/
		},
		/*#{1HA4CQ2RT1EndCSS*/
		/*}#1HA4CQ2RT1EndCSS*/
	};
	/*#{1HA4CQ2RT1PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.showDlg=function(vo){
		dlgVO=vo;
		chatCnt=0;
		title=dlgVO.title||null;
		boxChats.clearChats();
		if(self.w<500){
			self.showFace("mobile");
		}else{
			self.showFace("desktop");
		}
		self.showFace("start");
		tabNT.checkLogin(false).then(async (logined)=>{
			let bot;
			if(!logined){
				let res=await tabNT.makeCall("checkAICallStatus",{},5000);
				if(res.code!==200){
					let rootApp;
					rootApp=app.appFrame?app.appFrame.app:app;
					if(!(await rootApp.modalDlg(DlgLogin,{x:rootApp.width/2,y:100,alignH:1}))){
						app.closeDlg(self);
						return;
					}
					await tabNT.checkLogin(false);
				}
			}
			try{
				await boxChats.initSession(vo.bot||vo.url);
				bot=boxChats.entryBot;
				if(bot){
					botName=bot.name||"AI";
					self.sendChat(vo.prompt);
				}
			}catch(err){
				console.error(err);
				app.closeDlg(self);
			}
		});
	};
	
	//------------------------------------------------------------------------
	cssVO.sendChat=async function(text){
		if(!text)
			return;
		chatResult=null;
		self.showFace("wait");
		try{
			chatResult=await boxChats.execChat(null,text);
		}catch(err){
		}
		if(dlgVO.waitClose){
			self.showFace("done");
		}else{
			app.closeDlg(self,chatResult);
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.abortChat=async function(){
		await boxChats.abortChat();
		chatResult=null;
		self.showFace("abort");
	};
	/*}#1HA4CQ2RT1PostCSSVO*/
	cssVO.constructor=DlgAIWork;
	return cssVO;
};
/*#{1HA4CQ2RT1ExCodes*/
/*}#1HA4CQ2RT1ExCodes*/

//----------------------------------------------------------------------------
DlgAIWork.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1HA4CQ2RT1PreAISpot*/
	/*}#1HA4CQ2RT1PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1HA4CQ2RT1PostAISpot*/
	/*}#1HA4CQ2RT1PostAISpot*/
	return exposeVO;
};

/*#{1HAT6MSEI0EndDoc*/
/*}#1HAT6MSEI0EndDoc*/

export default DlgAIWork;
export{DlgAIWork};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1HAT6MSEI0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1HA4CQ2RU0",
//			"attrs": {
//				"device": "Desktop 800x600",
//				"screenW": "800",
//				"screenH": "600",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1HA4CQ2RU1",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1HA4CQ2RU2",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1HA4CQ2RU3",
//			"attrs": {}
//		},
//		"localVars": {
//			"jaxId": "1HA4CQ2RU4",
//			"attrs": {
//				"botName": {
//					"type": "string",
//					"valText": "AI"
//				},
//				"title": {
//					"type": "string",
//					"valText": ""
//				}
//			}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1HA4CQ2RU5",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1HA4CQ2RU6",
//			"attrs": {
//				"start": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HAJJLQL80",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HAJJNKNF0",
//							"attrs": {}
//						}
//					}
//				},
//				"done": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HA5D430C0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HA5DK4IS0",
//							"attrs": {}
//						}
//					}
//				},
//				"wait": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HA5D4BEQ0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HA5DK4IS1",
//							"attrs": {}
//						}
//					}
//				},
//				"mobile": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HA5I24TH0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HA5I33500",
//							"attrs": {}
//						}
//					}
//				},
//				"desktop": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HA5I2GNK0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HA5I33501",
//							"attrs": {}
//						}
//					}
//				},
//				"abort": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1HAT9N7KE0",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1HAT9O5HI0",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1HAAN550J0",
//			"attrs": {}
//		},
//		"exposeToAI": "true",
//		"descAI": "",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1HA4CQ2RT1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1HA4CQ2RU7",
//					"attrs": {
//						"type": "hud",
//						"id": "DlgAIChat",
//						"position": "Absolute",
//						"x": "50%",
//						"y": "50%",
//						"w": "90%",
//						"h": "",
//						"anchorH": "Center",
//						"anchorV": "Center",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "[10,10,10,10]",
//						"minW": "320",
//						"minH": "",
//						"maxW": "800",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Flex Y"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1HA4D73LO0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HA4DON240",
//									"attrs": {
//										"type": "box",
//										"id": "BoxBG",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"body\"]",
//										"border": "1",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor[\"lineBodySub\"]",
//										"corner": "6",
//										"shadow": "true",
//										"shadowX": "2",
//										"shadowY": "6",
//										"shadowBlur": "8",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.30]"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HA4DON241",
//									"attrs": {
//										"1HA5I2GNK0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HA5I33504",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HA5I33505",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HA5I2GNK0",
//											"faceTagName": "desktop"
//										},
//										"1HA5D4BEQ0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HAT9O5HI1",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HAT9O5HI2",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HA5D4BEQ0",
//											"faceTagName": "wait"
//										},
//										"1HA5D430C0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HATHCP5Q2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HATHCP5Q3",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HA5D430C0",
//											"faceTagName": "done"
//										},
//										"1HAJJLQL80": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HATHKTUO0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HATHKTUO1",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HAJJLQL80",
//											"faceTagName": "start"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HA4DON242",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HA4DON243",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "true",
//								"container": "false",
//								"nameVal": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1HA4DB93M0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HA4DON244",
//									"attrs": {
//										"type": "text",
//										"id": "TxtTitle",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "Tree Off",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#cfgColor[\"fontBodySub\"]",
//										"text": "#(title||botName)+\" (working...)\"",
//										"font": "",
//										"fontSize": "#txtSize.big",
//										"bold": "true",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Center",
//										"wrap": "false",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HA4DON245",
//									"attrs": {
//										"1HA5I2GNK0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HA5I33508",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HA5I33509",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HA5I2GNK0",
//											"faceTagName": "desktop"
//										},
//										"1HAJJLQL80": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HAJJNKNF3",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HAJJNKNF4",
//													"attrs": {
//														"text": {
//															"type": "string",
//															"valText": "${(title||botName)+\" (working...)\"}",
//															"localizable": true
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HAJJLQL80",
//											"faceTagName": "start"
//										},
//										"1HA5D4BEQ0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HAT9O5HI5",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HAT9O5HI6",
//													"attrs": {
//														"text": {
//															"type": "string",
//															"valText": "${(title||botName)+\" (working...)\"}",
//															"localizable": true
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HA5D4BEQ0",
//											"faceTagName": "wait"
//										},
//										"1HA5D430C0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HAT9O5HI7",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HAT9O5HI8",
//													"attrs": {
//														"text": {
//															"type": "string",
//															"valText": "${title||botName}",
//															"localizable": true
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HA5D430C0",
//											"faceTagName": "done"
//										},
//										"1HAT9N7KE0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HAT9O5HI9",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HAT9O5HI10",
//													"attrs": {
//														"text": {
//															"type": "string",
//															"valText": "${(title||botName)+\" (aborted)\"}",
//															"localizable": true
//														}
//													}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HAT9N7KE0",
//											"faceTagName": "abort"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HA4DON246",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HA4DON247",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "Gear1HA0EN6720",
//							"jaxId": "1HA51LIVU0",
//							"attrs": {
//								"createArgs": {
//									"jaxId": "1HA53D8VE0",
//									"attrs": {}
//								},
//								"properties": {
//									"jaxId": "1HA53D8VE1",
//									"attrs": {
//										"type": "#null#>BoxAIChat()",
//										"id": "BoxChats",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"display": "On",
//										"face": "",
//										"w": "100%",
//										"h": "",
//										"minH": "20",
//										"maxH": "380",
//										"clip": "Auto Scroll Y"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HA53D8VE2",
//									"attrs": {
//										"1HA5I2GNK0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HA5I335032",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HA5I335033",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HA5I2GNK0",
//											"faceTagName": "desktop"
//										},
//										"1HA5D4BEQ0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HAT9O5HI17",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HAT9O5HI18",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HA5D4BEQ0",
//											"faceTagName": "wait"
//										},
//										"1HA5D430C0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HATHCP5Q6",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HATHCP5Q7",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HA5D430C0",
//											"faceTagName": "done"
//										},
//										"1HAJJLQL80": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HATHKTUO2",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HATHKTUO3",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HAJJLQL80",
//											"faceTagName": "start"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HA53D8VE3",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HA53D8VE4",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true",
//								"containerSlots": {
//									"jaxId": "1HA53D8VE5",
//									"attrs": {}
//								}
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1HA539OJ20",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HA53D8VE6",
//									"attrs": {
//										"type": "box",
//										"id": "BoxUser",
//										"position": "relative",
//										"x": "50%",
//										"y": "0",
//										"w": "100%-50",
//										"h": "",
//										"anchorH": "Center",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "30",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "[255,255,255,1.00]",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "3",
//										"shadow": "true",
//										"shadowX": "0",
//										"shadowY": "1",
//										"shadowBlur": "4",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.30]",
//										"contentLayout": "Flex Y"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1HA5C6UEO0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HA5CQ5QV0",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxInput",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "[5,10,5,10]",
//														"minW": "",
//														"minH": "20",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex X",
//														"traceSize": "true",
//														"itemsAlign": "Center",
//														"subAlign": "Center",
//														"itemsWrap": "Wrap"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnText.js",
//															"jaxId": "1HAT6T5R40",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1HAT6UKLH0",
//																	"attrs": {
//																		"style": "primary",
//																		"w": "100",
//																		"h": "25",
//																		"text": "Close",
//																		"outlined": "false",
//																		"icon": ""
//																	}
//																},
//																"properties": {
//																	"jaxId": "1HAT6UKLH1",
//																	"attrs": {
//																		"type": "#null#>BtnText(\"primary\",100,25,\"Close\",false,\"\")",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"margin": "[0,20,0,0]"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HAT6UKLI0",
//																	"attrs": {
//																		"1HA5D4BEQ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAT9O5HI23",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAT9O5HI24",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HA5D4BEQ0",
//																			"faceTagName": "wait"
//																		},
//																		"1HA5D430C0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HATHCP5Q10",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HATHCP5Q11",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HA5D430C0",
//																			"faceTagName": "done"
//																		},
//																		"1HAJJLQL80": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HATHKTUO4",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HATHKTUO5",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAJJLQL80",
//																			"faceTagName": "start"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HAT6UKLI1",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HAT9SIKO0",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1HAT9SOVE0",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1HAT6UKLI2",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1HAT6UKLI3",
//																	"attrs": {
//																		"Slot1H2F6U36O0": {
//																			"jaxId": "1HAT6UKLI4",
//																			"attrs": {
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"container": "true"
//																			}
//																		}
//																	}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnText.js",
//															"jaxId": "1HAT6UNGU0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1HAT6UNGU1",
//																	"attrs": {
//																		"style": "warning",
//																		"w": "100",
//																		"h": "25",
//																		"text": "Regenerate",
//																		"outlined": "false",
//																		"icon": ""
//																	}
//																},
//																"properties": {
//																	"jaxId": "1HAT6UNGU2",
//																	"attrs": {
//																		"type": "#null#>BtnText(\"warning\",100,25,\"Regenerate\",false,\"\")",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HAT6UNGU3",
//																	"attrs": {
//																		"1HA5D4BEQ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAT9O5HJ2",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAT9O5HJ3",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HA5D4BEQ0",
//																			"faceTagName": "wait"
//																		},
//																		"1HA5D430C0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HATHCP5Q14",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HATHCP5Q15",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HA5D430C0",
//																			"faceTagName": "done"
//																		},
//																		"1HAJJLQL80": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HATHKTUO6",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HATHKTUO7",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAJJLQL80",
//																			"faceTagName": "start"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HAT6UNGU4",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HAT9QFSD0",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1HAT9R4AM0",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1HAT6UNGU5",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1HAT6UNGU6",
//																	"attrs": {
//																		"Slot1H2F6U36O0": {
//																			"jaxId": "1HAT6UNGU7",
//																			"attrs": {
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"container": "true"
//																			}
//																		}
//																	}
//																}
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1HA5CQ5QV15",
//													"attrs": {
//														"1HA5D430C0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HA5DK4IS24",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HA5DK4IS25",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HA5D430C0",
//															"faceTagName": "done"
//														},
//														"1HA5D4BEQ0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HA5DK4IS26",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HA5DK4IS27",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HA5D4BEQ0",
//															"faceTagName": "wait"
//														},
//														"1HA5I2GNK0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HA5I335048",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HA5I335049",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HA5I2GNK0",
//															"faceTagName": "desktop"
//														},
//														"1HAJJLQL80": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAJJNKNG16",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAJJNKNG17",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAJJLQL80",
//															"faceTagName": "start"
//														},
//														"1HAT9N7KE0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAT9O5HJ6",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAT9O5HJ7",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAT9N7KE0",
//															"faceTagName": "abort"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HA5CQ5QV16",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HA5CQ5QV17",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1HA5CRLRB0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HA5D3IKV0",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxWait",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "50",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "Off",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": ""
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1HA5CSM2L0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HA5D3IKV1",
//																	"attrs": {
//																		"type": "text",
//																		"id": "",
//																		"position": "Absolute",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "20",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontBodyLit\"]",
//																		"text": "AI is thinking...",
//																		"font": "",
//																		"fontSize": "#txtSize.smallPlus",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Center",
//																		"alignV": "Center",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"lineClamp": "0",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HA5D3IKV2",
//																	"attrs": {
//																		"1HA5I2GNK0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HA5I335052",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HA5I335053",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HA5I2GNK0",
//																			"faceTagName": "desktop"
//																		},
//																		"1HA5D4BEQ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAT9O5HJ8",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAT9O5HJ9",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HA5D4BEQ0",
//																			"faceTagName": "wait"
//																		},
//																		"1HA5D430C0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HATHCP5Q18",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HATHCP5Q19",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HA5D430C0",
//																			"faceTagName": "done"
//																		},
//																		"1HAJJLQL80": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HATHKTUO8",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HATHKTUO9",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAJJLQL80",
//																			"faceTagName": "start"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HA5D3IKV3",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HA5D3IKV4",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnText.js",
//															"jaxId": "1HA5CV4FU0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1HA5D3IKV5",
//																	"attrs": {
//																		"style": "primary",
//																		"w": "100",
//																		"h": "25",
//																		"text": "Abort",
//																		"outlined": "false",
//																		"icon": ""
//																	}
//																},
//																"properties": {
//																	"jaxId": "1HA5D3IKV6",
//																	"attrs": {
//																		"type": "#null#>BtnText(\"primary\",100,25,\"Abort\",false,\"\")",
//																		"id": "BtnAbort",
//																		"position": "Absolute",
//																		"x": "50%",
//																		"y": "20",
//																		"display": "On",
//																		"face": "",
//																		"anchorH": "Center"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HA5D3IKV7",
//																	"attrs": {
//																		"1HA5I2GNK0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HA5I335056",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HA5I335057",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HA5I2GNK0",
//																			"faceTagName": "desktop"
//																		},
//																		"1HA5D4BEQ0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HAT9O5HJ12",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HAT9O5HJ13",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HA5D4BEQ0",
//																			"faceTagName": "wait"
//																		},
//																		"1HA5D430C0": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HATHCP5Q22",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HATHCP5Q23",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HA5D430C0",
//																			"faceTagName": "done"
//																		},
//																		"1HAJJLQL80": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1HATHKTUO10",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1HATHKTUO11",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1HAJJLQL80",
//																			"faceTagName": "start"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HA5D3IKV8",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HA7BN1640",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1HA7BOS360",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1HA5D3IKV9",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1HA5D3IKV10",
//																	"attrs": {
//																		"Slot1H2F6U36O0": {
//																			"jaxId": "1HA5D3IKV11",
//																			"attrs": {
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"container": "true"
//																			}
//																		}
//																	}
//																}
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1HA5D3IKV12",
//													"attrs": {
//														"1HA5D430C0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HA5DK4IS32",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HA5DK4IS33",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HA5D430C0",
//															"faceTagName": "done"
//														},
//														"1HA5D4BEQ0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HA5DK4IS34",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HA5DK4IS35",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HA5D4BEQ0",
//															"faceTagName": "wait"
//														},
//														"1HA5I2GNK0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HA5I335060",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HA5I335061",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HA5I2GNK0",
//															"faceTagName": "desktop"
//														},
//														"1HAT9N7KE0": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HAT9O5HJ16",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAT9O5HJ17",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAT9N7KE0",
//															"faceTagName": "abort"
//														},
//														"1HAJJLQL80": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1HATHKTUO12",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HATHKTUO13",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1HAJJLQL80",
//															"faceTagName": "start"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HA5D3IKV13",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HA5D3IKV14",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1HA53D8VE7",
//									"attrs": {
//										"1HA5I2GNK0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HA5I335064",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HA5I335065",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HA5I2GNK0",
//											"faceTagName": "desktop"
//										},
//										"1HA5D4BEQ0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HAT9O5HJ18",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HAT9O5HJ19",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HA5D4BEQ0",
//											"faceTagName": "wait"
//										},
//										"1HA5D430C0": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HATHCP5Q26",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HATHCP5Q27",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HA5D430C0",
//											"faceTagName": "done"
//										},
//										"1HAJJLQL80": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1HATHKTUO14",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HATHKTUO15",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1HAJJLQL80",
//											"faceTagName": "start"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HA53D8VE8",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HA53D8VE9",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1HA4CQ2RU8",
//					"attrs": {
//						"1HA5I2GNK0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HA5I335068",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HA5I335069",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HA5I2GNK0",
//							"faceTagName": "desktop"
//						},
//						"1HA5D4BEQ0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HAT9O5HJ22",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HAT9O5HJ23",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HA5D4BEQ0",
//							"faceTagName": "wait"
//						},
//						"1HA5D430C0": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HATHCP5Q30",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HATHCP5Q31",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HA5D430C0",
//							"faceTagName": "done"
//						},
//						"1HAJJLQL80": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1HATHKTUO16",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HATHKTUO17",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1HAJJLQL80",
//							"faceTagName": "start"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1HA4CQ2RU9",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1HA4CQ2RU10",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "true",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1HA4CQ2RU11",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}