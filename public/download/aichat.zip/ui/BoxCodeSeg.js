//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
/*#{1HABRJ9190StartDoc*/
import {DlgMenu} from "/@homekit/ui/DlgMenu.js";
let firstRun=true;
/*}#1HABRJ9190StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BoxCodeSeg=function(code,mode,saveCallback,runCallback){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let btnMode,txtMode,btnCopy,boxCode;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	
	/*#{1HABRJ9191LocalVals*/
	const app=VFACT.app;
	let cm=null;
	let curCode="";
	let curMode="";
	let modeName="";
	let codeType="";
	let readCodeDone=false;
	/*}#1HABRJ9191LocalVals*/
	
	/*#{1HABRJ9191PreState*/
	/*}#1HABRJ9191PreState*/
	/*#{1HABRJ9191PostState*/
	/*}#1HABRJ9191PostState*/
	cssVO={
		"hash":"1HABRJ9191",nameHost:true,
		"type":"hud","position":"relative","x":10,"y":0,"w":">calc(100% - 20px)","h":"","padding":1,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
		"contentLayout":"flex-y",
		children:[
			{
				"hash":"1HABUSDTD0",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["body"],
				"border":1,
			},
			{
				"hash":"1HABUU6OS0",
				"type":"box","position":"relative","x":0,"y":0,"w":"100%","h":22,"padding":[0,5,0,5],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["secondary"],
				"contentLayout":"flex-x","itemsAlign":1,
				children:[
					{
						"hash":"1HABV63T30",
						"type":BtnIcon(cfgColor.fontSecondary,20,0,appCfg.sharedAssets+"/btncombo.svg",null),"id":"BtnMode","position":"relative","x":0,"y":0,
						"OnClick":function(event){
							/*#{1HACN0CT80FunctionBody*/
							self.setMode();
							/*}#1HACN0CT80FunctionBody*/
						},
					},
					{
						"hash":"1HABV88HT0",
						"type":"text","id":"TxtMode","position":"relative","x":0,"y":0,"w":100,"h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontSecondary"],
						"text":"Javascript","fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","flex":true,
					},
					{
						"hash":"1HABVB07M0",
						"type":BtnIcon(cfgColor.fontSecondary,20,0,appCfg.sharedAssets+"/save.svg",null),"id":"BtnSave","position":"relative","x":0,"y":0,"attached":!!saveCallback,
						"OnClick":function(event){
							/*#{1HACN187I0FunctionBody*/
							self.saveCode();
							/*}#1HACN187I0FunctionBody*/
						},
					},
					{
						"hash":"1HABVC5M40",
						"type":BtnIcon(cfgColor.fontSecondary,20,0,appCfg.sharedAssets+"/copy.svg",null),"id":"BtnCopy","position":"relative","x":0,"y":0,
						"OnClick":function(event){
							/*#{1HACN1L9E0FunctionBody*/
							self.copyCode();
							/*}#1HACN1L9E0FunctionBody*/
						},
					},
					{
						"type":BtnIcon(cfgColor.fontSecondary,20,0,appCfg.sharedAssets+"/run.svg",null),"id":"BtnRun","position":"relative","x":0,"y":0,
						"attached":!!runCallback,
						"OnClick":function(event){
							self.runCode();
						},
					}
				],
			},
			{
				"hash":"1HABVDH7E0",
				"type":"hud","id":"BoxCode","position":"relative","x":0,"y":0,"w":"100%","h":"","overflow":"auto","minW":"","minH":50,"maxW":"","maxH":200,"styleClass":"",
			},
			{
				"hash":"1HABVGM1U0",
				"type":"box","position":"relative","x":0,"y":0,"w":"100%","h":10,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["fontSecondaryLit"],
			}
		],
		/*#{1HABRJ9191ExtraCSS*/
		/*}#1HABRJ9191ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			self=this;
			btnMode=self.BtnMode;txtMode=self.TxtMode;btnCopy=self.BtnCopy;boxCode=self.BoxCode;
			/*#{1HABRJ9191Create*/
			if(code){
				self.setCode(code,mode);
			}else{
				//Start reading codes
				readCodeDone=false;
			}
			/*}#1HABRJ9191Create*/
		},
		/*#{1HABRJ9191EndCSS*/
		/*}#1HABRJ9191EndCSS*/
	};
	/*#{1HABRJ9191PostCSSVO*/
	let mods=[
		{text:"Generic Code"},
		{text:"Javascript",mode:"javascript"},
		{text:"HTML",mode:"html"},
		{text:"CSS",mode:"css"},
		{text:"C/CPP",mode:"cpp"},
		{text:"Java",mode:"java"},
		{text:"Python",mode:"py"},
	];
	
	//------------------------------------------------------------------------
	cssVO.setCode=async function(code,codeType_param=""){
		let pos,line1,mode,wrap;
		codeType=codeType_param;
		if(cm){
			boxCode.webObj.innerHTML="";
			cm=null;
		}
		if(!window.CodeMirror){
			//import CodeMirror
			await VFACT.appendScript("/@codemirror/lib/codemirror.js");
			await VFACT.appendCSS("/@codemirror/lib/codemirror.css");
		}
		curCode=code;
		if(!codeType_param){
			pos=code.indexOf("\n");
			line1=code.substring(0,pos).toLowerCase();
			switch(line1){
				case "javascript":
				case "html":
				case "markdown":
				case "json":
				case "css":
				case "jsx":
				case "cpp":
				case "c":
				case "java":
				case "python":
					codeType_param=line1;
					codeType=line1;
					code=code.substring(pos+1);
					break;
			}
		}
		wrap=false;
		switch(codeType_param){
			case "javascript":
				mode="javascript";
				modeName="JavaScript";
				await VFACT.appendScript("/@codemirror/mode/javascript.js");
				await VFACT.appendCSS("/@codemirror/mode/javascript.css");
				break;
			case "html":
				mode="text/html";
				modeName="HTML";
				await VFACT.appendCSS("/@codemirror/mode/javascript.css");
	
				await VFACT.appendScript("/@codemirror/mode/css.js");
				await VFACT.appendScript("/@codemirror/mode/javascript.js");
				await VFACT.appendScript("/@codemirror/mode/xml.js");
				await VFACT.appendScript("/@codemirror/mode/htmlmixed.js");
				break;
			case "markdown":
				wrap=true;
				mode="text/x-markdown";
				modeName="Markdown";
				await VFACT.appendScript("/@codemirror/mode/markdown.js");
				break;
			case "json":
				mode={name: "javascript", json: true};
				modeName="JSON";
				await VFACT.appendCSS("/@codemirror/mode/javascript.css");
				await VFACT.appendScript("/@codemirror/mode/javascript.js");
				break;
			case "css":
			case ".css":
				mode={name: "css"};
				modeName="CSS";
				await VFACT.appendScript("/@codemirror/mode/css.js");
				break;
			case "jsx":
			case ".jsx":
				mode="text/jsx";
				modeName="JSX";
				await VFACT.appendScript("/@codemirror/mode/javascript.js");
				await VFACT.appendCSS("/@codemirror/mode/javascript.css");
				await VFACT.appendScript("/@codemirror/mode/xml.js");
				await VFACT.appendScript("/@codemirror/mode/jsx.js");
				break;
			case "java":
			case ".java":
				mode="text/x-java";
				modeName="Java";
				await VFACT.appendScript("/@codemirror/mode/clike.js");
				break;
			case "cpp":
			case "c":
				mode="text/x-c++src";
				modeName="C++";
				await VFACT.appendCSS("/@codemirror/mode/clike.js");
				break;
			default:
				mode="text/plain";
				modeName="Generic Code";
				break;
		}
		if(code.endsWith("```\n")){
			code=code.substring(0,code.length-3);
		}
		txtMode.text=modeName;
		curMode=mode;
		//Create code mirror;
		cm=CodeMirror(boxCode.webObj, {
			value:code,
			mode:mode,
			lineNumbers:true,
			undoDepth:20
		});
		if(firstRun){
			firstRun=false;
			setTimeout(()=>{
				cm.refresh();
			},300)
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.addCode=function(moreCode){
		curCode+=moreCode;
		if(cm){
			cm.doc.setValue(curCode);
			if(curCode.endsWith("```\n")){
				readCodeDone=true;
				return true;
			}
		}else{
			let pos=curCode.indexOf("\n");
			if(pos>=0){
				self.setCode(curCode);
			}
		}
		return false;
	};
	
	//------------------------------------------------------------------------
	cssVO.setMode=function(){
		let code=self.getCode();
		app.showDlg(DlgMenu,{
			hud:btnMode,
			items:mods,
			callback(item){
				if(!item){
					return;
				}
				self.setCode(code,item.mode);
				txtMode.text=item.text;
			}
		});
	};
	
	//------------------------------------------------------------------------
	cssVO.saveCode=function(){
		let code=self.getCode();
		saveCallback(code);
	};
	
	//------------------------------------------------------------------------
	cssVO.copyCode=function(){
		let code=self.getCode();
		navigator.clipboard.writeText(code);
		if(app.showTip){
			app.showTip(btnCopy,(($ln==="CN")?("代码已复制"):/*EN*/("Code copied")));
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.runCode=function(){
		let code=self.getCode();
		if(runCallback){
			runCallback(code, codeType);
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.getCode=function(){
		if(cm){
			return cm.doc.getValue();
		}
		return "";
	};
	/*}#1HABRJ9191PostCSSVO*/
	cssVO.constructor=BoxCodeSeg;
	return cssVO;
};
/*#{1HABRJ9191ExCodes*/
/*}#1HABRJ9191ExCodes*/

//----------------------------------------------------------------------------
BoxCodeSeg.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1HABRJ9191PreAISpot*/
	/*}#1HABRJ9191PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1HABRJ9191PostAISpot*/
	/*}#1HABRJ9191PostAISpot*/
	return exposeVO;
};

/*#{1HABRJ9190EndDoc*/
/*}#1HABRJ9190EndDoc*/

export default BoxCodeSeg;
export{BoxCodeSeg};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1HABRJ9190",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1HABRJ9192",
//			"attrs": {
//				"device": "Custom Size",
//				"screenW": "375",
//				"screenH": "750",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1HABRJ9193",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1HABRJ9194",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1HABRJ9195",
//			"attrs": {
//				"code": {
//					"type": "string",
//					"valText": "\"\""
//				},
//				"mode": {
//					"type": "string",
//					"valText": "\"javascript\""
//				},
//				"saveCallback": {
//					"type": "auto",
//					"valText": "null"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1HABRJ9196",
//			"attrs": {}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1HABRJ9197",
//			"attrs": {}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1HABRJ9198",
//			"attrs": {}
//		},
//		"mockupStates": {
//			"jaxId": "1HABRJ9199",
//			"attrs": {}
//		},
//		"exposeToAI": "true",
//		"descAI": "",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1HABRJ9191",
//			"attrs": {
//				"properties": {
//					"jaxId": "1HABRJ91910",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Relative",
//						"x": "10",
//						"y": "0",
//						"w": "100%-20",
//						"h": "",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "1",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Flex Y"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1HABUSDTD0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HABVCP3N0",
//									"attrs": {
//										"type": "box",
//										"id": "BoxBG",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"body\"]",
//										"border": "1",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HABVCP3N1",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1HABVCP3N2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HABVCP3O0",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1HABUU6OS0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HABVCP3O1",
//									"attrs": {
//										"type": "box",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "22",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "[0,5,0,5]",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"secondary\"]",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"contentLayout": "Flex X",
//										"itemsAlign": "Center"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1HABV63T30",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1HABVCP3O2",
//													"attrs": {
//														"style": "#cfgColor.fontSecondary",
//														"w": "20",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/btncombo.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1HABVCP3O3",
//													"attrs": {
//														"type": "#null#>BtnIcon(cfgColor.fontSecondary,20,0,appCfg.sharedAssets+\"/btncombo.svg\",null)",
//														"id": "BtnMode",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": ""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HABVCP3O4",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1HABVCP3O5",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1HACN0CT80",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1HACN0SRG0",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1HABVCP3O6",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1HABVCP3O7",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1HABV88HT0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HABVCP3O8",
//													"attrs": {
//														"type": "text",
//														"id": "TxtMode",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontSecondary\"]",
//														"text": "Javascript",
//														"font": "",
//														"fontSize": "#txtSize.small",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0",
//														"flex": "true"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HABVCP3O9",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1HABVCP3O10",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HABVCP3O11",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1HABVB07M0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1HABVC4H70",
//													"attrs": {
//														"style": "#cfgColor.fontSecondary",
//														"w": "20",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/save.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1HABVC4H71",
//													"attrs": {
//														"type": "#null#>BtnIcon(cfgColor.fontSecondary,20,0,appCfg.sharedAssets+\"/save.svg\",null)",
//														"id": "BtnSave",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"attach": "#!!saveCallback"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HABVC4H72",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1HABVC4H73",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1HACN187I0",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1HACN1FJG0",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1HABVC4H74",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1HABVC4H75",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnIcon.js",
//											"jaxId": "1HABVC5M40",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1HABVC5M41",
//													"attrs": {
//														"style": "#cfgColor.fontSecondary",
//														"w": "20",
//														"h": "0",
//														"icon": "#appCfg.sharedAssets+\"/copy.svg\"",
//														"colorBG": "null"
//													}
//												},
//												"properties": {
//													"jaxId": "1HABVC5M42",
//													"attrs": {
//														"type": "#null#>BtnIcon(cfgColor.fontSecondary,20,0,appCfg.sharedAssets+\"/copy.svg\",null)",
//														"id": "BtnCopy",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": ""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HABVC5M43",
//													"attrs": {}
//												},
//												"functions": {
//													"jaxId": "1HABVC5M44",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1HACN1L9E0",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1HACN1R3T0",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1HABVC5M45",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1HABVC5M46",
//													"attrs": {}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1HABVCP3O12",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1HABVCP3O13",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HABVCP3O14",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1HABVDH7E0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HABVINFD0",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxCode",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Auto Scroll",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "50",
//										"maxW": "",
//										"maxH": "200",
//										"face": "",
//										"styleClass": ""
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HABVINFD1",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1HABVINFD2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HABVINFD3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1HABVGM1U0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HABVINFD4",
//									"attrs": {
//										"type": "box",
//										"id": "",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "10",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#cfgColor[\"fontSecondaryLit\"]",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HABVINFD5",
//									"attrs": {}
//								},
//								"functions": {
//									"jaxId": "1HABVINFD6",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HABVINFD7",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1HABRJ91911",
//					"attrs": {}
//				},
//				"functions": {
//					"jaxId": "1HABRJ91912",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1HABRJ91913",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1HABRJ91914",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}