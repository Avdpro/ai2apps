//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnObject} from "/@StdUI/ui/BtnObject.js";
import {BtnText} from "/@StdUI/ui/BtnText.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
import {DataView} from "/@StdUI/ui/DataView.js";
/*#{1HA934NIR0StartDoc*/
import pathLib from "/@path";
import Base64 from "/@tabos/utils/base64.js";
import {DlgFile} from "/@homekit/ui/DlgFile.js";
/*}#1HA934NIR0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BoxAskUser=function(vo,session){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let txtContent,boxCountdown,txtCountdown,boxMenu,boxMenuItems,boxAsk,btn1,btn2,btn3,boxInput,edInput,edMemo,txtInputHint,boxCode,boxBlock,boxDataView,dvData,btnDataNext,boxAudio,btnStopRecord,txtAudio,btnPlayAudio,btnDownloadAudio,btnUseAudio,btnRecord;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let hideIcon=!!vo.hideIcon;
	let icon=vo.icon||(appCfg.sharedAssets+"/help.svg");
	
	/*#{1HA934NIR1LocalVals*/
	let countdownTimer=null;
	/*}#1HA934NIR1LocalVals*/
	
	/*#{1HA934NIR1PreState*/
	/*}#1HA934NIR1PreState*/
	state={
		"countdown":vo.countdown,
		/*#{1HA934NIR7ExState*/
		/*}#1HA934NIR7ExState*/
	};
	state=VFACT.flexState(state);
	/*#{1HA934NIR1PostState*/
	const roleDefs={
		"user":{
			side:"right",
			icon:appCfg.sharedAssets+"/user.svg",
			textColor:cfgColor.fontBody,
			bgColor:cfgColor.tool,
			bgBorderSize:0,
			bgBorderColor:cfgColor.fontBodySub,
			iconColor:cfgColor.fontBody,
			iconBG:cfgColor.body,
			iconBorderColor:cfgColor.fontBodyLit,
			iconBorderSize:1,
			iconCorner:100,
			render:false
		},
		"assistant":{
			side:"left",
			icon:appCfg.sharedAssets+"/agent.svg",
			textColor:cfgColor.fontBody,
			bgColor:0,
			bgBorderSize:0,
			bgBorderColor:cfgColor.fontBodySub,
			iconColor:cfgColor.fontBody,
			iconBG:cfgColor.body,
			iconBorderColor:cfgColor.fontBodyLit,
			iconBorderSize:1,
			iconCorner:100,
		},
		"wait":{
			side:"left",
			icon:appCfg.sharedAssets+"/wait.svg",
			textColor:cfgColor.fontBody,
			bgColor:cfgColor.tool,
			bgBorderSize:0,
			bgBorderColor:cfgColor.fontBodySub,
			iconColor:cfgColor.fontBody,
			iconBG:cfgColor.body,
			iconBorderColor:cfgColor.fontBodyLit,
			iconBorderSize:1,
			iconCorner:100,
			render:false,
		},
		"system":{
			side:"left",
			icon:appCfg.sharedAssets+"/event.svg",
			textColor:cfgColor.fontBodySub,
			bgColor:cfgColor.tool,
			bgBorderSize:0,
			bgBorderColor:cfgColor.fontBodySub,
			iconColor:cfgColor.fontBody,
			iconBG:cfgColor.body,
			iconBorderColor:cfgColor.fontBodyLit,
			iconBorderSize:1,
			iconCorner:100,
		},
		"warning":{
			side:"left",
			icon:appCfg.sharedAssets+"/event.svg",
			textColor:cfgColor.fontWarning,
			bgColor:cfgColor.warning,
			bgBorderSize:0,
			bgBorderColor:cfgColor.fontBodySub,
			iconColor:cfgColor.fontWarning,
			iconBG:cfgColor.warning,
			iconBorderColor:cfgColor.fontBodyLit,
			iconBorderSize:0,
			iconCorner:100,
			render:false,
		},
		"error":{
			side:"left",
			icon:appCfg.sharedAssets+"/event.svg",
			textColor:cfgColor.error,
			bgColor:0,
			bgBorderSize:0,
			bgBorderColor:cfgColor.fontBodySub,
			iconColor:cfgColor.fontError,
			iconBG:cfgColor.error,
			iconBorderColor:cfgColor.fontBodyLit,
			iconBorderSize:0,
			iconCorner:100,
			render:false,
		}
	};
	roleDefs.greeting=roleDefs.ai=roleDefs.agent=roleDefs.assistant;
	vo.role=vo.role||vo.type||"assistant";
	if(vo.role){
		let def;
		def=roleDefs[vo.role]||roleDefs.assistant;
		if(session && session.getRoleDef){
			let sdef;
			sdef=session.getRoleDef(vo.role);
			if(sdef){
				def={...def,...sdef};
			}
		}
		vo={...def,...vo};
	}else{
		vo={...vo};
	}
	icon=vo.icon||(appCfg.sharedAssets+"/help.svg");
	/*}#1HA934NIR1PostState*/
	cssVO={
		"hash":"1HA934NIR1",nameHost:true,
		"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":"","padding":hideIcon?[10,10,15,10]:[10,10,15,45],"minW":"","minH":"","maxW":"","maxH":"",
		"styleClass":"","contentLayout":"flex-y",
		children:[
			{
				"hash":"1HA9DBEF30",
				"type":"box","id":"BoxIcon","x":5,"y":5,"w":vo.iconSize||32,"h":vo.iconSize||32,"padding":2,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"background":vo.iconBG||vo.bgColor||cfgColor.primary,"border":vo.iconBorderSize||0,"borderColor":vo.iconBorderColor||[0,0,0,1.00],"corner":vo.iconCorner||5,
				"attached":!hideIcon,
				children:[
					{
						"hash":"1HA9DBEF40",
						"type":"box","position":"relative","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":vo.iconColor||cfgColor.fontPrimary,
						"maskImage":icon,"attached":!!vo.icon,
					},
					{
						"hash":"1HB2PL2PQ0",
						"type":"image","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","image":vo.pic,"fitSize":true,"attached":!!vo.pic,
					}
				],
			},
			{
				"hash":"1IC7TCOG70",
				"type":"text","id":"TxtHeader","position":"relative","x":0,"y":0,"w":"100%","h":"","alpha":0.7,"margin":[0,0,3,0],"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","color":vo.textColor,"text":vo.txtHeader,"fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","attached":!!vo.txtHeader,
			},
			{
				"hash":"1HAA3CQLS0",
				"type":"text","id":"TxtContent","position":"relative","x":0,"y":0,"w":"100%","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":vo.textColor,
				"text":vo.prompt||vo.text,"fontSize":txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","wrap":true,"selectable":true,
			},
			{
				"hash":"1I13M8KIA0",
				"type":"hud","id":"BoxCountdown","position":"relative","x":0,"y":0,"w":"100%","h":30,"padding":[0,0,0,10],"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","attached":vo.countdown>0,"contentLayout":"flex-x",
				children:[
					{
						"hash":"1I13MBG8P0",
						"type":"text","id":"TxtCountdown","position":"relative","x":0,"y":0,"w":100,"h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodySub"],
						"text":$P(()=>(state.countdown),state),"fontSize":txtSize.big,"fontWeight":"bold","fontStyle":"normal","textDecoration":"","alignV":1,
					}
				],
			},
			{
				"hash":"1HAADF97V0",
				"type":"hud","id":"BoxMenu","position":"relative","x":0,"y":0,"w":"100%","h":"","padding":[5,10,10,10],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"contentLayout":"flex-y","attached":vo.type==="menu",
				children:[
					{
						"hash":"1HAAICUAP0",
						"type":"hud","id":"BoxMenuItems","position":"relative","x":0,"y":0,"w":"100%","h":"","minW":"","minH":20,"maxW":"","maxH":"","styleClass":"",
						children:[
						],
					},
					{
						"hash":"1HAAIE08L0",
						"type":BtnText("primary",60,20,vo.button||"OK",false,""),"position":"relative","x":0,"y":0,"margin":[10,0,0,0],"corner":3,"attached":!!vo.multiSelect,
						"OnClick":function(event){
							/*#{1HAAK4ARU0FunctionBody*/
							self.closeMultiMenu();
							/*}#1HAAK4ARU0FunctionBody*/
						},
					}
				],
			},
			{
				"hash":"1HAA3H1FE0",
				"type":"hud","id":"BoxAsk","position":"relative","x":0,"y":0,"w":"100%","h":"","margin":[5,0,0,0],"padding":[0,20,0,20],"minW":"","minH":40,"maxW":"",
				"maxH":"","styleClass":"","contentLayout":"flex-x","itemsAlign":1,"itemsWrap":1,"attached":vo.type==="confirm",
				children:[
					{
						"hash":"1HAA3IFOF0",
						"type":BtnText("primary",100,24,vo.button1||"OK",false,""),"id":"Btn1","position":"relative","x":50,"y":12,"corner":3,"margin":[5,15,5,0],"anchorX":1,
						"anchorY":1,
						"OnClick":function(event){
							/*#{1HAACN4G30FunctionBody*/
							self.closeConfirm(1);
							/*}#1HAACN4G30FunctionBody*/
						},
					},
					{
						"hash":"1HAA3L6LG0",
						"type":BtnText("warning",100,24,vo.button2||"Cancel",false,""),"id":"Btn2","position":"relative","x":50,"y":12,"margin":[5,15,5,0],"corner":3,"attached":vo.button2,
						"anchorX":1,"anchorY":1,
						"OnClick":function(event){
							/*#{1HAACNIF10FunctionBody*/
							self.closeConfirm(0);
							/*}#1HAACNIF10FunctionBody*/
						},
					},
					{
						"hash":"1HAA3UKHN0",
						"type":BtnText("secondary",100,24,vo.button3,false,""),"id":"Btn3","position":"relative","x":50,"y":12,"margin":[5,15,5,0],"corner":3,"attached":vo.button3,
						"anchorX":1,"anchorY":1,
						"OnClick":function(event){
							/*#{1HAACO2RQ0FunctionBody*/
							self.closeConfirm(2);
							/*}#1HAACO2RQ0FunctionBody*/
						},
					}
				],
			},
			{
				"hash":"1HAAKRDC20",
				"type":"box","id":"BoxInput","position":"relative","x":10,"y":0,"w":">calc(100% - 20px)","h":"","minW":"","minH":30,"maxW":360,"maxH":"","styleClass":"",
				"background":[255,255,255,1],"corner":3,"shadowX":0,"shadowY":1,"shadowBlur":4,"shadowColor":[0,0,0,0.3],"contentLayout":"flex-y","attached":vo.type==="input",
				children:[
					{
						"hash":"1HAAKRDC22",
						"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":"","padding":[5,0,5,0],"minW":"","minH":20,"maxW":"","maxH":200,"styleClass":"","contentLayout":"flex-x",
						"traceSize":true,"itemsAlign":1,
						children:[
							{
								"hash":"1HENTEQ6L0",
								"type":BtnIcon("front",28,0,appCfg.sharedAssets+"/folder.svg",null),"id":"BtnOpenFile","position":"relative","x":0,"y":0,"attached":vo.file && vo.file!=="native",
								"OnClick":function(event){
									/*#{1HENTHD4Q0FunctionBody*/
									self.openFilePath();
									/*}#1HENTHD4Q0FunctionBody*/
								},
							},
							{
								"hash":"1HF65I8TR0",
								"type":BtnIcon("front",28,0,appCfg.sharedAssets+"/folder.svg",null),"id":"BtnOpenNative","position":"relative","x":0,"y":0,"attached":vo.file==="native",
								/*#{1HF65I8TR0Codes*/
								"labelHtml": '<input type="file" multiple="false" style="width:0px">',
								OnLableAction:function(){
									let files=[],i,n;
									n=this.files.length;
									for(i=0;i<n;i++){
										files.push(this.files[i]);
									}
									self.useNativeFile(files[0]);
									this.value="";
								}
								/*}#1HF65I8TR0Codes*/
							},
							{
								"hash":"1HAALRDJS0",
								"type":"edit","id":"EdInput","position":"relative","x":0,"y":0,"w":">calc(100% - 80px)","h":30,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
								"inputType":vo.inputType||"text","text":vo.initText||vo.text||"","placeHolder":vo.placeholder||vo.tip||"","color":[0,0,0],"outline":0,"border":[0,0,1,0],
								"attached":!vo.memo,
								"OnKeyDown":function(event){
									/*#{1HAAMBD940FunctionBody*/
									if(event.code==="Enter"){
										if((!event.isComposing) &&(!event.shiftKey)){
											event.stopPropagation();
											event.preventDefault();
											self.closeInput();
										}
									}
									/*}#1HAAMBD940FunctionBody*/
								},
							},
							{
								"hash":"1HAAKRDC30",
								"type":"memo","id":"EdMemo","position":"relative","x":0,"y":0,"w":">calc(100% - 50px)","h":"","minW":"","minH":20,"maxW":"","maxH":"","styleClass":"",
								"text":vo.initText||vo.text,"color":cfgColor["fontBody"],"background":cfgColor["body"],"fontSize":txtSize.mid,"outline":0,"border":[0,0,1,0],"borderColor":[0,0,0,0.5],
								"flex":true,"attached":!!vo.memo,
								"OnInput":function(){
									/*#{1HAAKRDC41FunctionBody*/
									txtInputHint.display=!this.text;
									/*}#1HAAKRDC41FunctionBody*/
								},
								"OnKeyDown":function(event){
									/*#{1HAAKRDC43FunctionBody*/
									if(event.code==="Enter"){
										if((!event.isComposing) &&(!event.shiftKey)){
											event.stopPropagation();
											event.preventDefault();
											self.closeInput();
										}
									}
									/*}#1HAAKRDC43FunctionBody*/
								},
							},
							{
								"hash":"1HAAKRDC46",
								"type":BtnIcon("front",30,0,appCfg.sharedAssets+"/send.svg",null),"id":"BtnSend","position":"relative","x":0,"y":0,"margin":[0,0,0,10],"padding":2,
								"autoLayout":true,
								"OnClick":function(event){
									/*#{1HAAKRDC53FunctionBody*/
									self.closeInput();
									/*}#1HAAKRDC53FunctionBody*/
								},
							},
							{
								"hash":"1HAAKRDC57",
								"type":"text","id":"TxtInputHint","x":15,"y":0,"w":100,"h":"100%","display":(!vo.initText)&&(!vo.text),"uiEvent":-1,"minW":"","minH":"","maxW":"",
								"maxH":"","styleClass":"","color":cfgColor["fontBodyLit"],"text":vo.placeholder||vo.tip||"","fontSize":txtSize.mid,"fontWeight":"normal","fontStyle":"italic",
								"textDecoration":"","alignV":1,"attached":!!vo.memo,
							}
						],
					},
					{
						"hash":"1HAAL48AG0",
						"type":"text","position":"relative","x":10,"y":0,"w":">calc(100% - 20px)","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodySub"],
						"text":"New line: Shift+Enter","fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","attached":vo.memo,
					}
				],
			},
			{
				"hash":"1HBIS5UIR0",
				"type":"hud","id":"BoxCode","position":"relative","x":0,"y":0,"w":"100%","h":"","margin":[10,0,0,0],"padding":[0,20,0,20],"minW":"","minH":40,"maxW":"",
				"maxH":"","styleClass":"","contentLayout":"flex-y","itemsAlign":1,"itemsWrap":1,"attached":vo.type==="code",
				children:[
					{
						"hash":"1HBISLN7M0",
						"type":"box","position":"relative","x":0,"y":0,"w":"100%","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["body"],
						"border":1,"contentLayout":"flex-y",
						children:[
							{
								"hash":"1HBISSGF50",
								"type":"box","position":"relative","x":0,"y":0,"w":"100%","h":10,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["secondary"],
							},
							{
								"hash":"1HBIST3QG0",
								"type":"hud","id":"BoxCodes","position":"relative","x":0,"y":0,"w":"100%","h":300,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
							},
							{
								"hash":"1HBISTSUE0",
								"type":"box","position":"relative","x":0,"y":0,"w":"100%","h":10,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["secondary"],
							}
						],
					},
					{
						"hash":"1HBISOTQN0",
						"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":30,"padding":[0,10,0,10],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
						children:[
							{
								"hash":"1HBISPSNU0",
								"type":BtnText("primary",100,25,"Apply",false,""),"id":"BtnApplyCode","position":"relative","x":0,"y":0,"corner":3,"margin":[5,15,5,0],
								"OnClick":function(event){
									/*#{1HBISPSNU5FunctionBody*/
									/*}#1HBISPSNU5FunctionBody*/
								},
							},
							{
								"hash":"1HBISQGHA0",
								"type":BtnText("warning",100,25,"Cancel",false,""),"id":"BtnAbortCode","position":"relative","x":0,"y":0,"margin":[5,15,5,0],"corner":3,
								"OnClick":function(event){
									/*#{1HBISQGHA5FunctionBody*/
									/*}#1HBISQGHA5FunctionBody*/
								},
							}
						],
					}
				],
			},
			{
				"hash":"1HEJE92P70",
				"type":"hud","id":"BoxBlock","position":"relative","x":0,"y":0,"w":"100%","h":"","margin":[10,0,0,0],"padding":[0,20,0,20],"minW":"","minH":40,"maxW":"",
				"maxH":"","styleClass":"","contentLayout":"flex-x","itemsAlign":1,"itemsWrap":1,"attached":vo.type==="block",
			},
			{
				"hash":"1IC7TIVS00",
				"type":"text","id":"TxtFooter","position":"relative","x":0,"y":0,"w":"100%","h":"","alpha":0.7,"margin":[0,0,3,0],"minW":"","minH":"","maxW":"","maxH":"",
				"styleClass":"","color":vo.textColor,"text":vo.txtFooter,"fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","attached":!!vo.txtFooter,
			},
			{
				"hash":"1IC90NK8F0",
				"type":"hud","id":"BoxDataView","position":"relative","x":0,"y":0,"w":"100%","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","attached":vo.type==="object",
				children:[
					{
						"hash":"1IC90O52S0",
						"type":DataView(null,null,null,"",{"titleHeight":30,"titleSize":18,"titleColor":cfgColor["fontBody"],"titleBold":true,"lineHeight":25,"lineGap":5,"labelSize":12,"labelColor":cfgColor["fontBody"],"labelBold":true,"labelLine":true,"valueSize":14,"valueColor":cfgColor["fontBody"],"valueBold":false,"segHeight":20,"segSize":14,"segBold":true,"segColor":cfgColor["fontBody"],"trace":false,"edit":true,"noteSize":12,"autoCollapse":false,"hideCollapse":false,"valueRightAlign":false,"gridLine":false,"labelWidth":0},""),
						"id":"DvData","position":"relative","x":0,"y":0,
					},
					{
						"hash":"1IC90O7S10",
						"type":BtnText("primary",100,20,vo.button||(($ln==="CN")?("继续"):("Next")),false,""),"id":"BtnDataNext","position":"relative","x":0,"y":0,"margin":[10,0,0,0],
						"corner":3,
						"OnClick":function(event){
							/*#{1IC90O7S20FunctionBody*/
							self.closeDataView();
							/*}#1IC90O7S20FunctionBody*/
						},
					}
				],
			},
			{
				"hash":"1IJGU71G60",
				"type":"hud","id":"BoxAudio","position":"relative","x":0,"y":0,"w":"100%","h":59,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
				"itemsAlign":1,"attached":vo.type==="voice"||vo.type==="audio",
				children:[
					{
						"hash":"1IJH3JPK60",
						"type":"hud","id":"Line2","position":"relative","x":0,"y":0,"w":"100%","h":40,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
						"itemsAlign":1,
						children:[
							{
								"hash":"1IJGV580L0",
								"type":BtnText("primary",100,28,(($ln==="CN")?("结束"):("Done")),false,appCfg.sharedAssets+"/hudbox.svg"),"id":"BtnStopRecord","position":"relative",
								"x":0,"y":0,"corner":5,"margin":[0,20,0,0],
								"OnClick":function(event){
									/*#{1IJH016LK1FunctionBody*/
									self.stopRecording();
									/*}#1IJH016LK1FunctionBody*/
								},
							},
							{
								"hash":"1IJH3K5640",
								"type":"text","id":"TxtAudio","position":"relative","x":0,"y":0,"w":"","h":"","margin":[0,20,0,0],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
								"color":cfgColor["fontBodySub"],"text":(($ln==="CN")?("录音中..."):("Recording...")),"fontSize":txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal",
								"textDecoration":"",
							},
							{
								"hash":"1IJGV96PD0",
								"type":BtnText("secondary",100,28,(($ln==="CN")?("播放"):("Play")),false,appCfg.sharedAssets+"/sound.svg"),"id":"BtnPlayAudio","position":"relative",
								"x":0,"y":0,"corner":5,"margin":[0,20,0,0],
								"OnClick":function(event){
									/*#{1IJH016LK2FunctionBody*/
									self.playAudio();
									/*}#1IJH016LK2FunctionBody*/
								},
							},
							{
								"hash":"1IJGVT4LF0",
								"type":BtnText("secondary",100,28,(($ln==="CN")?("下载"):("Download")),false,appCfg.sharedAssets+"/download.svg"),"id":"BtnDownloadAudio","position":"relative",
								"x":0,"y":0,"corner":5,"margin":[0,20,0,0],
								"OnClick":function(event){
									/*#{1IJH016LK4FunctionBody*/
									self.downloadAudio();
									/*}#1IJH016LK4FunctionBody*/
								},
							}
						],
					},
					{
						"hash":"1IJH3J4MH0",
						"type":"hud","id":"Line1","position":"relative","x":0,"y":0,"w":"100%","h":40,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
						"itemsAlign":1,
						children:[
							{
								"hash":"1IJGVAPDA0",
								"type":BtnText("primary",100,28,(($ln==="CN")?("使用"):("Use")),false,appCfg.sharedAssets+"/check_fat.svg"),"id":"BtnUseAudio","position":"relative",
								"x":0,"y":0,"corner":5,"margin":[0,20,0,0],
								"OnClick":function(event){
									/*#{1IJH016LK3FunctionBody*/
									self.useAudio();
									/*}#1IJH016LK3FunctionBody*/
								},
							},
							{
								"hash":"1IJGUFF2C0",
								"type":BtnText("primary",100,28,(($ln==="CN")?("录音"):("Record")),false,appCfg.sharedAssets+"/voice.svg"),"id":"BtnRecord","position":"relative",
								"x":0,"y":0,"corner":5,"margin":[0,20,0,0],
								"OnClick":function(event){
									/*#{1IJH016LK0FunctionBody*/
									self.startRecording();
									/*}#1IJH016LK0FunctionBody*/
								},
							}
						],
					}
				],
			}
		],
		/*#{1HA934NIR1ExtraCSS*/
		/*}#1HA934NIR1ExtraCSS*/
		faces:{
			"audio":{
				/*Line2*/"#1IJH3JPK60":{
					"display":0
				},
				/*BtnStopRecord*/"#1IJGV580L0":{
					"display":0
				},
				/*TxtAudio*/"#1IJH3K5640":{
					"display":0
				},
				/*BtnPlayAudio*/"#1IJGV96PD0":{
					"display":0
				},
				/*BtnDownloadAudio*/"#1IJGVT4LF0":{
					"display":0
				},
				/*Line1*/"#1IJH3J4MH0":{
					"display":1
				},
				/*BtnUseAudio*/"#1IJGVAPDA0":{
					"display":0
				},
				/*BtnRecord*/"#1IJGUFF2C0":{
					"display":1
				}
			},"recording":{
				/*Line2*/"#1IJH3JPK60":{
					"display":1
				},
				/*BtnStopRecord*/"#1IJGV580L0":{
					"display":1
				},
				/*TxtAudio*/"#1IJH3K5640":{
					"display":1
				},
				/*BtnPlayAudio*/"#1IJGV96PD0":{
					"display":0
				},
				/*BtnDownloadAudio*/"#1IJGVT4LF0":{
					"display":0
				},
				/*Line1*/"#1IJH3J4MH0":{
					"display":0
				},
				/*BtnUseAudio*/"#1IJGVAPDA0":{
					"display":0
				},
				/*BtnRecord*/"#1IJGUFF2C0":{
					"display":0
				}
			},"audioReady":{
				/*BtnStopRecord*/"#1IJGV580L0":{
					"display":0
				},
				/*TxtAudio*/"#1IJH3K5640":{
					"display":1
				},
				/*BtnPlayAudio*/"#1IJGV96PD0":{
					"display":1
				},
				/*BtnDownloadAudio*/"#1IJGVT4LF0":{
					"display":1
				},
				/*Line1*/"#1IJH3J4MH0":{
					"display":1
				},
				/*BtnUseAudio*/"#1IJGVAPDA0":{
					"display":1
				},
				/*BtnRecord*/"#1IJGUFF2C0":{
					"display":1
				}
			}
		},
		OnCreate:function(){
			self=this;
			txtContent=self.TxtContent;boxCountdown=self.BoxCountdown;txtCountdown=self.TxtCountdown;boxMenu=self.BoxMenu;boxMenuItems=self.BoxMenuItems;boxAsk=self.BoxAsk;btn1=self.Btn1;btn2=self.Btn2;btn3=self.Btn3;boxInput=self.BoxInput;edInput=self.EdInput;edMemo=self.EdMemo;txtInputHint=self.TxtInputHint;boxCode=self.BoxCode;boxBlock=self.BoxBlock;boxDataView=self.BoxDataView;dvData=self.DvData;btnDataNext=self.BtnDataNext;boxAudio=self.BoxAudio;btnStopRecord=self.BtnStopRecord;txtAudio=self.TxtAudio;btnPlayAudio=self.BtnPlayAudio;btnDownloadAudio=self.BtnDownloadAudio;btnUseAudio=self.BtnUseAudio;btnRecord=self.BtnRecord;
			/*#{1HA934NIR1Create*/
			function OnClick(){
				if(vo.multiSelect){
					this.BtnCheck.checked=!this.BtnCheck.checked;
				}else{
					//txtContent.text+=" ["+this.obj.text+"]";
					self.closeMenu(this.obj);
				}
			}
			function countdown(){
				countdownTimer=null;
				if(state.countdown>0){
					state.countdown--;
					countdownTimer=setTimeout(countdown,1000);
				}else{
					boxCountdown.display=false;
					if(vo.type==="menu"){
						if(vo.multiSelect){
							self.closeMultiMenu();
						}else{
							let hud=boxMenuItems.children[0];
							if(hud){
								hud.OnClick();
							}
						}
					}else if(vo.type==="confirm"){
						self.closeConfirm(1);
					}
				}
			}
			if(vo.type==="menu"){
				let i,n,items,item,css,hud;
				items=vo.items;
				n=items.length;
				for(i=0;i<n;i++){
					item=items[i];
					item.selectable=vo.multiSelect;
					item.wrap=true;
					css={
						type:BtnObject({iconSize:36,h:36,...item}),fontSize:16,margin:[0,0,10,0],maxW:"100%",
						OnClick:OnClick,itemIdx:i,uiEvent:-1,
						show(){
							let icon;
							icon=this.BoxIcon;
							this.alpha=1;
							this.animate({
								type:"in",dx:-50,time:120+this.itemIdx*50,
								OnFinish(){
									this.uiObj.uiEvent=1;
									if(icon){
										icon.animate({type:"pose",scale:1,time:100,easing:"ease-out"});
									}
								}
							});
							if(icon){
								icon.scale=0.75;
							}
						}
					};
					hud=boxMenuItems.appendNewChild(css);
					hud.alpha=0;
					items[i]=hud;
				}
				setTimeout(()=>{
					for(item of items){
						item.show();
					}
				},200);
			}else if(vo.type==="audio"||vo.type==="voice"){
				self.showFace("audio");
			}else if(vo.type==="confirm"){
				let idx=0;
				if(vo.ani!==false){
					if(btn1){
						btn1.display=0;
						btn1.scale=0.8;
						setTimeout(()=>{
							btn1.display=1;
							btn1.animate({type:"pose",scale:1,time:100,easing:"ease-out"});
						},200+idx*50);
						idx++;
					}
					if(btn2){
						btn2.display=0;
						btn2.scale=0.8;
						setTimeout(()=>{
							btn2.display=1;
							btn2.animate({type:"pose",scale:1,time:100,easing:"ease-out"});
						},200+idx*50);
						idx++;
					}
					if(btn3){
						btn3.display=0;
						btn3.scale=0.8;
						setTimeout(()=>{
							btn3.display=1;
							btn3.animate({type:"pose",scale:1,time:100,easing:"ease-out"});
						},200+idx*50);
						idx++;
					}
				}
			}else if(vo.type==="input"){
				let editBox;
				editBox=edInput||edMemo;
				editBox.focus();
			}else if(vo.type==="object"){
				dvData.setObject(vo.template||null,vo.object||null,vo.dvOptions||{edit:vo.edit});
				dvData.OnEdit=self.OnDvEdit;
				self.OnDvEdit();
			}else if(vo.type==="block"){
				let block;
				vo.block.position="relative";
				block=boxBlock.appendNewChild(vo.block);
				block.showBlock(vo.input,(result)=>{
					boxBlock.uiEvent=-1;
					self.doCallback(result);
				});
			}
			if(txtCountdown && state.countdown>0){
				countdown();
			}
			/*}#1HA934NIR1Create*/
		},
		/*#{1HA934NIR1EndCSS*/
		/*}#1HA934NIR1EndCSS*/
	};
	/*#{1HA934NIR1PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.clearCountdown=function(){
		if(countdownTimer){
			clearTimeout(countdownTimer);
		}
		if(boxCountdown){
			boxCountdown.display=false;
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.initCodes=async function(code,orgCode){
		//TODO: Code this:
	};
	
	//------------------------------------------------------------------------
	let willCallback=false;
	let callbackResult=null;
	cssVO.doCallback=function(result){
		if(self.callback){
			self.callback(result);
			return;
		}
		willCallback=true;
		callbackResult=result;
	};
	
	//------------------------------------------------------------------------
	cssVO.setCallback=function(callback){
		self.callback=callback;
		if(willCallback){
			callback(callbackResult);
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.endAsk=function(result){
		if(boxAsk && boxAsk.parent===self){
			self.removeChild(boxAsk);
		}
		if(boxMenu && boxMenu.parent===self){
			self.removeChild(boxMenu);
		}
		if(boxInput && boxInput.parent===self){
			self.removeChild(boxInput);
		}
		if(boxCode && boxCode.parent===self){
			self.removeChild(boxCode);
		}
		if(boxBlock && boxBlock.parent===self){
			self.removeChild(boxBlock);
		}
		self.doCallback(result);
	};
	
	//------------------------------------------------------------------------
	cssVO.cancelAsk=function(result){
		if(boxAsk && boxAsk.parent===self){
			self.removeChild(boxAsk);
		}
		if(boxMenu && boxMenu.parent===self){
			self.removeChild(boxMenu);
		}
		if(boxInput && boxInput.parent===self){
			self.removeChild(boxInput);
		}
		if(boxCode && boxCode.parent===self){
			self.removeChild(boxCode);
		}
		if(boxBlock && boxBlock.parent===self){
			self.removeChild(boxBlock);
		}
		if(result){
			//txtContent.text+=" ["+result+"]";
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.closeConfirm=function(code){
		self.clearCountdown();
		self.removeChild(boxAsk);
		switch(code){
			case 1:
				//txtContent.text+=" ["+(vo.button1||"OK")+"]";
				self.doCallback([vo.button1||"OK",1]);
				return;
			case 0:
				//txtContent.text+=" ["+(vo.button2||"Cancel")+"]";
				self.doCallback([vo.button2||"Cancel",0]);
				return;
			case 2:
				//txtContent.text+=" ["+(vo.button3)+"]";
				self.doCallback([vo.button3,2]);
				return;
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.closeMenu=function(obj){
		self.clearCountdown();
		self.removeChild(boxMenu);
		self.doCallback([obj.text,obj]);
	};
	
	//------------------------------------------------------------------------
	cssVO.closeMultiMenu=function(){
		let items,item,i,n,resultTxt,resultItems;
		self.clearCountdown();
		resultItems=[];
		resultTxt="";
		items=boxMenuItems.children;
		n=items.length;
		for(i=0;i<n;i++){
			item=items[i];
			if(item.BtnCheck.checked){
				resultTxt+=item.obj.text+", ";
				resultItems.push(item.obj);
			}
		}
		if(resultTxt){
			resultTxt=resultTxt.substring(0,resultTxt.length-2);
		}else{
			resultTxt="None";
		}
		//txtContent.text+=" ["+resultTxt+"]";
		self.removeChild(boxMenu);
		self.doCallback([resultTxt,resultItems]);
	};
	
	//------------------------------------------------------------------------
	let curCheck=null;
	let checkIdx=0;
	let lastCheckIdx;
	cssVO.OnDvEdit=async function(){
		let data,checker,checked,thisCheckIdx;
		checker=vo.checkData;
		if(checker instanceof Function){
			btnDataNext.enable=false;
			data=dvData.getEditedVO();
			if(curCheck){
				thisCheckIdx=checkIdx++;
				lastCheckIdx=thisCheckIdx;
				await curCheck;
				if(lastCheckIdx!==thisCheckIdx){
					return;
				}
			}
			checked=checker(data,dvData);
			if(checked instanceof Promise){
				curCheck=checked;
				btnDataNext.enable=!!(await checked);
			}else{
				btnDataNext.enable=!!checked;
			}
		}else{
			let missing;
			missing=dvData.getMissing(false,null);
			if(missing){
				btnDataNext.enable=false;
			}else{
				btnDataNext.enable=true;
			}
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.closeDataView=function(){
		let result,resultText;
		result=dvData.getEditedVO();
		resultText=JSON.stringify(result,null,"\t");
		//txtContent.text+=" ["+resultText+"]";
		self.removeChild(boxDataView);
		self.doCallback([resultText,result]);
	};
	
	//------------------------------------------------------------------------
	cssVO.closeInput=function(){
		let text,val;
		if(edInput){
			val=text=edInput.text;
		}else{
			val=text=edMemo.text;
		}
		if(vo.inputType==="password"){
			text="";
			for(let i=0;i<val.length;i++){
				text+="*";
			}
		}
		self.removeChild(boxInput);
		self.doCallback([text,val]);
	};
	
	//------------------------------------------------------------------------
	cssVO.abort=function(){
		if(boxAsk){
			self.removeChild(boxAsk);
		}
		if(boxInput){
			self.removeChild(boxInput);
		}
		if(boxMenu){
			self.removeChild(boxMenu);
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.openFilePath=async function(){
		let path,result,byteAry;
		path=await VFACT.app.modalDlg(DlgFile,{
			mode:"open",
			path:vo.path||"/",
			options:{
				filter:vo.filter
			}			
		});
		if(path){
			path="/~"+path;
			edInput.text=path;
			//byteAry=await tabFS.readFile(path);
			self.removeChild(boxInput);
			//txtContent.text+=" ["+path+"]";
			self.doCallback([path,null]);
		}
	};
	
	async function arrayBuffer(file){
		if(file.arrayBuffer){
			return file.arrayBuffer();
		}
		return new Promise((onDone,onError)=>{
			let reader=new FileReader();
			reader.onload=function(event) {
				let arrayBuffer = event.target.result;
				onDone(arrayBuffer);
			};
			reader.readAsArrayBuffer(file);
		})
	}
	
	//------------------------------------------------------------------------
	cssVO.useNativeFile=async function(file){
		let buf,byteAry,ext,fileData;
		if(!file){
			return;
		}
		try{
			buf=await arrayBuffer(file);
			byteAry = new Uint8Array(buf);
		}catch(err){
			return;
		}
		//txtContent.text+=" ["+file.name+"]";
		
		self.removeChild(boxInput);
		fileData=byteAry;
		/*fileData=Base64.encode(byteAry);
		switch(ext){
		case ".jpg":
			fileData="data:image/jpeg;base64,"+fileData;
			break;
		case ".png":
			fileData="data:image/png;base64,"+fileData;
			break;
		case ".txt":
			fileData="data:text/plain;base64,"+fileData;
			break;
		case ".json":
			fileData="data:text/json;base64,"+fileData;
			break;
		default:
			fileData="data:application/octet-stream;base64,"+fileData;
			break;
		}*/
		self.doCallback([file.name,fileData]);
	};
	
	//-----------------------------------------------------------------------
	let mediaRecorder=null;
	let audioItem=null;
	let wavUrl=null;
	let wavBlob=null;
	let recordTimer=null;
	let recordStart=0;
	let audioTime=0;
	
	function writeString(view, offset, string) {
		for (let i = 0; i < string.length; i++) {
			view.setUint8(offset + i, string.charCodeAt(i));
		}
	}
	
	function encodeWav(audioBuffer) {
		const numOfChan = audioBuffer.numberOfChannels;
		const sampleRate = audioBuffer.sampleRate;
		const bytesPerSample = 2;
		const blockAlign = numOfChan * bytesPerSample;
		const buffer = new ArrayBuffer(44 + audioBuffer.length * bytesPerSample * numOfChan);
		const view = new window.DataView(buffer);
	
		// WAV Header
		writeString(view, 0, 'RIFF');
		view.setUint32(4, 36 + audioBuffer.length * bytesPerSample * numOfChan, true);
		writeString(view, 8, 'WAVE');
		writeString(view, 12, 'fmt ');
		view.setUint32(16, 16, true);
		view.setUint16(20, 1, true);
		view.setUint16(22, numOfChan, true);
		view.setUint32(24, sampleRate, true);
		view.setUint32(28, sampleRate * blockAlign, true);
		view.setUint16(32, blockAlign, true);
		view.setUint16(34, bytesPerSample * 8, true);
		writeString(view, 36, 'data');
		view.setUint32(40, audioBuffer.length * bytesPerSample * numOfChan, true);
	
		// Write PCM data
		let offset = 44;
		for (let i = 0; i < audioBuffer.length; i++) {
			for (let channel = 0; channel < numOfChan; channel++) {
				let sample = Math.max(-1, Math.min(1, audioBuffer.getChannelData(channel)[i]));
				view.setInt16(offset, sample < 0 ? sample * 0x8000 : sample * 0x7FFF, true);
				offset += bytesPerSample;
			}
		}
		return buffer;
	}
	async function convertWebMToWav(webmBlob) {
		const arrayBuffer = await webmBlob.arrayBuffer();
		const audioBuffer = await new AudioContext().decodeAudioData(arrayBuffer);
	
		// WAV Encode
		const wavData = encodeWav(audioBuffer);
		return new Blob([wavData], { type: 'audio/wav' });
	}
	
	cssVO.startRecording=async function(){
		self.showFace("recording");
		//TODO: Code this:
		recordStart=Date.now();
		const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
		mediaRecorder = new MediaRecorder(stream);
		let audioChunks = [];
		mediaRecorder.ondataavailable = (event) => {
			audioChunks.push(event.data);
		};
	
		mediaRecorder.onstop = async () => {
			const audioBlob = new Blob(audioChunks, { type: 'audio/webm' });
			const audioUrl = URL.createObjectURL(audioBlob);
			audioItem = new Audio(audioUrl);
	
			// 转换为 WAV
			wavBlob = await convertWebMToWav(audioBlob);
			wavUrl = URL.createObjectURL(wavBlob);
		};
	
		mediaRecorder.start();
		
		txtAudio.text=(($ln==="CN")?("正在录音：0秒"):/*EN*/("Recording: 0s"));
		recordTimer=setInterval(()=>{
			let duration = (Date.now() - recordStart) / 1000;
			txtAudio.text=(($ln==="CN")?(`正在录音：${duration.toFixed(2)}秒`):/*EN*/(`Recording: ${duration.toFixed(2)}s`));
		},100);
	};
	
	//-----------------------------------------------------------------------
	cssVO.stopRecording=function(){
		mediaRecorder.stop();
		audioTime=(Date.now() - recordStart) / 1000;
		txtAudio.text=(($ln==="CN")?(`录音长度：${audioTime.toFixed(2)}秒`):/*EN*/(`Recorded: ${audioTime.toFixed(2)}s`));
		clearInterval(recordTimer);
		self.showFace("audioReady");
	};
	
	//-----------------------------------------------------------------------
	cssVO.playAudio=function(){
		if(audioItem){
			audioItem.play();
		}
		btnPlayAudio.enable=false;
		setTimeout(()=>{
			btnPlayAudio.enable=true;
		},1000);
	};
	
	//-----------------------------------------------------------------------
	cssVO.downloadAudio=function(){
		// Create download link:
		const a = document.createElement("a");
		a.href = wavUrl;
		a.download = "recording.wav";
		a.click();
	};
	
	//-----------------------------------------------------------------------
	cssVO.useAudio=async function(){
		let wavdata;
		wavdata=await wavBlob.arrayBuffer();
		wavdata=new Uint8Array(wavdata);
		self.removeChild(boxAudio);
		self.doCallback(["audio.wav",wavdata]);
	};
	/*}#1HA934NIR1PostCSSVO*/
	cssVO.constructor=BoxAskUser;
	return cssVO;
};
/*#{1HA934NIR1ExCodes*/
/*}#1HA934NIR1ExCodes*/

//----------------------------------------------------------------------------
BoxAskUser.exposeAI=async function(hud,appAIVO,opts){
	let exposeVO;
	/*#{1HA934NIR1PreAISpot*/
	/*}#1HA934NIR1PreAISpot*/
	exposeVO=await VFACT.exposeHudAIBaisc(hud,appAIVO,opts);
	exposeVO.type="";
	exposeVO.typeDescription="";
	if(!opts.recursive){
		let subList=await VFACT.genSubHudAIExpose(hud,appAIVO,opts);
		if(subList && subList.length){exposeVO.children=subList;}
	}
	/*#{1HA934NIR1PostAISpot*/
	/*}#1HA934NIR1PostAISpot*/
	return exposeVO;
};

/*#{1HA934NIR0EndDoc*/
/*}#1HA934NIR0EndDoc*/

export default BoxAskUser;
export{BoxAskUser};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1HA934NIR0",
//	"attrs": {
//		"editEnv": {
//			"jaxId": "1HA934NIR2",
//			"attrs": {
//				"device": "Desktop 800x600",
//				"screenW": "800",
//				"screenH": "600",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"jaxId": "1HA934NIR3",
//			"attrs": {}
//		},
//		"model": {
//			"jaxId": "1HA934NIR4",
//			"attrs": {}
//		},
//		"createArgs": {
//			"jaxId": "1HA934NIR5",
//			"attrs": {
//				"vo": {
//					"type": "object",
//					"def": "FlatObj",
//					"jaxId": "1IJGU43UI0",
//					"attrs": {
//						"type": {
//							"type": "string",
//							"valText": "audio"
//						},
//						"text": {
//							"type": "string",
//							"valText": "Please Confirm"
//						},
//						"txtHeader": {
//							"type": "string",
//							"valText": ""
//						},
//						"txtFooter": {
//							"type": "string",
//							"valText": ""
//						},
//						"textColor": {
//							"type": "colorRGBA",
//							"valText": "#cfgColor[\"fontBody\"]"
//						},
//						"hideIcon": {
//							"type": "bool",
//							"valText": "false"
//						},
//						"icon": {
//							"type": "string",
//							"valText": "#appCfg.sharedAssets+\"/help.svg\""
//						},
//						"iconColor": {
//							"type": "colorRGBA",
//							"valText": "#cfgColor[\"fontBody\"]"
//						},
//						"iconBG": {
//							"type": "colorRGBA",
//							"valText": "#cfgColor[\"body\"]"
//						},
//						"iconBorderColor": {
//							"type": "colorRGB",
//							"valText": "#cfgColor[\"fontBodyLit\"]"
//						},
//						"iconBorderSize": {
//							"type": "int",
//							"valText": "1"
//						},
//						"iconCorner": {
//							"type": "int",
//							"valText": "100"
//						},
//						"multiSelect": {
//							"type": "bool",
//							"valText": "true"
//						},
//						"button": {
//							"type": "string",
//							"valText": "Next"
//						},
//						"placeHolder": {
//							"type": "string",
//							"valText": "Place holder"
//						},
//						"initText": {
//							"type": "string",
//							"valText": "Init Text"
//						},
//						"memo": {
//							"type": "bool",
//							"valText": "false"
//						},
//						"countDown": {
//							"type": "int",
//							"valText": "20"
//						}
//					}
//				},
//				"session": {
//					"type": "auto",
//					"valText": "null"
//				}
//			}
//		},
//		"localVars": {
//			"jaxId": "1HA934NIR6",
//			"attrs": {
//				"hideIcon": {
//					"type": "bool",
//					"valText": "#!!vo.hideIcon"
//				},
//				"icon": {
//					"type": "string",
//					"valText": "#vo.icon||(appCfg.sharedAssets+\"/help.svg\")"
//				}
//			}
//		},
//		"oneHud": "false",
//		"state": {
//			"jaxId": "1HA934NIR7",
//			"attrs": {
//				"countdown": {
//					"type": "int",
//					"valText": "#vo.countdown"
//				}
//			}
//		},
//		"segs": {
//			"attrs": []
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"jaxId": "1HA934NIR8",
//			"attrs": {
//				"audio": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IJGVILF10",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IJGVO4230",
//							"attrs": {}
//						}
//					}
//				},
//				"recording": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IJGVK0F50",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IJGVO4231",
//							"attrs": {}
//						}
//					}
//				},
//				"audioReady": {
//					"type": "facetag",
//					"def": "FaceTag",
//					"jaxId": "1IJGVM0E10",
//					"attrs": {
//						"mockup": "false",
//						"previewEntry": "false",
//						"mockupNext": "",
//						"description": "",
//						"preFunc": "false",
//						"faceFunc": "false",
//						"delay": "0",
//						"faceTimes": {
//							"jaxId": "1IJGVO4232",
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"mockupStates": {
//			"jaxId": "1HAA37TBQ0",
//			"attrs": {
//				"Confirm": {
//					"type": "mockState",
//					"def": "MockState",
//					"jaxId": "1HAAIQB850",
//					"attrs": {
//						"createArgs": {
//							"jaxId": "1HA934NIR5",
//							"attrs": {
//								"vo": {
//									"type": "auto",
//									"valText": "#{type:\"confirm\",icon:appCfg.sharedAssets+\"/faces.svg\",iconBG:cfgColor.primary,iconColor:cfgColor.fontPrimary,\tbgColor:cfgColor.body,textColor:cfgColor.fontBody,text:\"Please Confirm:\",button1:\"Yes\",button2:\"No\",button3:\"Abort\"}"
//								}
//							}
//						},
//						"stateObj": {
//							"jaxId": "1HA934NIR7",
//							"attrs": {}
//						}
//					}
//				},
//				"Menu": {
//					"type": "mockState",
//					"def": "MockState",
//					"jaxId": "1HAAIQB851",
//					"attrs": {
//						"createArgs": {
//							"jaxId": "1HA934NIR5",
//							"attrs": {
//								"vo": {
//									"type": "auto",
//									"valText": "#{type:\"menu\",icon:appCfg.sharedAssets+\"/faces.svg\",iconBG:cfgColor.primary,iconColor:cfgColor.fontPrimary,\tbgColor:cfgColor.body,textColor:cfgColor.fontBody,text:\"Please Confirm:\",button:\"Yes\"}"
//								}
//							}
//						},
//						"stateObj": {
//							"jaxId": "1HA934NIR7",
//							"attrs": {}
//						}
//					}
//				},
//				"MultiSelect": {
//					"type": "mockState",
//					"def": "MockState",
//					"jaxId": "1HAAIU8HP0",
//					"attrs": {
//						"createArgs": {
//							"jaxId": "1HA934NIR5",
//							"attrs": {
//								"vo": {
//									"type": "auto",
//									"valText": "#{type:\"menu\",icon:appCfg.sharedAssets+\"/faces.svg\",iconBG:cfgColor.primary,iconColor:cfgColor.fontPrimary,\tbgColor:cfgColor.body,textColor:cfgColor.fontBody,text:\"Please Confirm:\",button:\"Yes\",multiSelect:1}"
//								}
//							}
//						},
//						"stateObj": {
//							"jaxId": "1HA934NIR7",
//							"attrs": {}
//						}
//					}
//				},
//				"Input": {
//					"type": "mockState",
//					"def": "MockState",
//					"jaxId": "1HAAKJDOH0",
//					"attrs": {
//						"createArgs": {
//							"jaxId": "1HA934NIR5",
//							"attrs": {
//								"vo": {
//									"type": "auto",
//									"valText": "#{type:\"input\",icon:appCfg.sharedAssets+\"/faces.svg\",iconBG:cfgColor.primary,iconColor:cfgColor.fontPrimary,\tbgColor:cfgColor.body,textColor:cfgColor.fontBody,text:\"Please input:\",button:\"Yes\",placeHolder:\"please input\",initText:\"text\"}"
//								}
//							}
//						},
//						"stateObj": {
//							"jaxId": "1HA934NIR7",
//							"attrs": {}
//						}
//					}
//				},
//				"Input Memo": {
//					"type": "mockState",
//					"def": "MockState",
//					"jaxId": "1HAAMI7TE0",
//					"attrs": {
//						"createArgs": {
//							"jaxId": "1HA934NIR5",
//							"attrs": {
//								"vo": {
//									"type": "auto",
//									"valText": "#{type:\"input\",icon:appCfg.sharedAssets+\"/faces.svg\",iconBG:cfgColor.primary,iconColor:cfgColor.fontPrimary,\tbgColor:cfgColor.body,textColor:cfgColor.fontBody,text:\"Please input:\",button:\"Yes\",placeHolder:\"please input\",initText:\"text\",memo:1}"
//								}
//							}
//						},
//						"stateObj": {
//							"jaxId": "1HA934NIR7",
//							"attrs": {}
//						}
//					}
//				},
//				"block": {
//					"type": "mockState",
//					"def": "MockState",
//					"jaxId": "1HEJEANSG0",
//					"attrs": {
//						"createArgs": {
//							"jaxId": "1HA934NIR5",
//							"attrs": {
//								"vo": {
//									"type": "auto",
//									"valText": "#{type:\"block\",icon:appCfg.sharedAssets+\"/faces.svg\",iconBG:cfgColor.primary,iconColor:cfgColor.fontPrimary,\tbgColor:cfgColor.body,textColor:cfgColor.fontBody,text:\"Please Confirm:\",button1:\"Yes\",button2:\"No\",button3:\"Abort\"}"
//								},
//								"session": {
//									"type": "auto",
//									"valText": "null"
//								}
//							}
//						},
//						"stateObj": {
//							"jaxId": "1HA934NIR7",
//							"attrs": {}
//						}
//					}
//				},
//				"file": {
//					"type": "mockState",
//					"def": "MockState",
//					"jaxId": "1HENTH7BK0",
//					"attrs": {
//						"createArgs": {
//							"jaxId": "1HA934NIR5",
//							"attrs": {
//								"vo": {
//									"type": "auto",
//									"valText": "#{type:\"input\",icon:appCfg.sharedAssets+\"/faces.svg\",iconBG:cfgColor.primary,iconColor:cfgColor.fontPrimary,\tbgColor:cfgColor.body,textColor:cfgColor.fontBody,text:\"Please input:\",button:\"Yes\",placeHolder:\"please input\",initText:\"text\",file:true}"
//								},
//								"session": {
//									"type": "auto",
//									"valText": "null"
//								}
//							}
//						},
//						"stateObj": {
//							"jaxId": "1HA934NIR7",
//							"attrs": {}
//						}
//					}
//				},
//				"CountDown": {
//					"type": "mockState",
//					"def": "MockState",
//					"jaxId": "1I13MIQVO0",
//					"attrs": {
//						"createArgs": {
//							"jaxId": "1HA934NIR5",
//							"attrs": {
//								"vo": {
//									"type": "auto",
//									"valText": "#{type:\"menu\",icon:appCfg.sharedAssets+\"/faces.svg\",iconBG:cfgColor.primary,iconColor:cfgColor.fontPrimary,\tbgColor:cfgColor.body,textColor:cfgColor.fontBody,text:\"Please Confirm:\",button:\"Yes\",countDown:20}"
//								},
//								"session": {
//									"type": "auto",
//									"valText": "null"
//								}
//							}
//						},
//						"stateObj": {
//							"jaxId": "1HA934NIR7",
//							"attrs": {
//								"countDown": {
//									"type": "int",
//									"valText": "10"
//								}
//							}
//						}
//					}
//				},
//				"HideIcon": {
//					"type": "mockState",
//					"def": "MockState",
//					"jaxId": "1I69964NR0",
//					"attrs": {
//						"createArgs": {
//							"jaxId": "1HA934NIR5",
//							"attrs": {
//								"vo": {
//									"type": "auto",
//									"valText": "#{type:\"confirm\",icon:appCfg.sharedAssets+\"/faces.svg\",iconBG:cfgColor.primary,iconColor:cfgColor.fontPrimary,\tbgColor:cfgColor.body,textColor:cfgColor.fontBody,text:\"Please Confirm:\",button1:\"Yes\",button2:\"No\",button3:\"Abort\",countdown:10,hideIcon:true}"
//								},
//								"session": {
//									"type": "auto",
//									"valText": "null"
//								}
//							}
//						},
//						"stateObj": {
//							"jaxId": "1HA934NIR7",
//							"attrs": {
//								"countdown": {
//									"type": "int",
//									"valText": "#vo.countdown"
//								}
//							}
//						}
//					}
//				}
//			}
//		},
//		"exposeToAI": "true",
//		"descAI": "",
//		"exposeTree2AI": "true",
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1HA934NIR1",
//			"attrs": {
//				"properties": {
//					"jaxId": "1HA934NIR9",
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Relative",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "#hideIcon?[10,10,15,10]:[10,10,15,45]",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Flex Y"
//					}
//				},
//				"subHuds": {
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1HA9DBEF30",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HA9DBEF31",
//									"attrs": {
//										"type": "box",
//										"id": "BoxIcon",
//										"position": "Absolute",
//										"x": "5",
//										"y": "5",
//										"w": "#vo.iconSize||32",
//										"h": "#vo.iconSize||32",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "2",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#vo.iconBG||vo.bgColor||cfgColor.primary",
//										"border": "#vo.iconBorderSize||0",
//										"borderStyle": "Solid",
//										"borderColor": "#vo.iconBorderColor||[0,0,0,1.00]",
//										"corner": "#vo.iconCorner||5",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"attach": "#!hideIcon"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1HA9DBEF40",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HA9DBEF41",
//													"attrs": {
//														"type": "box",
//														"id": "",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "#vo.iconColor||cfgColor.fontPrimary",
//														"border": "0",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]",
//														"maskImage": "#icon",
//														"attach": "#!!vo.icon"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HA9DBEF42",
//													"attrs": {
//														"1IJGVILF10": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IJGVVINP0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IJGVVINP1",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IJGVILF10",
//															"faceTagName": "audio"
//														},
//														"1IJGVK0F50": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IJH3SNGF0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IJH3SNGF1",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IJGVK0F50",
//															"faceTagName": "recording"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HA9DBEF45",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HA9DBEF46",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "image",
//											"jaxId": "1HB2PL2PQ0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HB2PNL4Q0",
//													"attrs": {
//														"type": "image",
//														"id": "",
//														"position": "Absolute",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"image": "#vo.pic",
//														"autoSize": "false",
//														"fitSize": "Fit",
//														"repeat": "true",
//														"alignX": "Left",
//														"alignY": "Top",
//														"attach": "#!!vo.pic"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HB2PNL4Q1",
//													"attrs": {
//														"1IJGVILF10": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IJGVVINP4",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IJGVVINP5",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IJGVILF10",
//															"faceTagName": "audio"
//														},
//														"1IJGVK0F50": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IJH3SNGF4",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IJH3SNGF5",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IJGVK0F50",
//															"faceTagName": "recording"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HB2PNL4Q2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HB2PNL4Q3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1HA9DBEF47",
//									"attrs": {
//										"1IJGVILF10": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IJGVVINP8",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IJGVVINP9",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IJGVILF10",
//											"faceTagName": "audio"
//										},
//										"1IJGVK0F50": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IJH3SNGF8",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IJH3SNGF9",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IJGVK0F50",
//											"faceTagName": "recording"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HA9DBEF410",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HA9DBEF411",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1IC7TCOG70",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IC7TEJ000",
//									"attrs": {
//										"type": "text",
//										"id": "TxtHeader",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "0.7",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,3,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#vo.textColor",
//										"text": "#vo.txtHeader",
//										"font": "",
//										"fontSize": "#txtSize.small",
//										"bold": "false",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Top",
//										"wrap": "false",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0",
//										"attach": "#!!vo.txtHeader"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1IC7TEJ001",
//									"attrs": {
//										"1IJGVILF10": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IJGVVINP12",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IJGVVINP13",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IJGVILF10",
//											"faceTagName": "audio"
//										},
//										"1IJGVK0F50": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IJH3SNGF12",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IJH3SNGF13",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IJGVK0F50",
//											"faceTagName": "recording"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1IC7TEJ002",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IC7TEJ003",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1HAA3CQLS0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HAA3CQLS1",
//									"attrs": {
//										"type": "text",
//										"id": "TxtContent",
//										"position": "Relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#vo.textColor",
//										"text": "#vo.prompt||vo.text",
//										"font": "",
//										"fontSize": "#txtSize.smallPlus",
//										"bold": "false",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Top",
//										"wrap": "true",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "true",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HAA3CQLS2",
//									"attrs": {
//										"1IJGVILF10": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IJGVVINP16",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IJGVVINP17",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IJGVILF10",
//											"faceTagName": "audio"
//										},
//										"1IJGVK0F50": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IJH3SNGF16",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IJH3SNGF17",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IJGVK0F50",
//											"faceTagName": "recording"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HAA3CQLS5",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HAA3CQLS6",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1I13M8KIA0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1I13MAOE70",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxCountdown",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "30",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "[0,0,0,10]",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"attach": "#vo.countdown>0",
//										"contentLayout": "Flex X"
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1I13MBG8P0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1I13MHBPE0",
//													"attrs": {
//														"type": "text",
//														"id": "TxtCountdown",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"w": "100",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBodySub\"]",
//														"text": "${state.countdown},state",
//														"font": "",
//														"fontSize": "#txtSize.big",
//														"bold": "true",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Center",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1I13MHBPE1",
//													"attrs": {
//														"1IJGVILF10": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IJGVVINP20",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IJGVVINP21",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IJGVILF10",
//															"faceTagName": "audio"
//														},
//														"1IJGVK0F50": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IJH3SNGF20",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IJH3SNGF21",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IJGVK0F50",
//															"faceTagName": "recording"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1I13MHBPE2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1I13MHBPE3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1I13MAOE71",
//									"attrs": {
//										"1IJGVILF10": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IJGVVINP24",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IJGVVINP25",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IJGVILF10",
//											"faceTagName": "audio"
//										},
//										"1IJGVK0F50": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IJH3SNGF24",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IJH3SNGF25",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IJGVK0F50",
//											"faceTagName": "recording"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1I13MAOE72",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1I13MAOE73",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1HAADF97V0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HAAI91K60",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxMenu",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "[5,10,10,10]",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex Y",
//										"attach": "#vo.type===\"menu\""
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1HAAICUAP0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HAAIQB852",
//													"attrs": {
//														"type": "hud",
//														"id": "BoxMenuItems",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "20",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": ""
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnObject.js",
//															"jaxId": "1HAAIP3VS0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1HAAIQB853",
//																	"attrs": {
//																		"obj": "{\"text\":\"Object\",\"icon\":\"\",\"iconColor\":[255,0,0,1]}",
//																		"converter": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1HAAIQB854",
//																	"attrs": {
//																		"type": "#null#>BtnObject({\"text\":\"Object\",\"icon\":\"\",\"iconColor\":[255,0,0,1]},null)",
//																		"id": "",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"maxW": "360",
//																		"attach": "#!vo.multiSelect"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HAAIQB855",
//																	"attrs": {
//																		"1IJGVILF10": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJGVVINP28",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJGVVINP29",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IJGVILF10",
//																			"faceTagName": "audio"
//																		},
//																		"1IJGVK0F50": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJH3SNGF28",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJH3SNGF29",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IJGVK0F50",
//																			"faceTagName": "recording"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HAAIQB856",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HAAIQB857",
//																	"attrs": {}
//																},
//																"mockup": "true",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1HAAIQB858",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnObject.js",
//															"jaxId": "1HAAIQDS10",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1HAAIQDS11",
//																	"attrs": {
//																		"obj": "{\"text\":\"Object\",\"icon\":\"\",\"iconColor\":[255,0,0,1]}",
//																		"converter": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1HAAIQDS12",
//																	"attrs": {
//																		"type": "#null#>BtnObject({\"text\":\"Object\",\"icon\":\"\",\"iconColor\":[255,0,0,1]},null)",
//																		"id": "",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"maxW": "360",
//																		"attach": "#!vo.multiSelect"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HAAIQDS13",
//																	"attrs": {
//																		"1IJGVILF10": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJGVVINP32",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJGVVINP33",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IJGVILF10",
//																			"faceTagName": "audio"
//																		},
//																		"1IJGVK0F50": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJH3SNGF32",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJH3SNGF33",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IJGVK0F50",
//																			"faceTagName": "recording"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HAAIQDS14",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HAAIQDS15",
//																	"attrs": {}
//																},
//																"mockup": "true",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1HAAIQDS16",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnObject.js",
//															"jaxId": "1HAAISI4C0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1HAAISI4C1",
//																	"attrs": {
//																		"obj": "#{\"text\":\"Object\",selectable:true,checked:1}",
//																		"converter": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1HAAISI4C2",
//																	"attrs": {
//																		"type": "#null#>BtnObject({\"text\":\"Object\",selectable:true,checked:1},null)",
//																		"id": "",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"maxW": "360",
//																		"attach": "#!!vo.multiSelect"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HAAISI4C3",
//																	"attrs": {
//																		"1IJGVILF10": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJGVVINP36",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJGVVINP37",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IJGVILF10",
//																			"faceTagName": "audio"
//																		},
//																		"1IJGVK0F50": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJH3SNGF36",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJH3SNGF37",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IJGVK0F50",
//																			"faceTagName": "recording"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HAAISI4C4",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HAAISI4C5",
//																	"attrs": {}
//																},
//																"mockup": "true",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1HAAISI4C6",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnObject.js",
//															"jaxId": "1HAAJ9POB0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1HAAJ9POB1",
//																	"attrs": {
//																		"obj": "#{\"text\":\"Array\",selectable:true,checked:0}",
//																		"converter": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1HAAJ9POB2",
//																	"attrs": {
//																		"type": "#null#>BtnObject({\"text\":\"Array\",selectable:true,checked:0},null)",
//																		"id": "",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"maxW": "360",
//																		"attach": "#!!vo.multiSelect"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HAAJ9POB3",
//																	"attrs": {
//																		"1IJGVILF10": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJGVVINP40",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJGVVINP41",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IJGVILF10",
//																			"faceTagName": "audio"
//																		},
//																		"1IJGVK0F50": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJH3SNGF40",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJH3SNGF41",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IJGVK0F50",
//																			"faceTagName": "recording"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HAAJ9POB4",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HAAJ9POB5",
//																	"attrs": {}
//																},
//																"mockup": "true",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1HAAJ9POB6",
//																	"attrs": {}
//																}
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1HAAIQB859",
//													"attrs": {
//														"1IJGVILF10": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IJGVVINP44",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IJGVVINP45",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IJGVILF10",
//															"faceTagName": "audio"
//														},
//														"1IJGVK0F50": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IJH3SNGF44",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IJH3SNGF45",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IJGVK0F50",
//															"faceTagName": "recording"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HAAIQB8510",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HAAIQB8511",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "true",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnText.js",
//											"jaxId": "1HAAIE08L0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1HAAIQB8512",
//													"attrs": {
//														"style": "primary",
//														"w": "60",
//														"h": "20",
//														"text": "#vo.button||\"OK\"",
//														"outlined": "false",
//														"icon": ""
//													}
//												},
//												"properties": {
//													"jaxId": "1HAAIQB860",
//													"attrs": {
//														"type": "#null#>BtnText(\"primary\",60,20,vo.button||\"OK\",false,\"\")",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"margin": "[10,0,0,0]",
//														"corner": "3",
//														"attach": "#!!vo.multiSelect"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HAAIQB861",
//													"attrs": {
//														"1IJGVILF10": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IJGVVINP48",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IJGVVINP49",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IJGVILF10",
//															"faceTagName": "audio"
//														},
//														"1IJGVK0F50": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IJH3SNGG0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IJH3SNGG1",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IJGVK0F50",
//															"faceTagName": "recording"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HAAIQB862",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1HAAK4ARU0",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1HAAK4KAU0",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1HAAIQB863",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"jaxId": "1HAAIQB864",
//													"attrs": {
//														"Slot1H2F6U36O0": {
//															"jaxId": "1HAAIQB865",
//															"attrs": {
//																"subHuds": {
//																	"attrs": []
//																},
//																"container": "true"
//															}
//														}
//													}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1HAAI91K67",
//									"attrs": {
//										"1IJGVILF10": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IJGVVINP52",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IJGVVINP53",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IJGVILF10",
//											"faceTagName": "audio"
//										},
//										"1IJGVK0F50": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IJH3SNGG4",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IJH3SNGG5",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IJGVK0F50",
//											"faceTagName": "recording"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HAAI91K68",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HAAI91K69",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1HAA3H1FE0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HAA3NR1A0",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxAsk",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[5,0,0,0]",
//										"padding": "[0,20,0,20]",
//										"minW": "",
//										"minH": "40",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex X",
//										"subAlign": "Start",
//										"itemsAlign": "Center",
//										"itemsWrap": "Wrap",
//										"attach": "#vo.type===\"confirm\""
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnText.js",
//											"jaxId": "1HAA3IFOF0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1HAA3L5VK0",
//													"attrs": {
//														"style": "primary",
//														"w": "100",
//														"h": "24",
//														"text": "#vo.button1||\"OK\"",
//														"outlined": "false",
//														"icon": ""
//													}
//												},
//												"properties": {
//													"jaxId": "1HAA3L5VK1",
//													"attrs": {
//														"type": "#null#>BtnText(\"primary\",100,24,vo.button1||\"OK\",false,\"\")",
//														"id": "Btn1",
//														"position": "relative",
//														"x": "50",
//														"y": "12",
//														"display": "On",
//														"face": "",
//														"corner": "3",
//														"margin": "[5,15,5,0]",
//														"anchorH": "Center",
//														"anchorV": "Center"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HAA3L5VK2",
//													"attrs": {
//														"1IJGVILF10": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IJGVVINP56",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IJGVVINP57",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IJGVILF10",
//															"faceTagName": "audio"
//														},
//														"1IJGVK0F50": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IJH3SNGG8",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IJH3SNGG9",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IJGVK0F50",
//															"faceTagName": "recording"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HAA3L5VK3",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1HAACN4G30",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1HAACNC060",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1HAA3L5VK4",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1HAA3L5VK5",
//													"attrs": {
//														"Slot1H2F6U36O0": {
//															"jaxId": "1HAA3L5VK6",
//															"attrs": {
//																"subHuds": {
//																	"attrs": []
//																},
//																"container": "true"
//															}
//														}
//													}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnText.js",
//											"jaxId": "1HAA3L6LG0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1HAA3L6LG1",
//													"attrs": {
//														"style": "warning",
//														"w": "100",
//														"h": "24",
//														"text": "#vo.button2||\"Cancel\"",
//														"outlined": "false",
//														"icon": ""
//													}
//												},
//												"properties": {
//													"jaxId": "1HAA3L6LG2",
//													"attrs": {
//														"type": "#null#>BtnText(\"warning\",100,24,vo.button2||\"Cancel\",false,\"\")",
//														"id": "Btn2",
//														"position": "relative",
//														"x": "50",
//														"y": "12",
//														"display": "On",
//														"face": "",
//														"margin": "[5,15,5,0]",
//														"corner": "3",
//														"attach": "#vo.button2",
//														"anchorH": "Center",
//														"anchorV": "Center"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HAA3L6LG3",
//													"attrs": {
//														"1IJGVILF10": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IJGVVINP60",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IJGVVINP61",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IJGVILF10",
//															"faceTagName": "audio"
//														},
//														"1IJGVK0F50": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IJH3SNGG12",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IJH3SNGG13",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IJGVK0F50",
//															"faceTagName": "recording"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HAA3L6LG4",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1HAACNIF10",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1HAACNU2D0",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1HAA3L6LG5",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1HAA3L6LG6",
//													"attrs": {
//														"Slot1H2F6U36O0": {
//															"jaxId": "1HAA3L6LG7",
//															"attrs": {
//																"subHuds": {
//																	"attrs": []
//																},
//																"container": "true"
//															}
//														}
//													}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnText.js",
//											"jaxId": "1HAA3UKHN0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1HAA3UKHN1",
//													"attrs": {
//														"style": "secondary",
//														"w": "100",
//														"h": "24",
//														"text": "#vo.button3",
//														"outlined": "false",
//														"icon": ""
//													}
//												},
//												"properties": {
//													"jaxId": "1HAA3UKHN2",
//													"attrs": {
//														"type": "#null#>BtnText(\"secondary\",100,24,vo.button3,false,\"\")",
//														"id": "Btn3",
//														"position": "relative",
//														"x": "50",
//														"y": "12",
//														"display": "On",
//														"face": "",
//														"margin": "[5,15,5,0]",
//														"corner": "3",
//														"attach": "#vo.button3",
//														"anchorH": "Center",
//														"anchorV": "Center"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HAA3UKHN3",
//													"attrs": {
//														"1IJGVILF10": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IJGVVINP64",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IJGVVINP65",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IJGVILF10",
//															"faceTagName": "audio"
//														},
//														"1IJGVK0F50": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IJH3SNGG16",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IJH3SNGG17",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IJGVK0F50",
//															"faceTagName": "recording"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HAA3UKHN4",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1HAACO2RQ0",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1HAACO7I40",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1HAA3UKHN5",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1HAA3UKHO0",
//													"attrs": {
//														"Slot1H2F6U36O0": {
//															"jaxId": "1HAA3UKHO1",
//															"attrs": {
//																"subHuds": {
//																	"attrs": []
//																},
//																"container": "true"
//															}
//														}
//													}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1HAA3NR1A1",
//									"attrs": {
//										"1IJGVILF10": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IJGVVINP68",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IJGVVINP69",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IJGVILF10",
//											"faceTagName": "audio"
//										},
//										"1IJGVK0F50": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IJH3SNGG20",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IJH3SNGG21",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IJGVK0F50",
//											"faceTagName": "recording"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HAA3NR1A2",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HAA3NR1A3",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1HAAKRDC20",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HAAKRDC21",
//									"attrs": {
//										"type": "box",
//										"id": "BoxInput",
//										"position": "relative",
//										"x": "10",
//										"y": "0",
//										"w": "100%-20",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "30",
//										"maxW": "360",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "[255,255,255,1.00]",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "3",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "1",
//										"shadowBlur": "4",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.30]",
//										"contentLayout": "Flex Y",
//										"attach": "#vo.type===\"input\""
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1HAAKRDC22",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HAAKRDC23",
//													"attrs": {
//														"type": "hud",
//														"id": "",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "[5,0,5,0]",
//														"minW": "",
//														"minH": "20",
//														"maxW": "",
//														"maxH": "200",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex X",
//														"traceSize": "true",
//														"itemsAlign": "Center"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1HENTEQ6L0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1HENTH7BK1",
//																	"attrs": {
//																		"style": "\"front\"",
//																		"w": "28",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/folder.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1HENTH7BK2",
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"front\",28,0,appCfg.sharedAssets+\"/folder.svg\",null)",
//																		"id": "BtnOpenFile",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"attach": "#vo.file && vo.file!==\"native\""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HENTH7BK3",
//																	"attrs": {
//																		"1IJGVILF10": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJGVVINP72",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJGVVINP73",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IJGVILF10",
//																			"faceTagName": "audio"
//																		},
//																		"1IJGVK0F50": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJH3SNGG24",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJH3SNGG25",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IJGVK0F50",
//																			"faceTagName": "recording"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HENTH7BK4",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HENTHD4Q0",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1HENTHLIQ0",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1HENTH7BK5",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1HENTH7BK6",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1HF65I8TR0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1HF65I8TR1",
//																	"attrs": {
//																		"style": "\"front\"",
//																		"w": "28",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/folder.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1HF65I8TR2",
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"front\",28,0,appCfg.sharedAssets+\"/folder.svg\",null)",
//																		"id": "BtnOpenNative",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"attach": "#vo.file===\"native\""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HF65I8TR3",
//																	"attrs": {
//																		"1IJGVILF10": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJGVVINP76",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJGVVINP77",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IJGVILF10",
//																			"faceTagName": "audio"
//																		},
//																		"1IJGVK0F50": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJH3SNGG28",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJH3SNGG29",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IJGVK0F50",
//																			"faceTagName": "recording"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HF65I8TR4",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HF65I8TS2",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "true",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1HF65I8TS3",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "edit",
//															"jaxId": "1HAALRDJS0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAAM2RS10",
//																	"attrs": {
//																		"type": "edit",
//																		"id": "EdInput",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%-80",
//																		"h": "30",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"inputType": "#vo.inputType||\"text\"",
//																		"text": "#vo.initText||vo.text||\"\"",
//																		"placeHolder": "#vo.placeholder||vo.tip||\"\"",
//																		"color": "[0,0,0]",
//																		"bgColor": "[255,255,255,1.00]",
//																		"font": "",
//																		"fontSize": "16",
//																		"outline": "0",
//																		"border": "[0,0,1,0]",
//																		"borderStyle": "Solid",
//																		"borderColor": "[0,0,0,1.00]",
//																		"corner": "0",
//																		"selectOnFocus": "true",
//																		"spellCheck": "true",
//																		"attach": "#!vo.memo"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HAAM2RS11",
//																	"attrs": {
//																		"1IJGVILF10": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJGVVINP80",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJGVVINP81",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IJGVILF10",
//																			"faceTagName": "audio"
//																		},
//																		"1IJGVK0F50": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJH3SNGG32",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJH3SNGG33",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IJGVK0F50",
//																			"faceTagName": "recording"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HAAM2RS12",
//																	"attrs": {
//																		"OnKeyDown": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HAAMBD940",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1HAAMBFJ20",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1HAAM2RS13",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "memo",
//															"jaxId": "1HAAKRDC30",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAAKRDC31",
//																	"attrs": {
//																		"type": "memo",
//																		"id": "EdMemo",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%-50",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "20",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"text": "#vo.initText||vo.text",
//																		"color": "#cfgColor[\"fontBody\"]",
//																		"bgColor": "#cfgColor[\"body\"]",
//																		"font": "",
//																		"fontSize": "#txtSize.mid",
//																		"outline": "0",
//																		"border": "[0,0,1,0]",
//																		"borderStyle": "Solid",
//																		"borderColor": "[0,0,0,0.5]",
//																		"corner": "0",
//																		"readOnly": "false",
//																		"selectOnFocus": "true",
//																		"spellCheck": "true",
//																		"flex": "true",
//																		"attach": "#!!vo.memo"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HAAKRDC32",
//																	"attrs": {
//																		"1IJGVILF10": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJGVVINQ0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJGVVINQ1",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IJGVILF10",
//																			"faceTagName": "audio"
//																		},
//																		"1IJGVK0F50": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJH3SNGG36",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJH3SNGG37",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IJGVK0F50",
//																			"faceTagName": "recording"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HAAKRDC40",
//																	"attrs": {
//																		"OnInput": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HAAKRDC41",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1HAAKRDC42",
//																					"attrs": {}
//																				},
//																				"seg": ""
//																			}
//																		},
//																		"OnKeyDown": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HAAKRDC43",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1HAAKRDC44",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1HAAKRDC45",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1HAAKRDC46",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1HAAKRDC47",
//																	"attrs": {
//																		"style": "\"front\"",
//																		"w": "30",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/send.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"jaxId": "1HAAKRDC48",
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"front\",30,0,appCfg.sharedAssets+\"/send.svg\",null)",
//																		"id": "BtnSend",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"margin": "[0,0,0,10]",
//																		"padding": "2",
//																		"anchorV": "Top",
//																		"autoLayout": "true"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HAAKRDC49",
//																	"attrs": {
//																		"1IJGVILF10": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJGVVINQ4",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJGVVINQ5",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IJGVILF10",
//																			"faceTagName": "audio"
//																		},
//																		"1IJGVK0F50": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJH3SNGG40",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJH3SNGG41",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IJGVK0F50",
//																			"faceTagName": "recording"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HAAKRDC52",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HAAKRDC53",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1HAAKRDC54",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1HAAKRDC55",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1HAAKRDC56",
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1HAAKRDC57",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HAAKRDC58",
//																	"attrs": {
//																		"type": "text",
//																		"id": "TxtInputHint",
//																		"position": "Absolute",
//																		"x": "15",
//																		"y": "0",
//																		"w": "100",
//																		"h": "100%",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "#(!vo.initText)&&(!vo.text)",
//																		"clip": "Off",
//																		"uiEvent": "Tree Off",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontBodyLit\"]",
//																		"text": "#vo.placeholder||vo.tip||\"\"",
//																		"font": "",
//																		"fontSize": "#txtSize.mid",
//																		"bold": "false",
//																		"italic": "true",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Center",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"lineClamp": "0",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0",
//																		"attach": "#!!vo.memo"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HAAKRDC59",
//																	"attrs": {
//																		"1IJGVILF10": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJGVVINQ8",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJGVVINQ9",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IJGVILF10",
//																			"faceTagName": "audio"
//																		},
//																		"1IJGVK0F50": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJH3SNGG44",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJH3SNGG45",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IJGVK0F50",
//																			"faceTagName": "recording"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HAAKRDC516",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HAAKRDC517",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true"
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1HAAKRDC518",
//													"attrs": {
//														"1IJGVILF10": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IJGVVINQ12",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IJGVVINQ13",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IJGVILF10",
//															"faceTagName": "audio"
//														},
//														"1IJGVK0F50": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IJH3SNGG48",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IJH3SNGG49",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IJGVK0F50",
//															"faceTagName": "recording"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HAAKRDC72",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HAAKRDC73",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1HAAL48AG0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HAAL5BJ90",
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "relative",
//														"x": "10",
//														"y": "0",
//														"w": "100%-20",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBodySub\"]",
//														"text": "New line: Shift+Enter",
//														"font": "",
//														"fontSize": "#txtSize.small",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "false",
//														"lineClamp": "0",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0",
//														"attach": "#vo.memo"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1HAAL5BJ91",
//													"attrs": {
//														"1IJGVILF10": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IJGVVINQ16",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IJGVVINQ17",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IJGVILF10",
//															"faceTagName": "audio"
//														},
//														"1IJGVK0F50": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IJH3SNGG52",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IJH3SNGG53",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IJGVK0F50",
//															"faceTagName": "recording"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HAAL5BJ92",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HAAL5BJ93",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1HAAKRDC825",
//									"attrs": {
//										"1IJGVILF10": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IJGVVINQ20",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IJGVVINQ21",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IJGVILF10",
//											"faceTagName": "audio"
//										},
//										"1IJGVK0F50": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IJH3SNGG56",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IJH3SNGG57",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IJGVK0F50",
//											"faceTagName": "recording"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HAAKRDC832",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HAAKRDC833",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1HBIS5UIR0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HBIS5UIR1",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxCode",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[10,0,0,0]",
//										"padding": "[0,20,0,20]",
//										"minW": "",
//										"minH": "40",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex Y",
//										"subAlign": "Start",
//										"itemsAlign": "Center",
//										"itemsWrap": "Wrap",
//										"attach": "#vo.type===\"code\""
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1HBISLN7M0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HBISS1QQ0",
//													"attrs": {
//														"type": "box",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "#cfgColor[\"body\"]",
//														"border": "1",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]",
//														"contentLayout": "Flex Y"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "box",
//															"jaxId": "1HBISSGF50",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HBISTQUU0",
//																	"attrs": {
//																		"type": "box",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "10",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"background": "#cfgColor[\"secondary\"]",
//																		"border": "0",
//																		"borderStyle": "Solid",
//																		"borderColor": "[0,0,0,1.00]",
//																		"corner": "0",
//																		"shadow": "false",
//																		"shadowX": "2",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowSpread": "0",
//																		"shadowColor": "[0,0,0,0.50]"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HBISTQUU1",
//																	"attrs": {
//																		"1IJGVILF10": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJGVVINQ24",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJGVVINQ25",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IJGVILF10",
//																			"faceTagName": "audio"
//																		},
//																		"1IJGVK0F50": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJH3SNGG60",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJH3SNGG61",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IJGVK0F50",
//																			"faceTagName": "recording"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HBISTQUU2",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HBISTQUU3",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1HBIST3QG0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HBIT7NV60",
//																	"attrs": {
//																		"type": "hud",
//																		"id": "BoxCodes",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "300",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": ""
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HBIT7NV61",
//																	"attrs": {
//																		"1IJGVILF10": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJGVVINQ28",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJGVVINQ29",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IJGVILF10",
//																			"faceTagName": "audio"
//																		},
//																		"1IJGVK0F50": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJH3SNGG64",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJH3SNGG65",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IJGVK0F50",
//																			"faceTagName": "recording"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HBIT7NV62",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HBIT7NV63",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"exposeContainer": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "box",
//															"jaxId": "1HBISTSUE0",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1HBISTSUE1",
//																	"attrs": {
//																		"type": "box",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "10",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"background": "#cfgColor[\"secondary\"]",
//																		"border": "0",
//																		"borderStyle": "Solid",
//																		"borderColor": "[0,0,0,1.00]",
//																		"corner": "0",
//																		"shadow": "false",
//																		"shadowX": "2",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowSpread": "0",
//																		"shadowColor": "[0,0,0,0.50]"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HBISTSUE2",
//																	"attrs": {
//																		"1IJGVILF10": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJGVVINQ32",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJGVVINQ33",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IJGVILF10",
//																			"faceTagName": "audio"
//																		},
//																		"1IJGVK0F50": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJH3SNGG68",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJH3SNGG69",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IJGVK0F50",
//																			"faceTagName": "recording"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HBISTSUE3",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1HBISTSUE4",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false"
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1HBISS1QQ1",
//													"attrs": {
//														"1IJGVILF10": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IJGVVINQ36",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IJGVVINQ37",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IJGVILF10",
//															"faceTagName": "audio"
//														},
//														"1IJGVK0F50": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IJH3SNGG72",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IJH3SNGG73",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IJGVK0F50",
//															"faceTagName": "recording"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HBISS1QQ2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HBISS1QQ3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1HBISOTQN0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1HBISS1QQ4",
//													"attrs": {
//														"type": "hud",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "30",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "[0,10,0,10]",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex X"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnText.js",
//															"jaxId": "1HBISPSNU0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1HBISPSNU1",
//																	"attrs": {
//																		"style": "primary",
//																		"w": "100",
//																		"h": "25",
//																		"text": "Apply",
//																		"outlined": "false",
//																		"icon": ""
//																	}
//																},
//																"properties": {
//																	"jaxId": "1HBISPSNU2",
//																	"attrs": {
//																		"type": "#null#>BtnText(\"primary\",100,25,\"Apply\",false,\"\")",
//																		"id": "BtnApplyCode",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"corner": "3",
//																		"margin": "[5,15,5,0]"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HBISPSNU3",
//																	"attrs": {
//																		"1IJGVILF10": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJGVVINQ40",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJGVVINQ41",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IJGVILF10",
//																			"faceTagName": "audio"
//																		},
//																		"1IJGVK0F50": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJH3SNGG76",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJH3SNGG77",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IJGVK0F50",
//																			"faceTagName": "recording"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HBISPSNU4",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HBISPSNU5",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1HBISPSNU6",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1HBISPSNU7",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1HBISPSNU8",
//																	"attrs": {
//																		"Slot1H2F6U36O0": {
//																			"jaxId": "1HBISPSNU9",
//																			"attrs": {
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"container": "true"
//																			}
//																		}
//																	}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnText.js",
//															"jaxId": "1HBISQGHA0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1HBISQGHA1",
//																	"attrs": {
//																		"style": "warning",
//																		"w": "100",
//																		"h": "25",
//																		"text": "Cancel",
//																		"outlined": "false",
//																		"icon": ""
//																	}
//																},
//																"properties": {
//																	"jaxId": "1HBISQGHA2",
//																	"attrs": {
//																		"type": "#null#>BtnText(\"warning\",100,25,\"Cancel\",false,\"\")",
//																		"id": "BtnAbortCode",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"margin": "[5,15,5,0]",
//																		"corner": "3"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1HBISQGHA3",
//																	"attrs": {
//																		"1IJGVILF10": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJGVVINQ44",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJGVVINQ45",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IJGVILF10",
//																			"faceTagName": "audio"
//																		},
//																		"1IJGVK0F50": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJH3SNGG80",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJH3SNGG81",
//																					"attrs": {}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IJGVK0F50",
//																			"faceTagName": "recording"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1HBISQGHA4",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HBISQGHA5",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1HBISQGHA6",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1HBISQGHA7",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"jaxId": "1HBISQGHA8",
//																	"attrs": {
//																		"Slot1H2F6U36O0": {
//																			"jaxId": "1HBISQGHA9",
//																			"attrs": {
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"container": "true"
//																			}
//																		}
//																	}
//																}
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1HBISS1QQ5",
//													"attrs": {
//														"1IJGVILF10": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IJGVVINQ48",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IJGVVINQ49",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IJGVILF10",
//															"faceTagName": "audio"
//														},
//														"1IJGVK0F50": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IJH3SNGG84",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IJH3SNGG85",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IJGVK0F50",
//															"faceTagName": "recording"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1HBISS1QQ6",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1HBISS1QQ7",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1HBIS5UIT15",
//									"attrs": {
//										"1IJGVILF10": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IJGVVINQ52",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IJGVVINQ53",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IJGVILF10",
//											"faceTagName": "audio"
//										},
//										"1IJGVK0F50": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IJH3SNGG88",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IJH3SNGG89",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IJGVK0F50",
//											"faceTagName": "recording"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HBIS5UIT16",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HBIS5UIT17",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1HEJE92P70",
//							"attrs": {
//								"properties": {
//									"jaxId": "1HEJE92P71",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxBlock",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[10,0,0,0]",
//										"padding": "[0,20,0,20]",
//										"minW": "",
//										"minH": "40",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex X",
//										"subAlign": "Start",
//										"itemsAlign": "Center",
//										"itemsWrap": "Wrap",
//										"attach": "#vo.type===\"block\""
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1HEJE92P825",
//									"attrs": {
//										"1IJGVILF10": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IJGVVINQ56",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IJGVVINQ57",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IJGVILF10",
//											"faceTagName": "audio"
//										},
//										"1IJGVK0F50": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IJH3SNGG92",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IJH3SNGG93",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IJGVK0F50",
//											"faceTagName": "recording"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1HEJE92P826",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1HEJE92P827",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1IC7TIVS00",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IC7TIVS01",
//									"attrs": {
//										"type": "text",
//										"id": "TxtFooter",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "0.7",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[0,0,3,0]",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#vo.textColor",
//										"text": "#vo.txtFooter",
//										"font": "",
//										"fontSize": "#txtSize.small",
//										"bold": "false",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Top",
//										"wrap": "false",
//										"ellipsis": "false",
//										"lineClamp": "0",
//										"select": "false",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0",
//										"attach": "#!!vo.txtFooter"
//									}
//								},
//								"subHuds": {
//									"attrs": []
//								},
//								"faces": {
//									"jaxId": "1IC7TIVS02",
//									"attrs": {
//										"1IJGVILF10": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IJGVVINQ60",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IJGVVINQ61",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IJGVILF10",
//											"faceTagName": "audio"
//										},
//										"1IJGVK0F50": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IJH3SNGG96",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IJH3SNGG97",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IJGVK0F50",
//											"faceTagName": "recording"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1IC7TIVS03",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IC7TIVS04",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1IC90NK8F0",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IC90PU500",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxDataView",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"attach": "#vo.type===\"object\""
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/DataView.js",
//											"jaxId": "1IC90O52S0",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1IC90O52S1",
//													"attrs": {
//														"box": "null",
//														"template": "null",
//														"dataObj": "null",
//														"property": "",
//														"options": {
//															"jaxId": "1IC90O52S2",
//															"attrs": {
//																"titleHeight": "30",
//																"titleSize": "18",
//																"titleColor": "#cfgColor[\"fontBody\"]",
//																"titleBold": "true",
//																"lineHeight": "25",
//																"lineGap": "5",
//																"labelSize": "12",
//																"labelColor": "#cfgColor[\"fontBody\"]",
//																"labelBold": "true",
//																"labelLine": "true",
//																"valueSize": "14",
//																"valueColor": "#cfgColor[\"fontBody\"]",
//																"valueBold": "false",
//																"segHeight": "20",
//																"segSize": "14",
//																"segBold": "true",
//																"segColor": "#cfgColor[\"fontBody\"]",
//																"trace": "false",
//																"edit": "true",
//																"noteSize": "12",
//																"autoCollapse": "false",
//																"hideCollapse": "false",
//																"valueRightAlign": "false",
//																"gridLine": "false",
//																"labelWidth": "0"
//															}
//														},
//														"title": ""
//													}
//												},
//												"properties": {
//													"jaxId": "1IC90O52T0",
//													"attrs": {
//														"type": "#null#>DataView(null,null,null,\"\",{\"titleHeight\":30,\"titleSize\":18,\"titleColor\":cfgColor[\"fontBody\"],\"titleBold\":true,\"lineHeight\":25,\"lineGap\":5,\"labelSize\":12,\"labelColor\":cfgColor[\"fontBody\"],\"labelBold\":true,\"labelLine\":true,\"valueSize\":14,\"valueColor\":cfgColor[\"fontBody\"],\"valueBold\":false,\"segHeight\":20,\"segSize\":14,\"segBold\":true,\"segColor\":cfgColor[\"fontBody\"],\"trace\":false,\"edit\":true,\"noteSize\":12,\"autoCollapse\":false,\"hideCollapse\":false,\"valueRightAlign\":false,\"gridLine\":false,\"labelWidth\":0},\"\")",
//														"id": "DvData",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": ""
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IC90O52T1",
//													"attrs": {
//														"1IJGVILF10": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IJGVVINQ64",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IJGVVINQ65",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IJGVILF10",
//															"faceTagName": "audio"
//														},
//														"1IJGVK0F50": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IJH3SNGG100",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IJH3SNGG101",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IJGVK0F50",
//															"faceTagName": "recording"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IC90O52T2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IC90O52T3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1IC90O52T4",
//													"attrs": {}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnText.js",
//											"jaxId": "1IC90O7S10",
//											"attrs": {
//												"createArgs": {
//													"jaxId": "1IC90O7S11",
//													"attrs": {
//														"style": "primary",
//														"w": "100",
//														"h": "20",
//														"text": "#vo.button||(($ln===\"CN\")?(\"继续\"):(\"Next\"))",
//														"outlined": "false",
//														"icon": ""
//													}
//												},
//												"properties": {
//													"jaxId": "1IC90O7S12",
//													"attrs": {
//														"type": "#null#>BtnText(\"primary\",100,20,vo.button||(($ln===\"CN\")?(\"继续\"):(\"Next\")),false,\"\")",
//														"id": "BtnDataNext",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"margin": "[10,0,0,0]",
//														"corner": "3",
//														"attach": "true"
//													}
//												},
//												"subHuds": {
//													"attrs": []
//												},
//												"faces": {
//													"jaxId": "1IC90O7S13",
//													"attrs": {
//														"1IJGVILF10": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IJGVVINQ68",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IJGVVINQ69",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IJGVILF10",
//															"faceTagName": "audio"
//														},
//														"1IJGVK0F50": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IJH3SNGG104",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IJH3SNGG105",
//																	"attrs": {}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IJGVK0F50",
//															"faceTagName": "recording"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IC90O7S14",
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1IC90O7S20",
//															"attrs": {
//																"callArgs": {
//																	"jaxId": "1IC90O7S21",
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"jaxId": "1IC90O7S22",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "true",
//												"containerSlots": {
//													"jaxId": "1IC90O7S23",
//													"attrs": {
//														"Slot1H2F6U36O0": {
//															"jaxId": "1IC90O7S24",
//															"attrs": {
//																"subHuds": {
//																	"attrs": []
//																},
//																"container": "true"
//															}
//														}
//													}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1IC90PU501",
//									"attrs": {
//										"1IJGVILF10": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IJGVVINQ72",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IJGVVINQ73",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IJGVILF10",
//											"faceTagName": "audio"
//										},
//										"1IJGVK0F50": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IJH3SNGG108",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IJH3SNGG109",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IJGVK0F50",
//											"faceTagName": "recording"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1IC90PU502",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IC90PU503",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1IJGU71G60",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IJGV6B990",
//									"attrs": {
//										"type": "hud",
//										"id": "BoxAudio",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "59",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex Y",
//										"itemsAlign": "Center",
//										"attach": "#vo.type===\"voice\"||vo.type===\"audio\""
//									}
//								},
//								"subHuds": {
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1IJH3JPK60",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IJH3JPK61",
//													"attrs": {
//														"type": "hud",
//														"id": "Line2",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "40",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex X",
//														"itemsAlign": "Center"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnText.js",
//															"jaxId": "1IJGV580L0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1IJGV580L1",
//																	"attrs": {
//																		"style": "primary",
//																		"w": "100",
//																		"h": "28",
//																		"text": {
//																			"type": "string",
//																			"valText": "Done",
//																			"localize": {
//																				"EN": "Done",
//																				"CN": "结束"
//																			},
//																			"localizable": true
//																		},
//																		"outlined": "false",
//																		"icon": "#appCfg.sharedAssets+\"/hudbox.svg\""
//																	}
//																},
//																"properties": {
//																	"jaxId": "1IJGV580M0",
//																	"attrs": {
//																		"type": "#null#>BtnText(\"primary\",100,28,(($ln===\"CN\")?(\"结束\"):(\"Done\")),false,appCfg.sharedAssets+\"/hudbox.svg\")",
//																		"id": "BtnStopRecord",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"corner": "5",
//																		"margin": "[0,20,0,0]"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IJGV580M1",
//																	"attrs": {
//																		"1IJGVILF10": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJGVO42313",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJGVO42314",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IJGVILF10",
//																			"faceTagName": "audio"
//																		},
//																		"1IJGVK0F50": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJGVO42315",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJGVO42316",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IJGVK0F50",
//																			"faceTagName": "recording"
//																		},
//																		"1IJGVM0E10": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJGVO42317",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJGVO42318",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IJGVM0E10",
//																			"faceTagName": "audioReady"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1IJGV580M2",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1IJH016LK1",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1IJH016LR1",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1IJGV580M3",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1IJGV580M4",
//																	"attrs": {
//																		"Slot1H2F6U36O0": {
//																			"jaxId": "1IJGV580M5",
//																			"attrs": {
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"container": "true"
//																			}
//																		}
//																	}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1IJH3K5640",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IJH3K5641",
//																	"attrs": {
//																		"type": "text",
//																		"id": "TxtAudio",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "[0,20,0,0]",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontBodySub\"]",
//																		"text": {
//																			"type": "string",
//																			"valText": "Recording...",
//																			"localize": {
//																				"EN": "Recording...",
//																				"CN": "录音中..."
//																			},
//																			"localizable": true
//																		},
//																		"font": "",
//																		"fontSize": "#txtSize.smallPlus",
//																		"bold": "false",
//																		"italic": "false",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Top",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"lineClamp": "0",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IJH3K5650",
//																	"attrs": {
//																		"1IJGVILF10": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJH3K5651",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJH3K5652",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IJGVILF10",
//																			"faceTagName": "audio"
//																		},
//																		"1IJGVK0F50": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJH3K5653",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJH3K5654",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IJGVK0F50",
//																			"faceTagName": "recording"
//																		},
//																		"1IJGVM0E10": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJH3K5655",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJH3K5656",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IJGVM0E10",
//																			"faceTagName": "audioReady"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1IJH3K5657",
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"jaxId": "1IJH3K5658",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnText.js",
//															"jaxId": "1IJGV96PD0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1IJGV96PD1",
//																	"attrs": {
//																		"style": "secondary",
//																		"w": "100",
//																		"h": "28",
//																		"text": {
//																			"type": "string",
//																			"valText": "Play",
//																			"localize": {
//																				"EN": "Play",
//																				"CN": "播放"
//																			},
//																			"localizable": true
//																		},
//																		"outlined": "false",
//																		"icon": "#appCfg.sharedAssets+\"/sound.svg\""
//																	}
//																},
//																"properties": {
//																	"jaxId": "1IJGV96PD2",
//																	"attrs": {
//																		"type": "#null#>BtnText(\"secondary\",100,28,(($ln===\"CN\")?(\"播放\"):(\"Play\")),false,appCfg.sharedAssets+\"/sound.svg\")",
//																		"id": "BtnPlayAudio",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"corner": "5",
//																		"margin": "[0,20,0,0]"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IJGV96PD3",
//																	"attrs": {
//																		"1IJGVILF10": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJGVO42319",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJGVO42320",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IJGVILF10",
//																			"faceTagName": "audio"
//																		},
//																		"1IJGVK0F50": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJGVO42321",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJGVO42322",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IJGVK0F50",
//																			"faceTagName": "recording"
//																		},
//																		"1IJGVM0E10": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJGVO42323",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJGVO42324",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IJGVM0E10",
//																			"faceTagName": "audioReady"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1IJGV96PD4",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1IJH016LK2",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1IJH016LS0",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1IJGV96PD5",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1IJGV96PD6",
//																	"attrs": {
//																		"Slot1H2F6U36O0": {
//																			"jaxId": "1IJGV96PD7",
//																			"attrs": {
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"container": "true"
//																			}
//																		}
//																	}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnText.js",
//															"jaxId": "1IJGVT4LF0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1IJGVT4LF1",
//																	"attrs": {
//																		"style": "secondary",
//																		"w": "100",
//																		"h": "28",
//																		"text": {
//																			"type": "string",
//																			"valText": "Download",
//																			"localize": {
//																				"EN": "Download",
//																				"CN": "下载"
//																			},
//																			"localizable": true
//																		},
//																		"outlined": "false",
//																		"icon": "#appCfg.sharedAssets+\"/download.svg\""
//																	}
//																},
//																"properties": {
//																	"jaxId": "1IJGVT4LF2",
//																	"attrs": {
//																		"type": "#null#>BtnText(\"secondary\",100,28,(($ln===\"CN\")?(\"下载\"):(\"Download\")),false,appCfg.sharedAssets+\"/download.svg\")",
//																		"id": "BtnDownloadAudio",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"corner": "5",
//																		"margin": "[0,20,0,0]"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IJGVT4LF3",
//																	"attrs": {
//																		"1IJGVILF10": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJGVT4LG0",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJGVT4LG1",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IJGVILF10",
//																			"faceTagName": "audio"
//																		},
//																		"1IJGVK0F50": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJGVT4LG2",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJGVT4LG3",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IJGVK0F50",
//																			"faceTagName": "recording"
//																		},
//																		"1IJGVM0E10": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJGVT4LG4",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJGVT4LG5",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IJGVM0E10",
//																			"faceTagName": "audioReady"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1IJGVT4LG6",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1IJH016LK4",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1IJH016LS2",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1IJGVT4LG7",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1IJGVT4LG8",
//																	"attrs": {
//																		"Slot1H2F6U36O0": {
//																			"jaxId": "1IJGVT4LG9",
//																			"attrs": {
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"container": "true"
//																			}
//																		}
//																	}
//																}
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1IJH3JPK70",
//													"attrs": {
//														"1IJGVILF10": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IJH3QAD20",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IJH3QAD21",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IJGVILF10",
//															"faceTagName": "audio"
//														},
//														"1IJGVK0F50": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IJH3SNGG112",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IJH3SNGG113",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IJGVK0F50",
//															"faceTagName": "recording"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IJH3JPK71",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IJH3JPK72",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1IJH3J4MH0",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IJH3JOUQ0",
//													"attrs": {
//														"type": "hud",
//														"id": "Line1",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "40",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex X",
//														"itemsAlign": "Center"
//													}
//												},
//												"subHuds": {
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnText.js",
//															"jaxId": "1IJGVAPDA0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1IJGVAPDA1",
//																	"attrs": {
//																		"style": "primary",
//																		"w": "100",
//																		"h": "28",
//																		"text": {
//																			"type": "string",
//																			"valText": "Use",
//																			"localize": {
//																				"EN": "Use",
//																				"CN": "使用"
//																			},
//																			"localizable": true
//																		},
//																		"outlined": "false",
//																		"icon": "#appCfg.sharedAssets+\"/check_fat.svg\""
//																	}
//																},
//																"properties": {
//																	"jaxId": "1IJGVAPDA2",
//																	"attrs": {
//																		"type": "#null#>BtnText(\"primary\",100,28,(($ln===\"CN\")?(\"使用\"):(\"Use\")),false,appCfg.sharedAssets+\"/check_fat.svg\")",
//																		"id": "BtnUseAudio",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"corner": "5",
//																		"margin": "[0,20,0,0]"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IJGVAPDA3",
//																	"attrs": {
//																		"1IJGVILF10": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJGVO42325",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJGVO42326",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IJGVILF10",
//																			"faceTagName": "audio"
//																		},
//																		"1IJGVK0F50": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJGVO42327",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJGVO42328",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IJGVK0F50",
//																			"faceTagName": "recording"
//																		},
//																		"1IJGVM0E10": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJGVO42329",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJGVO42330",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IJGVM0E10",
//																			"faceTagName": "audioReady"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1IJGVAPDA4",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1IJH016LK3",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1IJH016LS1",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1IJGVAPDA5",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1IJGVAPDA6",
//																	"attrs": {
//																		"Slot1H2F6U36O0": {
//																			"jaxId": "1IJGVAPDA7",
//																			"attrs": {
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"container": "true"
//																			}
//																		}
//																	}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnText.js",
//															"jaxId": "1IJGUFF2C0",
//															"attrs": {
//																"createArgs": {
//																	"jaxId": "1IJGV56030",
//																	"attrs": {
//																		"style": "primary",
//																		"w": "100",
//																		"h": "28",
//																		"text": {
//																			"type": "string",
//																			"valText": "Record",
//																			"localize": {
//																				"EN": "Record",
//																				"CN": "录音"
//																			},
//																			"localizable": true
//																		},
//																		"outlined": "false",
//																		"icon": "#appCfg.sharedAssets+\"/voice.svg\""
//																	}
//																},
//																"properties": {
//																	"jaxId": "1IJGV56031",
//																	"attrs": {
//																		"type": "#null#>BtnText(\"primary\",100,28,(($ln===\"CN\")?(\"录音\"):(\"Record\")),false,appCfg.sharedAssets+\"/voice.svg\")",
//																		"id": "BtnRecord",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"corner": "5",
//																		"margin": "[0,20,0,0]"
//																	}
//																},
//																"subHuds": {
//																	"attrs": []
//																},
//																"faces": {
//																	"jaxId": "1IJGV56032",
//																	"attrs": {
//																		"1IJGVK0F50": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJGVO4233",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJGVO4234",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "Off"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IJGVK0F50",
//																			"faceTagName": "recording"
//																		},
//																		"1IJGVM0E10": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJGVO4235",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJGVO4236",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IJGVM0E10",
//																			"faceTagName": "audioReady"
//																		},
//																		"1IJGVILF10": {
//																			"type": "hudface",
//																			"def": "HudFace",
//																			"jaxId": "1IJGVVINQ76",
//																			"attrs": {
//																				"properties": {
//																					"jaxId": "1IJGVVINQ77",
//																					"attrs": {
//																						"display": {
//																							"type": "choice",
//																							"valText": "On"
//																						}
//																					}
//																				},
//																				"anis": {
//																					"attrs": []
//																				}
//																			},
//																			"faceTagId": "1IJGVILF10",
//																			"faceTagName": "audio"
//																		}
//																	}
//																},
//																"functions": {
//																	"jaxId": "1IJGV56033",
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1IJH016LK0",
//																			"attrs": {
//																				"callArgs": {
//																					"jaxId": "1IJH016LR0",
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"jaxId": "1IJGV56034",
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true",
//																"containerSlots": {
//																	"jaxId": "1IJGV56035",
//																	"attrs": {
//																		"Slot1H2F6U36O0": {
//																			"jaxId": "1IJGV56036",
//																			"attrs": {
//																				"subHuds": {
//																					"attrs": []
//																				},
//																				"container": "true"
//																			}
//																		}
//																	}
//																}
//															}
//														}
//													]
//												},
//												"faces": {
//													"jaxId": "1IJH3JOUQ1",
//													"attrs": {
//														"1IJGVILF10": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IJH3QAD22",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IJH3QAD23",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IJGVILF10",
//															"faceTagName": "audio"
//														},
//														"1IJGVK0F50": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IJH3SNGG116",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IJH3SNGG117",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "Off"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IJGVK0F50",
//															"faceTagName": "recording"
//														},
//														"1IJGVM0E10": {
//															"type": "hudface",
//															"def": "HudFace",
//															"jaxId": "1IJH3SNGG118",
//															"attrs": {
//																"properties": {
//																	"jaxId": "1IJH3SNGG119",
//																	"attrs": {
//																		"display": {
//																			"type": "choice",
//																			"valText": "On"
//																		}
//																	}
//																},
//																"anis": {
//																	"attrs": []
//																}
//															},
//															"faceTagId": "1IJGVM0E10",
//															"faceTagName": "audioReady"
//														}
//													}
//												},
//												"functions": {
//													"jaxId": "1IJH3JOUQ2",
//													"attrs": {}
//												},
//												"extraPpts": {
//													"jaxId": "1IJH3JOUQ3",
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"jaxId": "1IJGV6B991",
//									"attrs": {
//										"1IJGVILF10": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IJGVVINQ78",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IJGVVINQ79",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IJGVILF10",
//											"faceTagName": "audio"
//										},
//										"1IJGVK0F50": {
//											"type": "hudface",
//											"def": "HudFace",
//											"jaxId": "1IJH3SNGG120",
//											"attrs": {
//												"properties": {
//													"jaxId": "1IJH3SNGG121",
//													"attrs": {}
//												},
//												"anis": {
//													"attrs": []
//												}
//											},
//											"faceTagId": "1IJGVK0F50",
//											"faceTagName": "recording"
//										}
//									}
//								},
//								"functions": {
//									"jaxId": "1IJGV6B992",
//									"attrs": {}
//								},
//								"extraPpts": {
//									"jaxId": "1IJGV6B993",
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"jaxId": "1HA934NIR10",
//					"attrs": {
//						"1IJGVILF10": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1IJGVVINQ82",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IJGVVINQ83",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1IJGVILF10",
//							"faceTagName": "audio"
//						},
//						"1IJGVK0F50": {
//							"type": "hudface",
//							"def": "HudFace",
//							"jaxId": "1IJH3SNGG124",
//							"attrs": {
//								"properties": {
//									"jaxId": "1IJH3SNGG125",
//									"attrs": {}
//								},
//								"anis": {
//									"attrs": []
//								}
//							},
//							"faceTagId": "1IJGVK0F50",
//							"faceTagName": "recording"
//						}
//					}
//				},
//				"functions": {
//					"jaxId": "1HA934NIR11",
//					"attrs": {}
//				},
//				"extraPpts": {
//					"jaxId": "1HA934NIR12",
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1HA934NIR13",
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false",
//				"exposeToAI": "false",
//				"descAI": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}