//Auto genterated by Cody
import {$P,VFACT,callAfter,sleep} from "/@vfact";
import inherits from "/@inherits";
import {appCfg} from "../cfg/appCfg.js";
import {BtnObject} from "/@StdUI/ui/BtnObject.js";
import {BtnText} from "/@StdUI/ui/BtnText.js";
import {BtnIcon} from "/@StdUI/ui/BtnIcon.js";
/*#{1HA934NIR0StartDoc*/
import {tabFS} from "/@tabos";
import {DlgFile} from "/@homekit/ui/DlgFile.js";
/*}#1HA934NIR0StartDoc*/
const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
//----------------------------------------------------------------------------
let BoxAskUser=function(vo,session){
	let cfgColor,cfgSize,txtSize,state;
	let cssVO,self;
	const $ln=appCfg.lanCode||VFACT.lanCode||"EN";
	let boxBG,txtContent,boxMenu,boxMenuItems,boxAsk,boxInput,edInput,edMemo,txtInputHint,boxCode,boxBlock;
	
	cfgColor=appCfg.color;
	cfgSize=appCfg.size;
	txtSize=appCfg.txtSize;
	
	let icon=vo.icon||(appCfg.sharedAssets+"/help.svg");
	
	/*#{1HA934NIR1LocalVals*/
	/*}#1HA934NIR1LocalVals*/
	
	/*#{1HA934NIR1PreState*/
	/*}#1HA934NIR1PreState*/
	/*#{1HA934NIR1PostState*/
	/*}#1HA934NIR1PostState*/
	cssVO={
		"hash":"1HA934NIR1",nameHost:true,
		"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":"","padding":[10,10,15,50],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-y",
		children:[
			{
				"hash":"1HA9DAPVC0",
				"type":"box","id":"BoxBG","x":0,"y":0,"w":"100%","h":"100%","padding":[10,10,15,50],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":vo.blkColor,
				"border":vo.top?0:[1,0,0,0],"borderColor":cfgColor["fontBodyLit"],"contentLayout":"flex-y","itemsWrap":1,
			},
			{
				"hash":"1HA9DBEF30",
				"type":"box","id":"BoxIcon","x":11,"y":5,"w":28,"h":28,"padding":2,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":vo.iconBG||vo.bgColor||cfgColor.primary,
				"corner":5,
				children:[
					{
						"hash":"1HA9DBEF40",
						"type":"box","position":"relative","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":vo.iconColor||cfgColor.fontPrimary,
						"maskImage":icon,"attached":!!vo.icon,
					},
					{
						"hash":"1HB2PL2PQ0",
						"type":"image","x":0,"y":0,"w":"100%","h":"100%","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","image":vo.pic,"fitSize":true,"attached":!!vo.pic,
					}
				],
			},
			{
				"hash":"1HAA3CQLS0",
				"type":"text","id":"TxtContent","position":"relative","x":0,"y":0,"w":"100%","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":vo.textColor,
				"text":vo.prompt||vo.text,"fontSize":txtSize.smallPlus,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","wrap":true,"selectable":true,
			},
			{
				"hash":"1HAADF97V0",
				"type":"hud","id":"BoxMenu","position":"relative","x":0,"y":0,"w":"100%","h":"","padding":[10,10,10,10],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
				"contentLayout":"flex-y","attached":vo.type==="menu",
				children:[
					{
						"hash":"1HAAICUAP0",
						"type":"hud","id":"BoxMenuItems","position":"relative","x":0,"y":0,"w":"100%","h":"","minW":"","minH":20,"maxW":"","maxH":"","styleClass":"",
						children:[
						],
					},
					{
						"hash":"1HAAIE08L0",
						"type":BtnText("primary",60,20,vo.button||"OK",false,""),"position":"relative","x":0,"y":0,"margin":[10,0,0,0],"corner":3,"attached":!!vo.multiSelect,
						"OnClick":function(event){
							/*#{1HAAK4ARU0FunctionBody*/
							self.closeMultiMenu();
							/*}#1HAAK4ARU0FunctionBody*/
						},
					}
				],
			},
			{
				"hash":"1HAA3H1FE0",
				"type":"hud","id":"BoxAsk","position":"relative","x":0,"y":0,"w":"100%","h":"","margin":[10,0,0,0],"padding":[0,20,0,20],"minW":"","minH":40,"maxW":"",
				"maxH":"","styleClass":"","contentLayout":"flex-x","itemsAlign":1,"itemsWrap":1,"attached":vo.type==="confirm",
				children:[
					{
						"hash":"1HAA3IFOF0",
						"type":BtnText("primary",100,25,vo.button1||"OK",false,""),"id":"Btn1","position":"relative","x":0,"y":0,"corner":3,"margin":[5,15,5,0],
						"OnClick":function(event){
							/*#{1HAACN4G30FunctionBody*/
							self.closeConfirm(1);
							/*}#1HAACN4G30FunctionBody*/
						},
					},
					{
						"hash":"1HAA3L6LG0",
						"type":BtnText("warning",100,25,vo.button2||"Cancel",false,""),"id":"Btn2","position":"relative","x":0,"y":0,"margin":[5,15,5,0],"corner":3,
						"OnClick":function(event){
							/*#{1HAACNIF10FunctionBody*/
							self.closeConfirm(0);
							/*}#1HAACNIF10FunctionBody*/
						},
					},
					{
						"hash":"1HAA3UKHN0",
						"type":BtnText("secondary",100,25,vo.button3,false,""),"id":"Btn3","position":"relative","x":0,"y":0,"margin":[5,15,5,0],"corner":3,"attached":vo.button3,
						"OnClick":function(event){
							/*#{1HAACO2RQ0FunctionBody*/
							self.closeConfirm(2);
							/*}#1HAACO2RQ0FunctionBody*/
						},
					}
				],
			},
			{
				"hash":"1HAAKRDC20",
				"type":"box","id":"BoxInput","position":"relative","x":10,"y":0,"w":">calc(100% - 20px)","h":"","minW":"","minH":30,"maxW":360,"maxH":"","styleClass":"",
				"background":[255,255,255,1],"corner":3,"shadowX":0,"shadowY":1,"shadowBlur":4,"shadowColor":[0,0,0,0.3],"contentLayout":"flex-y","attached":vo.type==="input",
				children:[
					{
						"hash":"1HAAKRDC22",
						"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":"","padding":[5,0,5,0],"minW":"","minH":20,"maxW":"","maxH":200,"styleClass":"","contentLayout":"flex-x",
						"traceSize":true,"itemsAlign":1,
						children:[
							{
								"hash":"1HENTEQ6L0",
								"type":BtnIcon("front",28,0,appCfg.sharedAssets+"/folder.svg",null),"id":"BtnOpenFile","position":"relative","x":0,"y":0,"attached":vo.file==="tabos",
								"OnClick":function(event){
									/*#{1HENTHD4Q0FunctionBody*/
									self.openFilePath();
									/*}#1HENTHD4Q0FunctionBody*/
								},
							},
							{
								"hash":"1HF65I8TR0",
								"type":BtnIcon("front",28,0,appCfg.sharedAssets+"/folder.svg",null),"id":"BtnOpenNative","position":"relative","x":0,"y":0,"attached":vo.file==="native",
								/*#{1HF65I8TR0Codes*/
								"labelHtml": '<input type="file" multiple="false" style="width:0px">',
								OnLableAction:function(){
									let files=[],i,n;
									n=this.files.length;
									for(i=0;i<n;i++){
										files.push(this.files[i]);
									}
									self.useNativeFile(files[0]);
									this.value="";
								}
								/*}#1HF65I8TR0Codes*/
							},
							{
								"hash":"1HAALRDJS0",
								"type":"edit","id":"EdInput","position":"relative","x":0,"y":0,"w":">calc(100% - 80px)","h":30,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
								"inputType":vo.inputType||"text","text":vo.initText||vo.text||"","placeHolder":vo.placeholder||vo.tip||"","color":[0,0,0],"outline":0,"border":[0,0,1,0],
								"attached":!vo.memo,
								"OnKeyDown":function(event){
									/*#{1HAAMBD940FunctionBody*/
									if(event.code==="Enter"){
										if((!event.isComposing) &&(!event.shiftKey)){
											event.stopPropagation();
											event.preventDefault();
											self.closeInput();
										}
									}
									/*}#1HAAMBD940FunctionBody*/
								},
							},
							{
								"hash":"1HAAKRDC30",
								"type":"memo","id":"EdMemo","position":"relative","x":0,"y":0,"w":">calc(100% - 50px)","h":"","minW":"","minH":20,"maxW":"","maxH":"","styleClass":"",
								"text":vo.initText||vo.text,"color":cfgColor["fontBody"],"background":cfgColor["body"],"fontSize":txtSize.mid,"outline":0,"border":[0,0,1,0],"borderColor":[0,0,0,0.5],
								"flex":true,"attached":!!vo.memo,
								"OnInput":function(){
									/*#{1HAAKRDC41FunctionBody*/
									txtInputHint.display=!this.text;
									/*}#1HAAKRDC41FunctionBody*/
								},
								"OnKeyDown":function(event){
									/*#{1HAAKRDC43FunctionBody*/
									if(event.code==="Enter"){
										if((!event.isComposing) &&(!event.shiftKey)){
											event.stopPropagation();
											event.preventDefault();
											self.closeInput();
										}
									}
									/*}#1HAAKRDC43FunctionBody*/
								},
							},
							{
								"hash":"1HAAKRDC46",
								"type":BtnIcon("front",30,0,appCfg.sharedAssets+"/send.svg",null),"id":"BtnSend","position":"relative","x":0,"y":0,"margin":[0,0,0,10],"padding":2,
								"autoLayout":true,
								"OnClick":function(event){
									/*#{1HAAKRDC53FunctionBody*/
									self.closeInput();
									/*}#1HAAKRDC53FunctionBody*/
								},
							},
							{
								"hash":"1HAAKRDC57",
								"type":"text","id":"TxtInputHint","x":15,"y":0,"w":100,"h":"100%","display":(!vo.initText)&&(!vo.text),"uiEvent":-1,"minW":"","minH":"","maxW":"",
								"maxH":"","styleClass":"","color":cfgColor["fontBodyLit"],"text":vo.placeholder||vo.tip||"","fontSize":txtSize.mid,"fontWeight":"normal","fontStyle":"italic",
								"textDecoration":"","alignV":1,"attached":!!vo.memo,
							}
						],
					},
					{
						"hash":"1HAAL48AG0",
						"type":"text","position":"relative","x":10,"y":0,"w":">calc(100% - 20px)","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","color":cfgColor["fontBodySub"],
						"text":"New line: Shift+Enter","fontSize":txtSize.small,"fontWeight":"normal","fontStyle":"normal","textDecoration":"","attached":vo.memo,
					}
				],
			},
			{
				"hash":"1HBIS5UIR0",
				"type":"hud","id":"BoxCode","position":"relative","x":0,"y":0,"w":"100%","h":"","margin":[10,0,0,0],"padding":[0,20,0,20],"minW":"","minH":40,"maxW":"",
				"maxH":"","styleClass":"","contentLayout":"flex-y","itemsAlign":1,"itemsWrap":1,"attached":vo.type==="code",
				children:[
					{
						"hash":"1HBISLN7M0",
						"type":"box","position":"relative","x":0,"y":0,"w":"100%","h":"","minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["body"],
						"border":1,"contentLayout":"flex-y",
						children:[
							{
								"hash":"1HBISSGF50",
								"type":"box","position":"relative","x":0,"y":0,"w":"100%","h":10,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["secondary"],
							},
							{
								"hash":"1HBIST3QG0",
								"type":"hud","id":"BoxCodes","position":"relative","x":0,"y":0,"w":"100%","h":300,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"",
							},
							{
								"hash":"1HBISTSUE0",
								"type":"box","position":"relative","x":0,"y":0,"w":"100%","h":10,"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","background":cfgColor["secondary"],
							}
						],
					},
					{
						"hash":"1HBISOTQN0",
						"type":"hud","position":"relative","x":0,"y":0,"w":"100%","h":30,"padding":[0,10,0,10],"minW":"","minH":"","maxW":"","maxH":"","styleClass":"","contentLayout":"flex-x",
						children:[
							{
								"hash":"1HBISPSNU0",
								"type":BtnText("primary",100,25,"Apply",false,""),"id":"BtnApplyCode","position":"relative","x":0,"y":0,"corner":3,"margin":[5,15,5,0],
								"OnClick":function(event){
									/*#{1HBISPSNU5FunctionBody*/
									/*}#1HBISPSNU5FunctionBody*/
								},
							},
							{
								"hash":"1HBISQGHA0",
								"type":BtnText("warning",100,25,"Cancel",false,""),"id":"BtnAbortCode","position":"relative","x":0,"y":0,"margin":[5,15,5,0],"corner":3,
								"OnClick":function(event){
									/*#{1HBISQGHA5FunctionBody*/
									/*}#1HBISQGHA5FunctionBody*/
								},
							}
						],
					}
				],
			},
			{
				"hash":"1HEJE92P70",
				"type":"hud","id":"BoxBlock","position":"relative","x":0,"y":0,"w":"100%","h":"","margin":[10,0,0,0],"padding":[0,20,0,20],"minW":"","minH":40,"maxW":"",
				"maxH":"","styleClass":"","contentLayout":"flex-x","itemsAlign":1,"itemsWrap":1,"attached":vo.type==="block",
			}
		],
		/*#{1HA934NIR1ExtraCSS*/
		/*}#1HA934NIR1ExtraCSS*/
		faces:{
		},
		OnCreate:function(){
			self=this;
			boxBG=self.BoxBG;txtContent=self.TxtContent;boxMenu=self.BoxMenu;boxMenuItems=self.BoxMenuItems;boxAsk=self.BoxAsk;boxInput=self.BoxInput;edInput=self.EdInput;edMemo=self.EdMemo;txtInputHint=self.TxtInputHint;boxCode=self.BoxCode;boxBlock=self.BoxBlock;
			/*#{1HA934NIR1Create*/
			function OnClick(){
				if(vo.multiSelect){
					this.BtnCheck.checked=!this.BtnCheck.checked;
				}else{
					txtContent.text+=" "+this.obj.text;
					self.closeMenu(this.obj);
				}
			}
			if(vo.type==="menu"){
				let items,item,css;
				items=vo.items;
				for(item of items){
					item.selectable=vo.multiSelect;
					css={
						type:BtnObject(item),fontSize:16,margin:[0,0,5,0],maxW:360,
						OnClick:OnClick
					};
					boxMenuItems.appendNewChild(css);
				}
			}else if(vo.type==="input"){
				let editBox;
				editBox=edInput||edMemo;
				editBox.focus();
			}else if(vo.type==="block"){
				let block;
				vo.block.position="relative";
				block=boxBlock.appendNewChild(vo.block);
				block.showBlock(vo.input,(result)=>{
					boxBlock.uiEvent=-1;
					self.callback(result);
				});
			}
			/*}#1HA934NIR1Create*/
		},
		/*#{1HA934NIR1EndCSS*/
		/*}#1HA934NIR1EndCSS*/
	};
	/*#{1HA934NIR1PostCSSVO*/
	//------------------------------------------------------------------------
	cssVO.initCodes=async function(code,orgCode){
		//TODO: Code this:
	};
	
	//------------------------------------------------------------------------
	cssVO.closeConfirm=function(code){
		self.removeChild(boxAsk);
		switch(code){
			case 1:
				self.callback([vo.button1||"OK",1]);
				return;
			case 0:
				self.callback([vo.button2||"Cancel",0]);
				return;
			case 2:
				self.callback([vo.button3,2]);
				return;
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.closeMenu=function(obj){
		self.removeChild(boxMenu);
		self.callback([obj.text,obj]);
	};
	
	//------------------------------------------------------------------------
	cssVO.closeMultiMenu=function(){
		let items,item,i,n,resultTxt,resultItems;
		resultItems=[];
		resultTxt="";
		items=boxMenuItems.children;
		n=items.length;
		for(i=0;i<n;i++){
			item=items[i];
			if(item.BtnCheck.checked){
				resultTxt+=item.obj.text+", ";
				resultItems.push(item.obj);
			}
		}
		if(resultTxt){
			resultTxt=resultTxt.substring(0,resultTxt.length-2);
		}else{
			resultTxt="None";
		}
		txtContent.text+=" "+resultTxt;
		self.removeChild(boxMenu);
		self.callback([resultTxt,resultItems]);
	};
	
	//------------------------------------------------------------------------
	cssVO.closeInput=function(){
		let text,val;
		if(edInput){
			val=text=edInput.text;
		}else{
			val=text=edMemo.text;
		}
		if(vo.inputType==="password"){
			text="";
			for(let i=0;i<val.length;i++){
				text+="*";
			}
		}
		self.removeChild(boxInput);
		self.callback([text,val]);
	};
	
	//------------------------------------------------------------------------
	cssVO.abort=function(){
		if(boxAsk){
			self.removeChild(boxAsk);
		}
		if(boxInput){
			self.removeChild(boxInput);
		}
		if(boxMenu){
			self.removeChild(boxMenu);
		}
	};
	
	//------------------------------------------------------------------------
	cssVO.openFilePath=async function(){
		let path,result,byteAry;
		path=await VFACT.app.modalDlg(DlgFile,{
			mode:"open",
			path:vo.path||"/",
			options:{
				filter:vo.filter
			}			
		});
		if(path){
			path="/~"+path;
			edInput.text=path;
			//byteAry=await tabFS.readFile(path);
			self.removeChild(boxInput);
			txtContent.text+=" "+path;
			self.callback([path,path]);
		}
	};
	
	async function arrayBuffer(file){
		if(file.arrayBuffer){
			return file.arrayBuffer();
		}
		return new Promise((onDone,onError)=>{
			let reader=new FileReader();
			reader.onload=function(event) {
				let arrayBuffer = event.target.result;
				onDone(arrayBuffer);
			};
			reader.readAsArrayBuffer(file);
		})
	}
	
	//------------------------------------------------------------------------
	cssVO.useNativeFile=async function(file){
		let buf,byteAry;
		if(!file){
			return;
		}
		try{
			buf=await arrayBuffer(file);
			byteAry = new Uint8Array(buf);
		}catch(err){
			return;
		}
		txtContent.text+=" "+file.name;
		self.removeChild(boxInput);
		self.callback([file.name,byteAry]);
	};
	/*}#1HA934NIR1PostCSSVO*/
	return cssVO;
};
/*#{1HA934NIR1ExCodes*/
/*}#1HA934NIR1ExCodes*/


export default BoxAskUser;
export{BoxAskUser};
/*Cody Project Doc*/
//{
//	"type": "docfile",
//	"def": "GearHud",
//	"jaxId": "1HA934NIR0",
//	"editVersion": 121,
//	"attrs": {
//		"editEnv": {
//			"type": "object",
//			"jaxId": "1HA934NIR2",
//			"editVersion": 12,
//			"attrs": {
//				"device": "Desktop 800x600",
//				"screenW": "800",
//				"screenH": "600",
//				"bgColor": "[255,255,255]",
//				"bgChecker": "false"
//			}
//		},
//		"editObjs": {
//			"type": "object",
//			"jaxId": "1HA934NIR3",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"model": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1HA934NIR4",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"createArgs": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1HA934NIR5",
//			"editVersion": 132,
//			"attrs": {
//				"vo": {
//					"type": "auto",
//					"valText": "#{type:\"input\",icon:appCfg.sharedAssets+\"/faces.svg\",iconBG:cfgColor.primary,iconColor:cfgColor.fontPrimary,\tbgColor:cfgColor.body,textColor:cfgColor.fontBody,text:\"Please input:\",button:\"Yes\",placeHolder:\"please input\",initText:\"text\",file:\"tabos\"}"
//				},
//				"session": {
//					"type": "auto",
//					"valText": "null"
//				}
//			}
//		},
//		"localVars": {
//			"type": "object",
//			"def": "Object",
//			"jaxId": "1HA934NIR6",
//			"editVersion": 14,
//			"attrs": {
//				"icon": {
//					"type": "string",
//					"valText": "#vo.icon||(appCfg.sharedAssets+\"/help.svg\")"
//				}
//			}
//		},
//		"oneHud": "false",
//		"state": {
//			"type": "object",
//			"def": "StateObj",
//			"jaxId": "1HA934NIR7",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"segs": {
//			"type": "array",
//			"attrs": []
//		},
//		"exportTarget": "\"jax\"",
//		"gearName": "",
//		"gearIcon": "gears.svg",
//		"gearW": "100",
//		"gearH": "100",
//		"gearCatalog": "",
//		"description": "",
//		"fixPose": "false",
//		"previewImg": "",
//		"faceTags": {
//			"type": "object",
//			"def": "FaceTags",
//			"jaxId": "1HA934NIR8",
//			"editVersion": 0,
//			"attrs": {}
//		},
//		"mockupStates": {
//			"type": "object",
//			"def": "MockupObj",
//			"jaxId": "1HAA37TBQ0",
//			"editVersion": 19,
//			"attrs": {
//				"Confirm": {
//					"type": "mockState",
//					"def": "MockState",
//					"jaxId": "1HAAIQB850",
//					"editVersion": 4,
//					"attrs": {
//						"createArgs": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HA934NIR5",
//							"editVersion": 28,
//							"attrs": {
//								"vo": {
//									"type": "auto",
//									"valText": "#{type:\"confirm\",icon:appCfg.sharedAssets+\"/faces.svg\",iconBG:cfgColor.primary,iconColor:cfgColor.fontPrimary,\tbgColor:cfgColor.body,textColor:cfgColor.fontBody,text:\"Please Confirm:\",button1:\"Yes\",button2:\"No\",button3:\"Abort\"}"
//								}
//							}
//						},
//						"stateObj": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HA934NIR7",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"Menu": {
//					"type": "mockState",
//					"def": "MockState",
//					"jaxId": "1HAAIQB851",
//					"editVersion": 4,
//					"attrs": {
//						"createArgs": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HA934NIR5",
//							"editVersion": 34,
//							"attrs": {
//								"vo": {
//									"type": "auto",
//									"valText": "#{type:\"menu\",icon:appCfg.sharedAssets+\"/faces.svg\",iconBG:cfgColor.primary,iconColor:cfgColor.fontPrimary,\tbgColor:cfgColor.body,textColor:cfgColor.fontBody,text:\"Please Confirm:\",button:\"Yes\"}"
//								}
//							}
//						},
//						"stateObj": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HA934NIR7",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"MultiSelect": {
//					"type": "mockState",
//					"def": "MockState",
//					"jaxId": "1HAAIU8HP0",
//					"editVersion": 4,
//					"attrs": {
//						"createArgs": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HA934NIR5",
//							"editVersion": 46,
//							"attrs": {
//								"vo": {
//									"type": "auto",
//									"valText": "#{type:\"menu\",icon:appCfg.sharedAssets+\"/faces.svg\",iconBG:cfgColor.primary,iconColor:cfgColor.fontPrimary,\tbgColor:cfgColor.body,textColor:cfgColor.fontBody,text:\"Please Confirm:\",button:\"Yes\",multiSelect:1}"
//								}
//							}
//						},
//						"stateObj": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HA934NIR7",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"Input": {
//					"type": "mockState",
//					"def": "MockState",
//					"jaxId": "1HAAKJDOH0",
//					"editVersion": 4,
//					"attrs": {
//						"createArgs": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HA934NIR5",
//							"editVersion": 64,
//							"attrs": {
//								"vo": {
//									"type": "auto",
//									"valText": "#{type:\"input\",icon:appCfg.sharedAssets+\"/faces.svg\",iconBG:cfgColor.primary,iconColor:cfgColor.fontPrimary,\tbgColor:cfgColor.body,textColor:cfgColor.fontBody,text:\"Please input:\",button:\"Yes\",placeHolder:\"please input\",initText:\"text\"}"
//								}
//							}
//						},
//						"stateObj": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HA934NIR7",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"Input Memo": {
//					"type": "mockState",
//					"def": "MockState",
//					"jaxId": "1HAAMI7TE0",
//					"editVersion": 4,
//					"attrs": {
//						"createArgs": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HA934NIR5",
//							"editVersion": 70,
//							"attrs": {
//								"vo": {
//									"type": "auto",
//									"valText": "#{type:\"input\",icon:appCfg.sharedAssets+\"/faces.svg\",iconBG:cfgColor.primary,iconColor:cfgColor.fontPrimary,\tbgColor:cfgColor.body,textColor:cfgColor.fontBody,text:\"Please input:\",button:\"Yes\",placeHolder:\"please input\",initText:\"text\",memo:1}"
//								}
//							}
//						},
//						"stateObj": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HA934NIR7",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"block": {
//					"type": "mockState",
//					"def": "MockState",
//					"jaxId": "1HEJEANSG0",
//					"editVersion": 4,
//					"attrs": {
//						"createArgs": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HA934NIR5",
//							"editVersion": 120,
//							"attrs": {
//								"vo": {
//									"type": "auto",
//									"valText": "#{type:\"block\",icon:appCfg.sharedAssets+\"/faces.svg\",iconBG:cfgColor.primary,iconColor:cfgColor.fontPrimary,\tbgColor:cfgColor.body,textColor:cfgColor.fontBody,text:\"Please Confirm:\",button1:\"Yes\",button2:\"No\",button3:\"Abort\"}"
//								},
//								"session": {
//									"type": "auto",
//									"valText": "null"
//								}
//							}
//						},
//						"stateObj": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HA934NIR7",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				},
//				"file": {
//					"type": "mockState",
//					"def": "MockState",
//					"jaxId": "1HENTH7BK0",
//					"editVersion": 4,
//					"attrs": {
//						"createArgs": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HA934NIR5",
//							"editVersion": 126,
//							"attrs": {
//								"vo": {
//									"type": "auto",
//									"valText": "#{type:\"input\",icon:appCfg.sharedAssets+\"/faces.svg\",iconBG:cfgColor.primary,iconColor:cfgColor.fontPrimary,\tbgColor:cfgColor.body,textColor:cfgColor.fontBody,text:\"Please input:\",button:\"Yes\",placeHolder:\"please input\",initText:\"text\",file:true}"
//								},
//								"session": {
//									"type": "auto",
//									"valText": "null"
//								}
//							}
//						},
//						"stateObj": {
//							"type": "object",
//							"def": "Object",
//							"jaxId": "1HA934NIR7",
//							"editVersion": 0,
//							"attrs": {}
//						}
//					}
//				}
//			}
//		},
//		"hud": {
//			"type": "hudobj",
//			"def": "hud",
//			"jaxId": "1HA934NIR1",
//			"editVersion": 22,
//			"attrs": {
//				"properties": {
//					"type": "object",
//					"jaxId": "1HA934NIR9",
//					"editVersion": 94,
//					"attrs": {
//						"type": "hud",
//						"id": "",
//						"position": "Relative",
//						"x": "0",
//						"y": "0",
//						"w": "100%",
//						"h": "",
//						"anchorH": "Left",
//						"anchorV": "Top",
//						"autoLayout": "false",
//						"display": "On",
//						"clip": "Off",
//						"uiEvent": "On",
//						"alpha": "1",
//						"rotate": "0",
//						"scale": "",
//						"filter": "",
//						"cursor": "",
//						"zIndex": "0",
//						"margin": "",
//						"padding": "[10,10,15,50]",
//						"minW": "",
//						"minH": "",
//						"maxW": "",
//						"maxH": "",
//						"face": "",
//						"styleClass": "",
//						"contentLayout": "Flex Y"
//					}
//				},
//				"subHuds": {
//					"type": "array",
//					"attrs": [
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1HA9DAPVC0",
//							"editVersion": 61,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1HA9DAPVC1",
//									"editVersion": 182,
//									"attrs": {
//										"type": "box",
//										"id": "BoxBG",
//										"position": "Absolute",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "100%",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "[10,10,15,50]",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#vo.blkColor",
//										"border": "#vo.top?0:[1,0,0,0]",
//										"borderStyle": "Solid",
//										"borderColor": "#cfgColor[\"fontBodyLit\"]",
//										"corner": "0",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]",
//										"contentLayout": "Flex Y",
//										"itemsWrap": "Wrap"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1HA9DAPVC2",
//									"editVersion": 34,
//									"attrs": {}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1HA9DAPVC5",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1HA9DAPVC6",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1HA9DBEF30",
//							"editVersion": 39,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1HA9DBEF31",
//									"editVersion": 234,
//									"attrs": {
//										"type": "box",
//										"id": "BoxIcon",
//										"position": "Absolute",
//										"x": "11",
//										"y": "5",
//										"w": "28",
//										"h": "28",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "2",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "#vo.iconBG||vo.bgColor||cfgColor.primary",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "5",
//										"shadow": "false",
//										"shadowX": "2",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.50]"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1HA9DBEF40",
//											"editVersion": 22,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HA9DBEF41",
//													"editVersion": 140,
//													"attrs": {
//														"type": "box",
//														"id": "",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "#vo.iconColor||cfgColor.fontPrimary",
//														"border": "0",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]",
//														"maskImage": "#icon",
//														"attach": "#!!vo.icon"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1HA9DBEF42",
//													"editVersion": 34,
//													"attrs": {}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1HA9DBEF45",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1HA9DBEF46",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "image",
//											"jaxId": "1HB2PL2PQ0",
//											"editVersion": 20,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HB2PNL4Q0",
//													"editVersion": 92,
//													"attrs": {
//														"type": "image",
//														"id": "",
//														"position": "Absolute",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "100%",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"image": "#vo.pic",
//														"autoSize": "false",
//														"fitSize": "Fit",
//														"repeat": "true",
//														"alignX": "Left",
//														"alignY": "Top",
//														"attach": "#!!vo.pic"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1HB2PNL4Q1",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1HB2PNL4Q2",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1HB2PNL4Q3",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1HA9DBEF47",
//									"editVersion": 34,
//									"attrs": {}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1HA9DBEF410",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1HA9DBEF411",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "text",
//							"jaxId": "1HAA3CQLS0",
//							"editVersion": 68,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1HAA3CQLS1",
//									"editVersion": 136,
//									"attrs": {
//										"type": "text",
//										"id": "TxtContent",
//										"position": "Relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"color": "#vo.textColor",
//										"text": "#vo.prompt||vo.text",
//										"font": "",
//										"fontSize": "#txtSize.smallPlus",
//										"bold": "false",
//										"italic": "false",
//										"underline": "false",
//										"alignH": "Left",
//										"alignV": "Top",
//										"wrap": "true",
//										"ellipsis": "false",
//										"select": "true",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "2",
//										"shadowBlur": "3",
//										"shadowColor": "[0,0,0,1.00]",
//										"shadowEx": "",
//										"maxTextW": "0"
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1HAA3CQLS2",
//									"editVersion": 34,
//									"attrs": {}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1HAA3CQLS5",
//									"editVersion": 4,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1HAA3CQLS6",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "false",
//								"nameVal": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1HAADF97V0",
//							"editVersion": 55,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1HAAI91K60",
//									"editVersion": 100,
//									"attrs": {
//										"type": "hud",
//										"id": "BoxMenu",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "[10,10,10,10]",
//										"minW": "",
//										"minH": "",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex Y",
//										"attach": "#vo.type===\"menu\""
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1HAAICUAP0",
//											"editVersion": 52,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HAAIQB852",
//													"editVersion": 82,
//													"attrs": {
//														"type": "hud",
//														"id": "BoxMenuItems",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "20",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": ""
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnObject.js",
//															"jaxId": "1HAAIP3VS0",
//															"editVersion": 43,
//															"attrs": {
//																"createArgs": {
//																	"type": "object",
//																	"def": "gearCrateArgs",
//																	"jaxId": "1HAAIQB853",
//																	"editVersion": 18,
//																	"attrs": {
//																		"obj": "{\"text\":\"Object\",\"icon\":\"\",\"iconColor\":[255,0,0,1]}",
//																		"converter": "null"
//																	}
//																},
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HAAIQB854",
//																	"editVersion": 59,
//																	"attrs": {
//																		"type": "#null#>BtnObject({\"text\":\"Object\",\"icon\":\"\",\"iconColor\":[255,0,0,1]},null)",
//																		"id": "",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"maxW": "360",
//																		"attach": "#!vo.multiSelect"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HAAIQB855",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HAAIQB856",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HAAIQB857",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "true",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"type": "object",
//																	"jaxId": "1HAAIQB858",
//																	"editVersion": 0,
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnObject.js",
//															"jaxId": "1HAAIQDS10",
//															"editVersion": 43,
//															"attrs": {
//																"createArgs": {
//																	"type": "object",
//																	"def": "gearCrateArgs",
//																	"jaxId": "1HAAIQDS11",
//																	"editVersion": 16,
//																	"attrs": {
//																		"obj": "{\"text\":\"Object\",\"icon\":\"\",\"iconColor\":[255,0,0,1]}",
//																		"converter": "null"
//																	}
//																},
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HAAIQDS12",
//																	"editVersion": 57,
//																	"attrs": {
//																		"type": "#null#>BtnObject({\"text\":\"Object\",\"icon\":\"\",\"iconColor\":[255,0,0,1]},null)",
//																		"id": "",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"maxW": "360",
//																		"attach": "#!vo.multiSelect"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HAAIQDS13",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HAAIQDS14",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HAAIQDS15",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "true",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"type": "object",
//																	"jaxId": "1HAAIQDS16",
//																	"editVersion": 0,
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnObject.js",
//															"jaxId": "1HAAISI4C0",
//															"editVersion": 51,
//															"attrs": {
//																"createArgs": {
//																	"type": "object",
//																	"def": "gearCrateArgs",
//																	"jaxId": "1HAAISI4C1",
//																	"editVersion": 54,
//																	"attrs": {
//																		"obj": "#{\"text\":\"Object\",selectable:true,checked:1}",
//																		"converter": "null"
//																	}
//																},
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HAAISI4C2",
//																	"editVersion": 71,
//																	"attrs": {
//																		"type": "#null#>BtnObject({\"text\":\"Object\",selectable:true,checked:1},null)",
//																		"id": "",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"maxW": "360",
//																		"attach": "#!!vo.multiSelect"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HAAISI4C3",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HAAISI4C4",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HAAISI4C5",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "true",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"type": "object",
//																	"jaxId": "1HAAISI4C6",
//																	"editVersion": 0,
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnObject.js",
//															"jaxId": "1HAAJ9POB0",
//															"editVersion": 52,
//															"attrs": {
//																"createArgs": {
//																	"type": "object",
//																	"def": "gearCrateArgs",
//																	"jaxId": "1HAAJ9POB1",
//																	"editVersion": 54,
//																	"attrs": {
//																		"obj": "#{\"text\":\"Array\",selectable:true,checked:0}",
//																		"converter": "null"
//																	}
//																},
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HAAJ9POB2",
//																	"editVersion": 72,
//																	"attrs": {
//																		"type": "#null#>BtnObject({\"text\":\"Array\",selectable:true,checked:0},null)",
//																		"id": "",
//																		"position": "Relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"maxW": "360",
//																		"attach": "#!!vo.multiSelect"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HAAJ9POB3",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HAAJ9POB4",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HAAJ9POB5",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "true",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"type": "object",
//																	"jaxId": "1HAAJ9POB6",
//																	"editVersion": 0,
//																	"attrs": {}
//																}
//															}
//														}
//													]
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1HAAIQB859",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1HAAIQB8510",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1HAAIQB8511",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "true",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnText.js",
//											"jaxId": "1HAAIE08L0",
//											"editVersion": 43,
//											"attrs": {
//												"createArgs": {
//													"type": "object",
//													"def": "gearCrateArgs",
//													"jaxId": "1HAAIQB8512",
//													"editVersion": 42,
//													"attrs": {
//														"style": "primary",
//														"w": "60",
//														"h": "20",
//														"text": "#vo.button||\"OK\"",
//														"outlined": "false",
//														"icon": ""
//													}
//												},
//												"properties": {
//													"type": "object",
//													"jaxId": "1HAAIQB860",
//													"editVersion": 65,
//													"attrs": {
//														"type": "#null#>BtnText(\"primary\",60,20,vo.button||\"OK\",false,\"\")",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"margin": "[10,0,0,0]",
//														"corner": "3",
//														"attach": "#!!vo.multiSelect"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1HAAIQB861",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1HAAIQB862",
//													"editVersion": 2,
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1HAAK4ARU0",
//															"editVersion": 4,
//															"attrs": {
//																"callArgs": {
//																	"type": "object",
//																	"jaxId": "1HAAK4KAU0",
//																	"editVersion": 2,
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1HAAIQB863",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"type": "object",
//													"jaxId": "1HAAIQB864",
//													"editVersion": 2,
//													"attrs": {
//														"Slot1H2F6U36O0": {
//															"type": "gearcontainer",
//															"jaxId": "1HAAIQB865",
//															"editVersion": 4,
//															"attrs": {
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"container": "true"
//															}
//														}
//													}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1HAAI91K67",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1HAAI91K68",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1HAAI91K69",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1HAA3H1FE0",
//							"editVersion": 54,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1HAA3NR1A0",
//									"editVersion": 134,
//									"attrs": {
//										"type": "hud",
//										"id": "BoxAsk",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[10,0,0,0]",
//										"padding": "[0,20,0,20]",
//										"minW": "",
//										"minH": "40",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex X",
//										"subAlign": "Start",
//										"itemsAlign": "Center",
//										"itemsWrap": "Wrap",
//										"attach": "#vo.type===\"confirm\""
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnText.js",
//											"jaxId": "1HAA3IFOF0",
//											"editVersion": 57,
//											"attrs": {
//												"createArgs": {
//													"type": "object",
//													"def": "gearCrateArgs",
//													"jaxId": "1HAA3L5VK0",
//													"editVersion": 30,
//													"attrs": {
//														"style": "primary",
//														"w": "100",
//														"h": "25",
//														"text": "#vo.button1||\"OK\"",
//														"outlined": "false",
//														"icon": ""
//													}
//												},
//												"properties": {
//													"type": "object",
//													"jaxId": "1HAA3L5VK1",
//													"editVersion": 94,
//													"attrs": {
//														"type": "#null#>BtnText(\"primary\",100,25,vo.button1||\"OK\",false,\"\")",
//														"id": "Btn1",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"corner": "3",
//														"margin": "[5,15,5,0]"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1HAA3L5VK2",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1HAA3L5VK3",
//													"editVersion": 2,
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1HAACN4G30",
//															"editVersion": 4,
//															"attrs": {
//																"callArgs": {
//																	"type": "object",
//																	"jaxId": "1HAACNC060",
//																	"editVersion": 2,
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1HAA3L5VK4",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"type": "object",
//													"jaxId": "1HAA3L5VK5",
//													"editVersion": 2,
//													"attrs": {
//														"Slot1H2F6U36O0": {
//															"type": "gearcontainer",
//															"jaxId": "1HAA3L5VK6",
//															"editVersion": 4,
//															"attrs": {
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"container": "true"
//															}
//														}
//													}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnText.js",
//											"jaxId": "1HAA3L6LG0",
//											"editVersion": 63,
//											"attrs": {
//												"createArgs": {
//													"type": "object",
//													"def": "gearCrateArgs",
//													"jaxId": "1HAA3L6LG1",
//													"editVersion": 48,
//													"attrs": {
//														"style": "warning",
//														"w": "100",
//														"h": "25",
//														"text": "#vo.button2||\"Cancel\"",
//														"outlined": "false",
//														"icon": ""
//													}
//												},
//												"properties": {
//													"type": "object",
//													"jaxId": "1HAA3L6LG2",
//													"editVersion": 88,
//													"attrs": {
//														"type": "#null#>BtnText(\"warning\",100,25,vo.button2||\"Cancel\",false,\"\")",
//														"id": "Btn2",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"margin": "[5,15,5,0]",
//														"corner": "3"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1HAA3L6LG3",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1HAA3L6LG4",
//													"editVersion": 2,
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1HAACNIF10",
//															"editVersion": 4,
//															"attrs": {
//																"callArgs": {
//																	"type": "object",
//																	"jaxId": "1HAACNU2D0",
//																	"editVersion": 2,
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1HAA3L6LG5",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"type": "object",
//													"jaxId": "1HAA3L6LG6",
//													"editVersion": 2,
//													"attrs": {
//														"Slot1H2F6U36O0": {
//															"type": "gearcontainer",
//															"jaxId": "1HAA3L6LG7",
//															"editVersion": 4,
//															"attrs": {
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"container": "true"
//															}
//														}
//													}
//												}
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "Gear/@StdUI/ui/BtnText.js",
//											"jaxId": "1HAA3UKHN0",
//											"editVersion": 67,
//											"attrs": {
//												"createArgs": {
//													"type": "object",
//													"def": "gearCrateArgs",
//													"jaxId": "1HAA3UKHN1",
//													"editVersion": 54,
//													"attrs": {
//														"style": "secondary",
//														"w": "100",
//														"h": "25",
//														"text": "#vo.button3",
//														"outlined": "false",
//														"icon": ""
//													}
//												},
//												"properties": {
//													"type": "object",
//													"jaxId": "1HAA3UKHN2",
//													"editVersion": 104,
//													"attrs": {
//														"type": "#null#>BtnText(\"secondary\",100,25,vo.button3,false,\"\")",
//														"id": "Btn3",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"display": "On",
//														"face": "",
//														"margin": "[5,15,5,0]",
//														"corner": "3",
//														"attach": "#vo.button3"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1HAA3UKHN3",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1HAA3UKHN4",
//													"editVersion": 2,
//													"attrs": {
//														"OnClick": {
//															"type": "fixedFunc",
//															"jaxId": "1HAACO2RQ0",
//															"editVersion": 4,
//															"attrs": {
//																"callArgs": {
//																	"type": "object",
//																	"jaxId": "1HAACO7I40",
//																	"editVersion": 2,
//																	"attrs": {
//																		"event": ""
//																	}
//																},
//																"seg": ""
//															}
//														}
//													}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1HAA3UKHN5",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false",
//												"containerSlots": {
//													"type": "object",
//													"jaxId": "1HAA3UKHO0",
//													"editVersion": 2,
//													"attrs": {
//														"Slot1H2F6U36O0": {
//															"type": "gearcontainer",
//															"jaxId": "1HAA3UKHO1",
//															"editVersion": 4,
//															"attrs": {
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"container": "true"
//															}
//														}
//													}
//												}
//											}
//										}
//									]
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1HAA3NR1A1",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1HAA3NR1A2",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1HAA3NR1A3",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "box",
//							"jaxId": "1HAAKRDC20",
//							"editVersion": 54,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1HAAKRDC21",
//									"editVersion": 262,
//									"attrs": {
//										"type": "box",
//										"id": "BoxInput",
//										"position": "relative",
//										"x": "10",
//										"y": "0",
//										"w": "100%-20",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "",
//										"padding": "",
//										"minW": "",
//										"minH": "30",
//										"maxW": "360",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"background": "[255,255,255,1.00]",
//										"border": "0",
//										"borderStyle": "Solid",
//										"borderColor": "[0,0,0,1.00]",
//										"corner": "3",
//										"shadow": "false",
//										"shadowX": "0",
//										"shadowY": "1",
//										"shadowBlur": "4",
//										"shadowSpread": "0",
//										"shadowColor": "[0,0,0,0.30]",
//										"contentLayout": "Flex Y",
//										"attach": "#vo.type===\"input\""
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1HAAKRDC22",
//											"editVersion": 34,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HAAKRDC23",
//													"editVersion": 160,
//													"attrs": {
//														"type": "hud",
//														"id": "",
//														"position": "Relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "[5,0,5,0]",
//														"minW": "",
//														"minH": "20",
//														"maxW": "",
//														"maxH": "200",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex X",
//														"traceSize": "true",
//														"itemsAlign": "Center"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1HENTEQ6L0",
//															"editVersion": 32,
//															"attrs": {
//																"createArgs": {
//																	"type": "object",
//																	"def": "gearCrateArgs",
//																	"jaxId": "1HENTH7BK1",
//																	"editVersion": 22,
//																	"attrs": {
//																		"style": "\"front\"",
//																		"w": "28",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/folder.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HENTH7BK2",
//																	"editVersion": 45,
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"front\",28,0,appCfg.sharedAssets+\"/folder.svg\",null)",
//																		"id": "BtnOpenFile",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"attach": "#vo.file===\"tabos\""
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HENTH7BK3",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HENTH7BK4",
//																	"editVersion": 2,
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HENTHD4Q0",
//																			"editVersion": 4,
//																			"attrs": {
//																				"callArgs": {
//																					"type": "object",
//																					"jaxId": "1HENTHLIQ0",
//																					"editVersion": 2,
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HENTH7BK5",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"type": "object",
//																	"jaxId": "1HENTH7BK6",
//																	"editVersion": 0,
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1HF65I8TR0",
//															"editVersion": 37,
//															"attrs": {
//																"createArgs": {
//																	"type": "object",
//																	"def": "gearCrateArgs",
//																	"jaxId": "1HF65I8TR1",
//																	"editVersion": 22,
//																	"attrs": {
//																		"style": "\"front\"",
//																		"w": "28",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/folder.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HF65I8TR2",
//																	"editVersion": 58,
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"front\",28,0,appCfg.sharedAssets+\"/folder.svg\",null)",
//																		"id": "BtnOpenNative",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"attach": "#vo.file===\"native\""
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HF65I8TR3",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HF65I8TR4",
//																	"editVersion": 4,
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HF65I8TS2",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "true",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"type": "object",
//																	"jaxId": "1HF65I8TS3",
//																	"editVersion": 0,
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "edit",
//															"jaxId": "1HAALRDJS0",
//															"editVersion": 44,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HAAM2RS10",
//																	"editVersion": 192,
//																	"attrs": {
//																		"type": "edit",
//																		"id": "EdInput",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%-80",
//																		"h": "30",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"inputType": "#vo.inputType||\"text\"",
//																		"text": "#vo.initText||vo.text||\"\"",
//																		"placeHolder": "#vo.placeholder||vo.tip||\"\"",
//																		"color": "[0,0,0]",
//																		"bgColor": "[255,255,255,1.00]",
//																		"font": "",
//																		"fontSize": "16",
//																		"outline": "0",
//																		"border": "[0,0,1,0]",
//																		"borderStyle": "Solid",
//																		"borderColor": "[0,0,0,1.00]",
//																		"corner": "0",
//																		"selectOnFocus": "true",
//																		"spellCheck": "true",
//																		"attach": "#!vo.memo"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HAAM2RS11",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HAAM2RS12",
//																	"editVersion": 6,
//																	"attrs": {
//																		"OnKeyDown": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HAAMBD940",
//																			"editVersion": 4,
//																			"attrs": {
//																				"callArgs": {
//																					"type": "object",
//																					"jaxId": "1HAAMBFJ20",
//																					"editVersion": 2,
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HAAM2RS13",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "memo",
//															"jaxId": "1HAAKRDC30",
//															"editVersion": 53,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HAAKRDC31",
//																	"editVersion": 340,
//																	"attrs": {
//																		"type": "memo",
//																		"id": "EdMemo",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%-50",
//																		"h": "",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "20",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"text": "#vo.initText||vo.text",
//																		"color": "#cfgColor[\"fontBody\"]",
//																		"bgColor": "#cfgColor[\"body\"]",
//																		"font": "",
//																		"fontSize": "#txtSize.mid",
//																		"outline": "0",
//																		"border": "[0,0,1,0]",
//																		"borderStyle": "Solid",
//																		"borderColor": "[0,0,0,0.5]",
//																		"corner": "0",
//																		"readOnly": "false",
//																		"selectOnFocus": "true",
//																		"spellCheck": "true",
//																		"flex": "true",
//																		"attach": "#!!vo.memo"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HAAKRDC32",
//																	"editVersion": 22,
//																	"attrs": {}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HAAKRDC40",
//																	"editVersion": 8,
//																	"attrs": {
//																		"OnInput": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HAAKRDC41",
//																			"editVersion": 4,
//																			"attrs": {
//																				"callArgs": {
//																					"type": "object",
//																					"jaxId": "1HAAKRDC42",
//																					"editVersion": 0,
//																					"attrs": {}
//																				},
//																				"seg": ""
//																			}
//																		},
//																		"OnKeyDown": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HAAKRDC43",
//																			"editVersion": 4,
//																			"attrs": {
//																				"callArgs": {
//																					"type": "object",
//																					"jaxId": "1HAAKRDC44",
//																					"editVersion": 2,
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HAAKRDC45",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnIcon.js",
//															"jaxId": "1HAAKRDC46",
//															"editVersion": 54,
//															"attrs": {
//																"createArgs": {
//																	"type": "object",
//																	"def": "gearCrateArgs",
//																	"jaxId": "1HAAKRDC47",
//																	"editVersion": 16,
//																	"attrs": {
//																		"style": "\"front\"",
//																		"w": "30",
//																		"h": "0",
//																		"icon": "#appCfg.sharedAssets+\"/send.svg\"",
//																		"colorBG": "null"
//																	}
//																},
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HAAKRDC48",
//																	"editVersion": 86,
//																	"attrs": {
//																		"type": "#null#>BtnIcon(\"front\",30,0,appCfg.sharedAssets+\"/send.svg\",null)",
//																		"id": "BtnSend",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"margin": "[0,0,0,10]",
//																		"padding": "2",
//																		"anchorV": "Top",
//																		"autoLayout": "true"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HAAKRDC49",
//																	"editVersion": 22,
//																	"attrs": {}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HAAKRDC52",
//																	"editVersion": 2,
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HAAKRDC53",
//																			"editVersion": 4,
//																			"attrs": {
//																				"callArgs": {
//																					"type": "object",
//																					"jaxId": "1HAAKRDC54",
//																					"editVersion": 2,
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HAAKRDC55",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"type": "object",
//																	"jaxId": "1HAAKRDC56",
//																	"editVersion": 0,
//																	"attrs": {}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "text",
//															"jaxId": "1HAAKRDC57",
//															"editVersion": 52,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HAAKRDC58",
//																	"editVersion": 200,
//																	"attrs": {
//																		"type": "text",
//																		"id": "TxtInputHint",
//																		"position": "Absolute",
//																		"x": "15",
//																		"y": "0",
//																		"w": "100",
//																		"h": "100%",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "#(!vo.initText)&&(!vo.text)",
//																		"clip": "Off",
//																		"uiEvent": "Tree Off",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"color": "#cfgColor[\"fontBodyLit\"]",
//																		"text": "#vo.placeholder||vo.tip||\"\"",
//																		"font": "",
//																		"fontSize": "#txtSize.mid",
//																		"bold": "false",
//																		"italic": "true",
//																		"underline": "false",
//																		"alignH": "Left",
//																		"alignV": "Center",
//																		"wrap": "false",
//																		"ellipsis": "false",
//																		"select": "false",
//																		"shadow": "false",
//																		"shadowX": "0",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowColor": "[0,0,0,1.00]",
//																		"shadowEx": "",
//																		"maxTextW": "0",
//																		"attach": "#!!vo.memo"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HAAKRDC59",
//																	"editVersion": 22,
//																	"attrs": {}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HAAKRDC516",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HAAKRDC517",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "true"
//															}
//														}
//													]
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1HAAKRDC518",
//													"editVersion": 10,
//													"attrs": {}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1HAAKRDC72",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1HAAKRDC73",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "text",
//											"jaxId": "1HAAL48AG0",
//											"editVersion": 20,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HAAL5BJ90",
//													"editVersion": 136,
//													"attrs": {
//														"type": "text",
//														"id": "",
//														"position": "relative",
//														"x": "10",
//														"y": "0",
//														"w": "100%-20",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"color": "#cfgColor[\"fontBodySub\"]",
//														"text": "New line: Shift+Enter",
//														"font": "",
//														"fontSize": "#txtSize.small",
//														"bold": "false",
//														"italic": "false",
//														"underline": "false",
//														"alignH": "Left",
//														"alignV": "Top",
//														"wrap": "false",
//														"ellipsis": "false",
//														"select": "false",
//														"shadow": "false",
//														"shadowX": "0",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowColor": "[0,0,0,1.00]",
//														"shadowEx": "",
//														"maxTextW": "0",
//														"attach": "#vo.memo"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": []
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1HAAL5BJ91",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1HAAL5BJ92",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1HAAL5BJ93",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "false",
//												"nameVal": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1HAAKRDC825",
//									"editVersion": 22,
//									"attrs": {}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1HAAKRDC832",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1HAAKRDC833",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1HBIS5UIR0",
//							"editVersion": 57,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1HBIS5UIR1",
//									"editVersion": 154,
//									"attrs": {
//										"type": "hud",
//										"id": "BoxCode",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[10,0,0,0]",
//										"padding": "[0,20,0,20]",
//										"minW": "",
//										"minH": "40",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex Y",
//										"subAlign": "Start",
//										"itemsAlign": "Center",
//										"itemsWrap": "Wrap",
//										"attach": "#vo.type===\"code\""
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": [
//										{
//											"type": "hudobj",
//											"def": "box",
//											"jaxId": "1HBISLN7M0",
//											"editVersion": 24,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HBISS1QQ0",
//													"editVersion": 150,
//													"attrs": {
//														"type": "box",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"background": "#cfgColor[\"body\"]",
//														"border": "1",
//														"borderStyle": "Solid",
//														"borderColor": "[0,0,0,1.00]",
//														"corner": "0",
//														"shadow": "false",
//														"shadowX": "2",
//														"shadowY": "2",
//														"shadowBlur": "3",
//														"shadowSpread": "0",
//														"shadowColor": "[0,0,0,0.50]",
//														"contentLayout": "Flex Y"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "box",
//															"jaxId": "1HBISSGF50",
//															"editVersion": 20,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HBISTQUU0",
//																	"editVersion": 104,
//																	"attrs": {
//																		"type": "box",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "10",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"background": "#cfgColor[\"secondary\"]",
//																		"border": "0",
//																		"borderStyle": "Solid",
//																		"borderColor": "[0,0,0,1.00]",
//																		"corner": "0",
//																		"shadow": "false",
//																		"shadowX": "2",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowSpread": "0",
//																		"shadowColor": "[0,0,0,0.50]"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HBISTQUU1",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HBISTQUU2",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HBISTQUU3",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "hud",
//															"jaxId": "1HBIST3QG0",
//															"editVersion": 31,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HBIT7NV60",
//																	"editVersion": 76,
//																	"attrs": {
//																		"type": "hud",
//																		"id": "BoxCodes",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "300",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": ""
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HBIT7NV61",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HBIT7NV62",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HBIT7NV63",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"exposeContainer": "false"
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "box",
//															"jaxId": "1HBISTSUE0",
//															"editVersion": 20,
//															"attrs": {
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HBISTSUE1",
//																	"editVersion": 104,
//																	"attrs": {
//																		"type": "box",
//																		"id": "",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"w": "100%",
//																		"h": "10",
//																		"anchorH": "Left",
//																		"anchorV": "Top",
//																		"autoLayout": "false",
//																		"display": "On",
//																		"clip": "Off",
//																		"uiEvent": "On",
//																		"alpha": "1",
//																		"rotate": "0",
//																		"scale": "",
//																		"filter": "",
//																		"cursor": "",
//																		"zIndex": "0",
//																		"margin": "",
//																		"padding": "",
//																		"minW": "",
//																		"minH": "",
//																		"maxW": "",
//																		"maxH": "",
//																		"face": "",
//																		"styleClass": "",
//																		"background": "#cfgColor[\"secondary\"]",
//																		"border": "0",
//																		"borderStyle": "Solid",
//																		"borderColor": "[0,0,0,1.00]",
//																		"corner": "0",
//																		"shadow": "false",
//																		"shadowX": "2",
//																		"shadowY": "2",
//																		"shadowBlur": "3",
//																		"shadowSpread": "0",
//																		"shadowColor": "[0,0,0,0.50]"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HBISTSUE2",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HBISTSUE3",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HBISTSUE4",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "true",
//																"nameVal": "false"
//															}
//														}
//													]
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1HBISS1QQ1",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1HBISS1QQ2",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1HBISS1QQ3",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false"
//											}
//										},
//										{
//											"type": "hudobj",
//											"def": "hud",
//											"jaxId": "1HBISOTQN0",
//											"editVersion": 22,
//											"attrs": {
//												"properties": {
//													"type": "object",
//													"jaxId": "1HBISS1QQ4",
//													"editVersion": 102,
//													"attrs": {
//														"type": "hud",
//														"id": "",
//														"position": "relative",
//														"x": "0",
//														"y": "0",
//														"w": "100%",
//														"h": "30",
//														"anchorH": "Left",
//														"anchorV": "Top",
//														"autoLayout": "false",
//														"display": "On",
//														"clip": "Off",
//														"uiEvent": "On",
//														"alpha": "1",
//														"rotate": "0",
//														"scale": "",
//														"filter": "",
//														"cursor": "",
//														"zIndex": "0",
//														"margin": "",
//														"padding": "[0,10,0,10]",
//														"minW": "",
//														"minH": "",
//														"maxW": "",
//														"maxH": "",
//														"face": "",
//														"styleClass": "",
//														"contentLayout": "Flex X"
//													}
//												},
//												"subHuds": {
//													"type": "array",
//													"attrs": [
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnText.js",
//															"jaxId": "1HBISPSNU0",
//															"editVersion": 61,
//															"attrs": {
//																"createArgs": {
//																	"type": "object",
//																	"def": "gearCrateArgs",
//																	"jaxId": "1HBISPSNU1",
//																	"editVersion": 36,
//																	"attrs": {
//																		"style": "primary",
//																		"w": "100",
//																		"h": "25",
//																		"text": "Apply",
//																		"outlined": "false",
//																		"icon": ""
//																	}
//																},
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HBISPSNU2",
//																	"editVersion": 102,
//																	"attrs": {
//																		"type": "#null#>BtnText(\"primary\",100,25,\"Apply\",false,\"\")",
//																		"id": "BtnApplyCode",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"corner": "3",
//																		"margin": "[5,15,5,0]"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HBISPSNU3",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HBISPSNU4",
//																	"editVersion": 2,
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HBISPSNU5",
//																			"editVersion": 4,
//																			"attrs": {
//																				"callArgs": {
//																					"type": "object",
//																					"jaxId": "1HBISPSNU6",
//																					"editVersion": 2,
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HBISPSNU7",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"type": "object",
//																	"jaxId": "1HBISPSNU8",
//																	"editVersion": 2,
//																	"attrs": {
//																		"Slot1H2F6U36O0": {
//																			"type": "gearcontainer",
//																			"jaxId": "1HBISPSNU9",
//																			"editVersion": 4,
//																			"attrs": {
//																				"subHuds": {
//																					"type": "array",
//																					"attrs": []
//																				},
//																				"container": "true"
//																			}
//																		}
//																	}
//																}
//															}
//														},
//														{
//															"type": "hudobj",
//															"def": "Gear/@StdUI/ui/BtnText.js",
//															"jaxId": "1HBISQGHA0",
//															"editVersion": 67,
//															"attrs": {
//																"createArgs": {
//																	"type": "object",
//																	"def": "gearCrateArgs",
//																	"jaxId": "1HBISQGHA1",
//																	"editVersion": 54,
//																	"attrs": {
//																		"style": "warning",
//																		"w": "100",
//																		"h": "25",
//																		"text": "Cancel",
//																		"outlined": "false",
//																		"icon": ""
//																	}
//																},
//																"properties": {
//																	"type": "object",
//																	"jaxId": "1HBISQGHA2",
//																	"editVersion": 96,
//																	"attrs": {
//																		"type": "#null#>BtnText(\"warning\",100,25,\"Cancel\",false,\"\")",
//																		"id": "BtnAbortCode",
//																		"position": "relative",
//																		"x": "0",
//																		"y": "0",
//																		"display": "On",
//																		"face": "",
//																		"margin": "[5,15,5,0]",
//																		"corner": "3"
//																	}
//																},
//																"subHuds": {
//																	"type": "array",
//																	"attrs": []
//																},
//																"faces": {
//																	"type": "object",
//																	"jaxId": "1HBISQGHA3",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"functions": {
//																	"type": "object",
//																	"jaxId": "1HBISQGHA4",
//																	"editVersion": 2,
//																	"attrs": {
//																		"OnClick": {
//																			"type": "fixedFunc",
//																			"jaxId": "1HBISQGHA5",
//																			"editVersion": 4,
//																			"attrs": {
//																				"callArgs": {
//																					"type": "object",
//																					"jaxId": "1HBISQGHA6",
//																					"editVersion": 2,
//																					"attrs": {
//																						"event": ""
//																					}
//																				},
//																				"seg": ""
//																			}
//																		}
//																	}
//																},
//																"extraPpts": {
//																	"type": "object",
//																	"def": "Object",
//																	"jaxId": "1HBISQGHA7",
//																	"editVersion": 0,
//																	"attrs": {}
//																},
//																"mockup": "false",
//																"codes": "false",
//																"locked": "false",
//																"container": "false",
//																"nameVal": "false",
//																"containerSlots": {
//																	"type": "object",
//																	"jaxId": "1HBISQGHA8",
//																	"editVersion": 2,
//																	"attrs": {
//																		"Slot1H2F6U36O0": {
//																			"type": "gearcontainer",
//																			"jaxId": "1HBISQGHA9",
//																			"editVersion": 4,
//																			"attrs": {
//																				"subHuds": {
//																					"type": "array",
//																					"attrs": []
//																				},
//																				"container": "true"
//																			}
//																		}
//																	}
//																}
//															}
//														}
//													]
//												},
//												"faces": {
//													"type": "object",
//													"jaxId": "1HBISS1QQ5",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"functions": {
//													"type": "object",
//													"jaxId": "1HBISS1QQ6",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"extraPpts": {
//													"type": "object",
//													"def": "Object",
//													"jaxId": "1HBISS1QQ7",
//													"editVersion": 0,
//													"attrs": {}
//												},
//												"mockup": "false",
//												"codes": "false",
//												"locked": "false",
//												"container": "true",
//												"nameVal": "false",
//												"exposeContainer": "false"
//											}
//										}
//									]
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1HBIS5UIT15",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1HBIS5UIT16",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1HBIS5UIT17",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						},
//						{
//							"type": "hudobj",
//							"def": "hud",
//							"jaxId": "1HEJE92P70",
//							"editVersion": 57,
//							"attrs": {
//								"properties": {
//									"type": "object",
//									"jaxId": "1HEJE92P71",
//									"editVersion": 146,
//									"attrs": {
//										"type": "hud",
//										"id": "BoxBlock",
//										"position": "relative",
//										"x": "0",
//										"y": "0",
//										"w": "100%",
//										"h": "",
//										"anchorH": "Left",
//										"anchorV": "Top",
//										"autoLayout": "false",
//										"display": "On",
//										"clip": "Off",
//										"uiEvent": "On",
//										"alpha": "1",
//										"rotate": "0",
//										"scale": "",
//										"filter": "",
//										"cursor": "",
//										"zIndex": "0",
//										"margin": "[10,0,0,0]",
//										"padding": "[0,20,0,20]",
//										"minW": "",
//										"minH": "40",
//										"maxW": "",
//										"maxH": "",
//										"face": "",
//										"styleClass": "",
//										"contentLayout": "Flex X",
//										"subAlign": "Start",
//										"itemsAlign": "Center",
//										"itemsWrap": "Wrap",
//										"attach": "#vo.type===\"block\""
//									}
//								},
//								"subHuds": {
//									"type": "array",
//									"attrs": []
//								},
//								"faces": {
//									"type": "object",
//									"jaxId": "1HEJE92P825",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"functions": {
//									"type": "object",
//									"jaxId": "1HEJE92P826",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"extraPpts": {
//									"type": "object",
//									"def": "Object",
//									"jaxId": "1HEJE92P827",
//									"editVersion": 0,
//									"attrs": {}
//								},
//								"mockup": "false",
//								"codes": "false",
//								"locked": "false",
//								"container": "true",
//								"nameVal": "true",
//								"exposeContainer": "false"
//							}
//						}
//					]
//				},
//				"faces": {
//					"type": "object",
//					"jaxId": "1HA934NIR10",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"functions": {
//					"type": "object",
//					"jaxId": "1HA934NIR11",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"extraPpts": {
//					"type": "object",
//					"def": "Object",
//					"jaxId": "1HA934NIR12",
//					"editVersion": 0,
//					"attrs": {}
//				},
//				"mockup": "false",
//				"codes": "false",
//				"locked": "false",
//				"container": "true",
//				"nameVal": "false",
//				"exposeContainer": "false"
//			}
//		},
//		"exposeGear": "false",
//		"exposeTemplate": "false",
//		"exposeAttrs": {
//			"type": "object",
//			"def": "exposeAttrs",
//			"jaxId": "1HA934NIR13",
//			"editVersion": 64,
//			"attrs": {
//				"id": "true",
//				"position": "true",
//				"x": "true",
//				"y": "true",
//				"w": "false",
//				"h": "false",
//				"anchorH": "false",
//				"anchorV": "false",
//				"autoLayout": "false",
//				"display": "true",
//				"contentLayout": "false",
//				"subAlign": "false",
//				"itemsAlign": "false",
//				"itemsWrap": "false",
//				"clip": "false",
//				"uiEvent": "false",
//				"alpha": "false",
//				"rotate": "false",
//				"scale": "false",
//				"filter": "false",
//				"aspect": "false",
//				"cursor": "false",
//				"zIndex": "false",
//				"flex": "false",
//				"margin": "false",
//				"traceSize": "false",
//				"padding": "false",
//				"minW": "false",
//				"minH": "false",
//				"maxW": "false",
//				"maxH": "false",
//				"styleClass": "false"
//			}
//		},
//		"exposeStateAttrs": {
//			"type": "array",
//			"def": "StringArray",
//			"attrs": []
//		}
//	}
//}